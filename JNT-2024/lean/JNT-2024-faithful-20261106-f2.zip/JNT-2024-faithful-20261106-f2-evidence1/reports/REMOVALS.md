# Removed obsolete proof targets — f2

Reference manuscript: **2026-11-06d**. Previous releases remain unchanged.

The following earlier proofs were removed; correspondence uses their existing published-proof replacements. Qualified names below omit the common `«JNT-2024».` prefix.

| Removed target | Retained published-proof target |
|---|---|
| `Parameters.lemma32` | `Parameters.lemma32_published_of_paper_hypotheses` |
| `Parameters.lemma33a_of_integral` | `Parameters.lemma33_published` |
| `lemma33c` | `lemma33c_published` |
| `Parameters.lemma34` | `Parameters.lemma34_published_statement` |
| `Parameters.representation_fourth_power` | `Parameters.representation_fourth_power_published` |
| `Parameters.candidate_normalized_representation_published` | `Parameters.candidate_representation_from_published_quotient` |

Twelve additional source declarations had no remaining use and were removed:

- `Parameters.representation_first_square`.
- `Parameters.candidate_gcd_dvd_coordinate`.
- `Parameters.candidate_other_valuation_lower`.
- `valuation_quadratic_root_bound`.
- `Parameters.candidate_gcd_dvd_coordinate_of_integral`.
- `Parameters.unnormalized_representation`.
- `Parameters.representation_odd_center`.
- `Parameters.candidate_valuation_le_radical`.
- `Parameters.candidate_positive_prime_support`.
- `Parameters.lemma33a`.
- `normalizationQuotient_negative_of_dvd`.
- `normalizationQuotient_valuation_le`.

In total, 18 source declarations and their generated declarations (35 compiled
names) were removed. `RepresentationParity.lean` became empty and was removed;
its imports were removed. Blank lines preserve the locations of all retained
source declarations. No retained statement or proof body changed.

The selection record contains the exact removed names and hashes of the 1568
retained declaration texts. Fresh compiled-environment checks forbid all 35
removed names and check that every retained source declaration has a recorded
correspondence, dependency or elaboration purpose.

The main theorem and its Section 6 applications still explicitly require
`DenominatorEstimate4`, `AkhtariTheorem11` and `Section46Magma`.
The separate finite-maxima calculation record, other approved proof choices
and exclusions are unchanged; see [SCOPE.md](SCOPE.md).
