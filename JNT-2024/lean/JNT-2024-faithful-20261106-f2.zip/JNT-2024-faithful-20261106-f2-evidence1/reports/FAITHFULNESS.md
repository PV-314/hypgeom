# Faithfulness review — 2026-11-06d

The reference is the exact PDF/TeX included in `manuscript/`. This release
follows its revised Section 5 and Theorem 1.4, with the approved inputs,
proof choices and exclusions in [SCOPE.md](SCOPE.md).

The f1 audit identified six obsolete correspondence targets whose earlier
proofs were still included. In f2 those six targets and twelve helpers used
only by the removed proofs are absent. Correspondence now uses the existing
published-proof declarations. See [REMOVALS.md](REMOVALS.md) for the exact list.

All 1568 retained source declarations have exactly the same text as in f1-doc1.
No retained mathematical statement, hypothesis or proof body was edited.
The earlier authorized Section 6 updates are preserved: its upper bounds use
the current Section 5 assembly, and its cutoff comparison states only the
printed conclusions for families 6.5–6.6.

The fresh audits check separate statement-type and proof-value dependencies,
92 specified published-proof steps, the occurrence of approved external
premises in proof bodies, and the absence of every removed declaration.
These checks supplement the prior manuscript review; they are not an
automated proof of correspondence with mathematical prose.

The principal checks are:

- All 27 numbered statement bodies are matched to the included TeX by their
  recorded locations and hashes. All 24 nonconjectural statements have Lean
  references with the stated scope; conjectures remain identified as such.
- Section 2 retains the actual arbitrary-field Lemma 2.1, the printed
  successor argument, supplied analytic proofs, approved m=1,n=4 denominator
  scope, Gaussian correction, and published constants 1.072 and 1.257.
- Section 3 retains the restored prime, gcd and parity arguments, signed
  representations, gap principle and printed analytic reductions. The
  approved finite proof choice for Lemma 3.13 is explicit.
- Section 4 uses the printed case analysis and the approved Akhtari and Magma
  inputs. The nine alternative quartic certificates and the alternative
  Proposition 4.1 are absent.
- Theorem 1.4 uses the current Lemmas 5.1–5.6 and assembly. The superseded
  classifications, old main theorem and Ljunggren input are absent.
- Section 6 retains the printed parameter ranges, witnesses, normalizers,
  inequalities and limits. Both `family64_atMost_three` and
  `families65_68_atMost_three` call `theorem14_revised`, with its same three
  explicit premises. Their compiled proof dependencies are audited along
  with every other retained correspondence target.
- The 06d negative-a normalization and revised Lemma 3.8(b) remark are kept
  with their complete supplied proofs and precise scope.

No kernel audit can by itself establish manuscript correspondence. The full
statement log, correspondence table, preserved proof text and dependency
checks are provided together so that this comparison is reviewable.

`release/verification.json` gives the measured results of the fresh clean
build and complete audits. `release/source-preservation.json` records the
declaration comparison, and `release/proof-closures.json` records all audited
dependency closures. `release/proof-usage-verification.json` and
`release/proof-route-checks.json` record the separate proof-use checks. No result from a prior release is used as this release's
build or axiom-audit evidence.

The only sources needed for reconstruction are in this ZIP and its pinned
external dependencies. Reproduction uses relative project paths and does
not read another release ZIP, checkout or compiled project cache.
