# Calculations not certified in Lean

Authoritative register, started 2 November 2026 at the user's instruction.
Every calculation whose Lean certification we skip must receive an entry here.
Retain its exact claim, source, evidence, verification status, Lean interface,
and uses. Numerical evidence is not a Lean proof. Use explicit named hypotheses
where needed; never hide an input behind `sorry`, an axiom, or an instance.
Existing certified calculations and supplied mathematical proofs are retained.

## CALC-001 — Lemma 2.3(a), finite calculation: finite calculation and both maxima

- **Decision:** accepted as a result of calculation; further Lean certification
  waived by the user. Closed for computational work. Do not restart the experiments.
- **Domain:** 0 ≤ r ≤ 138, d' = 2^e for 0 ≤ e ≤ 6; 973 pairs.
- **Result:** both normalized expressions attain their maxima at r = 3;
  among these representatives both are attained at d' = 2, 8, 32. Values:
  128 sqrt(2) exp(-126/25) and (15015/512) sqrt(2) exp(-126/25), approximately
  1.1718736219027062859 and 0.26848880665388694584. Bounds are strict for r ≠ 3.
- **Evidence:** [reproducible exact arithmetic](../audit/check-denominator-maxima.py),
  [all indexed values](../audit/denominator-maxima-values.json), and
  [calculation details](../audit/denominator-maxima-status.md). Runtime about 0.30 seconds.
  Comparisons use exact rational arithmetic and an exponential enclosure;
  decimal displays are not used for decisions.
- **Lean interface:** `Calculations.Lemma23aFiniteMaxima` in
  [CalculationInputs.lean](../JNT-2024/CalculationInputs.lean). Its fields state
  the finite bounds, strictness off r = 3, and attainment at d = 2, r = 3.
  The previously proved seven-representative reduction supports general d ≠ 0.
- **Uses:** the manuscript's reported maxima. Existing `lemma23a_finite` and
  Theorem 1.4 continue to use their original proved bounds and do not acquire
  this premise. A future proof using this input must name `hCalculation` explicitly.
- **Trust:** externally checked calculation; NOT a kernel-proved maximum theorem.
  `DenominatorEstimate4` remains a separate cited mathematical input.

## CALC-002 — Section 4.6, small-d calculation: 63 quartics

- **Decision:** the user explicitly authorized recording global completeness as
  a Magma calculation result, with an independent search for 1 <= y <= 109.
  This supersedes the earlier restriction to the remaining 54 equations.
- **Exact claim:** for every `(a,n)` in `Section4.smallPairs`, every positive
  solution of `x^2+n^2=(a^2+n^2)*y^4` has `y<=109`.
- **Lean input:** `Calculations.Section46Magma` in
  [Section46Calculation.lean](../JNT-2024/Section46Calculation.lean). Its `height`
  field is precisely `SmallQuarticHeightBound`. There is no axiom or instance.
  Every theorem using this input names `hCalculation` explicitly.
- **Evidence:** [exact bounded search](../audit/check-section46-small-search.py)
  and [all 63 lists and function inputs](../audit/section46-small-search.json).
  The independent search took 0.014 seconds and matched every existing Lean
  list. It found 18 equations with at least two solutions and exactly the two
  printed exceptions with three. It does not establish global completeness.
- **Reuse:** the existing kernel-certified bounded completeness, soundness,
  counts, and height of listed solutions are unchanged. Their application to
  the named input proves `section46_lists_complete`,
  `section46_solution_set`, and `section46_global_lists_and_counts`.
- **Magma application:** use the documented two-argument overload with
  coefficients `[a^2+n^2,0,0,0,-n^2]` and point `[1,a]`. Coordinate order is
  `[paper y,paper x]`; convert to positive solutions using both absolute values
  and discard zero coordinates. The one-argument overload requires a square
  constant term and is inapplicable here. See the
  [official handbook](https://docs.magma-maths.org/ArithmeticGeometry/EllipticCurvesOverQAndNumberFields/intro-2.html#integralquarticpointsq-p-rngintelt-rngintelt-seqenum)
  and [reconstructed input](../audit/section46-magma-input.m).
- **Limits of verification:** the initial PDF reports V2.28-2 and its global
  result. The historical program/output has not yet been recovered, and the
  reconstructed Magma input has not been executed. The documentation review
  establishes the correct API application, not the historical execution or a
  new unrestricted computation. This accepted global input remains visibly
  external to Lean.
- **Scope:** the nine alternative global proofs are excluded from this release.
  They are not used to justify this input.

Other pending enumerations are not automatically accepted or skipped by this
decision. Add a numbered entry whenever the same policy is applied to one.

## CALC-002 status clarification in f1-doc1

The user reconfirmed: keep the explicit input and clarify its documentation;
do not undertake a fresh unrestricted Magma run for this update.

There are two distinct assertions:

1. **Proved in Lean:** within 1 <= y <= 109, the listed positive solutions are
   complete (with no imposed bound on x), for all 63 equations. The bounded
   counts are 18 equations with at least two solutions and exactly two with
   three solutions, namely the printed d=17 and d=68 cases.
2. **Explicit external input:** every positive solution of every one of those
   63 equations satisfies y <= 109. This is `Section46Magma.height`, not a
   consequence of the bounded search. Global completeness and the global
   counts are Lean theorems conditional on that input.

The historical transcript is unavailable. The reconstructed script has not
been executed, and no fresh unrestricted Magma verification is claimed.
The script uses the documented two-argument overload, whose API was checked
again against the official handbook for this update. API correctness is not
execution evidence. The existing calculation premise remains unchanged.
