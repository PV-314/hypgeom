# Corrections and supplied proof details

This report concerns the included 2026-11-06d manuscript. Earlier corrected
errors are distinguished from details supplied to make the proofs explicit.
It is not a list of new errors still requiring changes to this manuscript.

| Location | Correction or qualification and consequence |
|---|---|
| Section 1.2 | Smallest-square normalization can force a=0: alpha=120+49sqrt(6), epsilon=5+2sqrt(6), y(-1)=1 and x(-1)=0. The warning and example are proved; the author defers the zero-a case. No unrestricted rebasing theorem is asserted. |
| Section 1.2, 06d addition | Negative a is handled by minus algebraic conjugation: (x_k,y_k) becomes (-x(-k),y(-k)). Norm, all y-values and the least-square property are preserved, for arbitrary b and both unit norms. The standing assumptions, rather than Proposition 3.1, are the relevant positivity restriction. |
| Lemma 2.1 proof | Two missing final factors p in successor determinants in the initial attachment were restored. A subsequent product/quotient typo was also corrected by the author. Statement and constants are unchanged. |
| Lemma 2.2(a,c,e) | Parameter, conjugation, endpoint and domain details required justification. The current (e) uses the cited near-one domain; the supplied continuation proof establishes that interface. |
| Equation (2.8) | The current literal k0=1.257 and the factor 1.072 are retained. Section 4 uses the corresponding non-strict upper estimate and proves its required strict conclusions. |
| Remark after Proposition 3.1 | The standalone radical-under-powers claim needs nonzero norm and a positive exponent. The general remark is excluded; the required unit specialization is proved. |
| Proposition 3.1(b-i) | The previously alleged coefficient error was withdrawn. There is no coefficient correction. |
| Lemma 3.8(b), opening remark | The ambiguous small-numerator assertion was replaced by a precise statement about arbitrary integer coordinates. Rationalisation, the strict inequalities and arbitrarily small differences are proved. No occurrence among sequence representations is asserted. |
| Lemma 3.9(a) | The comparison with 2.29/sqrt(15) is non-strict; equality occurs at k=0 for (a,b,d,t,u)=(15,1,240,62,4). The final strict bound <0.6 and downstream constants remain unchanged. |
| Lemma 3.10 | The odd-gcd hypothesis and even-gcd counterexample were already present in the corrected attachment; both are retained. |
| Lemmas 5.4–5.5 | The unnecessary absolute-norm >=4 restriction was removed from 5.4, which is applied directly in 5.5. Both full statements include norm -1. |
| Section 5 | The new manuscript replaces the earlier enumeration/classification proof. The former 86-versus-78 scope issue and 20-versus-22 unit count concern the superseded text, not this proof. The current Lemmas 5.1–5.6 and assembly are used throughout, including Section 6. |

The following omitted or compressed details have proofs, not additional
assumptions:

| Location | Supplied construction or justification |
|---|---|
| Section 1.2, after (1.3) | Identification of the recurrence coefficient with the field trace of epsilon squared; coordinate and ring-of-integers bridges; repeated-value example and necessary unit condition. |
| Lemma 2.1 | Least successor index, integral-norm discreteness, positivity and nonvanishing determinants; applicability to every imaginary quadratic field; printed successor inequalities. |
| Lemma 2.2 | Common remainder construction, general identity, integral/continuation and branch arguments, conjugation and endpoints, and the required estimates. |
| Lemma 2.3(a) | Coefficientwise content monotonicity, removal of odd factors and finite reduction to seven powers of two. Exact maxima are separately recorded as CALC-001. |
| Lemma 2.3(b) | Rational difference and positivity in the second induction. |
| Equations (2.5)–(2.10) | Homogenisation, integrality, Gaussian correction, field membership, determinant/error identities and uniform estimates. |
| Lemma 3.2, after (3.6) | Both omitted prime-two gcd cases and their combined divisibility proof. |
| Proposition 3.1(a) | Maximality of the common normalization and exact quotient construction. |
| Proposition 3.1(b) | Mixed-parity valuations including zero center; equal-valuation subtraction; even-u implication forcing odd y. |
| Lemmas 3.5–3.9 | Positivity, nearest-root selection, phase and signed-coordinate identities, monotonicity and gap bootstrap. |
| Lemmas 3.10–3.12 | Recurrences, integrality periods, gcd descents and valuation cases following the printed arguments. |
| Section 4 | All approximation hypotheses from the sequence and all printed intermediate inequalities; exceptional middle quartic solutions excluded by integrality. |
| Section 5 | New bounds, congruences and prime-divisor cases; full signed-unit and norm -1 coverage; explicit above/below-cutoff distinction in the assembly. |
| Section 6.1 | Indices and square roots for the six additional tuples whose witnesses were omitted. |
| Section 6.9 | Explicit square-negative-norm family with limiting ratio 1/4 from above. |

Approved proof choices and shared helpers:

- Lemma 2.2 retains the supplied analytic proofs. Required general helpers can
  prove more than their manuscript-facing specializations; every application
  keeps the published hypotheses and constants, including 1.072.
- Lemma 2.3 uses the existing kernel-certified finite inequalities. No lengthy
  new exact-maxima proof is introduced.
- Lemma 3.13 retains the expressly approved certified finite alternative with
  the printed analytic reductions. Exact reported minima and the optional
  improvement to 1.14 remain excluded.
- Shared arithmetic and algebraic helpers are retained only when required by
  the faithful statements/proofs or their elaboration. The six obsolete targets
  and their unused helpers were removed in f2. The constant-one alternative wrapper,
  alternative Proposition 4.1 and old Section 5 classifications are absent.
- The Section 6 cutoff comparison declaration now contains only the two
  printed conclusions for 6.5–6.6. Its extra comparisons for 6.7–6.8 are
  omitted from this faithful-only copy; the printed norm bounds and
  normalizer identities for all four families remain.

All approved external dependencies and remaining omissions are individually
listed in [SCOPE.md](SCOPE.md). No new mathematical hypothesis is introduced
by separating this release. Prior complete releases preserve the alternatives;
they are not required to build or audit this one.

The f2 removal changes the source selection and correspondence targets, not
the retained mathematics or its approved inputs. The exact removals and
published-proof replacements are in [REMOVALS.md](REMOVALS.md).
