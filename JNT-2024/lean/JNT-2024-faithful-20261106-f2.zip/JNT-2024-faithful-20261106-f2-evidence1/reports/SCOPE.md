# Explicit dependencies, approved choices and omissions

Locations refer to the included 2026-11-06d manuscript.

| Location | Explicit input or approved choice |
|---|---|
| Lemma 2.3(a), large-index denominator estimate | `Hypergeometric.DenominatorEstimate4`, the cited n=4 estimate in the sufficient two-term form for r >= 139. An explicit premise, not a proved external theorem. |
| Section 4.6, norm -1 | `ExternalResults.AkhtariTheorem11`, at most two positive solutions of AX^4-BY^2=1 for positive integer A,B. Its application is proved. |
| Section 4.6, 63 quartics | `Calculations.Section46Magma`, global completeness through the bound y <= 109. The bounded lists and counts are certified; global completeness is an approved calculation premise. No historical Magma transcript or new unrestricted execution is claimed. |
| Lemma 2.3(a), reported maxima | CALC-001 / `Calculations.Lemma23aFiniteMaxima`, exact maxima at r=3, accepted as a calculation record. The main theorem uses certified finite inequalities and does not assume this maxima input. |
| Lemma 3.13, finite part | The approved certified finite argument replaces the PARI search. Printed analytic reductions are retained. No PARI premise is added. |
| Section 2 denominator arithmetic | Approved specialization m=1,n=4. Lemma 2.2 retains its general rational-parameter statement. |

The three premises in the first three rows are the complete external premises
of Theorem 1.4 and of its Section 6 upper-bound applications. Axiom audits alone
do not display such premises: Lean proves conditional implications. Their full
types are printed in the statement audit. Ljunggren and superseded Section 5
proofs are absent from this release.

| Location | Unformalised assertion |
|---|---|
| General n in the denominator definitions and (2.1) | General-n denominator/content arithmetic and the product over primes dividing n. |
| Section 2, after (2.5) | The incidental odd-r field description for general t′. |
| Remark after Proposition 3.1 | The general radical-under-powers assertion, with its nonzero-norm and positive-power qualifications. |
| Remark after Lemma 3.5 | Negative-index y_k can be negative when N_alpha > 0. |
| Remark after Lemma 3.11 | The exact set m in {0,1,2,4}; the optional exclusion m=3 is not proved. |
| End of Lemma 3.13 proof | Exact minima 1.1408... and 190.3..., attaining examples, optional 1.14 improvement, timings and historical search limits. |
| Remark after Proposition 4.1 | The hypothetical stronger-cutoff implication for the conjecture. |

None of these omitted assertions is used as a premise of Theorem 1.4.
Conjectures 1.1–1.3 and the infinitude conjecture in Section 6.1 remain
conjectures. Historical searches, background and bibliographic claims are
outside theorem coverage.

Section 1.2: the zero-real-coordinate obstruction to unrestricted
smallest-square normalization is expressly deferred by the author. The
negative-a reversal in 06d is proved for arbitrary b and both unit norms;
the counterexample, b=1 least-square application and trace identity are proved.

Documentary limitations: the earlier review did not directly verify Baker's
cited Lemma 4 or compare Chen–Voutier with the publisher-typeset version.
The needed Lemma 2.2 estimates have independent Lean proofs. These limitations
add no premise. The historical Lemma 3.13 PARI script differs from the stated
search in filters and thresholds; no exact historical-search certification is
claimed. See the calculation register for the distinct Magma limitation.

Section 4.6 clarification: `Section46Magma` asserts that **every** positive
solution of each of the 63 quartics has y <= 109. Completeness inside that
bound is proved; exclusion of solutions above it remains the approved input.
The user reconfirmed retaining this status for the documentation update.
No historical transcript was recovered and no unrestricted Magma run was made.
