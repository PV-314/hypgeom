# Reproducible faithful release

Release identifier: **JNT-2024-faithful-20261106-f2**.
Manuscript: **2026-11-06d**, included with its exact hashes in `identity.json`.

Install Lean/elan and Git, and use Python 3.9 or newer. In a fresh extraction,
from this project's root:

```text
lake exe cache get
python -X utf8 release/reproduce.py
```

The first command obtains the pinned dependencies and their optional compiled
cache. The second requires that this project's `.lake/build` is absent; it
performs a clean `lake build`, exports and audits all compiled declarations,
runs `#print axioms` for all named theorems and every principal theorem,
prints all correspondence-root types, checks all root dependency closures,
checks proof-body usage and the specified published proof routes,
and verifies the dependency pins before and after. It uses two Lean workers.
Fresh logs are written to `reproduction/`, preserving the supplied release
logs. Do not run `lake update`, which would change pinned revisions.

To check the saved evidence without rebuilding:

```text
python -X utf8 release/verify.py
python -X utf8 release/verify-proof-usage.py
python -X utf8 release/verify-package.py
```

The supplied `clean-build.log` is from a fresh project build; only pinned
dependency caches were shared. `AllAxioms.log` contains the explicit
`#print axioms` output. `Export.log` and `environment.json` additionally audit
all generated/private declarations. `Statements.log` prints the full types,
including explicit external premises that are not kernel axioms.
`proof-closures.json` contains the dependency closure of every retained
correspondence root, including all Section 6 applications.

`verification.json` summarizes the measured audit results. `source-sha256.json`
identifies all Lean sources, build configuration and manuscript files.
`MANIFEST.sha256` covers the entire distributed payload except itself.

No previous release or project cache is required. The three explicit main
premises and the approved proof choices/omissions are in `reports/SCOPE.md`.
External results and unrestricted Magma completeness are not claimed proved.

`ProofUsage.lean` exports separate type and value dependencies and checks
external-parameter occurrence. `proof-usage-verification.json` records its
results. The audit also checks retained source text against the selection
record; a previous release is not required to perform this verification.

The f2 build and all Lean audits were run afresh after the removals. No f1
build or axiom-audit result is substituted for an f2 result.
