"""Check every distributed file against the release manifest, without Lean."""
from pathlib import Path
import hashlib,json,os,re
R=Path(__file__).resolve().parent.parent
manifest=R/'release/MANIFEST.sha256';count=0
for line in manifest.read_text(encoding='utf-8').splitlines():
    h,n=line.split('  ',1);p=(R/n).resolve()
    assert p.is_relative_to(R.resolve()) and p.is_file(),n
    assert hashlib.sha256(p.read_bytes()).hexdigest()==h,n
    count+=1
markdown=[]
for base,dirs,names in os.walk(R):
    dirs[:]=[d for d in dirs if d not in {'.lake','reproduction','__pycache__'}]
    markdown.extend(Path(base)/n for n in names if n.endswith('.md'))
for p in markdown:
    for target in re.findall(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
        if target.startswith(('http:','https:','#','mailto:')):continue
        target=target.split('#')[0]
        assert (p.parent/target).exists(),(str(p.relative_to(R)),target)
identity=json.loads((R/'release/identity.json').read_text(encoding='utf-8'))
print(json.dumps(dict(releaseId=identity['releaseId'],manifestFiles=count,status='passed'),indent=2))
