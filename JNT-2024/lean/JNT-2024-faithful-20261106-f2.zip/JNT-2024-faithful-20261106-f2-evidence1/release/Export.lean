import «JNT-2024»
import Lean
open Lean Elab Command

run_cmd do
  let env ← getEnv
  let mut rows : Array Json := #[]
  for (n, ci) in env.constants.toList do
    let some idx := env.getModuleIdxFor? n | continue
    let mod := env.header.moduleNames[idx.toNat]!
    unless mod.toString.startsWith "«JNT-2024»" || mod.toString.startsWith "JNT-2024" do continue
    let range ← findDeclarationRanges? n
    let r := match range with
      | none => Json.null
      | some r => toJson #[r.range.pos.line,r.range.pos.column,r.range.endPos.line,r.range.endPos.column]
    let axs ← collectAxioms n
    rows := rows.push <| Json.mkObj [
      ("name",toJson n.toString),("module",toJson mod.toString),("range",r),
      ("deps",toJson (ci.getUsedConstantsAsSet.toList.map Name.toString)),
      ("theorem",toJson ci.isTheorem),
      ("axioms",toJson (axs.toList.map Name.toString))]
  let dest ← liftIO <| IO.getEnv "JNT_AUDIT_ENVIRONMENT"
  liftIO <| IO.FS.writeFile (dest.getD "release/environment.json") (Json.compress (toJson rows))
  logInfo m!"Audited {rows.size} compiled project declarations, including generated declarations"
