"""From a fresh extraction: python release/reproduce.py.
Install the pinned Lean toolchain, run `lake exe cache get` first if desired.
Requires Python 3.9+, Git and Lake; no other JNT-2024 release is needed.
"""
from pathlib import Path
import argparse,json,os,subprocess,hashlib,time,shutil,sys
R=Path(__file__).resolve().parent.parent;A=R/'release'
parser=argparse.ArgumentParser()
parser.add_argument('--output',default='reproduction',help='relative output directory for fresh logs')
parser.add_argument('--jobs',type=int,default=2,help='Lean worker limit (default: 2)')
args=parser.parse_args();O=(R/args.output).resolve()
assert O.is_relative_to(R) and O!=R,'Output must be a child of this extracted project.'
assert 1<=args.jobs<=8
assert not (R/'.lake/build').exists(),'Use a fresh extraction: project build artifacts must be absent.'
O.mkdir(exist_ok=True)
assert shutil.which('lake') and shutil.which('lean') and shutil.which('git'),'Install Lean/elan and Git on PATH.'
for n,h in json.loads((A/'source-sha256.json').read_text()).items():
    assert hashlib.sha256((R/n).read_bytes()).hexdigest()==h,n
env=os.environ.copy();env.pop('LEAN_PATH',None);env['LEAN_NUM_THREADS']=str(args.jobs)
env['JNT_AUDIT_ENVIRONMENT']=str(O/'environment.json')
env['JNT_FIDELITY_OUTPUT']=str(O/'proof-details.json')
version=subprocess.check_output(['lean','--version'],cwd=R,env=env,text=True,encoding='utf-8')
assert '4.35.0' in version and 'eb6cafb' in version,version
(O/'toolchain.txt').write_text(version,encoding='utf-8')
def pins(name):
    rows=[]
    for dep in json.loads((R/'lake-manifest.json').read_text())['packages']:
        p=R/'.lake/packages'/dep['name']
        rev=subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip()
        dirty=subprocess.check_output(['git','-C',str(p),'status','--porcelain','--untracked-files=no'],text=True).strip()
        assert rev==dep['rev'] and not dirty,dep['name']
        rows.append(dict(name=dep['name'],url=dep['url'],rev=rev,trackedSourceClean=True))
    (O/name).write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
def run(name,cmd):
    print('Running '+name,flush=True);start=time.monotonic();last=start
    with (O/f'{name}.log').open('w',encoding='utf-8') as log:
        p=subprocess.Popen(cmd,cwd=R,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace')
        for line in p.stdout:
            log.write(line);log.flush()
            if 'error:' in line or 'Build completed' in line or time.monotonic()-last>30:
                print(line.rstrip(),flush=True);last=time.monotonic()
        code=p.wait()
    result=dict(exit=code,seconds=round(time.monotonic()-start,2),command=cmd,leanWorkers=args.jobs)
    if name=='clean-build':result['freshProjectArtifacts']=True
    (O/f'{name}.result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    assert code==0,name+' failed; inspect '+str(O/f'{name}.log')
pins('dependency-pins.json')
run('clean-build',['lake','build'])
for n in ['Export','AllAxioms','Statements','ProofUsage']:
    run(n,['lake','env','lean','--root=.',str(Path('release')/f'{n}.lean')])
pins('dependency-pins-after-build.json')
subprocess.run([sys.executable,'-X','utf8',str(A/'verify.py'),'--audit-dir',str(O),'--write'],cwd=R,env=env,check=True)
subprocess.run([sys.executable,'-X','utf8',str(A/'verify-proof-usage.py'),'--audit-dir',str(O),'--write'],cwd=R,env=env,check=True)
print('Fresh build and full audits passed.',flush=True)
