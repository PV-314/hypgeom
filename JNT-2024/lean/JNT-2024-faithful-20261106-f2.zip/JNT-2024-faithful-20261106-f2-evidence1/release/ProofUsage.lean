import «JNT-2024»
import Lean
open Lean Elab Command Meta

run_cmd do
  let env ← getEnv
  let mut rows : Array Json := #[]
  let mut seen : NameSet := {}
  for mod in env.header.moduleNames, data in env.header.moduleData do
    unless mod.toString.startsWith "«JNT-2024»" || mod.toString.startsWith "JNT-2024" do continue
    for n in data.constNames ++ data.extraConstNames do
      if seen.contains n then continue
      seen := seen.insert n
      let some ci := env.find? n | continue
      let mut params : Array Json := #[]
      let valueDeps := match ci.value? (allowOpaque := true) with
        | some v => v.getUsedConstants.toList.map Name.toString
        | none => []
      if ci.isTheorem then
        if let some v := ci.value? (allowOpaque := true) then
          params ← liftTermElabM <| lambdaTelescope v fun xs body => do
            let mut ps : Array Json := #[]
            for x in xs do
              let ld ← x.fvarId!.getDecl
              let deps := ld.type.getUsedConstants.toList.map Name.toString
              if deps.any (fun d => d.endsWith ".DenominatorEstimate4" || d.endsWith ".AkhtariTheorem11" || d.endsWith ".Section46Magma" || d.endsWith ".Lemma23aFiniteMaxima") then
                ps := ps.push <| Json.mkObj [("name",toJson ld.userName.toString),
                  ("typeConstants",toJson deps),("occursInBody",toJson (body.containsFVar x.fvarId!))]
            return ps
      rows := rows.push <| Json.mkObj [
        ("name",toJson n.toString),("module",toJson mod.toString),
        ("typeDeps",toJson (ci.type.getUsedConstants.toList.map Name.toString)),
        ("valueDeps",toJson valueDeps),("externalParameters",toJson params)]
  let some dest ← liftIO <| IO.getEnv "JNT_FIDELITY_OUTPUT" | throwError "Missing output path"
  liftIO <| IO.FS.writeFile dest (Json.compress (toJson rows))
  logInfo m!"Inspected types, proof bodies and external-parameter use for {rows.size} project declarations"
