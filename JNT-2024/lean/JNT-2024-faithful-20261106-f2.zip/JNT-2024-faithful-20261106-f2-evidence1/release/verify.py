"""Verify sources and saved or freshly reproduced build/axiom/dependency evidence."""
from pathlib import Path
import argparse,json,re,hashlib
R=Path(__file__).resolve().parent.parent;A=R/'release'
ap=argparse.ArgumentParser();ap.add_argument('--audit-dir');ap.add_argument('--write',action='store_true');args=ap.parse_args()
O=Path(args.audit_dir).resolve() if args.audit_dir else A
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(A/'identity.json');inventory=read(A/'audit-inventory.json')
sources=read(A/'source-sha256.json')
for n,h in sources.items():assert sha(R/n)==h,('Source changed',n)
modules={p.relative_to(R).as_posix() for p in (R/'JNT-2024').glob('*.lean')}
assert modules=={n for n in sources if n.startswith('JNT-2024/') and n.endswith('.lean')}
build=read(O/'clean-build.result.json');bt=(O/'clean-build.log').read_text(encoding='utf-8')
assert build['exit']==0 and build['freshProjectArtifacts']
assert 'Build completed successfully' in bt and not re.search(r'(?m)^error:',bt)
for n in modules:assert re.search(r'Built «JNT-2024»\.'+re.escape(Path(n).stem)+r' \(',bt),n
assert re.search(r'Built «JNT-2024» \(',bt)
for n in ['Export','AllAxioms','Statements']:
    assert read(O/f'{n}.result.json')['exit']==0,n
    text=(O/f'{n}.log').read_text(encoding='utf-8')
    assert not re.search(r'(?m)^error:|sorryAx|Lean\.ofReduceBool',text),n
E={e['name']:e for e in read(O/'environment.json')}
assert {e['module'].split('.')[-1] for e in E.values()}=={Path(n).stem for n in modules}
assert all(set(e['axioms'])<={'propext','Classical.choice','Quot.sound'} for e in E.values())
assert not set(inventory['forbiddenDeclarations'])&E.keys()
assert not any('Ljunggren' in n or 'polynomial_exclusion' in n for n in E)
axiomlog=(O/'AllAxioms.log').read_text(encoding='utf-8')
expected=set(re.findall(r'^#print axioms (.+)$',(A/'AllAxioms.lean').read_text(encoding='utf-8'),re.M))
actual={n:[x.strip() for x in xs.split(',') if x.strip()] for n,xs in re.findall(
    r"^'(.+)' (?:depends on axioms: \[([^\]]*)\]|does not depend on any axioms)",axiomlog,re.M)}
assert set(actual)==expected,(expected-set(actual),set(actual)-expected)
assert all(set(actual[n])==set(E[n]['axioms']) for n in actual)
assert set(inventory['principal'])<=expected
assert {n for n,e in E.items() if e['theorem'] and e['range'] is not None and not n.startswith('_private.')}<=expected
def closure(root):
    seen=set();todo=[root]
    while todo:
        n=todo.pop()
        if n in seen:continue
        seen.add(n);todo.extend(d for d in E[n]['deps'] if d in E and d not in seen)
    return seen
assert set(inventory['roots'])<=E.keys()
closures={n:closure(n) for n in inventory['roots']}
needed=set().union(*closures.values())
for n in inventory['elaborationSupport']:needed.update(closure(n))
groups={};owners={}
for m in {e['module'] for e in E.values()}:
    ranges=sorted({tuple(e['range']) for e in E.values() if e['module']==m and e['range']},key=lambda r:(r[0],r[1],-r[2],-r[3]))
    outer=[]
    for r in ranges:
        if not any((q[0],q[1])<=(r[0],r[1]) and (r[2],r[3])<=(q[2],q[3]) for q in outer):outer.append(r)
    groups[m]=outer
    for n,e in E.items():
        if e['module']!=m or not e['range']:continue
        r=e['range'];hits=[(m,i) for i,q in enumerate(outer) if (q[0],q[1])<=(r[0],r[1]) and (r[2],r[3])<=(q[2],q[3])]
        assert len(hits)==1,(n,hits)
        owners[n]=hits[0]
for n in E:
    if n in owners:continue
    for candidate in [n,re.sub(r'^_private\..*?\.\d+\.','',n)]:
        while '.' in candidate:
            candidate=candidate.rsplit('.',1)[0]
            if candidate in owners:owners[n]=owners[candidate];break
        if n in owners:break
usedGroups={owners[n] for n in needed if n in owners}
allGroups={(m,i) for m,rs in groups.items() for i in range(len(rs))}
orphans=allGroups-usedGroups
assert not orphans,('Source declarations with no recorded purpose',[(m,groups[m][i]) for m,i in sorted(orphans)])
for n in inventory['mainRoots']:
    assert set(inventory['requiredMainDependencies'])<=closures[n],(n,set(inventory['requiredMainDependencies'])-closures[n])
    assert not any('Lemma23aFiniteMaxima' in d for d in closures[n]),n
for n in inventory['mainRoots'][2:]:assert '«JNT-2024».theorem14_revised' in closures[n],n
C=read(R/'reports/correspondence.json')
refs={d['qualified'] for e in C['entries'] for d in e['lean']}
assert refs<=E.keys()
checked=set(re.findall(r'^#check (.+)$',(A/'Statements.lean').read_text(encoding='utf-8'),re.M))
assert refs<=checked,refs-checked
for e in C['entries']:
    for d in e['lean']:
        assert E[d['qualified']]['range'][0]==d['line'],d['qualified']
for s in identity['manuscript']:assert sha(R/s['file'])==s['sha256'],s['file']
tex=next(R/s['file'] for s in identity['manuscript'] if s['file'].endswith('.tex'))
lines=tex.read_text(encoding='utf-8').splitlines()
for s in C['statements']:
    assert s['status']!='UNMATCHED'
    body='\n'.join(lines[s['texFirstLine']-1:s['texLastLine']])
    assert hashlib.sha256(body.encode()).hexdigest()==s['statementSha256'],s['number']
    for ref in s['refs']:
        m,n=ref.split(':',1)
        hit=[k for k,e in E.items() if e['module'].split('.')[-1]==m and k.endswith('.'+n)]
        assert len(hit)==1 and hit[0] in expected,ref
manifest=read(R/'lake-manifest.json')
for f in ['dependency-pins.json','dependency-pins-after-build.json']:
    pins=read(O/f)
    assert {p['name']:p['rev'] for p in pins}=={p['name']:p['rev'] for p in manifest['packages']}
    assert all(p['trackedSourceClean'] for p in pins)
result=dict(releaseId=identity['releaseId'],status='passed',manuscriptVersion='2026-11-06d',
    cleanBuildJobs=int(re.findall(r'Build completed successfully \((\d+) jobs\)',bt)[-1]),
    projectModulesCleanlyRebuilt=len(modules)+1,cleanBuildSeconds=build['seconds'],
    compiledDeclarationsAudited=len(E),explicitPrintAxioms=len(expected),principalDeclarations=len(inventory['principal']),
    standardAxiomsOnly=True,proofClosures=len(closures),correspondenceReferences=len(refs),
    numberedStatements=len(C['statements']),assertionRecords=len(C['entries']),
    requiredMainInputs=inventory['requiredMainInputs'],section6UsesCurrentTheorem=True,
    forbiddenDeclarationsAbsent=True,scopeExclusions=[e['id'] for e in C['entries'] if e['status']=='pending'],
    retainedSourceCommands=len(allGroups),allRetainedCommandsAccountedFor=True,
    pinnedPackages=len(manifest['packages']),cleanBuildLogSha256=sha(O/'clean-build.log'))
if args.write:
    (O/'verification.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    (O/'proof-closures.json').write_text(json.dumps({n:sorted(v) for n,v in closures.items()},ensure_ascii=False)+'\n',encoding='utf-8')
    relevance=[dict(module=m,range=groups[m][i],names=sorted(n for n,o in owners.items() if o==(m,i) and n in needed),
                    roots=sorted(n for n,o in owners.items() if o==(m,i) and n in inventory['roots'])) for m,i in sorted(allGroups)]
    (O/'source-relevance.json').write_text(json.dumps(relevance,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2,ensure_ascii=False))
