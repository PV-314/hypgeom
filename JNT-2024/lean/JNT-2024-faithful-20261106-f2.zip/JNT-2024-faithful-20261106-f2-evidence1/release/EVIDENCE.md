# Reproducible-release evidence checklist

Package identifier: **JNT-2024-faithful-20261106-f2-evidence1**.
Audited proof/build identifier: **JNT-2024-faithful-20261106-f2**.
Reference manuscript: **2026-11-06d**.

This is an evidence-packaging revision of f2. All Lean sources, build
configuration, manuscript files, and existing build/audit evidence are unchanged.
The audited proof identifier is deliberately retained in the original reports.
[package-identity.json](package-identity.json) identifies this ZIP revision.

## Required contents

| Requirement | Included evidence |
|---|---|
| All Lean source files and directory structure | `JNT-2024/`, `JNT-2024.lean`, and the four audit drivers in `release/`: 218 project source files plus 4 audit drivers. |
| Pinned configuration | [lean-toolchain](../lean-toolchain), [lakefile.toml](../lakefile.toml), [lake-manifest.json](../lake-manifest.json); [toolchain version](toolchain.txt) and package pins [before](dependency-pins.json) and [after](dependency-pins-after-build.json). |
| Full clean build | [clean-build.log](clean-build.log) and [command, exit status and timing](clean-build.result.json): 3388 jobs, 218 project modules, 2184.59 seconds, exit 0. |
| Principal-theorem axiom audit | [AllAxioms.lean](AllAxioms.lean), [full output](AllAxioms.log), [run result](AllAxioms.result.json), and [principal inventory](audit-inventory.json): 1359 explicit checks including all 45 principal declarations. |
| Full compiled-declaration axiom audit | [Export.log](Export.log), [run result](Export.result.json), and [environment.json](environment.json): all 3101 project declarations, including generated/private ones; only propext, Classical.choice and Quot.sound. |
| Statements, hypotheses and dependencies | [Statements.log](Statements.log), [dependency closures](proof-closures.json), [proof-use export](ProofUsage.log), [92 route checks](proof-route-checks.json), and [proof-use verification](proof-usage-verification.json). |
| Theorem/lemma correspondence and status | [CORRESPONDENCE.md](../reports/CORRESPONDENCE.md) and [machine-readable correspondence](../reports/correspondence.json): all 27 numbered statements, plus 282 assertion/proof-step records, with approved exclusions explicit. |
| Corrections, hypotheses, alternative proofs and changes | [CORRECTIONS.md](../reports/CORRECTIONS.md), [SCOPE.md](../reports/SCOPE.md), [CALCULATIONS.md](../reports/CALCULATIONS.md), [FAITHFULNESS.md](../reports/FAITHFULNESS.md), and [REMOVALS.md](../reports/REMOVALS.md). Unused alternative proof code remains in preserved earlier releases, not this faithful-only ZIP. |
| Release verification and identity | [REPORT.md](REPORT.md), [verification.json](verification.json), [proof identity](identity.json), and [package identity](package-identity.json). |
| Archive/extraction evidence | The previously external [f2 archive-verification record](evidence/f2-archive-verification.json), plus the newly captured [extraction-verification record](evidence/extraction-verification.json) and the verifier logs identified there. |
| Integrity and independent reproduction | [MANIFEST.sha256](MANIFEST.sha256), [source hashes](source-sha256.json), [evidence provenance](evidence/provenance.json), and [reproduction instructions](README.md). |

## What was actually run

1. **Fresh clean build and Lean audits:** f2's final, pruned source tree was
   built with no prior project build artifacts. Pinned dependency caches were
   shared. The complete logs and verification reports are inside this ZIP;
   they are not merely checkpoint logs.
2. **Archive extraction verification:** f2's ZIP passed CRC, fresh-extraction
   integrity and saved-evidence checks. That record was previously outside
   the ZIP and is now included, explicitly identified as evidence for f2.
3. **This packaging revision:** the existing proof evidence is preserved,
   saved-evidence verifiers are rerun on a fresh extraction, and their outputs
   and provenance are included. No additional Lean compilation is claimed.

A second clean build starting from the extracted final f2 ZIP was **not**
performed. The user expressly chose to package the existing evidence and
extraction verification. Consequently there are no additional extracted-build
logs to incorporate. The quoted description of fresh build logs being outside
the ZIP does not apply to f2: its fresh build and axiom logs were already inside.

The main theorem remains conditional on `DenominatorEstimate4`,
`AkhtariTheorem11` and `Section46Magma`. CALC-001 remains a separately recorded
finite-maxima input, not a main-theorem premise. Approved proof choices and
omissions are unchanged. No unrestricted Magma run is claimed.

This revision requires no other release to build or audit. Historical archive
names and hashes identify provenance, not external build dependencies.
The final ZIP's own SHA-256 is supplied in its companion checksum file.
