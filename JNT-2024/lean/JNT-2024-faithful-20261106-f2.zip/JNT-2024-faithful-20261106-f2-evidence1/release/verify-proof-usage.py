"""Check saved or freshly exported proof usage and retained source text."""
from pathlib import Path
import argparse,json,hashlib
R=Path(__file__).resolve().parent.parent;A=R/'release'
p=argparse.ArgumentParser();p.add_argument('--audit-dir');p.add_argument('--write',action='store_true');args=p.parse_args()
O=Path(args.audit_dir).resolve() if args.audit_dir else A
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
E={e['name']:e for e in read(O/'proof-details.json')}
compiled={e['name']:e for e in read(O/'environment.json')}
I=read(A/'audit-inventory.json');S=read(A/'source-selection.json');C=read(R/'reports/correspondence.json')
assert set(E)==set(compiled),'Proof export must cover the entire compiled project.'
assert read(O/'ProofUsage.result.json')['exit']==0
assert not set(I['forbiddenDeclarations'])&E.keys()
assert not set(S['removedDeclarations'])&E.keys()
assert not set(S['removedModules'])&{e['module'] for e in E.values()}
def resolve(n):
    if n in E:return n
    hits=[k for k in E if k.endswith('.'+n) and not k.startswith('_private.')]
    assert len(hits)==1,(n,hits)
    return hits[0]
def closure(n):
    seen=set();todo=[n]
    while todo:
        k=todo.pop()
        if k in seen or k not in E:continue
        seen.add(k);todo.extend(E[k]['valueDeps'])
    return seen
closures={n:closure(n) for n in I['roots']}
routes=[]
for root,deps in read(A/'proof-route-requirements.json').items():
    n=resolve(root);cl=closures.get(n) or closure(n)
    for d in deps:
        d=resolve(d);routes.append(dict(root=n,required=d,inValueClosure=d in cl))
assert all(x['inValueClosure'] for x in routes),[x for x in routes if not x['inValueClosure']]
unused=[dict(theorem=n,parameter=p) for n,e in E.items() for p in e['externalParameters'] if not p['occursInBody']]
assert not unused,unused
inputs={resolve(n) for n in ['DenominatorEstimate4','AkhtariTheorem11','Section46Magma']}
maxima=resolve('Lemma23aFiniteMaxima');main=[]
for n in I['mainRoots']:
    cl=closures[n];ps=E[n]['externalParameters']
    assert len(ps)==3,(n,ps)
    parameterInputs={d for p in ps for d in p['typeConstants'] if d in inputs}
    assert parameterInputs==inputs and all(p['occursInBody'] for p in ps),(n,ps)
    assert inputs<=cl and maxima not in cl
    assert set(I['requiredMainDependencies'])<=cl
    main.append(dict(name=n,externalParameters=ps,allThreeApprovedInputsUsed=True,
                     finiteMaximaInputPresent=False,removedDeclarationsPresent=[]))
for n in I['mainRoots'][2:]:assert resolve('theorem14_revised') in closures[n]
refs={d['qualified'] for e in C['entries'] for d in e['lean']}
assert refs<=E.keys() and not refs&set(S['removedDeclarations'])
assert set(S['replacements'].values())<=refs
for record in S['retainedDeclarationText']:
    file=R/'JNT-2024'/(record['module'].split('.')[-1]+'.lean')
    lines=file.read_text(encoding='utf-8').splitlines(keepends=True)
    first,_,last,_=record['range']
    raw=''.join(lines[first-1:last])
    assert hashlib.sha256(raw.encode()).hexdigest()==record['sha256'],record
    assert set(record['names'])<=E.keys(),record
assert len(S['retainedDeclarationText'])==S['retainedCommands']
result=dict(releaseId=read(A/'identity.json')['releaseId'],status='passed',
    compiledDeclarations=len(E),auditedRoots=len(closures),proofRouteChecks=len(routes),
    allRouteChecksPassed=True,removedCompiledDeclarations=len(S['removedDeclarations']),
    removedDeclarationsAbsent=True,retainedSourceCommands=S['retainedCommands'],
    retainedDeclarationTextUnchanged=True,correspondenceReferences=len(refs),
    externalParameterOccurrences=sum(len(e['externalParameters']) for e in E.values()),
    unusedExternalParameters=unused,mainProofs=main,
    limitation='Value dependencies include binder types; external-variable occurrence and source application review supplement them. These checks do not mechanically establish manuscript faithfulness.')
if args.write:
    def save(name,data):(O/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    save('proof-usage-verification.json',result);save('proof-route-checks.json',routes)
    save('root-proof-audit.json',[dict(name=n,valueClosure=sorted(cl),externalParameters=E[n]['externalParameters']) for n,cl in closures.items()])
print(json.dumps({k:v for k,v in result.items() if k!='mainProofs'},ensure_ascii=False,indent=2))
