# Verified release

Identifier: **JNT-2024-faithful-20261106-f2**. Manuscript: **2026-11-06d**.

- Removed six obsolete proof targets and twelve unused helper declarations; their 35 compiled names are absent.
- Fresh `lake build`: 3388 jobs; all 218 project modules rebuilt, in 2184.59 seconds with four Lean workers.
- Complete compiled-declaration axiom audit: 3101 declarations.
- Explicit `#print axioms`: 1359 declarations, including all 45 principal declarations.
- Only `propext`, `Classical.choice` and `Quot.sound`; no `sorryAx`, native-reduction axiom or custom axiom.
- 639 dependency closures; 637 correspondence references; 282 assertion records and all 27 numbered statements accounted for, with approved exclusions explicit.
- All 1568 retained source declarations have a recorded correspondence, dependency or elaboration purpose. Their full source text is unchanged from f1-doc1.
- 92 published-proof route checks passed. All 58 audited external-parameter occurrences are used in their proof bodies.
- Theorem 1.4 and both Section 6 upper-bound applications use the revised Section 5 proof and all three approved inputs.
- All 9 package revisions match the manifest before and after the build; tracked package sources are clean.

Fresh Lean audit runtimes (seconds): environment/axiom export 367.44; explicit axiom prints 56.30; statements 55.34; proof-usage export 54.61.

The main theorem remains conditional on `DenominatorEstimate4`,
`AkhtariTheorem11` and `Section46Magma`. The separate exact-maxima calculation
input is not a premise of the main theorem. Global completeness of the 63
quartics is still an approved input; no historical transcript or fresh
unrestricted Magma execution is claimed.

The approved premises, calculations, proof choices and omissions are recorded
in [SCOPE.md](../reports/SCOPE.md). A successful axiom audit does not discharge
named mathematical hypotheses or establish manuscript correspondence by itself.
The proof-use audit separates type and value references and checks parameter
occurrence; these checks supplement the recorded source and manuscript review.

The clean build has 6 tactic-style warnings, listed in
`build-warnings.json`. No retained mathematical proof was changed for f2.
The exact removals and replacements are in [REMOVALS.md](../reports/REMOVALS.md).

See [README.md](README.md) for independent reproduction,
[CORRESPONDENCE.md](../reports/CORRESPONDENCE.md) for coverage and
[CORRECTIONS.md](../reports/CORRECTIONS.md) for corrections and approved proof choices.
All 9 previous release ZIPs were checked unchanged. Their sources
and build artifacts are not needed to reconstruct this release.
