Evidence-packaging revision: **JNT-2024-faithful-20261106-f2-evidence1**.
Audited proof release: **JNT-2024-faithful-20261106-f2**.
See the [complete evidence checklist](release/EVIDENCE.md) for included logs,
reports, provenance and the precise scope of the extraction verification.

# Faithful formalisation — manuscript 2026-11-06d

This is a standalone source release of the formalisation following the supplied
2026-11-06d manuscript, including its revised Section 5 and the applications in
Section 6. No other release ZIP, checkout, build artifact or report is required.

The main declarations are `«JNT-2024».theorem14_revised` and
`«JNT-2024».theorem14_paper_revised`. Their three explicit premises are
`Hypergeometric.DenominatorEstimate4`, `ExternalResults.AkhtariTheorem11` and
`Calculations.Section46Magma`. The Section 6 upper-bound applications use this
same theorem and these same premises. See [dependencies and scope](reports/SCOPE.md).

The word faithful does not assert that external results, conjectures, or all
incidental remarks have been proved. The agreed specializations, omitted
remarks and approved proof choices are listed individually. In particular,
the approved certified finite argument for Lemma 3.13 is retained.

Contents:

- `JNT-2024/` and `JNT-2024.lean`: proof sources and required shared helpers.
- `lean-toolchain`, `lakefile.toml`, `lake-manifest.json`: pinned configuration.
- `manuscript/`: the exact 2026-11-06d PDF and TeX.
- `reports/`: correspondence, corrections, scope and proof review.
- `audit/`: calculation evidence and its reproduction scripts.
- `release/`: release identity, clean-build log, complete axiom and dependency
  audits, integrity manifest, and reproduction/verification scripts.

Reproduction instructions are in `release/README.md`. Lean 4.35.0 and the
manifest's exact dependency revisions are required. Package source caches and
compiled binaries are deliberately excluded from the ZIP. Reproduction fetches
only the pinned dependencies; it does not fetch another JNT-2024 release.

Release identifier: **JNT-2024-faithful-20261106-f2**.
The six obsolete additional proof targets and their twelve unused helpers
have been removed. The superseded Section 5 classifications remain absent.
Earlier releases, including their alternative proofs, are preserved separately.
See [the removal record](reports/REMOVALS.md).
