module

public import «JNT-2024».Lemma313
public import «JNT-2024».Lemma313AnalyticPublished
public import «JNT-2024».NormalizerFormula
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- Lemma 3.13 with the printed analytic reductions and the retained certified
calculation for the remaining ranges, as explicitly agreed on 3 November 2026.
The PARI search is not an assumed input, and no calculation is repeated here. -/
theorem lemma313_accepted (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hn : P.normAlpha < 0) (hd : 112 ≤ P.d) {k X Y ν : ℤ}
    (hx : P.x h.pell k=X) (hy : P.y h.pell k=Y) (hybig : 1 < Y)
    (hν : ν=1 ∨ ν= -1) :
    let M := Approximation.normalizerProduct (squarefreePart P.normAlpha) (2*X)
      (2*ν*squareFactor P.normAlpha)
    (113/100 : ℝ) < (1832/10000 : ℝ)*M*Real.sqrt P.d*(Y:ℝ)/|(P.normAlpha:ℝ)| ∧
      (190:ℝ) < (2112/100 : ℝ)*Real.sqrt P.d*(Y:ℝ)/M := by
  constructor
  · by_cases hd155 : 155 ≤ P.d
    · exact P.lemma313_first_large_d h hb hn hd155 hx hy hybig hν
    · simpa only [hy,Rat.cast_intCast] using (P.lemma313 h hb hn hd hx hy hybig hν).1
  · by_cases hd109000 : 109000 ≤ P.d
    · exact P.lemma313_second_large_d h hb hn hd109000 hx hy hybig hν
    · simpa only [hy,Rat.cast_intCast] using (P.lemma313 h hb hn hd hx hy hybig hν).2

end «JNT-2024».Parameters
