module

public import «JNT-2024».Lemma54
public import «JNT-2024».Lemma54CasesPublished
public import «JNT-2024».Monotonicity
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.Deriv.MeanValue
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- The odd-trace contradiction in the opening paragraph of Lemma 5.4. -/
theorem lemma54_trace_even (P : Parameters) (hp : P.Pell) (hb : P.b=1)
    (hodd : Odd (-P.normAlpha)) (hs : P.AdjacentSquare hp) : P.t % 2=0 := by
  by_contra he
  have ht : P.t % 2=1 := by omega
  have hn : Odd (P.d-P.a^2) := by simpa [normAlpha,hb,sub_eq_add_neg] using hodd
  have hnval := ZMod.val_intCast (n := 4) (P.d-P.a^2)
  push_cast at hnval
  have hnmod := Int.odd_iff.mp hn
  have htv := ZMod.val_intCast (n := 4) P.t
  have hp4 : (P.t:ZMod 4)^2-P.d*(P.u:ZMod 4)^2=0 := by
    rcases hp with hp | hp <;>
      have hh := congrArg (fun z:ℤ => (z:ZMod 4)) hp <;>
      norm_num at hh ⊢ <;> exact hh
  have hc := Section5.lemma54_odd_trace_cases (P.a:ZMod 4) P.d P.t P.u
    (by omega) (by omega) hp4
  rcases hs with ⟨v,hv⟩ | ⟨v,hv⟩
  · have hi : P.t^2+P.d*P.u^2+2*P.a*P.t*P.u=4*v^2 := by
      have hh : (P.t:ℚ)^2+P.d*(P.u:ℚ)^2+2*P.a*P.t*P.u=4*(v:ℚ)^2 := by
        rw [P.y_one,hb] at hv
        norm_num only [Int.cast_one,one_pow,one_mul] at hv
        linarith
      exact_mod_cast hh
    have hh := congrArg (fun z:ℤ => (z:ZMod 4)) hi
    norm_num at hh
    rw [show (4:ZMod 4)=0 by decide,zero_mul] at hh
    have hf : (2:ZMod 4)=0 := hc.2.2.2.1.symm.trans hh
    exact (by decide : (2:ZMod 4) ≠ 0) hf
  · have hi : P.t^2+P.d*P.u^2-2*P.a*P.t*P.u=4*v^2 := by
      have hh : (P.t:ℚ)^2+P.d*(P.u:ℚ)^2-2*P.a*P.t*P.u=4*(v:ℚ)^2 := by
        rw [P.y_neg_one,hb] at hv
        norm_num only [Int.cast_one,one_pow,one_mul] at hv
        linarith
      exact_mod_cast hh
    have hh := congrArg (fun z:ℤ => (z:ZMod 4)) hi
    norm_num at hh
    rw [show (4:ZMod 4)=0 by decide,zero_mul] at hh
    have hf : (2:ZMod 4)=0 := hc.2.2.2.2.symm.trans hh
    exact (by decide : (2:ZMod 4) ≠ 0) hf

/-- Lemma 5.4 with its printed hypotheses and each printed parity case. -/
theorem lemma54_published (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (_hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha)) (hodd : Odd (-P.normAlpha))
    (_hK : P.IsNegativeCutoff h.pell (-1)) (hs : P.AdjacentSquare h.pell) :
    (P.t^2-P.d*P.u^2=4 → P.t % 4=2 ∧ P.u % 4=0) ∧
    (P.t^2-P.d*P.u^2= -4 → P.u % 4=2) := by
  have ht := P.lemma54_trace_even h.pell hb hodd hs
  have htv := ZMod.val_intCast (n := 16) P.t
  obtain ⟨n,hn⟩ := hNs
  have hn2 : -P.normAlpha=n^2 := by simpa only [pow_two] using hn
  have hd : P.d-P.a^2=n^2 := by simpa [normAlpha,hb,sub_eq_add_neg] using hn2
  have hns := Section5.odd_square_residue16 (by rwa [← hn2] : Odd (n^2))
  have hdm := congrArg (fun z:ℤ => (z:ZMod 16)) hd
  push_cast at hdm
  have hN : (P.d:ZMod 16)-(P.a:ZMod 16)^2=1 ∨
      (P.d:ZMod 16)-(P.a:ZMod 16)^2=9 := by rwa [hdm]
  have hc := Section5.lemma54_cases_assembled (P.a:ZMod 16) P.d P.t P.u hN (by omega)
  constructor
  · intro hp
    have hh := congrArg (fun z:ℤ => (z:ZMod 16)) hp
    push_cast at hh
    exact ⟨Section5.int_mod_four_of_zmod_val (hc.1 hh).1,
      Section5.int_mod_four_of_zmod_val (hc.1 hh).2⟩
  · intro hp
    have hh := congrArg (fun z:ℤ => (z:ZMod 16)) hp
    push_cast at hh
    exact Section5.int_mod_four_of_zmod_val (hc.2 hh)


end «JNT-2024».Parameters

