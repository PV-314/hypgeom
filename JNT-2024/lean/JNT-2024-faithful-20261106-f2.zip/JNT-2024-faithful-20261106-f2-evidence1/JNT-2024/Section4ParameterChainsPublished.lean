module

public import «JNT-2024».Section4Prerequisites
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

/-- The literal intermediate fractions in (4.5)-(4.7), including 10.74
and sqrt(0.9375), before collecting the final constants. -/
theorem approximation_parameter_chains {N M L x : ℝ} (hN : 0 < N) (hM : 0 < M)
    (hL : 0 < L) (hx : (15/16 : ℝ)*L^2 < x^2) (hxl : |x| < L) :
    let e := Real.exp (42/25)
    let s := Real.sqrt (15/16 : ℝ)
    M*(|x|+L)/(2*e*N) > M*(|x|+L)/((1074/100 : ℝ)*N) ∧
    M*(|x|+L)/((1074/100 : ℝ)*N) > M*(1+s)*L/((1074/100 : ℝ)*N) ∧
    M*(1+s)*L/((1074/100 : ℝ)*N) > (1832/10000 : ℝ)*M*L/N ∧
    2*e*(|x|+L)/M > 2*e*(1+s)*L/M ∧
    2*e*(1+s)*L/M > (2112/100 : ℝ)*L/M ∧
    2*e*(|x|+L)/M < 4*e*L/M ∧
    4*e*L/M < (2147/100 : ℝ)*L/M := by
  let e := Real.exp (42/25)
  let s := Real.sqrt (15/16 : ℝ)
  have he : 0 < e := Real.exp_pos _
  have hs : 0 ≤ s := Real.sqrt_nonneg _
  have hs2 : s^2=(15/16 : ℝ) := Real.sq_sqrt (by norm_num)
  have hsl : (9682/10000 : ℝ)<s := by nlinarith
  have hx' : s*L < |x| := by
    apply (sq_lt_sq₀ (by positivity) (abs_nonneg x)).mp
    rw [mul_pow,hs2,sq_abs]
    exact hx
  have hb := exp_168_bounds
  change (107311/20000 : ℝ)<e ∧ e<10735/2000 at hb
  have hden : 2*e*N < (1074/100 : ℝ)*N := by nlinarith only [mul_lt_mul_of_pos_right hb.2 hN,hN]
  have hnum : (1832/10000 : ℝ)*(1074/100)<1+s := by linarith
  have hqnum : (2112/100 : ℝ)<2*e*(1+s) := by
    have hh := mul_lt_mul_of_pos_right hsl he
    nlinarith only [hb.1,hh]
  refine ⟨?_,?_,?_,?_,?_,?_,?_⟩
  · exact div_lt_div_of_pos_left (by positivity) (mul_pos (by positivity) hN) hden
  · apply (div_lt_div_iff_of_pos_right (by positivity : 0<(1074/100 : ℝ)*N)).mpr
    have hh := mul_lt_mul_of_pos_left hx' hM
    nlinarith only [hh]
  · apply (div_lt_div_iff₀ hN (by positivity : 0<(1074/100 : ℝ)*N)).mpr
    have hh := mul_lt_mul_of_pos_right hnum (by positivity : 0<M*L*N)
    nlinarith only [hh]
  · apply (div_lt_div_iff_of_pos_right hM).mpr
    have hh := mul_lt_mul_of_pos_left hx' (by positivity : 0<2*e)
    nlinarith only [hh]
  · exact (div_lt_div_iff_of_pos_right hM).mpr (mul_lt_mul_of_pos_right hqnum hL)
  · apply (div_lt_div_iff_of_pos_right hM).mpr
    have hh := mul_lt_mul_of_pos_left hxl (by positivity : 0<2*e)
    nlinarith only [hh]
  · apply (div_lt_div_iff_of_pos_right hM).mpr
    have hh := mul_lt_mul_of_pos_right hb.2 hL
    nlinarith only [hh,hL]

/-- Final parameter bounds obtained through every displayed intermediate
comparison in (4.5)-(4.7). -/
theorem approximation_parameter_bounds_printed {N M L x : ℝ}
    (hN : 0 < N) (hM : 0 < M) (hL : 0 < L)
    (hx : (15/16 : ℝ)*L^2 < x^2) (hxl : |x| < L) :
    (1832/10000 : ℝ)*M*L/N < M*(|x|+L)/(2*Real.exp (42/25)*N) ∧
    (2112/100 : ℝ)*L/M < 2*Real.exp (42/25)*(|x|+L)/M ∧
    2*Real.exp (42/25)*(|x|+L)/M < (2147/100 : ℝ)*L/M := by
  have h := approximation_parameter_chains hN hM hL hx hxl
  exact ⟨h.2.2.1.trans (h.2.1.trans h.1),h.2.2.2.2.1.trans h.2.2.2.1,
    h.2.2.2.2.2.1.trans h.2.2.2.2.2.2⟩

end «JNT-2024».Section4
