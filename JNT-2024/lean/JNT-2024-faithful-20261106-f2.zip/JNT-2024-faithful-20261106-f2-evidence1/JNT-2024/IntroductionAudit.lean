module

public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».PaperBridge
public import «JNT-2024».Positivity
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.RingTheory.Trace.Basic
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section
namespace «JNT-2024».Parameters

/-- The coefficient in (1.3) is the actual algebra trace of epsilon squared. -/
theorem recurrence_coefficient_trace (P : Parameters) :
    Algebra.trace ℚ P.Algebra (P.epsilon ^ 2) =
      ((P.t : ℚ)^2 + P.d * (P.u : ℚ)^2)/2 := by
  rw [← P.step_eq_epsilon_sq,
    Algebra.trace_eq_matrix_trace (QuadraticAlgebra.basis (P.d : ℚ) 0)]
  simp [Matrix.trace, Fin.sum_univ_two, Algebra.leftMulMatrix_eq_repr_mul, step,
    QuadraticAlgebra.re_one, QuadraticAlgebra.im_one]
  ring

/-- The literal field Q(sqrt(d)), not just the coordinate algebra. -/
theorem recurrence_coefficient_realField_trace (P : Parameters)
    [Fact (¬IsSquare P.d)] (hd : 0 < P.d) :
    Algebra.trace ℚ P.RealField (P.epsilonRealField ^ 2) =
      ((P.t : ℚ)^2 + P.d * (P.u : ℚ)^2)/2 := by
  rw [← P.realFieldEquiv_epsilon hd, ← map_pow,
    Algebra.trace_eq_of_algEquiv, P.recurrence_coefficient_trace]

def smallestSquareCounterexample : Parameters := ⟨120,7,6,10,4⟩

theorem smallestSquareCounterexample_admissible : smallestSquareCounterexample.Admissible := by
  refine ⟨by norm_num [smallestSquareCounterexample], by norm_num [smallestSquareCounterexample],
    by norm_num [smallestSquareCounterexample], by norm_num [smallestSquareCounterexample],
    by norm_num [smallestSquareCounterexample], ?_, ?_⟩
  · change ¬IsSquare (6:ℤ)
    rintro ⟨n,hn⟩
    have hb : -3<n ∧ n<3 := by constructor <;> nlinarith
    obtain ⟨hl,hu⟩ := hb
    interval_cases n <;> norm_num at hn
  · norm_num [Pell,smallestSquareCounterexample]

theorem smallestSquareCounterexample_values :
    smallestSquareCounterexample.normAlpha = -6 ∧
    smallestSquareCounterexample.x smallestSquareCounterexample_admissible.pell (-1) = 0 ∧
    smallestSquareCounterexample.y smallestSquareCounterexample_admissible.pell (-1) = 1 := by
  norm_num [normAlpha, x, y, term, stepUnit, backStep, alpha, smallestSquareCounterexample]

/-- Every integer square in this sequence is at least one, and one is attained. -/
theorem smallestSquareCounterexample_minimum (k : ℤ)
    (hs : IsIntegerSquare (smallestSquareCounterexample.y
      smallestSquareCounterexample_admissible.pell k)) :
    1 ≤ smallestSquareCounterexample.y smallestSquareCounterexample_admissible.pell k := by
  have hp := smallestSquareCounterexample.y_pos smallestSquareCounterexample_admissible
    (by norm_num [normAlpha,smallestSquareCounterexample]) k
  obtain ⟨n,hn⟩ := hs
  rw [hn] at hp ⊢
  have hn0 : n ≠ 0 := by intro he; simp [he] at hp
  have hsq : (1:ℤ) ≤ n^2 := by have := sq_pos_of_ne_zero hn0; omega
  exact_mod_cast hsq

/-- At the least square a new starting term has real coordinate zero;
it cannot satisfy the manuscript's strict positivity requirement on a. -/
theorem smallestSquareCounterexample_no_positive_start {a b : ℤ}
    (ha : 0<a) (hb : 0<b) (hsmall : b^2 ≤ 1)
    (hn : a^2-b^4*6 = -6) : False := by
  have hb1 : b=1 := by nlinarith
  subst b
  norm_num at hn
  nlinarith

/-- The example satisfies the literal ring-of-integers hypotheses as well. -/
theorem smallestSquareCounterexample_paper : smallestSquareCounterexample.PaperAdmissible :=
  smallestSquareCounterexample_admissible.toPaper

/-- Every occurrence of its least square has real coordinate zero. -/
theorem smallestSquareCounterexample_at_one (k : ℤ)
    (hy : smallestSquareCounterexample.y smallestSquareCounterexample_admissible.pell k = 1) :
    smallestSquareCounterexample.x smallestSquareCounterexample_admissible.pell k = 0 := by
  have hn := smallestSquareCounterexample.norm_identity smallestSquareCounterexample_admissible.pell k
  rw [hy,smallestSquareCounterexample_values.1] at hn
  norm_num [smallestSquareCounterexample] at hn
  simpa [smallestSquareCounterexample] using hn

/-- The new 06a paragraph: in the negative-norm b=1 setting of Theorem 1.4,
one is already an attained least integer square, and the starting a is positive. -/
theorem starting_square_is_least (P : Parameters) (h : P.Admissible)
    (hb : P.b=1) (hn : P.normAlpha<0) :
    P.y h.pell 0=1 ∧ 0<P.x h.pell 0 ∧
      ∀ k : ℤ, IsIntegerSquare (P.y h.pell k) → 1 ≤ P.y h.pell k := by
  refine ⟨by simp [hb], by simpa using (show (0:ℚ)<P.a by exact_mod_cast h.a_pos), ?_⟩
  intro k hs
  have hp := P.y_pos h hn k
  obtain ⟨n,he⟩ := hs
  rw [he] at hp ⊢
  have hn0 : n≠0 := by intro hz; simp [hz] at hp
  have hsq : (1:ℤ)≤n^2 := by have := sq_pos_of_ne_zero hn0; omega
  exact_mod_cast hsq

/-- The same assertion for every sequence satisfying the literal paper definition. -/
theorem paper_starting_square_is_least (P : Parameters) (h : P.PaperAdmissible)
    (X Y : ℤ → ℚ) (hseq : P.PaperSequence X Y) (hb : P.b=1) (hn : P.normAlpha<0) :
    Y 0=1 ∧ 0<X 0 ∧ ∀ k : ℤ, IsIntegerSquare (Y k) → 1≤Y k := by
  obtain ⟨rfl,rfl⟩ := (P.paper_sequence_iff h X Y).mp hseq
  exact P.starting_square_is_least h.toAdmissible hb hn

end «JNT-2024».Parameters
