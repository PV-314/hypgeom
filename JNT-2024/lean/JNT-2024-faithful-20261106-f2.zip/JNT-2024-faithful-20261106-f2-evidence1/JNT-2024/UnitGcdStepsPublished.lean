module

public import «JNT-2024».Sequence
public import «JNT-2024».UnitGcd
public import «JNT-2024».UnitParityPublished
public import «JNT-2024».UnitPowers
public import «JNT-2024».UnitSequenceIntegrality
public import «JNT-2024».UnitSequencePublished
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

theorem gcd_dvd_gcd_of_inverse {T U d ν X Y A B : ℤ} (hν : ν = 1 ∨ ν = -1)
    (hx : T * X - d * U * Y = ν * A) (hy : U * X - T * Y = -ν * B) :
    Int.gcd X Y ∣ Int.gcd A B := by
  have hX := Int.gcd_dvd_left X Y
  have hY := Int.gcd_dvd_right X Y
  have hA : (Int.gcd X Y : ℤ) ∣ A := by
    have hh := dvd_sub (dvd_mul_of_dvd_right hX T) (dvd_mul_of_dvd_right hY (d * U))
    rw [hx] at hh
    rcases hν with rfl | rfl <;> simpa using hh
  have hB : (Int.gcd X Y : ℤ) ∣ B := by
    have hh := dvd_sub (dvd_mul_of_dvd_right hX U) (dvd_mul_of_dvd_right hY T)
    rw [hy] at hh
    rcases hν with rfl | rfl <;> simpa using hh
  simpa using Int.dvd_gcd hA hB

theorem gcd_dvd_gcd_of_even_inverse {T U d ν X Y A B : ℤ} (hν : ν = 1 ∨ ν = -1)
    (hT : Even T) (hU : Even U)
    (hx : T * X - d * U * Y = 2 * ν * A) (hy : U * X - T * Y = -2 * ν * B) :
    Int.gcd X Y ∣ Int.gcd A B := by
  obtain ⟨t, ht⟩ := hT
  obtain ⟨u, hu⟩ := hU
  apply gcd_dvd_gcd_of_inverse (T := t) (U := u) (d := d) hν
  · rw [ht, hu] at hx
    nlinarith only [hx]
  · rw [ht, hu] at hy
    nlinarith only [hy]

namespace Parameters

/-- The two integer identities (3.33) at any pair of integral consecutive terms. -/
theorem unit_inverse_one_integral (P : Parameters) (hp : P.Pell) (A B : ℤ) (n : ℕ)
    {X Y X₀ Y₀ : ℤ} (hx : P.unitX A B (n + 1) = X) (hy : P.unitY A B (n + 1) = Y)
    (hx₀ : P.unitX A B n = X₀) (hy₀ : P.unitY A B n = Y₀) :
    ∃ ν : ℤ, (ν = 1 ∨ ν = -1) ∧
      P.t * X - P.d * P.u * Y = 2 * ν * X₀ ∧ P.u * X - P.t * Y = -2 * ν * Y₀ := by
  obtain ⟨ν,hνs,hν,_⟩ := P.unit_norm_integer_sign hp
  have hh := P.unit_inverse_one A B n
  rw [hx, hy, hx₀, hy₀, ← hν] at hh
  exact ⟨ν, hνs, by exact_mod_cast hh.2, by exact_mod_cast hh.1⟩

theorem unit_gcd_one_dvd_two (P : Parameters) (hp : P.Pell) (A B : ℤ) (n : ℕ)
    {X Y X₀ Y₀ : ℤ} (hx : P.unitX A B (n + 1) = X) (hy : P.unitY A B (n + 1) = Y)
    (hx₀ : P.unitX A B n = X₀) (hy₀ : P.unitY A B n = Y₀) :
    Int.gcd X Y ∣ 2 * Int.gcd X₀ Y₀ := by
  obtain ⟨ν,hν,hX,hY⟩ := P.unit_inverse_one_integral hp A B n hx hy hx₀ hy₀
  exact gcd_dvd_two_gcd_of_linear hν hX (by linarith only [hY])

/-- Case (i): halving the even coefficients of (3.33) gives one-step gcd descent. -/
theorem unit_gcd_step_one (P : Parameters) (hp : P.Pell) (ht : Even P.t) (hu : Even P.u)
    (A B : ℤ) (n : ℕ) {X Y X₀ Y₀ : ℤ}
    (hx : P.unitX A B (n + 1) = X) (hy : P.unitY A B (n + 1) = Y)
    (hx₀ : P.unitX A B n = X₀) (hy₀ : P.unitY A B n = Y₀) :
    Int.gcd X Y ∣ Int.gcd X₀ Y₀ := by
  obtain ⟨ν,hν,hX,hY⟩ := P.unit_inverse_one_integral hp A B n hx hy hx₀ hy₀
  exact gcd_dvd_gcd_of_even_inverse hν ht hu hX hY

/-- Cases (ii-a,b): halve the even integral coefficients of (3.35). -/
theorem unit_gcd_step_three (P : Parameters) (hp : P.Pell) (ht : Odd P.t) (hu : Odd P.u)
    (A B : ℤ) (n : ℕ) {X Y X₀ Y₀ : ℤ}
    (hx : P.unitX A B (n + 3) = X) (hy : P.unitY A B (n + 3) = Y)
    (hx₀ : P.unitX A B n = X₀) (hy₀ : P.unitY A B n = Y₀) :
    Int.gcd X Y ∣ Int.gcd X₀ Y₀ := by
  obtain ⟨ν,hνs,hν,_⟩ := P.unit_norm_integer_sign hp
  have hc := P.unit_inverse_three_coefficients hp hν
  have he := P.unit_inverse_three_coefficients_even hp hν ht hu
  have hh := P.unit_inverse_three hp A B n
  have hd : P.d * P.u * (3 * (P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) / (4 * P.epsilonNorm ^ 2) =
      (P.d : ℚ) * (P.u * (3 * (P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) / (4 * P.epsilonNorm ^ 2)) := by ring
  rw [hd, hc.1, hc.2, hx, hy, hx₀, hy₀, ← hν] at hh
  apply gcd_dvd_gcd_of_even_inverse (T := P.t * (ν + P.d * P.u ^ 2))
    (U := P.u * (P.t ^ 2 - ν)) (d := P.d) hνs he.2 he.1
  · exact_mod_cast hh.2
  · exact_mod_cast hh.1

/-- Case (iii): halve the even integral coefficients of (3.34). -/
theorem unit_gcd_step_two (P : Parameters) (hp : P.Pell) (ht : Even P.t) (hu : Odd P.u)
    (A B : ℤ) (n : ℕ) {X Y X₀ Y₀ : ℤ}
    (hx : P.unitX A B (n + 2) = X) (hy : P.unitY A B (n + 2) = Y)
    (hx₀ : P.unitX A B n = X₀) (hy₀ : P.unitY A B n = Y₀) :
    Int.gcd X Y ∣ Int.gcd X₀ Y₀ := by
  obtain ⟨ν,hνs,hν,_⟩ := P.unit_norm_integer_sign hp
  have hc := P.unit_inverse_two_coefficients hp hν
  have he := P.unit_inverse_two_coefficients_even hp (ν := ν) ht hu
  have hh := P.unit_inverse_two hp A B n
  have hd : P.d * P.t * P.u / P.epsilonNorm = (P.d : ℚ) * (P.t * P.u / P.epsilonNorm) := by ring
  rw [hd, hc.1, hc.2, hx, hy, hx₀, hy₀, ← hν] at hh
  apply gcd_dvd_gcd_of_even_inverse (T := 2 + P.d * P.u ^ 2 * ν)
    (U := P.t * P.u * ν) (d := P.d) hνs he.2 he.1
  · exact_mod_cast hh.2
  · exact_mod_cast hh.1

end Parameters
end «JNT-2024»
