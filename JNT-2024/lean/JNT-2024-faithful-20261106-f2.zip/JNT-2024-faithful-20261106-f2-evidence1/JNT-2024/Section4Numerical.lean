module

public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

/-- Squaring the published threshold (4.23), without changing its constant. -/
theorem threshold_squared {N d M y : ℝ} (hN : 0 < N) (hd : 0 < d) (hM : 0 < M)
    (hy : 137 * N * Real.sqrt N / (Real.sqrt d * M ^ 2) ≤ y) :
    137 ^ 2 * N ^ 3 ≤ y ^ 2 * d * M ^ 4 := by
  have hdS : 0 < Real.sqrt d := Real.sqrt_pos.mpr hd
  have ht := (div_le_iff₀ (mul_pos hdS (sq_pos_of_pos hM))).mp hy
  have hs := pow_le_pow_left₀ (by positivity : 0 ≤ 137 * N * Real.sqrt N) ht 2
  have hN2 := Real.sq_sqrt hN.le
  have hd2 := Real.sq_sqrt hd.le
  convert hs using 1 <;> ring_nf <;> simp [hN2, hd2] <;> ring


/-- The fourth-power threshold used at the end of Section 4.4. -/
theorem threshold_fourth {N d M y : ℝ} (hN : 0 < N) (hd : 0 < d) (hM : 0 < M)
    (hy : 61 * N * Real.sqrt N / (Real.sqrt d * M ^ 2) < y) :
    61 ^ 4 * N ^ 6 < y ^ 4 * d ^ 2 * M ^ 8 := by
  have ht := (div_lt_iff₀ (mul_pos (Real.sqrt_pos.mpr hd) (sq_pos_of_pos hM))).mp hy
  have hs := pow_lt_pow_left₀ ht (by positivity : 0 ≤ 61 * N * Real.sqrt N) (by decide : 4 ≠ 0)
  have hN4 : Real.sqrt N ^ 4 = N ^ 2 := by rw [show (4 : ℕ) = 2 * 2 by rfl, pow_mul, Real.sq_sqrt hN.le]
  have hd4 : Real.sqrt d ^ 4 = d ^ 2 := by rw [show (4 : ℕ) = 2 * 2 by rfl, pow_mul, Real.sq_sqrt hd.le]
  convert hs using 1 <;> ring_nf <;> simp [hN4, hd4] <;> ring

/-- The contradiction between (4.20) and (4.21), retaining `59.11` and `61`. -/
theorem case44_contradiction {N d M y : ℝ} (hN : 0 < N) (hd : 0 < d) (hM : 0 < M)
    (hy : 61 * N * Real.sqrt N / (Real.sqrt d * M ^ 2) < y)
    {r : ℕ} (hr : 1 < r)
    (h420 : (y ^ 4 * d ^ 2 * M ^ 8 / ((5911 / 100 : ℝ) ^ 4 * N ^ 6)) ^ (2 * r - 1) < 7 / 5) : False := by
  have hs := threshold_fourth hN hd hM hy
  let B : ℝ := y ^ 4 * d ^ 2 * M ^ 8 / ((5911 / 100 : ℝ) ^ 4 * N ^ 6)
  let C : ℝ := (61 / (5911 / 100) : ℝ) ^ 4
  have hCB : C < B := by
    apply (lt_div_iff₀ (mul_pos (by norm_num) (pow_pos hN 6))).mpr
    dsimp [C]
    convert hs using 1; ring
  have hC1 : 1 < C := by norm_num [C]
  have hC3 : (7 / 5 : ℝ) < C ^ 3 := by norm_num [C]
  have hp : C ^ 3 ≤ B ^ (2 * r - 1) :=
    (pow_le_pow_left₀ (by positivity : 0 ≤ C) hCB.le 3).trans
      (pow_le_pow_right₀ (le_trans hC1.le hCB.le) (by omega))
  exact (not_lt_of_ge hp) (h420.trans hC3)

/-- Section 4.3 at `r₀=1`, using the printed rounded upper bound `6.94`. -/
theorem case43_contradiction {N d y z : ℝ} (hN : 0 < N) (hNd : N < d) (hy : 0 < y)
    (hgap : (5732 / 100 : ℝ) * d ^ 2 * y ^ 3 < N ^ 2 * z)
    (hupper : N * z < (694 / 100 : ℝ) * d * y ^ 3) : False := by
  have hd : 0 < d := hN.trans hNd
  have h₁ := mul_lt_mul_of_pos_left hupper hN
  have h₂ := mul_lt_mul_of_pos_right hNd (show 0 < d * y ^ 3 by positivity)
  nlinarith [mul_pos hd (pow_pos hy 3)]


end «JNT-2024».Section4
