module

public import «JNT-2024».Lemma313Accepted
public import «JNT-2024».Lemma313AnalyticPublished
public import «JNT-2024».NormalizerBounds
public import «JNT-2024».NormalizerFormula
public import «JNT-2024».Section2Geometry
public import «JNT-2024».Section4ParameterChainsPublished
public import «JNT-2024».Section4Parameters
public import «JNT-2024».Section4Sequence
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- Section 4.1 uses Lemma 3.13 at d>=112, without the stronger alternative
argument based on the Proposition 4.1 cutoff. -/
theorem section4_parameter_bounds_published (P : Parameters) (h : P.Admissible) (hb : P.b = 1)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha)) {k X Y ν : ℤ}
    (hs : IsIntegerSquare (P.y h.pell k)) (hx : P.x h.pell k = (X : ℚ))
    (hy : P.y h.pell k = (Y : ℚ)) (hν : ν = 1 ∨ ν = -1)
    (hd112 : 112 ≤ P.d) (hybig : 1 < P.y h.pell k) :
    let Z := ν * squareFactor P.normAlpha
    let M := Approximation.normalizerProduct (-1) (2 * X) (2 * Z)
    let L := Real.sqrt (P.d : ℝ) * (Y : ℝ)
    let N := |(P.normAlpha : ℝ)|
    113 / 100 < Section2.E (-1) (2 * X) (2 * Z) ∧
    190 < Section2.Q (-1) (2 * X) (2 * Z) ∧
    (1832 / 10000 : ℝ) * M * L / N < Section2.E (-1) (2 * X) (2 * Z) ∧
    Section2.Q (-1) (2 * X) (2 * Z) < (2147 / 100 : ℝ) * L / M := by
  let Z := ν * squareFactor P.normAlpha
  let M := Approximation.normalizerProduct (-1) (2 * X) (2 * Z)
  let L := Real.sqrt (P.d : ℝ) * (Y : ℝ)
  let N := |(P.normAlpha : ℝ)|
  have hN : 0 < N := (P.section4_norm_range h hb hn).1
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hy1 := hybig
  have hY : (0 : ℝ) < Y := by exact_mod_cast (by rw [← hy]; linarith : (0 : ℚ) < Y)
  have hL : 0 < L := mul_pos (Real.sqrt_pos.mpr hd) hY
  have hS := squarefreePart_eq_neg_one (ne_of_lt hn) hNs
  have hZsq : (Z : ℝ) ^ 2 = N := by
    have hh := squareFactor_sq_mul P.normAlpha
    rw [hS] at hh
    have hhR : (squareFactor P.normAlpha : ℝ) ^ 2 * (-1) = P.normAlpha := by exact_mod_cast hh
    dsimp [Z, N]
    rw [abs_of_neg (by exact_mod_cast hn)]
    rcases hν with rfl | rfl <;> push_cast <;> nlinarith only [hhR]
  have hc : Int.gcd P.a P.b = 1 := by simp [hb]
  have hMe : M = Real.sqrt P.normalizerSquare := by
    simpa only [hS, mul_assoc] using (P.lemma312 h hc hn hx hy hν).1
  have hM2 : M ^ 2 = (P.normalizerSquare : ℝ) := by rw [hMe, Real.sq_sqrt (by positivity)]
  have hM : 0 < M := by
    rw [hMe]
    apply Real.sqrt_pos.mpr
    exact_mod_cast (by have hh := (P.normalizerSquare_bounds h hc (ne_of_lt hn)).2.1; omega : 0 < P.normalizerSquare)
  have he : (X : ℝ) ^ 2 + N = L ^ 2 := by
    have hh := P.norm_identity h.pell k
    rw [hx, hy] at hh
    have hhR : (X : ℝ) ^ 2 - P.d * (Y : ℝ) ^ 2 = P.normAlpha := by exact_mod_cast hh
    dsimp [L, N]
    rw [mul_pow, Real.sq_sqrt hd.le, abs_of_neg (by exact_mod_cast hn)]
    linarith
  have hxlow : (15 / 16 : ℝ) * L ^ 2 < (X : ℝ) ^ 2 := by
    have hh := (P.section4_coordinate_bounds h hb hn hs hy1).1
    rw [hx, hy] at hh
    dsimp [L]
    rw [mul_pow, Real.sq_sqrt hd.le]
    push_cast at hh
    nlinarith only [hh]
  have hxhigh : |(X : ℝ)| < L := by nlinarith [sq_abs (X : ℝ), abs_nonneg (X : ℝ)]
  have hform := Section4.gaussian_parameters hL hZsq he
  have hbounds := Section4.approximation_parameter_bounds_printed hN hM hL hxlow hxhigh
  rw [← hform.1, ← hform.2] at hbounds
  have hYbig : 1 < Y := by
    have hh : (1:ℚ)<(Y:ℚ) := by simpa only [hy] using hybig
    exact_mod_cast hh
  have hbig := P.lemma313_accepted h hb hn hd112 hx hy hYbig hν
  have hbig' : (113/100 : ℝ) < (1832/10000 : ℝ)*M*L/N ∧
      (190:ℝ) < (2112/100 : ℝ)*L/M := by
    simpa only [hS,mul_assoc,M,L,N] using hbig
  exact ⟨hbig'.1.trans hbounds.1,hbig'.2.trans hbounds.2.1,hbounds.1,hbounds.2.2⟩

/-- The Section 4 lower bound from the printed Lemma 3.5 and monotonicity.
The older completion-of-squares proof is archived in the previous complete releases. -/
theorem section4_value_lower_published (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hn : P.normAlpha < 0) {k : ℤ} (hk : k ≠ 0) :
    |(P.normAlpha:ℝ)|/4 ≤ (P.y h.pell k:ℝ) := by
  have hs := P.sequence_seed_bound_published h hb hn hk
  have hu : (1:ℝ) ≤ (P.u:ℝ)^2 := by
    have hi : (1:ℤ) ≤ P.u^2 := by nlinarith [h.u_pos]
    exact_mod_cast hi
  have hh := mul_le_mul_of_nonneg_left hu (abs_nonneg (P.normAlpha:ℝ))
  nlinarith only [hs,hh]

end «JNT-2024».Parameters
