module

public import «JNT-2024».Integrality
public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

abbrev withUnit (P : Parameters) (T U : ℤ) : Parameters := { P with t := T, u := U }

theorem epsilon_re_recurrence (P : Parameters) (n : ℕ) :
    (P.epsilon ^ (n + 2)).re = P.t * (P.epsilon ^ (n + 1)).re -
      P.epsilonNorm * (P.epsilon ^ n).re := by
  simp [pow_succ, epsilon, epsilonNorm]
  ring

theorem epsilon_power_half_integral (P : Parameters) (hp : P.Pell) (n : ℕ) :
    ∃ T U : ℤ, 2 * (P.epsilon ^ n).re = T ∧ 2 * (P.epsilon ^ n).im = U := by
  obtain ⟨ν, hν⟩ : ∃ ν : ℤ, (ν : ℚ) = P.epsilonNorm := by
    rcases P.pell_iff_epsilonNorm.mp hp with hh | hh
    · exact ⟨1, by simpa using hh.symm⟩
    · exact ⟨-1, by simpa using hh.symm⟩
  induction n using Nat.twoStepInduction with
  | zero => exact ⟨2, 0, by simp [QuadraticAlgebra.re_one], by simp [QuadraticAlgebra.im_one]⟩
  | one => exact ⟨P.t, P.u, by simp [epsilon]; ring, by simp [epsilon]; ring⟩
  | more n h₀ h₁ =>
    obtain ⟨T₀, U₀, hT₀, hU₀⟩ := h₀
    obtain ⟨T₁, U₁, hT₁, hU₁⟩ := h₁
    refine ⟨P.t * T₁ - ν * T₀, P.t * U₁ - ν * U₀, ?_, ?_⟩
    · rw [P.epsilon_re_recurrence]
      push_cast
      rw [hν, ← hT₀, ← hT₁]
      ring
    · rw [P.epsilon_im_recurrence]
      push_cast
      rw [hν, ← hU₀, ← hU₁]
      ring

theorem epsilon_power_norm_sq (P : Parameters) (hp : P.Pell) (n : ℕ) :
    QuadraticAlgebra.norm (P.epsilon ^ n) ^ 2 = (1 : ℚ) := by
  have hn : P.epsilonNorm ^ 2 = 1 := by
    rcases P.pell_iff_epsilonNorm.mp hp with hh | hh <;> rw [hh] <;> norm_num
  rw [map_pow, P.norm_epsilon, ← pow_mul, Nat.mul_comm, pow_mul, hn, one_pow]

/-- Every nonzero sequence index is represented by an integral power of the original unit. -/
theorem sequence_unit_parameters_with_norm (P : Parameters) (h : P.Admissible) {k : ℤ} (hk : k ≠ 0) :
    ∃ T U : ℤ, U ≠ 0 ∧ (P.withUnit T U).Pell ∧
      P.term h.pell k = P.alpha * (P.withUnit T U).epsilon ^ 2 ∧
      (P.withUnit T U).epsilonNorm = P.epsilonNorm ^ k := by
  have step : ∀ n : ℕ, 1 ≤ n →
      ∃ T U : ℤ, U ≠ 0 ∧ (P.withUnit T U).epsilon = P.epsilon ^ n ∧
        (P.withUnit T U).Pell := by
    intro n hn
    obtain ⟨T, U, hT, hU⟩ := P.epsilon_power_half_integral h.pell n
    have hu : (0 : ℚ) < (P.epsilon ^ n).im := by
      have hh := P.epsilon_im_lower h n hn
      have hp : (0 : ℚ) < P.u := by exact_mod_cast h.u_pos
      linarith
    have hU0 : U ≠ 0 := by intro he; simp [he] at hU; linarith
    have he : (P.withUnit T U).epsilon = P.epsilon ^ n := by
      ext
      · change (T : ℚ) / 2 = (P.epsilon ^ n).re
        linarith
      · change (U : ℚ) / 2 = (P.epsilon ^ n).im
        linarith
    have hnorm : (P.withUnit T U).epsilonNorm ^ 2 = 1 := by
      rw [← (P.withUnit T U).norm_epsilon, he]
      exact P.epsilon_power_norm_sq h.pell n
    exact ⟨T, U, hU0, he, (P.withUnit T U).pell_iff_epsilonNorm.mpr (sq_eq_one_iff.mp hnorm)⟩
  rcases k with n | n
  · have hn0 : n ≠ 0 := by intro hh; subst n; exact hk rfl
    have hn : 1 ≤ n := by omega
    obtain ⟨T, U, hU, he, hp⟩ := step n hn
    refine ⟨T, U, hU, hp, ?_, ?_⟩
    · change P.term h.pell (n : ℤ) = _
      rw [he, P.term_nat]
      congr 1
      rw [← pow_mul, Nat.mul_comm]
    · rw [← (P.withUnit T U).norm_epsilon, he, map_pow, P.norm_epsilon]
      simp
  · obtain ⟨T, U, hU, he, hp⟩ := step (n + 1) (by omega)
    have hstar : (P.withUnit T (-U)).epsilon = star ((P.withUnit T U).epsilon) := by
      ext
      · simp [epsilon]
      · simp [epsilon]; ring
    refine ⟨T, -U, neg_ne_zero.mpr hU, ?_, ?_, ?_⟩
    · simpa only [Pell, withUnit, neg_sq] using hp
    · change P.term h.pell (-((n + 1 : ℕ) : ℤ)) = _
      rw [P.term_neg_nat, hstar, he]
    · rw [← (P.withUnit T (-U)).norm_epsilon, hstar, he, QuadraticAlgebra.norm_star,
        map_pow, P.norm_epsilon]
      change P.epsilonNorm ^ (n + 1) = P.epsilonNorm ^ (-((n + 1 : ℕ) : ℤ))
      rw [zpow_neg, zpow_natCast]
      rcases P.pell_iff_epsilonNorm.mp h.pell with hh | hh <;> simp [hh, ← inv_pow]


theorem sequence_square_representation_input_indexed (P : Parameters) (h : P.Admissible) {k : ℤ}
    (hk : k ≠ 0) (hs : IsSquare (P.y h.pell k)) (hy : 0 < P.y h.pell k) :
    ∃ T U x v : ℤ, U ≠ 0 ∧ 0 < v ∧ (P.withUnit T U).Pell ∧
      (P.withUnit T U).RepresentsSquare x v ∧ P.y h.pell k = (v : ℚ) ^ 2 ∧
      P.x h.pell k = (x : ℚ) ∧ (P.withUnit T U).epsilonNorm = P.epsilonNorm ^ k := by
  obtain ⟨v₀, hv₀⟩ := P.rational_square_iff_integer_square h.pell k |>.mp hs
  let v := |v₀|
  have hv : P.y h.pell k = (v : ℚ) ^ 2 := by simpa [v] using hv₀
  have hvpos : 0 < v := by
    have hvq : (0 : ℚ) < v := by
      have hh : (0 : ℚ) ≤ v := by exact_mod_cast abs_nonneg v₀
      nlinarith
    exact_mod_cast hvq
  have hn := P.norm_identity h.pell k
  obtain ⟨x, hx⟩ := integer_root_of_two_mul_sq (P.x h.pell k) (by
    refine ⟨2 * (P.d * v ^ 4 + P.normAlpha), ?_⟩
    rw [hv] at hn
    push_cast
    nlinarith only [hn])
  obtain ⟨T, U, hU, hp, he, hν⟩ := P.sequence_unit_parameters_with_norm h hk
  refine ⟨T, U, x, v, hU, hvpos, hp, ?_, hv, hx, hν⟩
  change (⟨(x : ℚ), (v : ℚ) ^ 2⟩ : P.Algebra) = P.alpha * (P.withUnit T U).epsilon ^ 2
  rw [← he]
  ext
  · exact hx.symm
  · exact hv.symm

theorem sequence_unit_parameters (P : Parameters) (h : P.Admissible) {k : ℤ} (hk : k ≠ 0) :
    ∃ T U : ℤ, U ≠ 0 ∧ (P.withUnit T U).Pell ∧
      P.term h.pell k = P.alpha * (P.withUnit T U).epsilon ^ 2 := by
  obtain ⟨T, U, hU, hp, ht, _⟩ := P.sequence_unit_parameters_with_norm h hk
  exact ⟨T, U, hU, hp, ht⟩

theorem sequence_square_representation_input (P : Parameters) (h : P.Admissible) {k : ℤ}
    (hk : k ≠ 0) (hs : IsSquare (P.y h.pell k)) (hy : 0 < P.y h.pell k) :
    ∃ T U x v : ℤ, U ≠ 0 ∧ 0 < v ∧ (P.withUnit T U).Pell ∧
      (P.withUnit T U).RepresentsSquare x v ∧ P.y h.pell k = (v : ℚ) ^ 2 := by
  obtain ⟨T, U, x, v, hU, hv, hp, hrep, hy, _, _⟩ :=
    P.sequence_square_representation_input_indexed h hk hs hy
  exact ⟨T, U, x, v, hU, hv, hp, hrep, hy⟩

end «JNT-2024».Parameters
