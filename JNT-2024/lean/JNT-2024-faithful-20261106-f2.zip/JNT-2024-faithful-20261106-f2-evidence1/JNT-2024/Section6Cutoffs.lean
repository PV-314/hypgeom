module

public import «JNT-2024».NormalizerBounds
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».Section64
public import «JNT-2024».Section65_68
public import «JNT-2024».Section6Families
public import «JNT-2024».Section6Fibonacci
public import «JNT-2024».Section6Normalizers
public import «JNT-2024».Sequence
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Fib.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section6

noncomputable def rawCutoff (P : Parameters) : ℝ :=
  137 * |(P.normAlpha : ℝ)| * Real.sqrt |(P.normAlpha : ℝ)| /
    (Real.sqrt (P.d : ℝ)*P.normalizerSquare)

theorem families65_68_cutoff_comparisons (j : ℕ) :
    |((family65 j).normAlpha : ℝ)| < rawCutoff (family65 j) ∧
    |((family66 j).normAlpha : ℝ)|/2 < rawCutoff (family66 j) := by
  have h := families65_68_admissible j
  have hn := families65_68_negative_square j
  obtain ⟨_,hM65,_,hM66,_,_,_,_⟩ := families65_68_normalizers j
  obtain ⟨hN65,hN66,_,_,_⟩ := families65_68_values j
  have hp := pellPair_properties j
  have hpR : (7 : ℝ) ≤ pellP j := by exact_mod_cast hp.1
  refine ⟨?_,?_⟩
  · simpa only [rawCutoff,one_mul] using coefficient_below_cutoff (family65 j) h.1.d_pos hn.1.1
      (by rw [hM65]; norm_num) (c := 1) (by norm_num) (by
        rw [hM65, abs_negative_square _ hN65]
        simp only [family65,unitOne]
        push_cast
        nlinarith only [sq_nonneg ((pellP j : ℝ)-1), hpR])
  · have hh := coefficient_below_cutoff (family66 j) h.2.1.d_pos hn.2.1.1
      (by rw [hM66]; norm_num) (c := 1/2) (by norm_num) (by
        rw [hM66, abs_negative_square _ hN66]
        simp only [family66,unitOne]
        push_cast
        nlinarith only [sq_nonneg ((pellP j : ℝ)+1), hpR])
    simpa only [rawCutoff,one_div_mul_eq_div] using hh


theorem family64_negative_square (j : ℕ) :
    (family64 j).normAlpha < 0 ∧ IsSquare (-(family64 j).normAlpha) := by
  have hh := lucasIndex_spec j
  rw [family64_norm]
  exact negative_square (by dsimp [normRoot64]; omega)


end «JNT-2024».Section6
