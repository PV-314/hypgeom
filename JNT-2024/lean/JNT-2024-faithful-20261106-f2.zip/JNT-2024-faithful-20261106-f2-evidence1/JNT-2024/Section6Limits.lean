module

public import «JNT-2024».Section64
public import «JNT-2024».Section65_68
public import «JNT-2024».Section69
public import «JNT-2024».Section6Fibonacci
public import «JNT-2024».Sequence
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Analysis.SpecificLimits.Basic
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Fib.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

open Filter Topology

namespace «JNT-2024».Section6

noncomputable def ratio64 (x : ℝ) : ℝ :=
  ((x^2+4)/5) * Real.sqrt (((x-1)/2)^2+4) / (2*(x-4)/5)^3

noncomputable def normalizedRatio64 (z : ℝ) : ℝ :=
  (25/16)*(1+4*z^2)*Real.sqrt ((1-z)^2+16*z^2)/(1-4*z)^3

theorem ratio64_normalized {x : ℝ} (hx : 4 < x) : ratio64 x = normalizedRatio64 x⁻¹ := by
  have hx0 : x ≠ 0 := by linarith
  have hx4 : x-4 ≠ 0 := by linarith
  have he : 1-4*x⁻¹ = (x-4)/x := by field_simp
  have hden : 1-4*x⁻¹ ≠ 0 := by rw [he]; exact div_ne_zero hx4 hx0
  have hd : ((x-1)/2)^2+4 = (x/2)^2*((1-x⁻¹)^2+16*(x⁻¹)^2) := by
    field_simp
    ring
  unfold ratio64 normalizedRatio64
  rw [hd,Real.sqrt_mul (sq_nonneg (x/2)),Real.sqrt_sq (by linarith : (0 : ℝ) ≤ x/2)]
  field_simp [hx0,hx4,hden]
  ring

theorem ratio64_limit : Tendsto ratio64 atTop (𝓝 (25/16 : ℝ)) := by
  have hc : ContinuousAt normalizedRatio64 0 := by
    unfold normalizedRatio64
    fun_prop (disch := norm_num)
  have hh := hc.tendsto.comp (tendsto_inv_atTop_zero : Tendsto (fun x : ℝ => x⁻¹) atTop (𝓝 0))
  have hh' : Tendsto (fun x : ℝ => normalizedRatio64 x⁻¹) atTop (𝓝 (25/16 : ℝ)) := by
    simpa only [Function.comp_def, show normalizedRatio64 0 = 25/16 by norm_num [normalizedRatio64]] using hh
  apply hh'.congr'
  filter_upwards [eventually_gt_atTop (4 : ℝ)] with x hx
  exact (ratio64_normalized hx).symm

theorem lucasFamily_tendsto : Tendsto (fun j => (lucasFamily j : ℝ)) atTop atTop := by
  have hl : ∀ j : ℕ, (j : ℤ)+199 ≤ lucasFamily j := by
    intro j
    induction j with
    | zero => have hh := (lucasFamily_properties 0).1; simpa using hh
    | succ j ih =>
      have hh := lucasFamily_strictMono (Nat.lt_succ_self j)
      simp only [Nat.succ_eq_add_one] at hh
      push_cast
      omega
  apply tendsto_atTop_mono (f := fun j : ℕ => (j : ℝ)) ?_ tendsto_natCast_atTop_atTop
  intro j
  exact_mod_cast (show (j : ℤ) ≤ lucasFamily j by have hh := hl j; omega)

noncomputable def publishedRatio (P : Parameters) (hp : P.Pell) (k : ℤ) : ℝ :=
  (P.y hp k : ℝ) / (|(P.normAlpha : ℝ)| * Real.sqrt |(P.normAlpha : ℝ)| / Real.sqrt (P.d : ℝ))

theorem family64_ratio (j : ℕ) :
    publishedRatio (family64 j) (family64_admissible j).pell 1 = ratio64 (lucasFamily j) := by
  have hn := (lucasFamily_properties j).2.2.1
  have hnR : (lucasFamily j : ℝ)^2-5*(fibonacciFamily j : ℝ)^2 = -4 := by exact_mod_cast hn
  have hy : ((family64 j).y (family64_admissible j).pell 1 : ℝ) = ((lucasFamily j : ℝ)^2+4)/5 := by
    rw [family64_square]
    push_cast
    linarith
  have hm := lucasIndex_spec j
  have hr : (0 : ℝ) ≤ normRoot64 j := by
    exact_mod_cast (show 0 ≤ normRoot64 j by dsimp [normRoot64]; omega)
  have hroot : (normRoot64 j : ℝ) = 2*((lucasFamily j : ℝ)-4)/5 := by
    have he : normRoot64 j * 5 = 2*(lucasFamily j-4) := by dsimp [normRoot64]; omega
    have he' : (normRoot64 j : ℝ)*5 = 2*((lucasFamily j : ℝ)-4) := by exact_mod_cast he
    linarith
  have ht : ((family64 j).t : ℝ) = ((lucasFamily j : ℝ)-1)/2 := by
    have he : (family64 j).t*2 = lucasFamily j-1 := by dsimp [family64,unitOne]; omega
    have he' : ((family64 j).t : ℝ)*2 = (lucasFamily j : ℝ)-1 := by exact_mod_cast he
    linarith
  have hd : ((family64 j).d : ℝ) = (((lucasFamily j : ℝ)-1)/2)^2+4 := by
    have he : (family64 j).d = ((family64 j).t)^2+4 := rfl
    exact_mod_cast (show ((family64 j).d : ℝ) = (((lucasFamily j : ℝ)-1)/2)^2+4 by
      rw [he]; push_cast; rw [ht])
  unfold publishedRatio ratio64
  rw [hy,abs_negative_square _ (family64_norm j),Real.sqrt_sq hr,hroot,hd]
  rw [div_div_eq_mul_div]
  ring

/-- Exactly the limit `25/16` printed in Section 6.4. -/
theorem family64_published_limit :
    Tendsto (fun j => publishedRatio (family64 j) (family64_admissible j).pell 1)
      atTop (𝓝 (25/16 : ℝ)) := by
  simp_rw [family64_ratio]
  exact ratio64_limit.comp lucasFamily_tendsto

/-- The original Section 6.9 family approaches `1/4` from above. -/
theorem family69_published_limit :
    Tendsto (fun j : ℕ =>
      ((family69 (j+3)).y (family69_admissible (by omega)).pell (-1) : ℝ) /
        |((family69 (j+3)).normAlpha : ℝ)|) atTop (𝓝 (1/4 : ℝ)) := by
  have hh : Tendsto (fun j : ℕ => ((j : ℤ)+3 : ℝ)) atTop atTop :=
    tendsto_atTop_mono (f := fun j : ℕ => (j : ℝ)) (fun j => by push_cast; linarith) tendsto_natCast_atTop_atTop
  apply (quadratic_ratio_limit.comp hh).congr
  intro j
  dsimp only [Function.comp_def]
  symm
  rw [family69_ratio (by omega)]
  push_cast
  rfl

theorem squareNorm69_ratio {n : ℤ} (hn : 2 ≤ n) :
    ((squareNorm69 n).y (squareNorm69_admissible hn).pell (-1) : ℝ) /
      |((squareNorm69 n).normAlpha : ℝ)| = (4*(n : ℝ)^2+1)^2/(8*(n : ℝ)^2-2)^2 := by
  obtain ⟨hN,hy⟩ := squareNorm69_values hn
  rw [hy,abs_negative_square _ hN]
  push_cast
  rfl

theorem squareNorm69_published_limit :
    Tendsto (fun j : ℕ =>
      ((squareNorm69 (j+2)).y (squareNorm69_admissible (by omega)).pell (-1) : ℝ) /
        |((squareNorm69 (j+2)).normAlpha : ℝ)|) atTop (𝓝 (1/4 : ℝ)) := by
  have hh : Tendsto (fun j : ℕ => ((j : ℤ)+2 : ℝ)) atTop atTop :=
    tendsto_atTop_mono (f := fun j : ℕ => (j : ℝ)) (fun j => by push_cast; linarith) tendsto_natCast_atTop_atTop
  apply (square_norm_ratio_limit.comp hh).congr
  intro j
  dsimp only [Function.comp_def]
  symm
  rw [squareNorm69_ratio (by omega)]
  push_cast
  rfl

end «JNT-2024».Section6
