module

public import «JNT-2024».FourthRootEstimates
public import «JNT-2024».FourthRootGeometry
public import «JNT-2024».GapConstants
public import «JNT-2024».GapLattice
public import «JNT-2024».GapPhaseAlgebra
public import «JNT-2024».GapPublishedAlgebra
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- Arithmetic and residual identities supplied by a fourth-power representation. -/
structure FourthPowerDatum (D : ℤ) (b t : ℝ) (ω : ℂ) where
  r : ℤ
  s : ℤ
  y : ℝ
  f : ℝ
  y_pos : 0 < y
  f_pos : 0 < f
  point_ne : quadraticPoint D r s ≠ 0
  norm_four : ‖quadraticPoint D r s‖ ^ 4 * b ^ 2 = f ^ 2 * y
  residual : ‖ω - (quadraticPoint D r s / star (quadraticPoint D r s)) ^ 4‖ * y = 2 * t
  /-- Equation (3.18), normalized by the common positive imaginary part.
  This is proved from the actual signed representation in the constructor. -/
  imaginary_identity : |((2 * Complex.I / (1 - ω)) * (quadraticPoint D r s) ^ 4).im| = f ^ 2

namespace FourthPowerDatum

noncomputable def point {D : ℤ} {b t : ℝ} {ω : ℂ} (p : FourthPowerDatum D b t ω) : ℂ :=
  quadraticPoint D p.r p.s

noncomputable def ratio {D : ℤ} {b t : ℝ} {ω : ℂ} (p : FourthPowerDatum D b t ω) : ℂ :=
  p.point / star p.point

theorem ratio_norm {D : ℤ} {b t : ℝ} {ω : ℂ} (p : FourthPowerDatum D b t ω) : ‖p.ratio‖ = 1 := by
  rw [ratio, norm_div, norm_star]
  exact div_self (norm_ne_zero_iff.mpr p.point_ne)

theorem phase_approximation {D : ℤ} {b t : ℝ} {ω w : ℂ}
    (p : FourthPowerDatum D b t ω) (ht : 0 < t) (hw : w ^ 4 = ω) (hwn : ‖w‖ = 1)
    (hlarge : 4 * t ≤ p.y) :
    ∃ ζ : ℂ, FourthPhase ζ ∧ ‖w - ζ * p.ratio‖ * p.y < (5051 / 10000 : ℝ) * t := by
  have he : ‖w ^ 4 - p.ratio ^ 4‖ * p.y = 2 * t := by
    simpa only [hw, ratio, point] using p.residual
  have hpos : 0 < ‖w ^ 4 - p.ratio ^ 4‖ := by nlinarith [p.y_pos]
  have hsmall : ‖w ^ 4 - p.ratio ^ 4‖ ≤ 1 / 2 := by nlinarith [p.y_pos]
  obtain ⟨ζ, hζ, hh⟩ := fourth_root_half_error_fixed hwn p.ratio_norm hpos hsmall
  have hm := mul_lt_mul_of_pos_right hh p.y_pos
  exact ⟨ζ, hζ, by nlinarith only [hm, he]⟩


/-- The published imaginary-part contradiction for the phase distance. -/
theorem phase_ratios_ne {D : ℤ} {b t : ℝ} {ω ζ η : ℂ}
    (p q : FourthPowerDatum D b t ω) (_ht : 0 < t) (hζ : FourthPhase ζ) (hη : FourthPhase η)
    (hy : p.y ≠ q.y) : ζ * p.ratio ≠ η * q.ratio := by
  intro he
  have hh := phase_equality_imaginary p.point_ne q.point_ne hζ hη
    p.imaginary_identity q.imaginary_identity he
  change p.f ^ 2 * ‖q.point‖ ^ 4 = q.f ^ 2 * ‖p.point‖ ^ 4 at hh
  have hm := congrArg (fun v : ℝ => v * b ^ 2) hh
  have hp : ‖p.point‖ ^ 4 * b ^ 2 = p.f ^ 2 * p.y := p.norm_four
  have hq : ‖q.point‖ ^ 4 * b ^ 2 = q.f ^ 2 * q.y := q.norm_four
  have hc : (p.f ^ 2 * q.f ^ 2) * q.y = (p.f ^ 2 * q.f ^ 2) * p.y := by
    calc
      _ = p.f ^ 2 * (‖q.point‖ ^ 4 * b ^ 2) := by rw [hq]; ring
      _ = q.f ^ 2 * (‖p.point‖ ^ 4 * b ^ 2) := by nlinarith only [hm]
      _ = _ := by rw [hp]; ring
  have hn : p.f ^ 2 * q.f ^ 2 ≠ 0 :=
    ne_of_gt (mul_pos (sq_pos_of_pos p.f_pos) (sq_pos_of_pos q.f_pos))
  exact hy (mul_left_cancel₀ hn hc).symm

theorem cross_identity {D : ℤ} {b t : ℝ} {ω ζ η : ℂ}
    (p q : FourthPowerDatum D b t ω) :
    (ζ * p.ratio - η * q.ratio) * (star p.point * star q.point) =
      ζ * (p.point * star q.point) - η * star (p.point * star q.point) := by
  have hp : star p.point ≠ 0 := star_ne_zero.mpr p.point_ne
  have hq : star q.point ≠ 0 := star_ne_zero.mpr q.point_ne
  simp only [ratio, star_mul, star_star]
  field_simp

/-- Equation (3.23), using the paper's cross coordinate conjugate(p)*q. -/
theorem cross_identity_printed {D : ℤ} {b t : ℝ} {ω ζ η : ℂ}
    (p q : FourthPowerDatum D b t ω) :
    (ζ * p.ratio - η * q.ratio) * (star p.point * star q.point) =
      2 * ζ * ((star p.point * q.point).re : ℂ) -
        (ζ + η) * (star p.point * q.point) := by
  rw [p.cross_identity q]
  simpa only [Complex.eta, star_mul, star_star, mul_comm] using
    printed_cross_numerator ζ η (star p.point * q.point).re (star p.point * q.point).im

/-- Fourth powers of both positive sides of (3.25). -/
theorem cross_denominator_four {D : ℤ} {b t : ℝ} {ω : ℂ}
    (p q : FourthPowerDatum D b t ω) :
    ‖star p.point * star q.point‖ ^ 4 * b ^ 4 = (p.f * q.f) ^ 2 * p.y * q.y := by
  simp only [norm_mul, norm_star, mul_pow]
  calc
    _ = (‖p.point‖ ^ 4 * b ^ 2) * (‖q.point‖ ^ 4 * b ^ 2) := by ring
    _ = _ := by dsimp only [point]; rw [p.norm_four, q.norm_four]; ring

/-- The literal denominator norm in (3.25); nested square roots express
the positive fourth root of y_i*y_j. -/
theorem cross_denominator_norm {D : ℤ} {b t : ℝ} {ω : ℂ}
    (p q : FourthPowerDatum D b t ω) (hb : 0 < b) :
    ‖star p.point * star q.point‖ =
      Real.sqrt (p.f * q.f) * Real.sqrt (Real.sqrt (p.y * q.y)) / b := by
  have hfg := Real.sq_sqrt (le_of_lt (mul_pos p.f_pos q.f_pos))
  have hyy := Real.sq_sqrt (le_of_lt (mul_pos p.y_pos q.y_pos))
  have hyy' := Real.sq_sqrt (Real.sqrt_nonneg (p.y * q.y))
  have hright : (Real.sqrt (p.f * q.f) * Real.sqrt (Real.sqrt (p.y * q.y))) ^ 4 =
      (p.f * q.f) ^ 2 * p.y * q.y := by
    calc
      _ = (Real.sqrt (p.f * q.f) ^ 2) ^ 2 *
          (Real.sqrt (Real.sqrt (p.y * q.y)) ^ 2) ^ 2 := by ring
      _ = _ := by rw [hfg, hyy', hyy]; ring
  apply (eq_div_iff (ne_of_gt hb)).mpr
  apply (pow_left_inj₀ (mul_nonneg (norm_nonneg _) hb.le)
    (mul_nonneg (Real.sqrt_nonneg _) (Real.sqrt_nonneg _)) (by decide : (4 : ℕ) ≠ 0)).mp
  rw [mul_pow, p.cross_denominator_four q, hright]

theorem distance_upper {D : ℤ} {b t : ℝ} {ω w ζ η : ℂ}
    (p q : FourthPowerDatum D b t ω)
    (hp : ‖w - ζ * p.ratio‖ * p.y < (5051 / 10000 : ℝ) * t)
    (hq : ‖w - η * q.ratio‖ * q.y < (5051 / 10000 : ℝ) * t) :
    ‖ζ * p.ratio - η * q.ratio‖ * p.y * q.y < (5051 / 10000 : ℝ) * t * (p.y + q.y) := by
  have htri : ‖ζ * p.ratio - η * q.ratio‖ ≤ ‖w - ζ * p.ratio‖ + ‖w - η * q.ratio‖ := by
    have hh := norm_add_le (ζ * p.ratio - w) (w - η * q.ratio)
    rw [sub_add_sub_cancel] at hh
    simpa only [norm_sub_rev] using hh
  have hmul := mul_le_mul_of_nonneg_right htri (le_of_lt (mul_pos p.y_pos q.y_pos))
  have h₁ := mul_lt_mul_of_pos_right hp q.y_pos
  have h₂ := mul_lt_mul_of_pos_right hq p.y_pos
  nlinarith only [hmul, h₁, h₂]

theorem gap_from_separation {D : ℤ} {b t m : ℝ} {ω w ζ η : ℂ}
    (p q : FourthPowerDatum D b t ω) (hb : 0 < b) (ht : 0 < t) (hm : 0 < m)
    (hp : ‖w - ζ * p.ratio‖ * p.y < (5051 / 10000 : ℝ) * t)
    (hq : ‖w - η * q.ratio‖ * q.y < (5051 / 10000 : ℝ) * t)
    (hsep : m ≤ ‖ζ * (p.point * star q.point) - η * star (p.point * star q.point)‖ ^ 2) :
    GapInequality (m ^ 2) (b ^ 4 / ((p.f * q.f) ^ 2 * t ^ 4)) p.y q.y := by
  have hpy := p.y_pos
  have hqy := q.y_pos
  have hpf := p.f_pos
  have hqf := q.f_pos
  have he := congrArg (fun z : ℂ => ‖z‖ ^ 4) (p.cross_identity q (ζ := ζ) (η := η))
  simp only [norm_mul, norm_star, mul_pow] at he
  have hl : m ^ 2 ≤ ‖ζ * p.ratio - η * q.ratio‖ ^ 4 * ‖p.point‖ ^ 4 * ‖q.point‖ ^ 4 := by
    rw [mul_assoc, he]
    nlinarith [sq_nonneg (m - ‖ζ * (p.point * star q.point) - η * star (p.point * star q.point)‖ ^ 2)]
  have hl' := mul_le_mul_of_nonneg_right hl (show 0 ≤ b ^ 4 by positivity)
  have hnorm : (‖p.point‖ ^ 4 * ‖q.point‖ ^ 4) * b ^ 4 = (p.f * q.f) ^ 2 * p.y * q.y := by
    simpa only [norm_mul, norm_star, mul_pow] using p.cross_denominator_four q
  have hlow : m ^ 2 * b ^ 4 ≤ ‖ζ * p.ratio - η * q.ratio‖ ^ 4 * (p.f * q.f) ^ 2 * p.y * q.y := by
    calc
      _ ≤ _ := hl'
      _ = _ := by rw [show ‖ζ * p.ratio - η * q.ratio‖ ^ 4 * ‖p.point‖ ^ 4 * ‖q.point‖ ^ 4 * b ^ 4 =
        ‖ζ * p.ratio - η * q.ratio‖ ^ 4 * ((‖p.point‖ ^ 4 * ‖q.point‖ ^ 4) * b ^ 4) by ring, hnorm]; ring
  have hu := p.distance_upper q hp hq
  have hup := pow_lt_pow_left₀ hu (show 0 ≤ ‖ζ * p.ratio - η * q.ratio‖ * p.y * q.y by positivity) (by decide : (4 : ℕ) ≠ 0)
  have hlo := mul_le_mul_of_nonneg_right hlow (show 0 ≤ p.y ^ 3 * q.y ^ 3 by positivity)
  have hup' := mul_lt_mul_of_pos_right hup (show 0 < (p.f * q.f) ^ 2 by positivity)
  have hraw : m ^ 2 * b ^ 4 * p.y ^ 3 * q.y ^ 3 <
      (5051 / 10000 : ℝ) ^ 4 * (p.y + q.y) ^ 4 * ((p.f * q.f) ^ 2 * t ^ 4) := by
    nlinarith only [hlo, hup']
  have hden : 0 < (p.f * q.f) ^ 2 * t ^ 4 := by positivity
  unfold GapInequality
  have hh := (div_lt_iff₀ hden).mpr hraw
  convert hh using 1; ring

theorem cross_ne {D : ℤ} {b t : ℝ} {ω ζ η : ℂ}
    (p q : FourthPowerDatum D b t ω) (ht : 0 < t) (hζ : FourthPhase ζ) (hη : FourthPhase η)
    (hy : p.y ≠ q.y) : ζ * (p.point * star q.point) - η * star (p.point * star q.point) ≠ 0 := by
  intro he
  have hh := p.cross_identity q (ζ := ζ) (η := η)
  rw [he] at hh
  have hp : star p.point ≠ 0 := star_ne_zero.mpr p.point_ne
  have hq : star q.point ≠ 0 := star_ne_zero.mpr q.point_ne
  have hdiff := (mul_eq_zero.mp hh).resolve_right (mul_ne_zero hp hq)
  exact p.phase_ratios_ne q ht hζ hη hy (sub_eq_zero.mp hdiff)

theorem parallel_gap {D : ℤ} {b t : ℝ} {ω w ζ η : ℂ}
    (p q : FourthPowerDatum D b t ω) (hD : 0 < D) (hb : 0 < b) (ht : 0 < t)
    (hy : p.y < q.y) (hζ : FourthPhase ζ) (hη : FourthPhase η) (hc : SamePhaseClass ζ η)
    (hp : ‖w - ζ * p.ratio‖ * p.y < (5051 / 10000 : ℝ) * t)
    (hq : ‖w - η * q.ratio‖ * q.y < (5051 / 10000 : ℝ) * t) :
    GapInequality 16 (b ^ 4 / ((p.f * q.f) ^ 2 * t ^ 4)) p.y q.y := by
  have he : p.point * star q.point =
      (⟨(p.r * q.r + D * p.s * q.s : ℤ), (p.s * q.r - p.r * q.s : ℤ) * Real.sqrt D⟩ : ℂ) :=
    quadratic_cross_coordinates _ _ _ _ _ hD.le
  have hn := p.cross_ne q ht hζ hη (ne_of_lt hy)
  rw [he] at hn
  have hs := quadratic_parallel_separation hD hζ hη hc hn
  rw [← he] at hs
  simpa only [show (4 : ℝ) ^ 2 = 16 by norm_num] using p.gap_from_separation q hb ht (by norm_num) hp hq hs

theorem gaussian_gap {b t : ℝ} {ω : ℂ} (p q : FourthPowerDatum 1 b t ω)
    (hb : 0 < b) (ht : 0 < t) (hω : ‖ω‖ = 1) (hy : p.y < q.y) (hlarge : 4 * t ≤ p.y) :
    GapInequality 4 (b ^ 4 / ((p.f * q.f) ^ 2 * t ^ 4)) p.y q.y := by
  obtain ⟨w, hw, hwn⟩ := exists_unit_fourth_root hω
  obtain ⟨ζ, hζ, hp⟩ := p.phase_approximation ht hw hwn hlarge
  obtain ⟨η, hη, hq⟩ := q.phase_approximation ht hw hwn (le_trans hlarge hy.le)
  have he : p.point * star q.point =
      (⟨(p.r * q.r + p.s * q.s : ℤ), (p.s * q.r - p.r * q.s : ℤ)⟩ : ℂ) := by
    simpa [point] using quadratic_cross_coordinates 1 p.r p.s q.r q.s (by norm_num)
  have hn := p.cross_ne q ht hζ hη (ne_of_lt hy)
  rw [he] at hn
  have hs := gaussian_phase_separation hζ hη hn
  rw [← he] at hs
  simpa only [show (2 : ℝ) ^ 2 = 4 by norm_num] using p.gap_from_separation q hb ht (by norm_num) hp hq hs

/-- The two conclusions of the three-point gap principle for a selected pair. -/
def CubicGap {D : ℤ} {b t : ℝ} {ω : ℂ} (p q : FourthPowerDatum D b t ω) : Prop :=
  (1536 / 100 : ℝ) * (b ^ 4 / ((p.f * q.f) ^ 2 * t ^ 4)) * p.y ^ 3 < q.y ∧
  ((427 / 1600 : ℝ) ^ 2 ≤ (b ^ 4 / ((p.f * q.f) ^ 2 * t ^ 4)) * p.y ^ 2 →
    182 * (b ^ 4 / ((p.f * q.f) ^ 2 * t ^ 4)) * p.y ^ 3 < q.y)

theorem cubicGap_of_gap {D : ℤ} {b t : ℝ} {ω : ℂ} (p q : FourthPowerDatum D b t ω)
    (hb : 0 < b) (ht : 0 < t) (hy : p.y < q.y)
    (hg : GapInequality 16 (b ^ 4 / ((p.f * q.f) ^ 2 * t ^ 4)) p.y q.y) : p.CubicGap q := by
  have hpf := p.f_pos
  have hqf := q.f_pos
  have hA : 0 < b ^ 4 / ((p.f * q.f) ^ 2 * t ^ 4) := by positivity
  exact ⟨gap_quadratic hA p.y_pos hy hg, fun hs => gap_quadratic_strong hA p.y_pos hy hs hg⟩

/-- Lemma 3.8(b)'s geometric gap principle, with the representation data explicit. -/
theorem lemma38b_represented {D : ℤ} {b t : ℝ} {ω : ℂ} (p q v : FourthPowerDatum D b t ω)
    (hD : 0 < D) (hb : 0 < b) (ht : 0 < t) (hω : ‖ω‖ = 1)
    (hpq : p.y < q.y) (hqv : q.y < v.y) (hlarge : 4 * t ≤ p.y) :
    p.CubicGap q ∨ p.CubicGap v ∨ q.CubicGap v := by
  obtain ⟨w, hw, hwn⟩ := exists_unit_fourth_root hω
  obtain ⟨ζ, hζ, hp⟩ := p.phase_approximation ht hw hwn hlarge
  obtain ⟨η, hη, hq⟩ := q.phase_approximation ht hw hwn (le_trans hlarge hpq.le)
  obtain ⟨θ, hθ, hv⟩ := v.phase_approximation ht hw hwn (le_trans hlarge (lt_trans hpq hqv).le)
  rcases three_phases ζ η θ hζ hη hθ with hc | hc | hc
  · exact Or.inl (p.cubicGap_of_gap q hb ht hpq (p.parallel_gap q hD hb ht hpq hζ hη hc hp hq))
  · exact Or.inr (Or.inl (p.cubicGap_of_gap v hb ht (lt_trans hpq hqv)
      (p.parallel_gap v hD hb ht (lt_trans hpq hqv) hζ hθ hc hp hv)))
  · exact Or.inr (Or.inr (q.cubicGap_of_gap v hb ht hqv (q.parallel_gap v hD hb ht hqv hη hθ hc hq hv)))

/-- Lemma 3.8(a)'s geometric gap principle, permitting a smaller arithmetic coefficient. -/
theorem lemma38a_represented {b t A : ℝ} {ω : ℂ} (p q : FourthPowerDatum 1 b t ω)
    (hb : 0 < b) (ht : 0 < t) (hω : ‖ω‖ = 1) (hy : p.y < q.y) (hlarge : 4 * t ≤ p.y)
    (hA : 0 < A) (hcoeff : A ≤ b ^ 4 / ((p.f * q.f) ^ 2 * t ^ 4)) (hscale : 1 ≤ A * p.y ^ 2) :
    (5732 / 100 : ℝ) * A * p.y ^ 3 < q.y := by
  have hg := p.gaussian_gap q hb ht hω hy hlarge
  apply gap_gaussian hA p.y_pos hy hscale
  have hmul := mul_le_mul_of_nonneg_right hcoeff (show 0 ≤ 4 * p.y ^ 3 * q.y ^ 3 by
    have hp := p.y_pos; have hq := q.y_pos; positivity)
  dsimp [GapInequality] at hg ⊢
  nlinarith only [hmul, hg]

end FourthPowerDatum
end «JNT-2024»
