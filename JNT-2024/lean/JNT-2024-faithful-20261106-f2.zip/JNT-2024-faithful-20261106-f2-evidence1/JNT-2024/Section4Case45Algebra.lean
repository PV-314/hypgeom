module

public import «JNT-2024».Section4ExponentialPublished
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

/-- Division of (4.17) by the non-square-root factor in (4.15), reindexed
at r-1. Variables k,a,h are the printed numerical constants. -/
theorem case45_division_identity {N d y F M c k a h : ℝ} {r : ℕ}
    (hN : N ≠ 0) (hd : d ≠ 0) (hy : y ≠ 0) (hF : F ≠ 0) (hM : M ≠ 0)
    (ha : a ≠ 0) (hh : h ≠ 0) (hr : 1 ≤ r) :
    (((k/M)^4*(N/F)^2*c^4*(a*M/N)^(4*r)*d^(2*r)*y^(4*r-1)) /
      (h*(4*d/N)^r*y^(2*r+1))) =
    (k^4*c^4*a^4/(4*h))*d/(F^2*N)*
      ((a^4/4)*M^4*d*y^2/N^3)^(r-1) := by
  rw [pow_sub₀ y hy (by omega : 1 ≤ 4*r),
    pow_sub₀ ((a^4/4)*M^4*d*y^2/N^3) (by positivity) hr]
  simp only [pow_add,pow_one,mul_pow,div_pow,← pow_mul]
  simp only [show 4*r=r*4 by omega,show 2*r=r*2 by omega,show 3*r=r*3 by omega]
  simp only [pow_mul]
  field_simp

/-- Apply the printed minimum-at-three comparison to (4.17) and (4.15). -/
theorem case45_remove_square_root {N d y z F M : ℝ} {r : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hy : 0 < y) (hF : 0 < F) (hM : 0 < M)
    (hr : 1 ≤ r)
    (h417 : ((8537/1000 : ℝ)/M)^4*(N/F)^2*(3/4 : ℝ)^4*
      ((1832/10000 : ℝ)*M/N)^(4*r)*d^(2*r)*y^(4*r-1) < z)
    (h415 : z < (1734/1000 : ℝ)*Real.sqrt r*(4*d/N)^r*y^(2*r+1)) :
    ((8537/1000 : ℝ)/M)^4*(N/F)^2*(3/4 : ℝ)^4*
      ((175/1000 : ℝ)*M/N)^(4*r)*d^(2*r)*y^(4*r-1) <
      (1734/1000 : ℝ)*(4*d/N)^r*y^(2*r+1) := by
  have hs : 0 < Real.sqrt (r:ℝ) := Real.sqrt_pos.mpr (by exact_mod_cast (by omega : 0<r))
  have hfac : 0 < ((8537/1000 : ℝ)/M)^4*(N/F)^2*(3/4 : ℝ)^4*
      (M/N)^(4*r)*d^(2*r)*y^(4*r-1) := by positivity
  have hh := mul_lt_mul_of_pos_left (section45_exponential_bound_printed hr) hfac
  apply (mul_lt_mul_iff_right₀ hs).mp
  have hfirst : (((8537/1000 : ℝ)/M)^4*(N/F)^2*(3/4 : ℝ)^4*
      ((175/1000 : ℝ)*M/N)^(4*r)*d^(2*r)*y^(4*r-1))*Real.sqrt r <
      ((8537/1000 : ℝ)/M)^4*(N/F)^2*(3/4 : ℝ)^4*
      ((1832/10000 : ℝ)*M/N)^(4*r)*d^(2*r)*y^(4*r-1) := by
    convert hh using 1 <;> simp only [mul_pow,div_pow] <;> ring
  convert hfirst.trans (h417.trans h415) using 1 <;> ring

/-- Both rounded constants in (4.22), before using d>|N_alpha|. -/
theorem exact_equation422_before_norm {N d y F M : ℝ} {r : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hy : 0 < y) (hF : 0 < F) (hM : 0 < M)
    (hr : 1 ≤ r)
    (hh : ((8537/1000 : ℝ)/M)^4*(N/F)^2*(3/4 : ℝ)^4*
      ((175/1000 : ℝ)*M/N)^(4*r)*d^(2*r)*y^(4*r-1) <
      (1734/1000 : ℝ)*(4*d/N)^r*y^(2*r+1)) :
    (22725/100000 : ℝ)*d/(F^2*N)*
      ((23447/100000000 : ℝ)*M^4*d*y^2/N^3)^(r-1) < 1 := by
  have hratio := (div_lt_one (by positivity :
    0<(1734/1000 : ℝ)*(4*d/N)^r*y^(2*r+1))).mpr hh
  rw [case45_division_identity (ne_of_gt hN) (ne_of_gt hd) (ne_of_gt hy)
    (ne_of_gt hF) (ne_of_gt hM) (by norm_num) (by norm_num) hr] at hratio
  have hc : (22725/100000 : ℝ) ≤
      (8537/1000)^4*(3/4)^4*(175/1000)^4/(4*(1734/1000)) := by norm_num
  have hb : (23447/100000000 : ℝ) ≤ (175/1000)^4/4 := by norm_num
  have hcoeff := mul_le_mul_of_nonneg_right hc (by positivity : 0 ≤ d/(F^2*N))
  have hbase := mul_le_mul_of_nonneg_right hb (by positivity : 0 ≤ M^4*d*y^2/N^3)
  have hp := pow_le_pow_left₀ (by positivity) hbase (r-1)
  have hm := mul_le_mul hcoeff hp (by positivity) (by positivity)
  apply lt_of_le_of_lt _ hratio
  convert hm using 1 <;> ring

/-- The displayed (4.22), retaining F until Proposition 3.1(b) sets F=1. -/
theorem exact_equation422 {N d y F M : ℝ} {r : ℕ} (hN : 0 < N)
    (hNd : N < d) (hF : 0 < F)
    (hh : (22725/100000 : ℝ)*d/(F^2*N)*
      ((23447/100000000 : ℝ)*M^4*d*y^2/N^3)^(r-1) < 1) :
    (22725/100000 : ℝ)/F^2*
      ((23447/100000000 : ℝ)*M^4*d*y^2/N^3)^(r-1) < 1 := by
  have hd : 0 < d := hN.trans hNd
  have hc : (22725/100000 : ℝ)/F^2 ≤ (22725/100000 : ℝ)*d/(F^2*N) := by
    apply (div_le_div_iff₀ (sq_pos_of_pos hF) (mul_pos (sq_pos_of_pos hF) hN)).mpr
    nlinarith only [mul_le_mul_of_nonneg_left hNd.le (by positivity : 0 ≤ (22725/100000 : ℝ)*F^2)]
  apply lt_of_le_of_lt _ hh
  apply mul_le_mul_of_nonneg_right hc
  apply pow_nonneg
  positivity

end «JNT-2024».Section4
