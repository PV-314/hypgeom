module

public import «JNT-2024».DenominatorBounds
public import «JNT-2024».DenominatorContent
public import «JNT-2024».DenominatorDefinitions
public import «JNT-2024».GammaBounds
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Calculations

open Hypergeometric

/-- The normalized quantities in the finite calculation of Lemma 2.3(a). -/
noncomputable def normalizedDenominatorValue (G : ℕ → ℚ) (d : ℤ) (r : ℕ) : ℝ :=
  (G r : ℝ) * denominator4 r / numeratorContent4 d r /
    (Real.exp (42 / 25) / twoAdicScale4 d) ^ r

/-- CALC-001 in reports/CALCULATIONS.md. An explicitly recorded computational
input, NOT a proved theorem, axiom, or instance. A proof using this calculation
must take a named hypothesis of this type. The numerical evidence is retained
in audit/denominator-maxima-values.json; kernel certification is waived by the
user. Existing proofs of the published upper bounds remain unchanged. -/
structure Lemma23aFiniteMaxima : Prop where
  bounds : ∀ (d : ℤ), d ≠ 0 → ∀ (r : ℕ), r < 139 →
    normalizedDenominatorValue gammaRatio d r ≤
      128 * Real.sqrt 2 / Real.exp (126 / 25) ∧
    normalizedDenominatorValue gammaNumeratorRatio d r ≤
      (15015 / 512) * Real.sqrt 2 / Real.exp (126 / 25)
  strict_off_three : ∀ (d : ℤ), d ≠ 0 → ∀ (r : ℕ), r < 139 → r ≠ 3 →
    normalizedDenominatorValue gammaRatio d r <
      128 * Real.sqrt 2 / Real.exp (126 / 25) ∧
    normalizedDenominatorValue gammaNumeratorRatio d r <
      (15015 / 512) * Real.sqrt 2 / Real.exp (126 / 25)
  attained_at_three :
    normalizedDenominatorValue gammaRatio 2 3 =
      128 * Real.sqrt 2 / Real.exp (126 / 25) ∧
    normalizedDenominatorValue gammaNumeratorRatio 2 3 =
      (15015 / 512) * Real.sqrt 2 / Real.exp (126 / 25)

end Calculations
end «JNT-2024»
