module

public import «JNT-2024».ApproximationCriterion
public import «JNT-2024».DenominatorBounds
public import «JNT-2024».ImaginaryApproximation
public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».Section2Bounds
public import «JNT-2024».Section2Complex
public import «JNT-2024».Section2Gaussian
public import «JNT-2024».Section2Geometry
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Section2

theorem fourth_root_branch {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) :
    omega S u₁ u₂ ^ (1 / 4 : ℂ) =
      Complex.exp (Complex.I * ((omega S u₁ u₂).arg : ℂ) / 4) := by
  have hn : omega S u₁ u₂ ≠ 0 := by
    intro he
    have hh := omega_norm (u₁ := u₁) hS hu₂
    simp [he] at hh
  rw [Complex.cpow_def_of_ne_zero hn]
  have hl : Complex.log (omega S u₁ u₂) = ((omega S u₁ u₂).arg : ℂ) * Complex.I := by
    apply Complex.ext
    · simp [Complex.log_re, omega_norm hS hu₂]
    · simp [Complex.log_im]
  rw [hl]
  congr 1
  ring

/-- The actual corrected sequences, with precisely the constants of (2.7)–(2.10). -/
structure PaperApproximants (u₁ u₂ : ℤ) where
  k₀ : ℝ
  pr : ℕ → GaussianField
  qr : ℕ → GaussianField
  integral_p : ∀ r, IsIntegral ℤ (pr r)
  integral_q : ∀ r, IsIntegral ℤ (qr r)
  embed_p : ∀ r, gaussianEmbedding (pr r) = p u₁ u₂ r
  embed_q : ∀ r, gaussianEmbedding (qr r) = q u₁ u₂ r
  k₀_pos : 0 < k₀
  k₀_eq_1257 : k₀ = 1257 / 1000
  k₀_le_1257 : k₀ ≤ 1257 / 1000
  denominator_bound : ∀ r, ‖gaussianEmbedding (qr r)‖ < k₀ * Q (-1) u₁ u₂ ^ r
  error_bound : ∀ r, ‖gaussianEmbedding (qr r) * omega (-1) u₁ u₂ ^ (1 / 4 : ℂ) -
    gaussianEmbedding (pr r)‖ ≤ ell (-1) u₁ u₂ / E (-1) u₁ u₂ ^ r
  independent : ∀ r, pr r * qr (r + 1) - pr (r + 1) * qr r ≠ 0

/-- Section 2's constructions in the paper's Gaussian case, retaining the original hypotheses.
The sole external mathematical dependency is the cited denominator estimate. -/
theorem section2_constructions (hPrior : Hypergeometric.DenominatorEstimate4)
    {u₁ u₂ : ℤ} (_hU : IsIntegral ℤ (U (-1) u₁ u₂)) (hu₂ : u₂ ≠ 0)
    (hnear : ‖omega (-1) u₁ u₂ - 1‖ < 1) : Nonempty (PaperApproximants u₁ u₂) := by
  classical
  choose pr qr hip hiq hep heq using fun r => corrected_gaussian_integers (u₁ := u₁) hu₂ r
  refine ⟨{
    k₀ := 1257 / 1000
    pr := pr
    qr := qr
    integral_p := hip
    integral_q := hiq
    embed_p := hep
    embed_q := heq
    k₀_pos := by norm_num
    k₀_eq_1257 := rfl
    k₀_le_1257 := le_rfl
    denominator_bound := ?_
    error_bound := ?_
    independent := ?_ }⟩
  · intro r
    rw [heq]
    exact corrected_q_bound_fixed hPrior hu₂ hnear r
  · intro r
    rw [heq, hep]
    exact corrected_error_bound hPrior hu₂ hnear r
  · intro r he
    have hh := congrArg gaussianEmbedding he
    simp only [map_sub, map_mul, map_zero, hep, heq, sub_eq_zero] at hh
    exact corrected_determinant_ne hu₂ r hh

/-- The constructed sequences satisfy Lemma 2.1 as soon as its printed conditions `E,Q>1` hold. -/
theorem PaperApproximants.apply_lemma21 {u₁ u₂ : ℤ} (data : PaperApproximants u₁ u₂)
    (hu₂ : u₂ ≠ 0) (p₀ q₀ : GaussianField)
    (hp : IsIntegral ℤ p₀) (hq : IsIntegral ℤ q₀) (hpq : ¬ (p₀ = 0 ∧ q₀ = 0))
    (hE : 1 < E (-1) u₁ u₂) (hQ : 1 < Q (-1) u₁ u₂)
    {c : ℝ} (hc : 0 < c) (hc1 : c < 1) :
    let r := Approximation.firstIndex (Q := Q (-1) u₁ u₂) (ℓ := ell (-1) u₁ u₂)
      hE hc (gaussianEmbedding q₀)
    (1 - c / E (-1) u₁ u₂) / (data.k₀ * Q (-1) u₁ u₂ ^ (r + 1)) <
      ‖gaussianEmbedding q₀ * omega (-1) u₁ u₂ ^ (1 / 4 : ℂ) - gaussianEmbedding p₀‖ ∧
    (data.pr r * q₀ - data.qr r * p₀ ≠ 0 →
      (1 - c) / (data.k₀ * Q (-1) u₁ u₂ ^ r) <
        ‖gaussianEmbedding q₀ * omega (-1) u₁ u₂ ^ (1 / 4 : ℂ) - gaussianEmbedding p₀‖) := by
  exact Approximation.lemma21 (by norm_num : (-1 : ℤ) < 0)
    (omega (-1) u₁ u₂ ^ (1 / 4 : ℂ)) p₀ q₀ data.pr data.qr hp hq data.integral_p data.integral_q hpq
    data.k₀_pos (ell_pos (by norm_num) hu₂) hE hQ hc hc1
    data.denominator_bound data.error_bound data.independent

end Section2
end «JNT-2024»
