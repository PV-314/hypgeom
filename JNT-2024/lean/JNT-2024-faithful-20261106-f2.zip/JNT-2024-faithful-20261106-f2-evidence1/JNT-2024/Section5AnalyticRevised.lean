module

public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Pow.Real
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section5Revised

/-- The elementary inequality printed in the proof of the new Lemma 5.4. -/
theorem cubic_product_bound {s a : ℝ} (hs : 0 ≤ s) (ha : 0 ≤ a) :
    (s + a)^3 * (s - a) ≤ (27 / 16 : ℝ) * s^4 := by
  have hp : 0 ≤ (s - 2*a)^2 * (11*s^2 + 12*s*a + 4*a^2) := by positivity
  nlinarith only [hp]

/-- The two numerical comparisons printed immediately after that inequality. -/
theorem cubic_product_ratio {s a n : ℝ} (hs : 0 < s) (ha : 0 < a)
    (hn : 0 < n) (hn2 : n^2 = s^2-a^2) :
    (8 / (3 * Real.sqrt 3) : ℝ) ≤ 2*s^2/(n*(s+a)) ∧
      (3 / 2 : ℝ) < 8 / (3 * Real.sqrt 3) := by
  have h3 : 0 < Real.sqrt (3:ℝ) := Real.sqrt_pos.mpr (by norm_num)
  have h3sq : Real.sqrt (3:ℝ)^2=3 := Real.sq_sqrt (by norm_num)
  have hpoly := cubic_product_bound hs.le ha.le
  have hden : 0 < n*(s+a) := by positivity
  have hcross : 8*(n*(s+a)) ≤ 2*s^2*(3*Real.sqrt 3) := by
    apply (sq_le_sq₀ (by positivity) (by positivity)).mp
    simp only [mul_pow,h3sq,hn2]
    nlinarith only [hpoly]
  constructor
  · exact (div_le_div_iff₀ (by positivity) hden).mpr hcross
  · apply (lt_div_iff₀ (by positivity : (0:ℝ)<3*Real.sqrt 3)).mpr
    nlinarith only [h3sq,h3]

/-- The two signed-unit estimates in Lemma 5.4, before division by the norm. -/
theorem adjacent_lower_identity_bound {s a t u y : ℝ}
    (hs : 0 < s) (ha : 0 < a) (has : a < s) (ht : 0 < t) (hu : 0 < u)
    (hpell : t^2-s^2*u^2=4 ∨ t^2-s^2*u^2= -4)
    (hy : t^2+s^2*u^2-2*a*t*u ≤ 4*y) :
    2*u^2*s*(s-a)-4*(s-a)/s < 4*y := by
  have hsum : 0 < t+u*s := by positivity
  have hidentity : t^2+s^2*u^2-2*a*t*u =
      2*u^2*s*(s-a)+(t^2-s^2*u^2)-2*a*u*(t-u*s) := by ring
  have hproduct : (t-u*s)*(t+u*s)=t^2-s^2*u^2 := by ring
  have hsa : 0 < s-a := sub_pos.mpr has
  rcases hpell with hp | hp
  · have htus : u*s < t := by nlinarith only [hp,ht,hu,hs,mul_pos hu hs]
    have hrem : 0 < 4-2*a*u*(t-u*s) := by
      apply (mul_pos_iff_of_pos_right hsum).mp
      have he : (4-2*a*u*(t-u*s))*(t+u*s)=4*(t+u*s-2*a*u) := by
        linear_combination -2*a*u*hp
      rw [he]
      nlinarith only [mul_pos hu hsa,htus]
    have hfrac : 0 < 4*(s-a)/s := by positivity
    rw [hp] at hidentity
    linarith only [hy,hidentity,hrem,hfrac]
  · have htus : t < u*s := by nlinarith only [hp,ht,hu,hs,mul_pos hu hs]
    have hrem : -4*(s-a)/s < -4-2*a*u*(t-u*s) := by
      apply (div_lt_iff₀ hs).mpr
      apply (mul_lt_mul_iff_right₀ hsum).mp
      have he : ((-4-2*a*u*(t-u*s))*s)*(t+u*s)-(-4*(s-a))*(t+u*s)
          = 4*a*(u*s-t) := by linear_combination -2*a*u*s*hp
      nlinarith only [he,mul_pos (mul_pos (by norm_num : (0:ℝ)<4) ha)
        (sub_pos.mpr htus)]
    rw [hp] at hidentity
    simp only [neg_mul,neg_div] at hrem
    linarith only [hy,hidentity,hrem]

/-- Equation (5.6), in an equivalent division-free form. Only positivity of
the square root of |N_alpha| is needed; there is no |N_alpha|>=4 premise. -/
theorem adjacent_lower_bound {s a t u n y : ℝ}
    (hs : 0 < s) (ha : 0 < a) (has : a < s) (ht : 0 < t) (hu : 0 < u)
    (hn : 0 < n) (hn2 : n^2=s^2-a^2)
    (hpell : t^2-s^2*u^2=4 ∨ t^2-s^2*u^2= -4)
    (hy : t^2+s^2*u^2-2*a*t*u ≤ 4*y) :
    (3/2:ℝ)*n^3*u^2 < 4*s*y+4*n := by
  have hl := adjacent_lower_identity_bound hs ha has ht hu hpell hy
  have hc := cubic_product_ratio hs ha hn hn2
  have hr : (3/2:ℝ)*n*(s+a) < 2*s^2 := by
    have hh := hc.2.trans_le hc.1
    simpa only [mul_assoc] using (lt_div_iff₀ (by positivity : 0<n*(s+a))).mp hh
  have hns : n < s+a := by nlinarith only [hn2,hn,hs,ha,mul_pos hs ha]
  have hdiff : s-a < n := by nlinarith only [hn2,hn,hs,ha,has,mul_pos ha (sub_pos.mpr has)]
  have hl' := (lt_div_iff₀ hs).mp
    (show 4*(s-a)/s > 2*u^2*s*(s-a)-4*y by linarith only [hl])
  have hmul := mul_lt_mul_of_pos_right hr (mul_pos (sq_pos_of_pos hu) (sub_pos.mpr has))
  have he : n*(s+a)*(s-a)=n^3 := by
    calc
      _ = n*(s^2-a^2) := by ring
      _ = n*n^2 := by rw [hn2]
      _ = n^3 := by ring
  have he' := congrArg (fun x:ℝ => u^2*x) he
  nlinarith only [hl',hmul,he',hdiff]

/-- Combining (5.6) and the cutoff gives the printed strict bound 376. -/
theorem small_square_product_bound {s u n y M : ℝ}
    (hn : 0 < n) (hM : 0 < M)
    (hl : (3/2:ℝ)*n^3*u^2 < 4*s*y+4*n)
    (hcut : s*y*M^2 ≤ 137*n^3) (hMnorm : M^2 ≤ 4*n^2) :
    (u*M)^2 < 376 := by
  have hlow := mul_lt_mul_of_pos_right hl (sq_pos_of_pos hM)
  have hnorm := mul_le_mul_of_nonneg_left hMnorm (by positivity : 0 ≤ 4*n)
  have hfinal : (3/2:ℝ)*n^3*(u*M)^2 < 564*n^3 := by
    nlinarith only [hlow,hcut,hnorm]
  have hc := (mul_lt_mul_iff_right₀ (pow_pos hn 3)).mp
    (show n^3*((3/2:ℝ)*(u*M)^2) < n^3*564 by nlinarith only [hfinal])
  linarith

theorem even_product_le_eighteen {m : ℤ} (hm : Even m) (hpos : 0 ≤ m)
    (hbound : m^2 < 376) : m ≤ 18 := by
  obtain ⟨k,rfl⟩ := hm
  by_contra he
  have hk : 10 ≤ k := by omega
  nlinarith

end «JNT-2024».Section5Revised
