module

public import «JNT-2024».Integrality
public import «JNT-2024».Positivity
public import «JNT-2024».Sequence
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- Growth of a positive second-order recurrence from its first strict increase. -/
theorem recurrence_strictMono (f : ℕ → ℚ) (c : ℚ) (hc : 2 ≤ c)
    (hpos : ∀ n, 0 < f n) (hfirst : f 0 < f 1)
    (hrec : ∀ n, f (n + 2) = c * f (n + 1) - f n) : StrictMono f := by
  apply strictMono_nat_of_lt_succ
  intro n
  induction n with
  | zero => exact hfirst
  | succ n ih =>
    have hh := hrec n
    have hm := mul_nonneg (sub_nonneg.mpr hc) (le_of_lt (hpos (n + 1)))
    simpa [Nat.succ_eq_add_one] using (show f (n + 1) < f (n + 2) by nlinarith)

/-- Uniform positive terms force the consecutive differences to grow. -/
theorem recurrence_difference_lower_bound (f : ℕ → ℚ) (c : ℚ) (hc : 3 ≤ c)
    (hhalf : ∀ n, (1 : ℚ) / 2 ≤ f n)
    (hrec : ∀ n, f (n + 2) = c * f (n + 1) - f n) (n : ℕ) :
    (n : ℚ) / 2 + f 1 - f 0 ≤ f (n + 1) - f n := by
  induction n with
  | zero => simp
  | succ n ih =>
    have hh := hrec n
    have hf := hhalf (n + 1)
    have hm := mul_nonneg (sub_nonneg.mpr hc) (show 0 ≤ f (n + 1) by linarith)
    push_cast
    nlinarith

namespace Parameters

/-- The lower bound on the integral recurrence coefficient in Lemma 3.5(b). -/
theorem three_le_trace (P : Parameters) (h : P.Admissible) :
    3 ≤ ((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) / 2 := by
  have ht : 1 ≤ P.t ^ 2 := by nlinarith [h.t_pos]
  have hdu : 1 ≤ P.d * P.u ^ 2 := by
    have hh := mul_pos h.d_pos (sq_pos_of_pos h.u_pos)
    omega
  have hs : 6 ≤ P.t ^ 2 + P.d * P.u ^ 2 := by
    rcases h.pell with hp | hp <;> omega
  have hq : (6 : ℚ) ≤ (P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2 := by exact_mod_cast hs
  linarith

theorem three_halves_initial_lt_y_one (P : Parameters) (h : P.Admissible) :
    (3 / 2 : ℚ) * (P.b : ℚ) ^ 2 < P.y h.pell 1 := by
  have hc := P.three_le_trace h
  have hb : 0 < (P.b : ℚ) ^ 2 := sq_pos_of_pos (by exact_mod_cast h.b_pos)
  have hatu : 0 < (P.a : ℚ) * P.t * P.u := by
    exact mul_pos (mul_pos (by exact_mod_cast h.a_pos) (by exact_mod_cast h.t_pos))
      (by exact_mod_cast h.u_pos)
  have hm := mul_nonneg (sub_nonneg.mpr hc) (le_of_lt hb)
  rw [P.y_one]
  nlinarith

theorem y_zero_lt_y_one (P : Parameters) (h : P.Admissible) :
    P.y h.pell 0 < P.y h.pell 1 := by
  have hh := P.three_halves_initial_lt_y_one h
  rw [P.y_zero]
  nlinarith [sq_nonneg (P.b : ℚ)]

/-- Strict monotonicity for nonnegative indices, as asserted in Lemma 3.5(b). -/
theorem y_strictMono_nonnegative (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) : StrictMono (fun n : ℕ => P.y h.pell n) := by
  apply recurrence_strictMono _ (((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) / 2)
  · linarith [P.three_le_trace h]
  · intro n; exact P.y_pos h hn n
  · exact P.y_zero_lt_y_one h
  · intro n
    simpa [Nat.cast_add, Nat.cast_one, add_assoc] using P.y_recurrence h.pell ((n : ℤ) + 1)

theorem y_reverse_recurrence (P : Parameters) (h : P.Pell) (k : ℤ) :
    P.y h (k - 1) = ((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) / 2 * P.y h k
      - P.y h (k + 1) := by
  linarith [P.y_recurrence h k]

/-- The definition of `K` used in Lemma 3.5. -/
def IsNegativeCutoff (P : Parameters) (h : P.Pell) (K : ℤ) : Prop :=
  K < 0 ∧ (P.b : ℚ) ^ 2 < P.y h K ∧
    ∀ j : ℤ, K < j → j < 0 → P.y h j ≤ (P.b : ℚ) ^ 2

theorem y_cutoff_successor_le (P : Parameters) (h : P.Pell) (K : ℤ)
    (hK : P.IsNegativeCutoff h K) : P.y h (K + 1) ≤ (P.b : ℚ) ^ 2 := by
  by_cases heq : K + 1 = 0
  · rw [heq, P.y_zero]
  · exact hK.2.2 (K + 1) (by omega) (by have := hK.1; omega)

/-- The tail `y(K+1), y(K), y(K-1), ...` is strictly increasing. -/
theorem y_strictMono_negative_tail (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (K : ℤ) (hK : P.IsNegativeCutoff h.pell K) :
    StrictMono (fun n : ℕ => P.y h.pell (K + 1 - n)) := by
  apply recurrence_strictMono _ (((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) / 2)
  · linarith [P.three_le_trace h]
  · intro n; exact P.y_pos h hn _
  · simpa using lt_of_le_of_lt (P.y_cutoff_successor_le h.pell K hK) hK.2.1
  · intro n
    convert P.y_reverse_recurrence h.pell (K + 1 - ((n : ℤ) + 1)) using 1 <;>
      congr 1 <;> push_cast <;> ring_nf

/-- There is a negative-index term exceeding the initial square. -/
theorem exists_negative_above_initial (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) : ∃ n : ℕ, (P.b : ℚ) ^ 2 < P.y h.pell (-(n : ℤ)) := by
  let f : ℕ → ℚ := fun n => P.y h.pell (-(n : ℤ))
  have hrec : ∀ n, f (n + 2) =
      ((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) / 2 * f (n + 1) - f n := by
    intro n
    dsimp [f]
    convert P.y_reverse_recurrence h.pell (-((n : ℤ) + 1)) using 1 <;>
      congr 1
    ring_nf
  let m : ℕ := 4 * (P.b ^ 2).toNat
  have hcast : (m : ℚ) = 4 * (P.b : ℚ) ^ 2 := by
    have hb : ((P.b ^ 2).toNat : ℚ) = (P.b : ℚ) ^ 2 := by
      exact_mod_cast Int.toNat_of_nonneg (sq_nonneg P.b)
    simp [m, hb]
  have hbnd := recurrence_difference_lower_bound f _ (P.three_le_trace h)
    (fun n => P.one_half_le_y h hn _) hrec m
  have hf0 : f 0 = (P.b : ℚ) ^ 2 := by simp [f]
  have hf1 : 0 < f 1 := P.y_pos h hn _
  have hfm : 0 < f m := P.y_pos h hn _
  refine ⟨m + 1, ?_⟩
  change (P.b : ℚ) ^ 2 < f (m + 1)
  rw [hcast, hf0] at hbnd
  linarith

/-- The largest negative index above the initial square exists. -/
theorem exists_negative_cutoff (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) : ∃ K : ℤ, P.IsNegativeCutoff h.pell K := by
  have hex := P.exists_negative_above_initial h hn
  let n := Nat.find hex
  have hnval : (P.b : ℚ) ^ 2 < P.y h.pell (-(n : ℤ)) := Nat.find_spec hex
  have hnpos : 0 < n := by
    by_contra hle
    have hz : n = 0 := by omega
    simp [hz] at hnval
  refine ⟨-(n : ℤ), ?_, hnval, ?_⟩
  · exact neg_neg_of_pos (by exact_mod_cast hnpos)
  · intro j hnj hj
    have hcast : ((-j).toNat : ℤ) = -j := Int.toNat_of_nonneg (by omega)
    have hlt : (-j).toNat < n := by omega
    have hminimal := Nat.find_min hex hlt
    apply le_of_not_gt
    simpa [hcast] using hminimal

theorem negative_cutoff_unique (P : Parameters) (h : P.Pell) {K L : ℤ}
    (hK : P.IsNegativeCutoff h K) (hL : P.IsNegativeCutoff h L) : K = L := by
  rcases lt_trichotomy K L with hlt | heq | hgt
  · exact False.elim ((not_lt_of_ge (hK.2.2 L hlt hL.1)) hL.2.1)
  · exact heq
  · exact False.elim ((not_lt_of_ge (hL.2.2 K hgt hK.1)) hK.2.1)

/-- Lemma 3.5(b), with existence and uniqueness of its cutoff made explicit. -/
theorem lemma35b (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) :
    (∀ k : ℤ, ∃ n : ℤ, 0 < n ∧ 2 * P.y h.pell k = n) ∧
    StrictMono (fun n : ℕ => P.y h.pell n) ∧
    (∃! K : ℤ, P.IsNegativeCutoff h.pell K) ∧
    (∀ K : ℤ, P.IsNegativeCutoff h.pell K →
      StrictMono (fun n : ℕ => P.y h.pell (K + 1 - n))) := by
  refine ⟨P.two_y_positive_integer h hn, P.y_strictMono_nonnegative h hn, ?_,
    P.y_strictMono_negative_tail h hn⟩
  obtain ⟨K, hK⟩ := P.exists_negative_cutoff h hn
  exact ⟨K, hK, fun L hL => P.negative_cutoff_unique h.pell hL hK⟩

end Parameters
end «JNT-2024»
