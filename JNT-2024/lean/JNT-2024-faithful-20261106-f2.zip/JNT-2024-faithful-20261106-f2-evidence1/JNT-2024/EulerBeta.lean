module

public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

noncomputable def betaMoment (m n : ℕ) : ℂ :=
  ∫ t : ℝ in 0..1, (t : ℂ) ^ m * (1 - (t : ℂ)) ^ n

theorem betaMoment_eq_betaIntegral (m n : ℕ) :
    betaMoment m n = Complex.betaIntegral (m + 1) (n + 1) := by
  simp [betaMoment, Complex.betaIntegral]

theorem betaMoment_eq_factorial (m n : ℕ) :
    betaMoment m n = (m.factorial : ℂ) * n.factorial / (m + n + 1).factorial := by
  rw [betaMoment_eq_betaIntegral, Complex.betaIntegral_eq_Gamma_mul_div]
  · rw [show (m : ℂ) + 1 + (n + 1) = ((m + n + 1 : ℕ) : ℂ) + 1 by push_cast; ring]
    rw [Complex.Gamma_nat_eq_factorial, Complex.Gamma_nat_eq_factorial,
      Complex.Gamma_nat_eq_factorial]
  · simp only [Complex.add_re, Complex.natCast_re, Complex.one_re]; positivity
  · simp only [Complex.add_re, Complex.natCast_re, Complex.one_re]; positivity

noncomputable def eulerNormalizer (r : ℕ) : ℂ :=
  ((2 * r + 1).factorial : ℂ) / (r.factorial : ℂ) ^ 2

theorem eulerNormalizer_mul_betaMoment (r : ℕ) : eulerNormalizer r * betaMoment r r = 1 := by
  rw [eulerNormalizer, betaMoment_eq_factorial, show r + r + 1 = 2 * r + 1 by omega]
  have hf : (r.factorial : ℂ) ≠ 0 := by exact_mod_cast Nat.factorial_ne_zero r
  have hg : ((2 * r + 1).factorial : ℂ) ≠ 0 := by exact_mod_cast Nat.factorial_ne_zero _
  field_simp

theorem pochhammer_nat_succ_ne_zero (m j : ℕ) :
    (ascPochhammer ℂ j).eval ((m : ℂ) + 1) ≠ 0 := by
  have h := factorial_mul_ascPochhammer ℂ m j
  intro he
  rw [he, mul_zero] at h
  exact (by exact_mod_cast Nat.factorial_ne_zero (m + j) : ((m + j).factorial : ℂ) ≠ 0) h.symm

theorem eulerNormalizer_moment (r j : ℕ) :
    eulerNormalizer r * betaMoment (r + j) r =
      (ascPochhammer ℂ j).eval ((r : ℂ) + 1) / (ascPochhammer ℂ j).eval (2 * (r : ℂ) + 2) := by
  have h₁ := factorial_mul_ascPochhammer ℂ r j
  have h₂ := factorial_mul_ascPochhammer ℂ (2 * r + 1) j
  have hd := pochhammer_nat_succ_ne_zero (2 * r + 1) j
  have hf : (r.factorial : ℂ) ≠ 0 := by exact_mod_cast Nat.factorial_ne_zero r
  have hg : ((2 * r + 1).factorial : ℂ) ≠ 0 := by exact_mod_cast Nat.factorial_ne_zero _
  have hj : ((2 * r + 1 + j).factorial : ℂ) ≠ 0 := by exact_mod_cast Nat.factorial_ne_zero _
  have he : ((2 * r + 1 : ℕ) : ℂ) + 1 = 2 * r + 2 := by push_cast; ring
  rw [he] at h₂ hd
  rw [eulerNormalizer, betaMoment_eq_factorial,
    show r + j + r + 1 = 2 * r + 1 + j by omega, ← h₁, ← h₂]
  field_simp

end Hypergeometric
end «JNT-2024»
