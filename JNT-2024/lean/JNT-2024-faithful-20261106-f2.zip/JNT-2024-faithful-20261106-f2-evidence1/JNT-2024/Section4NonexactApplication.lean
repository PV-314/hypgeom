module

public import «JNT-2024».ApproximationCriterion
public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».Section2
public import «JNT-2024».Section2Complex
public import «JNT-2024».Section2Gaussian
public import «JNT-2024».Section2Geometry
public import «JNT-2024».Section4NonexactPublished
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

/-- Equations (4.10)--(4.11), starting from the actual Section 2 approximants
and Lemma 2.1(b), with the printed general c and f_k*f_l retained. -/
theorem nonexact_paper_bound {u₁ u₂ : ℤ} (data : Section2.PaperApproximants u₁ u₂)
    (hu₂ : u₂ ≠ 0) {p₀ q₀ : Section2.GaussianField}
    (hp : IsIntegral ℤ p₀) (hq : IsIntegral ℤ q₀) (hqne : q₀ ≠ 0)
    {N d y z F M c : ℝ} (hN : 0 < N) (hd : 0 < d) (hy : 0 < y)
    (hz : 0 < z) (hF : 0 < F) (hM : 0 < M)
    (hE : 1 < Section2.E (-1) u₁ u₂) (hQ : 1 < Section2.Q (-1) u₁ u₂)
    (hc : 0 < c) (hc1 : c < 1)
    (hQu : Section2.Q (-1) u₁ u₂ < (2147/100 : ℝ)*Real.sqrt d*y/M)
    (hnorm : ‖Section2.gaussianEmbedding q₀‖^4=F^2*y*z)
    (herror : ‖Section2.omega (-1) u₁ u₂^(1/4 : ℂ)-
        Section2.gaussianEmbedding p₀/Section2.gaussianEmbedding q₀‖ <
      2*Real.sqrt N/((3959/1000 : ℝ)*Real.sqrt d*z))
    (hne : let r := (Approximation.firstIndex (Q := Section2.Q (-1) u₁ u₂)
        (ℓ := Section2.ell (-1) u₁ u₂) hE hc (Section2.gaussianEmbedding q₀));
      data.pr r*q₀-data.qr r*p₀ ≠ 0) :
    let r := Approximation.firstIndex (Q := Section2.Q (-1) u₁ u₂)
      (ℓ := Section2.ell (-1) u₁ u₂) hE hc (Section2.gaussianEmbedding q₀)
    z^3 < (N*F)^2*((64/100 : ℝ)/(1-c))^4*((2147/100 : ℝ)/M)^(4*r)*
      d^(2*r-2)*y^(4*r+1) := by
  let r := Approximation.firstIndex (Q := Section2.Q (-1) u₁ u₂)
    (ℓ := Section2.ell (-1) u₁ u₂) hE hc (Section2.gaussianEmbedding q₀)
  have hr : 1 ≤ r := (Approximation.firstIndex_spec hE hc (Section2.gaussianEmbedding q₀)).1
  have ht : 0 < ‖Section2.gaussianEmbedding q₀‖ :=
    norm_pos_iff.mpr ((map_ne_zero Section2.gaussianEmbedding).mpr hqne)
  have hQp : 0 < Section2.Q (-1) u₁ u₂ := by linarith
  have hl := (data.apply_lemma21 hu₂ p₀ q₀ hp hq (by intro hh; exact hqne hh.2)
    hE hQ hc hc1).2 hne
  have he : ‖Section2.gaussianEmbedding q₀*Section2.omega (-1) u₁ u₂^(1/4 : ℂ)-
      Section2.gaussianEmbedding p₀‖ = ‖Section2.gaussianEmbedding q₀‖*
      ‖Section2.omega (-1) u₁ u₂^(1/4 : ℂ)-
        Section2.gaussianEmbedding p₀/Section2.gaussianEmbedding q₀‖ := by
    rw [← norm_mul]
    congr 1
    rw [mul_sub,mul_div_cancel₀ _ ((map_ne_zero Section2.gaussianEmbedding).mpr hqne)]
  rw [he] at hl
  have hu := nonexact_before_fourth hN hd hz ht data.k₀_pos data.k₀_le_1257 hQp hc1 hl herror
  have hfour := nonexact_fourth_power hN hd hy hz ht hQp hc1 hnorm hu
  exact nonexact_equation411 hN hd hy hF hM hQp hc1 hr hQu hfour

end «JNT-2024».Section4
