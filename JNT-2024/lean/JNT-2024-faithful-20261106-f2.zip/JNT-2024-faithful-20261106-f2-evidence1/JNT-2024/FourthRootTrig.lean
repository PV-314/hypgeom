module

public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- The four factors at the start of the printed proof of Lemma 3.7. -/
theorem fourth_power_four_factors (w z : ℂ) :
    w ^ 4 - z ^ 4 = (w - z) * (w - Complex.I * z) *
      (w + z) * (w + Complex.I * z) := by
  calc
    _ = (w - z) * (w + z) * (w ^ 2 + z ^ 2) := by ring
    _ = _ := by linear_combination (w - z) * (w + z) * z ^ 2 * Complex.I_sq

/-- Expansion of the other three factors; multiplication by w^(-3)
gives the geometric sum in the manuscript. -/
theorem fourth_power_geometric_factor (w z : ℂ) (hw : w ≠ 0) :
    w ^ 4 - z ^ 4 = (w - z) * w ^ 3 *
      ((z / w) ^ 3 + (z / w) ^ 2 + z / w + 1) := by
  have hsum : (w - Complex.I * z) * (w + z) * (w + Complex.I * z) =
      w ^ 3 + w ^ 2 * z + w * z ^ 2 + z ^ 3 := by
    linear_combination -(w + z) * z ^ 2 * Complex.I_sq
  calc
    _ = (w - z) * ((w - Complex.I * z) * (w + z) * (w + Complex.I * z)) := by
      rw [fourth_power_four_factors]
      ring
    _ = (w - z) * (w ^ 3 + w ^ 2 * z + w * z ^ 2 + z ^ 3) := by rw [hsum]
    _ = _ := by field_simp; ring

theorem unit_add_one_norm_sq {z : ℂ} (hz : ‖z‖ = 1) :
    ‖z + 1‖ ^ 2 = 2 + 2 * z.re := by
  have hs : z.re ^ 2 + z.im ^ 2 = 1 := by
    have h := Complex.sq_norm z
    rw [hz] at h
    simpa [Complex.normSq_apply, pow_two] using h.symm
  rw [Complex.sq_norm]
  simp only [Complex.normSq_apply, Complex.add_re, Complex.one_re,
    Complex.add_im, Complex.one_im, add_zero]
  nlinarith

/-- Equation (3.15), using the geometric sum and the unit-circle identity.
Here phi is the principal argument of z. -/
theorem fourth_geometric_sum_norm_sq {z : ℂ} (hz : ‖z‖ = 1) :
    ‖z ^ 3 + z ^ 2 + z + 1‖ ^ 2 =
      8 * Real.cos z.arg ^ 2 * (Real.cos z.arg + 1) := by
  have h0 : z ≠ 0 := norm_ne_zero_iff.mp (by rw [hz]; norm_num)
  have hc : Real.cos z.arg = z.re := by simpa [hz] using Complex.cos_arg h0
  have hs : z.re ^ 2 + z.im ^ 2 = 1 := by
    have h := Complex.sq_norm z
    rw [hz] at h
    simpa [Complex.normSq_apply, pow_two] using h.symm
  have hz2 : ‖z ^ 2‖ = 1 := by simp [norm_pow, hz]
  have h2 := unit_add_one_norm_sq hz2
  have h2' : ‖z ^ 2 + 1‖ ^ 2 = 4 * z.re ^ 2 := by
    have hre : (z ^ 2).re = z.re ^ 2 - z.im ^ 2 := by simp [pow_two]
    rw [hre] at h2
    nlinarith [h2]
  rw [show z ^ 3 + z ^ 2 + z + 1 = (z + 1) * (z ^ 2 + 1) by ring,
    norm_mul, mul_pow, unit_add_one_norm_sq hz, h2', hc]
  ring

/-- The chosen angle lies in the printed range and gives the printed exponential. -/
theorem unit_principal_exponential {z : ℂ} (hz : ‖z‖ = 1) :
    -Real.pi < z.arg ∧ z.arg ≤ Real.pi ∧ Complex.exp (z.arg * Complex.I) = z := by
  refine ⟨Complex.neg_pi_lt_arg z, Complex.arg_le_pi z, ?_⟩
  simpa [hz] using Complex.norm_mul_exp_arg_mul_I z

/-- The geometric sum written literally as the three exponentials in the paper. -/
theorem fourth_geometric_sum_exp {z : ℂ} (hz : ‖z‖ = 1) :
    z ^ 3 + z ^ 2 + z + 1 =
      Complex.exp (3 * (z.arg * Complex.I)) +
      Complex.exp (2 * (z.arg * Complex.I)) +
      Complex.exp (z.arg * Complex.I) + 1 := by
  rw [show (3 : ℂ) = (3 : ℕ) by norm_num,
    show (2 : ℂ) = (2 : ℕ) by norm_num,
    Complex.exp_nat_mul, Complex.exp_nat_mul, (unit_principal_exponential hz).2.2]

/-- The cosine quadrupling identity used in Lemma 3.7(b). -/
theorem cos_four_mul_published (φ : ℝ) :
    Real.cos (4 * φ) = 8 * Real.cos φ ^ 4 - 8 * Real.cos φ ^ 2 + 1 := by
  rw [show 4 * φ = 2 * (2 * φ) by ring, Real.cos_two_mul, Real.cos_two_mul]
  ring

theorem fourth_exponential_sum_norm_sq {z : ℂ} (hz : ‖z‖ = 1) :
    ‖Complex.exp (3 * (z.arg * Complex.I)) +
      Complex.exp (2 * (z.arg * Complex.I)) +
      Complex.exp (z.arg * Complex.I) + 1‖ ^ 2 =
      8 * Real.cos z.arg ^ 2 * (Real.cos z.arg + 1) := by
  rw [← fourth_geometric_sum_exp hz]
  exact fourth_geometric_sum_norm_sq hz

/-- Squared chord substitution 2-2*cos(phi) in the published proof. -/
theorem rotated_unit_chord_sq {w z : ℂ} (hw : ‖w‖ = 1) (hz : ‖z‖ = 1) :
    ‖w - z‖ ^ 2 = 2 - 2 * Real.cos (z / w).arg := by
  have hw0 : w ≠ 0 := norm_ne_zero_iff.mp (by rw [hw]; norm_num)
  have hq : ‖z / w‖ = 1 := by simp [hw, hz]
  have hc : Real.cos (z / w).arg = (z / w).re := by
    rw [Complex.cos_arg (norm_ne_zero_iff.mp (by rw [hq]; norm_num)), hq, div_one]
  have hh := unit_add_one_norm_sq (show ‖-(z / w)‖ = 1 by simpa using hq)
  have he : w - z = w * (-(z / w) + 1) := by field_simp; ring
  rw [he, norm_mul, hw, one_mul, hh, hc]
  simp only [Complex.neg_re]
  ring

/-- The literal trigonometric product calculation of Lemma 3.7(a). -/
theorem fourth_chord_trig_product {w z : ℂ} (hw : ‖w‖ = 1) (hz : ‖z‖ = 1) :
    ‖w ^ 4 - z ^ 4‖ ^ 2 = ‖w - z‖ ^ 2 *
      (8 * Real.cos (z / w).arg ^ 2 * (Real.cos (z / w).arg + 1)) := by
  have hw0 : w ≠ 0 := norm_ne_zero_iff.mp (by rw [hw]; norm_num)
  rw [fourth_power_geometric_factor w z hw0, norm_mul, norm_mul, norm_pow,
    hw, one_pow, mul_one, mul_pow]
  have hq : ‖z / w‖ = 1 := by simp [hw, hz]
  rw [fourth_geometric_sum_exp hq, fourth_exponential_sum_norm_sq hq]

/-- Eliminate cos(phi) from (3.15) using the printed chord substitution. -/
theorem fourth_power_chord_identity_published {w z : ℂ} (hw : ‖w‖ = 1) (hz : ‖z‖ = 1) :
    ‖w ^ 4 - z ^ 4‖ ^ 2 = ‖w - z‖ ^ 2 * (2 - ‖w - z‖ ^ 2) ^ 2 *
      (4 - ‖w - z‖ ^ 2) := by
  rw [fourth_chord_trig_product hw hz, rotated_unit_chord_sq hw hz]
  ring

/-- The full monotonicity interval stated after (3.15). The substitution
s=sqrt(4-c^2) turns the displayed factor into s^3-2s. -/
theorem fourth_expansion_factor_strictAnti {x y : ℝ}
    (hx : 0 < x) (hxy : x < y) (hy : y < Real.sqrt (10 / 3)) :
    (2 - y ^ 2) * Real.sqrt (4 - y ^ 2) <
      (2 - x ^ 2) * Real.sqrt (4 - x ^ 2) := by
  have hb := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 10 / 3)
  have hb0 := Real.sqrt_nonneg (10 / 3 : ℝ)
  have hylim : y ^ 2 < 10 / 3 := by nlinarith
  have hy4 : 0 < 4 - y ^ 2 := by linarith
  have hx4 : 0 < 4 - x ^ 2 := by nlinarith
  have hsx := Real.sq_sqrt (le_of_lt hx4)
  have hsy := Real.sq_sqrt (le_of_lt hy4)
  have hsy0 := Real.sqrt_pos.mpr hy4
  have hsx0 := Real.sqrt_pos.mpr hx4
  have hlt : Real.sqrt (4 - y ^ 2) < Real.sqrt (4 - x ^ 2) := by nlinarith
  have hm := mul_pos (sub_pos.mpr hlt) hsy0
  have hsum : 0 < Real.sqrt (4 - x ^ 2) ^ 2 +
      Real.sqrt (4 - x ^ 2) * Real.sqrt (4 - y ^ 2) +
      Real.sqrt (4 - y ^ 2) ^ 2 - 2 := by nlinarith
  have hp := mul_pos (sub_pos.mpr hlt) hsum
  have heq (c : ℝ) (hs : Real.sqrt (4 - c ^ 2) ^ 2 = 4 - c ^ 2) :
      (2 - c ^ 2) * Real.sqrt (4 - c ^ 2) =
        Real.sqrt (4 - c ^ 2) ^ 3 - 2 * Real.sqrt (4 - c ^ 2) := by
    nlinarith [congrArg (fun t : ℝ => t * Real.sqrt (4 - c ^ 2)) hs]
  rw [heq x hsx, heq y hsy]
  nlinarith only [hp]

/-- The equality with cos(4phi) at the beginning of the printed proof of (b). -/
theorem fourth_chord_cos_four {w z : ℂ} (hw : ‖w‖ = 1) (hz : ‖z‖ = 1) :
    ‖w ^ 4 - z ^ 4‖ ^ 2 = 2 - 2 * Real.cos (4 * (z / w).arg) := by
  have hw0 : w ≠ 0 := norm_ne_zero_iff.mp (by rw [hw]; norm_num)
  have hq : ‖z / w‖ = 1 := by simp [hw, hz]
  have hpow : (z / w) ^ 4 = Complex.exp ((4 * (z / w).arg : ℝ) * Complex.I) := by
    rw [Complex.ofReal_mul, Complex.ofReal_ofNat, mul_assoc]
    rw [show (4 : ℂ) = (4 : ℕ) by norm_num, Complex.exp_nat_mul,
      (unit_principal_exponential hq).2.2]
  have hh := unit_add_one_norm_sq (z := -(z / w) ^ 4) (by simp [hw, hz])
  have hre : ((z / w) ^ 4).re = Real.cos (4 * (z / w).arg) := by
    rw [hpow, Complex.exp_ofReal_mul_I_re]
  rw [Complex.neg_re, hre] at hh
  have he : w ^ 4 - z ^ 4 = w ^ 4 * (-(z / w) ^ 4 + 1) := by field_simp; ring
  rw [he, norm_mul, norm_pow, hw, one_pow, one_mul, hh]
  ring

/-- The rational squared-chord expression displayed in Lemma 3.7(b). -/
theorem fourth_chord_quotient {w z : ℂ} (hw : ‖w‖ = 1) (hz : ‖z‖ = 1)
    (hres : 0 < ‖w ^ 4 - z ^ 4‖) :
    ‖w - z‖ ^ 2 = ‖w ^ 4 - z ^ 4‖ ^ 2 /
      (8 * Real.cos (z / w).arg ^ 2 * (Real.cos (z / w).arg + 1)) ∧
    ‖w - z‖ ^ 2 = (2 - 2 * Real.cos (4 * (z / w).arg)) /
      (8 * Real.cos (z / w).arg ^ 2 * (Real.cos (z / w).arg + 1)) := by
  have he := fourth_chord_trig_product hw hz
  have hd : 0 < 8 * Real.cos (z / w).arg ^ 2 * (Real.cos (z / w).arg + 1) := by
    have hp : 0 < ‖w - z‖ ^ 2 *
        (8 * Real.cos (z / w).arg ^ 2 * (Real.cos (z / w).arg + 1)) := by
      rw [← he]
      exact sq_pos_of_pos hres
    exact pos_of_mul_pos_right hp (sq_nonneg _)
  have h := (eq_div_iff (ne_of_gt hd)).mpr he.symm
  exact ⟨h, by rw [← fourth_chord_cos_four hw hz]; exact h⟩

/-- The polynomial conversion in (b), obtained from the cosine quadrupling
identity rather than the earlier algebraic chord factorization. -/
theorem fourth_power_chord_identity_cos_four {w z : ℂ} (hw : ‖w‖ = 1) (hz : ‖z‖ = 1) :
    ‖w ^ 4 - z ^ 4‖ ^ 2 = ‖w - z‖ ^ 2 * (2 - ‖w - z‖ ^ 2) ^ 2 *
      (4 - ‖w - z‖ ^ 2) := by
  rw [fourth_chord_cos_four hw hz, cos_four_mul_published,
    rotated_unit_chord_sq hw hz]
  ring

/-- The quartic in the squared chord, before the conversion to degree eight. -/
def fourthChordSquaredPolynomial (c x : ℝ) : ℝ :=
  x ^ 4 - 8 * x ^ 3 + 20 * x ^ 2 - 16 * x + c ^ 2

theorem fourth_chord_quotient_polynomial {w z : ℂ} (hw : ‖w‖ = 1) (hz : ‖z‖ = 1)
    (hres : 0 < ‖w ^ 4 - z ^ 4‖) :
    fourthChordSquaredPolynomial ‖w ^ 4 - z ^ 4‖
      (‖w ^ 4 - z ^ 4‖ ^ 2 /
        (8 * Real.cos (z / w).arg ^ 2 * (Real.cos (z / w).arg + 1))) = 0 := by
  rw [← (fourth_chord_quotient hw hz hres).1]
  unfold fourthChordSquaredPolynomial
  have hh := fourth_power_chord_identity_cos_four hw hz
  nlinarith only [hh]

/-- The chord polynomial identity using the displayed quotient and quartic
conversion, as in the printed proof of Lemma 3.7(b). -/
theorem fourth_power_chord_identity_b_published {w z : ℂ}
    (hw : ‖w‖ = 1) (hz : ‖z‖ = 1) (hres : 0 < ‖w ^ 4 - z ^ 4‖) :
    ‖w ^ 4 - z ^ 4‖ ^ 2 = ‖w - z‖ ^ 2 * (2 - ‖w - z‖ ^ 2) ^ 2 *
      (4 - ‖w - z‖ ^ 2) := by
  have hh := fourth_chord_quotient_polynomial hw hz hres
  rw [← (fourth_chord_quotient hw hz hres).1] at hh
  unfold fourthChordSquaredPolynomial at hh
  nlinarith only [hh]

end «JNT-2024»
