module

public import «JNT-2024».ApproximationCriterion
public import «JNT-2024».ApproximationProofDetails
public import «JNT-2024».ComplexRepresentation
public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».Sequence
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

theorem imaginaryEmbedding_norm_sq (S : ℤ) (hS : S ≤ 0) (z : QuadraticAlgebra ℚ (S : ℚ) 0) :
    ‖imaginaryEmbedding S hS z‖ ^ 2 = ((QuadraticAlgebra.norm z : ℚ) : ℝ) := by
  have hs : Real.sqrt (-(S : ℝ)) ^ 2 = -(S : ℝ) :=
    Real.sq_sqrt (by exact_mod_cast neg_nonneg.mpr hS)
  rw [← Complex.normSq_eq_norm_sq]
  simp only [imaginaryEmbedding, RingHom.coe_mk, MonoidHom.coe_mk, OneHom.coe_mk,
    Complex.normSq_apply, QuadraticAlgebra.norm]
  push_cast
  nlinarith only [congrArg (fun t : ℝ => (z.im : ℝ) ^ 2 * t) hs]

theorem imaginary_integer_norm_ge_one {S : ℤ} (hS : S < 0)
    {z : QuadraticAlgebra ℚ (S : ℚ) 0} (hz : IsIntegral ℤ z) (hne : z ≠ 0) :
    1 ≤ ‖imaginaryEmbedding S hS.le z‖ := by
  let : Fact (¬ IsSquare S) := ⟨by rintro ⟨v, hv⟩; nlinarith [sq_nonneg v]⟩
  let P : Parameters := ⟨0, 0, S, 0, 0⟩
  let : NumberField (QuadraticAlgebra ℚ (S : ℚ) 0) := Parameters.numberField P
  let e : NumberField.RingOfIntegers P.Algebra := ⟨z, hz⟩
  have hn : ((Algebra.norm ℤ e : ℤ) : ℚ) = QuadraticAlgebra.norm z := by
    exact (Algebra.coe_norm_int e).trans (P.algebra_norm_eq z)
  have he := imaginaryEmbedding_norm_sq S hS.le z
  have hne' : imaginaryEmbedding S hS.le z ≠ 0 := (map_ne_zero (imaginaryEmbedding S hS.le)).mpr hne
  have hpos : (0 : ℝ) < (Algebra.norm ℤ e : ℤ) := by
    have hn' : ((Algebra.norm ℤ e : ℤ) : ℝ) = ((QuadraticAlgebra.norm z : ℚ) : ℝ) := by exact_mod_cast hn
    rw [hn', ← he]
    exact sq_pos_of_pos (norm_pos_iff.mpr hne')
  have hi : (1 : ℤ) ≤ Algebra.norm ℤ e := by
    have hh : (0 : ℤ) < Algebra.norm ℤ e := by exact_mod_cast hpos
    omega
  have hi' : (1 : ℝ) ≤ (Algebra.norm ℤ e : ℤ) := by exact_mod_cast hi
  have hn' : ((Algebra.norm ℤ e : ℤ) : ℝ) = ((QuadraticAlgebra.norm z : ℚ) : ℝ) := by exact_mod_cast hn
  rw [hn', ← he] at hi'
  nlinarith [norm_nonneg (imaginaryEmbedding S hS.le z)]

namespace Approximation

/-- Lemma 2.1 in the coordinate model of an arbitrary imaginary quadratic field.
All arithmetic discreteness hypotheses are proved from integrality. -/
theorem lemma21 {S : ℤ} (hS : S < 0) (θ : ℂ)
    (p q : QuadraticAlgebra ℚ (S : ℚ) 0) (pr qr : ℕ → QuadraticAlgebra ℚ (S : ℚ) 0)
    (hp : IsIntegral ℤ p) (hq : IsIntegral ℤ q)
    (hpr : ∀ r, IsIntegral ℤ (pr r)) (hqr : ∀ r, IsIntegral ℤ (qr r))
    (hpq : ¬ (p = 0 ∧ q = 0))
    {k ℓ E Q c : ℝ} (hk : 0 < k) (hℓ : 0 < ℓ) (hE : 1 < E) (hQ : 1 < Q)
    (hc : 0 < c) (hc1 : c < 1)
    (hqb : ∀ r, ‖imaginaryEmbedding S hS.le (qr r)‖ < k * Q ^ r)
    (herr : ∀ r, ‖imaginaryEmbedding S hS.le (qr r) * θ - imaginaryEmbedding S hS.le (pr r)‖ ≤ ℓ / E ^ r)
    (hind : ∀ r, pr r * qr (r + 1) - pr (r + 1) * qr r ≠ 0) :
    let f := imaginaryEmbedding S hS.le
    let r := firstIndex (Q := Q) (ℓ := ℓ) hE hc (f q)
    (1 - c / E) / (k * Q ^ (r + 1)) < ‖f q * θ - f p‖ ∧
      (pr r * q - qr r * p ≠ 0 → (1 - c) / (k * Q ^ r) < ‖f q * θ - f p‖) := by
  let : Fact (¬ IsSquare S) := ⟨by rintro ⟨v, hv⟩; nlinarith [sq_nonneg v]⟩
  let f := imaginaryEmbedding S hS.le
  have hf : Function.Injective f := f.injective
  have hpq' : ¬ (f p = 0 ∧ f q = 0) := by
    rintro ⟨hp', hq'⟩
    exact hpq ⟨hf (by simpa using hp'), hf (by simpa using hq')⟩
  have hind' : ∀ r, f (pr r) * f (qr (r + 1)) - f (pr (r + 1)) * f (qr r) ≠ 0 := by
    intro r
    simpa only [← map_mul, ← map_sub] using (map_ne_zero f).mpr (hind r)
  have hdiscrete : ∀ r, f (pr r) * f q - f (qr r) * f p ≠ 0 →
      1 ≤ ‖f (pr r) * f q - f (qr r) * f p‖ := by
    intro r hne
    rw [← map_mul, ← map_mul, ← map_sub] at hne ⊢
    exact imaginary_integer_norm_ge_one hS ((hpr r).mul hq |>.sub ((hqr r).mul hp))
      (fun he => hne (by rw [he, map_zero]))
  have hh := lemma21_complex_published hk hℓ hE hQ hc hc1 hpq' hqb herr hind' hdiscrete
    (firstIndex_spec (Q := Q) (ℓ := ℓ) hE hc (f q)).2
  refine ⟨hh.1, fun hne => hh.2 ?_⟩
  simpa only [map_mul, map_sub, f] using (map_ne_zero f).mpr hne

end Approximation
end «JNT-2024»
