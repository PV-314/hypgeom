module

public import «JNT-2024».DenominatorContent
public import «JNT-2024».DenominatorDefinitions
public import «JNT-2024».HypergeometricPolynomials
public import «JNT-2024».Section2Polynomial
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

open Polynomial

theorem coefficient4_top_ne_zero (r : ℕ) : coefficient (1 / 4) r r ≠ 0 := by
  unfold coefficient
  apply div_ne_zero
  · apply mul_ne_zero
    · apply Finset.prod_ne_zero_iff.mpr
      intro i hi
      have hi' : (i : ℚ) < r := by exact_mod_cast Finset.mem_range.mp hi
      linarith
    · apply Finset.prod_ne_zero_iff.mpr
      intro i hi
      have hi' : (i : ℚ) < r := by exact_mod_cast Finset.mem_range.mp hi
      linarith
  · apply mul_ne_zero
    · apply Finset.prod_ne_zero_iff.mpr
      intro i _
      have hi : (0 : ℚ) ≤ i := Nat.cast_nonneg i
      linarith
    · exact_mod_cast r.factorial_ne_zero

theorem integralPolynomial4_natDegree (r : ℕ) : (integralPolynomial4 r).natDegree = r := by
  apply Polynomial.natDegree_eq_of_le_of_coeff_ne_zero (integralPolynomial4_natDegree_le r)
  rw [integralPolynomial4_coeff]
  intro he
  have hh := integralCoefficient4_cast r r
  rw [he, Int.cast_zero] at hh
  exact mul_ne_zero (by exact_mod_cast denominator4_ne_zero r) (coefficient4_top_ne_zero r) hh.symm

theorem contentPolynomial4_natDegree {d : ℤ} (hd : d ≠ 0) (r : ℕ)
    {δ : ℂ} (hδ : δ ^ 2 = d) : (contentPolynomial4 d r δ).natDegree = r := by
  have hδ0 : δ ≠ 0 := by
    intro he
    rw [he, zero_pow (by decide : 2 ≠ 0)] at hδ
    exact hd (by exact_mod_cast hδ.symm)
  have hN : (numeratorContent4 d r : ℂ) ≠ 0 := by exact_mod_cast ne_of_gt (numeratorContent4_pos d r)
  have hlin : (1 - Polynomial.X : Polynomial ℤ).natDegree = 1 := by
    apply Polynomial.natDegree_eq_of_le_of_coeff_ne_zero
      ((Polynomial.natDegree_sub_le _ _).trans (by simp))
    norm_num [Polynomial.coeff_sub, Polynomial.coeff_one, Polynomial.coeff_X]
  rw [contentPolynomial4, Polynomial.natDegree_C_mul (inv_ne_zero hN),
    Polynomial.natDegree_comp, Polynomial.natDegree_C_mul_X _ hδ0,
    Polynomial.natDegree_map_eq_of_injective Int.cast_injective,
    shiftedIntegralPolynomial4, Polynomial.natDegree_comp, hlin, integralPolynomial4_natDegree]
  simp

theorem contentPolynomial4_ne_zero (d : ℤ) (r : ℕ) (δ : ℂ) : contentPolynomial4 d r δ ≠ 0 := by
  have h₀ : (contentPolynomial4 d r δ).coeff 0 ≠ 0 := by
    rw [contentPolynomial4_coeff, pow_zero, mul_one]
    exact div_ne_zero
      (by exact_mod_cast shiftedIntegralPolynomial4_coeff_zero_ne r)
      (by exact_mod_cast ne_of_gt (numeratorContent4_pos d r))
  intro he
  exact h₀ (by rw [he, Polynomial.coeff_zero])

theorem contentPolynomial4_degree_eq {d : ℤ} (hd : d ≠ 0) (r : ℕ)
    {δ : ℂ} (hδ : δ ^ 2 = d) : (contentPolynomial4 d r δ).degree = (r : WithBot ℕ) := by
  rw [Polynomial.degree_eq_natDegree (contentPolynomial4_ne_zero d r δ), contentPolynomial4_natDegree hd r hδ]

/-- Every coefficient belongs to `ℤ[√sf(d)]`, with the chosen root `δ / squareFactor d`. -/
theorem contentPolynomial4_coeff_in_order {d : ℤ} (hd : d ≠ 0) (r j : ℕ)
    {δ : ℂ} (hδ : δ ^ 2 = d) :
    ∃ a b : ℤ, (contentPolynomial4 d r δ).coeff j = a + b * (δ / (squareFactor d : ℂ)) := by
  have hN : (numeratorContent4 d r : ℂ) ≠ 0 := by exact_mod_cast ne_of_gt (numeratorContent4_pos d r)
  have hc : (squareFactor d : ℂ) ≠ 0 := by exact_mod_cast ne_of_gt (squareFactor_pos hd)
  have hdiv := (numeratorContent4_dvd_iff d r (numeratorContent4 d r)).mp dvd_rfl j
  let n : ℤ := scaledIntegralCoefficient4 d r j / numeratorContent4 d r
  have hn : (scaledIntegralCoefficient4 d r j : ℂ) = (numeratorContent4 d r : ℂ) * n := by
    exact_mod_cast (Int.mul_ediv_cancel' hdiv).symm
  have he : (contentPolynomial4 d r δ).coeff j = (n : ℂ) * (δ / (squareFactor d : ℂ)) ^ (j % 2) := by
    rw [contentPolynomial4_coeff, root_power_parity hδ]
    have hw : ((shiftedIntegralPolynomial4 r).coeff j : ℂ) * (d : ℂ) ^ (j / 2) *
        (squareFactor d : ℂ) ^ (j % 2) = (numeratorContent4 d r : ℂ) * n := by
      simpa only [scaledIntegralCoefficient4, Int.cast_mul, Int.cast_pow] using hn
    rw [div_pow]
    apply (div_eq_iff hN).mpr
    field_simp
    linear_combination δ ^ (j % 2) * hw
  by_cases hj : j % 2 = 0
  · exact ⟨n, 0, by simpa [hj] using he⟩
  · have hj' : j % 2 = 1 := by omega
    exact ⟨0, n, by simpa [hj'] using he⟩

end Hypergeometric
end «JNT-2024»
