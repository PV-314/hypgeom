module

public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».Sequence
public import «JNT-2024».SequenceRepresentations
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- The unsquared-unit sequence used only in Lemma 3.10. -/
def unitX (P : Parameters) (A B : ℤ) (n : ℕ) : ℚ :=
  ((⟨(A : ℚ), (B : ℚ)⟩ : P.Algebra) * P.epsilon ^ n).re

def unitY (P : Parameters) (A B : ℤ) (n : ℕ) : ℚ :=
  ((⟨(A : ℚ), (B : ℚ)⟩ : P.Algebra) * P.epsilon ^ n).im

theorem unit_coordinates_zero (P : Parameters) (A B : ℤ) :
    P.unitX A B 0 = A ∧ P.unitY A B 0 = B := by
  simp [unitX, unitY]

theorem unit_coordinates_one (P : Parameters) (A B : ℤ) :
    P.unitX A B 1 = (A * P.t + B * P.d * P.u) / 2 ∧
    P.unitY A B 1 = (A * P.u + B * P.t) / 2 := by
  constructor <;> simp [unitX, unitY, epsilon] <;> ring

/-- Equation (3.32), x coordinate. -/
theorem unitX_recurrence (P : Parameters) (A B : ℤ) (n : ℕ) :
    P.unitX A B (n + 2) = P.t * P.unitX A B (n + 1) - P.epsilonNorm * P.unitX A B n := by
  simp only [unitX, QuadraticAlgebra.re_mul]
  rw [P.epsilon_re_recurrence, P.epsilon_im_recurrence]
  ring

/-- Equation (3.32), y coordinate. -/
theorem unitY_recurrence (P : Parameters) (A B : ℤ) (n : ℕ) :
    P.unitY A B (n + 2) = P.t * P.unitY A B (n + 1) - P.epsilonNorm * P.unitY A B n := by
  simp only [unitY, QuadraticAlgebra.im_mul, zero_mul, add_zero]
  rw [P.epsilon_re_recurrence, P.epsilon_im_recurrence]
  ring

/-- Equation (3.33), proved from its two initial cases and the printed recurrence. -/
theorem unit_inverse_one (P : Parameters) (A B : ℤ) (n : ℕ) :
    P.u * P.unitX A B (n + 1) - P.t * P.unitY A B (n + 1) = -2 * P.epsilonNorm * P.unitY A B n ∧
    P.t * P.unitX A B (n + 1) - P.d * P.u * P.unitY A B (n + 1) = 2 * P.epsilonNorm * P.unitX A B n := by
  induction n using Nat.twoStepInduction with
  | zero => constructor <;> simp [unitX, unitY, epsilon, epsilonNorm] <;> ring
  | one => constructor <;> simp [unitX, unitY, pow_succ, epsilon, epsilonNorm] <;> ring
  | more n h₀ h₁ =>
    have hx := P.unitX_recurrence A B (n + 1)
    have hy := P.unitY_recurrence A B (n + 1)
    constructor
    · linear_combination (P.u : ℚ) * hx - (P.t : ℚ) * hy + (P.t : ℚ) * h₁.1 -
        P.epsilonNorm * h₀.1 + 2 * P.epsilonNorm * P.unitY_recurrence A B n
    · linear_combination (P.t : ℚ) * hx - (P.d : ℚ) * P.u * hy + (P.t : ℚ) * h₁.2 -
        P.epsilonNorm * h₀.2 - 2 * P.epsilonNorm * P.unitX_recurrence A B n

theorem unit_inverse_two_clear (P : Parameters) (A B : ℤ) (n : ℕ) :
    2 * P.t * P.u * P.unitX A B (n + 2) - ((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) * P.unitY A B (n + 2) =
      -4 * P.epsilonNorm ^ 2 * P.unitY A B n ∧
    ((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) * P.unitX A B (n + 2) - 2 * P.d * P.t * P.u * P.unitY A B (n + 2) =
      4 * P.epsilonNorm ^ 2 * P.unitX A B n := by
  have h₁ := P.unit_inverse_one A B n
  have h₂ := P.unit_inverse_one A B (n + 1)
  constructor
  · linear_combination (P.u : ℚ) * h₂.2 + (P.t : ℚ) * h₂.1 + 2 * P.epsilonNorm * h₁.1
  · linear_combination (P.t : ℚ) * h₂.2 + (P.d : ℚ) * P.u * h₂.1 + 2 * P.epsilonNorm * h₁.2

theorem unit_inverse_three_clear (P : Parameters) (A B : ℤ) (n : ℕ) :
    P.u * (3 * (P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) * P.unitX A B (n + 3) -
      P.t * ((P.t : ℚ) ^ 2 + 3 * P.d * (P.u : ℚ) ^ 2) * P.unitY A B (n + 3) =
        -8 * P.epsilonNorm ^ 3 * P.unitY A B n ∧
    P.t * ((P.t : ℚ) ^ 2 + 3 * P.d * (P.u : ℚ) ^ 2) * P.unitX A B (n + 3) -
      P.d * P.u * (3 * (P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) * P.unitY A B (n + 3) =
        8 * P.epsilonNorm ^ 3 * P.unitX A B n := by
  have h₁ := P.unit_inverse_one A B n
  have h₂ := P.unit_inverse_two_clear A B (n + 1)
  constructor
  · linear_combination (P.u : ℚ) * h₂.2 + (P.t : ℚ) * h₂.1 + 4 * P.epsilonNorm ^ 2 * h₁.1
  · linear_combination (P.t : ℚ) * h₂.2 + (P.d : ℚ) * P.u * h₂.1 + 4 * P.epsilonNorm ^ 2 * h₁.2

/-- Equation (3.34), with the printed rational coefficients. -/
theorem unit_inverse_two (P : Parameters) (hp : P.Pell) (A B : ℤ) (n : ℕ) :
    (P.t * P.u / P.epsilonNorm) * P.unitX A B (n + 2) -
      (((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) / (2 * P.epsilonNorm)) * P.unitY A B (n + 2) =
        -2 * P.epsilonNorm * P.unitY A B n ∧
    (((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) / (2 * P.epsilonNorm)) * P.unitX A B (n + 2) -
      (P.d * P.t * P.u / P.epsilonNorm) * P.unitY A B (n + 2) =
        2 * P.epsilonNorm * P.unitX A B n := by
  have hh := P.unit_inverse_two_clear A B n
  have hn : P.epsilonNorm ≠ 0 := by rcases P.pell_iff_epsilonNorm.mp hp with he | he <;> simp [he]
  constructor
  · field_simp
    nlinarith only [hh.1]
  · field_simp
    nlinarith only [hh.2]

/-- Equation (3.35), obtained by a further application of (3.33). -/
theorem unit_inverse_three (P : Parameters) (hp : P.Pell) (A B : ℤ) (n : ℕ) :
    (P.u * (3 * (P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) / (4 * P.epsilonNorm ^ 2)) * P.unitX A B (n + 3) -
      (P.t * ((P.t : ℚ) ^ 2 + 3 * P.d * (P.u : ℚ) ^ 2) / (4 * P.epsilonNorm ^ 2)) * P.unitY A B (n + 3) =
        -2 * P.epsilonNorm * P.unitY A B n ∧
    (P.t * ((P.t : ℚ) ^ 2 + 3 * P.d * (P.u : ℚ) ^ 2) / (4 * P.epsilonNorm ^ 2)) * P.unitX A B (n + 3) -
      (P.d * P.u * (3 * (P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) / (4 * P.epsilonNorm ^ 2)) * P.unitY A B (n + 3) =
        2 * P.epsilonNorm * P.unitX A B n := by
  have hh := P.unit_inverse_three_clear A B n
  have hn : P.epsilonNorm ≠ 0 := by rcases P.pell_iff_epsilonNorm.mp hp with he | he <;> simp [he]
  constructor
  · field_simp
    nlinarith only [hh.1]
  · field_simp
    nlinarith only [hh.2]

end «JNT-2024».Parameters
