module

public import «JNT-2024».ApproximationAlgebra
public import «JNT-2024».ApproximationCriterion
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Approximation

/-- The literal two-positive-summands identity in the nonzero-determinant case
of the proof of Lemma 2.1, page 5. -/
theorem lemma21_constant_identity {E Q c : ℝ} (hE : 1 < E) (hQ : 1 < Q) :
    Q * (1 - c * ((Q - 1) / (Q - 1 / E))) - (1 - c / E) =
      (1 - c) * (Q - 1) + c * (E - 1) / (E ^ 2 * (Q - 1 / E)) := by
  have hE0 : 0 < E := by linarith
  have hd : 0 < Q - 1 / E := by
    have hi := (div_lt_one hE0).mpr hE
    linarith
  have hQE : -1 + Q * E ≠ 0 := by nlinarith
  field_simp [ne_of_gt hE0, ne_of_gt hd]
  ring_nf
  field_simp [hQE]
  ring

/-- Keep the printed ratio when passing from the cutoff at r to the error at r+1. -/
theorem lemma21_successor_cutoff_bound {E Q ℓ c : ℝ} {q : ℂ} {r : ℕ}
    (hE : 1 < E) (hQ : 1 < Q) (hcut : Cutoff E Q ℓ c q r) :
    ℓ / E ^ (r + 1) * ‖q‖ < c * ((Q - 1) / (E * (Q - 1 / E))) := by
  have hE0 : 0 < E := by linarith
  have hh := (div_lt_div_iff_of_pos_right hE0).mpr (cutoff_error_bound hE hQ hcut)
  rw [pow_succ]
  convert hh using 1 <;> simp only [div_eq_mul_inv, mul_inv_rev] <;> ring

/-- The final displayed fraction and strict comparison in the zero-determinant case. -/
theorem lemma21_successor_fraction {E Q c : ℝ} (hE : 1 < E) (hQ : 1 < Q)
    (hc : 0 < c) :
    1 - c * ((Q - 1) / (E * (Q - 1 / E))) =
      (Q * E - 1 - c * Q + c) / (Q * E - 1) ∧
    1 - c / E < (Q * E - 1 - c * Q + c) / (Q * E - 1) := by
  have hE0 : 0 < E := by linarith
  have hd : 0 < Q - 1 / E := by
    have hi := (div_lt_one hE0).mpr hE
    linarith
  have hQE : Q * E - 1 ≠ 0 := by nlinarith
  have heq : 1 - c * ((Q - 1) / (E * (Q - 1 / E))) =
      (Q * E - 1 - c * Q + c) / (Q * E - 1) := by
    field_simp [ne_of_gt hE0, ne_of_gt hd, hQE]
    ring
  refine ⟨heq, ?_⟩
  rw [← heq]
  have hh := mul_lt_mul_of_pos_left (cutoff_ratio_bounds hE hQ).2 (div_pos hc hE0)
  have hid : c * ((Q - 1) / (E * (Q - 1 / E))) =
      (c / E) * ((Q - 1) / (Q - 1 / E)) := by
    simp only [div_eq_mul_inv, mul_inv_rev]
    ring
  rw [hid]
  linarith

/-- The printed strict lower bound before the final successor-fraction comparison.
The determinant norm premise is supplied by integrality in `lemma21`. -/
theorem lemma21_successor_paper_bound {θ p q pr qr : ℂ} {k ℓ E Q c : ℝ} {r : ℕ}
    (hE : 1 < E) (hQ : 1 < Q) (hc : 0 < c) (hc1 : c < 1)
    (hcut : Cutoff E Q ℓ c q r) (hdet : 1 ≤ ‖pr * q - qr * p‖)
    (hq : ‖qr‖ < k * Q ^ (r + 1)) (herr : ‖qr * θ - pr‖ ≤ ℓ / E ^ (r + 1)) :
    1 - c * ((Q - 1) / (E * (Q - 1 / E))) <
      k * Q ^ (r + 1) * ‖q * θ - p‖ := by
  have hE0 : 0 < E := by linarith
  have hb := lemma21_successor_cutoff_bound hE hQ hcut
  have hr := (cutoff_ratio_bounds hE hQ).2
  have hm := mul_lt_mul_of_pos_left hr (div_pos hc hE0)
  have hid : c * ((Q - 1) / (E * (Q - 1 / E))) =
      (c / E) * ((Q - 1) / (Q - 1 / E)) := by
    simp only [div_eq_mul_inv, mul_inv_rev]
    ring
  have hcE : c / E < 1 := (div_lt_one hE0).mpr (by linarith)
  have hbudget : ℓ / E ^ (r + 1) * ‖q‖ < 1 := by rw [hid] at hb; nlinarith
  have hh := determinant_error_bound hdet hq herr hbudget
  linarith

/-- Lemma 2.1 using the printed successor-index bound and displayed fraction.
The original shorter argument remains unchanged as `lemma21_complex`. All
hypotheses and conclusions agree; the actual successor determinant supplies
the norm premise of the printed estimate. -/
theorem lemma21_complex_published {θ p q : ℂ} {pr qr : ℕ → ℂ} {k ℓ E Q c : ℝ} {r : ℕ}
    (hk : 0 < k) (_hℓ : 0 < ℓ) (hE : 1 < E) (hQ : 1 < Q) (hc : 0 < c) (hc1 : c < 1)
    (hpq : ¬ (p = 0 ∧ q = 0))
    (hq : ∀ i, ‖qr i‖ < k * Q ^ i) (herr : ∀ i, ‖qr i * θ - pr i‖ ≤ ℓ / E ^ i)
    (hind : ∀ i, pr i * qr (i + 1) - pr (i + 1) * qr i ≠ 0)
    (hdiscrete : ∀ i, pr i * q - qr i * p ≠ 0 → 1 ≤ ‖pr i * q - qr i * p‖)
    (hcut : Cutoff E Q ℓ c q r) :
    (1 - c / E) / (k * Q ^ (r + 1)) < ‖q * θ - p‖ ∧
      (pr r * q - qr r * p ≠ 0 → (1 - c) / (k * Q ^ r) < ‖q * θ - p‖) := by
  have hQ0 : 0 < Q := by linarith
  have hratio := cutoff_ratio_bounds hE hQ
  have hbudget := cutoff_error_bound hE hQ hcut
  have hbudgetc : ℓ / E ^ r * ‖q‖ < c := lt_trans hbudget (by nlinarith only [hratio.2, hc])
  have hcase : pr r * q - qr r * p ≠ 0 →
      1 - c * ((Q - 1) / (Q - 1 / E)) < (k * Q ^ r) * ‖q * θ - p‖ := by
    intro hne
    have hh := determinant_error_bound (hdiscrete r hne) (hq r) (herr r) (lt_trans hbudgetc hc1)
    linarith only [hh, hbudget]
  constructor
  · apply (div_lt_iff₀ (mul_pos hk (pow_pos hQ0 _))).mpr
    by_cases hne : pr r * q - qr r * p ≠ 0
    · have hh := mul_lt_mul_of_pos_left (hcase hne) hQ0
      have hcst := cutoff_constant_comparison hE hQ hc hc1
      rw [pow_succ]
      nlinarith only [hh, hcst]
    · have hne' := next_determinant_ne_zero p q (pr r) (qr r) (pr (r + 1)) (qr (r + 1))
        hpq (hind r) (not_ne_iff.mp hne)
      have hh := lemma21_successor_paper_bound hE hQ hc hc1 hcut
        (hdiscrete (r + 1) hne') (hq (r + 1)) (herr (r + 1))
      obtain ⟨heq, hcompare⟩ := lemma21_successor_fraction hE hQ hc
      rw [heq] at hh
      simpa only [mul_comm] using hcompare.trans hh
  · intro hne
    apply (div_lt_iff₀ (mul_pos hk (pow_pos hQ0 _))).mpr
    have hh := determinant_error_bound (hdiscrete r hne) (hq r) (herr r) (lt_trans hbudgetc hc1)
    nlinarith only [hh, hbudgetc]

end Approximation
end «JNT-2024»
