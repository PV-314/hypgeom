module

public import «JNT-2024».NormalizerBounds
public import «JNT-2024».NormalizerFormula
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».Section5ResidueTransfer
public import «JNT-2024».Section6Families
public import «JNT-2024».Sequence
public import «JNT-2024».SmallUnitBounds
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section6

theorem gcd16_square_odd {r : ℤ} (hr : r % 2 = 1) : Int.gcd 16 (r^2) = 1 := by
  rw [Section5.gcd_square_residue r 16 (by decide)]
  have hc : ∀ v : ZMod 16, v.val % 2 = 1 → Nat.gcd 16 (v.val^2) = 1 := by decide +kernel
  apply hc
  have hv := ZMod.val_intCast (n := 16) r
  omega

theorem gcd16_square_four {r : ℤ} (hr : r % 4 = 0) : Int.gcd 16 (r^2) = 16 := by
  rw [Section5.gcd_square_residue r 16 (by decide)]
  have hc : ∀ v : ZMod 16, v.val % 4 = 0 → Nat.gcd 16 (v.val^2) = 16 := by decide +kernel
  apply hc
  have hv := ZMod.val_intCast (n := 16) r
  omega

theorem unitOne_two_normalizer (r : ℤ) :
    (unitOne 2 (2*r)).baseGcd = 4 ∧
    (unitOne 2 (2*r)).normalizerSquare = 16 * Int.gcd 16 (r^2) := by
  have hd : (2*r)^2+4 = 4*(r^2+1) := by ring
  have hG : (unitOne 2 (2*r)).baseGcd = 4 := by
    simp [Parameters.baseGcd, unitOne, hd]
  have hN : (unitOne 2 (2*r)).normAlpha = -(r^2)*4 := by
    simp [Parameters.normAlpha, unitOne]; ring
  have hq : (unitOne 2 (2*r)).normQuotient = -(r^2) := by
    rw [Parameters.normQuotient, hN, hG]
    exact Int.mul_ediv_cancel _ (by norm_num)
  refine ⟨hG, ?_⟩
  simp only [Parameters.normalizerSquare, hG, hq, Int.natAbs_neg,
    Int.gcd_eq_natAbs_gcd_natAbs]
  rfl

theorem unitTwo_one_normalizer (r : ℤ) :
    (unitTwo 1 r).baseGcd = 1 ∧
    (unitTwo 1 r).normalizerSquare = 4 * Int.gcd 16 (r^2) := by
  have hG : (unitTwo 1 r).baseGcd = 1 := by simp [Parameters.baseGcd, unitTwo]
  have hN : (unitTwo 1 r).normAlpha = -(r^2) := by simp [Parameters.normAlpha, unitTwo]
  have hq : (unitTwo 1 r).normQuotient = -(r^2) := by simp [Parameters.normQuotient, hN, hG]
  refine ⟨hG, ?_⟩
  simp only [Parameters.normalizerSquare, hG, hq, Int.natAbs_neg,
    Int.gcd_eq_natAbs_gcd_natAbs]
  rfl

theorem families65_68_normalizers (j : ℕ) :
    (family65 j).baseGcd = 4 ∧ (family65 j).normalizerSquare = 16 ∧
    (family66 j).baseGcd = 4 ∧ (family66 j).normalizerSquare = 256 ∧
    (family67 j).baseGcd = 1 ∧ (family67 j).normalizerSquare = 4 ∧
    (family68 j).baseGcd = 1 ∧ (family68 j).normalizerSquare = 64 := by
  have hh := pellPair_properties j
  have hm : pellP j-1 = 2*((pellP j-1)/2) := by omega
  have hp : pellP j+1 = 2*((pellP j+1)/2) := by omega
  have hodd : ((pellP j-1)/2)%2 = 1 := by omega
  have hfour : ((pellP j+1)/2)%4 = 0 := by omega
  have hm1 := unitOne_two_normalizer ((pellP j-1)/2)
  have hp1 := unitOne_two_normalizer ((pellP j+1)/2)
  have hm2 := unitTwo_one_normalizer ((pellP j-1)/2)
  have hp2 := unitTwo_one_normalizer ((pellP j+1)/2)
  rw [gcd16_square_odd hodd] at hm1 hm2
  rw [gcd16_square_four hfour] at hp1 hp2
  norm_num at hm1 hp1 hm2 hp2
  have h65 : (family65 j).baseGcd = 4 ∧ (family65 j).normalizerSquare = 16 := by
    unfold family65
    rw [hm]
    exact hm1
  have h66 : (family66 j).baseGcd = 4 ∧ (family66 j).normalizerSquare = 256 := by
    unfold family66
    rw [hp]
    exact hp1
  exact ⟨h65.1, h65.2, h66.1, h66.2, hm2.1, hm2.2, hp2.1, hp2.2⟩

/-- A division-free test for the original (unmaximized) Proposition 4.1 cutoff. -/
theorem coefficient_below_cutoff (P : Parameters) (hd : 0 < P.d)
    (hn : P.normAlpha < 0) (hB : 0 < P.normalizerSquare) {c : ℝ} (hc : 0 < c)
    (hi : c^2 * (P.normalizerSquare : ℝ)^2 * P.d < 137^2 * |(P.normAlpha : ℝ)|) :
    c * |(P.normAlpha : ℝ)| <
      137 * |(P.normAlpha : ℝ)| * Real.sqrt |(P.normAlpha : ℝ)| /
        (Real.sqrt (P.d : ℝ) * P.normalizerSquare) := by
  have hd' : (0 : ℝ) < P.d := by exact_mod_cast hd
  have hB' : (0 : ℝ) < P.normalizerSquare := by exact_mod_cast hB
  have hN : (0 : ℝ) < |(P.normAlpha : ℝ)| := abs_pos.mpr (by exact_mod_cast ne_of_lt hn)
  apply (lt_div_iff₀ (mul_pos (Real.sqrt_pos.mpr hd') hB')).mpr
  apply (sq_lt_sq₀ (by positivity) (by positivity)).mp
  have hh := mul_lt_mul_of_pos_right hi (sq_pos_of_pos hN)
  simp only [mul_pow, Real.sq_sqrt hd'.le, Real.sq_sqrt hN.le]
  nlinarith only [hh]

end «JNT-2024».Section6
