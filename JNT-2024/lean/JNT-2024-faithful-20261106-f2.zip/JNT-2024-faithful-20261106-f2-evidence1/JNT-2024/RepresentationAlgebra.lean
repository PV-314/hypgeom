module

public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».Sequence
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- Equation (3.1), allowing arbitrary algebraic integers `ε`, not just units. -/
def RepresentsSquare (P : Parameters) (x y : ℤ) : Prop :=
  (⟨(x : ℚ), (y : ℚ) ^ 2⟩ : P.Algebra) = P.alpha * P.epsilon ^ 2

/-- Equation (3.9). -/
theorem representation_x (P : Parameters) {x y : ℤ} (h : P.RepresentsSquare x y) :
    4 * x = P.a * (P.t ^ 2 + P.d * P.u ^ 2) + 2 * P.b ^ 2 * P.d * P.t * P.u := by
  have hx := congrArg QuadraticAlgebra.re h
  simp [alpha, epsilon, pow_two] at hx
  have hq : (4 : ℚ) * x = P.a * ((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) +
      2 * (P.b : ℚ) ^ 2 * P.d * P.t * P.u := by nlinarith [hx]
  exact_mod_cast hq

/-- The middle expression of equation (3.4). -/
theorem representation_y (P : Parameters) {x y : ℤ} (h : P.RepresentsSquare x y) :
    4 * y ^ 2 = 2 * P.a * P.t * P.u + P.b ^ 2 * P.t ^ 2 + P.b ^ 2 * P.d * P.u ^ 2 := by
  have hy := congrArg QuadraticAlgebra.im h
  simp [alpha, epsilon, pow_two] at hy
  have hq : (4 : ℚ) * (y : ℚ) ^ 2 = 2 * P.a * P.t * P.u +
      (P.b : ℚ) ^ 2 * (P.t : ℚ) ^ 2 + (P.b : ℚ) ^ 2 * P.d * (P.u : ℚ) ^ 2 := by
    nlinarith [hy]
  exact_mod_cast hq

/-- The integer norm required in Proposition 3.1 follows from integrality alone. -/
theorem exists_integer_epsilonNorm (P : Parameters) [Fact (¬ IsSquare P.d)]
    (hi : IsIntegral ℤ P.epsilon) : ∃ n : ℤ, (n : ℚ) = P.epsilonNorm := by
  let e : NumberField.RingOfIntegers P.Algebra := ⟨P.epsilon, hi⟩
  exact ⟨Algebra.norm ℤ e, (Algebra.coe_norm_int e).trans P.field_norm_epsilon⟩

theorem four_dvd_epsilon_discriminant (P : Parameters) [Fact (¬ IsSquare P.d)]
    (hi : IsIntegral ℤ P.epsilon) : 4 ∣ P.t ^ 2 - P.d * P.u ^ 2 := by
  obtain ⟨n, hn⟩ := P.exists_integer_epsilonNorm hi
  refine ⟨n, ?_⟩
  have hq : (P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2 = 4 * n := by
    unfold epsilonNorm at hn
    linarith
  exact_mod_cast hq

/-- The two candidates `r₁'`, `r₁''` are indexed by the sign `σ=±1`. -/
def repCandidate (P : Parameters) (y σ : ℤ) : ℤ := P.t * P.b ^ 2 + P.a * P.u + σ * 2 * P.b * y

theorem repCandidate_product (P : Parameters) {x y : ℤ} (h : P.RepresentsSquare x y) :
    P.repCandidate y 1 * P.repCandidate y (-1) = P.u ^ 2 * P.normAlpha := by
  have hy := congrArg (fun z : ℤ => P.b ^ 2 * z) (P.representation_y h)
  dsimp [repCandidate, normAlpha]
  nlinarith only [hy]

theorem repCandidate_ne_zero (P : Parameters) {x y σ : ℤ}
    (h : P.RepresentsSquare x y) (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0)
    (hσ : σ = 1 ∨ σ = -1) : P.repCandidate y σ ≠ 0 := by
  have hn : P.repCandidate y 1 * P.repCandidate y (-1) ≠ 0 := by
    rw [P.repCandidate_product h]
    exact mul_ne_zero (pow_ne_zero _ hu) hN
  rcases hσ with rfl | rfl
  · exact (mul_ne_zero_iff.mp hn).1
  · exact (mul_ne_zero_iff.mp hn).2

/-- The quadratic algebra in `√Nα`, distinct from the original algebra in `√d`. -/
abbrev NormAlgebra (P : Parameters) := QuadraticAlgebra ℚ (P.normAlpha : ℚ) 0

def repBeta (P : Parameters) : P.NormAlgebra := ⟨(P.a : ℚ), 1⟩
def repGamma (P : Parameters) (x : ℤ) : P.NormAlgebra := ⟨(x : ℚ), P.epsilonNorm⟩
def repMiddle (P : Parameters) : P.NormAlgebra :=
  ⟨(P.a : ℚ) * P.u + (P.b : ℚ) ^ 2 * P.t, -(P.u : ℚ)⟩
def repRoot (P : Parameters) (y σ : ℤ) : P.NormAlgebra :=
  ⟨(P.repCandidate y σ : ℚ), -(P.u : ℚ)⟩














/-- The second square identity on p. 13, valid for either sign. -/
theorem representation_second_square (P : Parameters) {x y σ : ℤ}
    (h : P.RepresentsSquare x y) (hσ : σ ^ 2 = 1) :
    P.repRoot y σ ^ 2 = (2 * (P.repCandidate y σ : ℚ)) • P.repMiddle := by
  have hy : (4 : ℚ) * (y : ℚ) ^ 2 = 2 * P.a * P.t * P.u +
      (P.b : ℚ) ^ 2 * (P.t : ℚ) ^ 2 + (P.b : ℚ) ^ 2 * P.d * (P.u : ℚ) ^ 2 := by
    exact_mod_cast P.representation_y h
  have hs : (σ : ℚ) ^ 2 = 1 := by exact_mod_cast hσ
  have hys := congrArg (fun z : ℚ => (P.b : ℚ) ^ 2 * z) hy
  have hss := congrArg (fun z : ℚ => 4 * (P.b : ℚ) ^ 2 * (y : ℚ) ^ 2 * z) hs
  unfold repRoot repMiddle
  ext <;> simp only [pow_two, QuadraticAlgebra.re_mul, QuadraticAlgebra.im_mul,
    QuadraticAlgebra.re_smul, QuadraticAlgebra.im_smul] <;> simp [repCandidate, normAlpha]
  · nlinarith only [hys, hss]
  · ring















/-- The companion norm identity giving the second equality in (3.2). -/
theorem representation_companion (P : Parameters) {x y σ : ℤ}
    (h : P.RepresentsSquare x y) (hσ : σ ^ 2 = 1) :
    P.repCandidate y σ ^ 2 - P.normAlpha * P.u ^ 2 =
      σ * 4 * P.b * y * P.repCandidate y σ := by
  have hy := congrArg (fun z : ℤ => P.b ^ 2 * z) (P.representation_y h)
  have hs := congrArg (fun z : ℤ => 4 * P.b ^ 2 * y ^ 2 * z) hσ
  dsimp [repCandidate, normAlpha]
  nlinarith only [hy, hs]

end «JNT-2024».Parameters
