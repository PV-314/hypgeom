module

public import «JNT-2024».Section62
public import «JNT-2024».Section69
public import «JNT-2024».Section6Limits
public import «JNT-2024».Sequence
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Analysis.SpecificLimits.Basic
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Fib.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.FinCases
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

open Filter Topology

namespace «JNT-2024».Section6

theorem family62a_infinite :
    Set.Infinite (Set.range (fun j : ℕ => family62a (2*(j : ℤ)+5))) := by
  apply Set.infinite_range_of_injective
  intro i j he
  have hi := quarterSquare_spec (show 5 ≤ 2*(i : ℤ)+5 by omega)
    (show Odd (2*(i : ℤ)+5) from ⟨(i : ℤ)+2,by ring⟩)
  have hj := quarterSquare_spec (show 5 ≤ 2*(j : ℤ)+5 by omega)
    (show Odd (2*(j : ℤ)+5) from ⟨(j : ℤ)+2,by ring⟩)
  have ha := congrArg Parameters.a he
  dsimp [family62a,unitTwo] at ha
  have hs : (2*(i : ℤ)+5)^2=(2*(j : ℤ)+5)^2 := by omega
  have hh := (sq_eq_sq₀ (by positivity : 0 ≤ 2*(i : ℤ)+5) (by positivity : 0 ≤ 2*(j : ℤ)+5)).mp hs
  omega

theorem square_parameter62 (j : ℕ) :
    5 < (20*(j : ℤ)+9)^2 ∧ (20*(j : ℤ)+9)^2 % 4 = 1 ∧ ¬ 5 ∣ (20*(j : ℤ)+9)^2 := by
  have hj : (0 : ℤ) ≤ j := by positivity
  have he : (20*(j : ℤ)+9)^2=400*(j : ℤ)^2+360*j+81 := by ring
  refine ⟨by nlinarith,?_,?_⟩
  · rw [he]; omega
  · intro hd
    have hm := Int.emod_eq_zero_of_dvd hd
    rw [he] at hm
    omega

theorem family62b_square_norm (j : ℕ) :
    (family62b ((20*(j : ℤ)+9)^2)).normAlpha = -(20*(j : ℤ)+9)^2 := by
  have hh := square_parameter62 j
  exact (family62b_published hh.1 hh.2.1 hh.2.2).2.2.2.1

theorem family62b_infinite :
    Set.Infinite (Set.range (fun j : ℕ => family62b ((20*(j : ℤ)+9)^2))) := by
  apply Set.infinite_range_of_injective
  intro i j he
  have hn := congrArg Parameters.normAlpha he
  rw [family62b_square_norm,family62b_square_norm] at hn
  have hs : (20*(i : ℤ)+9)^2=(20*(j : ℤ)+9)^2 := by omega
  have hh := (sq_eq_sq₀ (by positivity : 0 ≤ 20*(i : ℤ)+9) (by positivity : 0 ≤ 20*(j : ℤ)+9)).mp hs
  omega


theorem family69_infinite :
    Set.Infinite (Set.range (fun j : ℕ => family69 (5*(j : ℤ)+4))) := by
  apply Set.infinite_range_of_injective
  intro i j he
  have ht := congrArg Parameters.t he
  dsimp [family69,unitOne] at ht
  have hs : (5*(i : ℤ)+4)^2=(5*(j : ℤ)+4)^2 := by omega
  have hh := (sq_eq_sq₀ (by positivity : 0 ≤ 5*(i : ℤ)+4) (by positivity : 0 ≤ 5*(j : ℤ)+4)).mp hs
  omega

theorem squareNorm69_infinite :
    Set.Infinite (Set.range (fun j : ℕ => squareNorm69 ((j : ℤ)+2))) := by
  apply Set.infinite_range_of_injective
  intro i j he
  have ht := congrArg Parameters.t he
  dsimp [squareNorm69,unitOne] at ht
  rcases lt_trichotomy i j with hij | hij | hij
  · have hle : (i : ℤ)+2 ≤ (j : ℤ)+2 := by omega
    have hp := pow_le_pow_left₀ (show 0 ≤ (i : ℤ)+2 by positivity) hle 3
    have hlt : (i : ℤ) < j := by exact_mod_cast hij
    nlinarith
  · exact hij
  · have hle : (j : ℤ)+2 ≤ (i : ℤ)+2 := by omega
    have hp := pow_le_pow_left₀ (show 0 ≤ (j : ℤ)+2 by positivity) hle 3
    have hlt : (j : ℤ) < i := by exact_mod_cast hij
    nlinarith


theorem family69_from_above {n : ℤ} (hn : 3 ≤ n) :
    (1/4 : ℝ) < ((family69 n).y (family69_admissible hn).pell (-1) : ℝ) /
      |((family69 n).normAlpha : ℝ)| := by
  rw [family69_ratio hn]
  exact quadratic_ratio_above (by exact_mod_cast (show 1 ≤ n by omega))

theorem squareNorm69_from_above {n : ℤ} (hn : 2 ≤ n) :
    (1/4 : ℝ) < ((squareNorm69 n).y (squareNorm69_admissible hn).pell (-1) : ℝ) /
      |((squareNorm69 n).normAlpha : ℝ)| := by
  rw [squareNorm69_ratio hn]
  exact square_norm_ratio_above (by exact_mod_cast (show 1 ≤ n by omega))


end «JNT-2024».Section6
