module

public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

noncomputable def binomialCoefficient (a : ℂ) (j : ℕ) : ℂ :=
  (ascPochhammer ℂ j).eval a / j.factorial

theorem binomialCoefficient_eq_choose (a : ℂ) (j : ℕ) :
    binomialCoefficient a j = Ring.choose (a + j - 1) j := by
  rw [Ring.choose_eq_smul]
  simp only [smul_eq_mul, Polynomial.descPochhammer_smeval_eq_ascPochhammer,
    Polynomial.ascPochhammer_smeval_cast, Polynomial.ascPochhammer_smeval_eq_eval]
  simp only [show a + j - 1 - j + 1 = a by ring]
  unfold binomialCoefficient
  ring

theorem binomialKernel_hasSum (a : ℂ) {w : ℂ} (hw : ‖w‖ < 1) :
    HasSum (fun j : ℕ => binomialCoefficient a j * w ^ j) ((1 - w) ^ (-a)) := by
  have hh := (Complex.one_div_one_sub_cpow_hasFPowerSeriesOnBall_zero a).hasSum
    (y := w) (by simpa [Metric.mem_eball, edist_dist, enorm_eq_nnnorm] using
      (show (‖w‖₊ : ENNReal) < 1 by exact_mod_cast hw))
  simpa [FormalMultilinearSeries.ofScalars, binomialCoefficient_eq_choose,
    Complex.cpow_neg, one_div] using hh

theorem binomialKernel_summable_norm (a : ℂ) {w : ℂ} (hw : ‖w‖ < 1) :
    Summable (fun j : ℕ => ‖binomialCoefficient a j‖ * ‖w‖ ^ j) := by
  let p := FormalMultilinearSeries.ofScalars ℂ (fun j : ℕ => Ring.choose (a + j - 1) j)
  have hr : 1 ≤ p.radius := (Complex.one_div_one_sub_cpow_hasFPowerSeriesOnBall_zero a).r_le
  have hb : w ∈ Metric.eball (0 : ℂ) p.radius := by
    apply lt_of_lt_of_le _ hr
    simpa [edist_dist, enorm_eq_nnnorm] using
      (show (‖w‖₊ : ENNReal) < 1 by exact_mod_cast hw)
  have hh := p.summable_norm_apply hb
  simpa [p, FormalMultilinearSeries.ofScalars, binomialCoefficient_eq_choose, norm_mul, norm_pow] using hh

end Hypergeometric
end «JNT-2024»
