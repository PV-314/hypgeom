module

public import «JNT-2024».ApproximationGcd
public import «JNT-2024».NormalizerOddPrimePublished
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».NormalizerTwoPublished
public import «JNT-2024».NormalizerValuationsPublished
public import «JNT-2024».PrimePowerRatio
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- Lemma 3.11, assembled from the printed odd-prime and prime-two proofs.
 -/
theorem lemma311_published (P : Parameters) (h : P.Admissible) (hc : Int.gcd P.a P.b = 1)
    (hn : P.normAlpha < 0) {k X Y ν : ℤ}
    (hx : P.x h.pell k = (X : ℚ)) (hy : P.y h.pell k = (Y : ℚ))
    (hν : ν = 1 ∨ ν = -1) :
    ∃ m : ℕ,
      Approximation.gSquared (squarefreePart P.normAlpha) (2 * X) (2 * ν * squareFactor P.normAlpha) =
        (2 : ℚ) ^ m * P.baseGcd := by
  let S := squarefreePart P.normAlpha
  let C := squareFactor P.normAlpha
  let G₁ := Approximation.g1 (2 * X) (2 * ν * C)
  let G₂ := Approximation.g2 S (2 * X) (2 * ν * C)
  let G₃ := Approximation.g3 S (2 * X) (2 * ν * C)
  have hC : C ≠ 0 := ne_of_gt (squareFactor_pos (ne_of_lt hn))
  have hu : 2 * ν * C ≠ 0 := by rcases hν with rfl | rfl <;> simpa using hC
  have h₁ : G₁ ≠ 0 := ne_of_gt (Int.gcd_pos_of_ne_zero_right _ hu)
  have h₂ : G₂ ≠ 0 := ne_of_gt (Int.gcd_pos_of_ne_zero_right _ (squarefreePart_ne_zero _))
  have h₃ : G₃ ≠ 0 := ne_of_gt (Approximation.g3_pos _ _ _)
  have hB : P.baseGcd ≠ 0 := ne_of_gt (P.baseGcd_pos (ne_of_gt h.a_pos))
  have hA : G₁ ^ 2 * G₂ ≠ 0 := mul_ne_zero (pow_ne_zero _ h₁) h₂
  have hD : G₃ * P.baseGcd ≠ 0 := mul_ne_zero h₃ hB
  have hv (p : ℕ) [Fact p.Prime] :
      (padicValNat p (G₁ ^ 2 * G₂) : ℤ) - padicValNat p G₃ =
        padicValRat p (Approximation.gSquared S (2 * X) (2 * ν * C)) := by
    rw [padicValNat.mul (pow_ne_zero _ h₁) h₂, Nat.cast_add]
    exact (Approximation.gSquared_valuation_published p (squarefreePart_ne_zero _) hu).symm
  obtain ⟨m,hm⟩ := nat_eq_two_power_mul_of_valuations hA hD
    (by
      intro p hp hp₂
      let : Fact p.Prime := ⟨hp⟩
      have hh := P.normalizer_valuation_odd_published h hc hn p hp₂ hx hy hν
      have hh' := hv p
      rw [padicValNat.mul h₃ hB]
      change _ = padicValNat p (Approximation.g3 S (2 * X) (2 * ν * C)) + _
      rw [Approximation.g3_valuation_odd_published p hp₂, zero_add]
      have hz : padicValNat p G₃ = 0 := Approximation.g3_valuation_odd_published p hp₂ _ _ _
      change _ = (padicValNat p P.baseGcd : ℤ) at hh
      rw [← hh', hz, Nat.cast_zero, sub_zero] at hh
      exact_mod_cast hh)
    (by
      have hh := P.normalizer_valuation_two_published h hc hn hx hy hν
      have hh' := hv 2
      change (padicValNat 2 P.baseGcd : ℤ) ≤ _ at hh
      rw [← hh'] at hh
      rw [padicValNat.mul h₃ hB]
      omega)
  refine ⟨m, ?_⟩
  have hmQ : (G₁ : ℚ) ^ 2 * G₂ = (2 : ℚ) ^ m * (G₃ * (P.baseGcd : ℚ)) := by
    exact_mod_cast hm
  change (G₁ : ℚ) ^ 2 * G₂ / G₃ = (2 : ℚ) ^ m * P.baseGcd
  apply (div_eq_iff (by exact_mod_cast h₃)).mpr
  rw [hmQ]
  ring

end «JNT-2024».Parameters
