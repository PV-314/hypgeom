module

public import «JNT-2024».ApproximationGcd
public import «JNT-2024».ComplexRepresentation
public import «JNT-2024».DenominatorContent
public import «JNT-2024».DenominatorDefinitions
public import «JNT-2024».HypergeometricPolynomials
public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».Section2Complex
public import «JNT-2024».Section2Construction
public import «JNT-2024».Section2Parameters
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Section2

open Hypergeometric

noncomputable def gaussianPhase : ℂ := (1 + Complex.I) / (Real.sqrt 2 : ℂ)

theorem gaussianPhase_sq : gaussianPhase ^ 2 = Complex.I := by
  have hs : (Real.sqrt 2 : ℂ) ^ 2 = 2 := by exact_mod_cast Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
  rw [gaussianPhase, div_pow, hs]
  have hi := Complex.I_sq
  linear_combination (1 / 2 : ℂ) * hi

theorem gaussianPhase_norm : ‖gaussianPhase‖ = 1 := by
  have hh := congrArg norm gaussianPhase_sq
  rw [norm_pow, Complex.norm_I] at hh
  nlinarith [norm_nonneg gaussianPhase]

theorem gaussianPhase_integral : IsIntegral ℤ gaussianPhase := by
  apply IsIntegral.of_pow (by decide : 0 < 2)
  rw [gaussianPhase_sq]
  apply IsIntegral.of_pow (by decide : 0 < 2)
  rw [Complex.I_sq]
  simpa only [Int.cast_neg, Int.cast_one] using (isIntegral_intCast (-1) : IsIntegral ℤ ((-1 : ℤ) : ℂ))

/-- The correction specified in Section 2 for `t′=-1`. -/
noncomputable def correction (u₁ u₂ : ℤ) (r : ℕ) : ℂ :=
  if r % 2 = 1 ∧ Approximation.g3 (-1) u₁ u₂ = 2 then gaussianPhase else 1

theorem correction_norm (u₁ u₂ : ℤ) (r : ℕ) : ‖correction u₁ u₂ r‖ = 1 := by
  unfold correction
  split_ifs <;> simp [gaussianPhase_norm]

theorem correction_ne_zero (u₁ u₂ : ℤ) (r : ℕ) : correction u₁ u₂ r ≠ 0 := by
  intro he
  have hh := correction_norm u₁ u₂ r
  rw [he, norm_zero] at hh
  norm_num at hh

theorem correction_integral (u₁ u₂ : ℤ) (r : ℕ) : IsIntegral ℤ (correction u₁ u₂ r) := by
  unfold correction
  split_ifs
  · exact gaussianPhase_integral
  · exact isIntegral_one

noncomputable def p (u₁ u₂ : ℤ) (r : ℕ) : ℂ := correction u₁ u₂ r * rawP (-1) u₁ u₂ r
noncomputable def q (u₁ u₂ : ℤ) (r : ℕ) : ℂ := correction u₁ u₂ r * rawQ (-1) u₁ u₂ r
noncomputable def R (u₁ u₂ : ℤ) (r : ℕ) : ℂ := correction u₁ u₂ r * rawR (-1) u₁ u₂ r

theorem corrected_norms (u₁ u₂ : ℤ) (r : ℕ) :
    ‖p u₁ u₂ r‖ = ‖rawP (-1) u₁ u₂ r‖ ∧ ‖q u₁ u₂ r‖ = ‖rawQ (-1) u₁ u₂ r‖ ∧
      ‖R u₁ u₂ r‖ = ‖rawR (-1) u₁ u₂ r‖ := by
  simp [p, q, R, correction_norm]

theorem corrected_integral {u₁ u₂ : ℤ} (hu₂ : u₂ ≠ 0) (r : ℕ) :
    IsIntegral ℤ (p u₁ u₂ r) ∧ IsIntegral ℤ (q u₁ u₂ r) :=
  ⟨(correction_integral u₁ u₂ r).mul (rawP_integral (by norm_num) hu₂ r),
    (correction_integral u₁ u₂ r).mul (rawQ_integral (by norm_num) hu₂ r)⟩

theorem corrected_error_identity {u₁ u₂ : ℤ} (hnear : ‖omega (-1) u₁ u₂ - 1‖ < 1) (r : ℕ) :
    q u₁ u₂ r * omega (-1) u₁ u₂ ^ (1 / 4 : ℂ) - p u₁ u₂ r = R u₁ u₂ r := by
  unfold p q R
  linear_combination correction u₁ u₂ r * raw_error_identity hnear r

theorem corrected_determinant_ne {u₁ u₂ : ℤ} (hu₂ : u₂ ≠ 0) (r : ℕ) :
    p u₁ u₂ r * q u₁ u₂ (r + 1) ≠ p u₁ u₂ (r + 1) * q u₁ u₂ r := by
  intro he
  have hh : correction u₁ u₂ r * correction u₁ u₂ (r + 1) *
      (rawP (-1) u₁ u₂ r * rawQ (-1) u₁ u₂ (r + 1) -
        rawP (-1) u₁ u₂ (r + 1) * rawQ (-1) u₁ u₂ r) = 0 := by
    unfold p q at he
    linear_combination he
  have hf := mul_ne_zero (correction_ne_zero u₁ u₂ r) (correction_ne_zero u₁ u₂ (r + 1))
  exact (sub_ne_zero.mpr (raw_determinant_ne (by norm_num) hu₂ r))
    ((mul_eq_zero.mp hh).resolve_left hf)

abbrev GaussianField := QuadraticAlgebra ℚ ((-1 : ℤ) : ℚ) 0

instance gaussianNonsquare : Fact (¬ IsSquare (-1 : ℤ)) := ⟨by rintro ⟨x, hx⟩; nlinarith [sq_nonneg x]⟩

noncomputable def gaussianEmbedding : GaussianField →+* ℂ := imaginaryEmbedding (-1) (by norm_num)
noncomputable def gaussianField : Subfield ℂ := gaussianEmbedding.fieldRange

theorem I_mem_gaussianField : Complex.I ∈ gaussianField := by
  refine ⟨⟨0, 1⟩, ?_⟩
  apply Complex.ext <;> norm_num [gaussianEmbedding, imaginaryEmbedding]

theorem U_mem_gaussianField (u₁ u₂ : ℤ) : U (-1) u₁ u₂ ∈ gaussianField := by
  simp only [U, root, Int.cast_neg, Int.cast_one, neg_neg, Real.sqrt_one, Complex.ofReal_one, one_mul]
  exact div_mem (add_mem (intCast_mem _ _) (mul_mem (intCast_mem _ _) I_mem_gaussianField)) (ofNat_mem _ _)

theorem conj_mem_gaussianField {z : ℂ} (hz : z ∈ gaussianField) : star z ∈ gaussianField := by
  obtain ⟨w, hw⟩ := hz
  refine ⟨star w, ?_⟩
  rw [← hw]
  apply Complex.ext
  · change ((star w).re : ℝ) = (w.re : ℝ)
    simp
  · change ((star w).im : ℝ) * Real.sqrt (-((-1 : ℤ) : ℝ)) =
      -((w.im : ℝ) * Real.sqrt (-((-1 : ℤ) : ℝ)))
    simp

theorem omega_mem_gaussianField (u₁ u₂ : ℤ) : omega (-1) u₁ u₂ ∈ gaussianField :=
  div_mem (U_mem_gaussianField u₁ u₂) (conj_mem_gaussianField (U_mem_gaussianField u₁ u₂))

theorem X_mem_gaussianField (r : ℕ) {z : ℂ} (hz : z ∈ gaussianField) : X (1 / 4) r z ∈ gaussianField := by
  unfold X
  exact sum_mem fun j _ => mul_mem (SubfieldClass.ratCast_mem _ _) (pow_mem hz _)

theorem g2_gaussian (u₁ u₂ : ℤ) : Approximation.g2 (-1) u₁ u₂ = 1 := by
  simp [Approximation.g2]

theorem g3_gaussian (u₁ u₂ : ℤ) : Approximation.g3 (-1) u₁ u₂ = 2 ∨ Approximation.g3 (-1) u₁ u₂ = 4 := by
  unfold Approximation.g3
  norm_num
  exact Int.even_or_odd _

theorem A_sq_mem_gaussianField (u₁ u₂ : ℤ) : A (-1) u₁ u₂ ^ 2 ∈ gaussianField := by
  have hg : (Approximation.g (-1) u₁ u₂ : ℂ) ^ 2 = ((Approximation.gSquared (-1) u₁ u₂ : ℚ) : ℂ) := by
    exact_mod_cast Approximation.g_sq (-1) u₁ u₂
  rw [A, div_pow, hg]
  exact div_mem (pow_mem (conj_mem_gaussianField (U_mem_gaussianField u₁ u₂)) _) (SubfieldClass.ratCast_mem _ _)

theorem g_gaussian_four {u₁ u₂ : ℤ} (_hu₂ : u₂ ≠ 0) (hk : Approximation.g3 (-1) u₁ u₂ = 4) :
    Approximation.g (-1) u₁ u₂ = (Approximation.g1 u₁ u₂ : ℝ) / 2 := by
  unfold Approximation.g
  rw [g2_gaussian, hk]
  norm_num
  rw [show Real.sqrt 4 = (2 : ℝ) by
    rw [show (4 : ℝ) = 2 ^ 2 by norm_num, Real.sqrt_sq (by norm_num : (0 : ℝ) ≤ 2)]]
  ring

theorem sqrt_two_mul_g_gaussian {u₁ u₂ : ℤ} (hu₂ : u₂ ≠ 0) (hk : Approximation.g3 (-1) u₁ u₂ = 2) :
    Real.sqrt 2 * Approximation.g (-1) u₁ u₂ = (Approximation.g1 u₁ u₂ : ℝ) := by
  have hg := Approximation.g_sq (-1) u₁ u₂
  simp only [Approximation.gSquared, g2_gaussian, hk] at hg
  norm_num at hg
  have hs := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
  have he : (Real.sqrt 2 * Approximation.g (-1) u₁ u₂) ^ 2 = (Approximation.g1 u₁ u₂ : ℝ) ^ 2 := by
    rw [mul_pow, hs, hg]
    ring
  exact (sq_eq_sq₀ (mul_nonneg (Real.sqrt_nonneg _) (Approximation.g_pos (by norm_num) hu₂).le)
    (Nat.cast_nonneg _)).mp he

theorem phase_mul_A_mem_gaussianField {u₁ u₂ : ℤ} (hu₂ : u₂ ≠ 0)
    (hk : Approximation.g3 (-1) u₁ u₂ = 2) : gaussianPhase * A (-1) u₁ u₂ ∈ gaussianField := by
  have hg : (Real.sqrt 2 : ℂ) * (Approximation.g (-1) u₁ u₂ : ℂ) = (Approximation.g1 u₁ u₂ : ℂ) := by
    exact_mod_cast sqrt_two_mul_g_gaussian hu₂ hk
  have he : gaussianPhase * A (-1) u₁ u₂ =
      (1 + Complex.I) * star (U (-1) u₁ u₂) / (Approximation.g1 u₁ u₂ : ℂ) := by
    rw [gaussianPhase, A, div_mul_div_comm, hg]
  rw [he]
  exact div_mem (mul_mem (add_mem (one_mem _) I_mem_gaussianField)
    (conj_mem_gaussianField (U_mem_gaussianField u₁ u₂))) (natCast_mem _ _)

theorem corrected_A_pow_mem_gaussianField {u₁ u₂ : ℤ} (hu₂ : u₂ ≠ 0) (r : ℕ) :
    correction u₁ u₂ r * A (-1) u₁ u₂ ^ r ∈ gaussianField := by
  rcases g3_gaussian u₁ u₂ with hk | hk
  · by_cases hr : r % 2 = 0
    · have he : r = 2 * (r / 2) := by omega
      simp only [correction, hr, zero_ne_one, false_and, ite_false, one_mul]
      rw [he, pow_mul]
      exact pow_mem (A_sq_mem_gaussianField u₁ u₂) _
    · have hr' : r % 2 = 1 := by omega
      have he : r = 2 * (r / 2) + 1 := by omega
      simp only [correction, hr', hk, and_self, ite_eq_left]
      have he' : gaussianPhase * A (-1) u₁ u₂ ^ r =
          (A (-1) u₁ u₂ ^ 2) ^ (r / 2) * (gaussianPhase * A (-1) u₁ u₂) := by
        nth_rw 1 [he]
        rw [pow_add, pow_mul, pow_one]
        ring
      rw [he']
      exact mul_mem (pow_mem (A_sq_mem_gaussianField u₁ u₂) _) (phase_mul_A_mem_gaussianField hu₂ hk)
  · have hA : A (-1) u₁ u₂ ∈ gaussianField := by
      rw [A, g_gaussian_four hu₂ hk, Complex.ofReal_div, Complex.ofReal_natCast, Complex.ofReal_ofNat]
      exact div_mem (conj_mem_gaussianField (U_mem_gaussianField u₁ u₂))
        (div_mem (natCast_mem _ _) (ofNat_mem _ _))
    simp only [correction, hk, show ¬(4 : ℕ) = 2 by decide, and_false, ite_false, one_mul]
    exact pow_mem hA r

theorem corrected_mem_gaussianField {u₁ u₂ : ℤ} (hu₂ : u₂ ≠ 0) (r : ℕ) :
    p u₁ u₂ r ∈ gaussianField ∧ q u₁ u₂ r ∈ gaussianField := by
  have hs : correction u₁ u₂ r * rawScale (-1) u₁ u₂ r ∈ gaussianField := by
    have he : correction u₁ u₂ r * rawScale (-1) u₁ u₂ r =
        ((denominator4 r : ℂ) / numeratorContent4 (Approximation.dPrimeInteger (-1) u₁ u₂) r) *
          (correction u₁ u₂ r * A (-1) u₁ u₂ ^ r) := by unfold rawScale; ring
    rw [he]
    exact mul_mem (div_mem (natCast_mem _ _) (natCast_mem _ _)) (corrected_A_pow_mem_gaussianField hu₂ r)
  constructor
  · rw [p, rawP, ← mul_assoc]
    exact mul_mem hs (X_mem_gaussianField r (omega_mem_gaussianField u₁ u₂))
  · rw [q, rawQ, ← mul_assoc]
    apply mul_mem hs
    unfold Y
    exact sum_mem fun j _ => mul_mem (SubfieldClass.ratCast_mem _ _) (pow_mem (omega_mem_gaussianField u₁ u₂) _)

/-- The corrected approximants are algebraic integers in the required imaginary quadratic field. -/
theorem corrected_gaussian_integers {u₁ u₂ : ℤ} (hu₂ : u₂ ≠ 0) (r : ℕ) :
    ∃ pr qr : GaussianField, IsIntegral ℤ pr ∧ IsIntegral ℤ qr ∧
      gaussianEmbedding pr = p u₁ u₂ r ∧ gaussianEmbedding qr = q u₁ u₂ r := by
  obtain ⟨⟨pr, hpr⟩, ⟨qr, hqr⟩⟩ := corrected_mem_gaussianField (u₁ := u₁) hu₂ r
  have hi := corrected_integral (u₁ := u₁) hu₂ r
  refine ⟨pr, qr, ?_, ?_, hpr, hqr⟩
  · apply (isIntegral_algHom_iff gaussianEmbedding.toIntAlgHom gaussianEmbedding.injective).mp
    simpa only [RingHom.toIntAlgHom_apply, hpr] using hi.1
  · apply (isIntegral_algHom_iff gaussianEmbedding.toIntAlgHom gaussianEmbedding.injective).mp
    simpa only [RingHom.toIntAlgHom_apply, hqr] using hi.2

end Section2
end «JNT-2024»
