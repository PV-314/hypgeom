module

public import «JNT-2024».ArcGeometry
public import «JNT-2024».ArcLowerBound
public import «JNT-2024».EulerBeta
public import «JNT-2024».EulerIntegral
public import «JNT-2024».HypergeometricPolynomials
public import «JNT-2024».RemainderArc
public import «JNT-2024».RemainderConstruction
public import «JNT-2024».RemainderIdentity
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

noncomputable def centeredArcIntegral (ν : ℚ) (r : ℕ) (φ : ℝ) : ℂ :=
  ∫ t : ℝ in 0..1, (arcWeight φ t : ℂ) ^ r * circlePoint ((ν : ℝ) * φ * (t - 1 / 2))

theorem arcKernel_centered (ν : ℚ) (r : ℕ) {φ t : ℝ}
    (hφ : |φ| ≤ Real.pi / 2) (ht : t ∈ Set.Icc 0 1) :
    segmentKernel ν r (circlePoint φ) (circlePoint (φ * t)) *
        ((φ : ℂ) * Complex.I * circlePoint (φ * t)) =
      ((-1 : ℂ) ^ r * Complex.I * (φ : ℂ) * circlePoint (((r : ℝ) + ν) * φ / 2)) *
        ((arcWeight φ t : ℂ) ^ r * circlePoint ((ν : ℝ) * φ * (t - 1 / 2))) := by
  have htφ : |φ * t| < Real.pi := by
    rw [abs_mul, abs_of_nonneg ht.1]
    have := mul_le_of_le_one_right (abs_nonneg φ) ht.2
    linarith [Real.pi_pos]
  have hc : circlePoint (φ * t) ^ ((ν : ℂ) - r - 1) =
      circlePoint (((ν : ℝ) - r - 1) * (φ * t)) := by
    convert circlePoint_cpow ((ν : ℝ) - r - 1) (φ * t) htφ using 1
    push_cast
    rfl
  have he : circlePoint (φ * t + φ / 2) ^ r *
      circlePoint (((ν : ℝ) - r - 1) * (φ * t)) * circlePoint (φ * t) =
      circlePoint (((r : ℝ) + ν) * φ / 2) * circlePoint ((ν : ℝ) * φ * (t - 1 / 2)) := by
    rw [circlePoint_pow, ← circlePoint_add, ← circlePoint_add, ← circlePoint_add]
    congr 1
    ring
  rw [segmentKernel, arcWeight_product, hc]
  rw [show -circlePoint (φ * t + φ / 2) * (arcWeight φ t : ℂ) =
    (-1 : ℂ) * circlePoint (φ * t + φ / 2) * (arcWeight φ t : ℂ) by ring]
  simp only [mul_pow]
  linear_combination (-1 : ℂ) ^ r * Complex.I * (φ : ℂ) * (arcWeight φ t : ℂ) ^ r * he

theorem remainder_eq_centeredArcIntegral {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1)
    (r : ℕ) {z : ℂ} (hz : ‖z‖ = 1) (hre : 0 ≤ z.re) :
    remainder ν r z = ((risingQ ν (r + 1) : ℂ) / r.factorial) *
      ((-1 : ℂ) ^ r * Complex.I * (z.arg : ℂ) * circlePoint (((r : ℝ) + ν) * z.arg / 2)) *
      centeredArcIntegral ν r z.arg := by
  rw [remainder_eq_arcIntegral hν₀ hν₁ r hz hre]
  have he : (∫ t : ℝ in 0..1, segmentKernel ν r z (circlePoint (z.arg * t)) *
      ((z.arg : ℂ) * Complex.I * circlePoint (z.arg * t))) =
      ((-1 : ℂ) ^ r * Complex.I * (z.arg : ℂ) * circlePoint (((r : ℝ) + ν) * z.arg / 2)) *
      centeredArcIntegral ν r z.arg := by
    rw [centeredArcIntegral, ← intervalIntegral.integral_const_mul]
    apply intervalIntegral.integral_congr
    intro t ht
    have ht' : t ∈ Set.Icc (0 : ℝ) 1 := by simpa using ht
    simpa only [circlePoint_arg hz] using
      arcKernel_centered ν r (Complex.abs_arg_le_pi_div_two_iff.mpr hre) ht'
  rw [he]
  ring

theorem euler_norm_arc_identity {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1)
    (r : ℕ) {z : ℂ} (hz : ‖z‖ = 1) (hre : 0 ≤ z.re) :
    ‖z - 1‖ ^ (2 * r + 1) * ‖eulerHypergeometric (r + 1 - (ν : ℂ)) r z‖ =
      ‖eulerNormalizer r‖ * |z.arg| * ‖centeredArcIntegral ν r z.arg‖ := by
  have hh := congrArg norm (remainder_eq_centeredArcIntegral hν₀ hν₁ r hz hre)
  rw [← remainderPrefactor_mul_normalizer] at hh
  simp only [remainder, norm_mul, norm_pow, circlePoint_norm, norm_neg, norm_one,
    one_pow, Complex.norm_I, Complex.norm_real, Real.norm_eq_abs, one_mul, mul_one] at hh
  have hn : ‖(remainderPrefactor ν r : ℂ)‖ ≠ 0 := by
    apply norm_ne_zero_iff.mpr
    exact_mod_cast ne_of_gt (remainderPrefactor_pos hν₀ r)
  apply mul_left_cancel₀ hn
  linear_combination hh

theorem circlePoint_chord_sin {φ : ℝ} (hφ : |φ| ≤ Real.pi / 2) :
    ‖circlePoint φ - 1‖ = 2 * Real.sin (|φ| / 2) := by
  have hh := Complex.norm_exp_I_mul_ofReal_sub_one φ
  rw [Real.norm_eq_abs, abs_mul, abs_of_pos (by norm_num : (0 : ℝ) < 2),
    Real.abs_sin_eq_sin_abs_of_abs_le_pi (by rw [abs_div]; norm_num; linarith [Real.pi_pos]),
    abs_div, abs_of_pos (by norm_num : (0 : ℝ) < 2)] at hh
  simpa only [circlePoint, mul_comm Complex.I] using hh

noncomputable def realBetaMoment (r : ℕ) : ℝ := ∫ t : ℝ in 0..1, t ^ r * (1 - t) ^ r

theorem realBetaMoment_cast (r : ℕ) : (realBetaMoment r : ℂ) = betaMoment r r := by
  rw [realBetaMoment, betaMoment, ← intervalIntegral.integral_ofReal]
  congr 1
  funext t
  push_cast
  rfl

theorem realBetaMoment_pos (r : ℕ) : 0 < realBetaMoment r := by
  have he : realBetaMoment r = (r.factorial : ℝ) ^ 2 / (2 * r + 1).factorial := by
    apply Complex.ofReal_injective
    rw [realBetaMoment_cast, betaMoment_eq_factorial]
    push_cast
    rw [show r + r + 1 = 2 * r + 1 by omega]
    ring
  rw [he]
  positivity

theorem norm_eulerNormalizer_mul_realBetaMoment (r : ℕ) :
    ‖eulerNormalizer r‖ * realBetaMoment r = 1 := by
  have hh := congrArg norm (eulerNormalizer_mul_betaMoment r)
  rw [norm_mul, ← realBetaMoment_cast, Complex.norm_real, Real.norm_eq_abs,
    abs_of_pos (realBetaMoment_pos r), norm_one] at hh
  exact hh

theorem centeredArcIntegral_re (ν : ℚ) (r : ℕ) (φ : ℝ) :
    (centeredArcIntegral ν r φ).re =
      ∫ t : ℝ in 0..1, arcWeight φ t ^ r * Real.cos ((ν : ℝ) * φ * (t - 1 / 2)) := by
  have hc : Continuous (fun t : ℝ => (arcWeight φ t : ℂ) ^ r *
      circlePoint ((ν : ℝ) * φ * (t - 1 / 2))) := by
    unfold arcWeight circlePoint
    fun_prop
  have hh := Complex.reCLM.intervalIntegral_comp_comm
    (hc.intervalIntegrable (μ := MeasureTheory.volume) 0 1)
  simp only [Complex.reCLM_apply] at hh
  rw [centeredArcIntegral, ← hh]
  congr 1
  funext t
  simp only [← Complex.ofReal_pow, Complex.mul_re,
    Complex.ofReal_re, Complex.ofReal_im, circlePoint_re, zero_mul, sub_zero]

theorem centeredArcIntegral_norm_lower {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1 / 2)
    (r : ℕ) {φ : ℝ} (hφ : |φ| ≤ Real.pi / 2) :
    (2 * Real.sin (|φ| / 2)) ^ (2 * r) * Real.cos (|φ| / 4) * realBetaMoment r ≤
      ‖centeredArcIntegral ν r φ‖ := by
  have hνR₀ : (0 : ℝ) ≤ ν := by exact_mod_cast hν₀.le
  have hνR₁ : (ν : ℝ) ≤ 1 / 2 := by
    have hh := (Rat.cast_le (K := ℝ)).mpr hν₁.le
    norm_num at hh
    exact hh
  have hp (t : ℝ) (ht : t ∈ Set.Icc (0 : ℝ) 1) :
      ((2 * Real.sin (|φ| / 2)) ^ (2 * r) * Real.cos (|φ| / 4)) *
          (t ^ r * (1 - t) ^ r) ≤
        arcWeight φ t ^ r * Real.cos ((ν : ℝ) * φ * (t - 1 / 2)) := by
    have hs : 0 ≤ (2 * Real.sin (|φ| / 2)) ^ 2 * t * (1 - t) :=
      mul_nonneg (mul_nonneg (sq_nonneg _) ht.1) (sub_nonneg.mpr ht.2)
    have hw := pow_le_pow_left₀ hs (arcWeight_lower hφ ht) r
    have hc := arcPhase_cos_lower hνR₀ hνR₁ hφ ht
    have hh := mul_le_mul hw hc (arcPhase_cos_nonneg hφ)
      (pow_nonneg (arcWeight_nonneg (by linarith [Real.pi_pos]) ht) r)
    simp only [mul_pow, ← pow_mul] at hh
    convert hh using 1
    ring
  have hc₀ : Continuous (fun t : ℝ =>
      ((2 * Real.sin (|φ| / 2)) ^ (2 * r) * Real.cos (|φ| / 4)) * (t ^ r * (1 - t) ^ r)) := by
    fun_prop
  have hc₁ : Continuous (fun t : ℝ =>
      arcWeight φ t ^ r * Real.cos ((ν : ℝ) * φ * (t - 1 / 2))) := by
    unfold arcWeight
    fun_prop
  have hi := intervalIntegral.integral_mono_on (μ := MeasureTheory.volume) (by norm_num : (0 : ℝ) ≤ 1)
    (hc₀.intervalIntegrable 0 1) (hc₁.intervalIntegrable 0 1) hp
  rw [intervalIntegral.integral_const_mul, ← realBetaMoment, ← centeredArcIntegral_re] at hi
  exact hi.trans (Complex.re_le_norm _)

/-- Lemma 2.2(e): the analytic continuation, rather than the raw hypergeometric tsum. -/
theorem lemma22e {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1 / 2) (r : ℕ)
    {z : ℂ} (hz : ‖z‖ = 1) (hre : 0 ≤ z.re) :
    1 ≤ ‖eulerHypergeometric (r + 1 - (ν : ℂ)) r z‖ := by
  by_cases hz₁ : z = 1
  · simp [hz₁, eulerHypergeometric_one]
  have ha := Complex.abs_arg_le_pi_div_two_iff.mpr hre
  have he := euler_norm_arc_identity hν₀ (by linarith) r hz hre
  have hs : ‖z - 1‖ = 2 * Real.sin (|z.arg| / 2) := by
    simpa only [circlePoint_arg hz] using circlePoint_chord_sin ha
  have hd : 0 < 2 * Real.sin (|z.arg| / 2) := by
    rw [← hs]
    exact norm_pos_iff.mpr (sub_ne_zero.mpr hz₁)
  rw [hs] at he
  have hl := centeredArcIntegral_norm_lower hν₀ hν₁ r ha
  have hm := mul_le_mul_of_nonneg_left hl
    (mul_nonneg (norm_nonneg (eulerNormalizer r)) (abs_nonneg z.arg))
  rw [← he] at hm
  have hb := norm_eulerNormalizer_mul_realBetaMoment r
  have hh : (2 * Real.sin (|z.arg| / 2)) ^ (2 * r) *
      (|z.arg| * Real.cos (|z.arg| / 4)) ≤
      (2 * Real.sin (|z.arg| / 2)) ^ (2 * r + 1) *
        ‖eulerHypergeometric (r + 1 - (ν : ℂ)) r z‖ := by
    convert hm using 1
    linear_combination -((2 * Real.sin (|z.arg| / 2)) ^ (2 * r) *
      |z.arg| * Real.cos (|z.arg| / 4)) * hb
  have hcomp := mul_le_mul_of_nonneg_left (arc_sine_comparison ha)
    (pow_nonneg hd.le (2 * r))
  rw [← pow_succ] at hcomp
  have hfinal := hcomp.trans hh
  exact (le_mul_iff_one_le_right (pow_pos hd (2 * r + 1))).mp hfinal


end Hypergeometric
end «JNT-2024»
