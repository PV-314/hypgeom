module

public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».RepresentationGcdIdentities
public import «JNT-2024».RepresentationSupport
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section
namespace «JNT-2024»

/-- The valuation formula read directly from the printed (3.8). -/
theorem lemma33_valuation_eq38 (p : ℕ) [Fact p.Prime] {b r : ℤ}
    (_hb : b ≠ 0) (hr : r ≠ 0) :
    padicValRat p (normalizationQuotient b r) =
      (padicValInt p (squarefreePart r) : ℤ) -
        padicValNat p (Int.gcd (4 * b ^ 2) (r * squarefreePart r)) := by
  have hg : Int.gcd (4 * b ^ 2) (r * squarefreePart r) ≠ 0 :=
    ne_of_gt (Int.gcd_pos_of_ne_zero_right _ (mul_ne_zero hr (squarefreePart_ne_zero r)))
  rw [paper_eq38 b hr, padicValRat.div (by exact_mod_cast squarefreePart_ne_zero r)
    (by exact_mod_cast hg), padicValRat.of_int, padicValRat.of_nat]

/-- The bound by one and the prime conditions singled out by equality in
Lemma 3.3(a), obtained from (3.8). -/
theorem lemma33_eq38_prime_conditions (p : ℕ) [Fact p.Prime] {b r : ℤ}
    (hb : b ≠ 0) (hr : r ≠ 0) :
    padicValRat p (normalizationQuotient b r) ≤ 1 ∧
    (padicValRat p (normalizationQuotient b r) = 1 →
      padicValInt p (squarefreePart r) = 1 ∧
      (p : ℤ) ∣ squarefreePart r ∧ ¬ (p : ℤ) ∣ 2 * b) := by
  have hv := lemma33_valuation_eq38 p hb hr
  have hs := valuation_squarefree_le_one p (squarefreePart_squarefree r)
  have hrval := valuation_squarePart p hr
  constructor
  · omega
  · intro hq
    have hsf : padicValInt p (squarefreePart r) = 1 := by omega
    have hden : padicValNat p (Int.gcd (4 * b ^ 2) (r * squarefreePart r)) = 0 := by omega
    have h2b : 2 * b ≠ 0 := mul_ne_zero (by norm_num) hb
    have he : 4 * b ^ 2 = (2 * b) ^ 2 := by ring
    have hdv := valuation_gcd p (mul_ne_zero (by norm_num : (4 : ℤ) ≠ 0) (pow_ne_zero 2 hb))
      (mul_ne_zero hr (squarefreePart_ne_zero r))
    rw [he, valuation_int_pow, padicValInt.mul hr (squarefreePart_ne_zero r)] at hdv
    have hden' : padicValNat p (Int.gcd ((2 * b) ^ 2) (r * squarefreePart r)) = 0 := by
      simpa only [← he] using hden
    have hz : padicValInt p (2 * b) = 0 := by omega
    refine ⟨hsf, ?_, ?_⟩
    · have hh := (padicValInt_dvd_iff (p := p) 1 (squarefreePart r)).mpr (Or.inr (by omega))
      simpa using hh
    · intro hd
      have hh := ((padicValInt_dvd_iff (p := p) 1 (2 * b)).mp (by simpa using hd)).resolve_left h2b
      omega

/-- The two parity branches used to identify the support in Lemma 3.3(a). -/
theorem lemma33_support_parity (p : ℕ) [Fact p.Prime] {r r' u N : ℤ}
    (hr : r ≠ 0) (hr' : r' ≠ 0) (hu : u ≠ 0) (hN : N ≠ 0)
    (hprod : r * r' = u ^ 2 * N) (hs : padicValInt p (squarefreePart r) = 1) :
    (¬ (p : ℤ) ∣ (Int.gcd r r' : ℤ) → (p : ℤ) ∣ squarefreePart N) ∧
    ((padicValInt p r + padicValInt p r') % 2 = 1 → (p : ℤ) ∣ squarefreePart N) ∧
    ((padicValInt p r + padicValInt p r') % 2 = 0 → padicValInt p r' % 2 = 1) := by
  have hv := congrArg (padicValInt p) hprod
  rw [padicValInt.mul hr hr', padicValInt.mul (pow_ne_zero _ hu) hN, valuation_int_pow] at hv
  have hsr := valuation_squarePart p hr
  have hsN := valuation_squarePart p hN
  have hfN := valuation_squarefree_le_one p (squarefreePart_squarefree N)
  have hodd : (padicValInt p r + padicValInt p r') % 2 = 1 → (p : ℤ) ∣ squarefreePart N := by
    intro ho
    have hh := (padicValInt_dvd_iff (p := p) 1 (squarefreePart N)).mpr (Or.inr (by omega))
    simpa using hh
  refine ⟨?_, hodd, ?_⟩
  · intro hn
    have hpr : (p : ℤ) ∣ r := by
      have hh := (padicValInt_dvd_iff (p := p) 1 r).mpr (Or.inr (by omega))
      simpa using hh
    have hz : padicValInt p r' = 0 := by
      by_contra hz
      have hh := (padicValInt_dvd_iff (p := p) 1 r').mpr (Or.inr (by omega))
      exact hn (Int.dvd_coe_gcd hpr (by simpa using hh))
    apply hodd
    omega
  · intro he
    omega

/-- The strict denominator dominance invoked in the printed proof of (c). -/
theorem lemma33c_denominator_dominates {b r : ℤ} (hb : b ≠ 0) (hr : r ≠ 0) (he : Even r) :
    padicValInt 2 (squarefreePart r) <
      padicValNat 2 (Int.gcd (4 * b ^ 2) (r * squarefreePart r)) := by
  have hdv := valuation_gcd 2 (mul_ne_zero (by norm_num : (4 : ℤ) ≠ 0) (pow_ne_zero 2 hb))
    (mul_ne_zero hr (squarefreePart_ne_zero r))
  have h4b : 4 * b ^ 2 = (2 * b) ^ 2 := by ring
  have h2 : padicValInt 2 (2 : ℤ) = 1 := by norm_num [padicValInt]
  rw [h4b, valuation_int_pow, padicValInt.mul (by norm_num) hb, h2,
    padicValInt.mul hr (squarefreePart_ne_zero r)] at hdv
  have hs := valuation_squarefree_le_one 2 (squarefreePart_squarefree r)
  have hv : 1 ≤ padicValInt 2 r := by
    exact ((padicValInt_dvd_iff (p := 2) 1 r).mp
      (by simpa using even_iff_two_dvd.mp he)).resolve_left hr
  rw [h4b]
  omega

/-- Part (c) via the denominator comparison in the printed (3.8). -/
theorem lemma33c_published {b r : ℤ} (hb : b ≠ 0) (hr : r ≠ 0) (he : Even r) :
    padicValRat 2 (normalizationQuotient b r) < 0 := by
  have hv := lemma33_valuation_eq38 2 hb hr
  have hd := lemma33c_denominator_dominates hb hr he
  omega

namespace Parameters

/-- The printed sum, norm comparison identity, and candidate divisibility
used in Lemma 3.3(a). The difference identity is already proved in
`candidate_common_prime_dvd_norm`. -/
theorem lemma33a_common_prime_identities (P : Parameters) {x y : ℤ}
    (h : P.RepresentsSquare x y) :
    P.repCandidate y 1 + P.repCandidate y (-1) = 2 * P.a * P.u + 2 * P.b ^ 2 * P.t ∧
    P.t * (P.repCandidate y 1 + P.repCandidate y (-1)) - 4 * y ^ 2 =
      P.b ^ 2 * (P.t ^ 2 - P.d * P.u ^ 2) ∧
    P.repCandidate y 1 ∣ P.u ^ 2 * P.normAlpha := by
  refine ⟨?_, ?_, ?_⟩
  · unfold repCandidate
    ring
  · have hy := P.representation_y h
    dsimp [repCandidate]
    nlinarith only [hy]
  · rw [← P.repCandidate_product h]
    exact dvd_mul_right _ _

/-- The paper's support argument: first the norm-times-squarefree factor,
then u*N, with the printed common-prime and parity cases. -/
theorem lemma33a_support_published (P : Parameters) {x y ν : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0)
    (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν) (p : ℕ) [hp : Fact p.Prime]
    (hq : padicValRat p (normalizationQuotient P.b (P.repCandidate y 1)) = 1) :
    (p : ℤ) ∣ P.u * P.normAlpha ∧ (p : ℤ) ∣ ν * squarefreePart P.normAlpha := by
  have hr := P.repCandidate_ne_zero h hu hN (Or.inl rfl)
  have hr' := P.repCandidate_ne_zero h hu hN (Or.inr rfl)
  obtain ⟨hs, _, hpb⟩ := (lemma33_eq38_prime_conditions p hb hr).2 hq
  have hprod := P.repCandidate_product h
  have hpI : Prime (p : ℤ) := Nat.prime_iff_prime_int.mp hp.out
  have hpr : (p : ℤ) ∣ P.repCandidate y 1 := by
    have hv := valuation_squarePart p hr
    have hh := (padicValInt_dvd_iff (p := p) 1 (P.repCandidate y 1)).mpr (Or.inr (by omega))
    simpa using hh
  have hpar := lemma33_support_parity p hr hr' hu hN hprod hs
  have hnorm : (p : ℤ) ∣ ν * squarefreePart P.normAlpha := by
    by_cases hg : (p : ℤ) ∣ (Int.gcd (P.repCandidate y 1) (P.repCandidate y (-1)) : ℤ)
    · by_cases ho : (padicValInt p (P.repCandidate y 1) + padicValInt p (P.repCandidate y (-1))) % 2 = 1
      · exact dvd_mul_of_dvd_right (hpar.2.1 ho) _
      · have he : (padicValInt p (P.repCandidate y 1) + padicValInt p (P.repCandidate y (-1))) % 2 = 0 := by omega
        have hother_odd := hpar.2.2 he
        have hpr' : (p : ℤ) ∣ P.repCandidate y (-1) := by
          have hh := (padicValInt_dvd_iff (p := p) 1 (P.repCandidate y (-1))).mpr (Or.inr (by omega))
          simpa using hh
        exact dvd_mul_of_dvd_left (P.candidate_common_prime_dvd_norm h hν p hpb hpr hpr') _
    · exact dvd_mul_of_dvd_right (hpar.1 hg) _
  refine ⟨?_, hnorm⟩
  have hd : (p : ℤ) ∣ P.u ^ 2 * P.normAlpha :=
    dvd_trans hpr (P.lemma33a_common_prime_identities h).2.2
  rcases hpI.dvd_mul.mp hd with hd | hd
  · exact dvd_mul_of_dvd_left (hpI.dvd_of_dvd_pow hd) _
  · exact dvd_mul_of_dvd_right hd _

/-- The exact radical valuation asserted in the proof of Lemma 3.3(a). -/
theorem lemma33a_radical_eq_one (P : Parameters) {x y ν : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0)
    (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν) (p : ℕ) [hp : Fact p.Prime]
    (hq : padicValRat p (normalizationQuotient P.b (P.repCandidate y 1)) = 1) :
    padicValInt p (P.representationRadical ν) = 1 := by
  obtain ⟨hd, hd'⟩ := P.lemma33a_support_published h hb hu hN hν p hq
  have hpI : Prime (p : ℤ) := Nat.prime_iff_prime_int.mp hp.out
  have hg : (Int.gcd (P.u * P.normAlpha) (ν * squarefreePart P.normAlpha) : ℤ) ≠ 0 := by
    exact_mod_cast ne_of_gt (Int.gcd_pos_of_ne_zero_left _ (mul_ne_zero hu hN))
  have hrad : (p : ℤ) ∣ P.representationRadical ν :=
    (UniqueFactorizationMonoid.dvd_radical_iff_of_irreducible hpI.irreducible hg).mpr (Int.dvd_coe_gcd hd hd')
  have hlow : 1 ≤ padicValInt p (P.representationRadical ν) :=
    ((padicValInt_dvd_iff (p := p) 1 _).mp (by simpa using hrad)).resolve_left
      UniqueFactorizationMonoid.radical_ne_zero
  have hupp := valuation_squarefree_le_one p (UniqueFactorizationMonoid.squarefree_radical
    (a := (Int.gcd (P.u * P.normAlpha) (ν * squarefreePart P.normAlpha) : ℤ)))
  change padicValInt p (P.representationRadical ν) ≤ 1 at hupp
  omega

/-- Part (a) following the printed equality-one reduction and prime-support cases. -/
theorem lemma33a_published (P : Parameters) {x y ν : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0)
    (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν) (p : ℕ) [Fact p.Prime] :
    max (padicValRat p (normalizationQuotient P.b (P.repCandidate y 1)))
      (padicValRat p (normalizationQuotient P.b (P.repCandidate y (-1)))) ≤
      padicValInt p (P.representationRadical ν) := by
  have first {x y : ℤ} (h : P.RepresentsSquare x y) :
      padicValRat p (normalizationQuotient P.b (P.repCandidate y 1)) ≤
        padicValInt p (P.representationRadical ν) := by
    have hupp := (lemma33_eq38_prime_conditions p hb (P.repCandidate_ne_zero h hu hN (Or.inl rfl))).1
    by_cases hq : padicValRat p (normalizationQuotient P.b (P.repCandidate y 1)) = 1
    · rw [P.lemma33a_radical_eq_one h hb hu hN hν p hq]
      exact hupp
    · have hn : (0 : ℤ) ≤ padicValInt p (P.representationRadical ν) := by positivity
      omega
  exact max_le (first h) (by simpa only [repCandidate_neg_y] using first h.neg_y)

/-- All three parts of Lemma 3.3 under the paper's integrality hypothesis.
Part (b) reuses the existing proof, which already follows the printed parity
contradiction; parts (a) and (c) use the restored (3.8) arguments. -/
theorem lemma33_published (P : Parameters) [Fact (¬ IsSquare P.d)] {x y : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0)
    (hi : IsIntegral ℤ P.epsilon) :
    ∃ ν : ℤ, (ν : ℚ) = P.epsilonNorm ∧
      (∀ p : ℕ, p.Prime →
        max (padicValRat p (normalizationQuotient P.b (P.repCandidate y 1)))
          (padicValRat p (normalizationQuotient P.b (P.repCandidate y (-1)))) ≤
            padicValInt p (P.representationRadical ν)) ∧
      (∀ p : ℕ, p.Prime → 0 < padicValInt p (squarefreePart P.normAlpha) →
        min (padicValRat p (normalizationQuotient P.b (P.repCandidate y 1)))
          (padicValRat p (normalizationQuotient P.b (P.repCandidate y (-1)))) ≤ 0) ∧
      (Even (P.repCandidate y 1) → padicValRat 2 (normalizationQuotient P.b (P.repCandidate y 1)) < 0) ∧
      (Even (P.repCandidate y (-1)) → padicValRat 2 (normalizationQuotient P.b (P.repCandidate y (-1))) < 0) := by
  obtain ⟨ν, hν⟩ := P.exists_integer_epsilonNorm hi
  have he : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν := by
    have hq : (P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2 = 4 * ν := by
      unfold epsilonNorm at hν
      linarith
    exact_mod_cast hq
  refine ⟨ν, hν, ?_, ?_, ?_, ?_⟩
  · intro p hp
    let : Fact p.Prime := ⟨hp⟩
    exact P.lemma33a_published h hb hu hN he p
  · intro p hp hs
    let : Fact p.Prime := ⟨hp⟩
    exact P.lemma33b h hb hu hN p hs
  · exact lemma33c_published hb (P.repCandidate_ne_zero h hu hN (Or.inl rfl))
  · exact lemma33c_published hb (P.repCandidate_ne_zero h hu hN (Or.inr rfl))

end Parameters
end «JNT-2024»
