module

public import «JNT-2024».FourthRootEstimates
public import «JNT-2024».FourthRootGeometry
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

/-- The explicit numerical substitution c1=0.127 in Lemma 3.7(a). -/
theorem expansion_constant_0127 :
    (3959 / 1000 : ℝ) < (2 - (127 / 1000 : ℝ)^2) * Real.sqrt (4 - (127 / 1000 : ℝ)^2) := by
  have hs := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 4 - (127 / 1000 : ℝ)^2)
  have hp := Real.sqrt_nonneg (4 - (127 / 1000 : ℝ)^2)
  nlinarith

/-- The minimizing phase from (3.31), followed by Lemma 3.7(a) with exactly
the printed 0.127, gives the strict 3.959 inequality used in (4.2). -/
theorem comparison_phase_3959 {ω v : ℂ} (hω : ‖ω‖ = 1) (hv : ‖v‖ = 1)
    (hpos : 0 < ‖ω-v^4‖) (hsmall : ‖ω-v^4‖ ≤ 1/2) :
    ∃ η : ℂ, FourthPhase η ∧
      (∀ ζ : ℂ, FourthPhase ζ →
        ‖ω^(1/4 : ℂ)-η*v‖ ≤ ‖ω^(1/4 : ℂ)-ζ*v‖) ∧
      ‖ω^(1/4 : ℂ)-η*v‖ < (127/1000 : ℝ) ∧
      (3959/1000 : ℝ)*‖ω^(1/4 : ℂ)-η*v‖ < ‖ω-v^4‖ := by
  let w := ω^(1/4 : ℂ)
  have hw : w^4=ω := by
    dsimp [w]
    convert Complex.cpow_nat_inv_pow ω (by norm_num : (4 : ℕ) ≠ 0) using 1; norm_num
  have hwn : ‖w‖=1 := by
    have hh := congrArg norm hw
    rw [norm_pow,hω] at hh
    nlinarith [sq_nonneg (‖w‖^2-1),norm_nonneg w]
  obtain ⟨η,hη,hd,hclose,hmin⟩ := fourth_root_half_minimizer hwn hv
    (by rwa [hw]) (by rwa [hw])
  have hzn : ‖η*v‖=1 := by rw [norm_mul,hη.norm,hv,mul_one]
  have hzp : (η*v)^4=v^4 := by rw [mul_pow,hη.pow_four,one_mul]
  have hc : (127/1000 : ℝ) < Real.sqrt 2 := by
    have hs := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
    nlinarith [Real.sqrt_nonneg (2 : ℝ)]
  have he := lemma37a hwn hzn (by norm_num : (0 : ℝ) < 127/1000) hc hd
    (by linarith : ‖w-η*v‖ < 127/1000)
  rw [hw,hzp] at he
  exact ⟨η,hη,hmin,by linarith,
    (mul_lt_mul_of_pos_right expansion_constant_0127 hd).trans he⟩

end «JNT-2024».Section4
