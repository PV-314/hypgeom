module

public import «JNT-2024».ApproximationGcd
public import «JNT-2024».NormalizerValuationsPublished
public import «JNT-2024».RepresentationValuations
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Approximation

/-- The stronger divisibility p^(ell1+2ell2)|x_k^2 stated before the weaker
p^(ell1+ell2)|x_k^2 in Lemma 3.11(1). This is an explicit consequence of the
same component formulas already used in the integrated printed proof. -/
theorem odd_prime_strong_square_divisibility (p : ℕ) [Fact p.Prime] (hp : p ≠ 2)
    {S X C ν : ℤ} (hS : S ≠ 0) (hC : C ≠ 0) (hν : ν = 1 ∨ ν = -1) :
    (p : ℤ)^(padicValNat p (g1 (2*X) (2*ν*C)^2) +
      2*padicValNat p (g2 S (2*X) (2*ν*C))) ∣ X^2 := by
  by_cases hX : X=0
  · simp [hX]
  have h1 := g1_square_valuation_published p hX hC hν
  have h2 := g2_valuation_published p hS hX hC hν
  rw [padicValNat_primes hp,zero_add] at h1
  rw [h1,h2]
  apply (padicValInt_dvd_iff _ _).mpr
  right
  rw [valuation_int_pow]
  have hm := Nat.min_le_left (padicValInt p X) (padicValInt p C)
  have hs := Nat.min_le_left
    (padicValInt p X - min (padicValInt p X) (padicValInt p C)) (padicValInt p S)
  omega

end «JNT-2024».Approximation
