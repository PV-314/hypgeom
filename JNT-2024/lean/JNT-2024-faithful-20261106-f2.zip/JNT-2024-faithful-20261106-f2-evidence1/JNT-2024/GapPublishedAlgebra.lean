module

public import «JNT-2024».FourthRootGeometry
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- This is alpha/Im(alpha), expressed using the common omega. It lets all
representation data retain the same imaginary-part comparison. -/
theorem gap_common_alpha (α : ℂ) (ha : α ≠ 0) (hi : 0 < α.im) :
    2 * Complex.I / (1 - star α / α) = α / (α.im : ℂ) := by
  have hT : (α.im : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr (ne_of_gt hi)
  have hdiff : α - star α = 2 * Complex.I * (α.im : ℂ) := by
    apply Complex.ext <;> simp
    ring
  rw [show 1 - star α / α = (α - star α) / α by field_simp]
  rw [hdiff]
  field_simp

/-- The imaginary-part identity in (3.18), with both allowed signs retained. -/
theorem gap_representation_imaginary {α z : ℂ} {x f ν τ : ℝ}
    (ha : α ≠ 0) (hi : 0 < α.im)
    (hν : ν = 1 ∨ ν = -1) (hτ : τ = 1 ∨ τ = -1)
    (he : ((τ * f ^ 2 : ℝ) : ℂ) * (⟨x, ν * α.im⟩ : ℂ) = α * z ^ 4) :
    |((2 * Complex.I / (1 - star α / α)) * z ^ 4).im| = f ^ 2 := by
  rw [gap_common_alpha α ha hi, div_mul_eq_mul_div, Complex.div_ofReal_im]
  have him : (α * z ^ 4).im = τ * f ^ 2 * (ν * α.im) := by
    have hh := congrArg Complex.im he
    simpa only [Complex.mul_im, Complex.ofReal_re, Complex.ofReal_im, zero_mul, add_zero] using hh.symm
  rw [him]
  rcases hν with rfl | rfl <;> rcases hτ with rfl | rfl <;>
    norm_num [ne_of_gt hi, neg_div]

theorem fourthPhase_sq (ζ : ℂ) (hζ : FourthPhase ζ) : ζ ^ 2 = 1 ∨ ζ ^ 2 = -1 := by
  rcases hζ with rfl | rfl | rfl | rfl <;> norm_num

/-- The normalized fourth power implicit in the nonzero-distance argument. -/
theorem ratio_sq_mul_norm_four (z : ℂ) (hz : z ≠ 0) :
    (z / star z) ^ 2 * (‖z‖ ^ 4 : ℂ) = z ^ 4 := by
  have hs : star z ≠ 0 := star_ne_zero.mpr hz
  have hn : (‖z‖ ^ 2 : ℂ) = z * star z := by
    rw [Complex.star_def, Complex.mul_conj, ← Complex.ofReal_pow, Complex.normSq_eq_norm_sq]
  rw [show (‖z‖ ^ 4 : ℂ) = (‖z‖ ^ 2 : ℂ) ^ 2 by ring, hn]
  field_simp

/-- Literal imaginary-part comparison after equality of the phase-adjusted
ratios; the squared phases are exactly the possible signs in the manuscript. -/
theorem phase_equality_imaginary {C z w ζ η : ℂ} {f g : ℝ}
    (hz : z ≠ 0) (hw : w ≠ 0) (hζ : FourthPhase ζ) (hη : FourthPhase η)
    (hzi : |(C * z ^ 4).im| = f ^ 2) (hwi : |(C * w ^ 4).im| = g ^ 2)
    (he : ζ * (z / star z) = η * (w / star w)) :
    f ^ 2 * ‖w‖ ^ 4 = g ^ 2 * ‖z‖ ^ 4 := by
  have hs := congrArg (fun a : ℂ => a ^ 2 * (‖z‖ ^ 4 : ℂ) * (‖w‖ ^ 4 : ℂ)) he
  have hnz := ratio_sq_mul_norm_four z hz
  have hnw := ratio_sq_mul_norm_four w hw
  have hc : ζ ^ 2 * z ^ 4 * (‖w‖ ^ 4 : ℂ) = η ^ 2 * w ^ 4 * (‖z‖ ^ 4 : ℂ) := by
    calc
      _ = (ζ * (z / star z)) ^ 2 * (‖z‖ ^ 4 : ℂ) * (‖w‖ ^ 4 : ℂ) := by rw [mul_pow]; rw [← hnz]; ring
      _ = _ := hs
      _ = _ := by rw [mul_pow, ← hnw]; ring
  have hh := congrArg (fun a : ℂ => |(C * a).im|) hc
  have hcalc (ρ v : ℂ) (R : ℝ) (hρ : ρ ^ 2 = 1 ∨ ρ ^ 2 = -1) (hR : 0 ≤ R) :
      |(C * (ρ ^ 2 * v ^ 4 * (R : ℂ))).im| = |(C * v ^ 4).im| * R := by
    rw [show C * (ρ ^ 2 * v ^ 4 * (R : ℂ)) = ρ ^ 2 * ((C * v ^ 4) * (R : ℂ)) by ring]
    rcases hρ with hρ | hρ <;> rw [hρ] <;>
      simp [Complex.mul_im, abs_mul, abs_of_nonneg hR]
  rw [← Complex.ofReal_pow, ← Complex.ofReal_pow] at hh
  rw [hcalc ζ z _ (fourthPhase_sq ζ hζ) (by positivity),
    hcalc η w _ (fourthPhase_sq η hη) (by positivity), hzi, hwi] at hh
  exact hh

end «JNT-2024»
