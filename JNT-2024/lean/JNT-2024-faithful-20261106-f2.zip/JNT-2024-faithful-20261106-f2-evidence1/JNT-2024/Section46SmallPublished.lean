module

public import «JNT-2024».Section46Calculation
public import «JNT-2024».Section46ListsPublished
public import «JNT-2024».Section46OrbitPublished
public import «JNT-2024».Section4SmallPairs
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- The printed finite parameter reduction: all admissible small-d equations
with square negative norm at most -4 occur in the 63-element enumeration. -/
theorem section46_parameter_pair (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hN : P.normAlpha ≤ -4) (hNs : IsSquare (-P.normAlpha)) (hd : P.d ≤ 111) :
    ∃ a n : ℕ, (a,n) ∈ Section4.smallPairs ∧ P.a=(a : ℤ) ∧ P.d=(a^2+n^2 : ℕ) := by
  obtain ⟨n,hn⟩ := hNs
  have hn2 : -P.normAlpha=n^2 := by simpa only [pow_two] using hn
  have hdn : P.d=P.a^2+n^2 := by
    simp only [normAlpha,hb,one_pow,one_mul] at hn2
    linarith
  have ha : P.a=(P.a.toNat : ℤ) := (Int.toNat_of_nonneg h.a_pos.le).symm
  have hnn : (n.natAbs : ℤ)^2=n^2 := by simp
  have hde : P.d=(P.a.toNat^2+n.natAbs^2 : ℕ) := by
    push_cast
    rw [sq_abs,← ha]
    exact hdn
  refine ⟨P.a.toNat,n.natAbs,?_,ha,hde⟩
  apply (Section4.mem_smallPairs_iff _ _).mpr
  have hap : 0 < P.a.toNat := by have hh := h.a_pos; omega
  have hnlo : 2 ≤ n.natAbs := by
    have hs : (4 : ℤ) ≤ (n.natAbs : ℤ)^2 := by rw [hnn]; omega
    have hs' : 4 ≤ n.natAbs^2 := by exact_mod_cast hs
    by_contra hh
    have he : n.natAbs=0 ∨ n.natAbs=1 := by omega
    rcases he with he | he <;> simp [he] at hs'
  refine ⟨hap,hnlo,?_,?_⟩
  · rw [hde] at hd
    exact_mod_cast hd
  · rintro ⟨q,hq⟩
    apply h.d_not_square
    refine ⟨(q : ℤ),?_⟩
    rw [hde,hq]
    push_cast
    rfl

/-- The 63 complete lists and the two printed orbit exclusions imply that
there is at most one distinct square sequence value above one. -/
theorem section46_pair_square_unique (hCalculation : Calculations.Section46Magma)
    (P : Parameters) (h : P.Admissible) (hb : P.b=1) (hn : P.normAlpha < 0)
    {a n : ℕ} (hp : (a,n) ∈ Section4.smallPairs)
    (ha : P.a=(a : ℤ)) (hd : P.d=(a^2+n^2 : ℕ)) {i j : ℤ}
    (hsi : IsIntegerSquare (P.y h.pell i)) (hsj : IsIntegerSquare (P.y h.pell j))
    (hyi : 1 < P.y h.pell i) (hyj : 1 < P.y h.pell j) :
    P.y h.pell i=P.y h.pell j := by
  obtain ⟨x,y,hx,hy,hiy,he⟩ := P.section46_sequence_solution h hb hn ha hd hsi hyi
  obtain ⟨X,Y,hX,hY,hjY,hE⟩ := P.section46_sequence_solution h hb hn ha hd hsj hyj
  have hm : (a,n)=(1,4) ∨ (a,n)=(2,8) → y ≠ 2 ∧ Y ≠ 2 := by
    rintro (hh | hh)
    · rcases Prod.mk.inj hh with ⟨rfl,rfl⟩
      have hd17 : P.d=17 := by norm_num at hd; exact hd
      have ha1 : P.a=1 := by exact_mod_cast ha
      constructor
      · intro hy2
        apply P.section46_y_ne_four_17 h hd17 ha1 hb i
        simpa only [hy2,Nat.cast_ofNat,show (2 : ℚ)^2=4 by norm_num] using hiy
      · intro hY2
        apply P.section46_y_ne_four_17 h hd17 ha1 hb j
        simpa only [hY2,Nat.cast_ofNat,show (2 : ℚ)^2=4 by norm_num] using hjY
    · rcases Prod.mk.inj hh with ⟨rfl,rfl⟩
      have hd68 : P.d=68 := by norm_num at hd; exact hd
      have ha2 : P.a=2 := by exact_mod_cast ha
      constructor
      · intro hy2
        apply P.section46_y_ne_four_68 h hd68 ha2 hb i
        simpa only [hy2,Nat.cast_ofNat,show (2 : ℚ)^2=4 by norm_num] using hiy
      · intro hY2
        apply P.section46_y_ne_four_68 h hd68 ha2 hb j
        simpa only [hY2,Nat.cast_ofNat,show (2 : ℚ)^2=4 by norm_num] using hjY
  have hroot := Section4.section46_noninitial_unique hCalculation hp hx hX hy hY he hE hm
  rw [hiy,hjY,hroot]

/-- The entire Magma branch of Section 4.6, including the exceptional orbits.
The norm -1 branch is the separate cited Akhtari application. -/
theorem section46_small_square_unique (hCalculation : Calculations.Section46Magma)
    (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hN : P.normAlpha ≤ -4) (hNs : IsSquare (-P.normAlpha)) (hd : P.d ≤ 111) {i j : ℤ}
    (hsi : IsIntegerSquare (P.y h.pell i)) (hsj : IsIntegerSquare (P.y h.pell j))
    (hyi : 1 < P.y h.pell i) (hyj : 1 < P.y h.pell j) :
    P.y h.pell i=P.y h.pell j := by
  obtain ⟨a,n,hp,ha,hde⟩ := P.section46_parameter_pair h hb hN hNs hd
  exact P.section46_pair_square_unique hCalculation h hb (by omega) hp ha hde hsi hsj hyi hyj

end «JNT-2024».Parameters
