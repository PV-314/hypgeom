module

public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

abbrev SquarefreeNormAlgebra (P : Parameters) := QuadraticAlgebra ℚ (squarefreePart P.normAlpha : ℚ) 0

/-- Substitute `√Nα = squareFactor(Nα) √sf(Nα)`. -/
noncomputable def normToSquarefree (P : Parameters) : P.NormAlgebra →ₐ[ℚ] P.SquarefreeNormAlgebra :=
  QuadraticAlgebra.changeGenerator (squarefreePart P.normAlpha : ℚ) 0
    (squareFactor P.normAlpha : ℚ) 0
    (by simpa using (show (P.normAlpha : ℚ) =
      (squareFactor P.normAlpha : ℚ) ^ 2 * squarefreePart P.normAlpha from
        by exact_mod_cast (squareFactor_sq_mul P.normAlpha).symm)) (by simp)

theorem normToSquarefree_apply (P : Parameters) (z : P.NormAlgebra) :
    P.normToSquarefree z = ⟨z.re, (squareFactor P.normAlpha : ℚ) * z.im⟩ := by
  ext <;> simp [normToSquarefree, QuadraticAlgebra.changeGenerator, QuadraticAlgebra.lift,
    QuadraticAlgebra.re_one, QuadraticAlgebra.im_one]
  ring

/-- The two equalities in (3.2), without the separate divisibility bound on `f`. -/
def FourthPowerRepresentation (P : Parameters) (x y f r s : ℤ) : Prop :=
  (f : ℚ) ^ 2 • (⟨(x : ℚ), P.epsilonNorm * squareFactor P.normAlpha⟩ : P.SquarefreeNormAlgebra) =
      (⟨(P.a : ℚ), (squareFactor P.normAlpha : ℚ)⟩ : P.SquarefreeNormAlgebra) *
        (⟨(r : ℚ), (s : ℚ)⟩ : P.SquarefreeNormAlgebra) ^ 4 ∧
    f * y = P.b * (r ^ 2 - squarefreePart P.normAlpha * s ^ 2)

























/-- Common-factor cancellation in (3.2). This isolates the algebra from the valuation bounds. -/
theorem representation_cancel_factor (P : Parameters) {x y F R S g : ℤ} (hg : g ≠ 0)
    (h : P.FourthPowerRepresentation x y (g ^ 2 * F) (g * R) (g * S)) :
    P.FourthPowerRepresentation x y F R S := by
  obtain ⟨hpow, hnorm⟩ := h
  constructor
  · have hgq : (g : ℚ) ≠ 0 := by exact_mod_cast hg
    have hz : (⟨((g * R : ℤ) : ℚ), ((g * S : ℤ) : ℚ)⟩ : P.SquarefreeNormAlgebra) =
        (g : ℚ) • (⟨(R : ℚ), (S : ℚ)⟩ : P.SquarefreeNormAlgebra) := by ext <;> simp
    have hf : (((g ^ 2 * F : ℤ) : ℚ) ^ 2) = (g : ℚ) ^ 4 * (F : ℚ) ^ 2 := by push_cast; ring
    rw [hz, hf, smul_pow, ← smul_smul, mul_smul_comm] at hpow
    ext
    · have he := congrArg QuadraticAlgebra.re hpow
      simp only [QuadraticAlgebra.re_smul, smul_eq_mul] at he
      exact mul_left_cancel₀ (pow_ne_zero 4 hgq) he
    · have he := congrArg QuadraticAlgebra.im hpow
      simp only [QuadraticAlgebra.im_smul, smul_eq_mul] at he
      exact mul_left_cancel₀ (pow_ne_zero 4 hgq) he
  · have he : g ^ 2 * (F * y) = g ^ 2 * (P.b * (R ^ 2 - squarefreePart P.normAlpha * S ^ 2)) := by
      nlinarith only [hnorm]
    exact mul_left_cancel₀ (pow_ne_zero 2 hg) he

/-- Dividing by an admissible `g` produces integral parameters in (3.2). -/
theorem exists_normalized_representation (P : Parameters) {x y f r s g : ℤ}
    (h : P.FourthPowerRepresentation x y f r s) (hf : f ≠ 0) (hg : g ≠ 0)
    (hgf : g ^ 2 ∣ f) (hgr : g ∣ r) (hgs : g ∣ s) :
    ∃ F R S : ℤ, F ≠ 0 ∧ f = g ^ 2 * F ∧ r = g * R ∧ s = g * S ∧
      P.FourthPowerRepresentation x y F R S := by
  obtain ⟨F, rfl⟩ := hgf
  obtain ⟨R, rfl⟩ := hgr
  obtain ⟨S, rfl⟩ := hgs
  exact ⟨F, R, S, (mul_ne_zero_iff.mp hf).2, rfl, rfl, rfl, P.representation_cancel_factor hg h⟩

end «JNT-2024».Parameters
