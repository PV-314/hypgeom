module

public import «JNT-2024».ArgumentBounds
public import «JNT-2024».ComplexRepresentation
public import «JNT-2024».FourthRootEstimates
public import «JNT-2024».FourthRootGeometry
public import «JNT-2024».GapLattice
public import «JNT-2024».GapNormalization
public import «JNT-2024».GapPrinciple
public import «JNT-2024».GapRepresentationBounds
public import «JNT-2024».Lemma39PublishedAlgebra
public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».RepresentationGaussian
public import «JNT-2024».Sequence
public import «JNT-2024».SequenceRepresentations
public import «JNT-2024».SquarefreePart
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

theorem fourth_phase_separation {ζ η : ℂ} (hζ : FourthPhase ζ) (hη : FourthPhase η) (hne : ζ ≠ η) :
    2 ≤ ‖ζ - η‖ ^ 2 := by
  rw [← Complex.normSq_eq_norm_sq]
  rcases hζ with rfl | rfl | rfl | rfl <;> rcases hη with rfl | rfl | rfl | rfl <;>
    first | exact (hne rfl).elim | norm_num [Complex.normSq_apply]


/-- The printed 0.403 versus sqrt(2)-0.127 comparison following (3.31). -/
theorem phase_minimizer_published {w z σ : ℂ} (hw : ‖w‖ = 1) (hz : ‖z‖ = 1)
    (hσ : FourthPhase σ) (hpos : 0 < ‖w ^ 4 - z ^ 4‖)
    (hsmall : ‖w ^ 4 - z ^ 4‖ ≤ 1 / 2) (hclose : ‖w - σ * z‖ < 403 / 1000) :
    ∀ θ : ℂ, FourthPhase θ → θ ≠ σ → ‖w - σ * z‖ < ‖w - θ * z‖ := by
  obtain ⟨η, hη, _, hηclose, _⟩ := fourth_root_half_minimizer hw hz hpos hsmall
  have hroot := Real.sqrt_nonneg (2 : ℝ)
  have hroot2 := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
  have hnum : (403 / 1000 : ℝ) < Real.sqrt 2 - 127 / 1000 := by nlinarith
  have hfar : ∀ θ : ℂ, FourthPhase θ → θ ≠ η →
      Real.sqrt 2 - 127 / 1000 < ‖w - θ * z‖ := by
    intro θ hθ hne
    have hsep := fourth_phase_separation hη hθ (Ne.symm hne)
    have hsep' : Real.sqrt 2 ≤ ‖η - θ‖ := by nlinarith [norm_nonneg (η - θ)]
    have he : ‖η * z - θ * z‖ = ‖η - θ‖ := by rw [← sub_mul, norm_mul, hz, mul_one]
    have htri := norm_add_le (η * z - w) (w - θ * z)
    rw [sub_add_sub_cancel, he, norm_sub_rev (η * z) w] at htri
    linarith
  have hησ : η = σ := by
    by_contra hne
    have hh := hfar σ hσ (Ne.symm hne)
    linarith
  subst η
  intro θ hθ hne
  exact lt_trans hclose (lt_trans hnum (hfar θ hθ hne))


theorem samePhaseClass_ratio_sign {ζ η : ℂ} (hη : FourthPhase η) (hc : SamePhaseClass ζ η) :
    ζ / η = 1 ∨ ζ / η = -1 := by
  have hne : η ≠ 0 := by intro he; have hh := hη.norm; simp [he] at hh
  rcases hc with rfl | he
  · left; exact div_self hne
  · right; rw [he, neg_div, div_self hne]

namespace FourthPowerDatum

theorem ratio_quotient_cross {D : ℤ} {b t : ℝ} {ω : ℂ} (p q : FourthPowerDatum D b t ω) :
    p.ratio / q.ratio = star (star p.point * q.point) / (star p.point * q.point) := by
  simp only [ratio, star_mul, star_star]
  field_simp

theorem phased_ratio_close_one {D : ℤ} {b t : ℝ} {ω w ζ η : ℂ}
    (p q : FourthPowerDatum D b t ω) (ht : 0 < t)
    (_hζ : FourthPhase ζ) (hη : FourthPhase η) (hlarge : 4 * t ≤ p.y) (hy : p.y ≤ q.y)
    (hp : ‖w - ζ * p.ratio‖ * p.y < (5051 / 10000 : ℝ) * t)
    (hq : ‖w - η * q.ratio‖ * q.y < (5051 / 10000 : ℝ) * t) :
    ‖(ζ / η) * (p.ratio / q.ratio) - 1‖ < 253 / 1000 := by
  have hqn : ‖η * q.ratio‖ = 1 := by rw [norm_mul, hη.norm, q.ratio_norm, mul_one]
  have hqne : η * q.ratio ≠ 0 := by intro he; simp [he] at hqn
  have hηne := (mul_ne_zero_iff.mp hqne).1
  have hqrne := (mul_ne_zero_iff.mp hqne).2
  have he : (ζ / η) * (p.ratio / q.ratio) - 1 =
      (ζ * p.ratio - η * q.ratio) / (η * q.ratio) := by field_simp
  rw [he, norm_div, hqn, div_one]
  have hpbound : ‖w - ζ * p.ratio‖ < 5051 / 40000 := by nlinarith [norm_nonneg (w - ζ * p.ratio)]
  have hqbound : ‖w - η * q.ratio‖ < 5051 / 40000 := by
    have hlargeq := le_trans hlarge hy
    nlinarith [norm_nonneg (w - η * q.ratio)]
  have htri := norm_add_le (ζ * p.ratio - w) (w - η * q.ratio)
  rw [sub_add_sub_cancel, norm_sub_rev (ζ * p.ratio) w] at htri
  linarith

end FourthPowerDatum

namespace Parameters


theorem lemma39b (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    {k ℓ : ℤ} (p q : P.SequenceDatum)
    (hp : P.SequenceGapCertificate h.pell k p) (hq : P.SequenceGapCertificate h.pell ℓ q)
    (hy : (P.y h.pell k : ℝ) < (P.y h.pell ℓ : ℝ))
    (hlarge : 4 * Real.sqrt (|(P.normAlpha : ℝ)| / P.d) ≤ (P.y h.pell k : ℝ))
    {w ζ η : ℂ} (hζ : FourthPhase ζ) (hη : FourthPhase η) (hc : SamePhaseClass ζ η)
    (hpk : ‖w - ζ * p.ratio‖ * p.y < (5051 / 10000 : ℝ) * P.gapScale)
    (hqℓ : ‖w - η * q.ratio‖ * q.y < (5051 / 10000 : ℝ) * P.gapScale) :
    ∃ σ : ℂ, (σ = 1 ∨ σ = -1) ∧
      ∀ θ : ℂ, FourthPhase θ → θ ≠ σ →
        ‖principalFourthRoot (P.sequenceOmega h.pell k) - σ *
          (star (star p.point * q.point) / (star p.point * q.point))‖ <
        ‖principalFourthRoot (P.sequenceOmega h.pell k) - θ *
          (star (star p.point * q.point) / (star p.point * q.point))‖ := by
  have ht := P.gapScale_pos h.b_pos hn
  have hsign := samePhaseClass_ratio_sign hη hc
  have hph : FourthPhase (ζ / η) := by rcases hsign with he | he <;> simp [he, FourthPhase]
  have hclose := p.phased_ratio_close_one q ht hζ hη
    (by rw [hp.1, P.gapScale_eq_sqrt h.b_pos hn]; exact hlarge)
    (by rw [hp.1, hq.1]; exact hy.le) hpk hqℓ
  have hwclose := principalFourthRoot_close (lt_trans (P.lemma39a h hn hlarge).1 (P.lemma39a h hn hlarge).2)
  have hz : ‖p.ratio / q.ratio‖ = 1 := by rw [norm_div, p.ratio_norm, q.ratio_norm, div_one]
  have htri := norm_add_le (principalFourthRoot (P.sequenceOmega h.pell k) - 1)
    (1 - (ζ / η) * (p.ratio / q.ratio))
  rw [sub_add_sub_cancel, norm_sub_rev 1] at htri
  have h403 : ‖principalFourthRoot (P.sequenceOmega h.pell k) - (ζ / η) * (p.ratio / q.ratio)‖ < 403 / 1000 := by
    linarith
  have hres : ‖principalFourthRoot (P.sequenceOmega h.pell k) ^ 4 -
      (p.ratio / q.ratio) ^ 4‖ * q.y = 2 * P.gapScale := by
    rw [principalFourthRoot_pow_four (P.sequenceOmega_norm h.pell hn k), p.ratio_quotient_cross q]
    exact P.sequence_cross_residual_published h hn p q hp hq
  have hpos : 0 < ‖principalFourthRoot (P.sequenceOmega h.pell k) ^ 4 - (p.ratio / q.ratio) ^ 4‖ := by
    nlinarith [q.y_pos]
  have hlq : 4 * P.gapScale ≤ q.y := by
    rw [hq.1, P.gapScale_eq_sqrt h.b_pos hn]
    exact le_trans hlarge hy.le
  have hsmall : ‖principalFourthRoot (P.sequenceOmega h.pell k) ^ 4 - (p.ratio / q.ratio) ^ 4‖ ≤ 1 / 2 := by
    nlinarith [q.y_pos]
  refine ⟨ζ / η, hsign, ?_⟩
  simpa only [p.ratio_quotient_cross q] using
    phase_minimizer_published (principalFourthRoot_norm _) hz hph hpos hsmall h403

/-- The formulation of Lemma 3.9(b) using the minimizing phases in (3.20).
The approximation inequalities are consequences, rather than extra hypotheses. -/
theorem lemma39b_of_minimizers (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    {k ℓ : ℤ} (p q : P.SequenceDatum)
    (hp : P.SequenceGapCertificate h.pell k p) (hq : P.SequenceGapCertificate h.pell ℓ q)
    (hy : (P.y h.pell k : ℝ) < (P.y h.pell ℓ : ℝ))
    (hlarge : 4 * Real.sqrt (|(P.normAlpha : ℝ)| / P.d) ≤ (P.y h.pell k : ℝ))
    {w ζ η : ℂ} (hw : w ^ 4 = P.gapOmega)
    (hζ : FourthPhase ζ) (hη : FourthPhase η) (hc : SamePhaseClass ζ η)
    (hminp : ∀ θ : ℂ, FourthPhase θ → ‖w - ζ * p.ratio‖ ≤ ‖w - θ * p.ratio‖)
    (hminq : ∀ θ : ℂ, FourthPhase θ → ‖w - η * q.ratio‖ ≤ ‖w - θ * q.ratio‖) :
    ∃ σ : ℂ, (σ = 1 ∨ σ = -1) ∧
      ∀ θ : ℂ, FourthPhase θ → θ ≠ σ →
        ‖principalFourthRoot (P.sequenceOmega h.pell k) - σ *
          (star (star p.point * q.point) / (star p.point * q.point))‖ <
        ‖principalFourthRoot (P.sequenceOmega h.pell k) - θ *
          (star (star p.point * q.point) / (star p.point * q.point))‖ := by
  have hwn : ‖w‖ = 1 := by
    have hh := congrArg norm hw
    rw [norm_pow, P.gapOmega_norm hn] at hh
    have hs : ‖w‖ ^ 2 = 1 := by nlinarith [sq_nonneg (‖w‖ ^ 2 - 1)]
    nlinarith [norm_nonneg w]
  have ht := P.gapScale_pos h.b_pos hn
  have hlp : 4 * P.gapScale ≤ p.y := by
    rw [hp.1, P.gapScale_eq_sqrt h.b_pos hn]
    exact hlarge
  have hlq : 4 * P.gapScale ≤ q.y := by
    rw [hq.1, P.gapScale_eq_sqrt h.b_pos hn]
    exact le_trans hlarge hy.le
  obtain ⟨θ, hθ, hθbound⟩ := p.phase_approximation ht hw hwn hlp
  obtain ⟨φ, hφ, hφbound⟩ := q.phase_approximation ht hw hwn hlq
  exact P.lemma39b h hn p q hp hq hy hlarge hζ hη hc
    (lt_of_le_of_lt (mul_le_mul_of_nonneg_right (hminp θ hθ) p.y_pos.le) hθbound)
    (lt_of_le_of_lt (mul_le_mul_of_nonneg_right (hminq φ hφ) q.y_pos.le) hφbound)

end Parameters
end «JNT-2024»
