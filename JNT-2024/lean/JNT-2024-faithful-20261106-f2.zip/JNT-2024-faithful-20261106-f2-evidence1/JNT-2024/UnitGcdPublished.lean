module

public import «JNT-2024».Sequence
public import «JNT-2024».UnitGcdCasesPublished
public import «JNT-2024».UnitPowers
public import «JNT-2024».UnitSequenceIntegrality
public import «JNT-2024».UnitSequencePublished
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- The integrality equivalence used in the opening odd-gcd normalization of Lemma 3.10. -/
theorem half_integral_odd_scale {x : ℚ} {D G : ℤ} (hd : 2 * x = D) (hg : Odd G) :
    (∃ X : ℤ, (G : ℚ) * x = X) ↔ ∃ X : ℤ, x = X := by
  constructor
  · rintro ⟨X,hx⟩
    obtain ⟨g,hg⟩ := hg
    refine ⟨X - g * D, ?_⟩
    have hg' : (G : ℚ) = 2 * (g : ℚ) + 1 := by exact_mod_cast hg
    push_cast
    rw [hg'] at hx
    linear_combination hx - (g : ℚ) * hd
  · rintro ⟨X,rfl⟩
    exact ⟨G * X, by push_cast; rfl⟩

namespace Parameters

theorem unit_coordinates_scale (P : Parameters) (A B G : ℤ) (n : ℕ) :
    P.unitX (A * G) (B * G) n = G * P.unitX A B n ∧
    P.unitY (A * G) (B * G) n = G * P.unitY A B n := by
  constructor <;> simp [unitX, unitY, QuadraticAlgebra.re_mul, QuadraticAlgebra.im_mul] <;> ring

theorem unit_integrality_odd_scale (P : Parameters) (hp : P.Pell) (A B G : ℤ)
    (hg : Odd G) (n : ℕ) :
    ((∃ X : ℤ, P.unitX (A * G) (B * G) n = X) ↔ ∃ X : ℤ, P.unitX A B n = X) ∧
    ((∃ Y : ℤ, P.unitY (A * G) (B * G) n = Y) ↔ ∃ Y : ℤ, P.unitY A B n = Y) := by
  obtain ⟨ν,_,hν,_⟩ := P.unit_norm_integer_sign hp
  have hd := P.unit_doubled_coordinates hν A B n
  rw [(P.unit_coordinates_scale A B G n).1, (P.unit_coordinates_scale A B G n).2]
  exact ⟨half_integral_odd_scale hd.1 hg, half_integral_odd_scale hd.2 hg⟩

/-- Lemma 3.10, with its full odd-gcd hypothesis, following the printed
normalization, recurrence identities, integrality cases, and gcd descents.
 -/
theorem lemma310_published (P : Parameters) (hp : P.Pell) {A B X Y : ℤ} (hA : A ≠ 0)
    (ho : Odd (Int.gcd A B)) (n : ℕ)
    (he : (⟨(X : ℚ), (Y : ℚ)⟩ : P.Algebra) =
      (⟨(A : ℚ), (B : ℚ)⟩ : P.Algebra) * P.epsilon ^ n) :
    Int.gcd X Y = Int.gcd A B ∨ Int.gcd X Y = 2 * Int.gcd A B := by
  have hx : P.unitX A B n = X := (congrArg QuadraticAlgebra.re he).symm
  have hy : P.unitY A B n = Y := (congrArg QuadraticAlgebra.im he).symm
  obtain ⟨A₀,B₀,hab,ha,hb⟩ := Int.exists_gcd_one (Int.gcd_pos_of_ne_zero_left B hA)
  let G := Int.gcd A B
  have hg : Odd (G : ℤ) := by exact_mod_cast ho
  have hi := P.unit_integrality_odd_scale hp A₀ B₀ G hg n
  have hx' : P.unitX (A₀ * G) (B₀ * G) n = X := by simpa only [G, ← ha, ← hb] using hx
  have hy' : P.unitY (A₀ * G) (B₀ * G) n = Y := by simpa only [G, ← ha, ← hb] using hy
  obtain ⟨X₀,hx₀⟩ := hi.1.mp ⟨X,hx'⟩
  obtain ⟨Y₀,hy₀⟩ := hi.2.mp ⟨Y,hy'⟩
  have hs := P.unit_coordinates_scale A₀ B₀ G n
  rw [hx', hy', hx₀, hy₀] at hs
  have hX : X = (G : ℤ) * X₀ := by exact_mod_cast hs.1
  have hY : Y = (G : ℤ) * Y₀ := by exact_mod_cast hs.2
  have hc := P.unit_gcd_coprime_published hp A₀ B₀ hab n hx₀ hy₀
  have hG : Int.gcd X Y = G * Int.gcd X₀ Y₀ := by
    rw [hX, hY, Int.gcd_mul_left, Int.natAbs_natCast]
  rcases hc with hc | hc
  · exact Or.inl (by simpa [hc, G] using hG)
  · exact Or.inr (by simpa [hc, G, mul_comm] using hG)

end Parameters
end «JNT-2024»
