module

public import «JNT-2024».GammaBounds
public import «JNT-2024».HypergeometricPolynomials
public import «JNT-2024».HypergeometricRecurrence
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

/-- The least common denominator of the coefficients of `X_{1,4,r}`. -/
def denominator4 (r : ℕ) : ℕ :=
  (Finset.range (r + 1)).lcm (fun j => (coefficient (1 / 4) r j).den)

theorem denominator4_ne_zero (r : ℕ) : denominator4 r ≠ 0 := by
  simp [denominator4]

theorem denominator4_pos (r : ℕ) : 0 < denominator4 r := Nat.pos_of_ne_zero (denominator4_ne_zero r)

theorem coefficient_den_dvd_denominator4 (r j : ℕ) :
    (coefficient (1 / 4) r j).den ∣ denominator4 r := by
  by_cases hj : j < r + 1
  · exact Finset.dvd_lcm (Finset.mem_range.mpr hj)
  · rw [coefficient_vanishes (1 / 4) (by omega : r < j)]
    simp

theorem rat_den_dvd_iff_integer_mul (q : ℚ) (D : ℕ) :
    q.den ∣ D ↔ ∃ a : ℤ, (a : ℚ) = (D : ℚ) * q := by
  constructor
  · rintro ⟨k, rfl⟩
    refine ⟨(k : ℤ) * q.num, ?_⟩
    push_cast
    rw [mul_right_comm, Rat.den_mul_eq_num]
    ring
  · rintro ⟨a, ha⟩
    by_cases hD : D = 0
    · simp [hD]
    have hDq : (D : ℚ) ≠ 0 := by exact_mod_cast hD
    have hq : q = (a : ℚ) / D := by rw [ha]; field_simp
    have hd := Rat.den_dvd a (D : ℤ)
    have he : Rat.divInt a (D : ℤ) = (a : ℚ) / D := by simp [Rat.divInt_eq_div]
    rw [he, ← hq] at hd
    exact_mod_cast hd

/-- Characterization by divisibility, stronger than numerical minimality. -/
theorem denominator4_dvd_iff (r D : ℕ) :
    denominator4 r ∣ D ↔
      ∀ j : ℕ, ∃ a : ℤ, (a : ℚ) = (D : ℚ) * coefficient (1 / 4) r j := by
  constructor
  · intro hD j
    exact (rat_den_dvd_iff_integer_mul _ D).mp ((coefficient_den_dvd_denominator4 r j).trans hD)
  · intro h
    apply Finset.lcm_dvd
    intro j _
    exact (rat_den_dvd_iff_integer_mul _ D).mpr (h j)

theorem denominator4_le (r D : ℕ) (hD : 0 < D)
    (h : ∀ j : ℕ, ∃ a : ℤ, (a : ℚ) = (D : ℚ) * coefficient (1 / 4) r j) :
    denominator4 r ≤ D := Nat.le_of_dvd hD ((denominator4_dvd_iff r D).mpr h)

def integralCoefficient4 (r j : ℕ) : ℤ :=
  ((denominator4 r : ℚ) * coefficient (1 / 4) r j).num

theorem integralCoefficient4_cast (r j : ℕ) :
    (integralCoefficient4 r j : ℚ) = (denominator4 r : ℚ) * coefficient (1 / 4) r j := by
  obtain ⟨a, ha⟩ := (denominator4_dvd_iff r (denominator4 r)).mp dvd_rfl j
  unfold integralCoefficient4
  rw [← ha, Rat.num_intCast]

theorem denominator4_zero : denominator4 0 = 1 := by simp [denominator4, coefficient_zero]

/-- The second Gamma quotient in Lemma 2.3(a), represented exactly over the rationals. -/
def gammaNumeratorRatio (r : ℕ) : ℚ := risingQ (1 / 4) (r + 1) / r.factorial

def parityLoss (r : ℕ) : ℚ := if r % 2 = 0 then 1 else 2

/-- A rational lower approximation to `exp(1.68)`; its analytic comparison is proved separately. -/
def denominatorExponentialLower : ℚ := 107311 / 20000

def FiniteDenominatorCheck (r : ℕ) : Prop :=
  parityLoss r * (gammaRatio r * denominator4 r) ^ 2 <
      (293 / 250 : ℚ) ^ 2 * denominatorExponentialLower ^ (2 * r) ∧
  parityLoss r * (gammaNumeratorRatio r * denominator4 r) ^ 2 <
      (537 / 2000 : ℚ) ^ 2 * denominatorExponentialLower ^ (2 * r)


end Hypergeometric
end «JNT-2024»
