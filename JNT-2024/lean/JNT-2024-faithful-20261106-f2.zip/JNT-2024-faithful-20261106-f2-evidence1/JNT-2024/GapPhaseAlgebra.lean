module

public import «JNT-2024».FourthRootGeometry
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

theorem fourth_phase_relative {ζ η : ℂ} (hζ : FourthPhase ζ) (hη : FourthPhase η) :
    η = ζ ∨ η = -ζ ∨ η = Complex.I * ζ ∨ η = -Complex.I * ζ := by
  rcases hζ with rfl | rfl | rfl | rfl <;>
    rcases hη with rfl | rfl | rfl | rfl <;> norm_num [Complex.I_mul_I]

theorem phase_integer_coordinates {ζ : ℂ} (hζ : FourthPhase ζ) (A B : ℤ) :
    ∃ a b : ℤ, ζ * (⟨A, B⟩ : ℂ) = (⟨a, b⟩ : ℂ) := by
  rcases hζ with rfl | rfl | rfl | rfl
  · exact ⟨A, B, by simp⟩
  · exact ⟨-A, -B, by apply Complex.ext <;> simp⟩
  · exact ⟨-B, A, by apply Complex.ext <;> simp⟩
  · exact ⟨B, -A, by apply Complex.ext <;> simp⟩

/-- The literal numerator of (3.23), where x+iy is conjugate(p)*q. -/
theorem printed_cross_numerator (ζ η : ℂ) (x y : ℝ) :
    ζ * star (⟨x, y⟩ : ℂ) - η * (⟨x, y⟩ : ℂ) =
      2 * ζ * (x : ℂ) - (ζ + η) * (⟨x, y⟩ : ℂ) := by
  apply Complex.ext <;> simp <;> ring

/-- The four displayed alternatives in (3.24), with y already including
the positive square root of -sf(N). -/
theorem printed_cross_numerator_cases (ζ : ℂ) (x y : ℝ) :
    (ζ * star (⟨x, y⟩ : ℂ) - ζ * (⟨x, y⟩ : ℂ) = -2 * ζ * Complex.I * y) ∧
    (ζ * star (⟨x, y⟩ : ℂ) - (-ζ) * (⟨x, y⟩ : ℂ) = 2 * ζ * x) ∧
    (ζ * star (⟨x, y⟩ : ℂ) - (Complex.I * ζ) * (⟨x, y⟩ : ℂ) =
      ζ * (1 - Complex.I) * (x + y)) ∧
    (ζ * star (⟨x, y⟩ : ℂ) - (-Complex.I * ζ) * (⟨x, y⟩ : ℂ) =
      ζ * (1 + Complex.I) * (x - y)) := by
  refine ⟨?_, ?_, ?_, ?_⟩ <;> apply Complex.ext <;> simp <;> ring

/-- The factor 1+i in the Gaussian numerator, with an explicit integral
quotient. This replaces the earlier sixteen-case norm shortcut. -/
theorem gaussian_phase_divisible_one_add_I {A B : ℤ} {ζ η : ℂ}
    (hζ : FourthPhase ζ) (hη : FourthPhase η) :
    ∃ a b : ℤ, ζ * (⟨A, B⟩ : ℂ) - η * star (⟨A, B⟩ : ℂ) =
      (1 + Complex.I) * (⟨a, b⟩ : ℂ) := by
  have step (a b : ℤ)
      (he : ζ * (⟨A, B⟩ : ℂ) - η * star (⟨A, B⟩ : ℂ) =
        (1 + Complex.I) * (ζ * (⟨a, b⟩ : ℂ))) :
      ∃ a b : ℤ, ζ * (⟨A, B⟩ : ℂ) - η * star (⟨A, B⟩ : ℂ) =
        (1 + Complex.I) * (⟨a, b⟩ : ℂ) := by
    obtain ⟨r, s, hrs⟩ := phase_integer_coordinates hζ a b
    exact ⟨r, s, by rwa [hrs] at he⟩
  rcases fourth_phase_relative hζ hη with he | he | he | he
  · apply step B B
    rw [he]
    apply Complex.ext <;> simp
    ring
  · apply step A (-A)
    rw [he]
    apply Complex.ext <;> simp
    ring
  · apply step 0 (B - A)
    rw [he]
    apply Complex.ext <;> simp <;> ring
  · apply step (A + B) 0
    rw [he]
    apply Complex.ext <;> simp <;> ring

end «JNT-2024»
