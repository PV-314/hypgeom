module

public import «JNT-2024».Section5Finite
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- The inverse of the unsquared unit, including the negative-norm case. -/
def epsilonBack (P : Parameters) : P.Algebra :=
  ⟨P.epsilonNorm * P.t / 2, -P.epsilonNorm * P.u / 2⟩

theorem epsilon_mul_back (P : Parameters) (hp : P.Pell) : P.epsilon * P.epsilonBack = 1 := by
  have hh := P.pell_sq hp
  ext <;> simp [epsilon, epsilonBack, epsilonNorm, QuadraticAlgebra.re_one, QuadraticAlgebra.im_one]
  · nlinarith only [hh]
  · ring

def epsilonUnit (P : Parameters) (hp : P.Pell) : P.Algebraˣ where
  val := P.epsilon
  inv := P.epsilonBack
  val_inv := P.epsilon_mul_back hp
  inv_val := by rw [mul_comm]; exact P.epsilon_mul_back hp

/-- Conjecture 1.3 and Section 6.3 use `α ε^k`, rather than `α ε^(2k)`. -/
def generalY (P : Parameters) (hp : P.Pell) (k : ℤ) : ℚ :=
  (P.alpha * ((P.epsilonUnit hp) ^ k : P.Algebraˣ)).im

theorem epsilonUnit_sq (P : Parameters) (hp : P.Pell) :
    P.epsilonUnit hp ^ 2 = P.stepUnit hp := by
  apply Units.ext
  change P.epsilon ^ 2 = P.step
  exact P.step_eq_epsilon_sq.symm

theorem generalY_even (P : Parameters) (hp : P.Pell) (k : ℤ) :
    P.generalY hp (2*k) = P.y hp k := by
  unfold generalY y term
  rw [zpow_mul, zpow_ofNat, P.epsilonUnit_sq]

end «JNT-2024».Parameters

namespace «JNT-2024».Section6

def evalGeneral (P : Parameters) (k : ℤ) : ℚ :=
  (P.alpha * (if k < 0 then P.epsilonBack else P.epsilon) ^ k.natAbs).im

def evalEven (P : Parameters) (k : ℤ) : ℚ :=
  Section5.evalY P (decide (k < 0)) k.natAbs

theorem evalGeneral_eq (P : Parameters) (hp : P.Pell) (k : ℤ) :
    evalGeneral P k = P.generalY hp k := by
  by_cases hk : k < 0
  · have he := Int.eq_neg_natAbs_of_nonpos hk.le
    conv_rhs => rw [he]
    simp only [evalGeneral, hk, ↓reduceIte, Parameters.generalY, zpow_neg, zpow_natCast,
      ← inv_pow, Units.val_pow_eq_pow_val]
    rfl
  · have he : (k.natAbs : ℤ) = k := by simp [abs_of_nonneg (le_of_not_gt hk)]
    conv_rhs => rw [← he]
    simp only [evalGeneral, hk, ↓reduceIte, Parameters.generalY, zpow_natCast,
      Units.val_pow_eq_pow_val]
    rfl

theorem evalEven_eq (P : Parameters) (hp : P.Pell) (k : ℤ) :
    evalEven P k = P.y hp k := by
  unfold evalEven
  by_cases hk : k < 0
  · simp only [hk, decide_true]
    rw [Section5.evalY_negative P hp]
    congr 1
    exact (Int.eq_neg_natAbs_of_nonpos hk.le).symm
  · simp only [hk, decide_false]
    rw [Section5.evalY_positive P hp]
    congr 1
    simp [abs_of_nonneg (le_of_not_gt hk)]

/-- A finite witness to at least `m` distinct square values. -/
def AtLeastSquares (y : ℤ → ℚ) (m : ℕ) : Prop :=
  ∃ k : Fin m → ℤ, Function.Injective (fun i => y (k i)) ∧
    ∀ i, IsIntegerSquare (y (k i))


def Good (P : Parameters) : Prop :=
  0 < P.a ∧ 0 < P.b ∧ 0 < P.d ∧ 0 < P.t ∧ 0 < P.u ∧ ¬ IsSquare P.d ∧ P.Pell

instance (P : Parameters) : Decidable (Good P) := by unfold Good Parameters.Pell; infer_instance

theorem Good.admissible {P : Parameters} (h : Good P) : P.Admissible :=
  ⟨h.1, h.2.1, h.2.2.1, h.2.2.2.1, h.2.2.2.2.1, h.2.2.2.2.2.1, h.2.2.2.2.2.2⟩

structure Row (m : ℕ) where
  parameters : Parameters
  index : Fin m → ℤ
  root : Fin m → ℤ

def Row.Checked {m : ℕ} (r : Row m) (general : Bool) : Prop :=
  Good r.parameters ∧ Function.Injective (fun i => (r.root i : ℚ)^2) ∧
    ∀ i, (if general then evalGeneral r.parameters (r.index i) else evalEven r.parameters (r.index i)) = (r.root i : ℚ)^2

instance {m : ℕ} (r : Row m) (general : Bool) : Decidable (r.Checked general) := by
  unfold Row.Checked Function.Injective
  infer_instance

theorem Row.lower_bound {m : ℕ} {r : Row m} {general : Bool} (h : r.Checked general) :
    AtLeastSquares (if general then r.parameters.generalY h.1.admissible.pell else r.parameters.y h.1.admissible.pell) m := by
  have hv : ∀ i, (if general then r.parameters.generalY h.1.admissible.pell (r.index i)
      else r.parameters.y h.1.admissible.pell (r.index i)) = (r.root i : ℚ)^2 := by
    intro i
    have hi := h.2.2 i
    cases general
    · simpa only [Bool.false_eq_true, ↓reduceIte, evalEven_eq _ h.1.admissible.pell] using hi
    · simpa only [↓reduceIte, evalGeneral_eq _ h.1.admissible.pell] using hi
  refine ⟨r.index, ?_, ?_⟩
  · intro i j he
    apply h.2.1
    have hi := hv i
    have hj := hv j
    cases general <;> simp only [Bool.false_eq_true, ↓reduceIte] at hi hj he <;>
      exact hi.symm.trans (he.trans hj)
  · intro i
    refine ⟨r.root i, ?_⟩
    have hi := hv i
    cases general <;> simpa only [Bool.false_eq_true, ↓reduceIte] using hi

end «JNT-2024».Section6
