module

public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section5

theorem card_pair_le (a b : ℚ) : ({a, b} : Finset ℚ).card ≤ 2 := by
  simpa using Finset.card_insert_le a {b}

theorem square_eq_one_or_gt_one {q : ℚ} (hq : 0 < q) (hs : IsIntegerSquare q) :
    q = 1 ∨ 1 < q := by
  obtain ⟨v, rfl⟩ := hs
  have hi : (0 : ℤ) < v ^ 2 := by exact_mod_cast hq
  rcases eq_or_lt_of_le (show (1 : ℤ) ≤ v ^ 2 by omega) with hh | hh
  · left; exact_mod_cast hh.symm
  · right; exact_mod_cast hh

theorem atMost_two_of_unique {y : ℤ → ℚ} (hy : ∀ k, 0 < y k)
    (hu : ∀ i j, IsIntegerSquare (y i) → IsIntegerSquare (y j) →
      1 < y i → 1 < y j → y i = y j) : AtMostSquareValues y 2 := by
  classical
  by_cases he : ∃ i, IsIntegerSquare (y i) ∧ 1 < y i
  · obtain ⟨i, hi, hi1⟩ := he
    refine ⟨{1, y i}, card_pair_le _ _, ?_⟩
    intro k hk
    rcases square_eq_one_or_gt_one (hy k) hk with hh | hh
    · simp [hh]
    · simp [hu k i hk hi hh hi1]
  · refine ⟨{1}, by simp, ?_⟩
    intro k hk
    rcases square_eq_one_or_gt_one (hy k) hk with hh | hh
    · simp [hh]
    · exact False.elim (he ⟨k, hk, hh⟩)

theorem atMost_three_of_one_extra {y : ℤ → ℚ} (hy : ∀ k, 0 < y k) (v : ℚ)
    (hu : ∀ i j, IsIntegerSquare (y i) → IsIntegerSquare (y j) →
      1 < y i → 1 < y j → y i ≠ v → y j ≠ v → y i = y j) :
    AtMostSquareValues y 3 := by
  classical
  by_cases he : ∃ i, IsIntegerSquare (y i) ∧ 1 < y i ∧ y i ≠ v
  · obtain ⟨i, hi, hi1, hiv⟩ := he
    refine ⟨{1, v, y i}, ?_, ?_⟩
    · exact (Finset.card_insert_le _ _).trans (by have hh := card_pair_le v (y i); omega)
    · intro k hk
      rcases square_eq_one_or_gt_one (hy k) hk with hh | hh
      · simp [hh]
      · by_cases hkv : y k = v
        · simp [hkv]
        · simp [hu k i hk hi hh hi1 hkv hiv]
  · refine ⟨{1, v}, (card_pair_le _ _).trans (by decide), ?_⟩
    intro k hk
    rcases square_eq_one_or_gt_one (hy k) hk with hh | hh
    · simp [hh]
    · have hv : y k = v := by by_contra hv; exact he ⟨k, hk, hh, hv⟩
      simp [hv]

end «JNT-2024».Section5

namespace «JNT-2024».Parameters


end «JNT-2024».Parameters
