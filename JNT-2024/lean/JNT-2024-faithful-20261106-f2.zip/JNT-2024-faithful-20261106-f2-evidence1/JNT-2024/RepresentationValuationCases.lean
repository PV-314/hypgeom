module

public import «JNT-2024».RepresentationValuations
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- Squarefree decomposition identifies the valuation of the square factor. -/
theorem valuation_squareFactor_eq_half (p : ℕ) [Fact p.Prime] {r : ℤ}
    (hr : r ≠ 0) : padicValInt p (squareFactor r) = padicValInt p r / 2 := by
  have h := valuation_squarePart p hr
  have hs := valuation_squarefree_le_one p (squarefreePart_squarefree r)
  omega

/-- The common gcd valuation formula from which (3.3) and (3.5) split. -/
theorem normalizationGcd_sq_valuation (p : ℕ) [Fact p.Prime] {b r : ℤ}
    (hb : b ≠ 0) (hr : r ≠ 0) :
    padicValInt p ((normalizationGcd b r : ℤ) ^ 2) =
      2 * min (padicValInt p (2 : ℤ) + padicValInt p b + padicValInt p r / 2)
        (padicValInt p r) := by
  rw [valuation_int_pow]
  change 2 * padicValNat p (normalizationGcd b r) = _
  have h2b : 2 * b ≠ 0 := mul_ne_zero (by norm_num) hb
  rw [normalizationGcd, valuation_gcd p
    (mul_ne_zero h2b (ne_of_gt (squareFactor_pos hr))) hr,
    padicValInt.mul h2b (ne_of_gt (squareFactor_pos hr)),
    padicValInt.mul (by norm_num : (2 : ℤ) ≠ 0) hb,
    valuation_squareFactor_eq_half p hr]

/-- All four branches of (3.3), including the overlapping equality cases. -/
theorem paper_eq33 (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2) {b r : ℤ}
    (hb : b ≠ 0) (hr : r ≠ 0) :
    let k₁ := padicValInt p b
    let k₂ := padicValInt p r
    let v := padicValInt p ((normalizationGcd b r : ℤ) ^ 2)
    (k₂ % 2 = 0 → 2 * k₁ ≤ k₂ → v = 2 * k₁ + k₂) ∧
    (k₂ % 2 = 0 → k₂ ≤ 2 * k₁ → v = 2 * k₂) ∧
    (k₂ % 2 = 1 → (2 * k₁ : ℤ) - 1 ≤ k₂ → v = 2 * k₁ + k₂ - 1) ∧
    (k₂ % 2 = 1 → (k₂ : ℤ) ≤ 2 * k₁ - 1 → v = 2 * k₂) := by
  have hp : padicValInt p (2 : ℤ) = 0 := by
    change padicValNat p 2 = 0
    exact padicValNat_primes hp2
  dsimp only
  rw [normalizationGcd_sq_valuation p hb hr, hp, zero_add]
  omega

/-- All four branches of (3.5), including the overlapping equality cases. -/
theorem paper_eq35 {b r : ℤ} (hb : b ≠ 0) (hr : r ≠ 0) :
    let k₁ := padicValInt 2 b
    let k₂ := padicValInt 2 r
    let v := padicValInt 2 ((normalizationGcd b r : ℤ) ^ 2)
    (k₂ % 2 = 0 → 2 * k₁ + 2 ≤ k₂ → v = 2 * k₁ + k₂ + 2) ∧
    (k₂ % 2 = 0 → k₂ ≤ 2 * k₁ + 2 → v = 2 * k₂) ∧
    (k₂ % 2 = 1 → 2 * k₁ + 1 ≤ k₂ → v = 2 * k₁ + k₂ + 1) ∧
    (k₂ % 2 = 1 → k₂ ≤ 2 * k₁ + 1 → v = 2 * k₂) := by
  have hp : padicValInt 2 (2 : ℤ) = 1 := by norm_num [padicValInt]
  dsimp only
  rw [normalizationGcd_sq_valuation 2 hb hr, hp]
  omega

end «JNT-2024»
