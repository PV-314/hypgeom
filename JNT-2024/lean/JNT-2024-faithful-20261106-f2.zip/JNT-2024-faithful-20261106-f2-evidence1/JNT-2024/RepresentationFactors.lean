module

public import «JNT-2024».RepresentationValuations
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- The paper's `sf(|n|)` is the absolute value of the signed squarefree part. -/
theorem squarefreePart_abs {n : ℤ} (hn : n ≠ 0) : squarefreePart |n| = |squarefreePart n| := by
  have hs : Squarefree |squarefreePart n| := by
    simpa only [Int.natCast_natAbs] using
      (Int.squarefree_natCast.mpr (Int.squarefree_natAbs.mpr (squarefreePart_squarefree n)))
  apply squarefreePart_eq_of_factorization (c := squareFactor n) (abs_ne_zero.mpr hn) hs
  have hh := congrArg (abs : ℤ → ℤ) (squareFactor_sq_mul n)
  simpa only [abs_mul, abs_of_nonneg (sq_nonneg (squareFactor n))] using hh

theorem int_dvd_of_valuation_le {a b : ℤ} (ha : a ≠ 0) (hb : b ≠ 0)
    (h : ∀ p : ℕ, p.Prime → padicValInt p a ≤ padicValInt p b) : a ∣ b := by
  apply Int.natAbs_dvd_natAbs.mp
  apply (Nat.dvd_iff_prime_pow_dvd_dvd _ _).mpr
  intro p k hp hd
  let : Fact p.Prime := ⟨hp⟩
  exact (padicValNat_dvd_iff_le (Int.natAbs_ne_zero.mpr hb)).mpr
    (le_trans ((padicValNat_dvd_iff_le (Int.natAbs_ne_zero.mpr ha)).mp hd) (h p hp))

theorem prime_dvd_iff_valuation_pos (p : ℕ) [Fact p.Prime] {a : ℤ} (ha : a ≠ 0) :
    (p : ℤ) ∣ a ↔ 0 < padicValInt p a := by
  have hh := padicValInt_dvd_iff (p := p) 1 a
  simpa only [pow_one, ha, false_or, Nat.succ_le_iff] using hh


theorem valuation_radical_pos_of_dvd (p : ℕ) [hp : Fact p.Prime] {a : ℤ}
    (ha : a ≠ 0) (hd : (p : ℤ) ∣ a) :
    1 ≤ padicValInt p (UniqueFactorizationMonoid.radical a) := by
  apply (prime_dvd_iff_valuation_pos p UniqueFactorizationMonoid.radical_ne_zero).mp
  exact (UniqueFactorizationMonoid.dvd_radical_iff_of_irreducible
    (Nat.prime_iff_prime_int.mp hp.out).irreducible ha).mpr hd

theorem normalizationQuotient_ne_zero (b : ℤ) {r : ℤ} (hr : r ≠ 0) :
    normalizationQuotient b r ≠ 0 := by
  apply div_ne_zero (by exact_mod_cast hr)
  exact pow_ne_zero _ (by exact_mod_cast ne_of_gt (normalizationGcd_pos b hr))


/-- The strict size bound used to select a candidate, including the unit case. -/
theorem small_coprime_factor {a b n : ℕ} (ha : 0 < a) (hb : 0 < b) (hn : 0 < n)
    (hc : a.Coprime b) (hd : a * b ∣ n) :
    ((min a b : ℕ) : ℝ) < max 2 (Real.sqrt n) := by
  have hab : a * b ≤ n := Nat.le_of_dvd hn hd
  by_cases he : a = b
  · have ha1 : a = 1 := Nat.eq_one_of_dvd_coprimes hc (dvd_refl _) (by rw [he])
    rw [← he, min_self, ha1]
    norm_num
  have hlt : (min a b) ^ 2 < n := by
    rcases lt_or_gt_of_ne he with hh | hh
    · rw [min_eq_left (le_of_lt hh)]
      nlinarith
    · rw [min_eq_right (le_of_lt hh)]
      nlinarith
  have hltR : (((min a b : ℕ) : ℝ)) ^ 2 < (n : ℝ) := by exact_mod_cast hlt
  have hnR : (0 : ℝ) ≤ n := by positivity
  have hs := Real.sq_sqrt hnR
  have hs0 := Real.sqrt_nonneg (n : ℝ)
  have hm0 : (0 : ℝ) ≤ (min a b : ℕ) := by positivity
  have hltS : ((min a b : ℕ) : ℝ) < Real.sqrt n := by nlinarith
  exact lt_of_lt_of_le hltS (le_max_right _ _)

/-- Valuation of the integral coefficient obtained by dividing the raw representation. -/
theorem normalized_coefficient_valuation (p : ℕ) [Fact p.Prime] {b r f σ : ℤ}
    (hb : b ≠ 0) (hr : r ≠ 0) (hσ : σ = 1 ∨ σ = -1)
    (he : σ * 4 * b ^ 2 * r = (normalizationGcd b r : ℤ) ^ 2 * f) :
    (padicValInt p f : ℤ) = padicValInt p (4 * b ^ 2) +
      padicValRat p (normalizationQuotient b r) := by
  have hg : (normalizationGcd b r : ℚ) ≠ 0 := by
    exact_mod_cast ne_of_gt (normalizationGcd_pos b hr)
  have hbq : (4 * b ^ 2 : ℚ) ≠ 0 := mul_ne_zero (by norm_num) (pow_ne_zero _ (by exact_mod_cast hb))
  have hq := normalizationQuotient_ne_zero b hr
  have heq : (f : ℚ) = (σ : ℚ) * (4 * (b : ℚ) ^ 2) * normalizationQuotient b r := by
    have he' : (σ : ℚ) * 4 * (b : ℚ) ^ 2 * r = (normalizationGcd b r : ℚ) ^ 2 * f := by
      exact_mod_cast he
    unfold normalizationQuotient
    field_simp
    nlinarith only [he']
  have hv := congrArg (padicValRat p) heq
  have hcval : padicValRat p (4 * (b : ℚ) ^ 2) = (padicValInt p (4 * b ^ 2) : ℤ) := by
    have hc : ((4 * b ^ 2 : ℤ) : ℚ) = 4 * (b : ℚ) ^ 2 := by push_cast; rfl
    rw [← hc, padicValRat.of_int]
  rcases hσ with rfl | rfl
  · simp only [Int.cast_one, one_mul, padicValRat.of_int] at hv
    rw [padicValRat.mul hbq hq] at hv
    simpa only [hcval] using hv
  · simp only [Int.cast_neg, Int.cast_one, neg_mul, one_mul, padicValRat.neg,
      padicValRat.of_int] at hv
    rw [padicValRat.mul hbq hq] at hv
    simpa only [hcval] using hv

theorem normalized_coefficient_dvd_four {b r f σ R : ℤ}
    (hb : b ≠ 0) (hr : r ≠ 0) (hf : f ≠ 0) (hR : R ≠ 0) (hσ : σ = 1 ∨ σ = -1)
    (he : σ * 4 * b ^ 2 * r = (normalizationGcd b r : ℤ) ^ 2 * f)
    (hv : ∀ p : ℕ, p.Prime → padicValRat p (normalizationQuotient b r) ≤ padicValInt p R) :
    f ∣ 4 * b ^ 2 * R := by
  have hc : 4 * b ^ 2 ≠ 0 := mul_ne_zero (by norm_num) (pow_ne_zero _ hb)
  apply int_dvd_of_valuation_le hf (mul_ne_zero hc hR)
  intro p hp
  let : Fact p.Prime := ⟨hp⟩
  have he' := normalized_coefficient_valuation p hb hr hσ he
  have hv' := hv p hp
  rw [padicValInt.mul hc hR]
  omega

theorem valuation_four_mul_square (p : ℕ) [Fact p.Prime] {b : ℤ} (hb : b ≠ 0) :
    padicValInt p (4 * b ^ 2) = 2 * padicValInt p (2 : ℤ) + 2 * padicValInt p b := by
  rw [padicValInt.mul (by norm_num) (pow_ne_zero _ hb), valuation_int_pow]
  have hh := valuation_int_pow p (2 : ℤ) 2
  norm_num at hh
  rw [hh]

theorem valuation_two_eq_zero {p : ℕ} [hp : Fact p.Prime] (hp2 : p ≠ 2) :
    padicValInt p (2 : ℤ) = 0 := by
  apply padicValInt.eq_zero_of_not_dvd
  intro hd
  have hd' : p ∣ 2 := by exact_mod_cast hd
  exact hp2 ((Nat.prime_dvd_prime_iff_eq hp.out Nat.prime_two).mp hd')

theorem normalized_coefficient_dvd_two {b r f σ R : ℤ}
    (hb : b ≠ 0) (hr : r ≠ 0) (hf : f ≠ 0) (hR : R ≠ 0) (hσ : σ = 1 ∨ σ = -1)
    (he : σ * 4 * b ^ 2 * r = (normalizationGcd b r : ℤ) ^ 2 * f)
    (hv : ∀ p : ℕ, p.Prime → padicValRat p (normalizationQuotient b r) ≤ padicValInt p R)
    (hv2 : padicValRat 2 (normalizationQuotient b r) < 0) : f ∣ 2 * b ^ 2 * R := by
  have hc : 2 * b ^ 2 ≠ 0 := mul_ne_zero (by norm_num) (pow_ne_zero _ hb)
  apply int_dvd_of_valuation_le hf (mul_ne_zero hc hR)
  intro p hp
  let : Fact p.Prime := ⟨hp⟩
  have he' := normalized_coefficient_valuation p hb hr hσ he
  rw [valuation_four_mul_square p hb] at he'
  rw [padicValInt.mul hc hR, padicValInt.mul (by norm_num) (pow_ne_zero _ hb), valuation_int_pow]
  by_cases hp2 : p = 2
  · subst p
    have h2 : padicValInt 2 (2 : ℤ) = 1 := padicValInt.self (by norm_num)
    rw [h2] at he' ⊢
    omega
  · have hh := valuation_two_eq_zero hp2
    have hv' := hv p hp
    rw [hh] at he' ⊢
    omega

end «JNT-2024»
