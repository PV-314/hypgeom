module

public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- The positive integer `g₁` whose square is the gcd in Lemmas 3.2 and 3.3. -/
noncomputable def normalizationGcd (b r : ℤ) : ℕ := Int.gcd (2 * b * squareFactor r) r

theorem normalizationGcd_pos (b : ℤ) {r : ℤ} (hr : r ≠ 0) : 0 < normalizationGcd b r :=
  Int.gcd_pos_of_ne_zero_right _ hr

theorem normalizationGcd_sq (b r : ℤ) :
    normalizationGcd b r ^ 2 = Int.gcd (4 * b ^ 2 * r / squarefreePart r) (r ^ 2) := by
  have he : 4 * b ^ 2 * r = (2 * b * squareFactor r) ^ 2 * squarefreePart r := by
    nth_rw 1 [← squareFactor_sq_mul r]
    ring
  rw [he, Int.mul_ediv_cancel _ (squarefreePart_ne_zero r), Int.pow_gcd_pow]
  rfl

/-- The rational quantity `r₁/g₁²` in Lemma 3.3. -/
noncomputable def normalizationQuotient (b r : ℤ) : ℚ :=
  (r : ℚ) / (normalizationGcd b r : ℚ) ^ 2

theorem valuation_gcd (p : ℕ) [Fact p.Prime] {a b : ℤ} (ha : a ≠ 0) (hb : b ≠ 0) :
    padicValNat p (Int.gcd a b) = min (padicValInt p a) (padicValInt p b) := by
  have hg : Int.gcd a b ≠ 0 := ne_of_gt (Int.gcd_pos_of_ne_zero_right a hb)
  apply le_antisymm
  · apply le_min
    · apply (padicValNat_dvd_iff_le (p := p) (Int.natAbs_ne_zero.mpr ha)).mp
      exact dvd_trans pow_padicValNat_dvd (Int.gcd_dvd_natAbs_left a b)
    · apply (padicValNat_dvd_iff_le (p := p) (Int.natAbs_ne_zero.mpr hb)).mp
      exact dvd_trans pow_padicValNat_dvd (Int.gcd_dvd_natAbs_right a b)
  · apply (padicValNat_dvd_iff_le (p := p) hg).mp
    apply Int.dvd_gcd_iff.mpr
    constructor
    · exact (padicValInt_dvd_iff _ a).mpr (Or.inr (min_le_left _ _))
    · exact (padicValInt_dvd_iff _ b).mpr (Or.inr (min_le_right _ _))

theorem valuation_int_pow (p : ℕ) [Fact p.Prime] (a : ℤ) (n : ℕ) :
    padicValInt p (a ^ n) = n * padicValInt p a := by
  simp only [padicValInt, Int.natAbs_pow, padicValNat.pow]

theorem valuation_squarefree_le_one (p : ℕ) [hp : Fact p.Prime] {s : ℤ} (hs : Squarefree s) :
    padicValInt p s ≤ 1 := by
  by_contra h
  have hd : (p : ℤ) ^ 2 ∣ s := (padicValInt_dvd_iff _ s).mpr (Or.inr (by omega))
  exact Int.squarefree_iff_prime_sq_not_dvd.mp hs p hp.out hd

theorem valuation_squarePart (p : ℕ) [Fact p.Prime] {r : ℤ} (hr : r ≠ 0) :
    padicValInt p r = 2 * padicValInt p (squareFactor r) + padicValInt p (squarefreePart r) := by
  conv_lhs => rw [← squareFactor_sq_mul r]
  rw [padicValInt.mul (pow_ne_zero _ (ne_of_gt (squareFactor_pos hr))) (squarefreePart_ne_zero r),
    valuation_int_pow]

theorem normalizationQuotient_valuation (p : ℕ) [Fact p.Prime] {b r : ℤ}
    (hb : b ≠ 0) (hr : r ≠ 0) :
    padicValRat p (normalizationQuotient b r) = (padicValInt p r : ℤ) -
      2 * (min (padicValInt p (2 * b) + padicValInt p (squareFactor r)) (padicValInt p r) : ℕ) := by
  have h2b : 2 * b ≠ 0 := mul_ne_zero (by norm_num) hb
  have hc : squareFactor r ≠ 0 := ne_of_gt (squareFactor_pos hr)
  have hgq : (normalizationGcd b r : ℚ) ≠ 0 := by exact_mod_cast ne_of_gt (normalizationGcd_pos b hr)
  rw [normalizationQuotient, padicValRat.div (by exact_mod_cast hr) (pow_ne_zero _ hgq),
    padicValRat.pow, padicValRat.of_int, padicValRat.of_nat]
  rw [normalizationGcd, valuation_gcd p (mul_ne_zero h2b hc) hr, padicValInt.mul h2b hc]
  norm_num












/-- Positivity singles out an odd valuation in `r` and excludes primes dividing `2b`. -/
theorem normalizationQuotient_positive (p : ℕ) [Fact p.Prime] {b r : ℤ}
    (hb : b ≠ 0) (hr : r ≠ 0) (hq : 0 < padicValRat p (normalizationQuotient b r)) :
    padicValInt p (squarefreePart r) = 1 ∧ padicValInt p (2 * b) = 0 := by
  have he := valuation_squarePart p hr
  have hs := valuation_squarefree_le_one p (squarefreePart_squarefree r)
  rw [normalizationQuotient_valuation p hb hr] at hq
  rcases le_total (padicValInt p (2 * b) + padicValInt p (squareFactor r)) (padicValInt p r) with hh | hh
  · rw [min_eq_left hh] at hq
    omega
  · rw [min_eq_right hh] at hq
    omega
























/-- The parity argument in Lemma 3.3(b), in a general product form. -/
theorem normalizationQuotient_pair_nonpositive (p : ℕ) [Fact p.Prime] {b r r' u N : ℤ}
    (hb : b ≠ 0) (hr : r ≠ 0) (hr' : r' ≠ 0) (hu : u ≠ 0) (hN : N ≠ 0)
    (hprod : r * r' = u ^ 2 * N) (hpN : 0 < padicValInt p (squarefreePart N)) :
    min (padicValRat p (normalizationQuotient b r))
      (padicValRat p (normalizationQuotient b r')) ≤ 0 := by
  by_contra h
  have hq : 0 < padicValRat p (normalizationQuotient b r) := by omega
  have hq' : 0 < padicValRat p (normalizationQuotient b r') := by omega
  have hs := (normalizationQuotient_positive p hb hr hq).1
  have hs' := (normalizationQuotient_positive p hb hr' hq').1
  have hNs := valuation_squarefree_le_one p (squarefreePart_squarefree N)
  have hv := congrArg (padicValInt p) hprod
  rw [padicValInt.mul hr hr', padicValInt.mul (pow_ne_zero _ hu) hN, valuation_int_pow] at hv
  have he := valuation_squarePart p hr
  have he' := valuation_squarePart p hr'
  have heN := valuation_squarePart p hN
  omega

namespace Parameters

/-- Lemma 3.3(b), with the paper's two candidates and gcd denominators. -/
theorem lemma33b (P : Parameters) {x y : ℤ} (h : P.RepresentsSquare x y)
    (hb : P.b ≠ 0) (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0)
    (p : ℕ) [Fact p.Prime] (hpN : 0 < padicValInt p (squarefreePart P.normAlpha)) :
    min (padicValRat p (normalizationQuotient P.b (P.repCandidate y 1)))
      (padicValRat p (normalizationQuotient P.b (P.repCandidate y (-1)))) ≤ 0 := by
  exact normalizationQuotient_pair_nonpositive p hb
    (P.repCandidate_ne_zero h hu hN (Or.inl rfl))
    (P.repCandidate_ne_zero h hu hN (Or.inr rfl)) hu hN (P.repCandidate_product h) hpN

end Parameters
end «JNT-2024»
