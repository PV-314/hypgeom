module

public import «JNT-2024».ApproximationGcd
public import «JNT-2024».NormalizerHighComponentsPublished
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».NormalizerPublished
public import «JNT-2024».NormalizerValuationsPublished
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- The last step of Lemma 3.12: the printed component valuations make the
nonnegative exponent from Lemma 3.11 zero. -/
theorem normalizer_eq_base_high_valuation_published (P : Parameters) (h : P.Admissible)
    (hc : Int.gcd P.a P.b = 1) (hn : P.normAlpha < 0)
    (hh : padicValNat 2 P.baseGcd + 5 ≤ padicValInt 2 P.normAlpha)
    {k X Y ν : ℤ} (hx : P.x h.pell k = X) (hy : P.y h.pell k = Y) (hν : ν = 1 ∨ ν = -1) :
    Approximation.gSquared (squarefreePart P.normAlpha) (2 * X)
      (2 * ν * squareFactor P.normAlpha) = P.baseGcd := by
  obtain ⟨m,hm⟩ := P.lemma311_published h hc hn hx hy hν
  have hi := P.high_norm_normalizer_components_published h hc hn hh hx hy hν
  have hC := ne_of_gt (squareFactor_pos (ne_of_lt hn))
  have hu : 2 * ν * squareFactor P.normAlpha ≠ 0 := by rcases hν with rfl | rfl <;> simpa using hC
  have hv := Approximation.gSquared_valuation_published 2 (squarefreePart_ne_zero P.normAlpha) hu (u₁ := 2 * X)
  rw [hi.1,hi.2.1,hi.2.2] at hv
  rw [show 4 = 2 ^ 2 by decide, padicValNat.pow] at hv
  norm_num at hv
  have hv₂ : padicValRat 2 2 = 1 := padicValRat.self (by decide)
  have hB : (P.baseGcd : ℚ) ≠ 0 := by exact_mod_cast ne_of_gt (P.baseGcd_pos (ne_of_gt h.a_pos))
  have hmv := congrArg (padicValRat 2) hm
  rw [padicValRat.mul (pow_ne_zero _ (by norm_num)) hB, padicValRat.pow,
    hv₂, mul_one, padicValRat.of_nat, hv] at hmv
  have hm₀ : m = 0 := by omega
  simpa only [hm₀,pow_zero,one_mul] using hm

theorem normalizer_eq_base_of_high_norm_published (P : Parameters) (h : P.Admissible)
    (hc : Int.gcd P.a P.b = 1) (hn : P.normAlpha < 0)
    (hd : 32 * (P.baseGcd : ℤ) ∣ P.normAlpha) {k X Y ν : ℤ}
    (hx : P.x h.pell k = (X : ℚ)) (hy : P.y h.pell k = (Y : ℚ))
    (hν : ν = 1 ∨ ν = -1) :
    Approximation.gSquared (squarefreePart P.normAlpha) (2 * X)
      (2 * ν * squareFactor P.normAlpha) = P.baseGcd := by
  have hG : (2 : ℤ) ^ padicValNat 2 P.baseGcd ∣ (P.baseGcd : ℤ) := by
    exact_mod_cast (pow_padicValNat_dvd (p := 2) (n := P.baseGcd))
  have hN : (2 : ℤ) ^ (padicValNat 2 P.baseGcd + 5) ∣ P.normAlpha := by
    rw [pow_add, show (2 : ℤ) ^ 5 = 32 by norm_num]
    exact (mul_dvd_mul hG (dvd_refl (32 : ℤ))).trans (by simpa only [mul_comm] using hd)
  have hh := ((padicValInt_dvd_iff _ _).mp hN).resolve_left (ne_of_lt hn)
  exact P.normalizer_eq_base_high_valuation_published h hc hn hh hx hy hν

end «JNT-2024».Parameters
