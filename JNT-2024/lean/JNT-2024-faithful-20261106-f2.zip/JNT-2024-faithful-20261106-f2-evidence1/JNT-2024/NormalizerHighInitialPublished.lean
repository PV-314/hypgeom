module

public import «JNT-2024».NormalizerParity
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».NormalizerTwoPublished
public import «JNT-2024».RepresentationBothEvenPublished
public import «JNT-2024».RepresentationFactors
public import «JNT-2024».RepresentationGaussian
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».Sequence
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

theorem odd_valuation_two_zero {z : ℤ} (hz : Odd z) : padicValInt 2 z = 0 :=
  padicValInt.eq_zero_of_not_dvd (fun hd => Int.not_even_iff_odd.mpr hz (even_iff_two_dvd.mpr hd))

theorem integer_remove_two_power {a : ℤ} (ha : a ≠ 0) :
    ∃ A : ℤ, a = (2 : ℤ) ^ padicValInt 2 a * A ∧ Odd A := by
  obtain ⟨A,hA⟩ := padicValInt_dvd (p := 2) a
  change a = (2 : ℤ) ^ padicValInt 2 a * A at hA
  have hA₀ : A ≠ 0 := by intro hz; rw [hz,mul_zero] at hA; exact ha hA
  have hv := congrArg (padicValInt 2) hA
  rw [padicValInt.mul (pow_ne_zero _ (by norm_num)) hA₀, valuation_int_pow] at hv
  rw [show padicValInt 2 (2 : ℤ) = 1 by norm_num [padicValInt], mul_one] at hv
  refine ⟨A,hA,odd_of_valuation_two_zero hA₀ ?_⟩
  simp only [padicValInt] at hv ⊢
  omega

namespace Parameters

/-- The first paragraph of Lemma 3.12's high-valuation argument. -/
theorem high_norm_initial_valuations_published (P : Parameters) (h : P.Admissible)
    (hc : Int.gcd P.a P.b = 1) (hn : P.normAlpha < 0)
    (hh : padicValNat 2 P.baseGcd + 5 ≤ padicValInt 2 P.normAlpha) :
    Odd P.b ∧ padicValInt 2 (P.a ^ 2) = padicValNat 2 P.baseGcd ∧
    padicValInt 2 (P.d * P.b ^ 4) = padicValNat 2 P.baseGcd ∧
    padicValInt 2 P.d = padicValNat 2 P.baseGcd ∧ Even (padicValNat 2 P.baseGcd) := by
  have hsame : padicValInt 2 (P.a ^ 2) = padicValInt 2 (P.d * P.b ^ 4) := by
    by_contra hne
    have he := (P.initial_norm_two_valuation_cases h (ne_of_lt hn)).2 hne
    omega
  have hg := valuation_gcd 2 (pow_ne_zero 2 (ne_of_gt h.a_pos))
    (mul_ne_zero (ne_of_gt h.d_pos) (pow_ne_zero 4 (ne_of_gt h.b_pos)))
  change padicValNat 2 P.baseGcd = _ at hg
  rw [hsame, min_self] at hg
  have hb : Odd P.b := P.odd_b_of_even_norm hc (even_iff_two_dvd.mpr
    ((prime_dvd_iff_valuation_pos 2 (ne_of_lt hn)).mpr (by omega)))
  have hvb := odd_valuation_two_zero hb
  have hvd := hg
  rw [padicValInt.mul (ne_of_gt h.d_pos) (pow_ne_zero _ (ne_of_gt h.b_pos)),
    valuation_int_pow, hvb, mul_zero, add_zero] at hvd
  have he : Even (padicValNat 2 P.baseGcd) := by
    refine ⟨padicValInt 2 P.a, ?_⟩
    rw [← hg.symm, ← hsame, valuation_int_pow]
    ring
  exact ⟨hb,hsame.trans hg.symm,hg.symm,hvd.symm,he⟩

/-- The printed congruence d/2^ell = 1 mod 8, with its normalization supplied explicitly. -/
theorem high_norm_normalized_d_mod_eight (P : Parameters) (h : P.Admissible)
    (hc : Int.gcd P.a P.b = 1) (hn : P.normAlpha < 0)
    (hh : padicValNat 2 P.baseGcd + 5 ≤ padicValInt 2 P.normAlpha) :
    (P.d / (2 : ℤ) ^ padicValNat 2 P.baseGcd) % 8 = 1 := by
  let e := padicValNat 2 P.baseGcd
  have hi := P.high_norm_initial_valuations_published h hc hn hh
  have he : e = 2 * padicValInt 2 P.a := by dsimp [e]; rw [← hi.2.1, valuation_int_pow]
  obtain ⟨A,hA,hAo⟩ := integer_remove_two_power (ne_of_gt h.a_pos)
  have hDdiv : (2 : ℤ) ^ e ∣ P.d := (padicValInt_dvd_iff _ _).mpr (Or.inr (by rw [hi.2.2.2.1]))
  obtain ⟨D,hD⟩ := hDdiv
  have hpow : ((2 : ℤ) ^ padicValInt 2 P.a) ^ 2 = (2 : ℤ) ^ e := by
    rw [← pow_mul, he, Nat.mul_comm]
  have hA₂ : P.a ^ 2 = (2 : ℤ) ^ e * A ^ 2 := by rw [hA, mul_pow, hpow]
  have hN : P.normAlpha = (2 : ℤ) ^ e * (A ^ 2 - D * P.b ^ 4) := by
    unfold normAlpha
    rw [hA₂, hD]
    ring
  have h8 : (2 : ℤ) ^ e * 8 ∣ P.normAlpha := by
    have hd : (2 : ℤ) ^ (e + 3) ∣ P.normAlpha :=
      (padicValInt_dvd_iff _ _).mpr (Or.inr (by dsimp [e]; omega))
    simpa only [pow_add, show (2 : ℤ) ^ 3 = 8 by norm_num] using hd
  rw [hN] at h8
  have h8' := (mul_dvd_mul_iff_left (pow_ne_zero e (by norm_num : (2 : ℤ) ≠ 0))).mp h8
  have ha8 := odd_square_mod_eight hAo
  have hb8 : P.b ^ 4 % 8 = 1 := by
    have hh := odd_square_mod_eight (hi.1.pow (n := 2))
    simpa only [← pow_mul, show 2 * 2 = 4 by decide] using hh
  have hmod := Int.emod_eq_zero_of_dvd h8'
  rw [Int.sub_emod, Int.mul_emod, ha8, hb8, mul_one] at hmod
  have hD8 : D % 8 = 1 := by omega
  change (P.d / (2 : ℤ) ^ e) % 8 = 1
  rw [hD, Int.mul_ediv_cancel_left D (pow_ne_zero e (by norm_num))]
  exact hD8

end Parameters
end «JNT-2024»
