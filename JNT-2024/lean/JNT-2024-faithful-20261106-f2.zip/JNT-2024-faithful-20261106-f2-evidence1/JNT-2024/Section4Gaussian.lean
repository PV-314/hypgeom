module

public import «JNT-2024».ArgumentBounds
public import «JNT-2024».DenominatorBounds
public import «JNT-2024».Section2
public import «JNT-2024».Section2Bounds
public import «JNT-2024».Section2Complex
public import «JNT-2024».Section2Geometry
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

theorem gaussian_U (X Z : ℤ) : Section2.U (-1) (2 * X) (2 * Z) = (X : ℂ) + Z * Complex.I := by
  apply Complex.ext <;> norm_num [Section2.U, Section2.root]

theorem gaussian_U_integral (X Z : ℤ) : IsIntegral ℤ (Section2.U (-1) (2 * X) (2 * Z)) := by
  apply Section2.integral_of_quadratic (2 * X) (X ^ 2 + Z ^ 2)
  rw [gaussian_U]
  push_cast
  linear_combination (Z : ℂ) ^ 2 * Complex.I_sq

theorem gaussian_omega (X Z : ℤ) : Section2.omega (-1) (2 * X) (2 * Z) = conjugateRatio X Z := by
  have he : (X : ℂ) + Z * Complex.I = (⟨(X : ℝ), (Z : ℝ)⟩ : ℂ) := by
    apply Complex.ext <;> simp
  rw [Section2.omega, gaussian_U, he]
  rfl

theorem unit_circle_chord_le_arg {ω : ℂ} (hω : ‖ω‖ = 1) : ‖ω - 1‖ ≤ |ω.arg| := by
  have he := Complex.norm_mul_exp_arg_mul_I ω
  rw [hω, Complex.ofReal_one, one_mul] at he
  conv_lhs => rw [← he, mul_comm (ω.arg : ℂ) Complex.I]
  simpa only [Real.norm_eq_abs] using Real.norm_exp_I_mul_ofReal_sub_one_le (x := ω.arg)

/-- The disk condition and (4.8), for the Gaussian input used in Section 4. -/
theorem gaussian_input_bounds {X Z : ℤ} (hZ : Z ≠ 0) (hlarge : 15 * Z ^ 2 ≤ X ^ 2) :
    ‖Section2.omega (-1) (2 * X) (2 * Z) - 1‖ < 1 ∧
      Section2.ell (-1) (2 * X) (2 * Z) < (615 / 1000 : ℝ) * |(Z : ℝ)| / |(X : ℝ)| := by
  have hZr : (Z : ℝ) ≠ 0 := by exact_mod_cast hZ
  have hl : 15 * (Z : ℝ) ^ 2 ≤ (X : ℝ) ^ 2 := by exact_mod_cast hlarge
  have harg := conjugateRatio_argument_bound hZr hl
  have hnorm := conjugateRatio_norm (x := (X : ℝ)) hZr
  have hX : (X : ℝ) ≠ 0 := by intro he; rw [he] at hl; nlinarith [sq_pos_of_ne_zero hZr]
  have hratio : 0 < |(Z : ℝ)| / |(X : ℝ)| := div_pos (abs_pos.mpr hZr) (abs_pos.mpr hX)
  constructor
  · rw [gaussian_omega]
    have hc := unit_circle_chord_le_arg hnorm
    linarith [harg.1, harg.2]
  · rw [Section2.ell, gaussian_omega]
    have hh := mul_lt_mul_of_pos_left harg.1 (by norm_num : (0 : ℝ) < 537 / 2000)
    apply hh.trans
    convert mul_lt_mul_of_pos_right
      (by norm_num : (537 / 2000 : ℝ) * (229 / 100) < 615 / 1000) hratio using 1 <;> ring

/-- The actual Section 2 construction for Section 4's doubled Gaussian coordinates.
`DenominatorEstimate4` is passed explicitly; no further analytic assumption is introduced. -/
theorem gaussian_approximants (hPrior : Hypergeometric.DenominatorEstimate4)
    {X Z : ℤ} (hZ : Z ≠ 0) (hlarge : 15 * Z ^ 2 ≤ X ^ 2) :
    Nonempty (Section2.PaperApproximants (2 * X) (2 * Z)) :=
  Section2.section2_constructions hPrior (gaussian_U_integral X Z)
    (mul_ne_zero (by decide) hZ) (gaussian_input_bounds hZ hlarge).1

end «JNT-2024».Section4
