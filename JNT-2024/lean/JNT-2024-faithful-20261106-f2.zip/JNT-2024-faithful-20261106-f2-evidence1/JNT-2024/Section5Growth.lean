module

public import «JNT-2024».GrowthBounds
public import «JNT-2024».Monotonicity
public import «JNT-2024».Sequence
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

theorem section5_five_le_du_square (P : Parameters) (h : P.Admissible) :
    5 ≤ P.d * P.u ^ 2 := by
  have hdu : 0 < P.d * P.u ^ 2 := mul_pos h.d_pos (sq_pos_of_pos h.u_pos)
  rcases h.pell with hp | hp
  · have ht : 3 ≤ P.t := by nlinarith [h.t_pos]
    nlinarith
  · nlinarith [h.t_pos]

/-- Lemma 3.5(c) with the common exponent `|k|−1` when `K=−1`. -/
theorem section5_geometric_bound (P : Parameters) (h : P.Admissible) (hb : P.b = 1)
    (hn : P.normAlpha < 0) (hK : P.IsNegativeCutoff h.pell (-1))
    {k : ℤ} (hk : k ≠ 0) :
    |(P.normAlpha : ℝ)| * (P.u : ℝ) ^ 2 / 4 *
      (2 * P.d * (P.u : ℝ) ^ 2 / 5) ^ (k.natAbs - 1) ≤ (P.y h.pell k : ℝ) := by
  have hh : P.lowerSeed * (2 * P.d * (P.u : ℚ) ^ 2 / 5) ^ (k.natAbs - 1) ≤ P.y h.pell k := by
    rcases lt_or_gt_of_ne hk with hk | hk
    · have he : (-1 - k).toNat = k.natAbs - 1 := by
        have hh := Int.eq_neg_natAbs_of_nonpos hk.le
        omega
      simpa only [he] using (P.lemma35c h hn (-1) hK).2 k hk
    · have he : (k - 1).toNat = k.natAbs - 1 := by
        have hh := Int.natCast_natAbs (n := k)
        rw [abs_of_pos hk] at hh
        omega
      simpa only [he] using (P.lemma35c h hn (-1) hK).1 k hk
  dsimp [lowerSeed] at hh
  rw [hb] at hh
  norm_num only [Int.cast_one, one_pow, mul_one] at hh
  exact_mod_cast hh


end «JNT-2024».Parameters
