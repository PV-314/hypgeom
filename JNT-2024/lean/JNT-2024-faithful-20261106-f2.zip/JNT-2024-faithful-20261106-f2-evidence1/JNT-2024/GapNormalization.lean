module

public import «JNT-2024».ComplexRepresentation
public import «JNT-2024».GapPrinciple
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

theorem gaussian_coefficient_le {b t f g : ℝ} (hb : 0 < b) (ht : 0 < t)
    (hf : 0 < f) (hg : 0 < g) (hfb : f ≤ b ^ 2) (hgb : g ≤ b ^ 2) :
    1 / (b ^ 4 * t ^ 4) ≤ b ^ 4 / ((f * g) ^ 2 * t ^ 4) := by
  have hfg : f * g ≤ b ^ 4 := by nlinarith [mul_le_mul hfb hgb hg.le (sq_nonneg b)]
  have hs := pow_le_pow_left₀ (mul_pos hf hg).le hfg 2
  apply (div_le_div_iff₀ (by positivity) (by positivity)).mpr
  have hh := mul_le_mul_of_nonneg_right hs (show 0 ≤ t ^ 4 by positivity)
  nlinarith only [hh]

theorem gaussian_scale_bound {b t x : ℝ} (hb : 0 < b) (ht : 0 < t)
    (hx : b ^ 2 * t ^ 2 ≤ x) : 1 ≤ (1 / (b ^ 4 * t ^ 4)) * x ^ 2 := by
  have hs := pow_le_pow_left₀ (show 0 ≤ b ^ 2 * t ^ 2 by positivity) hx 2
  have hh : b ^ 4 * t ^ 4 ≤ x ^ 2 := by nlinarith only [hs]
  have hden : 0 < b ^ 4 * t ^ 4 := by positivity
  have he := (le_div_iff₀ hden).mpr (show 1 * (b ^ 4 * t ^ 4) ≤ x ^ 2 by simpa using hh)
  convert he using 1; ring

theorem quadratic_strong_scale_bound {b t N f g x : ℝ}
    (hb : 0 < b) (ht : 0 < t) (hN : 0 < N) (hf : 0 < f) (hg : 0 < g)
    (hfbound : f ^ 2 ≤ 16 * b ^ 4 * N) (hgbound : g ^ 2 ≤ 16 * b ^ 4 * N)
    (hx : (427 / 100 : ℝ) * b ^ 2 * N * t ^ 2 ≤ x) :
    (427 / 1600 : ℝ) ^ 2 ≤ (b ^ 4 / ((f * g) ^ 2 * t ^ 4)) * x ^ 2 := by
  have hfg : f * g ≤ 16 * b ^ 4 * N := by nlinarith [sq_nonneg (f - g)]
  have hs := pow_le_pow_left₀ (mul_pos hf hg).le hfg 2
  have hxs := pow_le_pow_left₀ (show 0 ≤ (427 / 100 : ℝ) * b ^ 2 * N * t ^ 2 by positivity) hx 2
  have hm₁ := mul_le_mul_of_nonneg_right hs (show 0 ≤ (427 / 1600 : ℝ) ^ 2 * t ^ 4 by positivity)
  have hm₂ := mul_le_mul_of_nonneg_left hxs (show 0 ≤ b ^ 4 by positivity)
  have hden : 0 < (f * g) ^ 2 * t ^ 4 := by positivity
  have hraw : (427 / 1600 : ℝ) ^ 2 * ((f * g) ^ 2 * t ^ 4) ≤ b ^ 4 * x ^ 2 := by
    nlinarith only [hm₁, hm₂]
  have he := (le_div_iff₀ hden).mpr hraw
  convert he using 1; ring

namespace Parameters

theorem gapScale_sq_abs (P : Parameters) (hb : 0 < P.b) (hn : P.normAlpha < 0) :
    P.gapScale ^ 2 = |(P.normAlpha : ℝ)| / P.d := by
  have hn' : (P.normAlpha : ℝ) < 0 := by exact_mod_cast hn
  rw [abs_of_neg hn']
  exact P.gapScale_sq hb hn

theorem paper_gap_coefficient (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    {f g : ℝ} (hf : 0 < f) (hg : 0 < g) :
    (P.b : ℝ) ^ 4 / ((f * g) ^ 2 * P.gapScale ^ 4) =
      ((P.b : ℝ) ^ 2 * P.d / (f * g * |(P.normAlpha : ℝ)|)) ^ 2 := by
  have hd : (P.d : ℝ) ≠ 0 := by exact_mod_cast ne_of_gt h.d_pos
  rw [show P.gapScale ^ 4 = (P.gapScale ^ 2) ^ 2 by ring, P.gapScale_sq_abs h.b_pos hn]
  field_simp

theorem paper_gaussian_coefficient (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) :
    1 / ((P.b : ℝ) ^ 4 * P.gapScale ^ 4) =
      ((P.d : ℝ) / ((P.b : ℝ) ^ 2 * |(P.normAlpha : ℝ)|)) ^ 2 := by
  have hd : (P.d : ℝ) ≠ 0 := by exact_mod_cast ne_of_gt h.d_pos
  rw [show P.gapScale ^ 4 = (P.gapScale ^ 2) ^ 2 by ring, P.gapScale_sq_abs h.b_pos hn]
  field_simp

abbrev SequenceDatum (P : Parameters) :=
  FourthPowerDatum (-squarefreePart P.normAlpha) (P.b : ℝ) P.gapScale P.gapOmega

def PaperCubicGap (P : Parameters) (p q : P.SequenceDatum) : Prop :=
  (1536 / 100 : ℝ) * ((P.b : ℝ) ^ 2 * P.d / (p.f * q.f * |(P.normAlpha : ℝ)|)) ^ 2 * p.y ^ 3 < q.y ∧
  ((427 / 100 : ℝ) * (P.b : ℝ) ^ 2 * |(P.normAlpha : ℝ)| ^ 2 / P.d ≤ p.y →
    182 * ((P.b : ℝ) ^ 2 * P.d / (p.f * q.f * |(P.normAlpha : ℝ)|)) ^ 2 * p.y ^ 3 < q.y)

theorem cubicGap_to_paper (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (p q : P.SequenceDatum)
    (hf : p.f ^ 2 ≤ 16 * (P.b : ℝ) ^ 4 * |(P.normAlpha : ℝ)|)
    (hg : q.f ^ 2 ≤ 16 * (P.b : ℝ) ^ 4 * |(P.normAlpha : ℝ)|)
    (hc : p.CubicGap q) : P.PaperCubicGap p q := by
  have hb : (0 : ℝ) < P.b := by exact_mod_cast h.b_pos
  have ht := P.gapScale_pos h.b_pos hn
  have hN : (0 : ℝ) < |(P.normAlpha : ℝ)| := by exact_mod_cast abs_pos.mpr (ne_of_lt hn)
  have hcoeff := P.paper_gap_coefficient h hn p.f_pos q.f_pos
  refine ⟨by simpa only [← hcoeff] using hc.1, ?_⟩
  intro hx
  have hx' : (427 / 100 : ℝ) * (P.b : ℝ) ^ 2 * |(P.normAlpha : ℝ)| * P.gapScale ^ 2 ≤ p.y := by
    rw [P.gapScale_sq_abs h.b_pos hn]
    convert hx using 1; ring
  have hs := quadratic_strong_scale_bound hb ht hN p.f_pos q.f_pos hf hg hx'
  simpa only [← hcoeff] using hc.2 hs

end Parameters
end «JNT-2024»
