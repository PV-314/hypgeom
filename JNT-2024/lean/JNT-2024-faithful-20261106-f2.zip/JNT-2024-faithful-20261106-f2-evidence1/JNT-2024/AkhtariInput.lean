module

public import «JNT-2024».Section46Calculation
public import «JNT-2024».Section46ListsPublished
public import «JNT-2024».Section46SmallPublished
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».ExternalResults

/-- Positive integer solutions of A*X^4-B*Y^2=1, written without truncated
natural-number subtraction. -/
def AkhtariSolution (A B : ℕ) (p : ℕ × ℕ) : Prop :=
  0 < p.1 ∧ 0 < p.2 ∧ A*p.1^4=B*p.2^2+1

/-- Akhtari, J. reine angew. Math. 630 (2009), Theorem 1.1.
Named external input, authorized by the user on 3 November 2026. The theorem
is used, not reproved. No axiom or default instance supplies this structure.
The field states that any three positive solutions contain an equal pair,
which expresses the published bound of at most two solution pairs. -/
structure AkhtariTheorem11 : Prop where
  no_three_distinct : ∀ A B : ℕ, 0 < A → 0 < B → ∀ p q r : ℕ × ℕ,
    AkhtariSolution A B p → AkhtariSolution A B q → AkhtariSolution A B r →
    p=q ∨ p=r ∨ q=r

end «JNT-2024».ExternalResults

namespace «JNT-2024».Section4

/-- In the norm -1 case, the known solution (1,a) leaves at most one further
positive solution. Akhtari's variables are X=paper y and Y=paper x. -/
theorem norm_minus_one_noninitial_unique (hAkhtari : ExternalResults.AkhtariTheorem11)
    {a x y X Y : ℕ} (ha : 0 < a) (hx : 0 < x) (hX : 0 < X)
    (hy : 1 < y) (hY : 1 < Y)
    (he : x^2+1=(a^2+1)*y^4) (hE : X^2+1=(a^2+1)*Y^4) : y=Y := by
  have h := hAkhtari.no_three_distinct (a^2+1) 1 (by omega) (by decide)
    (1,a) (y,x) (Y,X)
    (by dsimp [ExternalResults.AkhtariSolution]; exact ⟨by decide,ha,by ring⟩)
    (by dsimp [ExternalResults.AkhtariSolution]; exact ⟨by omega,hx,by simpa using he.symm⟩)
    (by dsimp [ExternalResults.AkhtariSolution]; exact ⟨by omega,hX,by simpa using hE.symm⟩)
  rcases h with h | h | h
  · have := congrArg Prod.fst h; dsimp at this; omega
  · have := congrArg Prod.fst h; dsimp at this; omega
  · exact congrArg Prod.fst h

end «JNT-2024».Section4

namespace «JNT-2024».Parameters

/-- Section 4.6's cited norm -1 application, with every sign and integrality
reduction proved from the sequence hypotheses. -/
theorem section46_norm_minus_one (hAkhtari : ExternalResults.AkhtariTheorem11)
    (P : Parameters) (h : P.Admissible) (hb : P.b=1) (hN : P.normAlpha= -1)
    {i j : ℤ} (hsi : IsIntegerSquare (P.y h.pell i)) (hsj : IsIntegerSquare (P.y h.pell j))
    (hyi : 1 < P.y h.pell i) (hyj : 1 < P.y h.pell j) :
    P.y h.pell i=P.y h.pell j := by
  have ha : P.a=(P.a.toNat : ℤ) := (Int.toNat_of_nonneg h.a_pos.le).symm
  have hd : P.d=(P.a.toNat^2+1^2 : ℕ) := by
    simp only [normAlpha,hb,one_pow] at hN
    push_cast
    rw [← ha]
    linarith
  obtain ⟨x,y,hx,hy,hei,he⟩ := P.section46_sequence_solution h hb (by omega) ha hd hsi hyi
  obtain ⟨X,Y,hX,hY,hej,hE⟩ := P.section46_sequence_solution h hb (by omega) ha hd hsj hyj
  have hroot := Section4.norm_minus_one_noninitial_unique hAkhtari
    (show 0 < P.a.toNat by have := h.a_pos; omega) hx hX hy hY
    (by simpa using he) (by simpa using hE)
  rw [hei,hej,hroot]

/-- The full small-d branch of the printed Proposition 4.1 proof. -/
theorem section46_small_published (hAkhtari : ExternalResults.AkhtariTheorem11)
    (hCalculation : Calculations.Section46Magma) (P : Parameters) (h : P.Admissible)
    (hb : P.b=1) (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha)) (hd : P.d ≤ 111)
    {i j : ℤ} (hsi : IsIntegerSquare (P.y h.pell i)) (hsj : IsIntegerSquare (P.y h.pell j))
    (hyi : 1 < P.y h.pell i) (hyj : 1 < P.y h.pell j) :
    P.y h.pell i=P.y h.pell j := by
  by_cases hN : P.normAlpha= -1
  · exact section46_norm_minus_one hAkhtari P h hb hN hsi hsj hyi hyj
  · have hN4 : P.normAlpha ≤ -4 := by
      obtain ⟨n,he⟩ := hNs
      have he' : -P.normAlpha=n^2 := by simpa only [pow_two] using he
      by_cases hlo : n ≤ -2
      · nlinarith
      by_cases hhi : 2 ≤ n
      · nlinarith
      have hn' : n= -1 ∨ n=0 ∨ n=1 := by omega
      rcases hn' with rfl | rfl | rfl <;> norm_num at he' <;> omega
    exact P.section46_small_square_unique hCalculation h hb hN4 hNs hd hsi hsj hyi hyj

end «JNT-2024».Parameters
