module

public import «JNT-2024».DenominatorDefinitions
public import «JNT-2024».DenominatorFinite
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

theorem exp_168_bounds : (107311 / 20000 : ℝ) < Real.exp (42 / 25) ∧
    Real.exp (42 / 25) < 10735 / 2000 := by
  constructor
  · simpa [Hypergeometric.denominatorExponentialLower] using
      Hypergeometric.denominatorExponentialLower_lt_exp
  · have hh := Real.exp_bound' (by norm_num : (0 : ℝ) ≤ 21 / 25)
      (by norm_num : (21 / 25 : ℝ) ≤ 1) (by decide : 0 < 8)
    have hb : Real.exp (21 / 25 : ℝ) < (23164 / 10000 : ℝ) := by
      norm_num [Finset.sum_range_succ] at hh
      linarith
    have he : Real.exp (42 / 25 : ℝ) = Real.exp (21 / 25 : ℝ) ^ 2 := by
      rw [show (42 / 25 : ℝ) = 21 / 25 + 21 / 25 by ring, Real.exp_add, pow_two]
    rw [he]
    nlinarith [Real.exp_pos (21 / 25)]

/-- Equation (4.3) and the strict comparison (4.4). -/
theorem coordinate_comparisons {N d x y : ℝ} (hN : 0 < N) (hNd : N < d)
    (hy : 4 ≤ y) (hnorm : x ^ 2 = d * y ^ 2 - N) :
    (15 / 16 : ℝ) * d * y ^ 2 < x ^ 2 ∧
      Real.sqrt d * y < (26 / 25 : ℝ) * |x| := by
  have hd : 0 < d := hN.trans hNd
  have hy2 : 16 ≤ y ^ 2 := by nlinarith
  have hc : (15 / 16 : ℝ) * d * y ^ 2 < x ^ 2 := by nlinarith [mul_le_mul_of_nonneg_left hy2 hd.le]
  have hroot := Real.sq_sqrt hd.le
  refine ⟨hc, ?_⟩
  apply (sq_lt_sq₀ (by positivity) (by positivity)).mp
  rw [mul_pow, mul_pow, hroot, sq_abs]
  nlinarith [mul_pos hd (show 0 < y ^ 2 by positivity)]

theorem coordinate_ratio_lower {L x : ℝ} (hL : 0 < L)
    (hx : (15 / 16 : ℝ) * L ^ 2 < x ^ 2) : (9682 / 10000 : ℝ) * L < |x| := by
  apply (sq_lt_sq₀ (by positivity) (abs_nonneg x)).mp
  rw [mul_pow, sq_abs]
  nlinarith [sq_pos_of_pos hL]


end «JNT-2024».Section4
