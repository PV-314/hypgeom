module

public import «JNT-2024».DenominatorBounds
public import «JNT-2024».DenominatorContent
public import «JNT-2024».DenominatorDefinitions
public import «JNT-2024».DenominatorFinite
public import «JNT-2024».GammaBounds
public import «JNT-2024».HypergeometricPolynomials
public import «JNT-2024».HypergeometricUpperBound
public import «JNT-2024».RemainderConstruction
public import «JNT-2024».RemainderUpperBound
public import «JNT-2024».Section2Complex
public import «JNT-2024».Section2Construction
public import «JNT-2024».Section2Gaussian
public import «JNT-2024».Section2Geometry
public import «JNT-2024».Section2Parameters
public import «JNT-2024».UnitCircleGeometry
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Section2

open Hypergeometric

/-- The printed constant in Lemma 2.2(d), retained throughout Section 2. -/
noncomputable def paperFactor : ℝ := 134 / 125
noncomputable def paperC1 : ℝ := 293 / 250
noncomputable def paperC2 : ℝ := 537 / 2000

theorem paper_constants : paperFactor * paperC1 < (1257 / 1000 : ℝ) := by
  norm_num [paperFactor, paperC1]

theorem paper_Y_bound {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0)
    (hnear : ‖omega S u₁ u₂ - 1‖ < 1) (r : ℕ) :
    ‖Y (1 / 4) r (omega S u₁ u₂)‖ <
      paperFactor * (gammaRatio r : ℝ) * ‖1 + principalSquareRoot (omega S u₁ u₂)‖ ^ (2 * r) := by
  have hh := (lemma22d (ν := 1 / 4) (by norm_num) (by norm_num) r (omega_norm hS hu₂) hnear).2
  have h₁ : 1 - ((1 / 4 : ℚ) : ℝ) = 3 / 4 := by norm_num
  have h₂ : (r : ℝ) + 1 - ((1 / 4 : ℚ) : ℝ) = (r : ℝ) + 3 / 4 := by norm_num; ring
  rw [h₁, h₂] at hh
  simpa only [paperFactor, gammaRatio_eq_gamma] using hh

theorem paper_remainder_bound {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0)
    (hnear : ‖omega S u₁ u₂ - 1‖ < 1) (r : ℕ) :
    ‖remainder (1 / 4) r (omega S u₁ u₂)‖ ≤
      (gammaNumeratorRatio r : ℝ) * |(omega S u₁ u₂).arg| *
        ‖1 - principalSquareRoot (omega S u₁ u₂)‖ ^ (2 * r) := by
  have hh := lemma22c (ν := 1 / 4) (by norm_num) (by norm_num) r (omega_norm hS hu₂) hnear
  have h₂ : (r : ℝ) + 1 + ((1 / 4 : ℚ) : ℝ) = (r : ℝ) + 5 / 4 := by norm_num; ring
  rw [h₂] at hh
  rw [gammaNumeratorRatio_eq_gamma]
  norm_num only [Rat.cast_div, Rat.cast_one, Rat.cast_ofNat] at hh
  convert hh using 1
  ring

theorem norm_rawScale (S u₁ u₂ : ℤ) (r : ℕ) :
    ‖rawScale S u₁ u₂ r‖ = (denominator4 r : ℝ) /
      numeratorContent4 (Approximation.dPrimeInteger S u₁ u₂) r * ‖A S u₁ u₂‖ ^ r := by
  simp [rawScale, norm_pow]

theorem paper_denominator_bounds (hPrior : DenominatorEstimate4)
    {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) (r : ℕ) :
    (gammaRatio r : ℝ) * denominator4 r / numeratorContent4 (Approximation.dPrimeInteger S u₁ u₂) r <
      paperC1 * (Real.exp (42 / 25) / twoAdicScale4 (Approximation.dPrimeInteger S u₁ u₂)) ^ r ∧
    (gammaNumeratorRatio r : ℝ) * denominator4 r / numeratorContent4 (Approximation.dPrimeInteger S u₁ u₂) r <
      paperC2 * (Real.exp (42 / 25) / twoAdicScale4 (Approximation.dPrimeInteger S u₁ u₂)) ^ r := by
  have hh := lemma23a_of_denominatorEstimate4 hPrior (Approximation.dPrimeInteger S u₁ u₂)
    (ne_of_lt (Approximation.dPrimeInteger_neg hS hu₂)) r
  simpa only [paperC1, paperC2, gammaRatio_eq_gamma, gammaNumeratorRatio_eq_gamma,
    mul_comm (r.factorial : ℝ) (Real.Gamma (3 / 4))] using hh

theorem rawQ_bound_of_denominator {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0)
    (hnear : ‖omega S u₁ u₂ - 1‖ < 1) (r : ℕ) {C : ℝ}
    (hD : (gammaRatio r : ℝ) * denominator4 r / numeratorContent4 (Approximation.dPrimeInteger S u₁ u₂) r <
      C * (Real.exp (42 / 25) / twoAdicScale4 (Approximation.dPrimeInteger S u₁ u₂)) ^ r) :
    ‖rawQ S u₁ u₂ r‖ < paperFactor * C * Q S u₁ u₂ ^ r := by
  have hratio : (0 : ℝ) < (denominator4 r : ℝ) /
      numeratorContent4 (Approximation.dPrimeInteger S u₁ u₂) r :=
    div_pos (by exact_mod_cast denominator4_pos r) (by exact_mod_cast numeratorContent4_pos _ r)
  have hA : 0 < ‖A S u₁ u₂‖ := norm_pos_iff.mpr (A_ne_zero hS hu₂)
  have hp : 0 < ‖1 + principalSquareRoot (omega S u₁ u₂)‖ := by
    have hh := principalSquareRoot_chord (omega_norm (u₁ := u₁) hS hu₂)
    nlinarith [norm_nonneg (1 + omega S u₁ u₂), norm_nonneg (1 + principalSquareRoot (omega S u₁ u₂))]
  have hd := mul_lt_mul_of_pos_right hD (show 0 < paperFactor * ‖A S u₁ u₂‖ ^ r *
    ‖1 + principalSquareRoot (omega S u₁ u₂)‖ ^ (2 * r) by unfold paperFactor; positivity)
  rw [rawQ, norm_mul, norm_rawScale]
  apply (mul_lt_mul_of_pos_left (paper_Y_bound hS hu₂ hnear r)
    (mul_pos hratio (pow_pos hA r))).trans
  rw [Q_eq_chord hS hu₂]
  simp only [mul_pow, ← pow_mul]
  convert hd using 1 <;> ring

theorem rawQ_bound (hPrior : DenominatorEstimate4)
    {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0)
    (hnear : ‖omega S u₁ u₂ - 1‖ < 1) (r : ℕ) :
    ‖rawQ S u₁ u₂ r‖ < paperFactor * paperC1 * Q S u₁ u₂ ^ r :=
  rawQ_bound_of_denominator hS hu₂ hnear r (paper_denominator_bounds hPrior hS hu₂ r).1

/-- The original constants in equations (2.9)–(2.10). -/
theorem rawR_bound (hPrior : DenominatorEstimate4)
    {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0)
    (hnear : ‖omega S u₁ u₂ - 1‖ < 1) (r : ℕ) :
    ‖rawR S u₁ u₂ r‖ ≤ ell S u₁ u₂ / E S u₁ u₂ ^ r := by
  have hratio : (0 : ℝ) ≤ (denominator4 r : ℝ) /
      numeratorContent4 (Approximation.dPrimeInteger S u₁ u₂) r := by positivity
  have hD := (paper_denominator_bounds hPrior (u₁ := u₁) hS hu₂ r).2.le
  have hd := mul_le_mul_of_nonneg_right hD (show 0 ≤ ‖A S u₁ u₂‖ ^ r * |(omega S u₁ u₂).arg| *
    ‖1 - principalSquareRoot (omega S u₁ u₂)‖ ^ (2 * r) by positivity)
  rw [rawR, norm_mul, norm_rawScale]
  apply (mul_le_mul_of_nonneg_left (paper_remainder_bound hS hu₂ hnear r)
    (mul_nonneg hratio (pow_nonneg (norm_nonneg _) r))).trans
  conv_rhs => rw [div_eq_mul_inv, ← inv_pow, E_inv_eq_chord hS hu₂]
  simp only [mul_pow, ← pow_mul, ell, paperC2] at hd ⊢
  convert hd using 1 <;> ring

theorem corrected_q_bound (hPrior : DenominatorEstimate4)
    {u₁ u₂ : ℤ} (hu₂ : u₂ ≠ 0) (hnear : ‖omega (-1) u₁ u₂ - 1‖ < 1) (r : ℕ) :
    ‖q u₁ u₂ r‖ < paperFactor * paperC1 * Q (-1) u₁ u₂ ^ r := by
  rw [(corrected_norms u₁ u₂ r).2.1]
  exact rawQ_bound hPrior (by norm_num) hu₂ hnear r

theorem corrected_error_bound (hPrior : DenominatorEstimate4)
    {u₁ u₂ : ℤ} (hu₂ : u₂ ≠ 0) (hnear : ‖omega (-1) u₁ u₂ - 1‖ < 1) (r : ℕ) :
    ‖q u₁ u₂ r * omega (-1) u₁ u₂ ^ (1 / 4 : ℂ) - p u₁ u₂ r‖ ≤
      ell (-1) u₁ u₂ / E (-1) u₁ u₂ ^ r := by
  rw [corrected_error_identity hnear r, (corrected_norms u₁ u₂ r).2.2]
  exact rawR_bound hPrior (by norm_num) hu₂ hnear r


/-- The literal choice in (2.8) of manuscript 2026-11-05d. -/
theorem corrected_q_bound_fixed (hPrior : DenominatorEstimate4)
    {u₁ u₂ : ℤ} (hu₂ : u₂ ≠ 0) (hnear : ‖omega (-1) u₁ u₂ - 1‖ < 1) (r : ℕ) :
    ‖q u₁ u₂ r‖ < (1257 / 1000 : ℝ) * Q (-1) u₁ u₂ ^ r := by
  exact (corrected_q_bound hPrior hu₂ hnear r).trans
    (mul_lt_mul_of_pos_right paper_constants
      (pow_pos (Q_pos (u₁ := u₁) (by norm_num : (-1 : ℤ) < 0) hu₂) r))

end Section2
end «JNT-2024»
