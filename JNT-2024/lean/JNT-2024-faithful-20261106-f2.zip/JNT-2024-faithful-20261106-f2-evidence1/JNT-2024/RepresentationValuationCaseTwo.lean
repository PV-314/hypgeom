module

public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».RepresentationValuationCaseOne
public import «JNT-2024».RepresentationValuationCases
public import «JNT-2024».RepresentationValuationLowerBounds
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section
namespace «JNT-2024»

/-- The two valuation identities used after the product identity in case (2).
The squarefree subtraction is written as addition to avoid truncated subtraction. -/
theorem lemma32_case2_product_valuation (p : ℕ) [Fact p.Prime]
    {r r' u N : ℤ} (hr : r ≠ 0) (hr' : r' ≠ 0) (hu : u ≠ 0) (hN : N ≠ 0)
    (hprod : r * r' = u ^ 2 * N) :
    padicValInt p ((-u * squareFactor N) ^ 2) + padicValInt p (squarefreePart N) =
      padicValInt p r + padicValInt p r' ∧
    u ^ 2 * N / squarefreePart N = (-u * squareFactor N) ^ 2 := by
  have hv := congrArg (padicValInt p) hprod
  rw [padicValInt.mul hr hr', padicValInt.mul (pow_ne_zero _ hu) hN,
    valuation_int_pow] at hv
  have hs := valuation_squarePart p hN
  have hneg : padicValInt p (-u) = padicValInt p u := by simp only [padicValInt, Int.natAbs_neg]
  constructor
  · rw [valuation_int_pow, padicValInt.mul (neg_ne_zero.mpr hu)
      (ne_of_gt (squareFactor_pos hN)), hneg]
    omega
  · have he : u ^ 2 * N = (-u * squareFactor N) ^ 2 * squarefreePart N := by
      nth_rw 1 [← squareFactor_sq_mul N]
      ring
    rw [he, Int.mul_ediv_cancel _ (squarefreePart_ne_zero N)]

/-- The odd/even squarefree correction in printed case (2), including the
extra unit in the lower bound when k₂ is even and p divides sf(N). -/
theorem lemma32_case2_parity (p : ℕ) [Fact p.Prime]
    {r r' u N : ℤ} (hr : r ≠ 0) (hr' : r' ≠ 0) (hu : u ≠ 0) (hN : N ≠ 0)
    (hprod : r * r' = u ^ 2 * N) (k : ℕ) (hlower : 2 * k ≤ padicValInt p r') :
    (padicValInt p r % 2 = 1 → padicValInt p (squarefreePart r) = 1) ∧
    (padicValInt p r % 2 = 0 → padicValInt p (squarefreePart r) = 0) ∧
    (padicValInt p r % 2 = 0 → (p : ℤ) ∣ squarefreePart N →
      padicValInt p r' % 2 = 1 ∧ 2 * k + 1 ≤ padicValInt p r') ∧
    (2 * k : ℤ) - padicValInt p (squarefreePart r) ≤
      (padicValInt p r' : ℤ) - padicValInt p (squarefreePart N) := by
  have hv := congrArg (padicValInt p) hprod
  rw [padicValInt.mul hr hr', padicValInt.mul (pow_ne_zero _ hu) hN,
    valuation_int_pow] at hv
  have hs := valuation_squarePart p hr
  have hsN := valuation_squarePart p hN
  have hf := valuation_squarefree_le_one p (squarefreePart_squarefree r)
  have hfN := valuation_squarefree_le_one p (squarefreePart_squarefree N)
  have hodd : padicValInt p r % 2 = 1 → padicValInt p (squarefreePart r) = 1 := by omega
  have heven : padicValInt p r % 2 = 0 → padicValInt p (squarefreePart r) = 0 := by omega
  have hboost : padicValInt p r % 2 = 0 → (p : ℤ) ∣ squarefreePart N →
      padicValInt p r' % 2 = 1 ∧ 2 * k + 1 ≤ padicValInt p r' := by
    intro he hd
    have hvN : 1 ≤ padicValInt p (squarefreePart N) := by
      exact ((padicValInt_dvd_iff 1 _).mp (by simpa using hd)).resolve_left (squarefreePart_ne_zero N)
    constructor <;> omega
  refine ⟨hodd, heven, hboost, ?_⟩
  by_cases ho : padicValInt p r % 2 = 1
  · have := hodd ho
    omega
  · have he : padicValInt p r % 2 = 0 := by omega
    have := heven he
    by_cases hd : (p : ℤ) ∣ squarefreePart N
    · have := hboost he hd
      omega
    · have hz : padicValInt p (squarefreePart N) = 0 := by
        by_contra hn
        apply hd
        have hdiv := (padicValInt_dvd_iff (p := p) 1 (squarefreePart N)).mpr (Or.inr (by omega))
        simpa using hdiv
      omega

namespace Parameters

/-- The valuation consequences of the strict gcd comparison in case (2). -/
theorem lemma32_case2_setup (P : Parameters) (p : ℕ) [Fact p.Prime]
    (hp2 : p ≠ 2) {r : ℤ} (hb : P.b ≠ 0) (hr : r ≠ 0)
    (hc : padicValInt p (4 * P.b ^ 2 * r / squarefreePart r) < padicValInt p (r ^ 2)) :
    2 * padicValInt p P.b < padicValInt p r ∧
    padicValInt p ((normalizationGcd P.b r : ℤ) ^ 2) + padicValInt p (squarefreePart r) =
      2 * padicValInt p P.b + padicValInt p r := by
  have he : 4 * P.b ^ 2 * r / squarefreePart r = (2 * P.b * squareFactor r) ^ 2 := by
    have he' : 4 * P.b ^ 2 * r = (2 * P.b * squareFactor r) ^ 2 * squarefreePart r := by
      nth_rw 1 [← squareFactor_sq_mul r]
      ring
    rw [he', Int.mul_ediv_cancel _ (squarefreePart_ne_zero r)]
  have h2 : padicValInt p (2 : ℤ) = 0 := by
    change padicValNat p 2 = 0
    exact padicValNat_primes hp2
  rw [he, valuation_int_pow, valuation_int_pow,
    padicValInt.mul (mul_ne_zero (by norm_num) hb) (ne_of_gt (squareFactor_pos hr)),
    padicValInt.mul (by norm_num) hb, h2, zero_add] at hc
  have hs := valuation_squarePart p hr
  have hsf := valuation_squarefree_le_one p (squarefreePart_squarefree r)
  have hg := normalizationGcd_sq_valuation p hb hr
  rw [h2, zero_add] at hg
  have hf := valuation_squareFactor_eq_half p hr
  constructor <;> omega

/-- The product identity already proved for the two candidates, in either order. -/
theorem lemma32_signed_candidate_product (P : Parameters) {x y σ : ℤ}
    (h : P.RepresentsSquare x y) (hσ : σ = 1 ∨ σ = -1) :
    P.repCandidate y σ * P.repCandidate y (-σ) = P.u ^ 2 * P.normAlpha := by
  rcases hσ with rfl | rfl
  · simpa using P.repCandidate_product h
  · simpa [mul_comm] using P.repCandidate_product h

/-- The bound on the other candidate in case (2), from the printed root bound
and the identity r_other = r - σ 4by. -/
theorem lemma32_case2_other (P : Parameters) {x y σ : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hy : y ≠ 0)
    (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0) (hσ : σ = 1 ∨ σ = -1)
    (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2)
    (hk : 2 * padicValInt p P.b < padicValInt p (P.repCandidate y σ)) :
    padicValInt p P.b ≤ padicValInt p y ∧
      2 * padicValInt p P.b ≤ padicValInt p (P.repCandidate y (-σ)) := by
  have hy' : padicValInt p P.b ≤ padicValInt p y := by
    have hh := P.lemma32_odd_lower_from_chain h hb hy hu hN hσ p hp2
    omega
  refine ⟨hy', ?_⟩
  have hby : (p : ℤ) ^ (2 * padicValInt p P.b) ∣ P.b * y := by
    apply (padicValInt_dvd_iff _ _).mpr
    right
    rw [padicValInt.mul hb hy]
    omega
  have hr : (p : ℤ) ^ (2 * padicValInt p P.b) ∣ P.repCandidate y σ :=
    (padicValInt_dvd_iff _ _).mpr (Or.inr (by omega))
  have he : P.repCandidate y (-σ) = P.repCandidate y σ - (σ * 4) * (P.b * y) := by
    unfold repCandidate
    ring
  have hd : (p : ℤ) ^ (2 * padicValInt p P.b) ∣ P.repCandidate y (-σ) := by
    rw [he]
    exact dvd_sub hr (dvd_mul_of_dvd_right hby _)
  have hσ' : -σ = 1 ∨ -σ = -1 := by rcases hσ with rfl | rfl <;> norm_num
  exact ((padicValInt_dvd_iff _ _).mp hd).resolve_left (P.repCandidate_ne_zero h hu hN hσ')

/-- The two displayed valuation identities on p. 11, in exactly their
subtractive form. Integer casts keep subtraction untruncated. -/
theorem lemma32_case2_displayed_identities (P : Parameters) {x y σ : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0)
    (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0) (hσ : σ = 1 ∨ σ = -1)
    (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2)
    (hc : padicValInt p (4 * P.b ^ 2 * P.repCandidate y σ / squarefreePart (P.repCandidate y σ)) <
      padicValInt p (P.repCandidate y σ ^ 2)) :
    (padicValInt p (P.u ^ 2 * P.normAlpha / squarefreePart P.normAlpha) : ℤ) =
      padicValInt p (P.repCandidate y σ) + padicValInt p (P.repCandidate y (-σ)) -
        padicValInt p (squarefreePart P.normAlpha) ∧
    (padicValInt p ((normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2) : ℤ) =
      2 * padicValInt p P.b + padicValInt p (P.repCandidate y σ) -
        padicValInt p (squarefreePart (P.repCandidate y σ)) := by
  have hr := P.repCandidate_ne_zero h hu hN hσ
  have hσ' : -σ = 1 ∨ -σ = -1 := by rcases hσ with rfl | rfl <;> norm_num
  have hr' := P.repCandidate_ne_zero h hu hN hσ'
  have hg := (P.lemma32_case2_setup p hp2 hb hr hc).2
  obtain ⟨hv, he⟩ := lemma32_case2_product_valuation p hr hr' hu hN
    (P.lemma32_signed_candidate_product h hσ)
  rw [he]
  constructor <;> omega

/-- Printed case (2), combining the other-candidate bound and the explicit
odd/even squarefree correction. -/
theorem lemma32_case2 (P : Parameters) {x y σ : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hy : y ≠ 0)
    (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0) (hσ : σ = 1 ∨ σ = -1)
    (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2)
    (hc : padicValInt p (4 * P.b ^ 2 * P.repCandidate y σ / squarefreePart (P.repCandidate y σ)) <
      padicValInt p (P.repCandidate y σ ^ 2)) :
    padicValInt p ((normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2) ≤
      padicValInt p ((-P.u * squareFactor P.normAlpha) ^ 2) := by
  have hr := P.repCandidate_ne_zero h hu hN hσ
  have hσ' : -σ = 1 ∨ -σ = -1 := by rcases hσ with rfl | rfl <;> norm_num
  have hr' := P.repCandidate_ne_zero h hu hN hσ'
  obtain ⟨hk, hg⟩ := P.lemma32_case2_setup p hp2 hb hr hc
  have hlower := (P.lemma32_case2_other h hb hy hu hN hσ p hp2 hk).2
  have hprod := P.lemma32_signed_candidate_product h hσ
  have he := (lemma32_case2_product_valuation p hr hr' hu hN hprod).2
  have hv := P.lemma32_case2_displayed_identities h hb hu hN hσ p hp2 hc
  rw [he] at hv
  have hpar := (lemma32_case2_parity p hr hr' hu hN hprod (padicValInt p P.b) hlower).2.2.2
  omega

/-- The entire printed odd-prime case division in Lemma 3.2, assembled from
cases (1-a), (1-b), and (2), rather than the existing alternative proof. -/
theorem lemma32_odd_published_valuation (P : Parameters) {x y σ : ℤ}
    (h : P.RepresentsSquare x y) (ha : P.a ≠ 0) (hb : P.b ≠ 0) (hd : P.d ≠ 0)
    (hy : y ≠ 0) (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0) (hσ : σ = 1 ∨ σ = -1)
    (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2) :
    padicValInt p (Int.gcd (4 * P.b ^ 2 * P.repCandidate y σ / squarefreePart (P.repCandidate y σ))
      (P.repCandidate y σ ^ 2) : ℤ) ≤ padicValInt p ((-P.u * squareFactor P.normAlpha) ^ 2) := by
  have hg : (normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2 =
      (Int.gcd (4 * P.b ^ 2 * P.repCandidate y σ / squarefreePart (P.repCandidate y σ))
        (P.repCandidate y σ ^ 2) : ℤ) := by
    rw [← Nat.cast_pow, normalizationGcd_sq]
  rw [← hg]
  rcases le_or_gt (padicValInt p (P.repCandidate y σ ^ 2))
      (padicValInt p (4 * P.b ^ 2 * P.repCandidate y σ / squarefreePart (P.repCandidate y σ))) with hc | hc
  · rcases lt_or_ge (2 * padicValInt p P.a) (4 * padicValInt p P.b + padicValInt p P.d) with hn | hn
    · exact P.lemma32_case1a h ha hb hd hy hu hN hσ p hp2 hc hn
    · exact P.lemma32_case1b h ha hb hd hu hN hσ p hp2 hc hn
  · exact P.lemma32_case2 h hb hy hu hN hσ p hp2 hc

end Parameters
end «JNT-2024»
