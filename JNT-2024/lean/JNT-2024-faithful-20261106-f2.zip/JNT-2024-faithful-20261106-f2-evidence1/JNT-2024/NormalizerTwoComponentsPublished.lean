module

public import «JNT-2024».ApproximationGcd
public import «JNT-2024».NormalizerValuationsPublished
public import «JNT-2024».RepresentationValuations
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Approximation

theorem g2_valuation_le_squarefree_published (p : ℕ) [Fact p.Prime] {S u₁ u₂ : ℤ}
    (hS : S ≠ 0) : padicValNat p (g2 S u₁ u₂) ≤ padicValInt p S := by
  apply (padicValNat_dvd_iff_le (Int.natAbs_ne_zero.mpr hS)).mp
  exact (pow_padicValNat_dvd (p := p) (n := g2 S u₁ u₂)).trans (Int.gcd_dvd_natAbs_right _ _)

theorem g3_two_valuation_le (S u₁ u₂ : ℤ) : padicValNat 2 (g3 S u₁ u₂) ≤ 2 := by
  have hv4 : padicValNat 2 4 = 2 := by
    rw [show 4 = 2 ^ 2 by decide, padicValNat.pow]
    norm_num
  rcases g3_cases S u₁ u₂ with he | he | he <;> norm_num [he, hv4]

theorem g3_eq_four_of_even_published {S : ℤ} (hS : Even S) (u₁ u₂ : ℤ) :
    g3 S u₁ u₂ = 4 := by
  have hs := Int.even_iff.mp hS
  unfold g3
  split_ifs with h₁ h₂
  · omega
  · omega
  · rfl

/-- The lower bounds for v_2(g1²) used in cases (2.1) and (2.2.1),
with no nonzero-coordinate restriction. -/
theorem g1_square_two_lower_published {S X C ν : ℤ} (hS : Squarefree S) (hC : C ≠ 0)
    (hν : ν = 1 ∨ ν = -1) (e : ℕ)
    (hN : (2 : ℤ) ^ e ∣ C ^ 2 * S) (hX : (2 : ℤ) ^ e ∣ X ^ 2) :
    e + 2 ≤ padicValNat 2 (g1 (2 * X) (2 * ν * C) ^ 2) + padicValInt 2 S := by
  have hN₀ := mul_ne_zero (pow_ne_zero 2 hC) hS.ne_zero
  have hn := ((padicValInt_dvd_iff _ _).mp hN).resolve_left hN₀
  rw [padicValInt.mul (pow_ne_zero 2 hC) hS.ne_zero, valuation_int_pow] at hn
  have hs := valuation_squarefree_le_one 2 hS
  by_cases hz : X = 0
  · subst X
    have he := (normalizer_zero_coordinate S C ν hν).1
    rw [he, padicValNat.pow, padicValNat.mul (by decide) (Int.natAbs_ne_zero.mpr hC)]
    norm_num
    change e + 2 ≤ 2 * (1 + padicValInt 2 C) + padicValInt 2 S
    simp only [padicValInt] at hn ⊢
    omega
  · have hx := ((padicValInt_dvd_iff _ _).mp hX).resolve_left (pow_ne_zero _ hz)
    rw [valuation_int_pow] at hx
    rw [g1_square_valuation_published 2 hz hC hν]
    norm_num
    simp only [padicValInt] at hn hx hs ⊢
    omega

/-- In case (2.2.2), v_2(N)=ell is odd; the square valuation of X
forces ell_1=ell+1 and ell_2=1. This also covers X=0 directly. -/
theorem normalizer_two_unequal_components {S X C ν : ℤ} (hS : Squarefree S) (hC : C ≠ 0)
    (hν : ν = 1 ∨ ν = -1) (hs : padicValInt 2 S = 1) (e : ℕ)
    (he : padicValInt 2 (C ^ 2 * S) = e) (hX : (2 : ℤ) ^ e ∣ X ^ 2) :
    Odd e ∧ padicValNat 2 (g1 (2 * X) (2 * ν * C) ^ 2) = e + 1 ∧
      padicValNat 2 (g2 S (2 * X) (2 * ν * C)) = 1 := by
  rw [padicValInt.mul (pow_ne_zero 2 hC) hS.ne_zero, valuation_int_pow, hs] at he
  have ho : Odd e := ⟨padicValInt 2 C, he.symm⟩
  refine ⟨ho, ?_⟩
  by_cases hz : X = 0
  · subst X
    have hh := normalizer_zero_coordinate S C ν hν
    rw [hh.1, hh.2, padicValNat.pow, padicValNat.mul (by decide) (Int.natAbs_ne_zero.mpr hC)]
    norm_num
    change 2 * (1 + padicValInt 2 C) = e + 1 ∧ padicValInt 2 S = 1
    exact ⟨by omega, hs⟩
  · have hx := ((padicValInt_dvd_iff _ _).mp hX).resolve_left (pow_ne_zero _ hz)
    rw [valuation_int_pow] at hx
    have hxc : padicValInt 2 C < padicValInt 2 X := by
      simp only [padicValInt] at he hx ⊢
      omega
    rw [g1_square_valuation_published 2 hz hC hν,
      g2_valuation_published 2 hS.ne_zero hz hC hν, min_eq_right (le_of_lt hxc), hs]
    norm_num
    omega

theorem g1_square_two_lower_of_square_divides {X C ν : ℤ} (hC : C ≠ 0)
    (hν : ν = 1 ∨ ν = -1) (e : ℕ)
    (hC₂ : (2 : ℤ) ^ e ∣ C ^ 2) (hX : (2 : ℤ) ^ e ∣ X ^ 2) :
    e + 2 ≤ padicValNat 2 (g1 (2 * X) (2 * ν * C) ^ 2) := by
  simpa using g1_square_two_lower_published (S := 1) (by simp) hC hν e (by simpa using hC₂) hX

end «JNT-2024».Approximation
