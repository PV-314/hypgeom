module

public import «JNT-2024».EulerIntegral
public import «JNT-2024».HypergeometricPolynomials
public import «JNT-2024».RemainderConstruction
public import «JNT-2024».RemainderIdentity
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

/-- The integration-by-parts recurrence constructs a primitive without contour integration. -/
theorem segmentKernel_hasPrimitive {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1)
    (r : ℕ) (z : ℂ) :
    ∃ g : ℂ → ℂ, ∀ w ∈ Complex.slitPlane, HasDerivAt g (segmentKernel ν r z w) w := by
  have hv : (ν : ℂ) ≠ 0 := by exact_mod_cast ne_of_gt hν₀
  have hv₁ : 1 - (ν : ℂ) ≠ 0 := by exact_mod_cast sub_ne_zero.mpr (ne_of_gt hν₁)
  have hv₂ : (ν : ℂ) + 1 ≠ 0 := by exact_mod_cast ne_of_gt (by linarith : 0 < ν + 1)
  induction r using Nat.twoStepInduction with
  | zero =>
    refine ⟨fun w => w ^ (ν : ℂ) / ν, fun w hw => ?_⟩
    convert ((hasDerivAt_id w).cpow_const (c := (ν : ℂ)) hw).div_const (ν : ℂ) using 1
    · rfl
    · simp [segmentKernel, hv]
  | one =>
    refine ⟨fun w => firstPrimitive ν z w / ((1 - (ν : ℂ)) * ν * (ν + 1)), fun w hw => ?_⟩
    convert (hasDerivAt_firstPrimitive ν z hw).div_const ((1 - (ν : ℂ)) * ν * (ν + 1)) using 1
    field_simp
  | more r h₀ h₁ =>
    obtain ⟨g₀, hg₀⟩ := h₀
    obtain ⟨g₁, hg₁⟩ := h₁
    let A : ℂ := ((r : ℂ) + 2) ^ 2 - (ν : ℂ) ^ 2
    let B : ℂ := (r + 2) * (2 * r + 3) * (1 + z)
    let C : ℂ := (r + 2) * (r + 1) * (1 - z) ^ 2
    have hA : A ≠ 0 := by
      have hh : (0 : ℚ) < ((r : ℚ) + 2) ^ 2 - ν ^ 2 := by
        have := Nat.cast_nonneg (α := ℚ) r
        nlinarith
      dsimp [A]
      exact_mod_cast ne_of_gt hh
    refine ⟨fun w => (recurrencePrimitive ν r z w + B * g₁ w - C * g₀ w) / A, fun w hw => ?_⟩
    convert (((hasDerivAt_recurrencePrimitive ν r z hw).add ((hg₁ w hw).const_mul B)).sub
      ((hg₀ w hw).const_mul C)).div_const A using 1
    dsimp [A, B, C] at *
    field_simp
    ring

theorem segmentIntegral_eq_curveIntegral {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1)
    (r : ℕ) {z : ℂ} (hz : z ∈ Complex.slitPlane) (γ γ' : ℝ → ℂ)
    (hγ : ∀ t ∈ Set.Icc (0 : ℝ) 1, γ t ∈ Complex.slitPlane)
    (hd : ∀ t ∈ Set.Icc (0 : ℝ) 1, HasDerivAt γ (γ' t) t)
    (hc : ContinuousOn (fun t => segmentKernel ν r z (γ t) * γ' t) (Set.Icc 0 1))
    (h₀ : γ 0 = 1) (h₁ : γ 1 = z) :
    segmentIntegral ν r z = ∫ t : ℝ in 0..1, segmentKernel ν r z (γ t) * γ' t := by
  obtain ⟨g, hg⟩ := segmentKernel_hasPrimitive hν₀ hν₁ r z
  have hc' : ContinuousOn (fun t : ℝ => segmentKernel ν r z (1 + t • (z - 1)))
      (Set.Icc 0 1) := by
    convert segmentKernel_chord_continuousOn ν r hz using 1
    funext t
    simp [chord, Complex.real_smul, mul_comm]
  have hs := intervalIntegral.integral_unitInterval_deriv_eq_sub
    (f := g) (f' := segmentKernel ν r z) (z₀ := 1) (z₁ := z - 1) hc'
    (fun t ht => hg _ (StarConvex.add_smul_mem Complex.starConvex_one_slitPlane
      (by simpa using hz) ht.1 ht.2))
  have hi := intervalIntegral.integral_eq_sub_of_hasDerivAt
    (f := fun t => g (γ t)) (f' := fun t => segmentKernel ν r z (γ t) * γ' t)
    (fun t ht => by
      have ht' : t ∈ Set.Icc (0 : ℝ) 1 := by simpa using ht
      simpa only [Function.comp_def, smul_eq_mul, mul_comm] using
        (hg (γ t) (hγ t ht')).scomp t (hd t ht'))
    (hc.intervalIntegrable_of_Icc (by norm_num : (0 : ℝ) ≤ 1))
  rw [h₀, h₁] at hi
  rw [hi]
  convert hs using 1
  · simp only [segmentIntegral, chord, Complex.real_smul, smul_eq_mul, mul_comm (z - 1)]
  · simp

noncomputable def circlePoint (θ : ℝ) : ℂ := Complex.exp ((θ : ℂ) * Complex.I)

theorem circlePoint_norm (θ : ℝ) : ‖circlePoint θ‖ = 1 := by
  simp [circlePoint, mul_comm]

theorem circlePoint_add (x y : ℝ) : circlePoint (x + y) = circlePoint x * circlePoint y := by
  simp [circlePoint, add_mul, Complex.exp_add]

theorem circlePoint_zero : circlePoint 0 = 1 := by simp [circlePoint]

theorem circlePoint_arg {z : ℂ} (hz : ‖z‖ = 1) : circlePoint z.arg = z := by
  simpa [circlePoint, hz] using Complex.norm_mul_exp_arg_mul_I z

theorem circlePoint_mem_slitPlane {θ : ℝ} (hθ : |θ| < Real.pi) :
    circlePoint θ ∈ Complex.slitPlane := by
  rw [circlePoint, Complex.exp_mem_slitPlane]
  simp only [Complex.mul_im, Complex.ofReal_re, Complex.I_im, mul_one,
    Complex.ofReal_im, Complex.I_re, mul_zero, add_zero]
  rw [(toIocMod_eq_self Real.two_pi_pos).mpr
    ⟨(abs_lt.mp hθ).1, by linarith [(abs_lt.mp hθ).2]⟩]
  exact ne_of_lt (abs_lt.mp hθ).2

theorem circlePoint_cpow (ν θ : ℝ) (hθ : |θ| < Real.pi) :
    circlePoint θ ^ (ν : ℂ) = circlePoint (ν * θ) := by
  rw [circlePoint, Complex.cpow_def_of_ne_zero (Complex.exp_ne_zero _), Complex.log_exp]
  · unfold circlePoint
    congr 1
    push_cast
    ring
  · simpa using (abs_lt.mp hθ).1
  · simpa using (abs_lt.mp hθ).2.le

theorem hasDerivAt_circlePoint (θ : ℝ) :
    HasDerivAt circlePoint (Complex.I * circlePoint θ) θ := by
  have hh := (Complex.hasDerivAt_exp ((θ : ℂ) * Complex.I)).scomp θ
    ((Complex.ofRealCLM.hasDerivAt).mul_const Complex.I)
  convert hh using 1
  · rfl
  · simp [circlePoint, smul_eq_mul]

theorem circlePoint_continuous : Continuous circlePoint := by
  unfold circlePoint
  fun_prop

theorem remainder_eq_arcIntegral {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1) (r : ℕ)
    {z : ℂ} (hz : ‖z‖ = 1) (hre : 0 ≤ z.re) :
    remainder ν r z = (risingQ ν (r + 1) : ℂ) / r.factorial *
      ∫ t : ℝ in 0..1, segmentKernel ν r z (circlePoint (z.arg * t)) *
        ((z.arg : ℂ) * Complex.I * circlePoint (z.arg * t)) := by
  have ha := Complex.abs_arg_le_pi_div_two_iff.mpr hre
  have hm (t : ℝ) (ht : t ∈ Set.Icc (0 : ℝ) 1) :
      circlePoint (z.arg * t) ∈ Complex.slitPlane := by
    apply circlePoint_mem_slitPlane
    rw [abs_mul, abs_of_nonneg ht.1]
    have := mul_le_of_le_one_right (abs_nonneg z.arg) ht.2
    linarith [Real.pi_pos]
  rw [remainder_eq_segmentIntegral', segmentIntegral_eq_curveIntegral hν₀ hν₁ r
    (unit_rightHalf_mem_slitPlane hz hre)
    (fun t => circlePoint (z.arg * t))
    (fun t => (z.arg : ℂ) * Complex.I * circlePoint (z.arg * t)) hm]
  · intro t _
    have hd' : HasDerivAt (fun u : ℝ => z.arg * u) z.arg t := by
      simpa using (hasDerivAt_id t).const_mul z.arg
    convert (hasDerivAt_circlePoint (z.arg * t)).scomp t hd' using 1
    · rfl
    · rw [Complex.real_smul]
      ring
  · exact ((segmentKernel_continuousOn ν r z).comp
      (circlePoint_continuous.comp (by fun_prop)).continuousOn hm).mul
      ((circlePoint_continuous.comp (by fun_prop)).continuousOn.const_mul _)
  · simp [circlePoint_zero]
  · simpa using circlePoint_arg hz

end Hypergeometric
end «JNT-2024»
