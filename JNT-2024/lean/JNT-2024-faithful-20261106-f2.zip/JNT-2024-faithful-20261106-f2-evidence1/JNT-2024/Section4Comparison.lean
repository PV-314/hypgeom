module

public import «JNT-2024».FourthRootGeometry
public import «JNT-2024».Section2Complex
public import «JNT-2024».Section4Gaussian
public import «JNT-2024».Section4PhasePublished
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

/-- The signed fourth-power identity determines the conjugate ratio; its sign cancels. -/
theorem representation_ratio {α z U : ℂ} {τ : ℤ} (hτ : τ ≠ 0)
    (he : (τ : ℂ) * U = α * z ^ 4) :
    U / star U = (α / star α) * (z / star z) ^ 4 := by
  have ht : (τ : ℂ) ≠ 0 := by exact_mod_cast hτ
  have hu : U = α * z ^ 4 / τ := (eq_div_iff ht).mpr (by simpa only [mul_comm] using he)
  rw [hu, star_div₀, star_mul, star_pow, star_intCast, div_pow]
  simp only [div_div_div_cancel_right₀ ht, mul_div_mul_comm]
  ring

/-- The exact cross-ratio residual preceding (4.2). -/
theorem cross_ratio_residual {α a b U V : ℂ} {τ σ : ℤ}
    (ha : α ≠ 0) (_hb : b ≠ 0) (hτ : τ ≠ 0) (hσ : σ ≠ 0)
    (hU : (τ : ℂ) * U = α * a ^ 4) (hV : (σ : ℂ) * V = α * b ^ 4)
    (hω : ‖U / star U‖ = 1) (hψ : ‖V / star V‖ = 1) :
    ‖U / star U - ((a / star a) / (b / star b)) ^ 4‖ = ‖V / star V - 1‖ := by
  have hα : α / star α ≠ 0 := div_ne_zero ha (star_ne_zero.mpr ha)
  have he : ((a / star a) / (b / star b)) ^ 4 = (U / star U) / (V / star V) := by
    rw [representation_ratio hτ hU, representation_ratio hσ hV, div_pow,
      mul_div_mul_left _ _ hα]
  rw [he]
  have hv : V / star V ≠ 0 := norm_ne_zero_iff.mp (by rw [hψ]; norm_num)
  have hid : U / star U - (U / star U) / (V / star V) =
      (U / star U) * ((V / star V) - 1) / (V / star V) := by
    rw [mul_sub, mul_one, sub_div, mul_div_cancel_right₀ _ hv]
  rw [hid, norm_div, norm_mul, hω, hψ, one_mul, div_one]

/-- Equation (4.9) with the exact coefficients `fₖ=fℓ=1`. -/
theorem comparison_norm {a b : ℂ} {y z : ℝ}
    (ha : ‖a‖ ^ 4 = y) (hb : ‖b‖ ^ 4 = z) : ‖star a * b‖ ^ 4 = y * z := by
  rw [norm_mul, norm_star, mul_pow, ha, hb]

theorem comparison_ratio {a b : ℂ} :
    star (star a * b) / (star a * b) = (a / star a) / (b / star b) := by
  rw [star_mul, star_star, div_div_eq_mul_div]
  ring

/-- The exact chord length for the doubled Gaussian input. -/
theorem gaussian_chord {X Z : ℤ} {L : ℝ} (hL : 0 < L)
    (hcoord : (X : ℝ) ^ 2 + (Z : ℝ) ^ 2 = L ^ 2) :
    ‖Section2.omega (-1) (2 * X) (2 * Z) - 1‖ = 2 * |(Z : ℝ)| / L := by
  let U := Section2.U (-1) (2 * X) (2 * Z)
  have hu : ‖U‖ = L := by
    have hh : ‖U‖ ^ 2 = L ^ 2 := by
      dsimp [U]
      rw [gaussian_U, ← Complex.normSq_eq_norm_sq, Complex.normSq_apply]
      simpa [pow_two] using hcoord
    nlinarith [norm_nonneg U]
  have hU : U ≠ 0 := norm_ne_zero_iff.mp (by rw [hu]; exact ne_of_gt hL)
  have he : U / star U - 1 = (U - star U) / star U := by
    rw [sub_div, div_self (star_ne_zero.mpr hU)]
  change ‖U / star U - 1‖ = _
  rw [he, norm_div, norm_star, hu]
  congr 1
  have hd : U - star U = (⟨0, 2 * (Z : ℝ)⟩ : ℂ) := by
    dsimp [U]
    rw [gaussian_U]
    apply Complex.ext <;> simp
    ring
  rw [hd, Complex.norm_eq_sqrt_sq_add_sq]
  simp [Real.sqrt_sq_eq_abs, abs_mul]


/-- The fourth-root phase used in (4.2), retaining its published constant `3.959`. -/
theorem comparison_phase {ω v : ℂ} {N d z : ℝ}
    (hω : ‖ω‖ = 1) (hv : ‖v‖ = 1) (hN : 0 < N) (hd : 0 < d) (hz : 0 < z)
    (hres : ‖ω - v ^ 4‖ = 2 * Real.sqrt N / (Real.sqrt d * z))
    (hsmall : ‖ω - v ^ 4‖ ≤ 1 / 2) :
    ∃ η : ℂ, FourthPhase η ∧
      ‖ω ^ (1 / 4 : ℂ) - η * v‖ <
        2 * Real.sqrt N / ((3959 / 1000 : ℝ) * Real.sqrt d * z) := by
  have hp : 0 < ‖ω-v^4‖ := by rw [hres]; positivity
  obtain ⟨η,hη,_,_,he⟩ := comparison_phase_3959 hω hv hp hsmall
  refine ⟨η,hη,?_⟩
  rw [hres] at he
  have hden : 0 < Real.sqrt d*z := by positivity
  have hh := (lt_div_iff₀ hden).mp he
  apply (lt_div_iff₀ (by positivity : 0 < (3959/1000 : ℝ)*Real.sqrt d*z)).mpr
  nlinarith only [hh]

end «JNT-2024».Section4
