module

public import «JNT-2024».Section4SmallPairs
public import «JNT-2024».SmallQuarticCertificates
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Calculations

/-- CALC-002: the unrestricted Magma calculation in Section 4.6.
This is an explicit input, not an axiom, instance, or proved theorem.
The existing bounded certificates independently prove everything up to y=109.
The user authorized recording global completeness as a calculation result. -/
structure Section46Magma : Prop where
  height : Section4.SmallQuarticHeightBound

end Calculations

namespace Section4

/-- The input is named explicitly; the bounded Lean calculation is reused. -/
theorem section46_lists_complete (hCalculation : Calculations.Section46Magma) :
    SmallQuarticListsComplete :=
  smallQuartic_completeness_iff_height.mpr hCalculation.height

/-- Identification with the actual unrestricted set of positive solutions. -/
theorem section46_solution_set (hCalculation : Calculations.Section46Magma)
    {a n : ℕ} (hp : (a,n) ∈ smallPairs) :
    {s : ℕ × ℕ | 0 < s.1 ∧ 0 < s.2 ∧ s.1^2+n^2=(a^2+n^2)*s.2^4} =
      (listedQuarticSolutions a n : Set (ℕ × ℕ)) := by
  ext s
  exact (section46_lists_complete hCalculation a n s.1 s.2 hp).symm

/-- All printed list counts, together with their unrestricted interpretation.
There are 18 equations with at least two solutions, and precisely the two
displayed exceptions with three; none has more than three. -/
theorem section46_global_lists_and_counts (hCalculation : Calculations.Section46Magma) :
    SmallQuarticListsComplete ∧
    (smallPairs.filter fun p => 2 ≤ (listedQuarticSolutions p.1 p.2).card).card = 18 ∧
    (smallPairs.filter fun p => 3 ≤ (listedQuarticSolutions p.1 p.2).card) = {(1,4),(2,8)} ∧
    (∀ p ∈ smallPairs, (listedQuarticSolutions p.1 p.2).card ≤ 3) :=
  ⟨section46_lists_complete hCalculation, listedQuarticSolutions_counts⟩

/-- The rational point supplied to the two-argument Magma function.
Magma's coordinate order is (paper y, paper x). -/
theorem section46_magma_base_point (a n : ℤ) :
    a^2 = (a^2+n^2)*1^4-n^2 := by ring

/-- Exact translation from the paper equation to the Magma quartic. -/
theorem section46_magma_equation (a n x y : ℤ) :
    x^2+n^2=(a^2+n^2)*y^4 ↔ x^2=(a^2+n^2)*y^4-n^2 := by omega

end Section4
end «JNT-2024»
