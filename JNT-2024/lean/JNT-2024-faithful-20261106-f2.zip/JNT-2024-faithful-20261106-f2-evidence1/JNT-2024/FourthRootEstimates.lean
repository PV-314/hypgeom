module

public import «JNT-2024».FourthRootGeometry
public import «JNT-2024».FourthRootTrig
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

theorem exists_unit_fourth_root {ω : ℂ} (hω : ‖ω‖ = 1) : ∃ w : ℂ, w ^ 4 = ω ∧ ‖w‖ = 1 := by
  let w : ℂ := ω ^ ((4 : ℂ)⁻¹)
  have hw : w ^ 4 = ω := Complex.cpow_nat_inv_pow _ (by norm_num)
  refine ⟨w, hw, ?_⟩
  have hh := congrArg norm hw
  rw [norm_pow, hω] at hh
  have hsq : ‖w‖ ^ 2 = 1 := by nlinarith [sq_nonneg (‖w‖ ^ 2 - 1)]
  nlinarith [norm_nonneg w]

/-- Lemma 3.7(b), with an explicit choice of the smallest positive polynomial root. -/
theorem lemma37b {ω z : ℂ} {c : ℝ} (hω : ‖ω‖ = 1) (hz : ‖z‖ = 1)
    (_hc : 0 < c) (hc2 : c ≤ 2) (hpos : 0 < ‖ω - z ^ 4‖) (hsmall : ‖ω - z ^ 4‖ < c) :
    ∃ w : ℂ, w ^ 4 = ω ∧ ‖w‖ = 1 ∧ 0 < ‖w - z‖ ∧ ‖w - z‖ < fourthRootRadius c := by
  obtain ⟨w, hw, hwn⟩ := exists_unit_fourth_root hω
  obtain ⟨ζ, hζ, hnear, _⟩ := exists_minimizing_fourth_phase hz hwn
  let v := ζ * w
  have hv : v ^ 4 = ω := by dsimp [v]; rw [mul_pow, hζ.pow_four, one_mul, hw]
  have hvn : ‖v‖ = 1 := by dsimp [v]; rw [norm_mul, hζ.norm, hwn, mul_one]
  have hlim : ‖v - z‖ ^ 2 ≤ 2 - Real.sqrt 2 := by simpa only [norm_sub_rev] using hnear
  have hdist : 0 < ‖v - z‖ := by
    apply norm_pos_iff.mpr
    intro he
    have hvz := sub_eq_zero.mp he
    rw [hvz] at hv
    rw [← hv, sub_self, norm_zero] at hpos
    exact (lt_irrefl 0) hpos
  have hid := fourth_power_chord_identity_b_published hvn hz (by simpa only [hv] using hpos)
  rw [hv] at hid
  have he : fourthChordMap (‖v - z‖ ^ 2) = ‖ω - z ^ 4‖ ^ 2 := by
    exact hid.symm
  have hchosen := fourthRootRadius_eq_of_chord hpos
    (le_trans (le_of_lt hsmall) hc2) hdist hlim he
  have hmono := fourthRootRadius_strictMono hpos hsmall hc2
  exact ⟨v, hv, hvn, hdist, by rw [hchosen]; exact hmono⟩


theorem fourthRootRadius_half_bound : fourthRootRadius (5001 / 10000) < 1263 / 10000 := by
  obtain ⟨hr, hlim, he⟩ := fourthRootRadius_properties (by norm_num : (0 : ℝ) < 5001 / 10000)
    (by norm_num : (5001 / 10000 : ℝ) ≤ 2)
  have hnum : (5001 / 10000 : ℝ) ^ 2 < fourthChordMap ((1263 / 10000) ^ 2) := by
    norm_num [fourthChordMap]
  by_contra hn
  have hs : (1263 / 10000 : ℝ) ^ 2 ≤ fourthRootRadius (5001 / 10000) ^ 2 := by nlinarith
  rcases lt_or_eq_of_le hs with hh | hh
  · have hm := fourthChordMap_strict hh hlim
    rw [he] at hm
    linarith
  · rw [hh, he] at hnum
    exact (lt_irrefl _) hnum

theorem fourthRoot_expansion_constant :
    (396 / 100 : ℝ) < (2 - (1263 / 10000) ^ 2) * Real.sqrt (4 - (1263 / 10000) ^ 2) := by
  have hh := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 4 - (1263 / 10000) ^ 2)
  have hp := Real.sqrt_nonneg (4 - (1263 / 10000 : ℝ) ^ 2)
  nlinarith


/-- The minimizing phase and the literal 0.1263 conclusion used in (3.31). -/
theorem fourth_root_half_minimizer {w z : ℂ} (hw : ‖w‖ = 1) (hz : ‖z‖ = 1)
    (hpos : 0 < ‖w ^ 4 - z ^ 4‖) (hsmall : ‖w ^ 4 - z ^ 4‖ ≤ 1 / 2) :
    ∃ ζ : ℂ, FourthPhase ζ ∧ 0 < ‖w - ζ * z‖ ∧
      ‖w - ζ * z‖ < 1263 / 10000 ∧
      ∀ η : ℂ, FourthPhase η → ‖w - ζ * z‖ ≤ ‖w - η * z‖ := by
  obtain ⟨ζ, hζ, hnear, hmin⟩ := exists_minimizing_fourth_phase hw hz
  have hzn : ‖ζ * z‖ = 1 := by rw [norm_mul, hζ.norm, hz, mul_one]
  have hzp : (ζ * z) ^ 4 = z ^ 4 := by rw [mul_pow, hζ.pow_four, one_mul]
  have hid := fourth_power_chord_identity_b_published hw hzn (by simpa only [hzp] using hpos)
  rw [hzp] at hid
  have hd : 0 < ‖w - ζ * z‖ := by
    apply norm_pos_iff.mpr
    intro he
    have he' : w ^ 4 = z ^ 4 := by rw [sub_eq_zero.mp he, hzp]
    rw [he', sub_self, norm_zero] at hpos
    exact (lt_irrefl 0) hpos
  have hclose : ‖w - ζ * z‖ < 1263 / 10000 := by
    have he : fourthChordMap (‖w - ζ * z‖ ^ 2) = ‖w ^ 4 - z ^ 4‖ ^ 2 := hid.symm
    have hchosen := fourthRootRadius_eq_of_chord hpos (by linarith : ‖w ^ 4 - z ^ 4‖ ≤ 2)
      hd hnear he
    have hmono := fourthRootRadius_strictMono hpos
      (show ‖w ^ 4 - z ^ 4‖ < 5001 / 10000 by linarith)
      (by norm_num : (5001 / 10000 : ℝ) ≤ 2)
    rw [hchosen]
    exact lt_trans hmono fourthRootRadius_half_bound
  exact ⟨ζ, hζ, hd, hclose, hmin⟩

/-- A common fourth root can be used for several approximants by adjusting their phases. -/
theorem fourth_root_half_error_fixed {w z : ℂ} (hw : ‖w‖ = 1) (hz : ‖z‖ = 1)
    (hpos : 0 < ‖w ^ 4 - z ^ 4‖) (hsmall : ‖w ^ 4 - z ^ 4‖ ≤ 1 / 2) :
    ∃ ζ : ℂ, FourthPhase ζ ∧
      ‖w - ζ * z‖ < (5051 / 20000 : ℝ) * ‖w ^ 4 - z ^ 4‖ := by
  obtain ⟨ζ, hζ, hd, hclose, _⟩ := fourth_root_half_minimizer hw hz hpos hsmall
  have hzn : ‖ζ * z‖ = 1 := by rw [norm_mul, hζ.norm, hz, mul_one]
  have hzp : (ζ * z) ^ 4 = z ^ 4 := by rw [mul_pow, hζ.pow_four, one_mul]
  have hc : (1263 / 10000 : ℝ) < Real.sqrt 2 := by
    have hh := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
    have hp := Real.sqrt_nonneg (2 : ℝ)
    nlinarith
  have he := lemma37a hw hzn (by norm_num : (0 : ℝ) < 1263 / 10000) hc hd hclose
  rw [hzp] at he
  have hf := mul_lt_mul_of_pos_right fourthRoot_expansion_constant hd
  exact ⟨ζ, hζ, by nlinarith⟩

end «JNT-2024»
