module

public import «JNT-2024».Sequence
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»


namespace Parameters

theorem odd_b_of_even_norm (P : Parameters) (hc : Int.gcd P.a P.b = 1) (hN : Even P.normAlpha) : Odd P.b := by
  apply Int.not_even_iff_odd.mp
  intro hb
  have ha2 : Even (P.a ^ 2) := by
    have hh := hN.add ((hb.pow_of_ne_zero (by decide : (4 : ℕ) ≠ 0)).mul_right P.d)
    convert hh using 1
    unfold normAlpha
    ring
  have ha := (Int.even_pow.mp ha2).1
  have hd : (2 : ℤ) ∣ (Int.gcd P.a P.b : ℤ) :=
    Int.dvd_coe_gcd (even_iff_two_dvd.mp ha) (even_iff_two_dvd.mp hb)
  norm_num [hc] at hd


end Parameters
end «JNT-2024»
