module

public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.Deriv.MeanValue
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

/-- Equation (4.18): cube (4.17) and combine it with the derived (4.11). -/
theorem nonexact_equation418 {N d y z F M c : ℝ} {r : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hy : 0 < y) (hF : 0 < F) (hM : 0 < M)
    (hc : 0 < c)
    (h417 : ((8537/1000 : ℝ)/M)^4*(N/F)^2*c^4*((1832/10000 : ℝ)*M/N)^(4*r)*
      d^(2*r)*y^(4*r-1) < z)
    (h411 : z^3 < (N*F)^2*((64/100 : ℝ)/(1-c))^4*((2147/100 : ℝ)/M)^(4*r)*
      d^(2*r-2)*y^(4*r+1)) :
    ((8537/1000 : ℝ)/M)^12*(N/F)^6*c^12*((1832/10000 : ℝ)*M/N)^(12*r)*
      d^(6*r)*y^(12*r-3) <
      (N*F)^2*((64/100 : ℝ)/(1-c))^4*((2147/100 : ℝ)/M)^(4*r)*
      d^(2*r-2)*y^(4*r+1) := by
  have hh := pow_lt_pow_left₀ h417 (by positivity) (by decide : 3 ≠ 0)
  apply lt_trans _ h411
  convert hh using 1
  simp only [mul_pow,← pow_mul]
  rw [show 4*3=12 from rfl,show 2*3=6 from rfl,
    show 4*r*3=12*r by omega,show 2*r*3=6*r by omega,
    show (4*r-1)*3=12*r-3 by omega]

/-- The elementary calculus justification for c=3/4 in Section 4.4. -/
theorem cutoff_choice_monotone :
    MonotoneOn (fun c : ℝ => c^12*(1-c)^4) (Set.Icc 0 (3/4)) := by
  have hder (c : ℝ) : HasDerivAt (fun x : ℝ => x^12*(1-x)^4)
      (4*c^11*(1-c)^3*(3-4*c)) c := by
    convert ((hasDerivAt_id c).pow 12).mul
      (((hasDerivAt_const c (1:ℝ)).sub (hasDerivAt_id c)).pow 4) using 1 <;> try dsimp
    · ext x
      rfl
    · ring
  apply monotoneOn_of_deriv_nonneg (convex_Icc _ _) (by fun_prop)
    (fun c _ => (hder c).differentiableAt.differentiableWithinAt)
  intro c hc
  rw [(hder c).deriv]
  have hc' : c ∈ Set.Icc (0:ℝ) (3/4) := interior_subset hc
  have h1 : 0 ≤ 1-c := by linarith [hc'.2]
  have h2 : 0 ≤ 3-4*c := by linarith [hc'.2]
  exact mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hc'.1 11))
    (pow_nonneg h1 3)) h2

/-- The numerical lower bound for the chosen c, as printed. -/
theorem cutoff_choice_value :
    (1237/10000000 : ℝ) < (3/4 : ℝ)^12*(1-3/4)^4 := by norm_num

/-- The two rational roundings used to pass from (4.18) to (4.19). -/
theorem case44_rounding_constants :
    (2147/100 : ℝ)^2/(1832/10000)^6 < 12200000 ∧
    (64/100 : ℝ)^4*(2147/100)^2/
      ((1832/10000)^6*(1237/10000000)*(8537/1000)^12) < 111/1000 := by
  norm_num

end «JNT-2024».Section4
