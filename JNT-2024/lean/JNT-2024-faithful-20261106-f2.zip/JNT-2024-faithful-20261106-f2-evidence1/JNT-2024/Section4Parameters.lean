module

public import «JNT-2024».NormalizerFormula
public import «JNT-2024».Section2Complex
public import «JNT-2024».Section2Geometry
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

/-- Substitution of the doubled Gaussian coordinates in (4.5)--(4.7). -/
theorem gaussian_parameters {X Z : ℤ} {N L : ℝ} (hL : 0 < L)
    (hZ : (Z : ℝ) ^ 2 = N) (hcoord : (X : ℝ) ^ 2 + N = L ^ 2) :
    Section2.E (-1) (2 * X) (2 * Z) =
      Approximation.normalizerProduct (-1) (2 * X) (2 * Z) * (|(X : ℝ)| + L) /
        (2 * Real.exp (42 / 25) * N) ∧
    Section2.Q (-1) (2 * X) (2 * Z) =
      2 * Real.exp (42 / 25) * (|(X : ℝ)| + L) /
        Approximation.normalizerProduct (-1) (2 * X) (2 * Z) := by
  have hH : Section2.H (-1) (2 * X) (2 * Z) = (2 * L) ^ 2 := by
    norm_num [Section2.H]
    nlinarith only [hZ, hcoord]
  have hs : Real.sqrt (Section2.H (-1) (2 * X) (2 * Z)) = 2 * L := by
    rw [hH, Real.sqrt_sq (by positivity)]
  constructor
  · rw [Section2.E, hs]
    norm_num only [Int.cast_mul, Int.cast_ofNat, Int.cast_neg, Int.cast_one, abs_neg,
      abs_one, mul_one, abs_mul, abs_of_pos (by norm_num : (0 : ℝ) < 2), mul_pow, hZ]
    ring
  · rw [Section2.Q, hs]
    norm_num only [Int.cast_mul, Int.cast_ofNat, abs_mul, abs_of_pos (by norm_num : (0 : ℝ) < 2)]
    ring

end «JNT-2024».Section4

namespace «JNT-2024».Parameters


end «JNT-2024».Parameters
