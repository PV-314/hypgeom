module

public import «JNT-2024».ArcGeometry
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

theorem arcWeight_sin (φ t : ℝ) :
    arcWeight φ t = 4 * Real.sin (φ * t / 2) * Real.sin (φ * (1 - t) / 2) := by
  rw [arcWeight, Real.cos_sub_cos]
  rw [show (φ * t - φ / 2 + φ / 2) / 2 = φ * t / 2 by ring,
    show (φ * t - φ / 2 - φ / 2) / 2 = -(φ * (1 - t) / 2) by ring, Real.sin_neg]
  ring

theorem arcWeight_neg (φ t : ℝ) : arcWeight (-φ) t = arcWeight φ t := by
  unfold arcWeight
  rw [show -φ * t - -φ / 2 = -(φ * t - φ / 2) by ring,
    show -φ / 2 = -(φ / 2) by ring, Real.cos_neg, Real.cos_neg]

theorem arcWeight_abs (φ t : ℝ) : arcWeight |φ| t = arcWeight φ t := by
  rcases le_or_gt 0 φ with hh | hh
  · rw [abs_of_nonneg hh]
  · rw [abs_of_neg hh, arcWeight_neg]

theorem sin_scaled_ge {h t : ℝ} (hh : h ∈ Set.Icc 0 Real.pi) (ht : t ∈ Set.Icc 0 1) :
    t * Real.sin h ≤ Real.sin (h * t) := by
  have hs := strictConcaveOn_sin_Icc.concaveOn.2
    (show (0 : ℝ) ∈ Set.Icc 0 Real.pi from ⟨le_rfl, Real.pi_pos.le⟩) hh
    (sub_nonneg.mpr ht.2) ht.1 (show (1 - t) + t = 1 by ring)
  simpa only [smul_eq_mul, Real.sin_zero, mul_zero, zero_add, mul_comm h] using hs

theorem arcWeight_lower {φ t : ℝ} (hφ : |φ| ≤ Real.pi / 2) (ht : t ∈ Set.Icc 0 1) :
    (2 * Real.sin (|φ| / 2)) ^ 2 * t * (1 - t) ≤ arcWeight φ t := by
  rw [← arcWeight_abs, arcWeight_sin]
  have hh : |φ| / 2 ∈ Set.Icc (0 : ℝ) Real.pi :=
    ⟨by positivity, by linarith [Real.pi_pos]⟩
  have h₁ := sin_scaled_ge hh ht
  have h₂ := sin_scaled_ge hh (show 1 - t ∈ Set.Icc (0 : ℝ) 1 from
    ⟨by linarith [ht.2], by linarith [ht.1]⟩)
  have hs := Real.sin_nonneg_of_mem_Icc hh
  have hp := mul_le_mul h₁ h₂ (mul_nonneg (by linarith [ht.2]) hs)
    ((mul_nonneg ht.1 hs).trans h₁)
  rw [show |φ| / 2 * t = |φ| * t / 2 by ring,
    show |φ| / 2 * (1 - t) = |φ| * (1 - t) / 2 by ring] at hp
  nlinarith

theorem arcPhase_cos_lower {ν φ t : ℝ} (hν₀ : 0 ≤ ν) (hν₁ : ν ≤ 1 / 2)
    (hφ : |φ| ≤ Real.pi / 2) (ht : t ∈ Set.Icc 0 1) :
    Real.cos (|φ| / 4) ≤ Real.cos (ν * φ * (t - 1 / 2)) := by
  have ht' : |t - 1 / 2| ≤ 1 / 2 := abs_le.mpr ⟨by linarith [ht.1], by linarith [ht.2]⟩
  have hu : |ν * φ * (t - 1 / 2)| ≤ |φ| / 4 := by
    rw [abs_mul, abs_mul, abs_of_nonneg hν₀]
    have h₁ := mul_le_mul_of_nonneg_left ht' (mul_nonneg hν₀ (abs_nonneg φ))
    have h₂ := mul_le_mul_of_nonneg_right hν₁ (abs_nonneg φ)
    nlinarith
  have hc := Real.cos_le_cos_of_nonneg_of_le_pi (abs_nonneg (ν * φ * (t - 1 / 2)))
    (show |φ| / 4 ≤ Real.pi by linarith [Real.pi_pos]) hu
  simpa only [Real.cos_abs] using hc

theorem arcPhase_cos_nonneg {φ : ℝ} (hφ : |φ| ≤ Real.pi / 2) :
    0 ≤ Real.cos (|φ| / 4) := by
  apply Real.cos_nonneg_of_mem_Icc
  constructor <;> linarith [abs_nonneg φ, Real.pi_pos]

theorem arc_sine_comparison {φ : ℝ} (hφ : |φ| ≤ Real.pi / 2) :
    2 * Real.sin (|φ| / 2) ≤ |φ| * Real.cos (|φ| / 4) := by
  have hc := arcPhase_cos_nonneg hφ
  have hs := Real.sin_le (show 0 ≤ |φ| / 4 by positivity)
  have hd := Real.sin_two_mul (|φ| / 4)
  rw [show 2 * (|φ| / 4) = |φ| / 2 by ring] at hd
  rw [hd]
  nlinarith

end Hypergeometric
end «JNT-2024»
