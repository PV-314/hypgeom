module

public import «JNT-2024».FiniteBounds
public import «JNT-2024».SmallUnitBounds
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace FiniteBounds

theorem commonSquare_bounds {a d n : ℕ} (hn : 0 < n) (hd : d = a ^ 2 + n) :
    4 ≤ commonSquare a d n ∧ commonSquare a d n ≤ 64 * n := by
  have hge : Nat.gcd (a ^ 2) d = Nat.gcd (a ^ 2) n := by rw [hd, add_comm, Nat.gcd_add_self_right]
  have hG : 0 < Nat.gcd (a ^ 2) d := by rw [hge]; exact Nat.gcd_pos_of_pos_right _ hn
  have hGl : Nat.gcd (a ^ 2) d ≤ n := by rw [hge]; exact Nat.gcd_le_right _ hn
  have hC : 0 < Nat.gcd 16 (n / Nat.gcd (a ^ 2) d) := Nat.gcd_pos_of_pos_left _ (by decide)
  have hCl : Nat.gcd 16 (n / Nat.gcd (a ^ 2) d) ≤ 16 := Nat.gcd_le_left _ (by decide)
  unfold commonSquare
  constructor <;> nlinarith

theorem large_solution {d n y M : ℕ} (hn : 0 < n) (hnd : n < d)
    (hny : n ≤ 4 * y) (hy : 73 ≤ y) (hM : 4 ≤ M) (hMu : M ≤ 64 * n) :
    1832 ^ 2 * M * d * y ^ 2 > 11300 ^ 2 * n ^ 2 ∧
      2112 ^ 2 * d * y ^ 2 > 19000 ^ 2 * M := by
  have hd : 0 < d := by omega
  have hy0 : 0 < y := by omega
  have hnn : n ^ 2 ≤ 4 * d * y := by
    have hh := Nat.mul_le_mul (le_of_lt hnd) hny
    nlinarith only [hh]
  constructor
  · have hcoef : 11300 ^ 2 < 1832 ^ 2 * y := by omega
    calc
      _ ≤ 11300 ^ 2 * (4 * d * y) := Nat.mul_le_mul_left _ hnn
      _ < (1832 ^ 2 * y) * (4 * d * y) := Nat.mul_lt_mul_of_pos_right hcoef (by positivity)
      _ ≤ _ := by nlinarith only [Nat.mul_le_mul_right (1832 ^ 2 * d * y ^ 2) hM]
  · have hcoef : 19000 ^ 2 * 64 < 2112 ^ 2 * y ^ 2 := by nlinarith
    calc
      _ ≤ 19000 ^ 2 * (64 * n) := Nat.mul_le_mul_left _ hMu
      _ < (2112 ^ 2 * y ^ 2) * n := by
        nlinarith only [Nat.mul_lt_mul_of_pos_right hcoef hn]
      _ ≤ _ := by nlinarith only [Nat.mul_le_mul_left (2112 ^ 2 * y ^ 2) (le_of_lt hnd)]

theorem unit_solution {a d n y : ℕ} {T U ν : ℤ}
    (ha : 0 < a) (hd : 112 ≤ d) (hn : 0 < n) (hdn : d = a ^ 2 + n)
    (hy : 1 < y) (hu : U ≠ 0) (hν : ν = 1 ∨ ν = -1)
    (hnorm : T ^ 2 - (d : ℤ) * U ^ 2 = 4 * ν)
    (hcoord : 4 * (y : ℤ) = (T + a * U) ^ 2 + (n : ℤ) * U ^ 2) :
    1832 ^ 2 * commonSquare a d n * d * y ^ 2 > 11300 ^ 2 * n ^ 2 ∧
      2112 ^ 2 * d * y ^ 2 > 19000 ^ 2 * commonSquare a d n := by
  by_cases hsmall : y ≤ 72
  · exact small_unit_solution ha hd hn hdn hy hsmall hu hν hnorm hcoord
  · have hU : (1 : ℤ) ≤ U ^ 2 := by have hh := sq_pos_of_ne_zero hu; omega
    have hn' : (0 : ℤ) < n := by exact_mod_cast hn
    have hny : n ≤ 4 * y := by
      have hh : (n : ℤ) ≤ 4 * y := by nlinarith [sq_nonneg (T + a * U)]
      exact_mod_cast hh
    have hb := commonSquare_bounds hn hdn
    exact large_solution hn (by nlinarith) hny (by omega) hb.1 hb.2

end FiniteBounds
end «JNT-2024»
