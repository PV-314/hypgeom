module

public import «JNT-2024».GapLattice
public import «JNT-2024».GapPrinciple
public import «JNT-2024».GapPublishedAlgebra
public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».RepresentationGaussian
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

noncomputable def imaginaryEmbedding (S : ℤ) (hS : S ≤ 0) :
    QuadraticAlgebra ℚ (S : ℚ) 0 →+* ℂ where
  toFun z := ⟨z.re, (z.im : ℝ) * Real.sqrt (-S)⟩
  map_one' := by apply Complex.ext <;> simp [QuadraticAlgebra.re_one, QuadraticAlgebra.im_one]
  map_zero' := by apply Complex.ext <;> simp [QuadraticAlgebra.re_zero, QuadraticAlgebra.im_zero]
  map_add' z w := by apply Complex.ext <;> simp; ring
  map_mul' z w := by
    have hh := Real.sq_sqrt (show (0 : ℝ) ≤ -(S : ℝ) by exact_mod_cast neg_nonneg.mpr hS)
    have hm := congrArg (fun x : ℝ => (z.im : ℝ) * w.im * x) hh
    apply Complex.ext <;> simp <;> nlinarith only [hm]

theorem squarefreePart_neg {n : ℤ} (hn : n < 0) : squarefreePart n < 0 := by
  have he := squareFactor_sq_mul n
  have hp := squareFactor_pos (ne_of_lt hn)
  nlinarith

/-- A division-free form of the exact residual used in (3.20). -/
theorem complex_representation_residual {α z : ℂ} {x v f τ : ℝ}
    (ha : α ≠ 0) (hz : z ≠ 0) (hi : 0 < α.im) (_hf : 0 < f)
    (hv : v = 1 ∨ v = -1) (hτ : τ = 1 ∨ τ = -1)
    (he : ((τ * f ^ 2 : ℝ) : ℂ) * (⟨x, v * α.im⟩ : ℂ) = α * z ^ 4) :
    ‖star α / α - (z / star z) ^ 4‖ * (‖α‖ * ‖z‖ ^ 4) = 2 * f ^ 2 * α.im := by
  have hs : star z ≠ 0 := star_ne_zero.mpr hz
  have hid : (star α / α - (z / star z) ^ 4) * (α * (star z) ^ 4) =
      star α * (star z) ^ 4 - α * z ^ 4 := by field_simp
  have hc := congrArg (starRingEnd ℂ) he
  simp only [map_mul, map_pow, Complex.conj_ofReal] at hc
  change ((τ * f ^ 2 : ℝ) : ℂ) * star (⟨x, v * α.im⟩ : ℂ) = star α * (star z) ^ 4 at hc
  rw [← he, ← hc] at hid
  have hn := congrArg norm hid
  simp only [norm_mul, norm_pow, norm_star] at hn
  have hval : ‖((τ * f ^ 2 : ℝ) : ℂ) * star (⟨x, v * α.im⟩ : ℂ) -
      ((τ * f ^ 2 : ℝ) : ℂ) * (⟨x, v * α.im⟩ : ℂ)‖ = 2 * f ^ 2 * α.im := by
    have hrewrite : ((τ * f ^ 2 : ℝ) : ℂ) * star (⟨x, v * α.im⟩ : ℂ) -
        ((τ * f ^ 2 : ℝ) : ℂ) * (⟨x, v * α.im⟩ : ℂ) =
        (⟨0, -2 * τ * f ^ 2 * v * α.im⟩ : ℂ) := by
      apply Complex.ext <;> simp [pow_two]; ring
    rw [hrewrite]
    have hni : ‖(⟨0, -2 * τ * f ^ 2 * v * α.im⟩ : ℂ)‖ = |-2 * τ * f ^ 2 * v * α.im| := by
      rw [Complex.norm_eq_sqrt_sq_add_sq]
      simp only [zero_pow (by decide : (2 : ℕ) ≠ 0), zero_add, Real.sqrt_sq_eq_abs]
    rw [hni]
    rcases hv with rfl | rfl <;> rcases hτ with rfl | rfl <;>
      simp [abs_mul, abs_of_pos hi, abs_of_nonneg (sq_nonneg f)]
  simpa only [Complex.star_def] using hn.trans hval

namespace Parameters

noncomputable def negativeNormRoot (P : Parameters) : ℝ :=
  (squareFactor P.normAlpha : ℝ) * Real.sqrt (-(squarefreePart P.normAlpha : ℝ))

noncomputable def complexAlpha (P : Parameters) : ℂ := ⟨P.a, P.negativeNormRoot⟩
noncomputable def gapOmega (P : Parameters) : ℂ := star P.complexAlpha / P.complexAlpha
noncomputable def gapScale (P : Parameters) : ℝ := (P.b : ℝ) ^ 2 * P.negativeNormRoot / ‖P.complexAlpha‖

theorem negativeNormRoot_pos (P : Parameters) (hn : P.normAlpha < 0) : 0 < P.negativeNormRoot := by
  have hc : (0 : ℝ) < squareFactor P.normAlpha := by exact_mod_cast squareFactor_pos (ne_of_lt hn)
  have hs : (0 : ℝ) < -(squarefreePart P.normAlpha : ℝ) := by exact_mod_cast neg_pos.mpr (squarefreePart_neg hn)
  exact mul_pos hc (Real.sqrt_pos.mpr hs)

theorem negativeNormRoot_sq (P : Parameters) (hn : P.normAlpha < 0) :
    P.negativeNormRoot ^ 2 = -(P.normAlpha : ℝ) := by
  have hs : (0 : ℝ) ≤ -(squarefreePart P.normAlpha : ℝ) := by
    exact_mod_cast neg_nonneg.mpr (squarefreePart_neg hn).le
  have he : (squareFactor P.normAlpha : ℝ) ^ 2 * squarefreePart P.normAlpha = P.normAlpha := by
    exact_mod_cast squareFactor_sq_mul P.normAlpha
  rw [negativeNormRoot, mul_pow, Real.sq_sqrt hs]
  nlinarith only [he]

theorem complexAlpha_ne_zero (P : Parameters) (hn : P.normAlpha < 0) : P.complexAlpha ≠ 0 := by
  intro he
  have hh := congrArg Complex.im he
  have hp := P.negativeNormRoot_pos hn
  change P.negativeNormRoot = 0 at hh
  linarith

theorem gapOmega_norm (P : Parameters) (hn : P.normAlpha < 0) : ‖P.gapOmega‖ = 1 := by
  rw [gapOmega, norm_div, norm_star, div_self (norm_ne_zero_iff.mpr (P.complexAlpha_ne_zero hn))]

theorem complexAlpha_norm_sq (P : Parameters) (hn : P.normAlpha < 0) :
    ‖P.complexAlpha‖ ^ 2 = (P.b : ℝ) ^ 4 * P.d := by
  rw [← Complex.normSq_eq_norm_sq]
  have hh := P.negativeNormRoot_sq hn
  simp only [Complex.normSq_apply, complexAlpha]
  simp [normAlpha] at hh
  nlinarith only [hh]

theorem gapScale_pos (P : Parameters) (hb : 0 < P.b) (hn : P.normAlpha < 0) : 0 < P.gapScale := by
  have hb' : (0 : ℝ) < P.b := by exact_mod_cast hb
  exact div_pos (mul_pos (sq_pos_of_pos hb') (P.negativeNormRoot_pos hn))
    (norm_pos_iff.mpr (P.complexAlpha_ne_zero hn))

theorem gapScale_sq (P : Parameters) (hb : 0 < P.b) (hn : P.normAlpha < 0) :
    P.gapScale ^ 2 = -(P.normAlpha : ℝ) / P.d := by
  have hb' : (P.b : ℝ) ≠ 0 := by exact_mod_cast ne_of_gt hb
  rw [gapScale, div_pow, mul_pow, P.negativeNormRoot_sq hn, P.complexAlpha_norm_sq hn]
  field_simp

theorem gapScale_eq_sqrt (P : Parameters) (hb : 0 < P.b) (hn : P.normAlpha < 0) :
    P.gapScale = Real.sqrt (|(P.normAlpha : ℝ)| / P.d) := by
  have hn' : (P.normAlpha : ℝ) < 0 := by exact_mod_cast hn
  rw [abs_of_neg hn', ← P.gapScale_sq hb hn, Real.sqrt_sq (P.gapScale_pos hb hn).le]

theorem quadraticPoint_norm_sq (D r s : ℤ) (hD : 0 ≤ D) :
    ‖quadraticPoint D r s‖ ^ 2 = (r : ℝ) ^ 2 + D * (s : ℝ) ^ 2 := by
  rw [← Complex.normSq_eq_norm_sq]
  have hh := Real.sq_sqrt (show (0 : ℝ) ≤ D by exact_mod_cast hD)
  have hm := congrArg (fun x : ℝ => (s : ℝ) ^ 2 * x) hh
  simp only [quadraticPoint, Complex.normSq_apply]
  nlinarith only [hm]

/-- The complex identity from Proposition 3.1, retaining both signs and the unit norm. -/
theorem signed_representation_complex (P : Parameters) {x v f r s τ : ℤ}
    (hn : P.normAlpha < 0) (hrep : P.SignedFourthPowerRepresentation x v f r s τ) :
    (((τ : ℝ) * (f : ℝ) ^ 2 : ℝ) : ℂ) *
      (⟨(x : ℝ), (P.epsilonNorm : ℝ) * P.complexAlpha.im⟩ : ℂ) =
      P.complexAlpha * quadraticPoint (-squarefreePart P.normAlpha) r s ^ 4 := by
  have hh := congrArg (imaginaryEmbedding (squarefreePart P.normAlpha) (squarefreePart_neg hn).le) hrep.1
  rw [map_mul, map_pow] at hh
  convert hh using 1
  · apply Complex.ext <;>
      simp [imaginaryEmbedding, complexAlpha, negativeNormRoot, pow_two]; ring
  · congr 1
    dsimp [quadraticPoint, imaginaryEmbedding]
    simp

/-- Convert both equations of Proposition 3.1, including its allowed sign, to gap data. -/
theorem signed_representation_datum (P : Parameters) {x v f r s τ : ℤ}
    (hb : 0 < P.b) (hn : P.normAlpha < 0) (hp : P.Pell) (hv : 0 < v) (hf : f ≠ 0)
    (hτ : τ = 1 ∨ τ = -1) (hrep : P.SignedFourthPowerRepresentation x v f r s τ) :
    ∃ p : FourthPowerDatum (-squarefreePart P.normAlpha) P.b P.gapScale P.gapOmega,
      p.y = (v : ℝ) ^ 2 ∧ p.f = (f : ℝ) ∧ p.r = r ∧ p.s = s := by
  let S := squarefreePart P.normAlpha
  let z := quadraticPoint (-S) r s
  have hS : S < 0 := squarefreePart_neg hn
  have hb' : (0 : ℝ) < P.b := by exact_mod_cast hb
  have hv' : (0 : ℝ) < v := by exact_mod_cast hv
  have hf' : (f : ℝ) ≠ 0 := by exact_mod_cast hf
  have hnorm : ‖z‖ ^ 2 = (r : ℝ) ^ 2 - S * (s : ℝ) ^ 2 := by
    simpa [z, sub_eq_add_neg] using quadraticPoint_norm_sq (-S) r s (neg_nonneg.mpr hS.le)
  have hcomp : (f : ℝ) * v = P.b * ‖z‖ ^ 2 := by
    rw [hnorm]
    exact_mod_cast hrep.2
  have hz : z ≠ 0 := by
    intro he
    rw [he, norm_zero, zero_pow (by decide : (2 : ℕ) ≠ 0), mul_zero] at hcomp
    exact mul_ne_zero hf' (ne_of_gt hv') hcomp
  have hfp : (0 : ℝ) < f := by
    have hh := mul_pos hb' (sq_pos_of_pos (norm_pos_iff.mpr hz))
    rw [← hcomp] at hh
    exact (mul_pos_iff_of_pos_right hv').mp hh
  have hfour : ‖z‖ ^ 4 * (P.b : ℝ) ^ 2 = (f : ℝ) ^ 2 * (v : ℝ) ^ 2 := by
    have hh := congrArg (fun x : ℝ => x ^ 2) hcomp
    nlinarith only [hh]
  have he : (((τ : ℝ) * (f : ℝ) ^ 2 : ℝ) : ℂ) *
      (⟨(x : ℝ), (P.epsilonNorm : ℝ) * P.complexAlpha.im⟩ : ℂ) = P.complexAlpha * z ^ 4 := by
    exact P.signed_representation_complex hn hrep
  have hν : (P.epsilonNorm : ℝ) = 1 ∨ (P.epsilonNorm : ℝ) = -1 := by
    rcases P.pell_iff_epsilonNorm.mp hp with hh | hh <;> simp [hh]
  have hτ' : (τ : ℝ) = 1 ∨ (τ : ℝ) = -1 := by rcases hτ with rfl | rfl <;> simp
  have hr := complex_representation_residual (P.complexAlpha_ne_zero hn) hz
    (P.negativeNormRoot_pos hn) hfp hν hτ' he
  have hres : ‖P.gapOmega - (z / star z) ^ 4‖ * (v : ℝ) ^ 2 = 2 * P.gapScale := by
    have ha0 := norm_ne_zero_iff.mpr (P.complexAlpha_ne_zero hn)
    apply mul_left_cancel₀ (pow_ne_zero 2 hf')
    apply mul_left_cancel₀ ha0
    calc
      _ = ‖P.gapOmega - (z / star z) ^ 4‖ * ‖P.complexAlpha‖ * (‖z‖ ^ 4 * (P.b : ℝ) ^ 2) := by
        rw [hfour]; ring
      _ = (‖star P.complexAlpha / P.complexAlpha - (z / star z) ^ 4‖ *
          (‖P.complexAlpha‖ * ‖z‖ ^ 4)) * (P.b : ℝ) ^ 2 := by dsimp [gapOmega]; ring
      _ = (2 * (f : ℝ) ^ 2 * P.complexAlpha.im) * (P.b : ℝ) ^ 2 := by rw [hr]
      _ = _ := by
        change (2 * (f : ℝ) ^ 2 * P.negativeNormRoot) * (P.b : ℝ) ^ 2 = _
        dsimp only [gapScale]
        field_simp [ha0]
  exact ⟨{
    r := r
    s := s
    y := (v : ℝ) ^ 2
    f := (f : ℝ)
    y_pos := sq_pos_of_pos hv'
    f_pos := hfp
    point_ne := hz
    norm_four := hfour
    residual := hres
    imaginary_identity := gap_representation_imaginary (P.complexAlpha_ne_zero hn)
      (P.negativeNormRoot_pos hn) hν hτ' he }, rfl, rfl, rfl, rfl⟩

end Parameters
end «JNT-2024»
