module

public import «JNT-2024».ApproximationCriterion
public import «JNT-2024».Section4Approximation
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

/-- All three comparisons in (4.16), from minimality of the actual cutoff. -/
theorem cutoff_printed_chain {E Q ℓ c : ℝ} (hE : 1 < E) (hQ : 190 < Q)
    (hℓ : 0 < ℓ) (hc : 0 < c) (z : ℂ)
    (hr : 1 < Approximation.firstIndex (Q := Q) (ℓ := ℓ) hE hc z) :
    let r := Approximation.firstIndex (Q := Q) (ℓ := ℓ) hE hc z
    c*(Q-1)/(ℓ*(Q-1/E))*E^(r-1) ≤ ‖z‖ ∧
    c*(Q-1)/(ℓ*Q)*E^(r-1) < c*(Q-1)/(ℓ*(Q-1/E))*E^(r-1) ∧
    (994/1000 : ℝ)*c/ℓ*E^(r-1) < c*(Q-1)/(ℓ*Q)*E^(r-1) := by
  let r := Approximation.firstIndex (Q := Q) (ℓ := ℓ) hE hc z
  have hEp : 0 < E := by linarith
  have hQp : 0 < Q := by linarith
  have hinv : 0 < 1/E := one_div_pos.mpr hEp
  have hinv1 : 1/E < 1 := (div_lt_one hEp).mpr hE
  have hden : 0 < Q-1/E := by linarith
  have hqm : 0 < Q-1 := by linarith
  have hnot : ¬ Approximation.Cutoff E Q ℓ c z (r-1) := by
    intro hh
    have hm := Approximation.firstIndex_le hE hc z (show 0 < r-1 by dsimp [r]; omega) hh
    change r ≤ r-1 at hm
    dsimp [r] at hm
    omega
  have hb : c*E^(r-1) ≤ (Q-1/E)*ℓ*‖z‖/(Q-1) := le_of_not_gt hnot
  have hb' := (le_div_iff₀ hqm).mp hb
  refine ⟨?_,?_,?_⟩
  · have he : c*(Q-1)/(ℓ*(Q-1/E))*E^(r-1) = c*(Q-1)*E^(r-1)/(ℓ*(Q-1/E)) := by ring
    rw [he]
    apply (div_le_iff₀ (mul_pos hℓ hden)).mpr
    nlinarith only [hb']
  · apply mul_lt_mul_of_pos_right _ (pow_pos hEp (r-1))
    exact div_lt_div_of_pos_left (mul_pos hc hqm) (mul_pos hℓ hden)
      (mul_lt_mul_of_pos_left (by linarith : Q-1/E < Q) hℓ)
  · have hh : (994/1000 : ℝ)*Q < Q-1 := by linarith
    apply mul_lt_mul_of_pos_right _ (pow_pos hEp (r-1))
    apply (div_lt_div_iff₀ hℓ (mul_pos hℓ hQp)).mpr
    have hm := mul_lt_mul_of_pos_right (mul_lt_mul_of_pos_left hh hc) hℓ
    nlinarith only [hm]

/-- Substituting (4.5), (4.8), then (4.3) into the cutoff bound gives the
literal 1.564 coefficient preceding (4.17). L denotes sqrt(d)*y_k. -/
theorem cutoff_coordinate_lower {E Q ℓ c N L X : ℝ} (hE : 1 < E) (hQ : 190 < Q)
    (hℓ : 0 < ℓ) (hc : 0 < c) (hN : 0 < N) (hL : 0 < L)
    (hX : (9682/10000 : ℝ)*L < |X|)
    (hell : ℓ < (615/1000 : ℝ)*Real.sqrt N/|X|)
    {A : ℝ} (hA : 0 < A) (hAE : A < E) (z : ℂ)
    (hr : 1 < Approximation.firstIndex (Q := Q) (ℓ := ℓ) hE hc z) :
    let r := Approximation.firstIndex (Q := Q) (ℓ := ℓ) hE hc z
    (1564/1000 : ℝ)*c*L/Real.sqrt N*A^(r-1) < ‖z‖ := by
  let r := Approximation.firstIndex (Q := Q) (ℓ := ℓ) hE hc z
  have hs := Real.sqrt_pos.mpr hN
  have hXp : 0 < |X| := (mul_pos (by norm_num) hL).trans hX
  have he := (lt_div_iff₀ hXp).mp hell
  have hm := mul_lt_mul_of_pos_left hX hℓ
  have hnum : (1564/1000 : ℝ)*L*ℓ < (994/1000 : ℝ)*Real.sqrt N := by
    nlinarith only [he,hm,hs]
  have hconst : (1564/1000 : ℝ)*c*L/Real.sqrt N < (994/1000 : ℝ)*c/ℓ := by
    apply (div_lt_div_iff₀ hs hℓ).mpr
    have hh := mul_lt_mul_of_pos_right hnum hc
    nlinarith only [hh]
  have hpow := pow_le_pow_left₀ hA.le hAE.le (r-1)
  have h1 := mul_lt_mul_of_pos_right hconst (pow_pos hA (r-1))
  have h2 := mul_le_mul_of_nonneg_left hpow (by positivity : 0 ≤ (994/1000 : ℝ)*c/ℓ)
  have h3 := cutoff_norm_lower hE hQ hℓ hc z hr
  have heq : (994/1000 : ℝ)*c/ℓ*E^(r-1)=(994/1000 : ℝ)*c*E^(r-1)/ℓ := by ring
  exact (h1.trans_le h2).trans (by simpa only [heq] using h3)

/-- Reindexing the preceding power and rounding 1.564/0.1832 down to 8.537,
exactly as in the passage to (4.17). -/
theorem cutoff_factor_8537 {N d y M c : ℝ} {r : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hy : 0 < y) (hM : 0 < M) (hc : 0 < c) (hr : 1 ≤ r) :
    let A := (1832/10000 : ℝ)*M*Real.sqrt d*y/N
    (8537/1000 : ℝ)*c*Real.sqrt N/M*A^r <
      (1564/1000 : ℝ)*c*Real.sqrt d*y/Real.sqrt N*A^(r-1) := by
  let A := (1832/10000 : ℝ)*M*Real.sqrt d*y/N
  have hsN := Real.sq_sqrt hN.le
  have hNp := Real.sqrt_pos.mpr hN
  have hAp : 0 < A := by dsimp [A]; positivity
  have he : (8537/1000 : ℝ)*c*Real.sqrt N/M*A =
      ((8537/1000 : ℝ)*(1832/10000))*c*Real.sqrt d*y/Real.sqrt N := by
    dsimp [A]
    field_simp
    exact hsN
  have hrw : r=(r-1)+1 := by omega
  change (8537/1000 : ℝ)*c*Real.sqrt N/M*A^r <
    (1564/1000 : ℝ)*c*Real.sqrt d*y/Real.sqrt N*A^(r-1)
  conv_lhs => rw [hrw,pow_succ]
  have hround : (8537/1000 : ℝ)*(1832/10000) < 1564/1000 := by norm_num
  have hh := mul_lt_mul_of_pos_right hround
    (by positivity : 0 < c*Real.sqrt d*y/Real.sqrt N)
  have hh' := mul_lt_mul_of_pos_right hh (pow_pos hAp (r-1))
  change (8537/1000 : ℝ)*c*Real.sqrt N/M*(A^(r-1)*A) < _
  calc
    _ = ((8537/1000 : ℝ)*c*Real.sqrt N/M*A)*A^(r-1) := by ring
    _ = (((8537/1000 : ℝ)*(1832/10000))*c*Real.sqrt d*y/Real.sqrt N)*A^(r-1) := by rw [he]
    _ < _ := by convert hh' using 1 <;> ring

/-- Equation (4.17), obtained by taking fourth powers and cancelling the
comparison norm from (4.9). F retains f_k*f_l until the printed specialisation. -/
theorem cutoff_equation417 {N d y z F M c t : ℝ} {r : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hy : 0 < y) (hF : 0 < F) (hM : 0 < M)
    (hc : 0 < c) (hr : 1 ≤ r) (hnorm : t^4=F^2*y*z)
    (hl : (1564/1000 : ℝ)*c*Real.sqrt d*y/Real.sqrt N*
      ((1832/10000 : ℝ)*M*Real.sqrt d*y/N)^(r-1) < t) :
    ((8537/1000 : ℝ)/M)^4*(N/F)^2*c^4*((1832/10000 : ℝ)*M/N)^(4*r)*
      d^(2*r)*y^(4*r-1) < z := by
  have hb := (cutoff_factor_8537 hN hd hy hM hc hr).trans hl
  have hp := pow_lt_pow_left₀ hb (by positivity) (by decide : 4 ≠ 0)
  rw [hnorm] at hp
  have hsN : Real.sqrt N^4=N^2 := by
    rw [show (4 : ℕ)=2*2 from rfl,pow_mul,Real.sq_sqrt hN.le]
  have hsd : Real.sqrt d^(4*r)=d^(2*r) := by
    rw [show 4*r=2*(2*r) by omega,pow_mul,Real.sq_sqrt hd.le]
  have he :
      (((8537/1000 : ℝ)/M)^4*(N/F)^2*c^4*((1832/10000 : ℝ)*M/N)^(4*r)*
        d^(2*r)*y^(4*r-1))*(F^2*y) =
      ((8537/1000 : ℝ)*c*Real.sqrt N/M*
        ((1832/10000 : ℝ)*M*Real.sqrt d*y/N)^r)^4 := by
    rw [pow_sub₀ y (ne_of_gt hy) (by omega : 1 ≤ 4*r)]
    simp only [mul_pow,div_pow,← pow_mul,pow_one,hsN]
    rw [Nat.mul_comm r 4,hsd]
    field_simp
  apply (mul_lt_mul_iff_right₀ (mul_pos (sq_pos_of_pos hF) hy)).mp
  convert hp using 1
  · simpa only [mul_comm] using he

/-- (4.17) directly from the minimal cutoff, coordinate bounds and (4.9). -/
theorem cutoff_equation417_application {E Q ℓ c N d y z F M X : ℝ}
    (hE : 1 < E) (hQ : 190 < Q) (hℓ : 0 < ℓ) (hc : 0 < c)
    (hN : 0 < N) (hd : 0 < d) (hy : 0 < y) (hF : 0 < F) (hM : 0 < M)
    (hX : (9682/10000 : ℝ)* (Real.sqrt d*y) < |X|)
    (hell : ℓ < (615/1000 : ℝ)*Real.sqrt N/|X|)
    (hAE : (1832/10000 : ℝ)*M*Real.sqrt d*y/N < E) (q : ℂ)
    (hnorm : ‖q‖^4=F^2*y*z)
    (hr : 1 < Approximation.firstIndex (Q := Q) (ℓ := ℓ) hE hc q) :
    let r := Approximation.firstIndex (Q := Q) (ℓ := ℓ) hE hc q
    ((8537/1000 : ℝ)/M)^4*(N/F)^2*c^4*((1832/10000 : ℝ)*M/N)^(4*r)*
      d^(2*r)*y^(4*r-1) < z := by
  have hl := cutoff_coordinate_lower hE hQ hℓ hc hN (mul_pos (Real.sqrt_pos.mpr hd) hy)
    hX hell (by positivity : 0 < (1832/10000 : ℝ)*M*Real.sqrt d*y/N) hAE q hr
  apply cutoff_equation417 hN hd hy hF hM hc (by omega) hnorm
  convert hl using 1
  ring

end «JNT-2024».Section4
