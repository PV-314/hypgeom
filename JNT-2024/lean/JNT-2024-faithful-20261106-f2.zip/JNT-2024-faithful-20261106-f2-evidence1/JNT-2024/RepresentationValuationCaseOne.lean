module

public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».RepresentationValuationCases
public import «JNT-2024».RepresentationValuationChains
public import «JNT-2024».RepresentationValuationLowerBounds
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section
namespace «JNT-2024».Parameters

/-- Norm and square-part equalities in printed case (1-a). The strict
hypothesis is the printed comparison with its denominator cleared. -/
theorem lemma32_case1a_norm (P : Parameters) (p : ℕ) [Fact p.Prime]
    (ha : P.a ≠ 0) (hb : P.b ≠ 0) (hd : P.d ≠ 0) (hN : P.normAlpha ≠ 0)
    (hlt : 2 * padicValInt p P.a < 4 * padicValInt p P.b + padicValInt p P.d) :
    padicValInt p P.normAlpha = 2 * padicValInt p P.a ∧
    padicValInt p (squareFactor P.normAlpha) = padicValInt p P.a ∧
    padicValInt p (P.normAlpha / squarefreePart P.normAlpha) = 2 * padicValInt p P.a := by
  have hv : padicValInt p (P.a ^ 2) < padicValInt p (P.d * P.b ^ 4) := by
    rw [padicValInt.mul hd (pow_ne_zero _ hb), valuation_int_pow, valuation_int_pow]
    omega
  have he : emultiplicity (p : ℤ) (P.a ^ 2) < emultiplicity (p : ℤ) (P.d * P.b ^ 4) := by
    rw [emultiplicity_eq_padicValInt p (pow_ne_zero _ ha),
      emultiplicity_eq_padicValInt p (mul_ne_zero hd (pow_ne_zero _ hb))]
    exact_mod_cast hv
  have hn := emultiplicity_sub_of_gt he
  have hid : P.d * P.b ^ 4 - P.a ^ 2 = -P.normAlpha := by unfold normAlpha; ring
  rw [hid, emultiplicity_neg, emultiplicity_eq_padicValInt p hN,
    emultiplicity_eq_padicValInt p (pow_ne_zero _ ha)] at hn
  have hn' : padicValInt p P.normAlpha = 2 * padicValInt p P.a := by
    rw [valuation_int_pow] at hn
    exact_mod_cast hn
  have hs := valuation_squarePart p hN
  have hf := valuation_squarefree_le_one p (squarefreePart_squarefree P.normAlpha)
  have hpart : padicValInt p (squareFactor P.normAlpha) = padicValInt p P.a := by omega
  refine ⟨hn', hpart, ?_⟩
  rw [div_squarefreePart, valuation_int_pow, hpart]

/-- Norm and square-part inequalities in printed case (1-b). -/
theorem lemma32_case1b_norm (P : Parameters) (p : ℕ) [Fact p.Prime]
    (ha : P.a ≠ 0) (hb : P.b ≠ 0) (hd : P.d ≠ 0) (hN : P.normAlpha ≠ 0)
    (hle : 4 * padicValInt p P.b + padicValInt p P.d ≤ 2 * padicValInt p P.a) :
    4 * padicValInt p P.b ≤ padicValInt p (P.normAlpha / squarefreePart P.normAlpha) ∧
    padicValInt p (P.normAlpha / squarefreePart P.normAlpha) ≤ padicValInt p P.normAlpha := by
  have hh := min_le_emultiplicity_add (p := (p : ℤ))
    (a := P.a ^ 2) (b := -(P.d * P.b ^ 4))
  have hid : P.a ^ 2 + -(P.d * P.b ^ 4) = P.normAlpha := by unfold normAlpha; ring
  rw [hid, emultiplicity_neg, emultiplicity_eq_padicValInt p hN,
    emultiplicity_eq_padicValInt p (pow_ne_zero _ ha),
    emultiplicity_eq_padicValInt p (mul_ne_zero hd (pow_ne_zero _ hb)),
    padicValInt.mul hd (pow_ne_zero _ hb), valuation_int_pow, valuation_int_pow] at hh
  have hmin : ((padicValInt p P.d + 4 * padicValInt p P.b : ℕ) : ℕ∞) ≤
      ((2 * padicValInt p P.a : ℕ) : ℕ∞) := by exact_mod_cast (show padicValInt p P.d + 4 * padicValInt p P.b ≤ 2 * padicValInt p P.a by omega)
  rw [min_eq_right hmin] at hh
  have hn : padicValInt p P.d + 4 * padicValInt p P.b ≤ padicValInt p P.normAlpha := by exact_mod_cast hh
  have hs := valuation_squarePart p hN
  have hf := valuation_squarefree_le_one p (squarefreePart_squarefree P.normAlpha)
  rw [div_squarefreePart, valuation_int_pow]
  constructor <;> omega

/-- The gcd comparison defining printed case (1) implies its two initial
valuation consequences. -/
theorem lemma32_case1_setup (P : Parameters) (p : ℕ) [Fact p.Prime]
    (hp2 : p ≠ 2) {r : ℤ} (hb : P.b ≠ 0) (hr : r ≠ 0)
    (hc : padicValInt p (r ^ 2) ≤ padicValInt p (4 * P.b ^ 2 * r / squarefreePart r)) :
    padicValInt p r ≤ 2 * padicValInt p P.b ∧
    padicValInt p ((normalizationGcd P.b r : ℤ) ^ 2) = 2 * padicValInt p r := by
  have he : 4 * P.b ^ 2 * r / squarefreePart r = (2 * P.b * squareFactor r) ^ 2 := by
    have he' : 4 * P.b ^ 2 * r = (2 * P.b * squareFactor r) ^ 2 * squarefreePart r := by
      nth_rw 1 [← squareFactor_sq_mul r]
      ring
    rw [he', Int.mul_ediv_cancel _ (squarefreePart_ne_zero r)]
  have h2 : padicValInt p (2 : ℤ) = 0 := by
    change padicValNat p 2 = 0
    exact padicValNat_primes hp2
  rw [he, valuation_int_pow, valuation_int_pow,
    padicValInt.mul (mul_ne_zero (by norm_num) hb) (ne_of_gt (squareFactor_pos hr)),
    padicValInt.mul (by norm_num) hb, h2, zero_add] at hc
  have hs := valuation_squarePart p hr
  have hg := normalizationGcd_sq_valuation p hb hr
  rw [h2, zero_add] at hg
  have hf := valuation_squareFactor_eq_half p hr
  constructor <;> omega

/-- In printed case (1), the lower bound on y forces both terms of
`tb² ± 2by` to be divisible by p^k₂, hence v_p(au) ≥ k₂. -/
theorem lemma32_case1_au (P : Parameters) {x y σ : ℤ}
    (h : P.RepresentsSquare x y) (ha : P.a ≠ 0) (hb : P.b ≠ 0) (hy : y ≠ 0)
    (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0) (hσ : σ = 1 ∨ σ = -1)
    (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2)
    (hk : padicValInt p (P.repCandidate y σ) ≤ 2 * padicValInt p P.b) :
    padicValInt p (P.repCandidate y σ) ≤ padicValInt p (P.a * P.u) := by
  have hy' : padicValInt p (P.repCandidate y σ) ≤ 2 * padicValInt p y := by
    have hh := P.lemma32_odd_lower_from_chain h hb hy hu hN hσ p hp2
    omega
  let k := padicValInt p (P.repCandidate y σ)
  have hb2 : (p : ℤ) ^ k ∣ P.b ^ 2 := by
    apply (padicValInt_dvd_iff _ _).mpr
    right
    rw [valuation_int_pow]
    exact hk
  have hby : (p : ℤ) ^ k ∣ P.b * y := by
    apply (padicValInt_dvd_iff _ _).mpr
    right
    rw [padicValInt.mul hb hy]
    dsimp [k]
    omega
  have he : P.a * P.u = P.repCandidate y σ -
      (P.t * P.b ^ 2 + (σ * 2) * (P.b * y)) := by unfold repCandidate; ring
  have hd : (p : ℤ) ^ k ∣ P.a * P.u := by
    rw [he]
    exact dvd_sub (padicValInt_dvd _) (dvd_add (dvd_mul_of_dvd_right hb2 _)
      (dvd_mul_of_dvd_right hby _))
  exact ((padicValInt_dvd_iff _ _).mp hd).resolve_left (mul_ne_zero ha hu)

/-- The concluding valuation comparison in printed case (1-a). -/
theorem lemma32_case1a (P : Parameters) {x y σ : ℤ}
    (h : P.RepresentsSquare x y) (ha : P.a ≠ 0) (hb : P.b ≠ 0) (hd : P.d ≠ 0)
    (hy : y ≠ 0) (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0) (hσ : σ = 1 ∨ σ = -1)
    (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2)
    (hc : padicValInt p (P.repCandidate y σ ^ 2) ≤
      padicValInt p (4 * P.b ^ 2 * P.repCandidate y σ / squarefreePart (P.repCandidate y σ)))
    (hlt : 2 * padicValInt p P.a < 4 * padicValInt p P.b + padicValInt p P.d) :
    padicValInt p ((normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2) ≤
      padicValInt p ((-P.u * squareFactor P.normAlpha) ^ 2) := by
  obtain ⟨hk, hg⟩ := P.lemma32_case1_setup p hp2 hb (P.repCandidate_ne_zero h hu hN hσ) hc
  have hau := P.lemma32_case1_au h ha hb hy hu hN hσ p hp2 hk
  have hn := (P.lemma32_case1a_norm p ha hb hd hN hlt).2.1
  rw [padicValInt.mul ha hu] at hau
  have hneg : padicValInt p (-P.u) = padicValInt p P.u := by simp only [padicValInt, Int.natAbs_neg]
  rw [hg, valuation_int_pow, padicValInt.mul (neg_ne_zero.mpr hu)
    (ne_of_gt (squareFactor_pos hN)), hneg, hn]
  omega

/-- The concluding valuation comparison in printed case (1-b). -/
theorem lemma32_case1b (P : Parameters) {x y σ : ℤ}
    (h : P.RepresentsSquare x y) (ha : P.a ≠ 0) (hb : P.b ≠ 0) (hd : P.d ≠ 0)
    (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0) (hσ : σ = 1 ∨ σ = -1)
    (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2)
    (hc : padicValInt p (P.repCandidate y σ ^ 2) ≤
      padicValInt p (4 * P.b ^ 2 * P.repCandidate y σ / squarefreePart (P.repCandidate y σ)))
    (hle : 4 * padicValInt p P.b + padicValInt p P.d ≤ 2 * padicValInt p P.a) :
    padicValInt p ((normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2) ≤
      padicValInt p ((-P.u * squareFactor P.normAlpha) ^ 2) := by
  obtain ⟨hk, hg⟩ := P.lemma32_case1_setup p hp2 hb (P.repCandidate_ne_zero h hu hN hσ) hc
  have hn := (P.lemma32_case1b_norm p ha hb hd hN hle).1
  rw [div_squarefreePart, valuation_int_pow] at hn
  have hneg : padicValInt p (-P.u) = padicValInt p P.u := by simp only [padicValInt, Int.natAbs_neg]
  rw [hg, valuation_int_pow, padicValInt.mul (neg_ne_zero.mpr hu)
    (ne_of_gt (squareFactor_pos hN)), hneg]
  omega

end «JNT-2024».Parameters
