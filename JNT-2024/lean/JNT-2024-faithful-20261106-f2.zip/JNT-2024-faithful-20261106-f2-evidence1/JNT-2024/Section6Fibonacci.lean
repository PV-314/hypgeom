module

public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Fib.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section6

set_option maxRecDepth 100000

/-- The usual Lucas numbers, with `L₀=2`, `L₁=1`. -/
def lucas (n : ℕ) : ℤ := 2*(Nat.fib (n+1) : ℤ) - Nat.fib n


theorem fibonacci_norm (n : ℕ) :
    (Nat.fib (n+1) : ℤ)^2 - (Nat.fib n : ℤ)*Nat.fib (n+1) - (Nat.fib n : ℤ)^2 = (-1 : ℤ)^n := by
  induction n with
  | zero => norm_num
  | succ n ih =>
    simp only [show n+1+1=n+2 by omega, Nat.fib_add_two, Nat.cast_add, pow_succ]
    nlinarith only [ih]

theorem lucas_fibonacci_norm (n : ℕ) :
    (lucas n)^2 - 5*(Nat.fib n : ℤ)^2 = 4*(-1 : ℤ)^n := by
  have hh := fibonacci_norm n
  unfold lucas
  nlinarith only [hh]

theorem lucas_add_two (n : ℕ) : lucas (n+2) = (Nat.fib n : ℤ)+3*Nat.fib (n+1) := by
  simp only [lucas, show n+2+1=(n+1)+2 by omega, Nat.fib_add_two, Nat.cast_add]
  ring

theorem lucas_strictMono : StrictMono (fun n => lucas (n+2)) := by
  apply strictMono_nat_of_lt_succ
  intro n
  rw [lucas_add_two, lucas_add_two]
  have hh : (0 : ℤ) < Nat.fib (n+1) := by exact_mod_cast (Nat.fib_pos.mpr (by omega : 0 < n+1))
  have hh0 : (0 : ℤ) ≤ Nat.fib n := by positivity
  simp only [show n+1+1=n+2 by omega, Nat.fib_add_two, Nat.cast_add]
  linarith

theorem lucas_add_sixty_mod (n : ℕ) : lucas (n+60) % 100 = lucas n % 100 := by
  have h59 : Nat.fib 59 = 956722026041 := by decide +kernel
  have h60 : Nat.fib 60 = 1548008755920 := by decide +kernel
  have h61 : Nat.fib 61 = 2504730781961 := by decide +kernel
  have hf := Nat.fib_add n 59
  have hg := Nat.fib_add n 60
  norm_num only [h59, h60, h61, Nat.reduceAdd] at hf hg
  have hf' : (Nat.fib (n+60) : ℤ) = (Nat.fib n : ℤ)*956722026041 + (Nat.fib (n+1) : ℤ)*1548008755920 := by
    exact_mod_cast (show Nat.fib (n+60) = _ by simpa only [Nat.add_assoc] using hf)
  have hg' : (Nat.fib (n+61) : ℤ) = (Nat.fib n : ℤ)*1548008755920 + (Nat.fib (n+1) : ℤ)*2504730781961 := by
    exact_mod_cast (show Nat.fib (n+61) = _ by simpa only [Nat.add_assoc] using hg)
  unfold lucas
  rw [show n+60+1=n+61 by omega, hf', hg']
  have he : 2*((Nat.fib n : ℤ)*1548008755920+(Nat.fib (n+1) : ℤ)*2504730781961)-
      ((Nat.fib n : ℤ)*956722026041+(Nat.fib (n+1) : ℤ)*1548008755920) =
      (2*(Nat.fib (n+1) : ℤ)-Nat.fib n) +
        100*(21392954858*(Nat.fib n : ℤ)+34614528080*(Nat.fib (n+1) : ℤ)) := by ring
  rw [he, Int.add_emod, Int.mul_emod 100]
  norm_num

def lucasFamily (j : ℕ) : ℤ := lucas (60*j+11)
def fibonacciFamily (j : ℕ) : ℤ := Nat.fib (60*j+11)

theorem lucasFamily_mod (j : ℕ) : lucasFamily j % 100 = 99 := by
  induction j with
  | zero => decide +kernel
  | succ j ih =>
    unfold lucasFamily at *
    rw [show 60*(j+1)+11=(60*j+11)+60 by omega, lucas_add_sixty_mod, ih]

theorem lucasFamily_strictMono : StrictMono lucasFamily := by
  intro i j hij
  change lucas ((60*i+9)+2) < lucas ((60*j+9)+2)
  exact lucas_strictMono (by omega)

theorem lucasFamily_properties (j : ℕ) :
    199 ≤ lucasFamily j ∧ 89 ≤ fibonacciFamily j ∧
    (lucasFamily j)^2 - 5*(fibonacciFamily j)^2 = -4 ∧ lucasFamily j % 100 = 99 := by
  have hl := lucasFamily_strictMono.monotone (Nat.zero_le j)
  have hf := Nat.fib_mono (show 11 ≤ 60*j+11 by omega)
  have hl0 : lucasFamily 0 = 199 := by decide +kernel
  have hf0 : Nat.fib 11 = 89 := by decide +kernel
  rw [hl0] at hl
  rw [hf0] at hf
  have hn := lucas_fibonacci_norm (60*j+11)
  have ho : Odd (60*j+11) := ⟨30*j+5, by omega⟩
  rw [ho.neg_one_pow] at hn
  exact ⟨hl, by unfold fibonacciFamily; exact_mod_cast hf, by simpa [lucasFamily, fibonacciFamily] using hn, lucasFamily_mod j⟩

end «JNT-2024».Section6
