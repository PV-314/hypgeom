module

public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».RepresentationDivisibility
public import «JNT-2024».RepresentationFactors
public import «JNT-2024».RepresentationNormalization
public import «JNT-2024».RepresentationQuotientsPublished
public import «JNT-2024».RepresentationValuationTwo
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- Every admissible common factor in the normalization on p. 13 divides
the selected positive factor. The square condition is the printed one. -/
theorem normalizationGcd_maximal {b r g : ℤ} (hb : b ≠ 0) (hr : r ≠ 0)
    (hgr : g ∣ r) (hgsq : g ^ 2 ∣ 4 * b ^ 2 * r) :
    g ∣ (normalizationGcd b r : ℤ) := by
  apply Int.dvd_coe_gcd _ hgr
  have hg : g ≠ 0 := ne_zero_of_dvd_ne_zero hr hgr
  have hc : 2 * b * squareFactor r ≠ 0 :=
    mul_ne_zero (mul_ne_zero (by norm_num) hb) (ne_of_gt (squareFactor_pos hr))
  apply int_dvd_of_valuation_le hg hc
  intro p hp
  let : Fact p.Prime := ⟨hp⟩
  have hn : 4 * b ^ 2 * r ≠ 0 := mul_ne_zero (mul_ne_zero (by norm_num) (pow_ne_zero _ hb)) hr
  have hv := ((padicValInt_dvd_iff (p := p) _ _).mp
    ((padicValInt_dvd (p := p) (g ^ 2)).trans hgsq)).resolve_left hn
  have he : 4 * b ^ 2 * r = (2 * b) ^ 2 * r := by ring
  rw [he, padicValInt.mul (pow_ne_zero _ (mul_ne_zero (by norm_num) hb)) hr,
    valuation_int_pow, valuation_int_pow] at hv
  have hs := valuation_squarePart p hr
  have hf := valuation_squarefree_le_one p (squarefreePart_squarefree r)
  rw [padicValInt.mul (mul_ne_zero (by norm_num) hb) (ne_of_gt (squareFactor_pos hr))]
  omega

/-- The nested gcd printed at the foot of p. 13 reduces to `g₁²` once
Lemma 3.2 supplies divisibility of the second coordinate. -/
theorem normalizationGcd_triple {b r s : ℤ}
    (hs : (normalizationGcd b r : ℤ) ∣ s) :
    Int.gcd (Int.gcd (4 * b ^ 2 * r / squarefreePart r) (r ^ 2) : ℤ) (s ^ 2) =
      normalizationGcd b r ^ 2 := by
  rw [← normalizationGcd_sq]
  apply Nat.dvd_antisymm
  · simpa only [Int.natAbs_natCast] using Int.gcd_dvd_natAbs_left ((normalizationGcd b r ^ 2 : ℕ) : ℤ) (s ^ 2)
  · have hh : ((normalizationGcd b r ^ 2 : ℕ) : ℤ) ∣ s ^ 2 := by
      simpa only [Nat.cast_pow] using pow_dvd_pow_of_dvd hs 2
    exact_mod_cast Int.dvd_coe_gcd (dvd_refl ((normalizationGcd b r ^ 2 : ℕ) : ℤ)) hh

/-- The selected factor is admissible and is the largest nonnegative
common factor whose square divides the numerator, exactly as on p. 13. -/
theorem normalizationGcd_greatest {b r s : ℤ} (hb : b ≠ 0) (hr : r ≠ 0)
    (hs : (normalizationGcd b r : ℤ) ∣ s) :
    0 < normalizationGcd b r ∧
    (normalizationGcd b r : ℤ) ∣ r ∧
    (normalizationGcd b r : ℤ) ∣ s ∧
    (normalizationGcd b r : ℤ) ^ 2 ∣ 4 * b ^ 2 * r ∧
    ∀ k : ℕ, (k : ℤ) ∣ r → (k : ℤ) ∣ s →
      (k : ℤ) ^ 2 ∣ 4 * b ^ 2 * r → k ≤ normalizationGcd b r := by
  refine ⟨normalizationGcd_pos b hr, Int.gcd_dvd_right _ _, hs,
    normalizationGcd_sq_dvd b r, ?_⟩
  intro k hkr _hks hksq
  have hk : k ∣ normalizationGcd b r := by
    exact_mod_cast normalizationGcd_maximal hb hr hkr hksq
  exact Nat.le_of_dvd (normalizationGcd_pos b hr) hk

end «JNT-2024»

namespace «JNT-2024».Parameters

/-- The printed quotient proof followed by division by the maximal common
factor; all three resulting parameters are the explicit integer quotients. -/
theorem normalized_representation_from_quotient (P : Parameters)
    [Fact (¬ IsSquare P.d)] [Fact (¬ IsSquare P.normAlpha)]
    {x y σ : ℤ} (h : P.RepresentsSquare x y) (ha : P.a ≠ 0) (hb : P.b ≠ 0)
    (hd : P.d ≠ 0) (hy : y ≠ 0) (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0)
    (hi : IsIntegral ℤ P.epsilon) (hσ : σ = 1 ∨ σ = -1) :
    let g : ℤ := normalizationGcd P.b (P.repCandidate y σ)
    let f := σ * 4 * P.b ^ 2 * P.repCandidate y σ / g ^ 2
    f ≠ 0 ∧ P.FourthPowerRepresentation x y f
      (P.repCandidate y σ / g) (-P.u * squareFactor P.normAlpha / g) := by
  dsimp only
  have hs : σ ^ 2 = 1 := by rcases hσ with rfl | rfl <;> norm_num
  have hs0 : σ ≠ 0 := by rcases hσ with rfl | rfl <;> norm_num
  have hr := P.repCandidate_ne_zero h hu hN hσ
  have hg : (normalizationGcd P.b (P.repCandidate y σ) : ℤ) ≠ 0 := by
    exact_mod_cast ne_of_gt (normalizationGcd_pos P.b hr)
  have hf : σ * 4 * P.b ^ 2 * P.repCandidate y σ ≠ 0 :=
    mul_ne_zero (mul_ne_zero (mul_ne_zero hs0 (by norm_num)) (pow_ne_zero _ hb)) hr
  have hgf : (normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2 ∣
      σ * 4 * P.b ^ 2 * P.repCandidate y σ := by
    convert dvd_mul_of_dvd_right (normalizationGcd_sq_dvd P.b (P.repCandidate y σ)) σ using 1
    ring
  obtain ⟨f, r, s, hf0, heF, heR, heS, hrep⟩ := P.exists_normalized_representation
    (P.unnormalized_representation_from_quotient h hb hd hs) hf hg hgf
    (Int.gcd_dvd_right _ _) (P.candidate_gcd_dvd_coordinate_published h ha hb hd hy hu hN hi hσ)
  have hfq := congrArg (fun z : ℤ => z / (normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2) heF
  have hrq := congrArg (fun z : ℤ => z / (normalizationGcd P.b (P.repCandidate y σ) : ℤ)) heR
  have hsq := congrArg (fun z : ℤ => z / (normalizationGcd P.b (P.repCandidate y σ) : ℤ)) heS
  simp only [Int.mul_ediv_cancel_left _ hg,
    Int.mul_ediv_cancel_left _ (pow_ne_zero 2 hg)] at hfq hrq hsq
  rw [hfq, hrq, hsq]
  exact ⟨hf0, hrep⟩

/-- The same normalization witnesses, with the first identity explicitly
supplied by the restored quotient proof. -/
theorem candidate_representation_from_published_quotient (P : Parameters)
    [Fact (¬ IsSquare P.d)] [Fact (¬ IsSquare P.normAlpha)] {x y σ : ℤ}
    (h : P.RepresentsSquare x y) (ha : P.a ≠ 0) (hb : P.b ≠ 0) (hd : P.d ≠ 0)
    (hy : y ≠ 0) (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0)
    (hi : IsIntegral ℤ P.epsilon) (hσ : σ = 1 ∨ σ = -1) :
    ∃ f r s : ℤ, f ≠ 0 ∧
      σ * 4 * P.b ^ 2 * P.repCandidate y σ =
        (normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2 * f ∧
      P.repCandidate y σ = (normalizationGcd P.b (P.repCandidate y σ) : ℤ) * r ∧
      -P.u * squareFactor P.normAlpha = (normalizationGcd P.b (P.repCandidate y σ) : ℤ) * s ∧
      P.FourthPowerRepresentation x y f r s := by
  have hs : σ ^ 2 = 1 := by rcases hσ with rfl | rfl <;> norm_num
  have hs0 : σ ≠ 0 := by rcases hσ with rfl | rfl <;> norm_num
  have hr := P.repCandidate_ne_zero h hu hN hσ
  have hf : σ * 4 * P.b ^ 2 * P.repCandidate y σ ≠ 0 :=
    mul_ne_zero (mul_ne_zero (mul_ne_zero hs0 (by norm_num)) (pow_ne_zero _ hb)) hr
  have hg : (normalizationGcd P.b (P.repCandidate y σ) : ℤ) ≠ 0 := by
    exact_mod_cast ne_of_gt (normalizationGcd_pos P.b hr)
  have hgf : (normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2 ∣
      σ * 4 * P.b ^ 2 * P.repCandidate y σ := by
    convert dvd_mul_of_dvd_right (normalizationGcd_sq_dvd P.b (P.repCandidate y σ)) σ using 1
    ring
  exact P.exists_normalized_representation (P.unnormalized_representation_from_quotient h hb hd hs)
    hf hg hgf (Int.gcd_dvd_right _ _)
    (P.candidate_gcd_dvd_coordinate_published h ha hb hd hy hu hN hi hσ)

end «JNT-2024».Parameters
