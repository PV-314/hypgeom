module

public import «JNT-2024».NormalizerBounds
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Parameters

/-- The published cutoff, using Lemma 3.12's index-independent squared normalizer. -/
noncomputable def proposition41Threshold (P : Parameters) : ℝ :=
  max 1 (137 * |(P.normAlpha : ℝ)| * Real.sqrt |(P.normAlpha : ℝ)| /
    (Real.sqrt (P.d : ℝ) * P.normalizerSquare))

end Parameters

/-- Exact target for Proposition 4.1. This definition is not a proof or an axiom.
The assertion counts distinct values, not indices. -/
def Proposition41 : Prop :=
  ∀ (P : Parameters) (h : P.Admissible), P.b = 1 → P.normAlpha < 0 →
    IsSquare (-P.normAlpha) → ∀ i j : ℤ,
      IsIntegerSquare (P.y h.pell i) → IsIntegerSquare (P.y h.pell j) →
      P.proposition41Threshold < (P.y h.pell i : ℝ) →
      P.proposition41Threshold < (P.y h.pell j : ℝ) → P.y h.pell i = P.y h.pell j

end «JNT-2024»
