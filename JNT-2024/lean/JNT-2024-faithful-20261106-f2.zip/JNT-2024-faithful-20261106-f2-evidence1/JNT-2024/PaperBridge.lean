module

public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».RealBounds
public import «JNT-2024».Sequence
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

open scoped NumberField

namespace «JNT-2024».Parameters

/-- The literal real quadratic field `ℚ(√d)`. -/
noncomputable def RealField (P : Parameters) := IntermediateField.adjoin ℚ {P.root}

/-- The element `α = a + b²√d` in `ℚ(√d)`. -/
noncomputable def alphaRealField (P : Parameters) : P.RealField :=
  ⟨P.realAlpha, by
    unfold realAlpha
    exact add_mem (intCast_mem _ _) (mul_mem (pow_mem (intCast_mem _ _) _)
      (IntermediateField.subset_adjoin ℚ _ (Set.mem_singleton _)))⟩

/-- The element `ε = (t + u√d)/2` in `ℚ(√d)`. -/
noncomputable def epsilonRealField (P : Parameters) : P.RealField :=
  ⟨P.realEpsilon, by
    unfold realEpsilon
    exact div_mem (add_mem (intCast_mem _ _) (mul_mem (intCast_mem _ _)
      (IntermediateField.subset_adjoin ℚ _ (Set.mem_singleton _)))) (ofNat_mem _ _)⟩

/-- The paper's unit condition in the full ring of integers of the literal real field. -/
def IsRealIntegerUnit (P : Parameters) : Prop :=
  ∃ e : 𝓞 P.RealField, (e : P.RealField) = P.epsilonRealField ∧ IsUnit e

section Equivalence

variable (P : Parameters) [Fact (¬ IsSquare P.d)]

/-- Evaluation at the positive square root is an injective field embedding. -/
noncomputable def realEmbedding (hd : 0 < P.d) : P.Algebra →ₐ[ℚ] ℝ where
  __ := P.evalAt P.root (Real.sq_sqrt (by exact_mod_cast (le_of_lt hd)))
  commutes' q := RingHom.map_rat_algebraMap _ q

theorem realEmbedding_injective (hd : 0 < P.d) : Function.Injective (P.realEmbedding hd) :=
  (P.realEmbedding hd).injective

theorem realEmbedding_range (hd : 0 < P.d) :
    (P.realEmbedding hd).fieldRange = IntermediateField.adjoin ℚ {P.root} := by
  apply le_antisymm
  · rintro r ⟨z, rfl⟩
    change (z.re : ℝ) + z.im * P.root ∈ IntermediateField.adjoin ℚ {P.root}
    exact add_mem ((IntermediateField.adjoin ℚ {P.root}).algebraMap_mem z.re)
      (mul_mem ((IntermediateField.adjoin ℚ {P.root}).algebraMap_mem z.im)
        (IntermediateField.subset_adjoin ℚ _ (Set.mem_singleton _)))
  · apply IntermediateField.adjoin_le_iff.mpr
    rintro r (rfl : r = P.root)
    exact ⟨QuadraticAlgebra.omega, by simp [realEmbedding, evalAt]⟩

/-- An explicit isomorphism from rational coordinates to `ℚ(√d) ⊆ ℝ`. -/
noncomputable def realFieldEquiv (hd : 0 < P.d) : P.Algebra ≃ₐ[ℚ] P.RealField :=
  (P.realEmbedding hd).equivFieldRange.trans
    (IntermediateField.equivOfEq (P.realEmbedding_range hd))

@[simp] theorem realFieldEquiv_coe (hd : 0 < P.d) (z : P.Algebra) :
    ((P.realFieldEquiv hd z : P.RealField) : ℝ) = (z.re : ℝ) + z.im * P.root := rfl


@[simp] theorem realFieldEquiv_alpha (hd : 0 < P.d) :
    P.realFieldEquiv hd P.alpha = P.alphaRealField := by
  apply Subtype.ext
  simp [alphaRealField, realAlpha, alpha]

@[simp] theorem realFieldEquiv_epsilon (hd : 0 < P.d) :
    P.realFieldEquiv hd P.epsilon = P.epsilonRealField := by
  apply Subtype.ext
  simp [epsilonRealField, realEpsilon, epsilon]
  ring


/-- The field isomorphism identifies the full rings of integers. -/
noncomputable def integersEquiv (hd : 0 < P.d) : 𝓞 P.Algebra ≃+* 𝓞 P.RealField :=
  NumberField.RingOfIntegers.mapRingEquiv (P.realFieldEquiv hd).toRingEquiv


theorem integerUnit_iff_realIntegerUnit (hd : 0 < P.d) :
    P.IsIntegerUnit ↔ P.IsRealIntegerUnit := by
  constructor
  · rintro ⟨e, he, hu⟩
    refine ⟨P.integersEquiv hd e, ?_, hu.map (P.integersEquiv hd).toRingHom⟩
    change P.realFieldEquiv hd (e : P.Algebra) = P.epsilonRealField
    rw [he, P.realFieldEquiv_epsilon]
  · rintro ⟨e, he, hu⟩
    refine ⟨(P.integersEquiv hd).symm e, ?_, hu.map (P.integersEquiv hd).symm.toRingHom⟩
    change (P.realFieldEquiv hd).symm (e : P.RealField) = P.epsilon
    rw [he, ← P.realFieldEquiv_epsilon hd, AlgEquiv.symm_apply_apply]

/-- The precise equivalence with the unit hypothesis used in the paper. -/
theorem pell_iff_realIntegerUnit (hd : 0 < P.d) : P.Pell ↔ P.IsRealIntegerUnit :=
  P.pell_iff_integerUnit.trans (P.integerUnit_iff_realIntegerUnit hd)


/-- The real equation defining both coordinate sequences, including negative indices. -/
theorem coordinates_real_formula (hd : 0 < P.d) (hp : P.Pell) (k : ℤ) :
    (P.x hp k : ℝ) + P.y hp k * P.root =
      P.realAlpha * P.realEpsilon ^ (2 * k) := by
  have he := congrArg (P.realEmbedding hd) (P.term_eq_field_powers hp k)
  simp only [map_mul, map_zpow₀] at he
  have hr : P.root ^ 2 = (P.d : ℝ) := Real.sq_sqrt (by exact_mod_cast (le_of_lt hd))
  have ha : P.realEmbedding hd P.alpha = P.realAlpha := P.evalAt_alpha P.root hr
  have hu : P.realEmbedding hd P.epsilon = P.realEpsilon := P.evalAt_epsilon P.root hr
  rw [ha, hu] at he
  exact he

/-- Rational coordinates satisfying the paper's equation are uniquely the existing `x,y`. -/
theorem coordinates_unique (hd : 0 < P.d) (hp : P.Pell) (k : ℤ) (x y : ℚ)
    (he : (x : ℝ) + y * P.root = P.realAlpha * P.realEpsilon ^ (2 * k)) :
    x = P.x hp k ∧ y = P.y hp k := by
  have hh : P.realEmbedding hd (⟨x, y⟩ : P.Algebra) = P.realEmbedding hd (P.term hp k) :=
    he.trans (P.coordinates_real_formula hd hp k).symm
  have hz := P.realEmbedding_injective hd hh
  exact ⟨congrArg QuadraticAlgebra.re hz, congrArg QuadraticAlgebra.im hz⟩

end Equivalence

/-- Section 1.2's assumptions, using the ring of integers instead of a Pell equation. -/
structure PaperAdmissible (P : Parameters) : Prop where
  a_pos : 0 < P.a
  b_pos : 0 < P.b
  d_pos : 0 < P.d
  t_pos : 0 < P.t
  u_pos : 0 < P.u
  d_not_square : ¬ IsSquare P.d
  integer_unit : P.IsRealIntegerUnit

theorem PaperAdmissible.toAdmissible {P : Parameters} (h : P.PaperAdmissible) : P.Admissible := by
  let : Fact (¬ IsSquare P.d) := ⟨h.d_not_square⟩
  exact ⟨h.a_pos, h.b_pos, h.d_pos, h.t_pos, h.u_pos, h.d_not_square,
    (P.pell_iff_realIntegerUnit h.d_pos).mpr h.integer_unit⟩

theorem Admissible.toPaper {P : Parameters} (h : P.Admissible) : P.PaperAdmissible := by
  let : Fact (¬ IsSquare P.d) := ⟨h.d_not_square⟩
  exact ⟨h.a_pos, h.b_pos, h.d_pos, h.t_pos, h.u_pos, h.d_not_square,
    (P.pell_iff_realIntegerUnit h.d_pos).mp h.pell⟩

theorem admissible_iff_paper (P : Parameters) : P.Admissible ↔ P.PaperAdmissible :=
  ⟨Admissible.toPaper, PaperAdmissible.toAdmissible⟩

/-- Equation (1.1), with rational coordinate sequences and real integer powers. -/
def PaperSequence (P : Parameters) (X Y : ℤ → ℚ) : Prop :=
  ∀ k : ℤ, (X k : ℝ) + Y k * P.root = P.realAlpha * P.realEpsilon ^ (2 * k)

/-- Any sequence defined by the paper is exactly the sequence already formalised.
Together with `admissible_iff_paper`, this transfers every existing result. -/
theorem paper_sequence_iff (P : Parameters) (h : P.PaperAdmissible) (X Y : ℤ → ℚ) :
    P.PaperSequence X Y ↔ X = P.x h.toAdmissible.pell ∧ Y = P.y h.toAdmissible.pell := by
  let : Fact (¬ IsSquare P.d) := ⟨h.d_not_square⟩
  constructor
  · intro hs
    constructor
    · funext k
      exact (P.coordinates_unique h.d_pos h.toAdmissible.pell k (X k) (Y k) (hs k)).1
    · funext k
      exact (P.coordinates_unique h.d_pos h.toAdmissible.pell k (X k) (Y k) (hs k)).2
  · rintro ⟨rfl, rfl⟩ k
    exact P.coordinates_real_formula h.d_pos h.toAdmissible.pell k

end «JNT-2024».Parameters
