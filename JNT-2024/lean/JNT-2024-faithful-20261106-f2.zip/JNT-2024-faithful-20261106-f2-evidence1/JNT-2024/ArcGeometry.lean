module

public import «JNT-2024».RemainderArc
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

theorem circlePoint_re (θ : ℝ) : (circlePoint θ).re = Real.cos θ := by
  simp [circlePoint, Complex.exp_re]

theorem circlePoint_im (θ : ℝ) : (circlePoint θ).im = Real.sin θ := by
  simp [circlePoint, Complex.exp_im]

theorem circlePoint_add_neg (θ : ℝ) :
    circlePoint θ + circlePoint (-θ) = (2 * Real.cos θ : ℝ) := by
  apply Complex.ext <;> simp only [Complex.add_re, Complex.add_im, circlePoint_re,
    circlePoint_im, Complex.ofReal_re, Complex.ofReal_im, Real.cos_neg, Real.sin_neg] <;> ring

theorem circlePoint_mul_neg (θ : ℝ) : circlePoint θ * circlePoint (-θ) = 1 := by
  rw [← circlePoint_add, add_neg_cancel, circlePoint_zero]

theorem circlePoint_pow (θ : ℝ) (r : ℕ) : circlePoint θ ^ r = circlePoint (r * θ) := by
  simp only [circlePoint, Complex.ofReal_mul, Complex.ofReal_natCast, ← Complex.exp_nat_mul]
  congr 1
  ring

theorem circlePoint_chord_sq (θ : ℝ) :
    ‖1 - circlePoint θ‖ ^ 2 = 2 * (1 - Real.cos θ) := by
  rw [← Complex.normSq_eq_norm_sq]
  simp only [Complex.normSq_apply, Complex.sub_re, Complex.sub_im, Complex.one_re,
    Complex.one_im, circlePoint_re, circlePoint_im]
  nlinarith [Real.sin_sq_add_cos_sq θ]

theorem circlePoint_product_center (h u : ℝ) :
    (1 - circlePoint (h + u)) * (circlePoint (h + u) - circlePoint (2 * h)) =
      circlePoint (2 * h + u) * ((2 * (Real.cos h - Real.cos u) : ℝ) : ℂ) := by
  have h₁ := circlePoint_add_neg h
  have h₂ := circlePoint_add_neg u
  have h₃ := circlePoint_mul_neg h
  have h₄ := circlePoint_mul_neg u
  rw [show 2 * h = h + h by ring]
  simp only [circlePoint_add]
  push_cast at *
  linear_combination (circlePoint h ^ 2 * circlePoint u) * h₁ -
    (circlePoint h ^ 2 * circlePoint u) * h₂ - circlePoint h * circlePoint u * h₃ +
    circlePoint h ^ 2 * h₄

noncomputable def arcWeight (φ t : ℝ) : ℝ :=
  2 * (Real.cos (φ * t - φ / 2) - Real.cos (φ / 2))

theorem arcWeight_product (φ t : ℝ) :
    (1 - circlePoint (φ * t)) * (circlePoint (φ * t) - circlePoint φ) =
      -circlePoint (φ * t + φ / 2) * (arcWeight φ t : ℂ) := by
  have hh := circlePoint_product_center (φ / 2) (φ * t - φ / 2)
  rw [show φ / 2 + (φ * t - φ / 2) = φ * t by ring,
    show 2 * (φ / 2) = φ by ring,
    show φ + (φ * t - φ / 2) = φ * t + φ / 2 by ring] at hh
  rw [hh]
  unfold arcWeight
  push_cast
  ring

theorem arcWeight_nonneg {φ t : ℝ} (hφ : |φ| ≤ Real.pi) (ht : t ∈ Set.Icc 0 1) :
    0 ≤ arcWeight φ t := by
  have hu : |φ * t - φ / 2| ≤ |φ / 2| := by
    rw [show φ * t - φ / 2 = φ * (t - 1 / 2) by ring, abs_mul, abs_div]
    norm_num
    have hh : |t - 1 / 2| ≤ 1 / 2 := abs_le.mpr ⟨by linarith [ht.1], by linarith [ht.2]⟩
    nlinarith [abs_nonneg φ, abs_nonneg (t - 1 / 2)]
  have hc := Real.cos_le_cos_of_nonneg_of_le_pi (abs_nonneg (φ * t - φ / 2))
    (show |φ / 2| ≤ Real.pi by rw [abs_div]; norm_num; linarith [Real.pi_pos]) hu
  simpa only [arcWeight, Real.cos_abs] using
    mul_nonneg (by norm_num : (0 : ℝ) ≤ 2) (sub_nonneg.mpr hc)

theorem arcWeight_le (φ t : ℝ) : arcWeight φ t ≤ ‖1 - circlePoint (φ / 2)‖ ^ 2 := by
  rw [circlePoint_chord_sq]
  unfold arcWeight
  linarith [Real.cos_le_one (φ * t - φ / 2)]

theorem arcWeight_norm_product {φ t : ℝ} (hφ : |φ| ≤ Real.pi)
    (ht : t ∈ Set.Icc 0 1) :
    ‖(1 - circlePoint (φ * t)) * (circlePoint (φ * t) - circlePoint φ)‖ = arcWeight φ t := by
  rw [arcWeight_product, norm_mul, norm_neg, circlePoint_norm, one_mul,
    Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (arcWeight_nonneg hφ ht)]

end Hypergeometric
end «JNT-2024»
