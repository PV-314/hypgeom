module

public import «JNT-2024».Sequence
public import «JNT-2024».UnitPowers
public import «JNT-2024».UnitSequencePublished
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- The integer recurrence underlying the doubled coordinates in (3.32). -/
def integerUnitRecurrence (t ν a b : ℤ) : ℕ → ℤ
  | 0 => a
  | 1 => b
  | n + 2 => t * integerUnitRecurrence t ν a b (n + 1) - ν * integerUnitRecurrence t ν a b n

theorem rational_integral_iff_double_even {x : ℚ} {X : ℤ} (hx : 2 * x = X) :
    (∃ m : ℤ, x = (m : ℚ)) ↔ Even X := by
  constructor
  · rintro ⟨m, rfl⟩
    refine ⟨m, ?_⟩
    have hh : X = 2 * m := by exact_mod_cast hx.symm
    omega
  · rintro ⟨m, hm⟩
    refine ⟨m, ?_⟩
    have hh : (X : ℚ) = m + m := by exact_mod_cast hm
    linarith

theorem rational_integral_of_even_double {x : ℚ} {X : ℤ} (hx : 2 * x = X) (he : Even X) :
    ∃ m : ℤ, x = (m : ℚ) := (rational_integral_iff_double_even hx).mpr he

theorem integerUnitRecurrence_even (t ν a b : ℤ) (ha : Even a) (hb : Even b) (n : ℕ) :
    Even (integerUnitRecurrence t ν a b n) := by
  induction n using Nat.twoStepInduction with
  | zero => exact ha
  | one => exact hb
  | more n h₀ h₁ => exact (h₁.mul_left t).sub (h₀.mul_left ν)

theorem integerUnitRecurrence_mod_two_period_three (t ν a b : ℤ)
    (ht : (t : ZMod 2) = 1) (hν : (ν : ZMod 2) = 1) (n : ℕ) :
    (integerUnitRecurrence t ν a b (n + 3) : ZMod 2) = integerUnitRecurrence t ν a b n := by
  change ((t * integerUnitRecurrence t ν a b (n + 2) - ν * integerUnitRecurrence t ν a b (n + 1) : ℤ) : ZMod 2) = _
  rw [integerUnitRecurrence]
  push_cast
  rw [ht, hν]
  have htwo : (2 : ZMod 2) = 0 := by decide
  linear_combination -htwo * (integerUnitRecurrence t ν a b n : ZMod 2)

theorem integerUnitRecurrence_mod_two_period_two (t ν a b : ℤ)
    (ht : (t : ZMod 2) = 0) (hν : (ν : ZMod 2) = 1) (n : ℕ) :
    (integerUnitRecurrence t ν a b (n + 2) : ZMod 2) = integerUnitRecurrence t ν a b n := by
  rw [integerUnitRecurrence]
  push_cast
  rw [ht, hν]
  have htwo : (2 : ZMod 2) = 0 := by decide
  linear_combination -htwo * (integerUnitRecurrence t ν a b n : ZMod 2)

theorem period_three_reduction {F : ℕ → ZMod 2} (hF : ∀ n, F (n + 3) = F n) (n : ℕ) :
    F n = F (n % 3) := by
  induction n using Nat.strong_induction_on with
  | h n ih =>
    by_cases hn : n < 3
    · rw [Nat.mod_eq_of_lt hn]
    · have he : n = (n - 3) + 3 := by omega
      calc
        F n = F (n - 3) := by conv_lhs => rw [he]; rw [hF]
        _ = F ((n - 3) % 3) := ih _ (by omega)
        _ = F (n % 3) := by congr 1; omega

theorem period_two_reduction {F : ℕ → ZMod 2} (hF : ∀ n, F (n + 2) = F n) (n : ℕ) :
    F n = F (n % 2) := by
  induction n using Nat.strong_induction_on with
  | h n ih =>
    by_cases hn : n < 2
    · rw [Nat.mod_eq_of_lt hn]
    · have he : n = (n - 2) + 2 := by omega
      calc
        F n = F (n - 2) := by conv_lhs => rw [he]; rw [hF]
        _ = F ((n - 2) % 2) := ih _ (by omega)
        _ = F (n % 2) := by congr 1; omega

namespace Parameters

theorem unit_norm_integer_sign (P : Parameters) (hp : P.Pell) :
    ∃ ν : ℤ, (ν = 1 ∨ ν = -1) ∧ (ν : ℚ) = P.epsilonNorm ∧ P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν := by
  rcases hp with hp | hp
  · exact ⟨1, Or.inl rfl, by simpa using (P.epsilonNorm_eq_one hp).symm, by simpa using hp⟩
  · exact ⟨-1, Or.inr rfl, by simpa using (P.epsilonNorm_eq_neg_one hp).symm, by simpa using hp⟩

/-- The recurrence proof of half-integrality for the unsquared-unit sequence. -/
theorem unit_doubled_coordinates (P : Parameters) {ν : ℤ} (hν : (ν : ℚ) = P.epsilonNorm)
    (A B : ℤ) (n : ℕ) :
    2 * P.unitX A B n = (integerUnitRecurrence P.t ν (2 * A) (A * P.t + B * P.d * P.u) n : ℚ) ∧
    2 * P.unitY A B n = (integerUnitRecurrence P.t ν (2 * B) (A * P.u + B * P.t) n : ℚ) := by
  induction n using Nat.twoStepInduction with
  | zero => simp [unitX, unitY, integerUnitRecurrence]
  | one =>
    rw [(P.unit_coordinates_one A B).1, (P.unit_coordinates_one A B).2]
    constructor <;> simp [integerUnitRecurrence] <;> ring
  | more n h₀ h₁ =>
    rw [P.unitX_recurrence, P.unitY_recurrence, integerUnitRecurrence, integerUnitRecurrence]
    push_cast
    rw [hν]
    constructor
    · linear_combination (P.t : ℚ) * h₁.1 - P.epsilonNorm * h₀.1
    · linear_combination (P.t : ℚ) * h₁.2 - P.epsilonNorm * h₀.2

/-- The printed initial-value/recurrence test for integrality at every index. -/
theorem unit_integral_of_initial_even (P : Parameters) (hp : P.Pell) (A B : ℤ)
    (hx : Even (A * P.t + B * P.d * P.u)) (hy : Even (A * P.u + B * P.t)) (n : ℕ) :
    (∃ X : ℤ, P.unitX A B n = (X : ℚ)) ∧ (∃ Y : ℤ, P.unitY A B n = (Y : ℚ)) := by
  obtain ⟨ν, _, hν, _⟩ := P.unit_norm_integer_sign hp
  obtain ⟨hX, hY⟩ := P.unit_doubled_coordinates hν A B n
  exact ⟨rational_integral_of_even_double hX (integerUnitRecurrence_even _ _ _ _ (even_two_mul A) hx n),
    rational_integral_of_even_double hY (integerUnitRecurrence_even _ _ _ _ (even_two_mul B) hy n)⟩

end Parameters
end «JNT-2024»

