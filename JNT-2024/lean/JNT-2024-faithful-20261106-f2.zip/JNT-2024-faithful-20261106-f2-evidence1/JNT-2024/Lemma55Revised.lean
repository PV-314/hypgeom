module

public import «JNT-2024».Lemma54Published
public import «JNT-2024».Lemma55PlusPublished
public import «JNT-2024».Lemma55PrimePublished
public import «JNT-2024».Lemma55UnitPublished
public import «JNT-2024».Monotonicity
public import «JNT-2024».NormalizerBounds
public import «JNT-2024».NormalizerFormula
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».Proposition41
public import «JNT-2024».Section5NormalizerRevised
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.Deriv.MeanValue
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Pow.Real
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.LegendreSymbol.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

theorem small_normalizer_square_revised (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hn : P.normAlpha<0) (hNs : IsSquare (-P.normAlpha))
    {k : ℤ} (hk : k=1 ∨ k= -1) (hs : IsIntegerSquare (P.y h.pell k))
    (hy : 1<P.y h.pell k) (hcut : (P.y h.pell k:ℝ) ≤ P.proposition41Threshold) :
    (P.normalizerSquare:ℤ)*P.u^2 ≤ 324 := by
  have hh := P.lemma54_revised h hb hn hNs hk hs hy hcut
  have hp : 0 ≤ (P.u:ℝ)*Real.sqrt (P.normalizerSquare:ℝ) :=
    mul_nonneg (by exact_mod_cast h.u_pos.le) (Real.sqrt_nonneg _)
  have hsq := (sq_le_sq₀ hp (by norm_num : (0:ℝ)≤18)).mpr hh
  rw [mul_pow,Real.sq_sqrt (by positivity)] at hsq
  have hc : (P.normalizerSquare:ℝ)*(P.u:ℝ)^2 ≤ 324 := by nlinarith only [hsq]
  exact_mod_cast hc

/-- Revised Lemma 5.5: the bound 18, the printed parity/modulo-three argument,
the modulo-nine exclusion, and the prime-divisor argument. No old polynomial
exclusion is used, and the norm-minus-one case is included. -/
theorem lemma55_revised (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hn : P.normAlpha<0) (hNs : IsSquare (-P.normAlpha)) (ho : Odd (-P.normAlpha))
    (hK : P.IsNegativeCutoff h.pell (-1))
    {k : ℤ} (hk : k=1 ∨ k= -1) (hs : IsIntegerSquare (P.y h.pell k))
    (hy : 1<P.y h.pell k) (hcut : (P.y h.pell k:ℝ) ≤ P.proposition41Threshold) :
    P.u=2 ∧ P.t^2-P.d*P.u^2= -4 ∧ Int.gcd (P.a^2) P.d=1 := by
  have hbound := P.small_normalizer_square_revised h hb hn hNs hk hs hy hcut
  have hM := (P.lemma55_odd_normalizer h hb hNs ho).2
  have hGpos := P.baseGcd_pos (ne_of_gt h.a_pos)
  have hM4 : (4:ℤ) ≤ P.normalizerSquare := by rw [hM]; exact_mod_cast (by omega : 4 ≤ 4*P.baseGcd)
  have hu9 : P.u ≤ 9 := by
    have hh := mul_le_mul_of_nonneg_right hM4 (sq_nonneg P.u)
    by_contra he
    have hu10 : 10 ≤ P.u := by omega
    nlinarith
  have hadj : P.AdjacentSquare h.pell := by
    rcases hk with rfl | rfl
    · exact Or.inl hs
    · exact Or.inr hs
  have hpar := P.lemma54_published h hb hn hNs ho hK hadj
  have hminus : P.t^2-P.d*P.u^2= -4 := by
    rcases h.pell with hp | hp
    · have hu4 := (hpar.1 hp).2
      have hu : P.u=4 ∨ P.u=8 := by have := h.u_pos; omega
      obtain ⟨n,hns⟩ := hNs
      have hn2 : -P.normAlpha=n^2 := by simpa only [pow_two] using hns
      have h3 : P.u%3 ≠ 0 := by rcases hu with he | he <;> simp [he]
      have hg9 := (P.lemma55_plus_divisibility h.pell hb hn2 hp h3 hadj).2.2.2.2
      have hg : 9 ≤ P.baseGcd := Nat.le_of_dvd hGpos hg9
      have hM36 : (36:ℤ) ≤ P.normalizerSquare := by rw [hM]; exact_mod_cast (by omega : 36 ≤ 4*P.baseGcd)
      have hm := mul_le_mul_of_nonneg_right hM36 (sq_nonneg P.u)
      rcases hu with hu | hu <;> rw [hu] at hbound hm <;> norm_num at hbound hm <;> omega
    · exact hp
  have hu2 : P.u=2 := by
    have hp := hpar.2 hminus
    have hu6 := P.lemma55_u6_impossible hminus
    have := h.u_pos
    omega
  refine ⟨hu2,hminus,?_⟩
  have hg1 : P.baseGcd=1 := by
    by_contra he
    obtain ⟨_,p,_,_,_,_,_,_,hg25⟩ := P.lemma55_gcd_prime_bounds h hb hNs ho hminus he
    have hM100 : (100:ℤ) ≤ P.normalizerSquare := by rw [hM]; exact_mod_cast (by omega : 100 ≤ 4*P.baseGcd)
    rw [hu2] at hbound
    norm_num at hbound
    omega
  simpa [baseGcd,hb] using hg1

end «JNT-2024».Parameters
