module

public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

/-- Section 4.6's pairs, indexed by `a` and the positive square root of `−Nα`.
This enumerates equations only; it does not assert completeness of their solutions. -/
def smallPairs : Finset (ℕ × ℕ) :=
  ((Finset.range 11).product (Finset.range 11)).filter fun p =>
    0 < p.1 ∧ 2 ≤ p.2 ∧ p.1 ^ 2 + p.2 ^ 2 ≤ 111 ∧ ¬ IsSquare (p.1 ^ 2 + p.2 ^ 2)

set_option maxRecDepth 10000 in
set_option maxHeartbeats 0 in
theorem smallPairs_card : smallPairs.card = 63 := by decide +kernel

/-- Every pair in the stated finite range occurs in the certified enumeration. -/
theorem mem_smallPairs_iff (a n : ℕ) :
    (a, n) ∈ smallPairs ↔ 0 < a ∧ 2 ≤ n ∧ a ^ 2 + n ^ 2 ≤ 111 ∧ ¬ IsSquare (a ^ 2 + n ^ 2) := by
  constructor
  · intro h
    exact (Finset.mem_filter.mp h).2
  · intro h
    have ha : a < 11 := by nlinarith [sq_nonneg (a : ℤ)]
    have hn : n < 11 := by nlinarith [sq_nonneg (n : ℤ)]
    exact Finset.mem_filter.mpr ⟨Finset.mem_product.mpr ⟨Finset.mem_range.mpr ha, Finset.mem_range.mpr hn⟩, h⟩

end «JNT-2024».Section4
