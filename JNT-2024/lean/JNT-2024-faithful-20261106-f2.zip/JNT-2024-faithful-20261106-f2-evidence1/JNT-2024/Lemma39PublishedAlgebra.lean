module

public import «JNT-2024».ArgumentBounds
public import «JNT-2024».ComplexRepresentation
public import «JNT-2024».GapLattice
public import «JNT-2024».GapNormalization
public import «JNT-2024».GapPrinciple
public import «JNT-2024».GapRepresentationBounds
public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».RepresentationGaussian
public import «JNT-2024».Sequence
public import «JNT-2024».SequenceRepresentations
public import «JNT-2024».SquarefreePart
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- The literal subtraction preceding (3.29), before division by the signed coefficient. -/
theorem representation_cross_difference {α z w U : ℂ} {c : ℝ}
    (hU : (c : ℂ) * U = α * z ^ 4) :
    (c : ℂ) * (U * (star z * w) ^ 4 - star U * (z * star w) ^ 4) =
      (‖z‖ ^ 8 : ℂ) * (α * w ^ 4 - star α * (star w) ^ 4) := by
  have hc := congrArg (starRingEnd ℂ) hU
  simp only [map_mul, map_pow, Complex.conj_ofReal] at hc
  change (c : ℂ) * star U = star α * (star z) ^ 4 at hc
  have hn : (‖z‖ ^ 2 : ℂ) = z * star z := by
    rw [Complex.star_def, Complex.mul_conj, ← Complex.ofReal_pow, Complex.normSq_eq_norm_sq]
  rw [show (‖z‖ ^ 8 : ℂ) = (‖z‖ ^ 2 : ℂ) ^ 4 by ring, hn]
  calc
    _ = ((c : ℂ) * U) * (star z) ^ 4 * w ^ 4 -
        ((c : ℂ) * star U) * z ^ 4 * (star w) ^ 4 := by ring
    _ = _ := by rw [hU, hc]; ring

/-- Equation (3.29), all representation signs, in a division-free real form. -/
theorem representation_cross_difference_norm {α z w U V : ℂ} {f g b y τ σ : ℝ}
    (hf : 0 < f) (_hb : 0 < b) (hτ : τ = 1 ∨ τ = -1) (hσ : σ = 1 ∨ σ = -1)
    (hU : ((τ * f ^ 2 : ℝ) : ℂ) * U = α * z ^ 4)
    (hV : ((σ * g ^ 2 : ℝ) : ℂ) * V = α * w ^ 4)
    (hz : ‖z‖ ^ 4 * b ^ 2 = f ^ 2 * y) :
    ‖U * (star z * w) ^ 4 - star U * (z * star w) ^ 4‖ * b ^ 4 =
      2 * f ^ 2 * g ^ 2 * y ^ 2 * |V.im| := by
  have hc := congrArg (starRingEnd ℂ) hV
  simp only [map_mul, map_pow, Complex.conj_ofReal] at hc
  change ((σ * g ^ 2 : ℝ) : ℂ) * star V = star α * (star w) ^ 4 at hc
  have he := representation_cross_difference (w := w) hU
  rw [← hV, ← hc, ← mul_sub] at he
  have hn := congrArg norm he
  simp only [norm_mul, Complex.norm_real, Real.norm_eq_abs,
    abs_norm, norm_pow] at hn
  have hτa : |τ| = 1 := by rcases hτ with rfl | rfl <;> norm_num
  have hσa : |σ| = 1 := by rcases hσ with rfl | rfl <;> norm_num
  have him : ‖V - star V‖ = 2 * |V.im| := by
    have he : V - star V = Complex.I * (2 * V.im : ℝ) := by
      apply Complex.ext <;> simp; ring
    rw [he, norm_mul, Complex.norm_I, one_mul, Complex.norm_real, Real.norm_eq_abs, abs_mul]
    norm_num
  rw [hτa, hσa, one_mul, one_mul, sq_abs, sq_abs, him] at hn
  have hzn := congrArg (fun t : ℝ => t ^ 2) hz
  have hm := congrArg (fun t : ℝ => t * b ^ 4) hn
  have hpos : f ^ 2 ≠ 0 := ne_of_gt (sq_pos_of_pos hf)
  apply mul_left_cancel₀ hpos
  calc
    _ = (‖z‖ ^ 8 * b ^ 4) * g ^ 2 * (2 * |V.im|) := by nlinarith only [hm]
    _ = (f ^ 4 * y ^ 2) * g ^ 2 * (2 * |V.im|) := by
      congr 2
      nlinarith only [hzn]
    _ = _ := by ring

/-- Dividing the printed difference by the norm of the denominator, as in (3.30). -/
theorem cross_difference_residual {U W : ℂ} (hU : U ≠ 0) (hW : W ≠ 0) :
    ‖U / star U - (star W / W) ^ 4‖ * (‖U‖ * ‖W‖ ^ 4) =
      ‖U * W ^ 4 - star U * (star W) ^ 4‖ := by
  have he : (U / star U - (star W / W) ^ 4) * (star U * W ^ 4) =
      U * W ^ 4 - star U * (star W) ^ 4 := by
    have hs := star_ne_zero.mpr hU
    field_simp
  have hh := congrArg norm he
  simpa only [norm_mul, norm_pow, norm_star] using hh

/-- Exact cancellation in (3.30), retaining the signed subtraction (3.29). -/
theorem representation_cross_residual {α z w U V : ℂ} {f g b y v A n τ σ : ℝ}
    (hf : 0 < f) (hg : 0 < g) (hb : 0 < b) (hy : 0 < y) (hA : 0 < A)
    (hzn : z ≠ 0) (hwn : w ≠ 0) (hτ : τ = 1 ∨ τ = -1) (hσ : σ = 1 ∨ σ = -1)
    (hU : ((τ * f ^ 2 : ℝ) : ℂ) * U = α * z ^ 4)
    (hV : ((σ * g ^ 2 : ℝ) : ℂ) * V = α * w ^ 4)
    (hz : ‖z‖ ^ 4 * b ^ 2 = f ^ 2 * y) (hw : ‖w‖ ^ 4 * b ^ 2 = g ^ 2 * v)
    (hUnorm : ‖U‖ * b ^ 2 = A * y) (hVim : |V.im| = n) :
    ‖U / star U - (star (star z * w) / (star z * w)) ^ 4‖ * v = 2 * b ^ 2 * n / A := by
  have hUn : U ≠ 0 := by intro he; rw [he, norm_zero, zero_mul] at hUnorm; nlinarith
  have hWn : star z * w ≠ 0 := mul_ne_zero (star_ne_zero.mpr hzn) hwn
  have hF := representation_cross_difference_norm hf hb hτ hσ hU hV hz
  rw [hVim] at hF
  have hR := cross_difference_residual hUn hWn
  have hcW : star (star z * w) = z * star w := by simp only [star_mul, star_star]; exact mul_comm _ _
  rw [hcW] at hR
  have hW : ‖star z * w‖ ^ 4 * b ^ 4 = f ^ 2 * g ^ 2 * y * v := by
    calc
      _ = (‖z‖ ^ 4 * b ^ 2) * (‖w‖ ^ 4 * b ^ 2) := by rw [norm_mul, norm_star]; ring
      _ = _ := by rw [hz, hw]; ring
  let R := ‖U / star U - (star (star z * w) / (star z * w)) ^ 4‖
  have hR' : R * (‖U‖ * ‖star z * w‖ ^ 4) =
      ‖U * (star z * w) ^ 4 - star U * (z * star w) ^ 4‖ := by
    dsimp only [R]
    rw [hcW]
    exact hR
  have hraw : R * ‖U‖ * (f ^ 2 * g ^ 2 * y * v) = 2 * f ^ 2 * g ^ 2 * y ^ 2 * n := by
    calc
      _ = (R * (‖U‖ * ‖star z * w‖ ^ 4)) * b ^ 4 := by rw [← hW]; ring
      _ = ‖U * (star z * w) ^ 4 - star U * (z * star w) ^ 4‖ * b ^ 4 := by
        rw [hR']
      _ = _ := hF
  have heq : (f ^ 2 * g ^ 2 * y ^ 2) * (R * v * A) =
      (f ^ 2 * g ^ 2 * y ^ 2) * (2 * b ^ 2 * n) := by
    calc
      _ = R * (A * y) * (f ^ 2 * g ^ 2 * y * v) := by ring
      _ = (R * ‖U‖ * (f ^ 2 * g ^ 2 * y * v)) * b ^ 2 := by rw [← hUnorm]; ring
      _ = _ := by rw [hraw]; ring
  have heq' := mul_left_cancel₀ (show f ^ 2 * g ^ 2 * y ^ 2 ≠ 0 by positivity) heq
  exact (eq_div_iff (ne_of_gt hA)).mpr heq'

namespace Parameters

noncomputable def sequencePoint (P : Parameters) (hp : P.Pell) (k : ℤ) : ℂ :=
  ⟨P.x hp k, (P.epsilonNorm ^ k : ℚ) * P.negativeNormRoot⟩

theorem sequencePoint_norm_scaled (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    {k : ℤ} (hy : 0 < (P.y h.pell k : ℝ)) :
    ‖P.sequencePoint h.pell k‖ * (P.b : ℝ) ^ 2 = ‖P.complexAlpha‖ * (P.y h.pell k : ℝ) := by
  have hid : (P.x h.pell k : ℝ) ^ 2 - P.d * (P.y h.pell k : ℝ) ^ 2 = P.normAlpha := by
    exact_mod_cast P.norm_identity h.pell k
  have hr := P.negativeNormRoot_sq hn
  have hu : ‖P.sequencePoint h.pell k‖ ^ 2 = (P.d : ℝ) * (P.y h.pell k : ℝ) ^ 2 := by
    rw [← Complex.normSq_eq_norm_sq, Complex.normSq_apply]
    rcases P.epsilonNorm_zpow_sign h.pell k with he | he <;>
      simp only [sequencePoint, he, Rat.cast_one, Rat.cast_neg, one_mul, neg_one_mul] <;>
      nlinarith only [hid, hr]
  apply (pow_left_inj₀ (by positivity : 0 ≤ ‖P.sequencePoint h.pell k‖ * (P.b : ℝ) ^ 2)
    (mul_nonneg (norm_nonneg _) hy.le) (by decide : (2 : ℕ) ≠ 0)).mp
  rw [mul_pow, mul_pow, hu, P.complexAlpha_norm_sq hn]
  ring

theorem sequencePoint_im_abs (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) (k : ℤ) :
    |(P.sequencePoint h.pell k).im| = P.negativeNormRoot := by
  rcases P.epsilonNorm_zpow_sign h.pell k with he | he <;>
    simp [sequencePoint, he, abs_of_pos (P.negativeNormRoot_pos hn)]

theorem sequence_gap_complex (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    {k : ℤ} (p : P.SequenceDatum) (hp : P.SequenceGapCertificate h.pell k p) :
    ∃ τ : ℝ, (τ = 1 ∨ τ = -1) ∧
      ((τ * p.f ^ 2 : ℝ) : ℂ) * P.sequencePoint h.pell k = P.complexAlpha * p.point ^ 4 := by
  obtain ⟨_, T, U, x, v, f, τ, _, _, _, _, hpf, hτ, hF, hxy, hνk⟩ := hp
  let Q := P.withUnit T U
  have he := Q.signed_representation_complex hn hF
  change (((τ : ℝ) * (f : ℝ) ^ 2 : ℝ) : ℂ) *
    (⟨(x : ℝ), (Q.epsilonNorm : ℝ) * P.negativeNormRoot⟩ : ℂ) = P.complexAlpha * p.point ^ 4 at he
  have hxR : (P.x h.pell k : ℝ) = (x : ℝ) := by exact_mod_cast hxy
  have hνR : (Q.epsilonNorm : ℝ) = ((P.epsilonNorm ^ k : ℚ) : ℝ) := by exact_mod_cast hνk
  rw [← hpf, ← hxR, hνR] at he
  refine ⟨(τ : ℝ), ?_, he⟩
  rcases hτ with rfl | rfl <;> simp

/-- Equation (3.30) for the actual indexed signed representations. -/
theorem sequence_cross_residual_published (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    {k ℓ : ℤ} (p q : P.SequenceDatum)
    (hp : P.SequenceGapCertificate h.pell k p) (hq : P.SequenceGapCertificate h.pell ℓ q) :
    ‖P.sequenceOmega h.pell k - (star (star p.point * q.point) / (star p.point * q.point)) ^ 4‖ * q.y =
      2 * P.gapScale := by
  obtain ⟨τ, hτ, hU⟩ := P.sequence_gap_complex h hn p hp
  obtain ⟨σ, hσ, hV⟩ := P.sequence_gap_complex h hn q hq
  have hnorm : ‖P.sequencePoint h.pell k‖ * (P.b : ℝ) ^ 2 = ‖P.complexAlpha‖ * p.y := by
    rw [hp.1]
    exact P.sequencePoint_norm_scaled h hn (by rw [← hp.1]; exact p.y_pos)
  have hh := representation_cross_residual p.f_pos q.f_pos (by exact_mod_cast h.b_pos)
    p.y_pos (norm_pos_iff.mpr (P.complexAlpha_ne_zero hn)) p.point_ne q.point_ne
    hτ hσ hU hV p.norm_four q.norm_four hnorm (P.sequencePoint_im_abs h hn ℓ)
  change ‖P.sequenceOmega h.pell k - (star (star p.point * q.point) / (star p.point * q.point)) ^ 4‖ * q.y =
    2 * (P.b : ℝ) ^ 2 * P.negativeNormRoot / ‖P.complexAlpha‖ at hh
  rw [hh, gapScale]
  ring

end Parameters

end «JNT-2024»


