module

public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».Sequence
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- The paper's valuation, including infinity at zero, agrees with the existing
finite-valued valuation on nonzero integers. -/
theorem emultiplicity_eq_padicValInt (p : ℕ) [Fact p.Prime] {z : ℤ}
    (hz : z ≠ 0) : emultiplicity (p : ℤ) z = (padicValInt p z : ℕ∞) := by
  rw [← Int.emultiplicity_natAbs, ← padicValNat_eq_emultiplicity
    (Int.natAbs_ne_zero.mpr hz)]
  rfl

namespace Parameters

/-- The preliminary valuation inequality before both chains in Lemma 3.2.
No nonvanishing condition is imposed on the intermediate sum. -/
theorem lemma32_valuation_au (P : Parameters) (p : ℕ) (y σ : ℤ) :
    min (emultiplicity (p : ℤ) (P.repCandidate y σ))
      (emultiplicity (p : ℤ) (P.t * P.b ^ 2 + σ * 2 * P.b * y)) ≤
      emultiplicity (p : ℤ) (P.a * P.u) := by
  have he : P.a * P.u = P.repCandidate y σ +
      -(P.t * P.b ^ 2 + σ * 2 * P.b * y) := by
    unfold repCandidate
    ring
  rw [he]
  simpa only [emultiplicity_neg] using
    (min_le_emultiplicity_add (p := (p : ℤ))
      (a := P.repCandidate y σ) (b := -(P.t * P.b ^ 2 + σ * 2 * P.b * y)))

/-- The right-hand expression of (3.4), with the integral norm named explicitly. -/
theorem paper_eq34_right (P : Parameters) {x y ν : ℤ}
    (h : P.RepresentsSquare x y) (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν) :
    4 * y ^ 2 = 2 * P.a * P.t * P.u + 4 * P.b ^ 2 * ν +
      2 * P.b ^ 2 * P.d * P.u ^ 2 := by
  have hy := P.representation_y h
  have hn := congrArg (fun z : ℤ => P.b ^ 2 * z) hν
  nlinarith only [hy, hn]

/-- First line of the odd-prime valuation chain on p. 10, valid also when
one of the displayed summands vanishes. -/
theorem lemma32_odd_chain_first (P : Parameters) {x y : ℤ}
    (h : P.RepresentsSquare x y) (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2) :
    min (emultiplicity (p : ℤ) (P.a * P.t * P.u))
      (min (emultiplicity (p : ℤ) (P.b ^ 2 * P.t ^ 2))
        (emultiplicity (p : ℤ) (P.b ^ 2 * P.d * P.u ^ 2))) ≤
      2 * emultiplicity (p : ℤ) y := by
  have hp : Prime (p : ℤ) := Nat.prime_iff_prime_int.mp (Fact.out : p.Prime)
  have h2 : emultiplicity (p : ℤ) (2 : ℤ) = 0 := by
    rw [emultiplicity_eq_padicValInt p (by norm_num)]
    have he : padicValInt p (2 : ℤ) = 0 := by
      change padicValNat p 2 = 0
      exact padicValNat_primes hp2
    simp [he]
  have he : 4 * y ^ 2 = 2 * (P.a * P.t * P.u) +
      (P.b ^ 2 * P.t ^ 2 + P.b ^ 2 * P.d * P.u ^ 2) := by
    have hy := P.representation_y h
    nlinarith only [hy]
  have hh := (min_le_min_left (emultiplicity (p : ℤ) (2 * (P.a * P.t * P.u)))
    (min_le_emultiplicity_add (p := (p : ℤ))
      (a := P.b ^ 2 * P.t ^ 2) (b := P.b ^ 2 * P.d * P.u ^ 2))).trans
    (min_le_emultiplicity_add (p := (p : ℤ))
      (a := 2 * (P.a * P.t * P.u))
      (b := P.b ^ 2 * P.t ^ 2 + P.b ^ 2 * P.d * P.u ^ 2))
  rw [← he] at hh
  have h4 : emultiplicity (p : ℤ) (4 : ℤ) = 0 := by
    have : (4 : ℤ) = 2 * 2 := by norm_num
    rw [this, emultiplicity_mul hp, h2, zero_add]
  simpa only [emultiplicity_mul hp, emultiplicity_pow hp, h2, h4,
    zero_add, Nat.cast_ofNat] using hh

/-- Substitution of the candidate into `atu`, the second line of the odd-prime
chain. Both signs and vanishing intermediate expressions are included. -/
theorem lemma32_odd_chain_second (P : Parameters) (p : ℕ) [Fact p.Prime]
    (y σ : ℤ) :
    let v := emultiplicity (p : ℤ)
    min (min (v (P.t ^ 2 * P.b ^ 2 + σ * 2 * P.b * P.t * y))
      (v (P.repCandidate y σ) + v P.t))
      (min (v (P.b ^ 2 * P.t ^ 2)) (v (P.b ^ 2 * P.d * P.u ^ 2))) ≤
    min (v (P.a * P.t * P.u))
      (min (v (P.b ^ 2 * P.t ^ 2)) (v (P.b ^ 2 * P.d * P.u ^ 2))) := by
  dsimp only
  apply min_le_min_right
  have he : P.a * P.t * P.u =
      -(P.t ^ 2 * P.b ^ 2 + σ * 2 * P.b * P.t * y) +
      P.repCandidate y σ * P.t := by
    unfold repCandidate
    ring
  rw [he]
  have hp : Prime (p : ℤ) := Nat.prime_iff_prime_int.mp (Fact.out : p.Prime)
  simpa only [emultiplicity_neg, emultiplicity_mul hp] using
    (min_le_emultiplicity_add (p := (p : ℤ))
      (a := -(P.t ^ 2 * P.b ^ 2 + σ * 2 * P.b * P.t * y))
      (b := P.repCandidate y σ * P.t))

/-- Third line of the odd-prime chain: separate the two summands, retaining
the already present valuation of `b²t²`. -/
theorem lemma32_odd_chain_third (P : Parameters) (p : ℕ) [Fact p.Prime]
    (hp2 : p ≠ 2) (y σ : ℤ) (hσ : σ = 1 ∨ σ = -1) :
    let v := emultiplicity (p : ℤ)
    min (v (P.b * P.t * y))
      (min (v (P.repCandidate y σ) + v P.t)
        (min (v (P.b ^ 2 * P.t ^ 2)) (v (P.b ^ 2 * P.d * P.u ^ 2)))) ≤
    min (min (v (P.t ^ 2 * P.b ^ 2 + σ * 2 * P.b * P.t * y))
      (v (P.repCandidate y σ) + v P.t))
      (min (v (P.b ^ 2 * P.t ^ 2)) (v (P.b ^ 2 * P.d * P.u ^ 2))) := by
  dsimp only
  have hp : Prime (p : ℤ) := Nat.prime_iff_prime_int.mp (Fact.out : p.Prime)
  have h2 : emultiplicity (p : ℤ) (2 : ℤ) = 0 := by
    rw [emultiplicity_eq_padicValInt p (by norm_num)]
    have he : padicValInt p (2 : ℤ) = 0 := by
      change padicValNat p 2 = 0
      exact padicValNat_primes hp2
    simp [he]
  have hs : emultiplicity (p : ℤ) (σ * 2 * P.b * P.t * y) =
      emultiplicity (p : ℤ) (P.b * P.t * y) := by
    rcases hσ with rfl | rfl
    · have he : (1 : ℤ) * 2 * P.b * P.t * y = 2 * (P.b * P.t * y) := by ring
      rw [he, emultiplicity_mul hp, h2, zero_add]
    · have he : (-1 : ℤ) * 2 * P.b * P.t * y = -(2 * (P.b * P.t * y)) := by ring
      rw [he, emultiplicity_neg, emultiplicity_mul hp, h2, zero_add]
  have hh := min_le_emultiplicity_add (p := (p : ℤ))
    (a := P.t ^ 2 * P.b ^ 2) (b := σ * 2 * P.b * P.t * y)
  rw [hs, mul_comm (P.t ^ 2) (P.b ^ 2)] at hh
  rw [mul_comm (P.t ^ 2) (P.b ^ 2)]
  apply le_min
  · apply le_min
    · apply le_trans _ hh
      apply le_min
      · exact (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _))
      · exact min_le_left _ _
    · exact (min_le_right _ _).trans (min_le_left _ _)
  · exact (min_le_right _ _).trans (min_le_right _ _)

/-- The complete displayed odd-prime chain on p. 10, with its last line
expanded by multiplicativity. The preceding declarations prove its individual steps. -/
theorem lemma32_odd_valuation_chain (P : Parameters) {x y : ℤ}
    (h : P.RepresentsSquare x y) (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2)
    (σ : ℤ) (hσ : σ = 1 ∨ σ = -1) :
    let v := emultiplicity (p : ℤ)
    min (v P.b + v P.t + v y)
      (min (v (P.repCandidate y σ) + v P.t)
        (min (2 * v P.b + 2 * v P.t) (2 * v P.b + v P.d + 2 * v P.u))) ≤
      2 * v y := by
  have hh := (P.lemma32_odd_chain_third p hp2 y σ hσ).trans
    ((P.lemma32_odd_chain_second p y σ).trans (P.lemma32_odd_chain_first h p hp2))
  have hp : Prime (p : ℤ) := Nat.prime_iff_prime_int.mp (Fact.out : p.Prime)
  dsimp only at hh ⊢
  simpa only [emultiplicity_mul hp, emultiplicity_pow hp, Nat.cast_ofNat, add_assoc] using hh

/-- First line of the prime-two chain on p. 11, using the printed right-hand
expression of (3.4). -/
theorem lemma32_two_chain_first (P : Parameters) {x y ν : ℤ}
    (h : P.RepresentsSquare x y) (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν) :
    min (emultiplicity (2 : ℤ) (2 * P.a * P.t * P.u))
      (emultiplicity (2 : ℤ) (P.b ^ 2 * (4 * ν + 2 * P.d * P.u ^ 2))) ≤
      2 * emultiplicity (2 : ℤ) y + 2 := by
  have hp : Prime (2 : ℤ) := Nat.prime_iff_prime_int.mp Nat.prime_two
  have h4 : emultiplicity (2 : ℤ) (4 : ℤ) = 2 := by
    have hh := emultiplicity_eq_padicValInt 2 (z := 4) (by norm_num)
    change emultiplicity (2 : ℤ) (4 : ℤ) = _ at hh
    rw [hh]
    have he : padicValInt 2 (4 : ℤ) = 2 := by
      have hpow : (4 : ℤ) = 2 ^ 2 := by norm_num
      rw [hpow, valuation_int_pow]
      norm_num [padicValInt]
    rw [he]
    rfl
  have he : 4 * y ^ 2 = 2 * P.a * P.t * P.u +
      P.b ^ 2 * (4 * ν + 2 * P.d * P.u ^ 2) := by
    have hy := P.paper_eq34_right h hν
    nlinarith only [hy]
  have hh := min_le_emultiplicity_add (p := (2 : ℤ))
    (a := 2 * P.a * P.t * P.u)
    (b := P.b ^ 2 * (4 * ν + 2 * P.d * P.u ^ 2))
  have hv : emultiplicity (2 : ℤ) (4 * y ^ 2) =
      2 * emultiplicity (2 : ℤ) y + 2 := by
    rw [emultiplicity_mul hp, emultiplicity_pow hp, h4, add_comm]
    rfl
  rwa [← he, hv] at hh

end Parameters
end «JNT-2024»
