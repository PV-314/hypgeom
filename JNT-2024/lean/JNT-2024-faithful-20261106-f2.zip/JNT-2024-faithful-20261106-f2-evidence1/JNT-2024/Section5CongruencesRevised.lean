module

public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section
namespace «JNT-2024».Section5Revised

/-- Elementary residue steps of the revised Lemma 5.6, kept separate from
the preserved larger finite certificates used by the former proof. -/
theorem plus_eight_parity : ∀ a t:ZMod 16,
    t^2=a^2+8 → a.val%2=1 ∧ t.val%2=1 := by decide +kernel

theorem plus_four_divisibility : ∀ a t:ZMod 16,
    t^2=a^2+4 → a.val%4=0 := by decide +kernel

theorem odd_square_sixteen : ∀ u:ZMod 16, u.val%2=1 → u^2=1 ∨ u^2=9 := by decide +kernel

theorem even_square_sixteen : ∀ n:ZMod 16, n.val%2=0 → n^2=0 ∨ n^2=4 := by decide +kernel

theorem square_four_root : ∀ n:ZMod 16, n^2=4 → n.val%4=2 := by decide +kernel

theorem square_zero_root : ∀ n:ZMod 16, n^2=0 → n.val%4=0 := by decide +kernel

theorem minus_nine_impossible : ∀ t:ZMod 9, t^2 ≠ -4 := by decide +kernel

theorem minus_sixteen_impossible : ∀ t:ZMod 16, t^2 ≠ -4 := by decide +kernel

theorem minus_two_bad_norm : ∀ a T:ZMod 16, T^2+1=a^2+4 →
    a.val%2=1 ∧ T.val%4=2 ∧
    ((T+a)^2+4=5 ∨ (T+a)^2+4=13) ∧
    ((T-a)^2+4=5 ∨ (T-a)^2+4=13) := by decide +kernel

theorem minus_two_good_parity : ∀ a T:ZMod 16, T^2+1=a^2 → a.val%2=1 := by decide +kernel

theorem five_thirteen_not_square : ∀ v:ZMod 16, v^2 ≠ 5 ∧ v^2 ≠ 13 := by decide +kernel

theorem minus_one_good_parity : ∀ a t:ZMod 16, t^2=a^2-4 →
    a.val%4=2 ∧ t.val%4=0 := by decide +kernel

theorem minus_one_bad_root : ∀ a t:ZMod 32,
    a.val%4=2 → t.val%4=0 →
    (t+a)^2+16=20 ∧ (t-a)^2+16=20 := by decide +kernel

theorem twenty_not_four_square : ∀ v:ZMod 32, 4*v^2 ≠ 20 := by decide +kernel

theorem square_sixteen_root : ∀ n:ZMod 32, n.val%8=4 → n^2=16 := by decide +kernel

end «JNT-2024».Section5Revised
