module

public import «JNT-2024».Sequence
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

open scoped NumberField

namespace «JNT-2024».Parameters


instance ratNonsquare (d : ℤ) [h : Fact (¬ IsSquare d)] :
    Fact (¬ IsSquare (d : ℚ)) := ⟨fun hs => h.out (Rat.isSquare_intCast_iff.mp hs)⟩

/-- The existing coordinate algebra is a number field when `d` is nonsquare. -/
instance numberField (P : Parameters) [Fact (¬ IsSquare P.d)] : NumberField P.Algebra where
  to_charZero := inferInstance
  to_finiteDimensional := inferInstance


/-- The coordinate norm already used in the project is the actual field norm. -/
theorem algebra_norm_eq (P : Parameters) (z : P.Algebra) :
    Algebra.norm ℚ z = QuadraticAlgebra.norm z :=
  QuadraticAlgebra.det_toLinearMap_eq_norm z

theorem field_norm_epsilon (P : Parameters) : Algebra.norm ℚ P.epsilon = P.epsilonNorm := by
  rw [P.algebra_norm_eq, P.norm_epsilon]


theorem pell_iff_epsilonNorm (P : Parameters) :
    P.Pell ↔ P.epsilonNorm = 1 ∨ P.epsilonNorm = -1 := by
  constructor
  · rintro (h | h)
    · exact Or.inl (P.epsilonNorm_eq_one h)
    · exact Or.inr (P.epsilonNorm_eq_neg_one h)
  · rintro (h | h)
    · exact Or.inl (P.epsilonNorm_eq_one_iff.mp h)
    · right
      have hq : (P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2 = -4 := by
        unfold epsilonNorm at h
        linarith
      exact_mod_cast hq

/-- A monic integral polynomial witnessing the integrality of `ε`. -/
theorem epsilon_isIntegral (P : Parameters) (hp : P.Pell) : IsIntegral ℤ P.epsilon := by
  obtain ⟨n, hn⟩ : ∃ n : ℤ, (n : ℚ) = P.epsilonNorm := by
    rcases P.pell_iff_epsilonNorm.mp hp with h | h
    · exact ⟨1, by simpa using h.symm⟩
    · exact ⟨-1, by simpa using h.symm⟩
  refine ⟨Polynomial.X ^ 2 +
    (Polynomial.C (-P.t) * Polynomial.X + Polynomial.C n), ?_, ?_⟩
  · apply Polynomial.monic_X_pow_add
    apply lt_of_le_of_lt (Polynomial.degree_add_le _ _)
    exact max_lt
      (lt_of_le_of_lt (Polynomial.degree_C_mul_X_le _) (by norm_num))
      (lt_of_le_of_lt Polynomial.degree_C_le (by norm_num))
  · simp only [Polynomial.eval₂_add, Polynomial.eval₂_pow, Polynomial.eval₂_X,
      Polynomial.eval₂_mul, Polynomial.eval₂_C]
    ext <;> simp [epsilon, pow_two, QuadraticAlgebra.re_zero, QuadraticAlgebra.im_zero]
    · unfold epsilonNorm at hn
      nlinarith [hn]
    · ring

section Integers

variable (P : Parameters) [Fact (¬ IsSquare P.d)]

/-- The element `ε` in the full ring of integers, not merely in `ℤ[√d]`. -/
def epsilonInteger (hp : P.Pell) : 𝓞 P.Algebra := ⟨P.epsilon, P.epsilon_isIntegral hp⟩

@[simp] theorem coe_epsilonInteger (hp : P.Pell) :
    (P.epsilonInteger hp : P.Algebra) = P.epsilon := rfl

theorem epsilonInteger_isUnit (hp : P.Pell) : IsUnit (P.epsilonInteger hp) := by
  apply (RingOfIntegers.isUnit_norm ℚ).mp
  rcases P.pell_iff_epsilonNorm.mp hp with h | h
  · have he : RingOfIntegers.norm ℚ (P.epsilonInteger hp) = 1 := by
      apply NumberField.RingOfIntegers.ext
      simpa [P.field_norm_epsilon] using h
    rw [he]
    exact isUnit_one
  · have he : RingOfIntegers.norm ℚ (P.epsilonInteger hp) = -1 := by
      apply NumberField.RingOfIntegers.ext
      simpa [P.field_norm_epsilon] using h
    rw [he]
    exact isUnit_neg_one

/-- The paper's hypothesis that `ε` is a unit of the ring of integers. -/
def IsIntegerUnit : Prop :=
  ∃ e : 𝓞 P.Algebra, (e : P.Algebra) = P.epsilon ∧ IsUnit e

/-- Both directions of the bridge; no positivity or squarefreeness is needed. -/
theorem pell_iff_integerUnit : P.Pell ↔ P.IsIntegerUnit := by
  constructor
  · intro hp
    exact ⟨P.epsilonInteger hp, rfl, P.epsilonInteger_isUnit hp⟩
  · rintro ⟨e, he, hu⟩
    have hn := Algebra.coe_norm_int e
    rw [he, P.field_norm_epsilon] at hn
    apply P.pell_iff_epsilonNorm.mpr
    rcases Int.isUnit_iff.mp (hu.map (Algebra.norm ℤ)) with h | h
    · left
      simpa [h] using hn.symm
    · right
      simpa [h] using hn.symm

/-- An actual unit of the full ring of integers representing `ε`. -/
noncomputable def epsilonIntegerUnit (hp : P.Pell) : (𝓞 P.Algebra)ˣ :=
  (P.epsilonInteger_isUnit hp).unit

@[simp] theorem coe_epsilonIntegerUnit (hp : P.Pell) :
    ((P.epsilonIntegerUnit hp : 𝓞 P.Algebra) : P.Algebra) = P.epsilon := by
  simp [epsilonIntegerUnit, IsUnit.unit_spec]

/-- The algebra unit used previously is the square of the integer-ring unit. -/
theorem stepUnit_eq_integerUnit_sq (hp : P.Pell) :
    P.stepUnit hp =
      Units.map (algebraMap (𝓞 P.Algebra) P.Algebra) (P.epsilonIntegerUnit hp ^ 2) := by
  apply Units.ext
  simpa [stepUnit] using P.step_eq_epsilon_sq

/-- The previous integer-indexed terms are exactly `α ε^(2k)` in the field. -/
theorem term_eq_field_powers (hp : P.Pell) (k : ℤ) :
    P.term hp k = P.alpha * P.epsilon ^ (2 * k) := by
  rw [term, Units.val_zpow_eq_zpow_val]
  change P.alpha * P.step ^ k = _
  rw [P.step_eq_epsilon_sq, ← zpow_natCast P.epsilon 2, ← zpow_mul]
  norm_num

end Integers

end «JNT-2024».Parameters
