module

public import «JNT-2024».NormalizerFormula
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

theorem gcd_two_power (n k : ℕ) (hn : n ≠ 0) :
    Nat.gcd (2 ^ k) n = 2 ^ min k (padicValNat 2 n) := by
  obtain ⟨j, _, hj⟩ := (Nat.dvd_prime_pow Nat.prime_two).mp (Nat.gcd_dvd_left (2 ^ k) n)
  have hv := valuation_gcd 2 (a := ((2 ^ k : ℕ) : ℤ)) (b := (n : ℤ))
    (by positivity) (by exact_mod_cast hn)
  have hv' : padicValNat 2 (Nat.gcd (2 ^ k) n) = min k (padicValNat 2 n) := by
    simpa only [Int.gcd_eq_natAbs_gcd_natAbs, Int.natAbs_natCast, padicValInt.of_nat,
      padicValNat.prime_pow] using hv
  rw [hj, padicValNat.prime_pow] at hv'
  rw [hj, hv']

theorem capped_valuation_product_le {G : ℕ} (hG : 0 < G) (v : ℕ) :
    2 ^ min 4 (padicValNat 2 G + v) ≤ G * 2 ^ min 4 v := by
  have hp : 2 ^ padicValNat 2 G ≤ G := Nat.le_of_dvd hG pow_padicValNat_dvd
  calc
    _ ≤ 2 ^ (padicValNat 2 G + min 4 v) := Nat.pow_le_pow_right (by decide) (by omega)
    _ = 2 ^ padicValNat 2 G * 2 ^ min 4 v := pow_add _ _ _
    _ ≤ _ := Nat.mul_le_mul_right _ hp

namespace Parameters

/-- The integer square of the common normalizer, suitable for exact finite checks. -/
def normalizerSquare (P : Parameters) : ℕ :=
  4 * P.baseGcd * Nat.gcd 16 P.normQuotient.natAbs

theorem normalizerSquare_eq (P : Parameters) (hc : Int.gcd P.a P.b = 1) (hn : P.normAlpha ≠ 0) :
    P.normalizerSquare = 4 * P.baseGcd * 2 ^ min 4 (padicValInt 2 P.normQuotient) := by
  rw [normalizerSquare, show (16 : ℕ) = 2 ^ 4 by norm_num,
    gcd_two_power _ _ (Int.natAbs_ne_zero.mpr (P.normQuotient_ne_zero hc hn))]
  rfl

theorem normalizerSquare_bounds (P : Parameters) (h : P.Admissible)
    (hc : Int.gcd P.a P.b = 1) (hn : P.normAlpha ≠ 0) :
    4 * 2 ^ min 4 (padicValInt 2 P.normAlpha) ≤ P.normalizerSquare ∧
      4 ≤ P.normalizerSquare ∧ P.normalizerSquare ≤ 64 * P.normAlpha.natAbs := by
  have hG := P.baseGcd_pos (ne_of_gt h.a_pos)
  have hB := P.normQuotient_ne_zero hc hn
  have hmul := P.normQuotient_mul hc
  have hv : padicValInt 2 P.normAlpha = padicValNat 2 P.baseGcd + padicValInt 2 P.normQuotient := by
    rw [← hmul, padicValInt.mul (by exact_mod_cast ne_of_gt hG) hB, padicValInt.of_nat]
  have hle := capped_valuation_product_le hG (padicValInt 2 P.normQuotient)
  rw [P.normalizerSquare_eq hc hn]
  have hpow : 1 ≤ 2 ^ min 4 (padicValInt 2 P.normQuotient) := Nat.one_le_two_pow
  have hpow' : 2 ^ min 4 (padicValInt 2 P.normQuotient) ≤ 16 := by
    exact Nat.pow_le_pow_right (by decide) (min_le_left _ _)
  have hGle : P.baseGcd ≤ P.normAlpha.natAbs :=
    Nat.le_of_dvd (Int.natAbs_pos.mpr hn) (by
      rw [P.baseGcd_eq hc]
      exact Int.gcd_dvd_natAbs_left _ _)
  refine ⟨by rw [hv]; nlinarith only [hle], ?_, ?_⟩
  · nlinarith
  · nlinarith

theorem lemma312 (P : Parameters) (h : P.Admissible) (hc : Int.gcd P.a P.b = 1)
    (hn : P.normAlpha < 0) {k X Y ν : ℤ}
    (hx : P.x h.pell k = (X : ℚ)) (hy : P.y h.pell k = (Y : ℚ)) (hν : ν = 1 ∨ ν = -1) :
    Approximation.normalizerProduct (squarefreePart P.normAlpha) (2 * X)
      (2 * ν * squareFactor P.normAlpha) = Real.sqrt P.normalizerSquare ∧
    Real.sqrt (4 * (2 : ℝ) ^ min 4 (padicValInt 2 P.normAlpha)) ≤
      Approximation.normalizerProduct (squarefreePart P.normAlpha) (2 * X)
        (2 * ν * squareFactor P.normAlpha) := by
  have he : Approximation.normalizerProduct (squarefreePart P.normAlpha) (2 * X)
      (2 * ν * squareFactor P.normAlpha) = Real.sqrt P.normalizerSquare := by
    rw [P.lemma312_eq h hc hn hx hy hν, P.normalizerSquare_eq hc (ne_of_lt hn)]
    push_cast
    rfl
  refine ⟨he, ?_⟩
  rw [he]
  apply Real.sqrt_le_sqrt
  exact_mod_cast (P.normalizerSquare_bounds h hc (ne_of_lt hn)).1

end Parameters
end «JNT-2024»
