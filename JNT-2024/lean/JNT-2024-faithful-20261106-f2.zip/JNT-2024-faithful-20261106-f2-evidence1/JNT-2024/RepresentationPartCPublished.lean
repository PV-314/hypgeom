module

public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».RepresentationBounds
public import «JNT-2024».RepresentationFactors
public import «JNT-2024».RepresentationFewPrimes
public import «JNT-2024».RepresentationLemma33Published
public import «JNT-2024».RepresentationLemma34Published
public import «JNT-2024».RepresentationNormalization
public import «JNT-2024».RepresentationNormalizationPublished
public import «JNT-2024».RepresentationPrimePartition
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- The strict bound in part (a) forces f'=1 when its squarefree support is prime. -/
theorem prime_small_factor_eq_one {p e : ℕ} (hp : p.Prime) (he : e ∣ p)
    (hsmall : (e : ℝ) < max 2 (Real.sqrt p)) : e = 1 := by
  rcases (Nat.dvd_prime hp).mp he with h | h
  · exact h
  · subst e
    have hp2 : (2 : ℝ) ≤ p := by exact_mod_cast hp.two_le
    have hs := Real.sq_sqrt (show (0 : ℝ) ≤ p by positivity)
    have hs0 := Real.sqrt_nonneg (p : ℝ)
    have hbound : Real.sqrt p ≤ (p : ℝ) := by nlinarith
    exact (not_lt_of_ge (max_le hp2 hbound) hsmall).elim

namespace Parameters

/-- Part (c-i): the factor f' from the exact printed construction in (a) is one. -/
theorem publishedSmallFactor_eq_one_of_prime (P : Parameters) {x y : ℤ} {p : ℕ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0)
    (hp : p.Prime) (hshape : (squarefreePart P.normAlpha).natAbs = p) :
    P.publishedSmallFactor y = 1 := by
  obtain ⟨_,hd,_,hsmall,_⟩ := P.published_candidate_selection h hb hu hN
  apply prime_small_factor_eq_one hp
  · rw [← hshape]
    exact Int.natCast_dvd.mp hd
  · have hc : |(squarefreePart P.normAlpha : ℝ)| = (p : ℝ) := by
      rw [← hshape]
      simp
    rwa [hc] at hsmall

/-- The strict two-adic bound in (c) from exactly the restored Lemmas 3.4 and 3.3(c). -/
theorem candidate_two_negative_published (P : Parameters) [Fact (¬ IsSquare P.d)] {x y σ : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0)
    (hi : IsIntegral ℤ P.epsilon) (hσ : σ = 1 ∨ σ = -1)
    (hex : ¬ (P.normAlpha % 4 = 1 ∧ 4 ∣ P.d)) :
    P.candidateValuation y σ 2 < 0 := by
  have hev := P.lemma34_published h hi hex
  apply lemma33c_published hb (P.repCandidate_ne_zero h hu hN hσ)
  rcases hσ with rfl | rfl
  · exact hev.1
  · exact hev.2.1

/-- The exact comparison and tie convention printed in (c-ii). -/
noncomputable def publishedPrimeComparisonSign (P : Parameters) (y : ℤ) (p : ℕ) : ℤ :=
  if P.candidateValuation y 1 p ≤ P.candidateValuation y (-1) p then 1 else -1

theorem publishedPrimeComparison_min (P : Parameters) (y : ℤ) (p : ℕ) :
    (P.publishedPrimeComparisonSign y p = 1 ∨ P.publishedPrimeComparisonSign y p = -1) ∧
      P.candidateValuation y (P.publishedPrimeComparisonSign y p) p =
        min (P.candidateValuation y 1 p) (P.candidateValuation y (-1) p) := by
  unfold publishedPrimeComparisonSign
  split
  · next hh => exact ⟨Or.inl rfl, (min_eq_left hh).symm⟩
  · next hh => exact ⟨Or.inr rfl, (min_eq_right (by omega)).symm⟩

/-- Part (c-ii): both two-valuations are negative, and the printed comparison
removes p. This proves both displayed valuation inequalities. -/
theorem twice_prime_candidate_published (P : Parameters) [Fact (¬ IsSquare P.d)]
    {x y : ℤ} {p : ℕ} (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hu : P.u ≠ 0)
    (hN : P.normAlpha ≠ 0) (hi : IsIntegral ℤ P.epsilon) (hp : p.Prime)
    (hshape : (squarefreePart P.normAlpha).natAbs = 2 * p) :
    max (P.candidateValuation y 1 2) (P.candidateValuation y (-1) 2) < 0 ∧
      P.candidateValuation y (P.publishedPrimeComparisonSign y p) p ≤ 0 ∧
      ∀ q : ℕ, q.Prime → (q : ℤ) ∣ squarefreePart P.normAlpha →
        P.candidateValuation y (P.publishedPrimeComparisonSign y p) q ≤ 0 := by
  have h2S : (2 : ℤ) ∣ squarefreePart P.normAlpha := Int.natCast_dvd.mpr
    (by rw [hshape]; exact dvd_mul_right 2 p)
  have hpS : (p : ℤ) ∣ squarefreePart P.normAlpha := Int.natCast_dvd.mpr
    (by rw [hshape]; exact dvd_mul_left p 2)
  have hex := P.not_parity_exception_of_even_squarefree h2S
  have hv1 := P.candidate_two_negative_published h hb hu hN hi (Or.inl rfl) hex
  have hv2 := P.candidate_two_negative_published h hb hu hN hi (Or.inr rfl) hex
  obtain ⟨hσ, hmin⟩ := P.publishedPrimeComparison_min y p
  have hvp : P.candidateValuation y (P.publishedPrimeComparisonSign y p) p ≤ 0 := by
    let : Fact p.Prime := ⟨hp⟩
    rw [hmin]
    exact P.lemma33b h hb hu hN p ((prime_dvd_iff_valuation_pos p (squarefreePart_ne_zero _)).mp hpS)
  refine ⟨max_lt hv1 hv2, hvp, ?_⟩
  intro q hq hd
  have hqd : q ∣ 2 * p := by rw [← hshape]; exact Int.natCast_dvd.mp hd
  rcases hq.dvd_mul.mp hqd with hd2 | hdp
  · have hq2 := (Nat.prime_dvd_prime_iff_eq hq Nat.prime_two).mp hd2
    subst q
    exact le_of_lt (P.candidate_two_negative_published h hb hu hN hi hσ hex)
  · have hqp := (Nat.prime_dvd_prime_iff_eq hq hp).mp hdp
    subst q
    exact hvp

/-- The two displayed valuation chains in (c-ii), with their nonnegative
radical terms. The strict two-adic bound also gives the printed minus-one bound. -/
theorem part_c_displayed_valuation_chains (P : Parameters) [Fact (¬ IsSquare P.d)]
    {x y : ℤ} {p : ℕ} (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hu : P.u ≠ 0)
    (hN : P.normAlpha ≠ 0) (hi : IsIntegral ℤ P.epsilon) (hp : p.Prime)
    (hshape : (squarefreePart P.normAlpha).natAbs = 2 * p) (ν : ℤ) :
    max (P.candidateValuation y 1 2) (P.candidateValuation y (-1) 2) < 0 ∧
    (0 : ℤ) ≤ padicValInt 2 (P.sharpRadical ν 1) ∧
    P.candidateValuation y (P.publishedPrimeComparisonSign y p) p ≤ 0 ∧
    (0 : ℤ) ≤ padicValInt p (P.sharpRadical ν 1) ∧
    P.candidateValuation y (P.publishedPrimeComparisonSign y p) 2 ≤ -1 := by
  obtain ⟨htwo, hpval, _⟩ := P.twice_prime_candidate_published h hb hu hN hi hp hshape
  obtain ⟨hσ, _⟩ := P.publishedPrimeComparison_min y p
  refine ⟨htwo, by positivity, hpval, by positivity, ?_⟩
  rcases hσ with hσ | hσ <;> rw [hσ] <;> omega

/-- The two printed cases supply their specified candidate, with every
squarefree-norm prime removed from its quotient numerator. -/
theorem exists_part_c_candidate_published (P : Parameters) [Fact (¬ IsSquare P.d)]
    {x y : ℤ} (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hu : P.u ≠ 0)
    (hN : P.normAlpha ≠ 0) (hi : IsIntegral ℤ P.epsilon)
    (hshape : (squarefreePart P.normAlpha).natAbs.Prime ∨
      ∃ p : ℕ, p.Prime ∧ (squarefreePart P.normAlpha).natAbs = 2 * p) :
    ∃ σ : ℤ, (σ = 1 ∨ σ = -1) ∧
      ∀ q : ℕ, q.Prime → (q : ℤ) ∣ squarefreePart P.normAlpha → P.candidateValuation y σ q ≤ 0 := by
  rcases hshape with hp | ⟨p, hp, hshape⟩
  · obtain ⟨hσ,_,_,_,hcover⟩ := P.published_candidate_selection h hb hu hN
    have he := P.publishedSmallFactor_eq_one_of_prime h hb hu hN hp rfl
    refine ⟨P.publishedCandidateSign y, hσ, ?_⟩
    intro q hq hd
    by_contra hv
    have hqd := hcover q hq hd (by omega)
    rw [he] at hqd
    exact hq.not_dvd_one hqd
  · exact ⟨P.publishedPrimeComparisonSign y p, (P.publishedPrimeComparison_min y p).1,
      (P.twice_prime_candidate_published h hb hu hN hi hp hshape).2.2⟩

/-- Proposition 3.1(c), using exactly the prime and twice-prime arguments
on pp. 16-17 and the restored quotient/normalization construction. -/
theorem proposition31c_prime_or_twice_published (P : Parameters)
    [Fact (¬ IsSquare P.d)] [Fact (¬ IsSquare P.normAlpha)] {x y : ℤ}
    (h : P.RepresentsSquare x y) (ha : P.a ≠ 0) (hb : P.b ≠ 0) (hy : y ≠ 0)
    (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0) (hi : IsIntegral ℤ P.epsilon)
    (hshape : (squarefreePart P.normAlpha).natAbs.Prime ∨
      ∃ p : ℕ, p.Prime ∧ (squarefreePart P.normAlpha).natAbs = 2 * p) :
    ∃ ν f r s : ℤ, (ν : ℚ) = P.epsilonNorm ∧ f ≠ 0 ∧
      P.FourthPowerRepresentation x y f r s ∧
      f ∣ (if P.normAlpha % 4 = 1 ∧ 4 ∣ P.d then 4 else 2) * P.b ^ 2 * P.sharpRadical ν 1 := by
  have hd : P.d ≠ 0 := by
    intro hz
    exact (Fact.out : ¬ IsSquare P.d) (hz ▸ IsSquare.zero)
  obtain ⟨ν,hn,hν⟩ := P.exists_integer_norm_relation hi
  obtain ⟨σ,hσ,hcover⟩ := P.exists_part_c_candidate_published h hb hu hN hi hshape
  obtain ⟨f,r,s,hf,he,_,_,hrep⟩ := P.candidate_representation_from_published_quotient h ha hb hd hy hu hN hi hσ
  have hv : ∀ q : ℕ, q.Prime → P.candidateValuation y σ q ≤ padicValInt q (P.sharpRadical ν 1) := by
    intro q hq
    let : Fact q.Prime := ⟨hq⟩
    apply P.candidate_valuation_le_sharpRadical_published h hb hu hN hν hσ (by norm_num)
    intro z hz hd hzpos
    have hh := hcover z hz hd
    change P.candidateValuation y σ z > 0 at hzpos
    omega
  refine ⟨ν,f,r,s,hn,hf,hrep,?_⟩
  by_cases hex : P.normAlpha % 4 = 1 ∧ 4 ∣ P.d
  · rw [ite_eq_left hex]
    exact normalized_coefficient_dvd_four hb (P.repCandidate_ne_zero h hu hN hσ) hf
      UniqueFactorizationMonoid.radical_ne_zero hσ he hv
  · rw [ite_eq_right hex]
    exact normalized_coefficient_dvd_two hb (P.repCandidate_ne_zero h hu hN hσ) hf
      UniqueFactorizationMonoid.radical_ne_zero hσ he hv
      (P.candidate_two_negative_published h hb hu hN hi hσ hex)

/-- The literal power-shape statement covers all three possibilities 2,p,2p;
in particular the prime-two case is included in (c-i). -/
theorem proposition31c_published (P : Parameters)
    [Fact (¬ IsSquare P.d)] [Fact (¬ IsSquare P.normAlpha)] {x y : ℤ}
    (h : P.RepresentsSquare x y) (ha : P.a ≠ 0) (hb : P.b ≠ 0) (hy : y ≠ 0)
    (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0) (hi : IsIntegral ℤ P.epsilon)
    (p ℓ m : ℕ) (hp : p.Prime) (hℓ : ℓ ≤ 1) (hm : m ≤ 1) (hpositive : 1 ≤ ℓ + m)
    (hshape : squarefreePart |P.normAlpha| = (2 : ℤ) ^ ℓ * (p : ℤ) ^ m) :
    ∃ ν f r s : ℤ, (ν : ℚ) = P.epsilonNorm ∧ f ≠ 0 ∧
      P.FourthPowerRepresentation x y f r s ∧
      f ∣ (if P.normAlpha % 4 = 1 ∧ 4 ∣ P.d then 4 else 2) * P.b ^ 2 * P.sharpRadical ν 1 := by
  have hn : (squarefreePart P.normAlpha).natAbs = 2 ^ ℓ * p ^ m := by
    have hh := congrArg Int.natAbs hshape
    simpa only [squarefreePart_abs hN, Int.natAbs_abs, Int.natAbs_mul, Int.natAbs_pow,
      Int.natAbs_natCast, show Int.natAbs (2 : ℤ) = 2 from rfl] using hh
  apply P.proposition31c_prime_or_twice_published h ha hb hy hu hN hi
  have hlcases : ℓ = 0 ∨ ℓ = 1 := by omega
  have hmcases : m = 0 ∨ m = 1 := by omega
  rcases hlcases with rfl | rfl <;> rcases hmcases with rfl | rfl
  · omega
  · left
    have hh : (squarefreePart P.normAlpha).natAbs = p := by simpa using hn
    rw [hh]
    exact hp
  · left
    have hh : (squarefreePart P.normAlpha).natAbs = 2 := by simpa using hn
    rw [hh]
    exact Nat.prime_two
  · right
    exact ⟨p,hp,by simpa using hn⟩

end Parameters
end «JNT-2024»
