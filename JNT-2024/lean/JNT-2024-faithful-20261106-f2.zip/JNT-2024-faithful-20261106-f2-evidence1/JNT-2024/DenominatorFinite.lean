module

public import «JNT-2024».DenominatorComputation
public import «JNT-2024».DenominatorDefinitions
public import «JNT-2024».HypergeometricPolynomials
public import «JNT-2024».RemainderConstruction
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

set_option maxRecDepth 100000 in
set_option maxHeartbeats 0 in
theorem denominator_fast_certificate : ∀ r : Fin 139, FastDenominatorCheck r.val := by
  decide +kernel

theorem denominator_finite_certificate : ∀ r : Fin 139, FiniteDenominatorCheck r.val :=
  fun r => (fastDenominatorCheck_iff r.val).mp (denominator_fast_certificate r)

theorem denominatorExponentialLower_lt_exp :
    (denominatorExponentialLower : ℝ) < Real.exp (42 / 25 : ℝ) := by
  have hh := Real.sum_le_exp_of_nonneg (by norm_num : (0 : ℝ) ≤ 42 / 25) 14
  have hl : (denominatorExponentialLower : ℝ) <
      ∑ i ∈ Finset.range 14, (42 / 25 : ℝ) ^ i / i.factorial := by
    norm_num [denominatorExponentialLower, Finset.sum_range_succ]
  exact hl.trans_le hh

theorem gammaNumeratorRatio_eq_gamma (r : ℕ) :
    (gammaNumeratorRatio r : ℝ) =
      Real.Gamma ((r : ℝ) + 5 / 4) / (Real.Gamma (1 / 4) * r.factorial) := by
  rw [gammaNumeratorRatio, Rat.cast_div, Rat.cast_natCast, risingQ_eq_gamma (by norm_num)]
  norm_num
  rw [show (1 / 4 : ℝ) + (r + 1) = (r : ℝ) + 5 / 4 by ring]
  ring

end Hypergeometric
end «JNT-2024»
