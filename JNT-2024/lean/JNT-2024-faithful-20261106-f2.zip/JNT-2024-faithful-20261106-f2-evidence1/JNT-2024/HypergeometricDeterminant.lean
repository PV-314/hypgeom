module

public import «JNT-2024».HypergeometricPolynomials
public import «JNT-2024».HypergeometricRecurrence
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

theorem Y_recurrence {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1) (r : ℕ)
    {z : ℂ} (hz : z ≠ 0) :
    (r + 2 - (ν : ℂ)) * Y ν (r + 2) z =
      (2 * r + 3) * (1 + z) * Y ν (r + 1) z -
      (r + 1 + ν) * (1 - z) ^ 2 * Y ν r z := by
  simp only [Y_eq_reciprocal ν _ hz]
  calc
    _ = z ^ (r + 2) * ((r + 2 - (ν : ℂ)) * X ν (r + 2) z⁻¹) := by ring
    _ = z ^ (r + 2) * ((2 * r + 3) * (1 + z⁻¹) * X ν (r + 1) z⁻¹ -
        (r + 1 + ν) * (1 - z⁻¹) ^ 2 * X ν r z⁻¹) := by rw [X_recurrence hν₀ hν₁]
    _ = _ := by simp only [pow_add, pow_one]; field_simp; ring

noncomputable def determinant (ν : ℚ) (r : ℕ) (z : ℂ) : ℂ :=
  X ν r z * Y ν (r + 1) z - X ν (r + 1) z * Y ν r z

theorem determinant_zero {ν : ℚ} (hν : ν ≠ 1) (z : ℂ) :
    determinant ν 0 z = (2 * (ν : ℂ) / (1 - ν)) * (1 - z) := by
  have hn : (1 - (ν : ℂ)) ≠ 0 := by exact_mod_cast sub_ne_zero.mpr (Ne.symm hν)
  simp only [determinant, X, Y, Finset.sum_range_succ, Finset.sum_range_zero,
    coefficient_zero, coefficient_one]
  push_cast
  norm_num
  field_simp
  ring

theorem determinant_recurrence {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1) (r : ℕ)
    {z : ℂ} (hz : z ≠ 0) :
    (r + 2 - (ν : ℂ)) * determinant ν (r + 1) z =
      (r + 1 + ν) * (1 - z) ^ 2 * determinant ν r z := by
  have hx := X_recurrence hν₀ hν₁ r z
  have hy := Y_recurrence hν₀ hν₁ r hz
  unfold determinant
  simp only [Nat.add_assoc]
  linear_combination X ν (r + 1) z * hy - Y ν (r + 1) z * hx

/-- Consecutive hypergeometric approximants are independent away from `z = 1`. -/
theorem determinant_ne_zero {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1) (r : ℕ)
    {z : ℂ} (hz : z ≠ 0) (hz₁ : z ≠ 1) : determinant ν r z ≠ 0 := by
  have hν : (ν : ℂ) ≠ 0 := by exact_mod_cast ne_of_gt hν₀
  have hn : (1 - (ν : ℂ)) ≠ 0 := by exact_mod_cast ne_of_gt (sub_pos.mpr hν₁)
  have hz' : 1 - z ≠ 0 := sub_ne_zero.mpr (Ne.symm hz₁)
  induction r with
  | zero =>
    rw [determinant_zero (ne_of_lt hν₁)]
    exact mul_ne_zero (div_ne_zero (mul_ne_zero (by norm_num) hν) hn) hz'
  | succ r ih =>
    have hr : (r + 1 + (ν : ℂ)) ≠ 0 := by
      have h : (r + 1 + ν : ℚ) ≠ 0 := by positivity
      exact_mod_cast h
    intro he
    have hh := determinant_recurrence hν₀ hν₁ r hz
    rw [he, mul_zero] at hh
    exact mul_ne_zero (mul_ne_zero hr (pow_ne_zero _ hz')) ih hh.symm

/-- Lemma 2.2(b), for the paper's unit-circle parameter. -/
theorem lemma22b {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1 / 2) (r : ℕ)
    {ω : ℂ} (hω : ‖ω‖ = 1) (hω₁ : ω ≠ 1) :
    X ν r ω * Y ν (r + 1) ω ≠ X ν (r + 1) ω * Y ν r ω := by
  have hω₀ : ω ≠ 0 := by intro h; simp [h] at hω
  exact sub_ne_zero.mp (determinant_ne_zero hν₀ (by linarith) r hω₀ hω₁)

end Hypergeometric
end «JNT-2024»
