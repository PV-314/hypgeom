module

public import «JNT-2024».NormalizerBounds
public import «JNT-2024».NormalizerFormula
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».Proposition41
public import «JNT-2024».Section5AnalyticRevised
public import «JNT-2024».Section5GcdNormalization
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Pow.Real
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- The normalizer is a positive even integer, with square at most 4|N_alpha|.
This supplies precisely (5.4), using the existing gcd normalization. -/
theorem normalizer_integer_revised (P : Parameters) (h : P.Admissible)
    (hb : P.b=1) (hn : P.normAlpha<0) (hNs : IsSquare (-P.normAlpha)) :
    ∃ M : ℤ, 0<M ∧ Even M ∧ (P.normalizerSquare:ℤ)=M^2 ∧
      M^2 ≤ 4*(-P.normAlpha) := by
  obtain ⟨n,hnval⟩ := hNs
  have hn2 : -P.normAlpha=n^2 := by simpa only [pow_two] using hnval
  obtain ⟨g,A,b,hg,_,_,hnb,_,_,hB,_⟩ := P.section5_normalized_coordinates h hb hn2
  have hn0 : n ≠ 0 := by intro he; rw [he] at hn2; norm_num at hn2; omega
  have hb0 : b ≠ 0 := by intro he; rw [he,mul_zero] at hnb; exact hn0 hnb
  have hv : 0 < Int.gcd 4 b := Int.gcd_pos_of_ne_zero_left b (by norm_num)
  have hgc : Int.gcd 16 (b^2)=(Int.gcd 4 b)^2 := by
    rw [show (16:ℤ)=4^2 by norm_num,Int.pow_gcd_pow]
  refine ⟨2*(g:ℤ)*(Int.gcd 4 b:ℤ),by positivity,?_,?_,?_⟩
  · refine ⟨(g:ℤ)*(Int.gcd 4 b:ℤ),?_⟩
    ring
  · rw [hB,hgc]
    push_cast
    ring
  · have hle := Int.gcd_le_right 16 (sq_pos_of_ne_zero hb0)
    have hm := mul_le_mul_of_nonneg_left hle (by positivity : (0:ℤ)≤4*(g:ℤ)^2)
    rw [hgc] at hm
    push_cast at hm
    rw [hnb] at hn2
    nlinarith only [hm,hn2]

/-- The literal complete-square identities (5.5), for either adjacent index. -/
theorem adjacent_complete_square_revised (P : Parameters) (hp : P.Pell) (hb : P.b=1) :
    4*P.y hp 1=((P.t:ℚ)+P.a*P.u)^2-(P.normAlpha:ℚ)*(P.u:ℚ)^2 ∧
    4*P.y hp (-1)=((P.t:ℚ)-P.a*P.u)^2-(P.normAlpha:ℚ)*(P.u:ℚ)^2 := by
  rw [P.y_one,P.y_neg_one,hb]
  simp only [normAlpha,hb,Int.cast_sub,Int.cast_pow,Int.cast_one,
    one_pow,one_mul]
  constructor <;> ring

/-- Lemma 5.4 of manuscript 2026-11-06d, including the norm-minus-one case.
The normalizer is written as its canonical positive square root. -/
theorem lemma54_revised (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hn : P.normAlpha<0) (hNs : IsSquare (-P.normAlpha))
    {k : ℤ} (hk : k=1 ∨ k= -1) (_hs : IsIntegerSquare (P.y h.pell k))
    (hy : 1<P.y h.pell k) (hcut : (P.y h.pell k:ℝ) ≤ P.proposition41Threshold) :
    (P.u:ℝ)*Real.sqrt (P.normalizerSquare:ℝ) ≤ 18 := by
  obtain ⟨M,hM,heven,hMsq,hMn⟩ := P.normalizer_integer_revised h hb hn hNs
  have hMreal : (0:ℝ)<M := by exact_mod_cast hM
  have hMsqR : (P.normalizerSquare:ℝ)=(M:ℝ)^2 := by exact_mod_cast hMsq
  have hMroot : Real.sqrt (P.normalizerSquare:ℝ)=(M:ℝ) := by
    rw [hMsqR,Real.sqrt_sq hMreal.le]
  have hd : (0:ℝ)<P.d := by exact_mod_cast h.d_pos
  have ha : (0:ℝ)<P.a := by exact_mod_cast h.a_pos
  have ht : (0:ℝ)<P.t := by exact_mod_cast h.t_pos
  have hu : (0:ℝ)<P.u := by exact_mod_cast h.u_pos
  have hnR : (P.normAlpha:ℝ)<0 := by exact_mod_cast hn
  let n : ℝ := Real.sqrt |(P.normAlpha:ℝ)|
  let s : ℝ := Real.sqrt (P.d:ℝ)
  have hs : 0<s := Real.sqrt_pos.mpr hd
  have hnpos : 0<n := Real.sqrt_pos.mpr (abs_pos.mpr (ne_of_lt hnR))
  have hs2 : s^2=(P.d:ℝ) := Real.sq_sqrt hd.le
  have hn2 : n^2=|(P.normAlpha:ℝ)| := Real.sq_sqrt (abs_nonneg _)
  have hnorm : (P.normAlpha:ℝ)=(P.a:ℝ)^2-P.d := by
    simp [normAlpha,hb]
  have hns : n^2=s^2-(P.a:ℝ)^2 := by rw [hn2,abs_of_neg hnR,hs2,hnorm]; ring
  have has : (P.a:ℝ)<s := by nlinarith only [hns,ha,hs,sq_pos_of_pos hnpos]
  have hpell : (P.t:ℝ)^2-s^2*(P.u:ℝ)^2=4 ∨ (P.t:ℝ)^2-s^2*(P.u:ℝ)^2= -4 := by
    rw [hs2]; exact_mod_cast h.pell
  have hyl : (P.t:ℝ)^2+s^2*(P.u:ℝ)^2-2*P.a*P.t*P.u ≤ 4*(P.y h.pell k:ℝ) := by
    rw [hs2]
    rcases hk with rfl | rfl
    · rw [P.y_one,hb]
      push_cast
      nlinarith [mul_pos (mul_pos ha ht) hu]
    · rw [P.y_neg_one,hb]
      push_cast
      linarith
  have hl := Section5Revised.adjacent_lower_bound hs ha has ht hu hnpos hns hpell hyl
  have hcut' : (P.y h.pell k:ℝ) ≤ 137*n^3/(s*(M:ℝ)^2) := by
    have hyR : (1:ℝ)<(P.y h.pell k:ℝ) := by exact_mod_cast hy
    change (P.y h.pell k:ℝ) ≤ max 1
      (137 * |(P.normAlpha:ℝ)| * n / (s*(P.normalizerSquare:ℝ))) at hcut
    have hc := (le_max_iff.mp hcut).resolve_left (not_le_of_gt hyR)
    rw [hMsqR,← hn2] at hc
    convert hc using 1 <;> ring
  have hcutprod : s*(P.y h.pell k:ℝ)*(M:ℝ)^2 ≤ 137*n^3 := by
    have hc := (le_div_iff₀ (mul_pos hs (sq_pos_of_pos hMreal))).mp hcut'
    nlinarith only [hc]
  have hMnR : (M:ℝ)^2 ≤ 4*n^2 := by
    rw [hn2,abs_of_neg hnR]; exact_mod_cast hMn
  have hbound := Section5Revised.small_square_product_bound hnpos hMreal hl hcutprod hMnR
  have hboundZ : (P.u*M)^2 < 376 := by exact_mod_cast hbound
  have hh := Section5Revised.even_product_le_eighteen (heven.mul_left P.u)
    (mul_pos h.u_pos hM).le hboundZ
  rw [hMroot]
  exact_mod_cast hh

end «JNT-2024».Parameters
