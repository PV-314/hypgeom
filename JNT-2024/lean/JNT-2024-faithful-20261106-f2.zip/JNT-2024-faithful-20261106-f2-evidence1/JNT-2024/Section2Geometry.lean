module

public import «JNT-2024».ApproximationGcd
public import «JNT-2024».DenominatorBounds
public import «JNT-2024».NormalizerFormula
public import «JNT-2024».Section2Complex
public import «JNT-2024».Section2Construction
public import «JNT-2024».Section2Parameters
public import «JNT-2024».UnitCircleGeometry
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Section2

open Hypergeometric

noncomputable def Q (S u₁ u₂ : ℤ) : ℝ :=
  Real.exp (42 / 25) * (|(u₁ : ℝ)| + Real.sqrt (H S u₁ u₂)) /
    Approximation.normalizerProduct S u₁ u₂

noncomputable def E (S u₁ u₂ : ℤ) : ℝ :=
  Approximation.normalizerProduct S u₁ u₂ * (|(u₁ : ℝ)| + Real.sqrt (H S u₁ u₂)) /
    (Real.exp (42 / 25) * (u₂ : ℝ) ^ 2 * |(S : ℝ)|)

noncomputable def ell (S u₁ u₂ : ℤ) : ℝ := (537 / 2000 : ℝ) * |(omega S u₁ u₂).arg|

theorem normalizerProduct_eq {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) :
    Approximation.normalizerProduct S u₁ u₂ = Approximation.g S u₁ u₂ *
      twoAdicScale4 (Approximation.dPrimeInteger S u₁ u₂) := by
  rw [Approximation.normalizerProduct, abs_of_pos (Approximation.g_pos (ne_of_lt hS) hu₂),
    Approximation.N4_dPrime_eq (ne_of_lt hS) hu₂]

theorem Q_pos {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) : 0 < Q S u₁ u₂ := by
  rw [Q, normalizerProduct_eq hS hu₂]
  exact div_pos (mul_pos (Real.exp_pos _) (add_pos_of_nonneg_of_pos (abs_nonneg _)
    (Real.sqrt_pos.mpr (H_pos hS hu₂))))
    (mul_pos (Approximation.g_pos (ne_of_lt hS) hu₂) (twoAdicScale4_pos _))


theorem ell_pos {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) : 0 < ell S u₁ u₂ := by
  have hn : (omega S u₁ u₂).arg ≠ 0 := by
    intro hz
    have hh := Complex.norm_mul_exp_arg_mul_I (omega S u₁ u₂)
    rw [omega_norm hS hu₂, hz] at hh
    have he : omega S u₁ u₂ = 1 := by simpa using hh.symm
    exact omega_ne_one hS hu₂ he
  exact mul_pos (by norm_num) (abs_pos.mpr hn)

theorem norm_A {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) :
    ‖A S u₁ u₂‖ = ‖U S u₁ u₂‖ / Approximation.g S u₁ u₂ := by
  rw [A, norm_div, norm_star, Complex.norm_real, Real.norm_eq_abs,
    abs_of_pos (Approximation.g_pos (ne_of_lt hS) hu₂)]

theorem norm_one_add_omega {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) :
    ‖1 + omega S u₁ u₂‖ = |(u₁ : ℝ)| / ‖U S u₁ u₂‖ := by
  have hu := star_ne_zero.mpr (U_ne_zero (u₁ := u₁) hS hu₂)
  have he : 1 + omega S u₁ u₂ = (u₁ : ℂ) / star (U S u₁ u₂) := by
    rw [omega, ← U_add_star]
    field_simp
    ring
  rw [he, norm_div, norm_star]
  norm_cast

theorem principalSquareRoot_minus_chord {z : ℂ} (hz : ‖z‖ = 1) :
    ‖1 - principalSquareRoot z‖ ^ 2 = 2 - ‖1 + z‖ := by
  have hh := principalSquareRoot_chord hz
  have hw := principalSquareRoot_norm z
  have he : ‖1 + principalSquareRoot z‖ ^ 2 + ‖1 - principalSquareRoot z‖ ^ 2 = 4 := by
    simp only [← Complex.normSq_eq_norm_sq, Complex.normSq_apply, Complex.add_re,
      Complex.add_im, Complex.sub_re, Complex.sub_im, Complex.one_re, Complex.one_im]
    have hs : (principalSquareRoot z).re ^ 2 + (principalSquareRoot z).im ^ 2 = 1 := by
      simpa only [Complex.normSq_apply, hw, one_pow, pow_two, mul_one] using Complex.normSq_eq_norm_sq (principalSquareRoot z)
    nlinarith only [hs]
  linarith

theorem plus_chord_scaled {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) :
    ‖A S u₁ u₂‖ * ‖1 + principalSquareRoot (omega S u₁ u₂)‖ ^ 2 =
      (|(u₁ : ℝ)| + Real.sqrt (H S u₁ u₂)) / Approximation.g S u₁ u₂ := by
  have hu : ‖U S u₁ u₂‖ ≠ 0 := norm_ne_zero_iff.mpr (U_ne_zero hS hu₂)
  have hg := ne_of_gt (Approximation.g_pos (u₁ := u₁) (ne_of_lt hS) hu₂)
  rw [norm_A hS hu₂, principalSquareRoot_chord (omega_norm hS hu₂), norm_one_add_omega hS hu₂,
    ← two_norm_U hS hu₂]
  field_simp
  ring

theorem minus_chord_scaled {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) :
    ‖A S u₁ u₂‖ * ‖1 - principalSquareRoot (omega S u₁ u₂)‖ ^ 2 =
      ((u₂ : ℝ) ^ 2 * |(S : ℝ)|) /
        (Approximation.g S u₁ u₂ * (|(u₁ : ℝ)| + Real.sqrt (H S u₁ u₂))) := by
  have hu : ‖U S u₁ u₂‖ ≠ 0 := norm_ne_zero_iff.mpr (U_ne_zero hS hu₂)
  have hg := ne_of_gt (Approximation.g_pos (u₁ := u₁) (ne_of_lt hS) hu₂)
  have ht : |(u₁ : ℝ)| + Real.sqrt (H S u₁ u₂) ≠ 0 :=
    ne_of_gt (add_pos_of_nonneg_of_pos (abs_nonneg _) (Real.sqrt_pos.mpr (H_pos hS hu₂)))
  have hn := U_norm_sq hS.le u₁ u₂
  have hs : |(S : ℝ)| = -(S : ℝ) := abs_of_neg (by exact_mod_cast hS)
  rw [norm_A hS hu₂, principalSquareRoot_minus_chord (omega_norm hS hu₂), norm_one_add_omega hS hu₂]
  rw [← two_norm_U hS hu₂] at ht ⊢
  rw [hs]
  field_simp
  unfold H at hn
  nlinarith [sq_abs (u₁ : ℝ)]

/-- Equation (2.7), derived with the paper's principal square root. -/
theorem Q_eq_chord {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) :
    Q S u₁ u₂ = (Real.exp (42 / 25) / twoAdicScale4 (Approximation.dPrimeInteger S u₁ u₂)) *
      (‖A S u₁ u₂‖ * ‖1 + principalSquareRoot (omega S u₁ u₂)‖ ^ 2) := by
  rw [Q, normalizerProduct_eq hS hu₂, plus_chord_scaled hS hu₂]
  ring

/-- Equation (2.9), in the reciprocal form used by the remainder estimate. -/
theorem E_inv_eq_chord {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) :
    (E S u₁ u₂)⁻¹ = (Real.exp (42 / 25) / twoAdicScale4 (Approximation.dPrimeInteger S u₁ u₂)) *
      (‖A S u₁ u₂‖ * ‖1 - principalSquareRoot (omega S u₁ u₂)‖ ^ 2) := by
  rw [E, normalizerProduct_eq hS hu₂, minus_chord_scaled hS hu₂, inv_div]
  simp only [div_eq_mul_inv, mul_inv_rev]
  ring

end Section2
end «JNT-2024»
