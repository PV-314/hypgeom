module

public import «JNT-2024».ComplexRepresentation
public import «JNT-2024».GapPrinciple
public import «JNT-2024».GapRepresentationBounds
public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».RepresentationBounds
public import «JNT-2024».RepresentationGaussian
public import «JNT-2024».RepresentationNormalization
public import «JNT-2024».RepresentationPrimePartition
public import «JNT-2024».Sequence
public import «JNT-2024».SequenceRepresentations
public import «JNT-2024».SquarefreePart
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

theorem small_integer_factor_square_strict {S : ℤ} {e : ℕ}
    (hS : (1 : ℝ) < |(S : ℝ)|) (he : 0 < e)
    (hsmall : (e : ℝ) < max 2 (Real.sqrt |(S : ℝ)|)) :
    (e : ℝ) ^ 2 < |(S : ℝ)| := by
  have hroot := Real.sq_sqrt (abs_nonneg (S : ℝ))
  have hr := Real.sqrt_nonneg |(S : ℝ)|
  by_cases hh : 2 ≤ Real.sqrt |(S : ℝ)|
  · rw [max_eq_right hh] at hsmall
    have hep : (0 : ℝ) < e := by exact_mod_cast he
    nlinarith
  · rw [max_eq_left (le_of_not_ge hh)] at hsmall
    have he2 : e < 2 := by exact_mod_cast hsmall
    have he1 : e = 1 := by omega
    simpa [he1] using hS

theorem squarefreePart_abs_gt_one {N : ℤ} (hn : N < 0) (hNs : ¬ IsSquare (-N)) :
    (1 : ℝ) < |(squarefreePart N : ℝ)| := by
  have hs := squarefreePart_neg hn
  have hne : squarefreePart N ≠ -1 := by
    intro he
    apply hNs
    refine ⟨squareFactor N, ?_⟩
    have hh := squareFactor_sq_mul N
    rw [he] at hh
    nlinarith
  have hh : (1 : ℤ) < |squarefreePart N| := by rw [abs_of_neg hs]; omega
  exact_mod_cast hh

namespace Parameters

/-- Both printed coefficient assertions following (3.16), in the nonsquare
case. The Gaussian case uses Proposition 3.1(b)'s stronger divisor b². -/
theorem unit_representation_coefficients_published (P : Parameters) {ν f : ℤ} {e : ℕ}
    (hb : 0 < P.b) (hn : P.normAlpha < 0) (hNs : ¬ IsSquare (-P.normAlpha))
    (hν : ν = 1 ∨ ν = -1) (hf : 0 < f) (he : 0 < e)
    (hed : (e : ℤ) ∣ squarefreePart P.normAlpha)
    (hsmall : (e : ℝ) < max 2 (Real.sqrt |(squarefreePart P.normAlpha : ℝ)|))
    (hd : f ∣ 4 * P.b ^ 2 * P.sharpRadical ν e) :
    f ∣ 4 * P.b ^ 2 * |squarefreePart P.normAlpha| ∧
    (f : ℝ) ^ 2 < 16 * (P.b : ℝ) ^ 4 * |(squarefreePart P.normAlpha : ℝ)| := by
  have hd' : f ∣ 4 * P.b ^ 2 * (e : ℤ) :=
    hd.trans (mul_dvd_mul_left _ (P.sharpRadical_dvd_factor hν e))
  refine ⟨hd'.trans (mul_dvd_mul_left _ ((dvd_abs _ _).mpr hed)), ?_⟩
  have hep : (0 : ℤ) < e := by exact_mod_cast he
  have hdiv : (0 : ℤ) < 4 * P.b ^ 2 * (e : ℤ) := by positivity
  have hle : (f : ℝ) ≤ 4 * (P.b : ℝ) ^ 2 * e := by exact_mod_cast Int.le_of_dvd hdiv hd'
  have hf' : (0 : ℝ) < f := by exact_mod_cast hf
  have hb' : (0 : ℝ) < P.b := by exact_mod_cast hb
  have heS := small_integer_factor_square_strict (squarefreePart_abs_gt_one hn hNs) he hsmall
  calc
    (f : ℝ) ^ 2 ≤ (4 * (P.b : ℝ) ^ 2 * e) ^ 2 := pow_le_pow_left₀ hf'.le hle 2
    _ = 16 * (P.b : ℝ) ^ 4 * (e : ℝ) ^ 2 := by ring
    _ < _ := mul_lt_mul_of_pos_left heS (by positivity)

/-- Actual non-Gaussian sequence data with the two literal coefficient bounds
in (3.16), and their weaker consequence used by the later bootstrap. -/
theorem sequence_general_datum_published (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : ¬ IsSquare (-P.normAlpha))
    {k : ℤ} (hk : k ≠ 0) (hs : IsSquare (P.y h.pell k)) (hy : 0 < P.y h.pell k) :
    ∃ p : FourthPowerDatum (-squarefreePart P.normAlpha) P.b P.gapScale P.gapOmega,
      P.SequenceGapCertificate h.pell k p ∧
      p.f ^ 2 ≤ 16 * (P.b : ℝ) ^ 4 * |(P.normAlpha : ℝ)| ∧
      p.f ^ 2 < 16 * (P.b : ℝ) ^ 4 * |(squarefreePart P.normAlpha : ℝ)| ∧
      ∃ f : ℤ, p.f = (f : ℝ) ∧ f ∣ 4 * P.b ^ 2 * |squarefreePart P.normAlpha| := by
  obtain ⟨T, U, x, v, hU, hv, hp, hrep, hyv, hxy, hνk⟩ := P.sequence_square_representation_input_indexed h hk hs hy
  let Q := P.withUnit T U
  let : Fact (¬ IsSquare Q.d) := ⟨h.d_not_square⟩
  let : Fact (¬ IsSquare Q.normAlpha) := ⟨by
    rintro ⟨m, hm⟩
    change P.normAlpha = m * m at hm
    nlinarith [sq_nonneg m]⟩
  obtain ⟨ν, f, r, s, hν, hf, hF, hed, he, hsmall, hd⟩ := Q.proposition31a_published hrep
    (ne_of_gt h.a_pos) h.b_pos hv hU (Q.epsilon_isIntegral hp)
  obtain ⟨p, hpy, hpf, hpr, hps⟩ := Q.signed_representation_datum h.b_pos hn hp hv hf (Or.inl rfl) hF.signed
  have hfp : 0 < f := by have hh := p.f_pos; rw [hpf] at hh; exact_mod_cast hh
  obtain ⟨hdiv, hstrict⟩ := Q.unit_representation_coefficients_published h.b_pos hn hNs
    (Q.integer_unit_norm hp hν) hfp he hed hsmall hd
  have hSN : |(squarefreePart P.normAlpha : ℝ)| ≤ |(P.normAlpha : ℝ)| := by
    have hh := Int.natAbs_le_of_dvd_ne_zero (squarefreePart_dvd P.normAlpha) (ne_of_lt hn)
    have hi : |squarefreePart P.normAlpha| ≤ |P.normAlpha| := by
      simpa using (show ((squarefreePart P.normAlpha).natAbs : ℤ) ≤ (P.normAlpha.natAbs : ℤ) by exact_mod_cast hh)
    exact_mod_cast hi
  refine ⟨p, ⟨?_, T, U, x, v, f, 1, hU, hv, hp, hrep, hpf, Or.inl rfl, ?_, hxy, hνk⟩, ?_, ?_, f, hpf, hdiv⟩
  · rw [hpy, hyv]
    norm_cast
  · simpa only [hpr, hps] using hF.signed
  · rw [hpf]
    exact le_trans (le_of_lt hstrict) (mul_le_mul_of_nonneg_left hSN (by positivity))
  · rwa [hpf]

end Parameters
end «JNT-2024»
