module

public import «JNT-2024».ApproximationGcd
public import «JNT-2024».NormalizerOddPrimePublished
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».NormalizerTwoComponentsPublished
public import «JNT-2024».NormalizerValuationsPublished
public import «JNT-2024».RepresentationBothEvenPublished
public import «JNT-2024».RepresentationFactors
public import «JNT-2024».RepresentationGaussian
public import «JNT-2024».RepresentationMixedParityPublished
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- The initial divisibilities in Lemma 3.11(2). -/
theorem base_prime_power_divides_norm_and_square (P : Parameters) (hc : Int.gcd P.a P.b = 1)
    (p : ℕ) [Fact p.Prime] {X Y : ℤ} (he : X ^ 2 - P.d * Y ^ 2 = P.normAlpha) :
    (p : ℤ) ^ padicValNat p P.baseGcd ∣ P.normAlpha ∧
    (p : ℤ) ^ padicValNat p P.baseGcd ∣ X ^ 2 := by
  have hg : (p : ℤ) ^ padicValNat p P.baseGcd ∣ (P.baseGcd : ℤ) := by
    exact_mod_cast (pow_padicValNat_dvd (p := p) (n := P.baseGcd))
  have hga : (P.baseGcd : ℤ) ∣ P.a ^ 2 := by
    rw [P.baseGcd_eq_ad_published hc]; exact Int.gcd_dvd_left _ _
  have hgd : (P.baseGcd : ℤ) ∣ P.d := by
    rw [P.baseGcd_eq_ad_published hc]; exact Int.gcd_dvd_right _ _
  have hd := hg.trans hgd
  have hn := hg.trans hga
  have hN : (p : ℤ) ^ padicValNat p P.baseGcd ∣ P.normAlpha :=
    dvd_sub hn (dvd_mul_of_dvd_right hd (P.b ^ 4))
  refine ⟨hN, ?_⟩
  have hh := dvd_add hN (dvd_mul_of_dvd_left hd (Y ^ 2))
  convert hh using 1
  linarith only [he]

/-- The equal/unequal initial valuation alternatives used in cases (2.2.1),(2.2.2). -/
theorem initial_norm_two_valuation_cases (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha ≠ 0) :
    (padicValInt 2 (P.a ^ 2) = padicValInt 2 (P.d * P.b ^ 4) →
      padicValNat 2 P.baseGcd + 1 ≤ padicValInt 2 P.normAlpha) ∧
    (padicValInt 2 (P.a ^ 2) ≠ padicValInt 2 (P.d * P.b ^ 4) →
      padicValInt 2 P.normAlpha = padicValNat 2 P.baseGcd) := by
  have ha : P.a ^ 2 ≠ 0 := pow_ne_zero _ (ne_of_gt h.a_pos)
  have hd : P.d * P.b ^ 4 ≠ 0 := mul_ne_zero (ne_of_gt h.d_pos) (pow_ne_zero _ (ne_of_gt h.b_pos))
  have hform : P.a ^ 2 - P.d * P.b ^ 4 = P.normAlpha := by unfold normAlpha; ring
  have hg : padicValNat 2 P.baseGcd = min (padicValInt 2 (P.a ^ 2))
      (padicValInt 2 (P.d * P.b ^ 4)) := valuation_gcd 2 ha hd
  constructor
  · intro hh
    have hv := valuation_two_sub_of_eq ha hd (by simpa only [hform] using hn) hh
    rw [hform] at hv
    rw [hg, hh, min_self]
    simpa only [hh] using hv
  · intro hh
    have hv := valuation_two_add_of_ne ha (neg_ne_zero.mpr hd)
      (by simpa only [← sub_eq_add_neg, hform] using hn)
      (by simpa only [valuation_neg] using hh)
    simpa only [← sub_eq_add_neg, hform, valuation_neg, hg] using hv

/-- Lemma 3.11(2): the printed three cases give the nonnegative exponent
at two. All input divisibilities are derived from the actual sequence. -/
theorem normalizer_valuation_two_published (P : Parameters) (h : P.Admissible)
    (hc : Int.gcd P.a P.b = 1) (hn : P.normAlpha < 0) {k X Y ν : ℤ}
    (hx : P.x h.pell k = X) (hy : P.y h.pell k = Y) (hν : ν = 1 ∨ ν = -1) :
    (padicValNat 2 P.baseGcd : ℤ) ≤
      padicValRat 2 (Approximation.gSquared (squarefreePart P.normAlpha) (2 * X)
        (2 * ν * squareFactor P.normAlpha)) := by
  let C := squareFactor P.normAlpha
  let S := squarefreePart P.normAlpha
  let e := padicValNat 2 P.baseGcd
  have hC : C ≠ 0 := ne_of_gt (squareFactor_pos (ne_of_lt hn))
  have hS : Squarefree S := squarefreePart_squarefree _
  have he : X ^ 2 - P.d * Y ^ 2 = P.normAlpha := by
    have hh := P.norm_identity h.pell k
    rw [hx, hy] at hh
    exact_mod_cast hh
  have hd := P.base_prime_power_divides_norm_and_square hc 2 he
  have hN : C ^ 2 * S = P.normAlpha := squareFactor_sq_mul _
  have hvN : padicValInt 2 P.normAlpha = 2 * padicValInt 2 C + padicValInt 2 S := by
    rw [← hN, padicValInt.mul (pow_ne_zero _ hC) hS.ne_zero, valuation_int_pow]
  have hnv : e ≤ padicValInt 2 P.normAlpha :=
    ((padicValInt_dvd_iff _ _).mp hd.1).resolve_left (ne_of_lt hn)
  have hs := valuation_squarefree_le_one 2 hS
  have hu : 2 * ν * C ≠ 0 := by rcases hν with rfl | rfl <;> simpa using hC
  have hv := Approximation.gSquared_valuation_published 2 hS.ne_zero hu (u₁ := 2 * X)
  have hg₃ := Approximation.g3_two_valuation_le S (2 * X) (2 * ν * C)
  change (e : ℤ) ≤ padicValRat 2 (Approximation.gSquared S (2 * X) (2 * ν * C))
  rw [hv]
  by_cases hs₀ : padicValInt 2 S = 0
  · have hC₂ : (2 : ℤ) ^ e ∣ C ^ 2 := (padicValInt_dvd_iff _ _).mpr
      (Or.inr (by rw [valuation_int_pow]; simp only [padicValInt] at hvN hnv hs₀ ⊢; omega))
    have hl := Approximation.g1_square_two_lower_of_square_divides hC hν e hC₂ hd.2
    have hl₂ := Approximation.g2_valuation_le_squarefree_published 2 hS.ne_zero
      (u₁ := 2 * X) (u₂ := 2 * ν * C)
    omega
  have hs₁ : padicValInt 2 S = 1 := by omega
  have hSe : Even S := even_iff_two_dvd.mpr
    ((prime_dvd_iff_valuation_pos 2 hS.ne_zero).mpr (by omega))
  have hg₃₄ := Approximation.g3_eq_four_of_even_published hSe (2 * X) (2 * ν * C)
  by_cases heq : padicValInt 2 (P.a ^ 2) = padicValInt 2 (P.d * P.b ^ 4)
  · have hn' := (P.initial_norm_two_valuation_cases h (ne_of_lt hn)).1 heq
    have hC₂ : (2 : ℤ) ^ e ∣ C ^ 2 := (padicValInt_dvd_iff _ _).mpr
      (Or.inr (by rw [valuation_int_pow]; dsimp [e]; omega))
    have hl := Approximation.g1_square_two_lower_of_square_divides hC hν e hC₂ hd.2
    omega
  · have hn' := (P.initial_norm_two_valuation_cases h (ne_of_lt hn)).2 heq
    have hl := Approximation.normalizer_two_unequal_components hS hC hν hs₁ e
      (by rw [hN]; exact hn') hd.2
    rw [hl.2.1, hl.2.2, hg₃₄]
    rw [show 4 = 2 ^ 2 by decide, padicValNat.pow]
    norm_num
    omega

end «JNT-2024».Parameters
