module

public import «JNT-2024».EulerBeta
public import «JNT-2024».EulerIntegral
public import «JNT-2024».HypergeometricPolynomials
public import «JNT-2024».RemainderCoefficients
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

def remainderPrefactor (ν : ℚ) (r : ℕ) : ℚ :=
  risingQ ν (r + 1) * r.factorial / (2 * r + 1).factorial

theorem remainderPrefactor_quarter (r : ℕ) :
    remainderPrefactor (1 / 4) r = remainderCoefficient r := by
  simp only [remainderPrefactor, remainderCoefficient, risingQ_eq_pochhammer]

theorem remainderPrefactor_pos {ν : ℚ} (hν : 0 < ν) (r : ℕ) :
    0 < remainderPrefactor ν r := by
  have hh : 0 < risingQ ν (r + 1) := by
    rw [risingQ_eq_pochhammer]
    exact ascPochhammer_pos _ _ hν
  unfold remainderPrefactor
  positivity


theorem risingQ_eq_gamma {ν : ℚ} (hν : 0 < ν) (j : ℕ) :
    (risingQ ν j : ℝ) = Real.Gamma ((ν : ℝ) + j) / Real.Gamma (ν : ℝ) := by
  have hv : (0 : ℝ) < ν := by exact_mod_cast hν
  have hg := ne_of_gt (Real.Gamma_pos_of_pos hv)
  induction j with
  | zero => simp [risingQ, hg]
  | succ j ih =>
    have hj : (0 : ℝ) < ν + j := by positivity
    rw [show (ν : ℝ) + ((j + 1 : ℕ) : ℝ) = (ν + j) + 1 by push_cast; ring,
      Real.Gamma_add_one (ne_of_gt hj)]
    simp only [risingQ_eq_pochhammer, ascPochhammer_succ_eval, Rat.cast_mul,
      Rat.cast_add, Rat.cast_natCast] at ih ⊢
    rw [ih]
    ring

theorem remainderIntegralFactor_eq_gamma {ν : ℚ} (hν : 0 < ν) (r : ℕ) :
    (risingQ ν (r + 1) : ℂ) / r.factorial =
      ((Real.Gamma ((r : ℝ) + 1 + ν) / ((r.factorial : ℝ) * Real.Gamma (ν : ℝ)) : ℝ) : ℂ) := by
  have hh := risingQ_eq_gamma hν (r + 1)
  have he : (ν : ℝ) + ((r + 1 : ℕ) : ℝ) = r + 1 + ν := by push_cast; ring
  rw [he] at hh
  have he' : (risingQ ν (r + 1) : ℝ) / r.factorial =
      Real.Gamma ((r : ℝ) + 1 + ν) / ((r.factorial : ℝ) * Real.Gamma (ν : ℝ)) := by rw [hh]; ring
  exact_mod_cast he'

/-- The paper's remainder, continued from its hypergeometric series by Euler's integral.
Agreement with the series is proved below; the approximation-error identity is a separate task. -/
noncomputable def remainder (ν : ℚ) (r : ℕ) (z : ℂ) : ℂ :=
  (z - 1) ^ (2 * r + 1) * (remainderPrefactor ν r : ℂ) *
    eulerHypergeometric (r + 1 - ν) r z

theorem remainder_eq_hypergeometric (ν : ℚ) (r : ℕ) {z : ℂ} (hz : ‖z - 1‖ < 1) :
    remainder ν r z = (z - 1) ^ (2 * r + 1) * (remainderPrefactor ν r : ℂ) *
      ₂F₁ (r + 1 - (ν : ℂ)) (r + 1) (2 * r + 2) (1 - z) := by
  rw [remainder, eulerHypergeometric_eq_series _ _ (by simpa only [norm_sub_rev] using hz)]

theorem remainderPrefactor_mul_normalizer (ν : ℚ) (r : ℕ) :
    (remainderPrefactor ν r : ℂ) * eulerNormalizer r =
      (risingQ ν (r + 1) : ℂ) / r.factorial := by
  have hf : (r.factorial : ℂ) ≠ 0 := by exact_mod_cast Nat.factorial_ne_zero r
  have hg : ((2 * r + 1).factorial : ℂ) ≠ 0 := by exact_mod_cast Nat.factorial_ne_zero _
  simp only [remainderPrefactor, eulerNormalizer, Rat.cast_div, Rat.cast_mul, Rat.cast_natCast]
  field_simp

theorem remainder_eq_eulerIntegral (ν : ℚ) (r : ℕ) (z : ℂ) :
    remainder ν r z = (risingQ ν (r + 1) : ℂ) / r.factorial * (z - 1) ^ (2 * r + 1) *
      ∫ t : ℝ in 0..1, eulerKernel (r + 1 - (ν : ℂ)) r z t := by
  unfold remainder eulerHypergeometric
  rw [show (z - 1) ^ (2 * r + 1) * (remainderPrefactor ν r : ℂ) *
      (eulerNormalizer r * ∫ t : ℝ in 0..1, eulerKernel (r + 1 - (ν : ℂ)) r z t) =
      ((remainderPrefactor ν r : ℂ) * eulerNormalizer r) * (z - 1) ^ (2 * r + 1) *
      ∫ t : ℝ in 0..1, eulerKernel (r + 1 - (ν : ℂ)) r z t by ring]
  rw [remainderPrefactor_mul_normalizer]

theorem chord_remainder_integrand (ν : ℚ) (r : ℕ) (z : ℂ) (t : ℝ) :
    (1 - chord z t) ^ r * (chord z t - z) ^ r *
        chord z t ^ ((ν : ℂ) - r - 1) * (z - 1) =
      (z - 1) ^ (2 * r + 1) * eulerKernel (r + 1 - (ν : ℂ)) r z t := by
  have he : (1 - chord z t) * (chord z t - z) =
      (z - 1) ^ 2 * (t : ℂ) * (1 - (t : ℂ)) := by unfold chord; ring
  rw [← mul_pow, he]
  simp only [eulerKernel, mul_pow, pow_mul, pow_succ,
    show -((r : ℂ) + 1 - ν) = (ν : ℂ) - r - 1 by ring]
  ring

/-- The exact straight-segment integral used for the later error identity and contour estimate. -/
theorem remainder_eq_segmentIntegral (ν : ℚ) (r : ℕ) (z : ℂ) :
    remainder ν r z = (risingQ ν (r + 1) : ℂ) / r.factorial *
      ∫ t : ℝ in 0..1, (1 - chord z t) ^ r * (chord z t - z) ^ r *
        chord z t ^ ((ν : ℂ) - r - 1) * (z - 1) := by
  simp_rw [chord_remainder_integrand]
  rw [intervalIntegral.integral_const_mul, remainder_eq_eulerIntegral]
  ring


theorem remainder_eq_gamma_segmentIntegral {ν : ℚ} (hν : 0 < ν) (r : ℕ) (z : ℂ) :
    remainder ν r z =
      ((Real.Gamma ((r : ℝ) + 1 + ν) / ((r.factorial : ℝ) * Real.Gamma (ν : ℝ)) : ℝ) : ℂ) *
      ∫ t : ℝ in 0..1, (1 - chord z t) ^ r * (chord z t - z) ^ r *
        chord z t ^ ((ν : ℂ) - r - 1) * (z - 1) := by
  rw [remainder_eq_segmentIntegral, remainderIntegralFactor_eq_gamma hν]


theorem unit_rightHalf_mem_slitPlane {ω : ℂ} (hω : ‖ω‖ = 1) (hre : 0 ≤ ω.re) :
    ω ∈ Complex.slitPlane := by
  by_cases hh : 0 < ω.re
  · exact Or.inl hh
  · right
    intro hi
    have he : ω = 0 := Complex.ext (by simp only [Complex.zero_re]; linarith) hi
    simp [he] at hω

/-- The complex-power convention coincides with the one fixed in Section 2.1 of the paper. -/
theorem cpow_eq_principal_phase (ν : ℚ) {ω : ℂ} (hω : ‖ω‖ = 1) :
    ω ^ (ν : ℂ) = Complex.exp (Complex.I * (((ν : ℝ) * ω.arg : ℝ) : ℂ)) := by
  have hne : ω ≠ 0 := by intro he; simp [he] at hω
  have hl : Complex.log ω = (ω.arg : ℂ) * Complex.I := by
    apply Complex.ext <;> simp [Complex.log_re, Complex.log_im, hω]
  rw [Complex.cpow_def_of_ne_zero hne, hl]
  congr 1
  push_cast
  ring

theorem remainder_zero_index (ν : ℚ) {z : ℂ} (hz : z ∈ Complex.slitPlane) :
    remainder ν 0 z = z ^ (ν : ℂ) - 1 := by
  have hc : ContinuousOn (fun t : ℝ => (ν : ℂ) * (1 + t • (z - 1)) ^ ((ν : ℂ) - 1))
      (Set.Icc 0 1) := by
    apply ContinuousOn.mul continuousOn_const
    apply ContinuousOn.cpow (by fun_prop) continuousOn_const
    intro t ht
    exact StarConvex.add_smul_mem Complex.starConvex_one_slitPlane (by simpa using hz) ht.1 ht.2
  have hh := intervalIntegral.integral_unitInterval_deriv_eq_sub
    (f := fun w : ℂ => w ^ (ν : ℂ)) (f' := fun w => (ν : ℂ) * w ^ ((ν : ℂ) - 1))
    (z₀ := 1) (z₁ := z - 1) hc (fun t ht => by
      simpa using (hasDerivAt_id (1 + t • (z - 1))).cpow_const (c := (ν : ℂ))
        (StarConvex.add_smul_mem Complex.starConvex_one_slitPlane (by simpa using hz) ht.1 ht.2))
  simp only [smul_eq_mul, intervalIntegral.integral_const_mul, add_sub_cancel,
    Complex.one_cpow] at hh
  rw [remainder_eq_eulerIntegral]
  norm_num [risingQ, eulerKernel]
  convert hh using 1
  simp only [chord, Complex.real_smul, mul_comm (z - 1)]
  ring

end Hypergeometric
end «JNT-2024»
