module

public import «JNT-2024».Sequence
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»


namespace Parameters

def baseGcd (P : Parameters) : ℕ := Int.gcd (P.a ^ 2) (P.d * P.b ^ 4)

theorem baseGcd_eq (P : Parameters) (hc : Int.gcd P.a P.b = 1) :
    P.baseGcd = Int.gcd P.normAlpha P.d := by
  have hcop : Int.gcd (P.a ^ 2) (P.b ^ 4) = 1 :=
    Int.isCoprime_iff_gcd_eq_one.mp ((Int.isCoprime_iff_gcd_eq_one.mpr hc).pow_left.pow_right)
  unfold baseGcd normAlpha
  rw [Int.gcd_mul_left_right_of_gcd_eq_one hcop, Int.gcd_sub_mul_right_left]

theorem baseGcd_pos (P : Parameters) (ha : P.a ≠ 0) : 0 < P.baseGcd :=
  Int.gcd_pos_of_ne_zero_left _ (pow_ne_zero _ ha)


end Parameters
end «JNT-2024»
