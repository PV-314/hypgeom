module

public import «JNT-2024».FourthRootGeometry
public import «JNT-2024».GapPhaseAlgebra
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

noncomputable def quadraticPoint (D r s : ℤ) : ℂ := ⟨r, s * Real.sqrt D⟩

theorem int_square_zero_or_one (n : ℤ) : (n : ℝ) ^ 2 = 0 ∨ 1 ≤ (n : ℝ) ^ 2 := by
  by_cases hn : n = 0
  · simp [hn]
  · right
    have hh : 1 ≤ n ^ 2 := by nlinarith [sq_pos_of_ne_zero hn]
    exact_mod_cast hh

theorem quadratic_cross_coordinates (D r s R S : ℤ) (hD : 0 ≤ D) :
    quadraticPoint D r s * star (quadraticPoint D R S) =
      (⟨(r * R + D * s * S : ℤ), (s * R - r * S : ℤ) * Real.sqrt D⟩ : ℂ) := by
  have hh := Real.sq_sqrt (show (0 : ℝ) ≤ D by exact_mod_cast hD)
  have hm := congrArg (fun x : ℝ => (s : ℝ) * S * x) hh
  apply Complex.ext <;> simp [quadraticPoint] <;> nlinarith only [hm]

/-- The two phase classes modulo sign, used for the three-point pigeonhole argument. -/
def SamePhaseClass (ζ η : ℂ) : Prop := ζ = η ∨ ζ = -η

theorem three_phases (ζ₁ ζ₂ ζ₃ : ℂ) (h₁ : FourthPhase ζ₁) (h₂ : FourthPhase ζ₂)
    (h₃ : FourthPhase ζ₃) :
    SamePhaseClass ζ₁ ζ₂ ∨ SamePhaseClass ζ₁ ζ₃ ∨ SamePhaseClass ζ₂ ζ₃ := by
  rcases h₁ with rfl | rfl | rfl | rfl <;>
    rcases h₂ with rfl | rfl | rfl | rfl <;>
    rcases h₃ with rfl | rfl | rfl | rfl <;> simp [SamePhaseClass]

theorem quadratic_parallel_separation {D A B : ℤ} {ζ η : ℂ} (hD : 0 < D)
    (_hζ : FourthPhase ζ) (hη : FourthPhase η) (hclass : SamePhaseClass ζ η)
    (hne : ζ * (⟨A, B * Real.sqrt D⟩ : ℂ) - η * star (⟨A, B * Real.sqrt D⟩ : ℂ) ≠ 0) :
    4 ≤ ‖ζ * (⟨A, B * Real.sqrt D⟩ : ℂ) - η * star (⟨A, B * Real.sqrt D⟩ : ℂ)‖ ^ 2 := by
  have hDr : (1 : ℝ) ≤ D := by exact_mod_cast hD
  have hroot := Real.sq_sqrt (show (0 : ℝ) ≤ D by linarith)
  rcases hclass with he | he
  · rw [he] at hne ⊢
    have heq : η * (⟨A, B * Real.sqrt D⟩ : ℂ) - η * star (⟨A, B * Real.sqrt D⟩ : ℂ) =
        η * (⟨0, 2 * B * Real.sqrt D⟩ : ℂ) := by
      rw [← mul_sub]; congr 1; apply Complex.ext <;> simp; ring
    rw [heq] at hne ⊢
    rw [norm_mul, hη.norm, one_mul, ← Complex.normSq_eq_norm_sq]
    have hB : B ≠ 0 := by
      intro hh
      apply hne
      have hz : (⟨0, 2 * B * Real.sqrt D⟩ : ℂ) = 0 := by
        apply Complex.ext <;> simp [hh]
      rw [hz, mul_zero]
    have hBsq : (1 : ℝ) ≤ (B : ℝ) ^ 2 := (int_square_zero_or_one B).resolve_left (by positivity)
    simp only [Complex.normSq_apply, zero_mul, zero_add]
    nlinarith [mul_nonneg (sub_nonneg.mpr hDr) (sq_nonneg (B : ℝ))]
  · rw [he] at hne ⊢
    have heq : -η * (⟨A, B * Real.sqrt D⟩ : ℂ) - η * star (⟨A, B * Real.sqrt D⟩ : ℂ) =
        -η * (⟨2 * A, 0⟩ : ℂ) := by
      apply Complex.ext <;> simp <;> ring
    rw [heq] at hne ⊢
    rw [norm_mul, norm_neg, hη.norm, one_mul, ← Complex.normSq_eq_norm_sq]
    have hA : A ≠ 0 := by
      intro hh
      apply hne
      have hz : (⟨2 * A, 0⟩ : ℂ) = 0 := by apply Complex.ext <;> simp [hh]
      rw [hz, mul_zero]
    have hAsq : (1 : ℝ) ≤ (A : ℝ) ^ 2 := (int_square_zero_or_one A).resolve_left (by positivity)
    simp only [Complex.normSq_apply, mul_zero, add_zero]
    nlinarith

/-- The published Gaussian argument: divide the nonzero numerator by 1+i
in the Gaussian integers, whose nonzero elements have norm at least one. -/
theorem gaussian_phase_separation {A B : ℤ} {ζ η : ℂ}
    (hζ : FourthPhase ζ) (hη : FourthPhase η)
    (hne : ζ * (⟨A, B⟩ : ℂ) - η * star (⟨A, B⟩ : ℂ) ≠ 0) :
    2 ≤ ‖ζ * (⟨A, B⟩ : ℂ) - η * star (⟨A, B⟩ : ℂ)‖ ^ 2 := by
  obtain ⟨a, b, he⟩ := gaussian_phase_divisible_one_add_I hζ hη
  have hn : (⟨a, b⟩ : ℂ) ≠ 0 := by
    intro hz
    apply hne
    rw [he, hz, mul_zero]
  have hp : 0 < ‖(⟨a, b⟩ : ℂ)‖ ^ 2 := sq_pos_of_pos (norm_pos_iff.mpr hn)
  rw [Complex.sq_norm] at hp
  simp only [Complex.normSq_apply] at hp
  have hi : 0 < a * a + b * b := by exact_mod_cast hp
  have hi1 : (1 : ℝ) ≤ (a : ℝ) ^ 2 + (b : ℝ) ^ 2 := by
    exact_mod_cast (show (1 : ℤ) ≤ a ^ 2 + b ^ 2 by nlinarith)
  have htwo : ‖(1 : ℂ) + Complex.I‖ ^ 2 = 2 := by
    norm_num [Complex.sq_norm, Complex.normSq_apply]
  rw [he, norm_mul, mul_pow, htwo, Complex.sq_norm]
  simp only [Complex.normSq_apply]
  nlinarith

end «JNT-2024»
