module

public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

/-- The ratio of the two sides of Section 4.5's exponential comparison has
its minimum at r=3. This uses two rational checks and monotonicity thereafter. -/
theorem exponential_ratio_minimum_squared {r : ℕ} (hr : 1 ≤ r) :
    (r : ℝ)*(1832/1750 : ℝ)^24 ≤ 3*(1832/1750 : ℝ)^(8*r) := by
  by_cases hsmall : r < 3
  · interval_cases r <;> norm_num at hr ⊢
  · have hthree : 3 ≤ r := by omega
    clear hr hsmall
    induction r, hthree using Nat.le_induction with
    | base => norm_num
    | succ r hr ih =>
      have hq : (4/3 : ℝ) < (1832/1750 : ℝ)^8 := by norm_num
      have hrR : (3 : ℝ) ≤ r := by exact_mod_cast hr
      have hstep : (r:ℝ)+1 ≤ r*(1832/1750 : ℝ)^8 := by
        nlinarith [mul_lt_mul_of_pos_left hq (show (0:ℝ)<r by linarith)]
      have hh := mul_le_mul_of_nonneg_right hstep (by positivity : 0 ≤ (1832/1750 : ℝ)^24)
      have hm := mul_le_mul_of_nonneg_right ih (by positivity : 0 ≤ (1832/1750 : ℝ)^8)
      push_cast
      rw [show 8*(r+1)=8*r+8 by omega,pow_add]
      nlinarith only [hh,hm]

/-- The minimum assertion with square roots, for the ratio
((0.1832)^(4r)/sqrt(r))/(0.175)^(4r). -/
theorem exponential_ratio_minimum {r : ℕ} (hr : 1 ≤ r) :
    (1832/1750 : ℝ)^12/Real.sqrt 3 ≤
      (1832/1750 : ℝ)^(4*r)/Real.sqrt r := by
  have hrR : (0:ℝ)<r := by exact_mod_cast (by omega : 0<r)
  apply (sq_le_sq₀ (by positivity) (by positivity)).mp
  conv_lhs => rw [div_pow]
  conv_rhs => rw [div_pow]
  rw [Real.sq_sqrt (by norm_num : (0:ℝ)≤3),
    Real.sq_sqrt hrR.le,← pow_mul,← pow_mul]
  apply (div_le_div_iff₀ (by norm_num : (0:ℝ)<3) hrR).mpr
  convert exponential_ratio_minimum_squared hr using 1 <;> ring_nf

/-- The printed comparison, now explicitly using the attained minimum at 3. -/
theorem section45_exponential_bound_printed {r : ℕ} (hr : 1 ≤ r) :
    (175/1000 : ℝ)^(4*r)*Real.sqrt r < (1832/10000 : ℝ)^(4*r) := by
  have hm := exponential_ratio_minimum_squared hr
  have hthree : (3:ℝ)<(1832/1750 : ℝ)^24 := by norm_num
  have hrR : (0:ℝ)<r := by exact_mod_cast (by omega : 0<r)
  have hh : (r:ℝ)<(1832/1750 : ℝ)^(8*r) := by
    nlinarith only [hm,mul_lt_mul_of_pos_left hthree hrR]
  rw [show (1832/1750 : ℝ)=(1832/10000)/(175/1000) by norm_num,div_pow] at hh
  have hh' := (lt_div_iff₀ (by positivity : 0<(175/1000 : ℝ)^(8*r))).mp hh
  apply (sq_lt_sq₀ (by positivity) (by positivity)).mp
  rw [mul_pow,Real.sq_sqrt hrR.le,← pow_mul,← pow_mul,
    show 4*r*2=8*r by omega]
  simpa only [mul_comm] using hh'

end «JNT-2024».Section4
