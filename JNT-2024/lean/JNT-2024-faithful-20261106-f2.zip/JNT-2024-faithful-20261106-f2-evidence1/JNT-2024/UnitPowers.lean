module

public import «JNT-2024».Sequence
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- The rational norm of the unit `ε`. -/
def epsilonNorm (P : Parameters) : ℚ :=
  ((P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2) / 4

theorem norm_epsilon (P : Parameters) : QuadraticAlgebra.norm P.epsilon = P.epsilonNorm := by
  simp [QuadraticAlgebra.norm, epsilon, epsilonNorm]
  ring

theorem epsilonNorm_eq_one (P : Parameters) (hp : P.t ^ 2 - P.d * P.u ^ 2 = 4) :
    P.epsilonNorm = 1 := by
  have hq : (P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2 = 4 := by exact_mod_cast hp
  simp [epsilonNorm, hq]

theorem epsilonNorm_eq_neg_one (P : Parameters) (hp : P.t ^ 2 - P.d * P.u ^ 2 = -4) :
    P.epsilonNorm = -1 := by
  have hq : (P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2 = -4 := by exact_mod_cast hp
  simp [epsilonNorm, hq]

theorem epsilonNorm_eq_one_iff (P : Parameters) :
    P.epsilonNorm = 1 ↔ P.t ^ 2 - P.d * P.u ^ 2 = 4 := by
  constructor
  · intro hp
    have hq : (P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2 = 4 := by
      unfold epsilonNorm at hp
      linarith
    exact_mod_cast hq
  · exact P.epsilonNorm_eq_one

theorem epsilon_im_recurrence (P : Parameters) (n : ℕ) :
    (P.epsilon ^ (n + 2)).im = P.t * (P.epsilon ^ (n + 1)).im -
      P.epsilonNorm * (P.epsilon ^ n).im := by
  simp [pow_succ, epsilon, epsilonNorm]
  ring

/-- The coefficients `uₙ` of `εⁿ` are nonnegative and nondecreasing. -/
theorem epsilon_im_nonneg_and_le_succ (P : Parameters) (h : P.Admissible) (n : ℕ) :
    0 ≤ (P.epsilon ^ n).im ∧ (P.epsilon ^ n).im ≤ (P.epsilon ^ (n + 1)).im := by
  have hu : (0 : ℚ) < P.u := by exact_mod_cast h.u_pos
  induction n with
  | zero => simp [epsilon, QuadraticAlgebra.im_one]; linarith
  | succ n ih =>
    have hp : 0 ≤ (P.epsilon ^ (n + 1)).im := le_trans ih.1 ih.2
    refine ⟨hp, ?_⟩
    change (P.epsilon ^ (n + 1)).im ≤ (P.epsilon ^ (n + 2)).im
    rw [P.epsilon_im_recurrence]
    rcases h.pell with he | he
    · rw [P.epsilonNorm_eq_one he]
      have hdu := mul_pos h.d_pos (sq_pos_of_pos h.u_pos)
      have ht : 2 ≤ P.t := by nlinarith [h.t_pos]
      have htq : (2 : ℚ) ≤ P.t := by exact_mod_cast ht
      nlinarith [ih.1, ih.2, mul_nonneg (sub_nonneg.mpr htq) hp]
    · rw [P.epsilonNorm_eq_neg_one he]
      have ht : (1 : ℚ) ≤ P.t := by exact_mod_cast h.t_pos
      nlinarith [ih.1, ih.2, mul_nonneg (sub_nonneg.mpr ht) hp]

theorem epsilon_im_monotone (P : Parameters) (h : P.Admissible) :
    Monotone (fun n : ℕ => (P.epsilon ^ n).im) :=
  monotone_nat_of_le_succ (fun n => (P.epsilon_im_nonneg_and_le_succ h n).2)

theorem epsilon_im_lower (P : Parameters) (h : P.Admissible) (n : ℕ) (hn : 1 ≤ n) :
    (P.u : ℚ) / 2 ≤ (P.epsilon ^ n).im := by
  simpa [epsilon] using P.epsilon_im_monotone h hn

theorem backStep_eq_star_epsilon_sq (P : Parameters) : P.backStep = (star P.epsilon) ^ 2 := by
  ext <;> simp [backStep, epsilon, pow_two] <;> ring

theorem term_neg_nat (P : Parameters) (h : P.Pell) (n : ℕ) :
    P.term h (-(n : ℤ)) = P.alpha * (star (P.epsilon ^ n)) ^ 2 := by
  have hp : P.backStep ^ n = (star (P.epsilon ^ n)) ^ 2 := by
    rw [P.backStep_eq_star_epsilon_sq, star_pow, ← pow_mul, ← pow_mul, Nat.mul_comm]
  simpa [term, zpow_neg, inv_pow, stepUnit] using congrArg (P.alpha * ·) hp

theorem term_nat (P : Parameters) (h : P.Pell) (n : ℕ) :
    P.term h (n : ℤ) = P.alpha * P.epsilon ^ (2 * n) := by
  simp [term, stepUnit, P.step_eq_epsilon_sq, pow_mul]

/-- The square-completion identity used for every negative index in 3.5(c). -/
theorem complete_square_negative (P : Parameters) (h : P.Pell) (n : ℕ) :
    (P.b : ℚ) ^ 2 * P.y h (-(n : ℤ)) =
      ((P.b : ℚ) ^ 2 * (P.epsilon ^ n).re - P.a * (P.epsilon ^ n).im) ^ 2 -
      P.normAlpha * (P.epsilon ^ n).im ^ 2 := by
  unfold y
  rw [P.term_neg_nat]
  simp only [pow_two, QuadraticAlgebra.im_mul, QuadraticAlgebra.re_mul,
    QuadraticAlgebra.re_star, QuadraticAlgebra.im_star]
  simp [alpha, normAlpha]
  ring

end «JNT-2024».Parameters
