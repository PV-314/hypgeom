module

public import «JNT-2024».NormalizerBounds
public import «JNT-2024».NormalizerFormula
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».Section5GcdNormalization
public import «JNT-2024».Section5ResidueTransfer
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.Deriv.MeanValue
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section5

set_option synthInstance.maxSize 1000

/-- Initial modulo-three consequences in Lemma 5.5(1). -/
theorem lemma55_mod_three_seed : ∀ a n t u : ZMod 3,
    u ≠ 0 → t^2-(a^2+n^2)*u^2=4 → u^2=1 ∧ a^2+n^2=t^2-1 := by decide +kernel

/-- The printed 3|t branch: both squares are 1 and both adjacent expressions 2. -/
theorem lemma55_mod_three_zero : ∀ a n t u : ZMod 3,
    u^2=1 → a^2+n^2=t^2-1 → t=0 →
    a^2=1 ∧ n^2=1 ∧
    t^2+(a^2+n^2)*u^2+2*a*t*u=2 ∧
    t^2+(a^2+n^2)*u^2-2*a*t*u=2 := by decide +kernel

/-- The surviving branch: t^2=1 and d,a,sqrt(abs(N)) all vanish modulo 3. -/
theorem lemma55_mod_three_nonzero : ∀ a n t : ZMod 3,
    a^2+n^2=t^2-1 → t ≠ 0 → t^2=1 ∧ a^2+n^2=0 ∧ a=0 ∧ n=0 := by decide +kernel

theorem lemma55_two_not_square_three : ¬ IsSquare (2:ZMod 3) := by decide +kernel

/-- The printed branch argument, assembled from its intermediate assertions. -/
theorem lemma55_mod_three (a n t u : ZMod 3) (hu : u ≠ 0)
    (hp : t^2-(a^2+n^2)*u^2=4)
    (hs : IsSquare (t^2+(a^2+n^2)*u^2+2*a*t*u) ∨
      IsSquare (t^2+(a^2+n^2)*u^2-2*a*t*u)) :
    u^2=1 ∧ t ≠ 0 ∧ t^2=1 ∧ a^2+n^2=0 ∧ a=0 ∧ n=0 := by
  obtain ⟨hu2,hd⟩ := lemma55_mod_three_seed a n t u hu hp
  have ht : t ≠ 0 := by
    intro ht
    obtain ⟨_,_,he,hf⟩ := lemma55_mod_three_zero a n t u hu2 hd ht
    rcases hs with hs | hs
    · rw [he] at hs; exact lemma55_two_not_square_three hs
    · rw [hf] at hs; exact lemma55_two_not_square_three hs
  exact ⟨hu2,ht,lemma55_mod_three_nonzero a n t hd ht⟩

end «JNT-2024».Section5

namespace «JNT-2024».Parameters

/-- All the printed divisibility conclusions, valid also for the later even-norm
applications of this same argument. -/
theorem lemma55_plus_divisibility (P : Parameters) (hp : P.Pell) (hb : P.b=1)
    {n : ℤ} (hn : -P.normAlpha=n^2) (he : P.t^2-P.d*P.u^2=4)
    (hu : P.u % 3 ≠ 0) (hs : P.AdjacentSquare hp) :
    P.t % 3 ≠ 0 ∧ 3 ∣ P.d ∧ 3 ∣ P.a ∧ 3 ∣ n ∧ 9 ∣ P.baseGcd := by
  have hd : P.d=P.a^2+n^2 := by simp only [normAlpha,hb,one_pow,one_mul] at hn; linarith
  have hpel := congrArg (fun x:ℤ => (x:ZMod 3)) he
  have hdm := congrArg (fun x:ℤ => (x:ZMod 3)) hd
  push_cast at hpel hdm
  rw [hdm] at hpel
  have hum : (P.u:ZMod 3) ≠ 0 := by
    intro hh
    have hv := ZMod.val_intCast (n:=3) P.u
    rw [hh] at hv
    norm_num at hv
    omega
  have hm := Section5.lemma55_mod_three (P.a:ZMod 3) n P.t P.u hum hpel (by
    obtain ⟨v,hv | hv⟩ := P.section5_adjacent_equations hp hb hs
    · left
      have hv' := congrArg (fun x:ℤ => (x:ZMod 3)) hv
      push_cast at hv'
      rw [hdm] at hv'
      refine ⟨2*(v:ZMod 3),?_⟩
      rw [hv']; ring
    · right
      have hv' := congrArg (fun x:ℤ => (x:ZMod 3)) hv
      push_cast at hv'
      rw [hdm] at hv'
      refine ⟨2*(v:ZMod 3),?_⟩
      rw [hv']; ring)
  have ha0 := ZMod.val_intCast (n:=3) P.a
  have hn0 := ZMod.val_intCast (n:=3) n
  have hd0 := ZMod.val_intCast (n:=3) P.d
  rw [hm.2.2.2.2.1] at ha0
  rw [hm.2.2.2.2.2] at hn0
  rw [hdm,hm.2.2.2.1] at hd0
  norm_num at ha0 hn0 hd0
  have ha3 : (3:ℤ) ∣ P.a := Int.dvd_of_emod_eq_zero ha0.symm
  have hn3 : (3:ℤ) ∣ n := Int.dvd_of_emod_eq_zero hn0.symm
  have hg3 : 3 ∣ Int.gcd P.a n := Int.dvd_gcd ha3 hn3
  refine ⟨?_,Int.dvd_of_emod_eq_zero hd0.symm,ha3,hn3,?_⟩
  · intro ht
    have hv := ZMod.val_intCast (n:=3) P.t
    have hv0 : (P.t:ZMod 3).val=0 := by omega
    exact hm.2.1 ((ZMod.val_eq_zero _).mp hv0)
  · rw [P.section5_baseGcd hb hn]
    exact pow_dvd_pow_of_dvd hg3 2

/-- For odd norm the normalized square root b' is odd, and (3.36) is exactly
M^2=4 gcd(a^2,d). -/
theorem lemma55_odd_normalizer (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hNs : IsSquare (-P.normAlpha)) (ho : Odd (-P.normAlpha)) :
    Odd P.normQuotient ∧ P.normalizerSquare=4*P.baseGcd := by
  obtain ⟨n,hn⟩ := hNs
  have hn2 : -P.normAlpha=n^2 := by simpa [pow_two] using hn
  obtain ⟨g,A,b,_,_,_,hnb,hG,hq,hB,_⟩ := P.section5_normalized_coordinates h hb hn2
  have hno : Odd n := by have hh : Odd (n^2) := hn2 ▸ ho; simpa [Int.odd_pow] using hh
  have hbo : Odd b := (Int.odd_mul.mp (hnb ▸ hno)).2
  have hgc : Int.gcd 16 (b^2)=1 := by
    have hh := (Nat.coprime_two_left.mpr (show Odd (b^2) from hbo.pow).natAbs).pow_left 4
    simpa [Int.gcd_eq_natAbs_gcd_natAbs] using hh
  constructor
  · simpa [hq] using (show Odd (b^2) from hbo.pow).neg
  · rw [hB,hgc,hG,mul_one]


end «JNT-2024».Parameters

