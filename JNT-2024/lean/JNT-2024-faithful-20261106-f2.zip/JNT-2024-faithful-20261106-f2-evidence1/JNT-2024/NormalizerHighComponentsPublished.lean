module

public import «JNT-2024».ApproximationGcd
public import «JNT-2024».NormalizerHighInitialPublished
public import «JNT-2024».NormalizerHighParityPublished
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».NormalizerValuationsPublished
public import «JNT-2024».RepresentationFactors
public import «JNT-2024».RepresentationGaussian
public import «JNT-2024».RepresentationMixedParityPublished
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Approximation

theorem normalized_difference_quotient_published (X C ν : ℤ) (hC : C ≠ 0)
    (hν : ν = 1 ∨ ν = -1) :
    (2 * X - 2 * ν * C) / (g1 (2 * X) (2 * ν * C) : ℤ) =
      X / (Int.gcd X C : ℤ) - ν * (C / (Int.gcd X C : ℤ)) := by
  let G : ℤ := Int.gcd X C
  have hG : G ≠ 0 := by
    change (Int.gcd X C : ℤ) ≠ 0
    exact_mod_cast ne_of_gt (Int.gcd_pos_of_ne_zero_right X hC)
  have hx : G * (X / G) = X := Int.mul_ediv_cancel' (Int.gcd_dvd_left X C)
  have hc : G * (C / G) = C := Int.mul_ediv_cancel' (Int.gcd_dvd_right X C)
  rw [g1_unit X C ν hν]
  push_cast
  change (2 * X - 2 * ν * C) / (2 * G) = X / G - ν * (C / G)
  have he : 2 * X - 2 * ν * C = (X / G - ν * (C / G)) * (2 * G) := by
    calc
      _ = 2 * (G * (X / G)) - 2 * ν * (G * (C / G)) := by rw [hx,hc]
      _ = _ := by ring
  rw [he, Int.mul_ediv_cancel _ (mul_ne_zero (by norm_num) hG)]

/-- The strict valuation comparison in the last paragraph of Lemma 3.12
forces the normalized difference odd, hence g3=4 by its definition. -/
theorem g3_eq_four_of_valuation_lt_published {S X C ν : ℤ} (hX : X ≠ 0) (hC : C ≠ 0)
    (hν : ν = 1 ∨ ν = -1) (hv : padicValInt 2 X < padicValInt 2 C) :
    g3 S (2 * X) (2 * ν * C) = 4 := by
  have hG : (Int.gcd X C : ℤ) ≠ 0 := by exact_mod_cast ne_of_gt (Int.gcd_pos_of_ne_zero_right X hC)
  have hvG : padicValInt 2 (Int.gcd X C : ℤ) = padicValInt 2 X := by
    rw [padicValInt.of_nat, valuation_gcd 2 hX hC, min_eq_left hv.le]
  have hvX := valuation_exact_integer_quotient 2 hX hG (Int.gcd_dvd_left X C)
  have hvC := valuation_exact_integer_quotient 2 hC hG (Int.gcd_dvd_right X C)
  rw [hvG, Nat.sub_self] at hvX
  rw [hvG] at hvC
  have hXq : X / (Int.gcd X C : ℤ) ≠ 0 := by
    intro hz
    have hh := Int.mul_ediv_cancel' (Int.gcd_dvd_left X C)
    rw [hz,mul_zero] at hh
    exact hX hh.symm
  have hCq : C / (Int.gcd X C : ℤ) ≠ 0 := by
    intro hz
    have hh := Int.mul_ediv_cancel' (Int.gcd_dvd_right X C)
    rw [hz,mul_zero] at hh
    exact hC hh.symm
  have ho := odd_of_valuation_two_zero hXq hvX
  have he : Even (C / (Int.gcd X C : ℤ)) := even_iff_two_dvd.mpr
    ((prime_dvd_iff_valuation_pos 2 hCq).mpr (by rw [hvC]; omega))
  have hnot := Int.not_even_iff_odd.mpr (ho.sub_even (he.mul_left ν))
  unfold g3
  rw [normalized_difference_quotient_published X C ν hC hν]
  simp [hnot]

end «JNT-2024».Approximation

namespace «JNT-2024».Parameters

theorem high_norm_square_valuation_published (P : Parameters) (h : P.Admissible)
    (hc : Int.gcd P.a P.b = 1) (hn : P.normAlpha < 0)
    (hh : padicValNat 2 P.baseGcd + 5 ≤ padicValInt 2 P.normAlpha)
    {k X Y : ℤ} (hx : P.x h.pell k = X) (hy : P.y h.pell k = Y) :
    X ≠ 0 ∧ padicValInt 2 (X ^ 2) = padicValNat 2 P.baseGcd := by
  have hi := P.high_norm_initial_valuations_published h hc hn hh
  have hyO := P.high_norm_sequence_y_odd_published h hc hn hh hy
  have hy₀ : Y ≠ 0 := by intro hz; simp [hz] at hyO
  have hyv := odd_valuation_two_zero hyO
  have hd₀ : P.d * Y ^ 2 ≠ 0 := mul_ne_zero (ne_of_gt h.d_pos) (pow_ne_zero _ hy₀)
  have hdv : padicValInt 2 (P.d * Y ^ 2) = padicValNat 2 P.baseGcd := by
    rw [padicValInt.mul (ne_of_gt h.d_pos) (pow_ne_zero _ hy₀), valuation_int_pow,
      hyv, mul_zero, add_zero, hi.2.2.2.1]
  have he : X ^ 2 = P.normAlpha + P.d * Y ^ 2 := by
    have he := P.norm_identity h.pell k
    rw [hx,hy] at he
    have he' : X ^ 2 - P.d * Y ^ 2 = P.normAlpha := by exact_mod_cast he
    linarith only [he']
  have hs₀ : P.normAlpha + P.d * Y ^ 2 ≠ 0 := by
    intro hz
    have hn' : P.normAlpha = -(P.d * Y ^ 2) := by linarith only [hz]
    have hv := congrArg (padicValInt 2) hn'
    rw [valuation_neg,hdv] at hv
    omega
  have hX₀ : X ≠ 0 := by intro hz; simp [hz] at he; exact hs₀ he.symm
  have hv := valuation_two_add_of_ne (ne_of_lt hn) hd₀ hs₀ (by rw [hdv]; omega)
  rw [hdv, min_eq_right (by omega)] at hv
  exact ⟨hX₀, by rw [he]; exact hv⟩

/-- The three exact component values in the last paragraph of the printed proof. -/
theorem high_norm_normalizer_components_published (P : Parameters) (h : P.Admissible)
    (hc : Int.gcd P.a P.b = 1) (hn : P.normAlpha < 0)
    (hh : padicValNat 2 P.baseGcd + 5 ≤ padicValInt 2 P.normAlpha)
    {k X Y ν : ℤ} (hx : P.x h.pell k = X) (hy : P.y h.pell k = Y) (hν : ν = 1 ∨ ν = -1) :
    padicValNat 2 (Approximation.g1 (2 * X) (2 * ν * squareFactor P.normAlpha) ^ 2) =
      padicValNat 2 P.baseGcd + 2 ∧
    padicValNat 2 (Approximation.g2 (squarefreePart P.normAlpha) (2 * X)
      (2 * ν * squareFactor P.normAlpha)) = 0 ∧
    Approximation.g3 (squarefreePart P.normAlpha) (2 * X) (2 * ν * squareFactor P.normAlpha) = 4 := by
  obtain ⟨hX,hxv⟩ := P.high_norm_square_valuation_published h hc hn hh hx hy
  have hC := ne_of_gt (squareFactor_pos (ne_of_lt hn))
  have hs := valuation_squarefree_le_one 2 (squarefreePart_squarefree P.normAlpha)
  have hNv := valuation_squarePart 2 (ne_of_lt hn)
  rw [valuation_int_pow] at hxv
  have hxc : padicValInt 2 X < padicValInt 2 (squareFactor P.normAlpha) := by omega
  refine ⟨?_, ?_, Approximation.g3_eq_four_of_valuation_lt_published hX hC hν hxc⟩
  · rw [Approximation.g1_square_valuation_published 2 hX hC hν, min_eq_left hxc.le]
    norm_num
    omega
  · rw [Approximation.g2_valuation_published 2 (squarefreePart_ne_zero _) hX hC hν,
      min_eq_left hxc.le, Nat.sub_self, Nat.zero_min]

end «JNT-2024».Parameters
