module

public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

theorem gcd_dvd_two_gcd_of_linear {A B X Y T U d ν : ℤ}
    (hν : ν = 1 ∨ ν = -1)
    (hx : T * X - d * U * Y = 2 * ν * A)
    (hy : T * Y - U * X = 2 * ν * B) : Int.gcd X Y ∣ 2 * Int.gcd A B := by
  have hX := Int.gcd_dvd_left X Y
  have hY := Int.gcd_dvd_right X Y
  have hA : (Int.gcd X Y : ℤ) ∣ 2 * A := by
    have hh : (Int.gcd X Y : ℤ) ∣ T * X - d * U * Y :=
      dvd_sub (dvd_mul_of_dvd_right hX T) (dvd_mul_of_dvd_right hY (d * U))
    rw [hx] at hh
    rcases hν with rfl | rfl <;> simpa using hh
  have hB : (Int.gcd X Y : ℤ) ∣ 2 * B := by
    have hh : (Int.gcd X Y : ℤ) ∣ T * Y - U * X :=
      dvd_sub (dvd_mul_of_dvd_right hY T) (dvd_mul_of_dvd_right hX U)
    rw [hy] at hh
    rcases hν with rfl | rfl <;> simpa using hh
  have hh := Int.dvd_gcd hA hB
  simpa [Int.gcd_mul_left] using hh


namespace Parameters


end Parameters

/-- The factor one half really occurs when the initial gcd is even. -/
theorem lemma310_even_counterexample :
    (⟨11, 3⟩ : QuadraticAlgebra ℚ 5 0) = (⟨2, 4⟩ : QuadraticAlgebra ℚ 5 0) * ⟨1 / 2, 1 / 2⟩ ∧
      Int.gcd 11 3 = 1 ∧ Int.gcd 2 4 = 2 := by
  constructor
  · ext <;> norm_num
  · norm_num

end «JNT-2024»
