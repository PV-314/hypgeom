module

public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

/-- Equation (4.10) and the choice k0=1.257 (allowing k0<=1.257) give the printed 0.64
coefficient, with c still arbitrary. Here t is the modulus of q. -/
theorem nonexact_before_fourth {N d z t k Q c δ : ℝ} {r : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hz : 0 < z) (ht : 0 < t)
    (hk : 0 < k) (hku : k ≤ 1257/1000) (hQ : 0 < Q) (hc : c < 1)
    (hl : (1-c)/(k*Q^r) < t*δ)
    (hu : δ < 2*Real.sqrt N/((3959/1000 : ℝ)*Real.sqrt d*z)) :
    z < ((64/100 : ℝ)*Real.sqrt N/((1-c)*Real.sqrt d))*Q^r*t := by
  have hsN := Real.sqrt_pos.mpr hN
  have hsd := Real.sqrt_pos.mpr hd
  have hcp : 0 < 1-c := by linarith
  have hl' := (div_lt_iff₀ (mul_pos hk (pow_pos hQ r))).mp hl
  have hu' := (lt_div_iff₀ (by positivity : 0 < (3959/1000 : ℝ)*Real.sqrt d*z)).mp hu
  have h1 := mul_lt_mul_of_pos_right hl'
    (by positivity : 0 < (3959/1000 : ℝ)*Real.sqrt d*z)
  have h2 := mul_lt_mul_of_pos_right hu' (by positivity : 0 < t*k*Q^r)
  have h3 := mul_le_mul_of_nonneg_right hku (by positivity : 0 ≤ 2*Real.sqrt N*t*Q^r)
  have hh : z*((1-c)*Real.sqrt d) < (64/100 : ℝ)*Real.sqrt N*Q^r*t := by
    nlinarith only [h1,h2,h3,mul_pos hcp (mul_pos hsd hz)]
  have he : ((64/100 : ℝ)*Real.sqrt N/((1-c)*Real.sqrt d))*Q^r*t =
      ((64/100 : ℝ)*Real.sqrt N*Q^r*t)/((1-c)*Real.sqrt d) := by ring
  rw [he]
  exact (lt_div_iff₀ (mul_pos hcp hsd)).mpr hh

/-- The fourth-power step of (4.11), retaining the representation coefficients
as F=f_k*f_l. This form keeps Q available for its subsequent substitution. -/
theorem nonexact_fourth_power {N d y z t F Q c : ℝ} {r : ℕ}
    (hN : 0 < N) (hd : 0 < d) (_hy : 0 < y) (hz : 0 < z) (_ht : 0 < t)
    (_hQ : 0 < Q) (hc : c < 1) (hnorm : t^4=F^2*y*z)
    (hu : z < ((64/100 : ℝ)*Real.sqrt N/((1-c)*Real.sqrt d))*Q^r*t) :
    z^3 < (N*F)^2*((64/100 : ℝ)/(1-c))^4/d^2*Q^(4*r)*y := by
  have hcp : 1-c ≠ 0 := by linarith
  have hp := pow_lt_pow_left₀ hu hz.le (by decide : 4 ≠ 0)
  have hN4 : Real.sqrt N^4=N^2 := by
    rw [show (4 : ℕ)=2*2 from rfl,pow_mul,Real.sq_sqrt hN.le]
  have hd4 : Real.sqrt d^4=d^2 := by
    rw [show (4 : ℕ)=2*2 from rfl,pow_mul,Real.sq_sqrt hd.le]
  have he : (((64/100 : ℝ)*Real.sqrt N/((1-c)*Real.sqrt d))*Q^r*t)^4 =
      ((N*F)^2*((64/100 : ℝ)/(1-c))^4/d^2*Q^(4*r)*y)*z := by
    simp only [mul_pow,div_pow,hN4,hd4,hnorm,← pow_mul]
    rw [Nat.mul_comm r 4]
    field_simp
  rw [he] at hp
  apply (mul_lt_mul_iff_right₀ hz).mp
  convert hp using 1 <;> ring

/-- Substitute (4.7) into the fourth-power inequality and expand exactly
the powers printed in (4.11). -/
theorem nonexact_equation411 {N d y z F M Q c : ℝ} {r : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hy : 0 < y) (hF : 0 < F) (_hM : 0 < M)
    (hQ : 0 < Q) (hc : c < 1) (hr : 1 ≤ r)
    (hQu : Q < (2147/100 : ℝ)*Real.sqrt d*y/M)
    (hu : z^3 < (N*F)^2*((64/100 : ℝ)/(1-c))^4/d^2*Q^(4*r)*y) :
    z^3 < (N*F)^2*((64/100 : ℝ)/(1-c))^4*((2147/100 : ℝ)/M)^(4*r)*
      d^(2*r-2)*y^(4*r+1) := by
  have hcp : 0 < 1-c := by linarith
  have hp := pow_le_pow_left₀ hQ.le hQu.le (4*r)
  have hh := mul_le_mul_of_nonneg_right
    (mul_le_mul_of_nonneg_left hp
      (by positivity : 0 ≤ (N*F)^2*((64/100 : ℝ)/(1-c))^4/d^2)) hy.le
  apply hu.trans_le
  convert hh using 1
  have hroot : Real.sqrt d^(4*r)=d^(2*r) := by
    rw [show 4*r=2*(2*r) by omega,pow_mul,Real.sq_sqrt hd.le]
  rw [pow_sub₀ d (ne_of_gt hd) (by omega : 2 ≤ 2*r),pow_add,pow_one]
  simp only [mul_pow,div_pow,hroot]
  ring

/-- Specialising (4.11) at r0=1 and using M>=2 yields (4.12). -/
theorem nonexact_equation412 {N d y z F M c : ℝ}
    (hN : 0 < N) (hy : 0 < y) (hF : 0 < F) (hM : 2 ≤ M) (hc : c < 1)
    (hu : z^3 < (N*F)^2*((64/100 : ℝ)/(1-c))^4*((2147/100 : ℝ)/M)^4*
      d^0*y^5) :
    z^3 < 35700/(1-c)^4*(N*F)^2*y^5 := by
  have hcp : 0 < 1-c := by linarith
  have hMp : 0 < M := by linarith
  have hfrac : (2147/100 : ℝ)/M ≤ (2147/200 : ℝ) := by
    apply (div_le_iff₀ hMp).mpr
    nlinarith only [hM]
  have hp := pow_le_pow_left₀ (by positivity : 0 ≤ (2147/100 : ℝ)/M) hfrac 4
  have hm := mul_le_mul_of_nonneg_left hp
    (by positivity : 0 ≤ (N*F)^2*((64/100 : ℝ)/(1-c))^4*y^5)
  have hround : (64/100 : ℝ)^4*(2147/200 : ℝ)^4 < 35700 := by norm_num
  have hcst := mul_lt_mul_of_pos_right hround
    (by positivity : 0 < (N*F)^2*y^5/(1-c)^4)
  norm_num only [pow_zero,mul_one] at hu
  rw [div_pow] at hm hu
  calc
    z^3 < (N*F)^2*((16/25 : ℝ)^4/(1-c)^4)*((2147/100 : ℝ)/M)^4*y^5 := hu
    _ ≤ ((64/100 : ℝ)^4*(2147/200 : ℝ)^4)*((N*F)^2*y^5/(1-c)^4) := by
      convert hm using 1 <;> ring
    _ < 35700/(1-c)^4*(N*F)^2*y^5 := by
      convert hcst using 1; ring

end «JNT-2024».Section4
