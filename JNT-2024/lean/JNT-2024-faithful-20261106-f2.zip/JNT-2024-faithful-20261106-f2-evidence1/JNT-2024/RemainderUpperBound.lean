module

public import «JNT-2024».ArcGeometry
public import «JNT-2024».HypergeometricPolynomials
public import «JNT-2024».RemainderArc
public import «JNT-2024».RemainderConstruction
public import «JNT-2024».RemainderIdentity
public import «JNT-2024».UnitCircleGeometry
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

theorem arcKernel_norm_le (ν : ℚ) (r : ℕ) {φ t : ℝ}
    (hφ : |φ| ≤ Real.pi / 2) (ht : t ∈ Set.Icc 0 1) :
    ‖segmentKernel ν r (circlePoint φ) (circlePoint (φ * t)) *
      ((φ : ℂ) * Complex.I * circlePoint (φ * t))‖ ≤
      |φ| * ‖1 - circlePoint (φ / 2)‖ ^ (2 * r) := by
  have htφ : |φ * t| < Real.pi := by
    rw [abs_mul, abs_of_nonneg ht.1]
    have := mul_le_of_le_one_right (abs_nonneg φ) ht.2
    linarith [Real.pi_pos]
  have hc : circlePoint (φ * t) ^ ((ν : ℂ) - r - 1) =
      circlePoint (((ν : ℝ) - r - 1) * (φ * t)) := by
    convert circlePoint_cpow ((ν : ℝ) - r - 1) (φ * t) htφ using 1
    push_cast
    rfl
  simp only [segmentKernel, norm_mul, norm_pow, hc, circlePoint_norm, Complex.norm_I,
    Complex.norm_real, Real.norm_eq_abs, mul_one]
  rw [← norm_mul, arcWeight_norm_product (by linarith [Real.pi_pos] : |φ| ≤ Real.pi) ht]
  have hh := pow_le_pow_left₀ (arcWeight_nonneg (by linarith [Real.pi_pos] : |φ| ≤ Real.pi) ht)
    (arcWeight_le φ t) r
  rw [← pow_mul] at hh
  nlinarith [abs_nonneg φ]

/-- Lemma 2.2(c), extended to the closed right half of the unit circle. -/
theorem remainder_norm_le {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1) (r : ℕ)
    {z : ℂ} (hz : ‖z‖ = 1) (hre : 0 ≤ z.re) :
    ‖remainder ν r z‖ ≤
      (Real.Gamma ((r : ℝ) + 1 + ν) / ((r.factorial : ℝ) * Real.Gamma (ν : ℝ))) *
        |z.arg| * ‖1 - principalSquareRoot z‖ ^ (2 * r) := by
  have hνR : (0 : ℝ) < ν := by exact_mod_cast hν₀
  have hC : 0 ≤ Real.Gamma ((r : ℝ) + 1 + ν) /
      ((r.factorial : ℝ) * Real.Gamma (ν : ℝ)) := by
    exact le_of_lt (div_pos (Real.Gamma_pos_of_pos (by positivity))
      (mul_pos (by positivity) (Real.Gamma_pos_of_pos hνR)))
  rw [remainder_eq_arcIntegral hν₀ hν₁ r hz hre,
    remainderIntegralFactor_eq_gamma hν₀, norm_mul, Complex.norm_real, Real.norm_eq_abs,
    abs_of_nonneg hC]
  have hh := intervalIntegral.norm_integral_le_of_norm_le_const
    (a := (0 : ℝ)) (b := 1) (C := |z.arg| * ‖1 - circlePoint (z.arg / 2)‖ ^ (2 * r))
    (f := fun t => segmentKernel ν r z (circlePoint (z.arg * t)) *
      ((z.arg : ℂ) * Complex.I * circlePoint (z.arg * t))) (fun t ht => by
      have ht' : t ∈ Set.Icc (0 : ℝ) 1 := by
        simp only [Set.uIoc_of_le zero_le_one] at ht
        exact ⟨ht.1.le, ht.2⟩
      simpa only [circlePoint_arg hz] using
        arcKernel_norm_le ν r (Complex.abs_arg_le_pi_div_two_iff.mpr hre) ht')
  simp only [sub_zero] at hh
  have he : circlePoint (z.arg / 2) = principalSquareRoot z := by
    simp only [circlePoint, principalSquareRoot, mul_comm]
  rw [he] at hh
  exact (mul_le_mul_of_nonneg_left hh hC).trans_eq (by ring)

theorem lemma22c {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1 / 2) (r : ℕ)
    {z : ℂ} (hz : ‖z‖ = 1) (hz₁ : ‖z - 1‖ < 1) :
    ‖remainder ν r z‖ ≤
      (Real.Gamma ((r : ℝ) + 1 + ν) / ((r.factorial : ℝ) * Real.Gamma (ν : ℝ))) *
        |z.arg| * ‖1 - principalSquareRoot z‖ ^ (2 * r) := by
  apply remainder_norm_le hν₀ (by linarith) r hz
  have hh := Complex.abs_re_le_norm (z - 1)
  simp only [Complex.sub_re, Complex.one_re] at hh
  have := (abs_lt.mp (hh.trans_lt hz₁)).1
  linarith

end Hypergeometric
end «JNT-2024»
