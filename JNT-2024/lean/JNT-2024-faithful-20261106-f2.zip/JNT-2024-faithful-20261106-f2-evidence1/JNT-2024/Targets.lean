module

public import «JNT-2024».Sequence
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Data.Finset.Card
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

/-!
# Exact target statements

These are definitions of propositions, NOT proofs or additional axioms.
The conjectures in Section 1.3 are not asserted as theorems.
-/

namespace «JNT-2024»

/-- An integer square viewed in `ℚ`, including zero. -/
def IsIntegerSquare (q : ℚ) : Prop := ∃ n : ℤ, q = (n : ℚ) ^ 2

/-- A finite set bounds the distinct square VALUES, not their indices or roots. -/
def AtMostSquareValues (y : ℤ → ℚ) (bound : ℕ) : Prop :=
  ∃ S : Finset ℚ, S.card ≤ bound ∧ ∀ k : ℤ, IsIntegerSquare (y k) → y k ∈ S

namespace Parameters

def AdjacentSquare (P : Parameters) (h : P.Pell) : Prop :=
  IsIntegerSquare (P.y h 1) ∨ IsIntegerSquare (P.y h (-1))

/-- Exactly the four exceptional alternatives of Theorem 1.4. -/
def Exceptional (P : Parameters) (h : P.Pell) : Prop :=
  P.t ^ 2 - P.d * P.u ^ 2 = -4 ∧ P.AdjacentSquare h ∧
    ((P.u = 1 ∧ P.normAlpha % 16 = 12 ∧
        (Int.gcd (P.a ^ 2) P.d = 1 ∨ Int.gcd (P.a ^ 2) P.d = 4)) ∨
     (P.u = 1 ∧ 64 ∣ P.normAlpha ∧ Int.gcd (P.a ^ 2) P.d = 4) ∨
     (P.u = 2 ∧ Odd P.normAlpha ∧ Int.gcd (P.a ^ 2) P.d = 1) ∨
     (P.u = 2 ∧ 16 ∣ P.normAlpha ∧ Int.gcd (P.a ^ 2) P.d = 1))

end Parameters

/-- The main formalisation target, proved by `theorem14_revised` in `Section5AssemblyRevised`.

`Admissible` uses the Pell condition. `Parameters.admissible_iff_paper` and
`paper_sequence_iff` prove the equivalence with the paper's ring-of-integers
hypotheses and its defining equation. The proof keeps `DenominatorEstimate4`,
`AkhtariTheorem11` and `Section46Magma` as explicit hypotheses.
-/
def Theorem14 : Prop :=
  ∀ (P : Parameters) (h : P.Admissible),
    P.b = 1 → P.normAlpha < 0 → IsSquare (-P.normAlpha) →
    AtMostSquareValues (P.y h.pell) 3 ∧
    (¬ P.Exceptional h.pell → AtMostSquareValues (P.y h.pell) 2)

end «JNT-2024»
