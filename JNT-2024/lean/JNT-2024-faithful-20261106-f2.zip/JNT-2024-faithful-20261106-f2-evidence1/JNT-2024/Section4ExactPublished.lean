module

public import «JNT-2024».HypergeometricPolynomials
public import «JNT-2024».Section2
public import «JNT-2024».Section2Complex
public import «JNT-2024».Section2Gaussian
public import «JNT-2024».Section4ChordsPublished
public import «JNT-2024».Section4ExactCase
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

/-- The actual comparison fraction, using the printed chord argument. -/
theorem exact_comparison_error_printed {u₁ u₂ : ℤ} (data : Section2.PaperApproximants u₁ u₂)
    (hu₂ : u₂ ≠ 0) (hnear : ‖Section2.omega (-1) u₁ u₂-1‖<1)
    {p₀ q₀ : Section2.GaussianField} (hq₀ : q₀ ≠ 0) {r : ℕ} (hr : 1 ≤ r)
    (he : data.pr r*q₀-data.qr r*p₀=0) :
    (2915/10000 : ℝ)/(4^r*Real.sqrt r)*
        (‖Section2.omega (-1) u₁ u₂-1‖/2)^(2*r+1) <
      ‖Section2.omega (-1) u₁ u₂^(1/4 : ℂ)-
        Section2.gaussianEmbedding p₀/Section2.gaussianEmbedding q₀‖ := by
  obtain ⟨hY,hratio⟩ := exact_comparison_ratio data hq₀ r he
  rw [hratio]
  exact exact_error_printed (Section2.omega_norm (by norm_num) hu₂) hnear
    (Section2.omega_ne_one (by norm_num) hu₂) hr hY

/-- Multiplying the error bound by 3.959 gives the printed 1.154 coefficient. -/
theorem exact_error_1154 {δ H U : ℝ} (hH : 0 < H)
    (hl : (2915/10000 : ℝ)*H < δ) (hu : (3959/1000 : ℝ)*δ < U) :
    (1154/1000 : ℝ)*H < U := by
  have hh := mul_lt_mul_of_pos_left hl (by norm_num : (0 : ℝ)<3959/1000)
  nlinarith only [hh,hu,hH]

/-- Rearrangement of the printed 1.154 inequality as (4.15). -/
theorem exact_equation415 {N d y z δ : ℝ} {r : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hy : 0 < y) (hz : 0 < z) (hr : 1 ≤ r)
    (hl : (2915/10000 : ℝ)/(4^r*Real.sqrt r)*
      (Real.sqrt N/(Real.sqrt d*y))^(2*r+1) < δ)
    (hu : δ < 2*Real.sqrt N/((3959/1000 : ℝ)*Real.sqrt d*z)) :
    z < (1734/1000 : ℝ)*Real.sqrt r*(4*d/N)^r*y^(2*r+1) := by
  let L := Real.sqrt d*y/Real.sqrt N
  have hL : 0 < L := by dsimp [L]; positivity
  have hs : 0 < Real.sqrt (r : ℝ) := Real.sqrt_pos.mpr (by exact_mod_cast (by omega : 0 < r))
  have hroot : L^2=d*y^2/N := by
    dsimp [L]
    rw [div_pow,mul_pow,Real.sq_sqrt hd.le,Real.sq_sqrt hN.le]
  have hlow : (2915/10000 : ℝ)/(4^r*Real.sqrt r*L^(2*r+1)) < δ := by
    convert hl using 1
    dsimp [L]
    simp only [div_pow,mul_pow]
    field_simp
  have hup : (3959/1000 : ℝ)*δ < 2*y/(L*z) := by
    have hh := mul_lt_mul_of_pos_left hu (by norm_num : (0 : ℝ)<3959/1000)
    convert hh using 1
    dsimp [L]
    field_simp
  have h1154 := exact_error_1154
    (by positivity : 0 < 1/(4^r*Real.sqrt r*L^(2*r+1)))
    (by simpa only [mul_one_div] using hlow) hup
  have hcross := (div_lt_div_iff₀
    (by positivity : 0 < 4^r*Real.sqrt r*L^(2*r+1))
    (mul_pos hL hz)).mp (by simpa only [mul_one_div] using h1154)
  have he : (4 : ℝ)^r*Real.sqrt r*L^(2*r+1) =
      Real.sqrt r*(4*L^2)^r*L := by
    rw [mul_pow,pow_add,pow_one,pow_mul]
    ring
  rw [he] at hcross
  have hc : (1154/1000 : ℝ)*z < 2*y*Real.sqrt r*(4*L^2)^r := by
    apply (mul_lt_mul_iff_right₀ hL).mp
    nlinarith only [hcross]
  have hrounded : z < (1734/1000 : ℝ)*y*Real.sqrt r*(4*L^2)^r := by
    nlinarith only [hc,hz]
  convert hrounded using 1
  rw [hroot]
  have he' : 4*(d*y^2/N)=(4*d/N)*y^2 := by ring
  rw [he',mul_pow,← pow_mul,pow_succ]
  ring

/-- The literal 6.94 specialization used with Lemma 3.8(a). -/
theorem exact_equation415_index_one {N d y z : ℝ} (hN : 0 < N) (hd : 0 < d)
    (hy : 0 < y) (h415 : z < (1734/1000 : ℝ)*Real.sqrt (1:ℝ)*(4*d/N)^1*y^(2*1+1)) :
    z < (694/100 : ℝ)*d/N*y^3 := by
  norm_num only [Real.sqrt_one,pow_one,mul_one] at h415
  have hh : (1734/1000 : ℝ)*(4*d/N)*y^3 < (694/100 : ℝ)*d/N*y^3 := by
    have hp : 0 < d/N*y^3 := by positivity
    have hc := mul_lt_mul_of_pos_right (by norm_num : (1734/1000 : ℝ)*4 < 694/100) hp
    convert hc using 1 <;> ring
  exact h415.trans (by convert hh using 1; norm_num)

end «JNT-2024».Section4
