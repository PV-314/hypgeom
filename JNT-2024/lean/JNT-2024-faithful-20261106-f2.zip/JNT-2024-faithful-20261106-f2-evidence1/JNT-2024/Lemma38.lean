module

public import «JNT-2024».ComplexRepresentation
public import «JNT-2024».GapCoefficientPublished
public import «JNT-2024».GapNormalization
public import «JNT-2024».GapPrinciple
public import «JNT-2024».GapRepresentationBounds
public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».RepresentationGaussian
public import «JNT-2024».Sequence
public import «JNT-2024».SequenceRepresentations
public import «JNT-2024».SquarefreePart
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- Lemma 3.8(a), directly for the sequence (1.1), with the exact constant 57.32. -/
theorem lemma38a (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (hNs : IsSquare (-P.normAlpha)) {i j : ℤ} (hi : i ≠ 0) (hj : j ≠ 0)
    (hsi : IsSquare (P.y h.pell i)) (hsj : IsSquare (P.y h.pell j))
    (hij : (P.y h.pell i : ℝ) < (P.y h.pell j : ℝ))
    (hlarge : max (4 * Real.sqrt (|(P.normAlpha : ℝ)| / P.d))
      ((P.b : ℝ) ^ 2 * |(P.normAlpha : ℝ)| / P.d) ≤ (P.y h.pell i : ℝ)) :
    (5732 / 100 : ℝ) * ((P.d : ℝ) / ((P.b : ℝ) ^ 2 * |(P.normAlpha : ℝ)|)) ^ 2 *
      (P.y h.pell i : ℝ) ^ 3 < (P.y h.pell j : ℝ) := by
  have hb : (0 : ℝ) < P.b := by exact_mod_cast h.b_pos
  have ht := P.gapScale_pos h.b_pos hn
  have hli : 4 * P.gapScale ≤ (P.y h.pell i : ℝ) := by
    rw [P.gapScale_eq_sqrt h.b_pos hn]
    exact le_trans (le_max_left _ _) hlarge
  have hip : (0 : ℝ) < (P.y h.pell i : ℝ) := lt_of_lt_of_le (by positivity) hli
  have hjp : (0 : ℝ) < (P.y h.pell j : ℝ) := lt_trans hip hij
  obtain ⟨p, hpy, hpf⟩ := P.sequence_gaussian_datum h hn hNs hi hsi (by exact_mod_cast hip)
  obtain ⟨q, hqy, hqf⟩ := P.sequence_gaussian_datum h hn hNs hj hsj (by exact_mod_cast hjp)
  have hscale : (P.b : ℝ) ^ 2 * P.gapScale ^ 2 ≤ p.y := by
    rw [P.gapScale_sq_abs h.b_pos hn, hpy]
    have hh := le_trans (le_max_right _ _) hlarge
    convert hh using 1; ring
  have hres := p.lemma38a_represented q hb ht (P.gapOmega_norm hn)
    (by simpa only [hpy, hqy] using hij) (by simpa only [hpy] using hli)
    (A := 1 / ((P.b : ℝ) ^ 4 * P.gapScale ^ 4)) (by positivity)
    (gaussian_coefficient_le hb ht p.f_pos q.f_pos hpf hqf)
    (gaussian_scale_bound hb ht hscale)
  simpa only [hpy, hqy, P.paper_gaussian_coefficient h hn] using hres


/-- The printed Lemma 3.8(b), retaining its nonsquare hypothesis for downstream use. -/
theorem lemma38b (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (hNs : ¬ IsSquare (-P.normAlpha))
    {i j k : ℤ} (hi : i ≠ 0) (hj : j ≠ 0) (hk : k ≠ 0)
    (hsi : IsSquare (P.y h.pell i)) (hsj : IsSquare (P.y h.pell j)) (hsk : IsSquare (P.y h.pell k))
    (hij : (P.y h.pell i : ℝ) < (P.y h.pell j : ℝ))
    (hjk : (P.y h.pell j : ℝ) < (P.y h.pell k : ℝ))
    (hlarge : 4 * Real.sqrt (|(P.normAlpha : ℝ)| / P.d) ≤ (P.y h.pell i : ℝ)) :
    ∃ p q v : P.SequenceDatum,
      P.SequenceGapCertificate h.pell i p ∧ P.SequenceGapCertificate h.pell j q ∧
      P.SequenceGapCertificate h.pell k v ∧
      (P.PaperCubicGap p q ∨ P.PaperCubicGap p v ∨ P.PaperCubicGap q v) := by
  have hb : (0 : ℝ) < P.b := by exact_mod_cast h.b_pos
  have ht := P.gapScale_pos h.b_pos hn
  have hli : 4 * P.gapScale ≤ (P.y h.pell i : ℝ) := by
    rwa [P.gapScale_eq_sqrt h.b_pos hn]
  have hip : (0 : ℝ) < (P.y h.pell i : ℝ) := lt_of_lt_of_le (by positivity) hli
  have hjp := lt_trans hip hij
  have hkp := lt_trans hjp hjk
  obtain ⟨p, hpc, hpf, _, _⟩ := P.sequence_general_datum_published h hn hNs hi hsi (by exact_mod_cast hip)
  obtain ⟨q, hqc, hqf, _, _⟩ := P.sequence_general_datum_published h hn hNs hj hsj (by exact_mod_cast hjp)
  obtain ⟨v, hvc, hvf, _, _⟩ := P.sequence_general_datum_published h hn hNs hk hsk (by exact_mod_cast hkp)
  refine ⟨p, q, v, hpc, hqc, hvc, ?_⟩
  have hpg := p.lemma38b_represented q v (neg_pos.mpr (squarefreePart_neg hn)) hb ht
    (P.gapOmega_norm hn) (by simpa only [hpc.1, hqc.1] using hij)
    (by simpa only [hqc.1, hvc.1] using hjk) (by simpa only [hpc.1] using hli)
  rcases hpg with hh | hh | hh
  · exact Or.inl (P.cubicGap_to_paper h hn p q hpf hqf hh)
  · exact Or.inr (Or.inl (P.cubicGap_to_paper h hn p v hpf hvf hh))
  · exact Or.inr (Or.inr (P.cubicGap_to_paper h hn q v hqf hvf hh))


/-- The selected indices in Lemma 3.8(b), explicitly belonging to the input triple. -/
theorem lemma38b_pair (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (hNs : ¬ IsSquare (-P.normAlpha))
    {i j k : ℤ} (hi : i ≠ 0) (hj : j ≠ 0) (hk : k ≠ 0)
    (hsi : IsSquare (P.y h.pell i)) (hsj : IsSquare (P.y h.pell j)) (hsk : IsSquare (P.y h.pell k))
    (hij : (P.y h.pell i : ℝ) < (P.y h.pell j : ℝ))
    (hjk : (P.y h.pell j : ℝ) < (P.y h.pell k : ℝ))
    (hlarge : 4 * Real.sqrt (|(P.normAlpha : ℝ)| / P.d) ≤ (P.y h.pell i : ℝ)) :
    ∃ ℓ m : ℤ, (ℓ = i ∨ ℓ = j ∨ ℓ = k) ∧ (m = i ∨ m = j ∨ m = k) ∧ ℓ ≠ m ∧
      (P.y h.pell ℓ : ℝ) < (P.y h.pell m : ℝ) ∧
      ∃ p q : P.SequenceDatum, P.SequenceGapCertificate h.pell ℓ p ∧
        P.SequenceGapCertificate h.pell m q ∧ P.PaperCubicGap p q := by
  obtain ⟨p, q, v, hpc, hqc, hvc, hh⟩ := P.lemma38b h hn hNs hi hj hk hsi hsj hsk hij hjk hlarge
  have hne : ∀ a b : ℤ, (P.y h.pell a : ℝ) < (P.y h.pell b : ℝ) → a ≠ b := by
    intro a b hab he
    rw [he] at hab
    exact (lt_irrefl _) hab
  rcases hh with hh | hh | hh
  · exact ⟨i, j, Or.inl rfl, Or.inr (Or.inl rfl), hne i j hij, hij, p, q, hpc, hqc, hh⟩
  · exact ⟨i, k, Or.inl rfl, Or.inr (Or.inr rfl), hne i k (lt_trans hij hjk),
      lt_trans hij hjk, p, v, hpc, hvc, hh⟩
  · exact ⟨j, k, Or.inr (Or.inl rfl), Or.inr (Or.inr rfl), hne j k hjk, hjk, q, v, hqc, hvc, hh⟩

end «JNT-2024».Parameters
