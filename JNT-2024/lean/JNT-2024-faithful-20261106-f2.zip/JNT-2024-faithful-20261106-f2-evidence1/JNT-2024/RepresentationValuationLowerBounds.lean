module

public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».RepresentationValuationChains
public import «JNT-2024».Sequence
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section
namespace «JNT-2024».Parameters

/-- The lower-bound inference after the printed odd-prime chain, expressed
without fractions. It uses that chain, not the alternative divisibility proof. -/
theorem lemma32_odd_lower_from_chain (P : Parameters) {x y σ : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hy : y ≠ 0)
    (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0) (hσ : σ = 1 ∨ σ = -1)
    (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2) :
    padicValInt p P.b ≤ padicValInt p y ∨
      padicValInt p (P.repCandidate y σ) ≤ 2 * padicValInt p y := by
  let v := emultiplicity (p : ℤ)
  have hh := P.lemma32_odd_valuation_chain h p hp2 σ hσ
  have hs : min (v P.b + v y) (min (v (P.repCandidate y σ)) (2 * v P.b)) ≤
      2 * v y := by
    apply le_trans _ hh
    apply min_le_min
    · simpa only [add_zero] using add_le_add (add_le_add le_rfl (show (0 : ℕ∞) ≤ v P.t from zero_le)) (le_refl (v y))
    · apply min_le_min
      · exact le_add_of_nonneg_right (show (0 : ℕ∞) ≤ v P.t from zero_le)
      · exact le_min (le_add_of_nonneg_right (show (0 : ℕ∞) ≤ 2 * v P.t from zero_le))
          ((le_add_of_nonneg_right (show (0 : ℕ∞) ≤ v P.d from zero_le)).trans
            (le_add_of_nonneg_right (show (0 : ℕ∞) ≤ 2 * v P.u from zero_le)))
  dsimp [v] at hs
  rw [emultiplicity_eq_padicValInt p hb, emultiplicity_eq_padicValInt p hy,
    emultiplicity_eq_padicValInt p (P.repCandidate_ne_zero h hu hN hσ)] at hs
  rcases min_le_iff.mp hs with h1 | h2
  · have hn : padicValInt p P.b + padicValInt p y ≤ 2 * padicValInt p y := by exact_mod_cast h1
    left
    omega
  · rcases min_le_iff.mp h2 with h2 | h3
    · right
      exact_mod_cast h2
    · have hn : 2 * padicValInt p P.b ≤ 2 * padicValInt p y := by exact_mod_cast h3
      left
      omega

/-- Second line of the printed prime-two chain: substitute the candidate and
use the factor `2b²` in the remaining summand. -/
theorem lemma32_two_chain_second (P : Parameters) (y σ ν : ℤ) :
    let v := emultiplicity (2 : ℤ)
    min (min (v (2 * P.t ^ 2 * P.b ^ 2 + σ * 4 * P.b * P.t * y))
      (v (P.repCandidate y σ) + v P.t + 1)) (v (2 * P.b ^ 2)) ≤
    min (v (2 * P.a * P.t * P.u))
      (v (P.b ^ 2 * (4 * ν + 2 * P.d * P.u ^ 2))) := by
  dsimp only
  have hp : Prime (2 : ℤ) := Nat.prime_iff_prime_int.mp Nat.prime_two
  have h2 : emultiplicity (2 : ℤ) (2 : ℤ) = 1 := by
    have hh := emultiplicity_eq_padicValInt 2 (z := 2) (by norm_num)
    change emultiplicity (2 : ℤ) (2 : ℤ) = _ at hh
    simpa [padicValInt] using hh
  apply min_le_min
  · have he : 2 * P.a * P.t * P.u =
        -(2 * P.t ^ 2 * P.b ^ 2 + σ * 4 * P.b * P.t * y) +
        (P.repCandidate y σ * P.t) * 2 := by
      unfold repCandidate
      ring
    rw [he]
    simpa only [emultiplicity_neg, emultiplicity_mul hp, h2] using
      (min_le_emultiplicity_add (p := (2 : ℤ))
        (a := -(2 * P.t ^ 2 * P.b ^ 2 + σ * 4 * P.b * P.t * y))
        (b := (P.repCandidate y σ * P.t) * 2))
  · apply emultiplicity_le_emultiplicity_of_dvd_right
    exact ⟨2 * ν + P.d * P.u ^ 2, by ring⟩

/-- Third line of the printed prime-two chain; the factor `2b²` absorbs
the other summand `2t²b²`. -/
theorem lemma32_two_chain_third (P : Parameters) (y σ : ℤ)
    (hσ : σ = 1 ∨ σ = -1) :
    let v := emultiplicity (2 : ℤ)
    min (v (4 * P.b * P.t * y))
      (min (v (P.repCandidate y σ) + v P.t + 1) (v (2 * P.b ^ 2))) ≤
    min (min (v (2 * P.t ^ 2 * P.b ^ 2 + σ * 4 * P.b * P.t * y))
      (v (P.repCandidate y σ) + v P.t + 1)) (v (2 * P.b ^ 2)) := by
  dsimp only
  have hs : emultiplicity (2 : ℤ) (σ * 4 * P.b * P.t * y) =
      emultiplicity (2 : ℤ) (4 * P.b * P.t * y) := by
    rcases hσ with rfl | rfl
    · simp
    · have he : (-1 : ℤ) * 4 * P.b * P.t * y = -(4 * P.b * P.t * y) := by ring
      rw [he, emultiplicity_neg]
  have hd : emultiplicity (2 : ℤ) (2 * P.b ^ 2) ≤
      emultiplicity (2 : ℤ) (2 * P.t ^ 2 * P.b ^ 2) := by
    apply emultiplicity_le_emultiplicity_of_dvd_right
    exact ⟨P.t ^ 2, by ring⟩
  have hh := min_le_emultiplicity_add (p := (2 : ℤ))
    (a := 2 * P.t ^ 2 * P.b ^ 2) (b := σ * 4 * P.b * P.t * y)
  rw [hs] at hh
  apply le_min
  · apply le_min
    · apply le_trans _ hh
      exact le_min (((min_le_right _ _).trans (min_le_right _ _)).trans hd)
        (min_le_left _ _)
    · exact (min_le_right _ _).trans (min_le_left _ _)
  · exact (min_le_right _ _).trans (min_le_right _ _)

/-- The complete displayed prime-two chain, with product valuations expanded. -/
theorem lemma32_two_valuation_chain (P : Parameters) {x y σ ν : ℤ}
    (h : P.RepresentsSquare x y) (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν)
    (hσ : σ = 1 ∨ σ = -1) :
    let v := emultiplicity (2 : ℤ)
    min (v P.b + v P.t + v y + 2)
      (min (v (P.repCandidate y σ) + v P.t + 1) (2 * v P.b + 1)) ≤
      2 * v y + 2 := by
  have hh := (P.lemma32_two_chain_third y σ hσ).trans
    ((P.lemma32_two_chain_second y σ ν).trans (P.lemma32_two_chain_first h hν))
  have hp : Prime (2 : ℤ) := Nat.prime_iff_prime_int.mp Nat.prime_two
  have h2 : emultiplicity (2 : ℤ) (2 : ℤ) = 1 := by
    have he := emultiplicity_eq_padicValInt 2 (z := 2) (by norm_num)
    change emultiplicity (2 : ℤ) (2 : ℤ) = _ at he
    simpa [padicValInt] using he
  have h4 : emultiplicity (2 : ℤ) (4 : ℤ) = 2 := by
    have he : (4 : ℤ) = 2 * 2 := by norm_num
    rw [he, emultiplicity_mul hp, h2]
    norm_num
  dsimp only at hh ⊢
  simpa only [emultiplicity_mul hp, emultiplicity_pow hp, Nat.cast_ofNat,
    h2, h4, add_comm, add_left_comm, add_assoc] using hh

/-- Integer inference from the printed prime-two chain. -/
theorem lemma32_two_lower_from_chain (P : Parameters) {x y σ ν : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hy : y ≠ 0)
    (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0) (hσ : σ = 1 ∨ σ = -1)
    (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν) :
    padicValInt 2 P.b ≤ padicValInt 2 y ∨
      padicValInt 2 (P.repCandidate y σ) ≤ 2 * padicValInt 2 y + 1 := by
  let v := emultiplicity (2 : ℤ)
  have hh := P.lemma32_two_valuation_chain h hν hσ
  have hs : min (v P.b + v y + 2)
      (min (v (P.repCandidate y σ) + 1) (2 * v P.b + 1)) ≤ 2 * v y + 2 := by
    apply le_trans _ hh
    apply min_le_min
    · simpa only [add_zero] using add_le_add
        (add_le_add (add_le_add le_rfl (show (0 : ℕ∞) ≤ v P.t from zero_le))
          (le_refl (v y))) (le_refl (2 : ℕ∞))
    · apply min_le_min _ le_rfl
      simpa only [add_zero] using add_le_add
        (add_le_add (le_refl (v (P.repCandidate y σ))) (show (0 : ℕ∞) ≤ v P.t from zero_le))
        (le_refl (1 : ℕ∞))
  dsimp [v] at hs
  have hv (z : ℤ) (hz : z ≠ 0) : emultiplicity (2 : ℤ) z = (padicValInt 2 z : ℕ∞) := by
    exact emultiplicity_eq_padicValInt 2 hz
  rw [hv P.b hb, hv y hy, hv _ (P.repCandidate_ne_zero h hu hN hσ)] at hs
  rcases min_le_iff.mp hs with h1 | h2
  · have hn : padicValInt 2 P.b + padicValInt 2 y + 2 ≤ 2 * padicValInt 2 y + 2 := by exact_mod_cast h1
    left
    omega
  · rcases min_le_iff.mp h2 with h2 | h3
    · have hn : padicValInt 2 (P.repCandidate y σ) + 1 ≤ 2 * padicValInt 2 y + 2 := by exact_mod_cast h2
      right
      omega
    · have hn : 2 * padicValInt 2 P.b + 1 ≤ 2 * padicValInt 2 y + 2 := by exact_mod_cast h3
      left
      omega

/-- The odd-prime lower bound exactly as printed, with rational division. -/
theorem lemma32_odd_lower_published (P : Parameters) {x y σ : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hy : y ≠ 0)
    (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0) (hσ : σ = 1 ∨ σ = -1)
    (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2) :
    min (padicValInt p P.b : ℚ) ((padicValInt p (P.repCandidate y σ) : ℚ) / 2) ≤
      (padicValInt p y : ℚ) := by
  rcases P.lemma32_odd_lower_from_chain h hb hy hu hN hσ p hp2 with hb' | hr'
  · exact (min_le_left _ _).trans (by exact_mod_cast hb')
  · apply (min_le_right _ _).trans
    have hh : (padicValInt p (P.repCandidate y σ) : ℚ) ≤ 2 * padicValInt p y := by
      exact_mod_cast hr'
    linarith

/-- Equation (3.6) and the immediately following even-k₂ refinement, derived
from the printed chain and integrality of ε. -/
theorem paper_eq36 (P : Parameters) [Fact (¬ IsSquare P.d)] {x y σ : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hy : y ≠ 0)
    (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0) (hσ : σ = 1 ∨ σ = -1)
    (hi : IsIntegral ℤ P.epsilon) :
    min (padicValInt 2 P.b : ℚ)
        (((padicValInt 2 (P.repCandidate y σ) : ℚ) - 1) / 2) ≤ (padicValInt 2 y : ℚ) ∧
    (padicValInt 2 (P.repCandidate y σ) % 2 = 0 →
      min (padicValInt 2 P.b : ℚ) ((padicValInt 2 (P.repCandidate y σ) : ℚ) / 2) ≤
        (padicValInt 2 y : ℚ)) := by
  obtain ⟨ν, hν⟩ := P.four_dvd_epsilon_discriminant hi
  have hh := P.lemma32_two_lower_from_chain h hb hy hu hN hσ hν
  constructor
  · rcases hh with hb' | hr'
    · exact (min_le_left _ _).trans (by exact_mod_cast hb')
    · apply (min_le_right _ _).trans
      have he : (padicValInt 2 (P.repCandidate y σ) : ℚ) ≤ 2 * padicValInt 2 y + 1 := by
        exact_mod_cast hr'
      linarith
  · intro heven
    rcases hh with hb' | hr'
    · exact (min_le_left _ _).trans (by exact_mod_cast hb')
    · have hr : padicValInt 2 (P.repCandidate y σ) ≤ 2 * padicValInt 2 y := by omega
      have he : (padicValInt 2 (P.repCandidate y σ) : ℚ) ≤ 2 * padicValInt 2 y := by
        exact_mod_cast hr
      apply (min_le_right _ _).trans
      linarith

end «JNT-2024».Parameters

