module

public import «JNT-2024».ApproximationCriterion
public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».Section2
public import «JNT-2024».Section2Complex
public import «JNT-2024».Section2Gaussian
public import «JNT-2024».Section2Geometry
public import «JNT-2024».Section4Case44Algebra
public import «JNT-2024».Section4Case44Published
public import «JNT-2024».Section4Case45Algebra
public import «JNT-2024».Section4CutoffPublished
public import «JNT-2024».Section4ExactPublished
public import «JNT-2024».Section4NonexactApplication
public import «JNT-2024».Section4NonexactPublished
public import «JNT-2024».Section4Numerical
public import «JNT-2024».Section4TerminalPublished
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.Deriv.MeanValue
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

/-- The four printed cases, applied to the actual Section 2 approximants.
The numerical and sequence inputs are stated explicitly for subsequent
connection to the restored Lemma 3.13 and Proposition 4.1 hypotheses. -/
theorem four_cases_published {u₁ u₂ : ℤ} (data : Section2.PaperApproximants u₁ u₂)
    (hu₂ : u₂ ≠ 0) (hnear : ‖Section2.omega (-1) u₁ u₂-1‖<1)
    {p₀ q₀ : Section2.GaussianField} (hp : IsIntegral ℤ p₀) (hq : IsIntegral ℤ q₀)
    (hqne : q₀ ≠ 0) {N d y z M X : ℝ}
    (hN : 0 < N) (hNd : N < d) (hd112 : 112 ≤ d) (hy : 0 < y) (hz : 0 < z)
    (hM2 : 2 ≤ M) (hyN : N/4 ≤ y)
    (hcut : 137*N*Real.sqrt N/(Real.sqrt d*M^2) ≤ y)
    (hMN : N^2*M^4/d^4 ≤ (2:ℝ)^20/17^4)
    (hE : 1 < Section2.E (-1) u₁ u₂) (hQ : 190 < Section2.Q (-1) u₁ u₂)
    (hElow : (1832/10000 : ℝ)*M*Real.sqrt d*y/N < Section2.E (-1) u₁ u₂)
    (hQup : Section2.Q (-1) u₁ u₂ < (2147/100 : ℝ)*Real.sqrt d*y/M)
    (hX : (9682/10000 : ℝ)*(Real.sqrt d*y) < |X|)
    (hell : Section2.ell (-1) u₁ u₂ < (615/1000 : ℝ)*Real.sqrt N/|X|)
    (hchord : ‖Section2.omega (-1) u₁ u₂-1‖/2=Real.sqrt N/(Real.sqrt d*y))
    (hnorm : ‖Section2.gaussianEmbedding q₀‖^4=y*z)
    (hgap : (5732/100 : ℝ)*d^2*y^3 < N^2*z)
    (herror : ‖Section2.omega (-1) u₁ u₂^(1/4 : ℂ)-
      Section2.gaussianEmbedding p₀/Section2.gaussianEmbedding q₀‖ <
      2*Real.sqrt N/((3959/1000 : ℝ)*Real.sqrt d*z)) : False := by
  have hd := hN.trans hNd
  have hM : 0 < M := by linarith
  have hc : (0:ℝ)<3/4 := by norm_num
  let r := Approximation.firstIndex (Q := Section2.Q (-1) u₁ u₂)
    (ℓ := Section2.ell (-1) u₁ u₂) hE hc (Section2.gaussianEmbedding q₀)
  have hr : 1 ≤ r := (Approximation.firstIndex_spec hE hc (Section2.gaussianEmbedding q₀)).1
  have h417 (hr' : 1 < r) :
      ((8537/1000 : ℝ)/M)^4*(N/1)^2*(3/4 : ℝ)^4*
      ((1832/10000 : ℝ)*M/N)^(4*r)*d^(2*r)*y^(4*r-1) < z := by
    apply cutoff_equation417_application hE hQ (Section2.ell_pos (by norm_num) hu₂) hc
      hN hd hy (by norm_num) hM hX hell hElow (Section2.gaussianEmbedding q₀)
      (by simpa using hnorm) hr'
  by_cases he : data.pr r*q₀-data.qr r*p₀=0
  · have hl := exact_comparison_error_printed data hu₂ hnear hqne hr he
    rw [hchord] at hl
    have h415 := exact_equation415 hN hd hy hz hr hl herror
    by_cases hr1 : r=1
    · rw [hr1] at h415
      have hu := exact_equation415_index_one hN hd hy (by simpa only [Nat.cast_one] using h415)
      apply case43_contradiction hN hNd hy hgap
      have hm := mul_lt_mul_of_pos_left hu hN
      convert hm using 1
      field_simp
    · have hr' : 1 < r := by omega
      have hred := case45_remove_square_root hN hd hy (by norm_num : (0:ℝ)<1) hM hr (h417 hr') h415
      have hpre := exact_equation422_before_norm hN hd hy (by norm_num : (0:ℝ)<1) hM hr hred
      have h422 := exact_equation422 hN hNd (by norm_num : (0:ℝ)<1) hpre
      apply case45_contradiction_printed hN hd hM hr' hcut
      simpa only [one_pow,div_one] using h422
  · have h411 := nonexact_paper_bound data hu₂ hp hq hqne hN hd hy hz
      (by norm_num : (0:ℝ)<1) hM hE (by linarith) hc (by norm_num) hQup
      (by simpa using hnorm) herror he
    change z^3 < (N*1)^2*((64/100 : ℝ)/(1-3/4))^4*((2147/100 : ℝ)/M)^(4*r)*
      d^(2*r-2)*y^(4*r+1) at h411
    by_cases hr1 : r=1
    · rw [hr1] at h411
      have h412 := nonexact_equation412 hN hy (by norm_num : (0:ℝ)<1) hM2 (by norm_num) h411
      apply case42_contradiction_printed hN hNd hd112 hyN hgap
      convert h412 using 1
      norm_num
    · have hr' : 1 < r := by omega
      have h418 := nonexact_equation418 hN hd hy (by norm_num : (0:ℝ)<1) hM hc (h417 hr') h411
      have h419 := nonexact_equation419_normalized hN hd hy (by norm_num : (0:ℝ)<1) hM hr h418
      have h420 := nonexact_equation420 hN hd hy hM hMN (by simpa only [one_pow,one_mul] using h419)
      apply case44_contradiction hN hd hM _ hr' h420
      apply lt_of_lt_of_le _ hcut
      apply (div_lt_div_iff_of_pos_right (by positivity : 0 < Real.sqrt d*M^2)).mpr
      have hh : 0 < N*Real.sqrt N := by positivity
      nlinarith only [hh]

end «JNT-2024».Section4
