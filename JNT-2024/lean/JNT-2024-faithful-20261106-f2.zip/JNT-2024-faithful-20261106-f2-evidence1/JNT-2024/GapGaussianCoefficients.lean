module

public import «JNT-2024».RepresentationFactors
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- The two common assertions in (3.16) also hold in the Gaussian case,
by the stronger printed divisor f | b². -/
theorem unit_representation_coefficients_gaussian (P : Parameters) {f : ℤ}
    (hb : 0 < P.b) (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha))
    (hf : 0 < f) (hd : f ∣ P.b ^ 2) :
    f ∣ 4 * P.b ^ 2 * squarefreePart |P.normAlpha| ∧
    (f : ℝ) ^ 2 < 16 * (P.b : ℝ) ^ 4 * (squarefreePart |P.normAlpha| : ℝ) := by
  have hs : squarefreePart |P.normAlpha| = 1 := by
    rw [squarefreePart_abs (ne_of_lt hn), squarefreePart_eq_neg_one (ne_of_lt hn) hNs]
    norm_num
  rw [hs]
  constructor
  · simpa only [mul_one] using hd.trans (dvd_mul_left (P.b ^ 2) 4)
  · have hle : (f : ℝ) ≤ (P.b : ℝ) ^ 2 := by
      exact_mod_cast Int.le_of_dvd (sq_pos_of_pos hb) hd
    have hfp : (0 : ℝ) ≤ f := by exact_mod_cast hf.le
    have hsq := pow_le_pow_left₀ hfp hle 2
    have hbR : (0 : ℝ) < P.b := by exact_mod_cast hb
    have hb4 : (0 : ℝ) < (P.b : ℝ) ^ 4 := by positivity
    norm_num
    nlinarith only [hsq, hb4]

end «JNT-2024».Parameters
