module

public import «JNT-2024».GrowthBounds
public import «JNT-2024».Integrality
public import «JNT-2024».Monotonicity
public import «JNT-2024».Sequence
public import «JNT-2024».UnitIntegralityCases
public import «JNT-2024».UnitSequenceIntegrality
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section5Revised

theorem odd_square_eight : ∀ n:ZMod 8, n.val%2=1 → n^2=1 := by decide +kernel

/-- The modulo-eight step printed in the revised Lemma 5.2. -/
theorem unit_one_parity : ∀ a t:ZMod 8, t^2-(a^2+1)=4 →
    a.val%2=0 ∧ t.val%2=1 ∧ (t^2+(a^2+1)).val=6 := by decide +kernel

theorem doubled_recurrence {f : ℕ → ℚ} {T B : ℤ} (h0 : f 0=1)
    (h1 : 2*f 1=(B:ℚ)) (hrec : ∀ n, f (n+2)=(T:ℚ)*f (n+1)-f n) (n : ℕ) :
    2*f n=(integerUnitRecurrence T 1 2 B n:ℚ) := by
  induction n using Nat.twoStepInduction with
  | zero => simp [h0,integerUnitRecurrence]
  | one => exact h1
  | more n h₀ h₁ =>
    rw [hrec,integerUnitRecurrence]
    push_cast
    linear_combination (T:ℚ)*h₁ - h₀

/-- Odd trace and odd doubled first term give precisely the period-three
integrality pattern, by the already proved integer recurrence argument. -/
theorem integral_iff_three_of_recurrence {f : ℕ → ℚ} {T B : ℤ}
    (hT : Odd T) (hB : Odd B) (h0 : f 0=1) (h1 : 2*f 1=(B:ℚ))
    (hrec : ∀ n, f (n+2)=(T:ℚ)*f (n+1)-f n) (n : ℕ) :
    (∃ z:ℤ, f n=(z:ℚ)) ↔ 3 ∣ n := by
  exact (rational_integral_iff_double_even (doubled_recurrence h0 h1 hrec n)).trans
    (integerUnitRecurrence_even_iff_three T 1 2 B hT (by decide) (by decide) hB n)

end Section5Revised
namespace Parameters

theorem odd_norm_unit_one_trace (P : Parameters) (hp : P.Pell) (hb : P.b=1)
    (hNs : IsSquare (-P.normAlpha)) (ho : Odd (-P.normAlpha)) (hu : P.u=1) :
    ∃ T Bp Bm : ℤ, Odd T ∧ Odd Bp ∧ Odd Bm ∧
      P.traceCoeff=(T:ℚ) ∧ 2*P.y hp 1=(Bp:ℚ) ∧ 2*P.y hp (-1)=(Bm:ℚ) := by
  obtain ⟨n,hn⟩ := hNs
  have hn2 : -P.normAlpha=n^2 := by simpa only [pow_two] using hn
  have hno : Odd n := by have hh : Odd (n^2) := hn2 ▸ ho; simpa [Int.odd_pow] using hh
  have hd : P.d=P.a^2+n^2 := by simp only [normAlpha,hb,one_pow,one_mul] at hn2; linarith
  have hnv := ZMod.val_intCast (n:=8) n
  have hnmod := Int.odd_iff.mp hno
  have hn8 : (n:ZMod 8)^2=1 := Section5Revised.odd_square_eight n (by omega)
  have hdc := congrArg (fun z:ℤ => (z:ZMod 8)) hd
  push_cast at hdc
  rw [hn8] at hdc
  have he : (P.t:ZMod 8)^2-((P.a:ZMod 8)^2+1)=4 := by
    rcases hp with hp | hp <;>
      have hh := congrArg (fun z:ℤ => (z:ZMod 8)) hp <;>
      simp only [hu,Int.cast_sub,Int.cast_pow,Int.cast_mul,Int.cast_one,one_pow,mul_one,hdc] at hh
    · exact hh
    · norm_num at hh; exact hh
  have hm := Section5Revised.unit_one_parity P.a P.t he
  have hd5 : P.d%8=5 := by
    have hc : ∀ a t:ZMod 8, t^2-(a^2+1)=4 → a^2+1=5 := by decide +kernel
    have hv := ZMod.val_intCast (n:=8) P.d
    rw [hdc,hc P.a P.t he] at hv
    norm_num [ZMod.val_ofNat] at hv
    omega
  have hto : Odd P.t := Int.odd_iff.mpr (by
    have hv := ZMod.val_intCast (n:=8) P.t
    omega)
  have hav := ZMod.val_intCast (n:=8) P.a
  have hae : Even P.a := Int.even_iff.mpr (by omega)
  have hv := ZMod.val_intCast (n:=8) (P.t^2+P.d)
  rw [Int.cast_add,Int.cast_pow,hdc] at hv
  rw [hm.2.2] at hv
  let T : ℤ := (P.t^2+P.d)/2
  have hTe : 2*T=P.t^2+P.d := by dsimp [T]; omega
  have hTo : Odd T := Int.odd_iff.mpr (by dsimp [T]; omega)
  have hTc : (2:ℚ)*(T:ℚ)=(P.t:ℚ)^2+P.d := by exact_mod_cast hTe
  refine ⟨T,T+P.a*P.t,T-P.a*P.t,hTo,
    hTo.add_even (hae.mul_right _),hTo.sub_even (hae.mul_right _),?_,?_,?_⟩
  · simp only [traceCoeff,hu,Int.cast_one,one_pow,mul_one]
    linarith only [hTc]
  · rw [P.y_one,hb,hu]
    push_cast
    linarith only [hTc]
  · rw [P.y_neg_one,hb,hu]
    push_cast
    linarith only [hTc]

/-- Every integer index, including the negative tail, in the printed recurrence
claim: when the negative norm is an odd square and u=1, y_k is integral iff 3|k. -/
theorem integral_iff_three_revised (P : Parameters) (hp : P.Pell) (hb : P.b=1)
    (hNs : IsSquare (-P.normAlpha)) (ho : Odd (-P.normAlpha)) (hu : P.u=1)
    (k : ℤ) : (∃ z:ℤ, P.y hp k=(z:ℚ)) ↔ 3 ∣ k := by
  obtain ⟨T,Bp,Bm,hT,hBp,hBm,htrace,hyp,hym⟩ := P.odd_norm_unit_one_trace hp hb hNs ho hu
  have pos (n : ℕ) : (∃ z:ℤ, P.y hp (n:ℤ)=(z:ℚ)) ↔ (3:ℕ) ∣ n := by
    refine Section5Revised.integral_iff_three_of_recurrence
      (f := fun j => P.y hp (j:ℤ)) hT hBp
      (by simp [hb]) (by simpa using hyp) ?_ n
    intro j
    have hh := P.y_recurrence hp ((j:ℤ)+1)
    change P.y hp ((j:ℤ)+1+1)=P.traceCoeff*P.y hp ((j:ℤ)+1)-P.y hp ((j:ℤ)+1-1) at hh
    simpa [htrace,Nat.cast_add,add_assoc] using hh
  have neg (n : ℕ) : (∃ z:ℤ, P.y hp (-(n:ℤ))=(z:ℚ)) ↔ (3:ℕ) ∣ n := by
    refine Section5Revised.integral_iff_three_of_recurrence
      (f := fun j => P.y hp (-(j:ℤ))) hT hBm
      (by simp [hb]) (by simpa using hym) ?_ n
    intro j
    have hh := P.y_reverse_recurrence hp (-((j:ℤ)+1))
    change P.y hp (-((j:ℤ)+1)-1)=P.traceCoeff*P.y hp (-((j:ℤ)+1))-P.y hp (-((j:ℤ)+1)+1) at hh
    convert hh using 1 <;> simp [htrace,Nat.cast_add] <;> ring_nf
  rcases le_total 0 k with hk | hk
  · have he : (k.natAbs:ℤ)=k := by simp [abs_of_nonneg hk]
    have hd : (3:ℕ) ∣ k.natAbs ↔ (3:ℤ) ∣ (k.natAbs:ℤ) := by
      constructor <;> intro hh <;> exact_mod_cast hh
    simpa only [he] using (pos k.natAbs).trans hd
  · have he : -(k.natAbs:ℤ)=k := (Int.eq_neg_natAbs_of_nonpos hk).symm
    have hd : (3:ℕ) ∣ k.natAbs ↔ (3:ℤ) ∣ -(k.natAbs:ℤ) := by
      rw [dvd_neg]
      constructor <;> intro hh <;> exact_mod_cast hh
    simpa only [he] using (neg k.natAbs).trans hd

end Parameters
end «JNT-2024»
