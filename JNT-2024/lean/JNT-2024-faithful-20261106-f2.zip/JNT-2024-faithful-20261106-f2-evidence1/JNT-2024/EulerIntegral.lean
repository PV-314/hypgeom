module

public import «JNT-2024».BinomialKernel
public import «JNT-2024».EulerBeta
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

open MeasureTheory
open scoped Interval

namespace «JNT-2024»
namespace Hypergeometric

noncomputable def chord (z : ℂ) (t : ℝ) : ℂ := 1 + (z - 1) * t

theorem chord_mem_slitPlane {z : ℂ} (hz : z ∈ Complex.slitPlane) {t : ℝ}
    (ht : t ∈ Set.Icc 0 1) : chord z t ∈ Complex.slitPlane := by
  simpa [chord, Complex.real_smul, mul_comm] using
    StarConvex.add_smul_mem Complex.starConvex_one_slitPlane
      (by simpa using hz : 1 + (z - 1) ∈ Complex.slitPlane) ht.1 ht.2

noncomputable def eulerKernel (a : ℂ) (r : ℕ) (z : ℂ) (t : ℝ) : ℂ :=
  (t : ℂ) ^ r * (1 - (t : ℂ)) ^ r * chord z t ^ (-a)

/-- Euler's integral candidate for `₂F₁(a,r+1;2r+2;1-z)`, using the principal branch. -/
noncomputable def eulerHypergeometric (a : ℂ) (r : ℕ) (z : ℂ) : ℂ :=
  eulerNormalizer r * ∫ t : ℝ in 0..1, eulerKernel a r z t

theorem eulerKernel_continuousOn (a : ℂ) (r : ℕ) {z : ℂ} (hz : z ∈ Complex.slitPlane) :
    ContinuousOn (eulerKernel a r z) (Set.Icc 0 1) := by
  unfold eulerKernel
  apply ContinuousOn.mul (by fun_prop)
  apply ContinuousOn.cpow (by unfold chord; fun_prop) continuousOn_const
  exact fun t ht => chord_mem_slitPlane hz ht

theorem eulerKernel_intervalIntegrable (a : ℂ) (r : ℕ) {z : ℂ} (hz : z ∈ Complex.slitPlane) :
    IntervalIntegrable (eulerKernel a r z) volume 0 1 := by
  apply ContinuousOn.intervalIntegrable
  simpa using eulerKernel_continuousOn a r hz

theorem eulerHypergeometric_one (a : ℂ) (r : ℕ) : eulerHypergeometric a r 1 = 1 := by
  simpa [eulerHypergeometric, eulerKernel, chord, betaMoment] using eulerNormalizer_mul_betaMoment r

theorem eulerKernel_term_integral (a : ℂ) (r j : ℕ) (z : ℂ) :
    (∫ t : ℝ in 0..1, (t : ℂ) ^ r * (1 - (t : ℂ)) ^ r *
      (binomialCoefficient a j * ((1 - z) * t) ^ j)) =
      binomialCoefficient a j * (1 - z) ^ j * betaMoment (r + j) r := by
  rw [betaMoment, ← intervalIntegral.integral_const_mul]
  apply intervalIntegral.integral_congr
  intro t _
  simp only [mul_pow, pow_add]
  ring

theorem eulerKernel_hasSum_integral (a : ℂ) (r : ℕ) {z : ℂ} (hz : ‖1 - z‖ < 1) :
    HasSum (fun j : ℕ => binomialCoefficient a j * (1 - z) ^ j * betaMoment (r + j) r)
      (∫ t : ℝ in 0..1, eulerKernel a r z t) := by
  let F : ℕ → ℝ → ℂ := fun j t => (t : ℂ) ^ r * (1 - (t : ℂ)) ^ r *
    (binomialCoefficient a j * ((1 - z) * t) ^ j)
  let B : ℕ → ℝ := fun j => ‖binomialCoefficient a j‖ * ‖1 - z‖ ^ j
  have hB : Summable B := binomialKernel_summable_norm a hz
  have hnorm : ∀ {t : ℝ}, t ∈ Ι (0 : ℝ) 1 → ‖(t : ℂ)‖ ≤ 1 ∧ ‖1 - (t : ℂ)‖ ≤ 1 := by
    intro t ht
    simp only [Set.uIoc_of_le zero_le_one, Set.mem_Ioc] at ht
    rw [show 1 - (t : ℂ) = ((1 - t : ℝ) : ℂ) by push_cast; rfl]
    simp only [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg ht.1.le,
      abs_of_nonneg (sub_nonneg.mpr ht.2)]
    constructor <;> linarith
  have hbound : ∀ j t, t ∈ Ι (0 : ℝ) 1 → ‖F j t‖ ≤ B j := by
    intro j t ht
    have hh := hnorm ht
    have ht₁ : ‖(t : ℂ)‖ ^ r ≤ 1 := pow_le_one₀ (norm_nonneg _) hh.1
    have ht₂ : ‖1 - (t : ℂ)‖ ^ r ≤ 1 := pow_le_one₀ (norm_nonneg _) hh.2
    have ht₃ : ‖(t : ℂ)‖ ^ j ≤ 1 := pow_le_one₀ (norm_nonneg _) hh.1
    dsimp [F, B]
    simp only [norm_mul, norm_pow, mul_pow]
    calc
      _ ≤ 1 * 1 * (‖binomialCoefficient a j‖ * (‖1 - z‖ ^ j * 1)) := by gcongr
      _ = _ := by ring
  have hlim : ∀ t, t ∈ Ι (0 : ℝ) 1 → HasSum (fun j => F j t) (eulerKernel a r z t) := by
    intro t ht
    have hw : ‖(1 - z) * (t : ℂ)‖ < 1 := by
      rw [norm_mul]
      exact lt_of_le_of_lt (mul_le_of_le_one_right (norm_nonneg _) (hnorm ht).1) hz
    have hh := (binomialKernel_hasSum a hw).mul_left ((t : ℂ) ^ r * (1 - (t : ℂ)) ^ r)
    have he : 1 - (1 - z) * (t : ℂ) = chord z t := by unfold chord; ring
    simpa only [F, eulerKernel, he] using hh
  have hh := intervalIntegral.hasSum_integral_of_dominated_convergence
    (μ := volume) (a := 0) (b := 1)
    (F := F) (f := eulerKernel a r z) (fun j _ => B j)
    (fun j => (show Continuous (F j) by dsimp [F]; fun_prop).aestronglyMeasurable)
    (fun j => ae_of_all _ (hbound j))
    (ae_of_all _ (fun _ _ => hB)) intervalIntegrable_const (ae_of_all _ hlim)
  simpa only [F, eulerKernel_term_integral] using hh

/-- Agreement with the defining series, proved by integrating its binomial expansion. -/
theorem eulerHypergeometric_eq_series (a : ℂ) (r : ℕ) {z : ℂ} (hz : ‖1 - z‖ < 1) :
    eulerHypergeometric a r z = ₂F₁ a (r + 1) (2 * r + 2) (1 - z) := by
  have hh := (eulerKernel_hasSum_integral a r hz).mul_left (eulerNormalizer r)
  have hc : ∀ j, eulerNormalizer r *
      (binomialCoefficient a j * (1 - z) ^ j * betaMoment (r + j) r) =
      ordinaryHypergeometricCoefficient a (r + 1) (2 * r + 2) j * (1 - z) ^ j := by
    intro j
    calc
      _ = binomialCoefficient a j * (eulerNormalizer r * betaMoment (r + j) r) * (1 - z) ^ j := by ring
      _ = _ := by rw [eulerNormalizer_moment]; unfold binomialCoefficient ordinaryHypergeometricCoefficient; ring
  simp_rw [hc] at hh
  exact hh.tsum_eq.symm.trans (by rw [ordinaryHypergeometric_eq_tsum]; rfl)

end Hypergeometric
end «JNT-2024»
