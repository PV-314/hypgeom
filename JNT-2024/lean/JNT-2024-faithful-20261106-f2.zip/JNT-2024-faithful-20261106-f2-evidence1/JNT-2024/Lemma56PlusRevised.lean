module

public import «JNT-2024».Lemma55PlusPublished
public import «JNT-2024».Lemma56NormalizerPublished
public import «JNT-2024».NormalizerBounds
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».Section5CongruencesRevised
public import «JNT-2024».Section5GcdNormalization
public import «JNT-2024».Section5ResidueTransfer
public import «JNT-2024».Section5Residues
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.Deriv.MeanValue
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Pow.Real
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.LegendreSymbol.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section
namespace «JNT-2024».Section5Revised

theorem root_two_square32 : ∀ n:ZMod 32, n.val%4=2 → n^2=4 := by decide +kernel

theorem square_factor_eight : ∀ x:ZMod 32,
    Section5.FourSquareResidue32 (x^2+4) → x.val%8=0 := by decide +kernel

theorem square_factor_four : ∀ x:ZMod 32,
    Section5.FourSquareResidue32 (x^2+4) → x.val%4=0 := by decide +kernel

/-- The selected factor in the printed positive-unit contradiction. -/
theorem plus_root_two_impossible {a n t u v x:ℤ} (hno : n%4=2) (hu : Odd u)
    (hp : t^2=(a^2+n^2)*u^2+4) (hx : x=t+a*u ∨ x=t-a*u)
    (hs : x^2+(n*u)^2=4*v^2) : False := by
  have huo := Int.odd_iff.mp hu
  have hnprod : (n*u)%4=2 := by
    rw [Int.mul_emod,hno]
    have hh : u%4=1 ∨ u%4=3 := by omega
    rcases hh with hh | hh <;> rw [hh] <;> norm_num
  have hnv := ZMod.val_intCast (n:=32) (n*u)
  have hn32 : ((n*u:ℤ):ZMod 32)^2=4 := root_two_square32 ((n*u:ℤ):ZMod 32) (by omega)
  have he32 := congrArg (fun z:ℤ => (z:ZMod 32)) hs
  simp only [Int.cast_add,Int.cast_pow,Int.cast_mul,Int.cast_ofNat] at he32
  have hn32' : ((n:ZMod 32)*u)^2=4 := by simpa using hn32
  rw [hn32'] at he32
  have hfour := Section5.four_square_residue32 (v:ZMod 32)
  rw [← he32] at hfour
  have hxv := ZMod.val_intCast (n:=32) x
  have hx4 : (4:ℤ) ∣ x := Int.dvd_of_emod_eq_zero (by
    have := square_factor_four x hfour; omega)
  have hp16 := congrArg (fun z:ℤ => (z:ZMod 16)) hp
  push_cast at hp16
  have hnp16 := ZMod.val_intCast (n:=16) ((n*u)^2)
  have hnp32 := ZMod.val_intCast (n:=32) ((n*u)^2)
  rw [Int.cast_pow,hn32] at hnp32
  norm_num [ZMod.val_ofNat] at hnp32
  have hn16 : ((n:ZMod 16)*u)^2=4 := by
    apply ZMod.val_injective 16
    simp only [Int.cast_pow,Int.cast_mul] at hnp16
    norm_num [ZMod.val_ofNat]; omega
  have hpt : (t:ZMod 16)^2=((a:ZMod 16)*u)^2+8 := by
    linear_combination hp16 + hn16
  have hpar := plus_eight_parity ((a:ZMod 16)*u) t hpt
  have hav := ZMod.val_intCast (n:=16) (a*u)
  have htv := ZMod.val_intCast (n:=16) t
  simp only [Int.cast_mul] at hav
  have hao : Odd (a*u) := Int.odd_iff.mpr (by omega)
  have hto : Odd t := Int.odd_iff.mpr (by omega)
  have hxnot8 : ¬(8:ℤ) ∣ x := by
    intro hx8
    have hprod : (16:ℤ) ∣ t^2-(a*u)^2 := by
      rcases hx with hx | hx
      · have hh := mul_dvd_mul hx8 (even_iff_two_dvd.mp (hto.sub_odd hao))
        rw [hx] at hh
        convert hh using 1 <;> ring
      · have hh := mul_dvd_mul hx8 (even_iff_two_dvd.mp (hto.add_odd hao))
        rw [hx] at hh
        convert hh using 1 <;> ring
    have hz := (ZMod.intCast_zmod_eq_zero_iff_dvd (t^2-(a*u)^2) 16).mpr hprod
    push_cast at hz
    rw [hpt] at hz
    norm_num at hz
    exact (by decide : (8:ZMod 16) ≠ 0) hz
  have hxmod : x%8=4 := by
    have h4 := Int.emod_eq_zero_of_dvd hx4
    have h8 : x%8 ≠ 0 := fun hh => hxnot8 (Int.dvd_of_emod_eq_zero hh)
    omega
  have hx32 := square_sixteen_root x (by omega)
  rw [hx32] at he32
  have he20 : (4:ZMod 32)*(v:ZMod 32)^2=20 := by norm_num at he32 ⊢; exact he32.symm
  have hv5 : v^2%8=5 := by
    have hv := ZMod.val_intCast (n:=32) (4*v^2)
    rw [Int.cast_mul,Int.cast_pow,Int.cast_ofNat,he20] at hv
    norm_num [ZMod.val_ofNat] at hv
    omega
  have hnever : ∀ z:ZMod 8, z^2 ≠ 5 := by decide +kernel
  apply hnever v
  apply ZMod.val_injective 8
  have hv := ZMod.val_intCast (n:=8) (v^2)
  rw [Int.cast_pow] at hv
  norm_num [ZMod.val_ofNat]
  omega

end Section5Revised
namespace Parameters

/-- The revised positive-unit exclusion: first u=2,4 by modulo three,
then the two root residues for u=1,3. -/
theorem lemma56_plus_excluded_revised (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hNs : IsSquare (-P.normAlpha)) (heven : Even (-P.normAlpha))
    (hadj : P.AdjacentSquare h.pell) (hu4 : P.u ≤ 4)
    (hbound : (P.normalizerSquare:ℤ)*P.u^2 ≤ 324) :
    P.t^2-P.d*P.u^2 ≠ 4 := by
  intro hplus
  obtain ⟨n,hn⟩ := hNs
  have hn2 : -P.normAlpha=n^2 := by simpa [pow_two] using hn
  have hne : Even n := by have hh : Even (n^2) := hn2 ▸ heven; simpa [Int.even_pow] using hh
  have hd : P.d=P.a^2+n^2 := by simp only [normAlpha,hb,one_pow,one_mul] at hn2; linarith
  have hu13 : P.u=1 ∨ P.u=3 := by
    have hall : P.u=1 ∨ P.u=2 ∨ P.u=3 ∨ P.u=4 := by have := h.u_pos; omega
    rcases hall with h1 | h2 | h3 | h4
    · exact Or.inl h1
    · have hg9 := (P.lemma55_plus_divisibility h.pell hb hn2 hplus (by simp [h2]) hadj).2.2.2.2
      have hM := P.lemma56_even_nine_normalizer h hb ⟨n,hn⟩ heven hg9
      have hMi : (144:ℤ) ≤ P.normalizerSquare := by exact_mod_cast hM
      rw [h2] at hbound; norm_num at hbound; omega
    · exact Or.inr h3
    · have hg9 := (P.lemma55_plus_divisibility h.pell hb hn2 hplus (by simp [h4]) hadj).2.2.2.2
      have hM := P.lemma56_even_nine_normalizer h hb ⟨n,hn⟩ heven hg9
      have hMi : (144:ℤ) ≤ P.normalizerSquare := by exact_mod_cast hM
      rw [h4] at hbound; norm_num at hbound; omega
  have huo : Odd P.u := by rcases hu13 with he | he <;> rw [he] <;> decide
  have hp : P.t^2=(P.a^2+n^2)*P.u^2+4 := by rw [← hd]; linarith
  by_cases hn4 : n%4=2
  · obtain ⟨v,hv | hv⟩ := P.section5_adjacent_equations h.pell hb hadj
    · apply Section5Revised.plus_root_two_impossible (v:=v) hn4 huo hp (Or.inl rfl)
      rw [hd] at hv
      nlinarith only [hv]
    · apply Section5Revised.plus_root_two_impossible (v:=v) hn4 huo hp (Or.inr rfl)
      rw [hd] at hv
      nlinarith only [hv]
  have hn0 : (4:ℤ) ∣ n := Int.dvd_of_emod_eq_zero (by have := Int.even_iff.mp hne; omega)
  have hn16 : (n:ZMod 16)^2=0 := by
    have hh := (ZMod.intCast_zmod_eq_zero_iff_dvd (n^2) 16).mpr (pow_dvd_pow_of_dvd hn0 2)
    simpa using hh
  have hp16 := congrArg (fun z:ℤ => (z:ZMod 16)) hp
  push_cast at hp16
  rw [hn16] at hp16
  have hp16' : (P.t:ZMod 16)^2=((P.a:ZMod 16)*P.u)^2+4 := by linear_combination hp16
  have ha0 := Section5Revised.plus_four_divisibility ((P.a:ZMod 16)*P.u) P.t hp16'
  have hav := ZMod.val_intCast (n:=16) (P.a*P.u)
  simp only [Int.cast_mul] at hav
  have hamod : (P.a*P.u)%4=0 := by omega
  have ha4 : (4:ℤ) ∣ P.a := Int.dvd_of_emod_eq_zero (by
    rcases hu13 with he | he <;> rw [he] at hamod <;> omega)
  have hg16 : 16 ∣ P.baseGcd := by
    rw [P.section5_baseGcd hb hn2]
    exact pow_dvd_pow_of_dvd (Int.dvd_gcd ha4 hn0) 2
  have hgpos := P.baseGcd_pos (ne_of_gt h.a_pos)
  have hMbase := P.lemma56_normalizer_ge_four_gcd h hb ⟨n,hn⟩
  rcases hu13 with hu1 | hu3
  · have hg9 := (P.lemma55_plus_divisibility h.pell hb hn2 hplus (by simp [hu1]) hadj).2.2.2.2
    have hg144 : 144 ∣ P.baseGcd := by
      rw [← show Nat.lcm 16 9=144 by decide]
      exact Nat.lcm_dvd hg16 hg9
    have hG := Nat.le_of_dvd hgpos hg144
    have hM : (576:ℤ) ≤ P.normalizerSquare := by exact_mod_cast (by omega : 576 ≤ P.normalizerSquare)
    rw [hu1] at hbound; norm_num at hbound; omega
  · have hG := Nat.le_of_dvd hgpos hg16
    have hM : (64:ℤ) ≤ P.normalizerSquare := by exact_mod_cast (by omega : 64 ≤ P.normalizerSquare)
    rw [hu3] at hbound; norm_num at hbound; omega

end Parameters
end «JNT-2024»
