module

public import «JNT-2024».Section4SmallPairs
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

set_option maxRecDepth 100000
set_option maxHeartbeats 0

/-- Additional positive solutions from the source Magma output, restricted to d<=111.
The first pair is (a,sqrt(-N)), the second is (x,y). -/
def extraQuarticSolutions : Finset ((ℕ × ℕ) × (ℕ × ℕ)) :=
  {((2,2),(478,13)), ((1,3),(79,5)), ((2,3),(1042,17)),
   ((1,4),(16,2)), ((1,4),(103,5)), ((3,3),(717,13)),
   ((4,4),(956,13)), ((2,6),(158,5)), ((4,5),(160,5)),
   ((5,5),(1195,13)), ((4,6),(2084,17)), ((3,7),(90483,109)),
   ((7,4),(32,2)), ((2,8),(32,2)), ((2,8),(206,5)),
   ((6,6),(1434,13)), ((7,5),(215,5)), ((1,9),(81,3)),
   ((3,9),(237,5)), ((7,7),(1673,13))}

def listedQuarticSolutions (a n : ℕ) : Finset (ℕ × ℕ) :=
  {(a,1)} ∪ ((extraQuarticSolutions.filter fun r => r.1=(a,n)).image Prod.snd)

/-- Every listed pair really is a positive solution. This is not completeness. -/
theorem listedQuarticSolutions_sound : ∀ p ∈ smallPairs,
    ∀ s ∈ listedQuarticSolutions p.1 p.2,
      0 < s.1 ∧ 0 < s.2 ∧ s.1^2+p.2^2=(p.1^2+p.2^2)*s.2^4 := by decide +kernel

theorem listedQuarticSolutions_counts :
    (smallPairs.filter fun p => 2 ≤ (listedQuarticSolutions p.1 p.2).card).card=18 ∧
    (smallPairs.filter fun p => 3 ≤ (listedQuarticSolutions p.1 p.2).card)={(1,4),(2,8)} ∧
    (∀ p ∈ smallPairs, (listedQuarticSolutions p.1 p.2).card ≤ 3) := by decide +kernel

theorem listedQuarticSolutions_17_68 :
    listedQuarticSolutions 1 4 = {(1,1),(16,2),(103,5)} ∧
    listedQuarticSolutions 2 8 = {(2,1),(32,2),(206,5)} := by decide +kernel

theorem listedQuarticSolutions_height :
    ∀ p ∈ smallPairs, ∀ s ∈ listedQuarticSolutions p.1 p.2, s.2 ≤ 109 := by decide +kernel

/-- Exhaustive finite certificate, explicitly restricted to 1<=y<=109. -/
theorem smallQuartic_finite_certificate : ∀ a n : Fin 11, (a.val,n.val) ∈ smallPairs →
    ∀ y : Fin 110, 0 < y.val →
      let x := Nat.sqrt ((a.val^2+n.val^2)*y.val^4-n.val^2)
      x^2+n.val^2=(a.val^2+n.val^2)*y.val^4 →
      (x,y.val) ∈ listedQuarticSolutions a.val n.val := by decide +kernel

/-- Completeness within the stated height bound, with no bound assumed on x. -/
theorem smallQuartic_complete_bounded {a n x y : ℕ} (hp : (a,n) ∈ smallPairs)
    (hy : 0 < y) (hy109 : y ≤ 109) (he : x^2+n^2=(a^2+n^2)*y^4) :
    (x,y) ∈ listedQuarticSolutions a n := by
  have hh := (Finset.mem_filter.mp hp).1
  have ha := Finset.mem_range.mp (Finset.mem_product.mp hh).1
  have hn := Finset.mem_range.mp (Finset.mem_product.mp hh).2
  have hs : x^2=(a^2+n^2)*y^4-n^2 := by omega
  have hr : Nat.sqrt ((a^2+n^2)*y^4-n^2)=x := by rw [← hs,Nat.sqrt_eq']
  have hc := smallQuartic_finite_certificate ⟨a,ha⟩ ⟨n,hn⟩ hp ⟨y,by omega⟩ hy
  simpa only [hr] using hc (by simpa only [hr] using he)

/-- Explicit remaining obligation; a definition, not an axiom or a proved bound. -/
def SmallQuarticHeightBound : Prop :=
  ∀ a n x y : ℕ, (a,n) ∈ smallPairs → 0 < x → 0 < y →
    x^2+n^2=(a^2+n^2)*y^4 → y ≤ 109

/-- The unrestricted solution-list claim in Section 4.6. Not asserted as a theorem. -/
def SmallQuarticListsComplete : Prop :=
  ∀ a n x y : ℕ, (a,n) ∈ smallPairs →
    ((x,y) ∈ listedQuarticSolutions a n ↔
      0 < x ∧ 0 < y ∧ x^2+n^2=(a^2+n^2)*y^4)

/-- Precisely isolates what the finite certificates leave to prove. -/
theorem smallQuartic_completeness_iff_height :
    SmallQuarticListsComplete ↔ SmallQuarticHeightBound := by
  constructor
  · intro h a n x y hp hx hy he
    exact listedQuarticSolutions_height (a,n) hp (x,y) ((h a n x y hp).mpr ⟨hx,hy,he⟩)
  · intro h a n x y hp
    refine ⟨listedQuarticSolutions_sound (a,n) hp (x,y),?_⟩
    rintro ⟨hx,hy,he⟩
    exact smallQuartic_complete_bounded hp hy (h a n x y hp hx hy he) he

end «JNT-2024».Section4
