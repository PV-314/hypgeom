module

public import «JNT-2024».ApproximationGcd
public import «JNT-2024».NormalizerHighPublished
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».NormalizerPublished
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Approximation

/-- The quantity `d′` in (2.6). -/
def dPrime (S u₁ u₂ : ℤ) : ℚ := (u₂ : ℚ) ^ 2 * S / gSquared S u₁ u₂

/-- The `n = 4` instance of (2.1), written as the positive square root. -/
noncomputable def N4 (q : ℚ) : ℝ := Real.sqrt ((2 : ℝ) ^ min (padicValRat 2 q) 6)

noncomputable def normalizerProduct (S u₁ u₂ : ℤ) : ℝ := |g S u₁ u₂| * N4 (dPrime S u₁ u₂)

theorem N4_sq (q : ℚ) : N4 q ^ 2 = (2 : ℝ) ^ min (padicValRat 2 q) 6 := by
  exact Real.sq_sqrt (by positivity)

theorem normalizerProduct_nonneg (S u₁ u₂ : ℤ) : 0 ≤ normalizerProduct S u₁ u₂ := by
  unfold normalizerProduct N4
  positivity

theorem normalizerProduct_sq (S u₁ u₂ : ℤ) : normalizerProduct S u₁ u₂ ^ 2 =
    (gSquared S u₁ u₂ : ℝ) * (2 : ℝ) ^ min (padicValRat 2 (dPrime S u₁ u₂)) 6 := by
  rw [normalizerProduct, mul_pow, sq_abs, g_sq, N4_sq]

theorem dPrime_unit (S x c ν : ℤ) (hν : ν = 1 ∨ ν = -1) :
    dPrime S (2 * x) (2 * ν * c) = 4 * (c ^ 2 * S : ℤ) / gSquared S (2 * x) (2 * ν * c) := by
  unfold dPrime
  rcases hν with rfl | rfl <;> push_cast <;> ring

theorem valuation_four_div_pow {B : ℤ} (hB : B ≠ 0) (m : ℕ) :
    padicValRat 2 (4 * (B : ℚ) / 2 ^ m) = 2 + (padicValInt 2 B : ℤ) - m := by
  have hv2 : padicValRat 2 2 = 1 := padicValRat.self (by decide : 1 < 2)
  have hv4 : padicValRat 2 4 = 2 := by
    rw [show (4 : ℚ) = 2 ^ 2 by norm_num, padicValRat.pow, hv2]
    norm_num
  rw [padicValRat.div (mul_ne_zero (by norm_num) (by exact_mod_cast hB)) (by positivity),
    padicValRat.mul (by norm_num) (by exact_mod_cast hB), padicValRat.pow, padicValRat.of_int]
  rw [hv4, hv2, mul_one]

theorem capped_exponent {v m : ℕ} (hh : 5 ≤ v → m = 0) :
    (m : ℤ) + min (2 + (v : ℤ) - m) 6 = 2 + min (v : ℤ) 4 := by
  by_cases hv : 5 ≤ v
  · rw [hh hv]
    omega
  · omega

theorem capped_normalizer_square {A : ℚ} {G : ℕ} {B : ℤ} {m : ℕ}
    (hB : B ≠ 0) (hA : A = 2 ^ m * G) (hh : 5 ≤ padicValInt 2 B → m = 0) :
    (A : ℝ) * (2 : ℝ) ^ min (padicValRat 2 (4 * (B : ℚ) / 2 ^ m)) 6 =
      4 * (G : ℝ) * 2 ^ min 4 (padicValInt 2 B) := by
  rw [hA, valuation_four_div_pow hB]
  push_cast
  have he := capped_exponent hh
  calc
    _ = (G : ℝ) * (2 : ℝ) ^ ((m : ℤ) + min (2 + (padicValInt 2 B : ℤ) - m) 6) := by
      rw [zpow_add₀ (by norm_num)]
      simp only [zpow_natCast]
      ring
    _ = _ := by
      rw [he, zpow_add₀ (by norm_num)]
      rw [show min (padicValInt 2 B : ℤ) 4 = ((min 4 (padicValInt 2 B) : ℕ) : ℤ) by omega]
      simp only [zpow_natCast]
      norm_num
      ring

end Approximation
namespace Parameters

def normQuotient (P : Parameters) : ℤ := P.normAlpha / P.baseGcd

theorem baseGcd_dvd_norm (P : Parameters) (hc : Int.gcd P.a P.b = 1) :
    (P.baseGcd : ℤ) ∣ P.normAlpha := by
  rw [P.baseGcd_eq hc]
  exact Int.gcd_dvd_left _ _

theorem normQuotient_mul (P : Parameters) (hc : Int.gcd P.a P.b = 1) :
    (P.baseGcd : ℤ) * P.normQuotient = P.normAlpha := Int.mul_ediv_cancel' (P.baseGcd_dvd_norm hc)

theorem normQuotient_ne_zero (P : Parameters) (hc : Int.gcd P.a P.b = 1) (hn : P.normAlpha ≠ 0) :
    P.normQuotient ≠ 0 := by
  intro he
  have hh := P.normQuotient_mul hc
  rw [he, mul_zero] at hh
  exact hn hh.symm


/-- The exact equality in Lemma 3.12, using the restored printed Lemma 3.11
and high-valuation argument, in the equivalent square-root form. -/
theorem lemma312_eq (P : Parameters) (h : P.Admissible) (hc : Int.gcd P.a P.b = 1)
    (hn : P.normAlpha < 0) {k X Y ν : ℤ}
    (hx : P.x h.pell k = (X : ℚ)) (hy : P.y h.pell k = (Y : ℚ)) (hν : ν = 1 ∨ ν = -1) :
    Approximation.normalizerProduct (squarefreePart P.normAlpha) (2 * X)
      (2 * ν * squareFactor P.normAlpha) =
        Real.sqrt (4 * (P.baseGcd : ℝ) * 2 ^ min 4 (padicValInt 2 P.normQuotient)) := by
  obtain ⟨m, hm⟩ := P.lemma311_published h hc hn hx hy hν
  have hG : (0 : ℚ) < P.baseGcd := by exact_mod_cast P.baseGcd_pos (ne_of_gt h.a_pos)
  have hB := P.normQuotient_ne_zero hc (ne_of_lt hn)
  have hd : Approximation.dPrime (squarefreePart P.normAlpha) (2 * X) (2 * ν * squareFactor P.normAlpha) =
      4 * (P.normQuotient : ℚ) / 2 ^ m := by
    rw [Approximation.dPrime_unit _ _ _ _ hν, squareFactor_sq_mul, hm]
    have he : (P.normAlpha : ℚ) = P.baseGcd * (P.normQuotient : ℚ) := by
      exact_mod_cast (P.normQuotient_mul hc).symm
    rw [he]
    field_simp
  have hh : 5 ≤ padicValInt 2 P.normQuotient → m = 0 := by
    intro hv
    have h32 : (32 : ℤ) ∣ P.normQuotient := by
      simpa using (padicValInt_dvd_iff (p := 2) 5 P.normQuotient).mpr (Or.inr hv)
    have hdN : 32 * (P.baseGcd : ℤ) ∣ P.normAlpha := by
      rw [← P.normQuotient_mul hc, mul_comm 32]
      exact mul_dvd_mul_left _ h32
    have hz := P.normalizer_eq_base_of_high_norm_published h hc hn hdN hx hy hν
    rw [hm] at hz
    have hpow : (2 : ℚ) ^ m = 1 := (mul_eq_right₀ (ne_of_gt hG)).mp hz
    have he := congrArg (padicValRat 2) hpow
    rw [padicValRat.pow] at he
    have hv2 : padicValRat 2 2 = 1 := padicValRat.self (by decide : 1 < 2)
    rw [hv2] at he
    norm_num at he
    exact he
  have hs : Approximation.normalizerProduct (squarefreePart P.normAlpha) (2 * X)
      (2 * ν * squareFactor P.normAlpha) ^ 2 =
        4 * (P.baseGcd : ℝ) * 2 ^ min 4 (padicValInt 2 P.normQuotient) := by
    rw [Approximation.normalizerProduct_sq, hd]
    exact Approximation.capped_normalizer_square hB hm hh
  rw [← hs, Real.sqrt_sq (Approximation.normalizerProduct_nonneg _ _ _)]

end Parameters
end «JNT-2024»
