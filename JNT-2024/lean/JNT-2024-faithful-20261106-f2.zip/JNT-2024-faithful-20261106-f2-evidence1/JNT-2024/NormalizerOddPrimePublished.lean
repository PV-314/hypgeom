module

public import «JNT-2024».ApproximationGcd
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».NormalizerValuationsPublished
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».Sequence
public import «JNT-2024».SequenceGcdPublished
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- The three contradiction branches in the printed odd-prime argument:
p does not divide S; p divides S and ell_2=1; p divides S and ell_2=0. -/
theorem normalizer_odd_prime_minimum_cases (x c s : ℕ) (hs : s ≤ 1) :
    let l₁ := 2 * min x c
    let l₂ := min (x - min x c) s
    l₁ + l₂ ≤ 2 * c + s ∧ l₁ + l₂ ≤ 2 * x ∧
      ¬ (l₁ + l₂ + 1 ≤ 2 * c + s ∧ l₁ + l₂ + 1 ≤ 2 * x) := by
  dsimp
  by_cases hs₀ : s = 0
  · simp only [hs₀, Nat.min_zero, add_zero]
    omega
  have hs₁ : s = 1 := by omega
  rw [hs₁]
  by_cases hl₂ : min (x - min x c) 1 = 1
  · rw [hl₂]
    omega
  · have hl₂₀ : min (x - min x c) 1 = 0 := by omega
    rw [hl₂₀]
    omega

/-- The norm identity and absence of a common prime factor transfer a prime
power dividing N and X² to d, exactly as in Lemma 3.11(1). -/
theorem norm_prime_power_dvd_d (p : ℕ) [hp : Fact p.Prime] {d N X Y : ℤ} (e : ℕ)
    (he : X ^ 2 - d * Y ^ 2 = N) (hg : ¬ p ∣ Int.gcd X Y)
    (hN : (p : ℤ) ^ e ∣ N) (hX : (p : ℤ) ^ e ∣ X ^ 2) : (p : ℤ) ^ e ∣ d := by
  by_cases hz : e = 0
  · simp [hz]
  have hpI : Prime (p : ℤ) := Nat.prime_iff_prime_int.mp hp.out
  have hpx : (p : ℤ) ∣ X := hpI.dvd_of_dvd_pow
    ((dvd_pow_self (p : ℤ) (by omega : e ≠ 0)).trans hX)
  have hpy : ¬ (p : ℤ) ∣ Y := fun hy => hg (Int.dvd_gcd hpx hy)
  have hD : (p : ℤ) ^ e ∣ d * Y ^ 2 := by
    have hh := dvd_sub hX hN
    convert hh using 1
    linarith only [he]
  have hc : IsCoprime ((p : ℤ) ^ e) (Y ^ 2) :=
    (hpI.coprime_iff_not_dvd.mpr hpy).pow_left.pow_right
  exact hc.dvd_of_dvd_mul_right hD

namespace Approximation

/-- All the actual normalizer data satisfy the printed odd-prime lower
divisibilities and upper contradiction, including X=0. -/
theorem odd_prime_normalizer_divisibility (p : ℕ) [Fact p.Prime] (hp : p ≠ 2)
    {S X C ν : ℤ} (hS : Squarefree S) (hC : C ≠ 0) (hν : ν = 1 ∨ ν = -1) :
    let e := padicValNat p (g1 (2 * X) (2 * ν * C) ^ 2) +
      padicValNat p (g2 S (2 * X) (2 * ν * C))
    (p : ℤ) ^ e ∣ C ^ 2 * S ∧ (p : ℤ) ^ e ∣ X ^ 2 ∧
      ¬ ((p : ℤ) ^ (e + 1) ∣ C ^ 2 * S ∧ (p : ℤ) ^ (e + 1) ∣ X ^ 2) := by
  have hS₀ : S ≠ 0 := hS.ne_zero
  have hN₀ : C ^ 2 * S ≠ 0 := mul_ne_zero (pow_ne_zero _ hC) hS₀
  have hvN : padicValInt p (C ^ 2 * S) = 2 * padicValInt p C + padicValInt p S := by
    rw [padicValInt.mul (pow_ne_zero _ hC) hS₀, valuation_int_pow]
  have hp₂ : padicValNat p 2 = 0 := padicValNat_primes hp
  by_cases hX : X = 0
  · subst X
    have hz := normalizer_zero_coordinate S C ν hν
    simp only [mul_zero] at hz
    dsimp
    rw [hz.1, hz.2, padicValNat.pow,
      padicValNat.mul (by decide) (Int.natAbs_ne_zero.mpr hC), hp₂, zero_add]
    change (p : ℤ) ^ (2 * padicValInt p C + padicValInt p S) ∣ C ^ 2 * S ∧ _
    rw [← hvN]
    refine ⟨(padicValInt_dvd_iff _ _).mpr (Or.inr le_rfl), by simp, ?_⟩
    intro hh
    have hv := (padicValInt_dvd_iff _ _).mp hh.1
    rcases hv with hv | hv
    · exact hN₀ hv
    · simp only [padicValInt] at hvN hv
      omega
  · have hv₁ := g1_square_valuation_published p hX hC hν
    have hv₂ := g2_valuation_published p hS₀ hX hC hν
    rw [hp₂, zero_add] at hv₁
    have hh := normalizer_odd_prime_minimum_cases (padicValInt p X) (padicValInt p C)
      (padicValInt p S) (valuation_squarefree_le_one p hS)
    dsimp at hh ⊢
    rw [hv₁, hv₂]
    refine ⟨(padicValInt_dvd_iff _ _).mpr (Or.inr (by simpa only [hvN] using hh.1)),
      (padicValInt_dvd_iff _ _).mpr (Or.inr (by simpa only [valuation_int_pow] using hh.2.1)), ?_⟩
    intro hd
    have hdn := ((padicValInt_dvd_iff _ _).mp hd.1).resolve_left hN₀
    have hdx := ((padicValInt_dvd_iff _ _).mp hd.2).resolve_left (pow_ne_zero _ hX)
    rw [hvN] at hdn
    rw [valuation_int_pow] at hdx
    exact hh.2.2 ⟨hdn,hdx⟩

end Approximation

namespace Parameters

theorem sequence_odd_prime_not_dvd_gcd (P : Parameters) (h : P.Admissible)
    (hc : Int.gcd P.a P.b = 1) (p : ℕ) (hp : p.Prime) (hp₂ : p ≠ 2)
    {k X Y : ℤ} (hx : P.x h.pell k = X) (hy : P.y h.pell k = Y) :
    ¬ p ∣ Int.gcd X Y := by
  rcases P.sequence_integral_gcd_published h hc hx hy with hg | hg
  · rw [hg]; exact hp.not_dvd_one
  · rw [hg]; intro hd; exact hp₂ ((Nat.prime_dvd_prime_iff_eq hp Nat.prime_two).mp hd)

/-- The paper's replacement of gcd(a²,db⁴) by gcd(a²,d). -/
theorem baseGcd_eq_ad_published (P : Parameters) (hc : Int.gcd P.a P.b = 1) :
    P.baseGcd = Int.gcd (P.a ^ 2) P.d := by
  have hh : Int.gcd (P.a ^ 2) (P.b ^ 4) = 1 :=
    Int.isCoprime_iff_gcd_eq_one.mp ((Int.isCoprime_iff_gcd_eq_one.mpr hc).pow_left.pow_right)
  exact Int.gcd_mul_left_right_of_gcd_eq_one hh

/-- Lemma 3.11(1): the printed divisibility chain and all three upper
contradiction branches give the exact odd-prime valuation of the base gcd. -/
theorem normalizer_base_valuation_odd_published (P : Parameters) (h : P.Admissible)
    (hc : Int.gcd P.a P.b = 1) (hn : P.normAlpha < 0) (p : ℕ) [hp : Fact p.Prime]
    (hp₂ : p ≠ 2) {k X Y ν : ℤ} (hx : P.x h.pell k = X) (hy : P.y h.pell k = Y)
    (hν : ν = 1 ∨ ν = -1) :
    padicValNat p P.baseGcd =
      padicValNat p (Approximation.g1 (2 * X) (2 * ν * squareFactor P.normAlpha) ^ 2) +
      padicValNat p (Approximation.g2 (squarefreePart P.normAlpha) (2 * X)
        (2 * ν * squareFactor P.normAlpha)) := by
  let e := padicValNat p (Approximation.g1 (2 * X) (2 * ν * squareFactor P.normAlpha) ^ 2) +
    padicValNat p (Approximation.g2 (squarefreePart P.normAlpha) (2 * X)
      (2 * ν * squareFactor P.normAlpha))
  have hd := Approximation.odd_prime_normalizer_divisibility p hp₂
    (S := squarefreePart P.normAlpha) (X := X) (C := squareFactor P.normAlpha)
    (squarefreePart_squarefree _) (ne_of_gt (squareFactor_pos (ne_of_lt hn))) hν
  change (p : ℤ) ^ e ∣ _ ∧ (p : ℤ) ^ e ∣ X ^ 2 ∧ ¬ (_ ∧ _) at hd
  rw [squareFactor_sq_mul] at hd
  have he : X ^ 2 - P.d * Y ^ 2 = P.normAlpha := by
    have hh := P.norm_identity h.pell k
    rw [hx, hy] at hh
    exact_mod_cast hh
  have hg := P.sequence_odd_prime_not_dvd_gcd h hc p hp.out hp₂ hx hy
  have hD := norm_prime_power_dvd_d p e he hg hd.1 hd.2.1
  have ha : (p : ℤ) ^ e ∣ P.a ^ 2 := by
    have hh := dvd_add hd.1 (dvd_mul_of_dvd_right hD (P.b ^ 4))
    convert hh using 1
    unfold normAlpha
    ring
  have hb : p ^ e ∣ P.baseGcd := by
    rw [P.baseGcd_eq_ad_published hc]
    have hh := Int.dvd_gcd ha hD
    simpa only [Int.natAbs_pow, Int.natAbs_natCast] using hh
  have hb₀ := ne_of_gt (P.baseGcd_pos (ne_of_gt h.a_pos))
  apply le_antisymm
  · by_contra hh
    have hb' : p ^ (e + 1) ∣ P.baseGcd := (padicValNat_dvd_iff_le hb₀).mpr (by omega)
    rw [P.baseGcd_eq_ad_published hc] at hb'
    have hg' : (p : ℤ) ^ (e + 1) ∣ (Int.gcd (P.a ^ 2) P.d : ℤ) := by exact_mod_cast hb'
    have ha' := hg'.trans (Int.gcd_dvd_left (P.a ^ 2) P.d)
    have hd' := hg'.trans (Int.gcd_dvd_right (P.a ^ 2) P.d)
    have hn' : (p : ℤ) ^ (e + 1) ∣ P.normAlpha :=
      dvd_sub ha' (dvd_mul_of_dvd_right hd' (P.b ^ 4))
    have hx' : (p : ℤ) ^ (e + 1) ∣ X ^ 2 := by
      have hh := dvd_add hn' (dvd_mul_of_dvd_left hd' (Y ^ 2))
      convert hh using 1
      linarith only [he]
    exact hd.2.2 ⟨hn',hx'⟩
  · exact (padicValNat_dvd_iff_le hb₀).mp hb

theorem normalizer_valuation_odd_published (P : Parameters) (h : P.Admissible)
    (hc : Int.gcd P.a P.b = 1) (hn : P.normAlpha < 0) (p : ℕ) [Fact p.Prime]
    (hp₂ : p ≠ 2) {k X Y ν : ℤ} (hx : P.x h.pell k = X) (hy : P.y h.pell k = Y)
    (hν : ν = 1 ∨ ν = -1) :
    padicValRat p (Approximation.gSquared (squarefreePart P.normAlpha) (2 * X)
      (2 * ν * squareFactor P.normAlpha)) = padicValNat p P.baseGcd := by
  have hC := ne_of_gt (squareFactor_pos (ne_of_lt hn))
  have hu : 2 * ν * squareFactor P.normAlpha ≠ 0 := by
    rcases hν with rfl | rfl <;> simpa using hC
  rw [Approximation.gSquared_valuation_published p (squarefreePart_ne_zero _) hu,
    Approximation.g3_valuation_odd_published p hp₂, Nat.cast_zero, sub_zero,
    P.normalizer_base_valuation_odd_published h hc hn p hp₂ hx hy hν]
  push_cast
  rfl

end Parameters
end «JNT-2024»
