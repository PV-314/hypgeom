module

public import «JNT-2024».Lemma55Revised
public import «JNT-2024».Lemma56GcdRevised
public import «JNT-2024».Lemma56MinusRevised
public import «JNT-2024».Lemma56PlusRevised
public import «JNT-2024».Monotonicity
public import «JNT-2024».NormalizerBounds
public import «JNT-2024».Proposition41
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.Deriv.MeanValue
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Pow.Real
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.LegendreSymbol.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section
namespace «JNT-2024».Parameters

/-- Lemma 5.6 of 2026-11-06d, through its new bound-18, congruence,
prime-divisor and final parity arguments. The former classification is not used. -/
theorem lemma56_revised (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hn : P.normAlpha<0) (hNs : IsSquare (-P.normAlpha)) (heven : Even (-P.normAlpha))
    (_hK : P.IsNegativeCutoff h.pell (-1))
    {k : ℤ} (hk : k=1 ∨ k= -1) (hs : IsIntegerSquare (P.y h.pell k))
    (hy : 1<P.y h.pell k) (hcut : (P.y h.pell k:ℝ) ≤ P.proposition41Threshold) :
    (P.u=1 ∧ P.t^2-P.d*P.u^2= -4 ∧ P.normAlpha%16=12 ∧
      (Int.gcd (P.a^2) P.d=1 ∨ Int.gcd (P.a^2) P.d=4)) ∨
    (P.u=1 ∧ P.t^2-P.d*P.u^2= -4 ∧ 64 ∣ P.normAlpha ∧ Int.gcd (P.a^2) P.d=4) ∨
    (P.u=2 ∧ P.t^2-P.d*P.u^2= -4 ∧ 16 ∣ P.normAlpha ∧ Int.gcd (P.a^2) P.d=1) := by
  have hadj : P.AdjacentSquare h.pell := by
    rcases hk with rfl | rfl
    · exact Or.inl hs
    · exact Or.inr hs
  have hbound := P.small_normalizer_square_revised h hb hn hNs hk hs hy hcut
  obtain ⟨hu4,hM⟩ := P.lemma56_unit_bound_revised h hb hn hNs heven hk hs hy hcut
  have hminus := h.pell.resolve_left (P.lemma56_plus_excluded_revised h hb hNs heven hadj hu4 hbound)
  have hu := P.lemma56_minus_units_revised h.u_pos hu4 hminus
  obtain ⟨n,hnval⟩ := hNs
  have hn2 : -P.normAlpha=n^2 := by simpa [pow_two] using hnval
  have hne : Even n := by have hh : Even (n^2) := hn2 ▸ heven; simpa [Int.even_pow] using hh
  have hprime := P.lemma56_no_odd_prime_revised h hb ⟨n,hnval⟩ heven hn2 hminus hM
  have hg := P.lemma56_root_gcd_revised h hb ⟨n,hnval⟩ hn2 hM hprime
  rcases hu with hu1 | hu2
  · rcases P.lemma56_minus_one_revised h hb hn2 hne hu1 hminus hadj hg with ⟨hmod,hgcd⟩ | ⟨hdiv,hgcd⟩
    · exact Or.inl ⟨hu1,hminus,hmod,hgcd⟩
    · exact Or.inr (Or.inl ⟨hu1,hminus,hdiv,hgcd⟩)
  · obtain ⟨hdiv,hgcd⟩ := P.lemma56_minus_two_revised h hb hn2 hne hu2 hminus hadj hg
    exact Or.inr (Or.inr ⟨hu2,hminus,hdiv,hgcd⟩)

end «JNT-2024».Parameters
