module

public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- Integer-valuedness of a two-sided recurrence from two consecutive values. -/
theorem recurrence_integer_values (f : ℤ → ℚ) (c : ℤ)
    (hrec : ∀ k, f (k + 1) = c * f k - f (k - 1))
    (hzero : ∃ n : ℤ, f 0 = n) (hone : ∃ n : ℤ, f 1 = n) :
    ∀ k, ∃ n : ℤ, f k = n := by
  suffices hp : ∀ k, (∃ n : ℤ, f k = n) ∧ (∃ n : ℤ, f (k + 1) = n) from
    fun k => (hp k).1
  intro k
  induction k using Int.induction_on with
  | zero => exact ⟨hzero, by simpa using hone⟩
  | succ k ih =>
    obtain ⟨⟨n, hn⟩, ⟨m, hm⟩⟩ := ih
    refine ⟨⟨m, hm⟩, c * m - n, ?_⟩
    rw [hrec]
    simp [hm, hn]
  | pred k ih =>
    obtain ⟨⟨n, hn⟩, ⟨m, hm⟩⟩ := ih
    refine ⟨⟨c * n - m, ?_⟩, ?_⟩
    · have hr := hrec (-(k : ℤ))
      rw [hn, hm] at hr
      push_cast
      linarith
    · simpa using (show ∃ n : ℤ, f (-(k : ℤ)) = n from ⟨n, hn⟩)

/-- A rational square whose double is integral has an integer square root. -/
theorem integer_root_of_two_mul_sq (q : ℚ) (h : ∃ n : ℤ, 2 * q ^ 2 = n) :
    ∃ n : ℤ, q = n := by
  obtain ⟨n, hn⟩ := h
  have heq : q ^ 2 = Rat.divInt n 2 := by rw [Rat.divInt_eq_div]; norm_num; linarith
  have hd : (q.den ^ 2 : ℕ) ∣ 2 := by
    have hh := Rat.den_dvd n 2
    rw [← heq, Rat.den_pow] at hh
    exact_mod_cast hh
  have hle : q.den ^ 2 ≤ 2 := Nat.le_of_dvd (by decide) hd
  have hpos := q.den_pos
  have hone : q.den = 1 := by nlinarith
  exact ⟨q.num, (Rat.coe_int_num_of_den_eq_one hone).symm⟩

namespace Parameters

/-- The recurrence coefficient is an integer; no positivity is needed. -/
theorem integral_trace (P : Parameters) (h : P.Pell) :
    ∃ c : ℤ, ((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) / 2 = c := by
  rcases h with h | h
  · refine ⟨P.t ^ 2 - 2, ?_⟩
    have hq : (P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2 = 4 := by exact_mod_cast h
    push_cast
    linarith
  · refine ⟨P.t ^ 2 + 2, ?_⟩
    have hq : (P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2 = -4 := by exact_mod_cast h
    push_cast
    linarith

/-- The integrality assertion of Lemma 3.5(b), for every integer index. -/
theorem two_y_integral (P : Parameters) (h : P.Pell) (k : ℤ) :
    ∃ n : ℤ, 2 * P.y h k = n := by
  obtain ⟨c, hc⟩ := P.integral_trace h
  apply recurrence_integer_values (fun k => 2 * P.y h k) c ?_ ?_ ?_ k
  · intro j
    rw [P.y_recurrence, hc]
    ring
  · exact ⟨2 * P.b ^ 2, by simp⟩
  · refine ⟨P.b ^ 2 * c + P.a * P.t * P.u, ?_⟩
    rw [P.y_one]
    push_cast
    calc
      _ = (P.b : ℚ) ^ 2 * (((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) / 2) +
          P.a * P.t * P.u := by ring
      _ = _ := by rw [hc]

/-- The remark on p. 3: rational-square terms are integer squares. -/
theorem rational_square_iff_integer_square (P : Parameters) (h : P.Pell) (k : ℤ) :
    IsSquare (P.y h k) ↔ IsIntegerSquare (P.y h k) := by
  constructor
  · rintro ⟨q, hq⟩
    have hs : P.y h k = q ^ 2 := by simpa [pow_two] using hq
    obtain ⟨n, hn⟩ := integer_root_of_two_mul_sq q (by simpa [hs] using P.two_y_integral h k)
    exact ⟨n, by rw [hs, hn]⟩
  · rintro ⟨n, hn⟩
    exact ⟨(n : ℚ), by simpa [pow_two] using hn⟩

end Parameters
end «JNT-2024»
