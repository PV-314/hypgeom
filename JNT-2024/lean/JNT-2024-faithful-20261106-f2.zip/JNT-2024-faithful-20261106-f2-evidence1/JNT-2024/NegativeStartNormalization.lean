module

public import «JNT-2024».Integrality
public import «JNT-2024».PaperBridge
public import «JNT-2024».RealBounds
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section
namespace «JNT-2024».Parameters

/-- Replacing alpha by minus its algebraic conjugate changes only a to -a. -/
def reverseStart (P : Parameters) : Parameters := { P with a := -P.a }

theorem reverseStart_pell (P : Parameters) (hp : P.Pell) : P.reverseStart.Pell := hp

theorem reverseStart_alpha (P : Parameters) :
    P.reverseStart.alpha = -star P.alpha := by
  ext <;> simp [reverseStart,alpha]

theorem reverseStart_norm (P : Parameters) : P.reverseStart.normAlpha = P.normAlpha := by
  simp [reverseStart,normAlpha]

/-- Exact reversal for all integer indices and either unit norm, without a sign
or size assumption on a,b. This proves the printed minus-conjugation operation. -/
theorem reverseStart_term (P : Parameters) (hp : P.Pell) (k : ℤ) :
    P.reverseStart.term (P.reverseStart_pell hp) k = -star (P.term hp (-k)) := by
  have hs : star P.step = P.backStep := by ext <;> simp [step,backStep]
  have hb : star P.backStep = P.step := by ext <;> simp [step,backStep]
  induction k using Int.induction_on with
  | zero => simpa using P.reverseStart_alpha
  | succ k ih =>
    rw [term_add_one,ih,show -((k:ℤ)+1)= -(k:ℤ)-1 by omega,term_sub_one]
    change -star (P.term hp (-k)) * P.step = -star (P.term hp (-k) * P.backStep)
    simp [star_mul,hb,mul_comm]
  | pred k ih =>
    rw [term_sub_one,ih,show -(-(k:ℤ)-1)= (k:ℤ)+1 by omega,term_add_one]
    rw [neg_neg]
    change -star (P.term hp k) * P.backStep = -star (P.term hp k * P.step)
    simp [star_mul,hs,mul_comm]

theorem reverseStart_coordinates (P : Parameters) (hp : P.Pell) (k : ℤ) :
    P.reverseStart.x (P.reverseStart_pell hp) k = -P.x hp (-k) ∧
    P.reverseStart.y (P.reverseStart_pell hp) k = P.y hp (-k) := by
  constructor
  · simpa [x] using congrArg QuadraticAlgebra.re (P.reverseStart_term hp k)
  · simpa [y] using congrArg QuadraticAlgebra.im (P.reverseStart_term hp k)

/-- The full set of y values, not merely its square subset, is unchanged. -/
theorem reverseStart_values (P : Parameters) (hp : P.Pell) :
    Set.range (P.reverseStart.y (P.reverseStart_pell hp)) = Set.range (P.y hp) := by
  ext q
  constructor
  · rintro ⟨k,rfl⟩
    exact ⟨-k,(P.reverseStart_coordinates hp k).2.symm⟩
  · rintro ⟨k,rfl⟩
    exact ⟨-k,by simpa using (P.reverseStart_coordinates hp (-k)).2⟩

/-- If the current starting square is least, the reversal keeps it least.
This applies to arbitrary b, not only the b=1 main-theorem setting. -/
theorem reverseStart_least_square (P : Parameters) (hp : P.Pell) :
    (∀ k : ℤ, IsIntegerSquare (P.y hp k) → (P.b:ℚ)^2 ≤ P.y hp k) ↔
    (∀ k : ℤ, IsIntegerSquare (P.reverseStart.y (P.reverseStart_pell hp) k) →
      (P.reverseStart.b:ℚ)^2 ≤ P.reverseStart.y (P.reverseStart_pell hp) k) := by
  have hb : P.reverseStart.b = P.b := rfl
  constructor
  · intro h k
    simpa only [(P.reverseStart_coordinates hp k).2,hb] using h (-k)
  · intro h k
    have hh := h (-k)
    simpa only [(P.reverseStart_coordinates hp (-k)).2,neg_neg,hb] using hh

/-- Literal ring-of-integers and arbitrary-sequence version of the 06d claim.
The original a is negative; all other standing arithmetic hypotheses are kept. -/
theorem negative_start_paper_normalization (P : Parameters) [Fact (¬IsSquare P.d)]
    (ha : P.a < 0) (hb : 0 < P.b) (hd : 0 < P.d) (ht : 0 < P.t) (hu : 0 < P.u)
    (hunit : P.IsRealIntegerUnit) (X Y : ℤ → ℚ) (hseq : P.PaperSequence X Y) :
    P.reverseStart.PaperAdmissible ∧
    P.reverseStart.PaperSequence (fun k => -X (-k)) (fun k => Y (-k)) ∧
    P.reverseStart.normAlpha = P.normAlpha := by
  have hp : P.Pell := (P.pell_iff_realIntegerUnit hd).mpr hunit
  let : Fact (¬IsSquare P.reverseStart.d) := ⟨show ¬IsSquare P.d from Fact.out⟩
  have hadm : P.reverseStart.PaperAdmissible :=
    ⟨neg_pos.mpr ha,hb,hd,ht,hu,Fact.out,hunit⟩
  refine ⟨hadm,?_,P.reverseStart_norm⟩
  intro k
  have hx := (P.coordinates_unique hd hp (-k) (X (-k)) (Y (-k)) (hseq (-k))).1
  have hy := (P.coordinates_unique hd hp (-k) (X (-k)) (Y (-k)) (hseq (-k))).2
  have hh := P.reverseStart.coordinates_real_formula hd (P.reverseStart_pell hp) k
  rw [(P.reverseStart_coordinates hp k).1,(P.reverseStart_coordinates hp k).2] at hh
  simpa only [hx,hy,Rat.cast_neg] using hh

end «JNT-2024».Parameters
