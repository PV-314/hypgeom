module

public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Approximation

def Cutoff (E Q ℓ c : ℝ) (q : ℂ) (r : ℕ) : Prop :=
  (Q - 1 / E) * ℓ * ‖q‖ / (Q - 1) < c * E ^ r

theorem exists_positive_cutoff {E Q ℓ c : ℝ} (hE : 1 < E) (hc : 0 < c) (q : ℂ) :
    ∃ r : ℕ, 0 < r ∧ Cutoff E Q ℓ c q r := by
  obtain ⟨n, hn⟩ := pow_unbounded_of_one_lt (((Q - 1 / E) * ℓ * ‖q‖ / (Q - 1)) / c) hE
  refine ⟨n + 1, by omega, ?_⟩
  unfold Cutoff
  have hp : E ^ n < E ^ (n + 1) := by
    rw [pow_succ]
    nlinarith only [pow_pos (by linarith : 0 < E) n, hE]
  exact (div_lt_iff₀ hc).mp (lt_trans hn hp) |>.trans_eq (mul_comm _ _)

noncomputable def firstIndex {E Q ℓ c : ℝ} (hE : 1 < E) (hc : 0 < c) (q : ℂ) : ℕ :=
  @Nat.find (fun n => 0 < n ∧ Cutoff E Q ℓ c q n) (Classical.decPred _)
    (exists_positive_cutoff (Q := Q) (ℓ := ℓ) hE hc q)

theorem firstIndex_spec {E Q ℓ c : ℝ} (hE : 1 < E) (hc : 0 < c) (q : ℂ) :
    0 < firstIndex (Q := Q) (ℓ := ℓ) hE hc q ∧
      Cutoff E Q ℓ c q (firstIndex (Q := Q) (ℓ := ℓ) hE hc q) := by
  classical
  exact @Nat.find_spec _ (Classical.decPred _) (exists_positive_cutoff (Q := Q) (ℓ := ℓ) hE hc q)

theorem firstIndex_le {E Q ℓ c : ℝ} (hE : 1 < E) (hc : 0 < c) (q : ℂ) {r : ℕ}
    (hr : 0 < r) (hcut : Cutoff E Q ℓ c q r) : firstIndex (Q := Q) (ℓ := ℓ) hE hc q ≤ r := by
  classical
  exact @Nat.find_min' _ (Classical.decPred _) (exists_positive_cutoff hE hc q) r ⟨hr, hcut⟩

theorem cutoff_error_bound {E Q ℓ c : ℝ} {q : ℂ} {r : ℕ}
    (hE : 1 < E) (hQ : 1 < Q) (hcut : Cutoff E Q ℓ c q r) :
    ℓ / E ^ r * ‖q‖ < c * ((Q - 1) / (Q - 1 / E)) := by
  have hE0 : 0 < E := by linarith
  have hden : 0 < Q - 1 / E := by
    have hh : 1 / E < 1 := (div_lt_one hE0).mpr hE
    linarith
  unfold Cutoff at hcut
  have hh := (div_lt_iff₀ (by linarith : 0 < Q - 1)).mp hcut
  have he : ℓ * ‖q‖ / E ^ r < c * (Q - 1) / (Q - 1 / E) := by
    apply (div_lt_div_iff₀ (pow_pos hE0 r) hden).mpr
    nlinarith only [hh]
  convert he using 1 <;> ring

theorem cutoff_ratio_bounds {E Q : ℝ} (hE : 1 < E) (hQ : 1 < Q) :
    0 < (Q - 1) / (Q - 1 / E) ∧ (Q - 1) / (Q - 1 / E) < 1 := by
  have hE0 : 0 < E := by linarith
  have hi : 1 / E < 1 := (div_lt_one hE0).mpr hE
  have hp : 0 < Q - 1 / E := by linarith
  exact ⟨div_pos (by linarith) hp, (div_lt_one hp).mpr (by linarith)⟩

theorem cutoff_constant_comparison {E Q c : ℝ} (hE : 1 < E) (hQ : 1 < Q)
    (hc : 0 < c) (hc1 : c < 1) :
    1 - c / E < Q * (1 - c * ((Q - 1) / (Q - 1 / E))) := by
  have hE0 : 0 < E := by linarith
  have hd : 0 < E * Q - 1 := by nlinarith
  have hd0 : E * Q - 1 ≠ 0 := ne_of_gt hd
  have hd0' : -1 + Q * E ≠ 0 := by nlinarith
  have hden : Q - 1 / E ≠ 0 := by
    have hi : 1 / E < 1 := (div_lt_one hE0).mpr hE
    linarith
  have hpos : 0 < (1 - c) * (Q - 1) * E * (E * Q - 1) + c * (E - 1) := by positivity
  have he : (Q * (1 - c * ((Q - 1) / (Q - 1 / E))) - (1 - c / E)) * (E * (E * Q - 1)) =
      (1 - c) * (Q - 1) * E * (E * Q - 1) + c * (E - 1) := by
    field_simp [ne_of_gt hE0, hd0, hd0', hden]
    ring_nf
    field_simp [hd0']; ring
  have hm : 0 < E * (E * Q - 1) := mul_pos hE0 hd
  nlinarith only [he, hpos, hm]

/-- The strict determinant-to-error estimate. -/
theorem determinant_error_bound {θ p q pr qr : ℂ} {K L : ℝ}
    (hdet : 1 ≤ ‖pr * q - qr * p‖) (hq : ‖qr‖ < K) (herr : ‖qr * θ - pr‖ ≤ L)
    (hbudget : L * ‖q‖ < 1) :
    1 - L * ‖q‖ < K * ‖q * θ - p‖ := by
  have htri := norm_add_le (qr * (q * θ - p)) (-(q * (qr * θ - pr)))
  have he : qr * (q * θ - p) + -(q * (qr * θ - pr)) = pr * q - qr * p := by ring
  rw [he, norm_mul, norm_neg, norm_mul] at htri
  have hl := mul_le_mul_of_nonneg_left herr (norm_nonneg q)
  have hrespos : 0 < ‖q * θ - p‖ := by
    by_contra hh
    have hz : ‖q * θ - p‖ = 0 := le_antisymm (le_of_not_gt hh) (norm_nonneg _)
    rw [hz, mul_zero, zero_add] at htri
    nlinarith only [htri, hdet, hl, hbudget]
  have hm := mul_lt_mul_of_pos_right hq hrespos
  nlinarith only [htri, hdet, hm, hl]


end Approximation
end «JNT-2024»
