module

public import «JNT-2024».ComplexRepresentation
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.NumberTheory.Pell
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section
namespace «JNT-2024»

/-- The manuscript's nonsquare condition implies the condition needed by Pell's theorem. -/
theorem lemma38b_core_not_square {N : ℤ} (hN : ¬ IsSquare (-N)) :
    ¬ IsSquare (-squarefreePart N) := by
  rintro ⟨z, hz⟩
  apply hN
  refine ⟨squareFactor N * z, ?_⟩
  have hf := squareFactor_sq_mul N
  have hs : squarefreePart N = -(z*z) := by linarith
  rw [hs] at hf
  nlinarith only [hf]

/-- The displayed identity and strict bounds in the revised opening of 3.8(b).
The coordinates are arbitrary positive integer Pell solutions, not asserted
to come from sequence representations. -/
theorem lemma38b_pell_bounds {N x y : ℤ} (hN : N < 0)
    (hx : 0 < x) (hy : 0 < y) (hp : x^2 + squarefreePart N * y^2 = 1) :
    0 < (x:ℝ) - y * Real.sqrt (-(squarefreePart N:ℝ)) ∧
    (x:ℝ) - y * Real.sqrt (-(squarefreePart N:ℝ)) =
      1 / ((x:ℝ) + y * Real.sqrt (-(squarefreePart N:ℝ))) ∧
    (x:ℝ) - y * Real.sqrt (-(squarefreePart N:ℝ)) <
      1 / (2 * y * Real.sqrt (-(squarefreePart N:ℝ))) := by
  have hs : 0 < -(squarefreePart N:ℝ) := by exact_mod_cast neg_pos.mpr (squarefreePart_neg hN)
  have hr := Real.sqrt_pos.mpr hs
  have hr2 := Real.sq_sqrt hs.le
  have hxR : (0:ℝ) < x := by exact_mod_cast hx
  have hyR : (0:ℝ) < y := by exact_mod_cast hy
  have hpR : (x:ℝ)^2 + (squarefreePart N:ℝ)*(y:ℝ)^2 = 1 := by exact_mod_cast hp
  have hnorm : (x:ℝ)^2 - (y * Real.sqrt (-(squarefreePart N:ℝ)))^2 = 1 := by
    rw [mul_pow, hr2]; nlinarith only [hpR]
  have hprod : (x:ℝ) - y * Real.sqrt (-(squarefreePart N:ℝ)) > 0 := by
    nlinarith [mul_pos hyR hr]
  have hden : 0 < (x:ℝ) + y * Real.sqrt (-(squarefreePart N:ℝ)) := by positivity
  have he : (x:ℝ) - y * Real.sqrt (-(squarefreePart N:ℝ)) =
      1 / ((x:ℝ) + y * Real.sqrt (-(squarefreePart N:ℝ))) := by
    apply (eq_div_iff (ne_of_gt hden)).mpr
    nlinarith only [hnorm]
  refine ⟨hprod, he, ?_⟩
  rw [he]
  apply one_div_lt_one_div_of_lt (by positivity)
  linarith only [hprod]

/-- Powers of a positive Pell solution have unbounded integer y coordinates. -/
theorem lemma38b_pell_power_growth {N : ℤ} (a : Pell.Solution₁ (-squarefreePart N))
    (hx : 1 < a.x) (hy : 0 < a.y) (n : ℕ) : (n:ℤ) ≤ (a^n).y := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [pow_succ, Pell.Solution₁.y_mul]
    have hxp := Pell.Solution₁.x_pow_pos (by omega : 0 < a.x) n
    have hyp : 0 ≤ (a^n).y := le_trans (by positivity) ih
    have hx1 : 1 ≤ (a^n).x := by omega
    have hy1 : 1 ≤ a.y := by omega
    push_cast
    nlinarith

/-- The revised remark: positive Pell solutions make the displayed quantity
arbitrarily small. The hypothesis is exactly nonsquareness of -N, with N<0. -/
theorem lemma38b_pell_arbitrarily_small {N : ℤ} (hN : N < 0)
    (hNs : ¬ IsSquare (-N)) {ε : ℝ} (hε : 0 < ε) :
    ∃ x y : ℤ, 0 < x ∧ 0 < y ∧ x^2 + squarefreePart N*y^2 = 1 ∧
      0 < (x:ℝ) - y * Real.sqrt (-(squarefreePart N:ℝ)) ∧
      (x:ℝ) - y * Real.sqrt (-(squarefreePart N:ℝ)) < ε := by
  have hs : 0 < -squarefreePart N := neg_pos.mpr (squarefreePart_neg hN)
  obtain ⟨a,hax,hay⟩ := Pell.Solution₁.exists_pos_of_not_isSquare hs (lemma38b_core_not_square hNs)
  have hsR : (0:ℝ) < -(squarefreePart N:ℝ) := by exact_mod_cast hs
  have hr := Real.sqrt_pos.mpr hsR
  obtain ⟨n,hn⟩ := exists_nat_gt (1 / (2 * Real.sqrt (-(squarefreePart N:ℝ)) * ε))
  have hn0 : 0 < n := by
    have : (0:ℝ) < n := lt_trans (by positivity) hn
    exact_mod_cast this
  have hy := lemma38b_pell_power_growth a hax hay n
  have hyp : 0 < (a^n).y := lt_of_lt_of_le (by exact_mod_cast hn0) hy
  have hxp := Pell.Solution₁.x_pow_pos (by omega : 0 < a.x) n
  have hp : (a^n).x^2 + squarefreePart N*(a^n).y^2 = 1 := by
    have hh := (a^n).prop
    nlinarith only [hh]
  obtain ⟨hpos,_,hb⟩ := lemma38b_pell_bounds hN hxp hyp hp
  refine ⟨(a^n).x,(a^n).y,hxp,hyp,hp,hpos,hb.trans ?_⟩
  have hyR : (n:ℝ) ≤ (a^n).y := by exact_mod_cast hy
  have hh := (div_lt_iff₀ (by positivity : (0:ℝ)<2*Real.sqrt (-(squarefreePart N:ℝ))*ε)).mp (hn.trans_le hyR)
  apply (div_lt_iff₀ (by positivity : (0:ℝ)<2*((a^n).y:ℝ)*Real.sqrt (-(squarefreePart N:ℝ)))).mpr
  nlinarith only [hh]

/-- Neither sign has a positive lower bound based only on integer coordinates.
Negating x gives the plus sign; no occurrence in the original sequence is claimed. -/
theorem lemma38b_no_uniform_integer_lower_bound {N : ℤ} (hN : N < 0)
    (hNs : ¬ IsSquare (-N)) {ε : ℝ} (hε : 0 < ε) :
    (∃ x y : ℤ, 0 < |(x:ℝ) - y*Real.sqrt (-(squarefreePart N:ℝ))| ∧
      |(x:ℝ) - y*Real.sqrt (-(squarefreePart N:ℝ))| < ε) ∧
    (∃ x y : ℤ, 0 < |(x:ℝ) + y*Real.sqrt (-(squarefreePart N:ℝ))| ∧
      |(x:ℝ) + y*Real.sqrt (-(squarefreePart N:ℝ))| < ε) := by
  obtain ⟨x,y,_,_,_,hp,he⟩ := lemma38b_pell_arbitrarily_small hN hNs hε
  constructor
  · exact ⟨x,y,by rwa [abs_of_pos hp],by rwa [abs_of_pos hp]⟩
  · refine ⟨-x,y,?_,?_⟩ <;>
      simpa only [Int.cast_neg,neg_add_eq_sub,abs_sub_comm,abs_of_pos hp] using (by assumption)

end «JNT-2024»
