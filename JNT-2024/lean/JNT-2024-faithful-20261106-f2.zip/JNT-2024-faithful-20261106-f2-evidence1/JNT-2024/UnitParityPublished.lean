module

public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».RepresentationBothEvenPublished
public import «JNT-2024».Sequence
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

theorem unit_odd_odd_mod_eight (P : Parameters) (hp : P.Pell) (ht : Odd P.t) (hu : Odd P.u) :
    P.d % 8 = 5 := by
  have ht8 := odd_square_mod_eight ht
  have hu8 := odd_square_mod_eight hu
  rcases hp with h | h <;>
    have he := congrArg (fun z : ℤ => z % 8) h <;>
    rw [Int.sub_emod, Int.mul_emod, ht8, hu8] at he <;> omega

theorem unit_even_odd_four_dvd (P : Parameters) (hp : P.Pell) (ht : Even P.t) (hu : Odd P.u) :
    4 ∣ P.d := by
  have ht4 : P.t ^ 2 % 4 = 0 := by
    apply Int.emod_eq_zero_of_dvd
    obtain ⟨m, hm⟩ := ht
    exact ⟨m ^ 2, by rw [hm]; ring⟩
  have hu8 := odd_square_mod_eight hu
  have hu4 : P.u ^ 2 % 4 = 1 := by omega
  apply Int.dvd_of_emod_eq_zero
  rcases hp with h | h <;>
    have he := congrArg (fun z : ℤ => z % 4) h <;>
    rw [Int.sub_emod, Int.mul_emod, ht4, hu4] at he <;> omega

theorem unit_not_odd_even (P : Parameters) (hp : P.Pell) (ht : Odd P.t) (hu : Even P.u) : False := by
  have ht8 := odd_square_mod_eight ht
  have hu4 : P.u ^ 2 % 4 = 0 := by
    apply Int.emod_eq_zero_of_dvd
    obtain ⟨m, hm⟩ := hu
    exact ⟨m ^ 2, by rw [hm]; ring⟩
  have ht4 : P.t ^ 2 % 4 = 1 := by omega
  rcases hp with h | h <;>
    have he := congrArg (fun z : ℤ => z % 4) h <;>
    rw [Int.sub_emod, Int.mul_emod, ht4, hu4] at he <;> omega

/-- The integral coefficients in (3.35), before the parity split. -/
theorem unit_inverse_three_coefficients (P : Parameters) (hp : P.Pell) {ν : ℤ}
    (hν : (ν : ℚ) = P.epsilonNorm) :
    P.u * (3 * (P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) / (4 * P.epsilonNorm ^ 2) =
      (P.u * (P.t ^ 2 - ν) : ℤ) ∧
    P.t * ((P.t : ℚ) ^ 2 + 3 * P.d * (P.u : ℚ) ^ 2) / (4 * P.epsilonNorm ^ 2) =
      (P.t * (ν + P.d * P.u ^ 2) : ℤ) := by
  have hn : P.epsilonNorm ^ 2 = 1 := by
    rcases P.pell_iff_epsilonNorm.mp hp with he | he <;> rw [he] <;> norm_num
  rw [hn]
  push_cast
  rw [hν]
  constructor <;> simp only [epsilonNorm] <;> ring

/-- The integral coefficients in (3.34). -/
theorem unit_inverse_two_coefficients (P : Parameters) (hp : P.Pell) {ν : ℤ}
    (hν : (ν : ℚ) = P.epsilonNorm) :
    P.t * P.u / P.epsilonNorm = (P.t * P.u * ν : ℤ) ∧
    ((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) / (2 * P.epsilonNorm) = (2 + P.d * P.u ^ 2 * ν : ℤ) := by
  have hrel : (P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2 = 4 * P.epsilonNorm := by
    simp only [epsilonNorm]; ring
  push_cast
  rw [hν]
  rcases P.pell_iff_epsilonNorm.mp hp with he | he <;> rw [he] at hrel ⊢ <;>
    constructor <;> norm_num <;> nlinarith only [hrel]

/-- Both coefficients of (3.35) are even in the odd-odd case. -/
theorem unit_inverse_three_coefficients_even (P : Parameters) (hp : P.Pell) {ν : ℤ}
    (hν : (ν : ℚ) = P.epsilonNorm) (ht : Odd P.t) (hu : Odd P.u) :
    Even (P.u * (P.t ^ 2 - ν)) ∧ Even (P.t * (ν + P.d * P.u ^ 2)) := by
  have hd8 := P.unit_odd_odd_mod_eight hp ht hu
  have hd : Odd P.d := Int.odd_iff.mpr (by omega)
  have hνs : ν = 1 ∨ ν = -1 := by
    rcases P.pell_iff_epsilonNorm.mp hp with he | he
    · left; exact_mod_cast hν.trans he
    · right; exact_mod_cast hν.trans he
  have hνo : Odd ν := by rcases hνs with rfl | rfl <;> decide
  exact ⟨((ht.pow).sub_odd hνo).mul_left _, (hνo.add_odd (hd.mul hu.pow)).mul_left _⟩

/-- Both coefficients of (3.34) are even in case (iii). -/
theorem unit_inverse_two_coefficients_even (P : Parameters) (hp : P.Pell) {ν : ℤ}
    (ht : Even P.t) (hu : Odd P.u) :
    Even (P.t * P.u * ν) ∧ Even (2 + P.d * P.u ^ 2 * ν) := by
  have hd : Even P.d := even_iff_two_dvd.mpr ((by norm_num : (2 : ℤ) ∣ 4).trans (P.unit_even_odd_four_dvd hp ht hu))
  exact ⟨(ht.mul_right _).mul_right _, (by decide : Even (2 : ℤ)).add ((hd.mul_right _).mul_right _)⟩

/-- The printed expansion of epsilon squared, with doubled integral coordinates. -/
theorem epsilon_sq_half_coordinates_published (P : Parameters) {ν : ℤ}
    (hν : (ν : ℚ) = P.epsilonNorm) :
    P.epsilon ^ 2 = (⟨((2 * ν + P.d * P.u ^ 2 : ℤ) : ℚ) / 2,
      ((P.t * P.u : ℤ) : ℚ) / 2⟩ : P.Algebra) := by
  have hrel : (P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2 = 4 * ν := by
    rw [hν]; simp only [epsilonNorm]; ring
  ext
  · simp [epsilon, pow_succ]
    linear_combination hrel / 4
  · simp [epsilon, pow_succ]
    ring

/-- The printed expansion of epsilon cubed. -/
theorem epsilon_cube_half_coordinates_published (P : Parameters) {ν : ℤ}
    (hν : (ν : ℚ) = P.epsilonNorm) :
    P.epsilon ^ 3 = (⟨((P.t * (ν + P.d * P.u ^ 2) : ℤ) : ℚ) / 2,
      ((P.u * (P.t ^ 2 - ν) : ℤ) : ℚ) / 2⟩ : P.Algebra) := by
  have hrel : (P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2 = 4 * ν := by
    rw [hν]; simp only [epsilonNorm]; ring
  ext
  · simp [epsilon, pow_succ]
    linear_combination (P.t : ℚ) * hrel / 8
  · simp [epsilon, pow_succ]
    linear_combination -(P.u : ℚ) * hrel / 8

theorem epsilon_sq_coordinates_odd (P : Parameters) (hp : P.Pell) (ν : ℤ)
    (ht : Odd P.t) (hu : Odd P.u) :
    Odd (2 * ν + P.d * P.u ^ 2) ∧ Odd (P.t * P.u) := by
  have hd8 := P.unit_odd_odd_mod_eight hp ht hu
  have hd : Odd P.d := Int.odd_iff.mpr (by omega)
  exact ⟨(even_two_mul ν).add_odd (hd.mul hu.pow), ht.mul hu⟩

end «JNT-2024».Parameters

