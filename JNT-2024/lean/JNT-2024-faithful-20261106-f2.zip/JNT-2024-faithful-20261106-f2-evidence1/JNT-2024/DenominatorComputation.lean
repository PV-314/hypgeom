module

public import «JNT-2024».DenominatorDefinitions
public import «JNT-2024».GammaBounds
public import «JNT-2024».HypergeometricPolynomials
public import «JNT-2024».HypergeometricRecurrence
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

theorem coefficient_quarter_succ (r j : ℕ) :
    coefficient (1 / 4) r (j + 1) = coefficient (1 / 4) r j *
      ((r : ℚ) - j) * (4 * r + 1 - 4 * j) / ((j + 1) * (4 * j + 3)) := by
  have hp : risingQ (1 - (1 / 4 : ℚ)) j ≠ 0 := by
    rw [risingQ_eq_pochhammer]
    exact ne_of_gt (ascPochhammer_pos _ _ (by norm_num))
  have hj : (j : ℚ) + 1 ≠ 0 := by positivity
  have hj' : (4 : ℚ) * j + 3 ≠ 0 := by positivity
  have hf : (j.factorial : ℚ) ≠ 0 := by positivity
  simp only [coefficient, risingQ_succ, Nat.factorial_succ, Nat.cast_mul, Nat.cast_add, Nat.cast_one]
  field_simp
  ring

/-- One pass through the coefficients, retaining the last coefficient and the denominator lcm. -/
def denominatorData (r : ℕ) : ℕ → ℚ × ℕ
  | 0 => (1, 1)
  | j + 1 =>
      let prev := denominatorData r j
      let q := prev.1 * ((r : ℚ) - j) * (4 * r + 1 - 4 * j) / ((j + 1) * (4 * j + 3))
      (q, Nat.lcm prev.2 q.den)

theorem denominatorData_fst (r j : ℕ) : (denominatorData r j).1 = coefficient (1 / 4) r j := by
  induction j with
  | zero => simp [denominatorData, coefficient_zero]
  | succ j ih => simpa only [denominatorData, ih] using (coefficient_quarter_succ r j).symm

theorem denominatorData_snd (r j : ℕ) :
    (denominatorData r j).2 = (Finset.range (j + 1)).lcm (fun k => (coefficient (1 / 4) r k).den) := by
  induction j with
  | zero => simp [denominatorData, coefficient_zero]
  | succ j ih =>
    rw [denominatorData]
    change Nat.lcm (denominatorData r j).2
      ((denominatorData r (j + 1)).1).den = _
    rw [ih, denominatorData_fst, Finset.range_add_one (n := j + 1), Finset.lcm_insert]
    simp only [lcm_eq_nat_lcm]
    exact Nat.lcm_comm _ _

theorem denominator4_eq_data (r : ℕ) : denominator4 r = (denominatorData r r).2 :=
  (denominatorData_snd r r).symm

def FastDenominatorCheck (r : ℕ) : Prop :=
  let D : ℚ := (denominatorData r r).2
  parityLoss r * (gammaRatio r * D) ^ 2 <
      (293 / 250 : ℚ) ^ 2 * denominatorExponentialLower ^ (2 * r) ∧
  parityLoss r * (gammaNumeratorRatio r * D) ^ 2 <
      (537 / 2000 : ℚ) ^ 2 * denominatorExponentialLower ^ (2 * r)

instance (r : ℕ) : Decidable (FastDenominatorCheck r) := by
  unfold FastDenominatorCheck
  infer_instance

theorem fastDenominatorCheck_iff (r : ℕ) : FastDenominatorCheck r ↔ FiniteDenominatorCheck r := by
  simp only [FastDenominatorCheck, FiniteDenominatorCheck, denominator4_eq_data]

end Hypergeometric
end «JNT-2024»
