module

public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- The gcd appearing in the sharp bounds, after removing the signed squarefree part. -/
noncomputable def sharpGcd (P : Parameters) (ν : ℤ) : ℕ :=
  Int.gcd (P.u * (P.normAlpha / squarefreePart P.normAlpha)) ν

/-- `rad(f' gcd(uNα/sf(Nα), Nε))`. -/
noncomputable def sharpRadical (P : Parameters) (ν : ℤ) (e : ℕ) : ℤ :=
  UniqueFactorizationMonoid.radical ((e : ℤ) * (P.sharpGcd ν : ℤ))

theorem sharpGcd_paper (P : Parameters) (ν : ℤ) :
    P.sharpGcd ν = Int.gcd (P.u * P.normAlpha / squarefreePart P.normAlpha) ν := by
  unfold sharpGcd
  rw [Int.mul_ediv_assoc _ (squarefreePart_dvd _)]

theorem norm_quotient_ne_zero (P : Parameters) (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0) :
    P.u * (P.normAlpha / squarefreePart P.normAlpha) ≠ 0 := by
  rw [div_squarefreePart]
  exact mul_ne_zero hu (pow_ne_zero _ (ne_of_gt (squareFactor_pos hN)))

theorem sharpGcd_pos (P : Parameters) (ν : ℤ) (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0) :
    0 < P.sharpGcd ν := Int.gcd_pos_of_ne_zero_left _ (P.norm_quotient_ne_zero hu hN)

theorem norm_quotient_mul (P : Parameters) :
    P.u * P.normAlpha = (P.u * (P.normAlpha / squarefreePart P.normAlpha)) * squarefreePart P.normAlpha := by
  rw [div_squarefreePart, mul_assoc, squareFactor_sq_mul]

theorem exists_integer_norm_relation (P : Parameters) [Fact (¬ IsSquare P.d)]
    (hi : IsIntegral ℤ P.epsilon) :
    ∃ ν : ℤ, (ν : ℚ) = P.epsilonNorm ∧ P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν := by
  obtain ⟨ν, hn⟩ := P.exists_integer_epsilonNorm hi
  refine ⟨ν, hn, ?_⟩
  have hq : (P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2 = 4 * ν := by
    unfold epsilonNorm at hn
    linarith
  exact_mod_cast hq


end «JNT-2024».Parameters
