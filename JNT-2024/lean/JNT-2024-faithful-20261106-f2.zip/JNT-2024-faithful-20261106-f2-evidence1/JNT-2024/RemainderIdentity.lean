module

public import «JNT-2024».EulerIntegral
public import «JNT-2024».HypergeometricDeterminant
public import «JNT-2024».HypergeometricPolynomials
public import «JNT-2024».HypergeometricRecurrence
public import «JNT-2024».RemainderConstruction
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

noncomputable def segmentKernel (ν : ℚ) (r : ℕ) (z w : ℂ) : ℂ :=
  ((1 - w) * (w - z)) ^ r * w ^ ((ν : ℂ) - r - 1)

noncomputable def recurrencePrimitive (ν : ℚ) (r : ℕ) (z w : ℂ) : ℂ :=
  ((1 - w) * (w - z)) ^ (r + 1) * w ^ ((ν : ℂ) - r - 2) *
    (((r : ℂ) + 2 + ν) * z - ν * (1 + z) * w - (r + 2 - ν) * w ^ 2)

theorem recurrence_certificate (n v z w : ℂ) :
    (n + 1) * (1 + z - 2 * w) * w *
        ((n + 2 + v) * z - v * (1 + z) * w - (n + 2 - v) * w ^ 2) +
      (v - n - 2) * ((1 - w) * (w - z)) *
        ((n + 2 + v) * z - v * (1 + z) * w - (n + 2 - v) * w ^ 2) +
      ((1 - w) * (w - z)) * w * (-v * (1 + z) - 2 * (n + 2 - v) * w) =
    ((n + 2) ^ 2 - v ^ 2) * ((1 - w) * (w - z)) ^ 2 -
      (n + 2) * (2 * n + 3) * (1 + z) * ((1 - w) * (w - z)) * w +
      (n + 2) * (n + 1) * (1 - z) ^ 2 * w ^ 2 := by
  ring

theorem cpow_shift_one {w : ℂ} (hw : w ≠ 0) (a : ℂ) :
    w ^ (a + 1) = w ^ a * w := by
  rw [Complex.cpow_add _ _ hw, Complex.cpow_one]

theorem hasDerivAt_recurrencePrimitive (ν : ℚ) (r : ℕ) (z : ℂ) {w : ℂ}
    (hw : w ∈ Complex.slitPlane) :
    HasDerivAt (recurrencePrimitive ν r z)
      ((((r : ℂ) + 2) ^ 2 - (ν : ℂ) ^ 2) * segmentKernel ν (r + 2) z w -
        (r + 2) * (2 * r + 3) * (1 + z) * segmentKernel ν (r + 1) z w +
        (r + 2) * (r + 1) * (1 - z) ^ 2 * segmentKernel ν r z w) w := by
  have hq : HasDerivAt (fun u : ℂ => (1 - u) * (u - z)) (1 + z - 2 * w) w := by
    convert ((hasDerivAt_const w 1).sub (hasDerivAt_id w)).mul
      ((hasDerivAt_id w).sub_const z) using 1 <;> first | rfl | (dsimp; ring)
  have hp : HasDerivAt (fun u : ℂ => ((r : ℂ) + 2 + ν) * z -
      ν * (1 + z) * u - (r + 2 - ν) * u ^ 2)
      (-(ν : ℂ) * (1 + z) - 2 * (r + 2 - ν) * w) w := by
    convert (((hasDerivAt_id w).const_mul ((ν : ℂ) * (1 + z))).const_sub
      (((r : ℂ) + 2 + ν) * z)).sub
      (((hasDerivAt_id w).pow 2).const_mul (r + 2 - (ν : ℂ))) using 1 <;>
      first | rfl | (dsimp; ring)
  have hd := ((hq.pow (r + 1)).mul
    ((hasDerivAt_id w).cpow_const (c := (ν : ℂ) - r - 2) hw)).mul hp
  convert hd using 1
  · rfl
  · have hw₀ := Complex.slitPlane_ne_zero hw
    have h₁ : w ^ ((ν : ℂ) - r - 2) = w ^ ((ν : ℂ) - r - 3) * w := by
      convert cpow_shift_one hw₀ ((ν : ℂ) - r - 3) using 1
      congr 1
      ring
    have h₂ : w ^ ((ν : ℂ) - r - 1) = w ^ ((ν : ℂ) - r - 3) * w ^ 2 := by
      rw [show (ν : ℂ) - r - 1 = ((ν : ℂ) - r - 2) + 1 by ring,
        cpow_shift_one hw₀, h₁]
      ring
    dsimp only [id, Pi.mul_apply, Pi.pow_apply]
    simp only [segmentKernel, Nat.cast_add, Nat.cast_one, Nat.cast_ofNat,
      Nat.add_sub_cancel, mul_one,
      show (ν : ℂ) - ((r : ℂ) + 2) - 1 = (ν : ℂ) - r - 3 by ring,
      show (ν : ℂ) - ((r : ℂ) + 1) - 1 = (ν : ℂ) - r - 2 by ring,
      show (ν : ℂ) - r - 2 - 1 = (ν : ℂ) - r - 3 by ring, h₁, h₂,
      pow_add, pow_one]
    linear_combination -(((1 - w) * (w - z)) ^ r * w ^ ((ν : ℂ) - r - 3)) *
      recurrence_certificate (r : ℂ) (ν : ℂ) z w

theorem segmentKernel_continuousOn (ν : ℚ) (r : ℕ) (z : ℂ) :
    ContinuousOn (segmentKernel ν r z) Complex.slitPlane := by
  apply ContinuousOn.mul (by fun_prop)
  exact continuousOn_id.cpow continuousOn_const (fun _ hw => hw)

theorem segmentKernel_chord_continuousOn (ν : ℚ) (r : ℕ) {z : ℂ}
    (hz : z ∈ Complex.slitPlane) :
    ContinuousOn (fun t : ℝ => segmentKernel ν r z (chord z t)) (Set.Icc 0 1) := by
  exact (segmentKernel_continuousOn ν r z).comp (by unfold chord; fun_prop)
    (fun _ ht => chord_mem_slitPlane hz ht)

noncomputable def segmentIntegral (ν : ℚ) (r : ℕ) (z : ℂ) : ℂ :=
  (z - 1) * ∫ t : ℝ in 0..1, segmentKernel ν r z (chord z t)

theorem remainder_eq_segmentIntegral' (ν : ℚ) (r : ℕ) (z : ℂ) :
    remainder ν r z = (risingQ ν (r + 1) : ℂ) / r.factorial * segmentIntegral ν r z := by
  rw [remainder_eq_segmentIntegral]
  simp only [segmentIntegral, segmentKernel, mul_pow, intervalIntegral.integral_mul_const]
  ring

theorem segmentIntegral_recurrence (ν : ℚ) (r : ℕ) {z : ℂ}
    (hz : z ∈ Complex.slitPlane) :
    (((r : ℂ) + 2) ^ 2 - (ν : ℂ) ^ 2) * segmentIntegral ν (r + 2) z -
      (r + 2) * (2 * r + 3) * (1 + z) * segmentIntegral ν (r + 1) z +
      (r + 2) * (r + 1) * (1 - z) ^ 2 * segmentIntegral ν r z = 0 := by
  let A : ℂ := ((r : ℂ) + 2) ^ 2 - (ν : ℂ) ^ 2
  let B : ℂ := (r + 2) * (2 * r + 3) * (1 + z)
  let C : ℂ := (r + 2) * (r + 1) * (1 - z) ^ 2
  have hc (k : ℕ) := segmentKernel_chord_continuousOn ν k hz
  have hi (k : ℕ) := (hc k).intervalIntegrable_of_Icc (μ := MeasureTheory.volume)
    (by norm_num : (0 : ℝ) ≤ 1)
  have hcont : ContinuousOn (fun t : ℝ => A * segmentKernel ν (r + 2) z (1 + t • (z - 1)) -
      B * segmentKernel ν (r + 1) z (1 + t • (z - 1)) +
      C * segmentKernel ν r z (1 + t • (z - 1))) (Set.Icc 0 1) := by
    convert
      (((hc (r + 2)).const_mul A).sub
        ((hc (r + 1)).const_mul B)).add ((hc r).const_mul C) using 1
    funext t
    simp only [chord, Complex.real_smul, mul_comm (z - 1), Pi.add_apply, Pi.sub_apply]
  have hh := intervalIntegral.integral_unitInterval_deriv_eq_sub
    (f := recurrencePrimitive ν r z)
    (f' := fun w => A * segmentKernel ν (r + 2) z w -
      B * segmentKernel ν (r + 1) z w + C * segmentKernel ν r z w)
    (z₀ := 1) (z₁ := z - 1) hcont (fun t ht =>
      hasDerivAt_recurrencePrimitive ν r z
        (StarConvex.add_smul_mem Complex.starConvex_one_slitPlane (by simpa using hz) ht.1 ht.2))
  simp only [smul_eq_mul, add_sub_cancel] at hh
  simp only [recurrencePrimitive, sub_self, mul_zero, zero_mul, zero_pow (by omega : r + 1 ≠ 0),
    mul_one, Complex.one_cpow] at hh
  have he (t : ℝ) : 1 + t • (z - 1) = chord z t := by
    simp [chord, Complex.real_smul, mul_comm]
  simp_rw [he] at hh
  rw [intervalIntegral.integral_add ((hi (r + 2)).const_mul A |>.sub
      ((hi (r + 1)).const_mul B)) ((hi r).const_mul C),
    intervalIntegral.integral_sub ((hi (r + 2)).const_mul A) ((hi (r + 1)).const_mul B),
    intervalIntegral.integral_const_mul, intervalIntegral.integral_const_mul,
    intervalIntegral.integral_const_mul] at hh
  dsimp [segmentIntegral]
  dsimp [A, B, C] at hh
  linear_combination hh

theorem integralFactor_succ (ν : ℚ) (r : ℕ) :
    ((r : ℂ) + 1) * ((risingQ ν (r + 2) : ℂ) / (r + 1).factorial) =
      (r + 1 + (ν : ℂ)) * ((risingQ ν (r + 1) : ℂ) / r.factorial) := by
  have hn : (r : ℂ) + 1 ≠ 0 := by exact_mod_cast (by omega : r + 1 ≠ 0)
  rw [show r + 2 = (r + 1) + 1 by omega, risingQ_succ, Nat.factorial_succ]
  push_cast
  field_simp
  ring

theorem remainder_recurrence (ν : ℚ) (r : ℕ) {z : ℂ}
    (hz : z ∈ Complex.slitPlane) :
    (r + 2 - (ν : ℂ)) * remainder ν (r + 2) z =
      (2 * r + 3) * (1 + z) * remainder ν (r + 1) z -
      (r + 1 + ν) * (1 - z) ^ 2 * remainder ν r z := by
  have hn : (r : ℂ) + 2 ≠ 0 := by exact_mod_cast (by omega : r + 2 ≠ 0)
  have h₁ := integralFactor_succ ν r
  have h₂ := integralFactor_succ ν (r + 1)
  simp only [Nat.cast_add, Nat.cast_one, Nat.add_assoc] at h₂
  simp only [remainder_eq_segmentIntegral']
  apply mul_left_cancel₀ hn
  linear_combination ((risingQ ν (r + 2) : ℂ) / (r + 1).factorial) *
      segmentIntegral_recurrence ν r hz +
    (r + 2 - (ν : ℂ)) * segmentIntegral ν (r + 2) z * h₂ -
    (r + 2) * (1 - z) ^ 2 * segmentIntegral ν r z * h₁

noncomputable def firstPrimitive (ν : ℚ) (z w : ℂ) : ℂ :=
  (ν : ℂ) * (ν - 1) * w ^ ((ν : ℂ) + 1) +
    (1 - (ν : ℂ) ^ 2) * (1 + z) * w ^ (ν : ℂ) +
    ν * (ν + 1) * z * w ^ ((ν : ℂ) - 1)

theorem hasDerivAt_firstPrimitive (ν : ℚ) (z : ℂ) {w : ℂ}
    (hw : w ∈ Complex.slitPlane) :
    HasDerivAt (firstPrimitive ν z)
      ((1 - (ν : ℂ)) * ν * (ν + 1) * segmentKernel ν 1 z w) w := by
  have h (a : ℂ) := (hasDerivAt_id w).cpow_const (c := a) hw
  convert (((h ((ν : ℂ) + 1)).const_mul ((ν : ℂ) * (ν - 1))).add
      ((h (ν : ℂ)).const_mul ((1 - (ν : ℂ) ^ 2) * (1 + z)))).add
      ((h ((ν : ℂ) - 1)).const_mul ((ν : ℂ) * (ν + 1) * z)) using 1
  · rfl
  · dsimp only [id]
    have hw₀ := Complex.slitPlane_ne_zero hw
    have h₁ : w ^ ((ν : ℂ) - 1) = w ^ ((ν : ℂ) - 2) * w := by
      convert cpow_shift_one hw₀ ((ν : ℂ) - 2) using 1
      congr 1
      ring
    have h₂ : w ^ (ν : ℂ) = w ^ ((ν : ℂ) - 2) * w ^ 2 := by
      calc
        _ = w ^ (((ν : ℂ) - 1) + 1) := by congr 1; ring
        _ = _ := by rw [cpow_shift_one hw₀, h₁]; ring
    simp only [segmentKernel, Nat.cast_one, pow_one, mul_one,
      show (ν : ℂ) + 1 - 1 = (ν : ℂ) by ring,
      show (ν : ℂ) - 1 - 1 = (ν : ℂ) - 2 by ring, h₁, h₂]
    ring

theorem remainder_one_index {ν : ℚ} (hν : ν ≠ 1) {z : ℂ}
    (hz : z ∈ Complex.slitPlane) :
    remainder ν 1 z = z ^ (ν : ℂ) * Y ν 1 z - X ν 1 z := by
  have hn : 1 - (ν : ℂ) ≠ 0 := by exact_mod_cast sub_ne_zero.mpr (Ne.symm hν)
  let C : ℂ := (1 - (ν : ℂ)) * ν * (ν + 1)
  have hc : ContinuousOn (fun t : ℝ => C * segmentKernel ν 1 z (1 + t • (z - 1)))
      (Set.Icc 0 1) := by
    convert (segmentKernel_chord_continuousOn ν 1 hz).const_mul C using 1
    funext t
    simp only [chord, Complex.real_smul, mul_comm (z - 1)]
  have hh := intervalIntegral.integral_unitInterval_deriv_eq_sub
    (f := firstPrimitive ν z) (f' := fun w => C * segmentKernel ν 1 z w)
    (z₀ := 1) (z₁ := z - 1) hc (fun t ht =>
      hasDerivAt_firstPrimitive ν z
        (StarConvex.add_smul_mem Complex.starConvex_one_slitPlane (by simpa using hz) ht.1 ht.2))
  simp only [smul_eq_mul, add_sub_cancel, intervalIntegral.integral_const_mul] at hh
  have hh' : C * segmentIntegral ν 1 z = firstPrimitive ν z z - firstPrimitive ν z 1 := by
    convert hh using 1
    simp only [segmentIntegral, chord, Complex.real_smul, mul_comm (z - 1)]
    ring
  have hz₀ := Complex.slitPlane_ne_zero hz
  have hpow := cpow_shift_one hz₀ ((ν : ℂ) - 1)
  simp only [sub_add_cancel] at hpow
  have he : firstPrimitive ν z z - firstPrimitive ν z 1 =
      z ^ (ν : ℂ) * ((1 - ν) * z + (1 + ν)) - ((1 - ν) + (1 + ν) * z) := by
    unfold firstPrimitive
    rw [cpow_shift_one hz₀]
    simp only [Complex.one_cpow, mul_one]
    linear_combination -(ν : ℂ) * (ν + 1) * hpow
  rw [he] at hh'
  apply mul_left_cancel₀ hn
  rw [remainder_eq_segmentIntegral']
  simp only [X, Y, Finset.sum_range_succ, Finset.sum_range_zero,
    coefficient_zero, coefficient_one]
  norm_num [risingQ, Finset.prod_range_succ]
  dsimp [C] at hh'
  field_simp [hn]
  left
  linear_combination hh'

/-- Lemma 2.2(a), with the identity extended to the entire principal slit plane. -/
theorem remainder_identity {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1) (r : ℕ)
    {z : ℂ} (hz : z ∈ Complex.slitPlane) :
    z ^ (ν : ℂ) * Y ν r z - X ν r z = remainder ν r z := by
  induction r using Nat.twoStepInduction with
  | zero =>
    rw [remainder_zero_index ν hz]
    simp [X, Y, coefficient_zero]
  | one => exact (remainder_one_index (ne_of_lt hν₁) hz).symm
  | more r h₀ h₁ =>
    have hn : (r : ℂ) + 2 - ν ≠ 0 := by
      have hp : (0 : ℚ) < r + 2 - ν := by have := Nat.cast_nonneg (α := ℚ) r; linarith
      exact_mod_cast ne_of_gt hp
    apply mul_left_cancel₀ hn
    linear_combination z ^ (ν : ℂ) * Y_recurrence hν₀ hν₁ r (Complex.slitPlane_ne_zero hz) -
      X_recurrence hν₀ hν₁ r z - remainder_recurrence ν r hz +
      (2 * r + 3) * (1 + z) * h₁ - (r + 1 + (ν : ℂ)) * (1 - z) ^ 2 * h₀

theorem lemma22a {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1 / 2) (r : ℕ)
    {z : ℂ} (hz : ‖z - 1‖ < 1) :
    z ^ (ν : ℂ) * Y ν r z - X ν r z = (z - 1) ^ (2 * r + 1) *
      (remainderPrefactor ν r : ℂ) *
      ₂F₁ (r + 1 - (ν : ℂ)) (r + 1) (2 * r + 2) (1 - z) := by
  rw [remainder_identity hν₀ (by linarith) r
    (Complex.ball_one_subset_slitPlane (by simpa [Metric.mem_ball, dist_eq_norm] using hz)),
    remainder_eq_hypergeometric ν r hz]

end Hypergeometric
end «JNT-2024»
