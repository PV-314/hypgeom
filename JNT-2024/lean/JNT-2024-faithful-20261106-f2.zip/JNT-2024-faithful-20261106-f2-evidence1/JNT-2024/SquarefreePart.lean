module

public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- A signed squarefree part and a nonnegative square factor. -/
structure SquarePart (n : ℤ) where
  factor : ℤ
  part : ℤ
  factor_nonneg : 0 ≤ factor
  factorization : factor ^ 2 * part = n
  squarefree : Squarefree part

theorem squarePart_exists (n : ℤ) : Nonempty (SquarePart n) := by
  obtain ⟨c, s, he, hs⟩ := exists_sq_mul_squarefree n
  refine ⟨⟨|c|, s, abs_nonneg _, ?_, hs⟩⟩
  rcases le_total 0 c with hc | hc
  · simpa only [abs_of_nonneg hc] using he
  · simpa only [abs_of_nonpos hc, neg_sq] using he

noncomputable def squarePart (n : ℤ) : SquarePart n := Classical.choice (squarePart_exists n)
noncomputable def squareFactor (n : ℤ) : ℤ := (squarePart n).factor

/-- The signed squarefree part `sf(n)` used in the paper, for nonzero integers. -/
noncomputable def squarefreePart (n : ℤ) : ℤ := (squarePart n).part

theorem squareFactor_nonneg (n : ℤ) : 0 ≤ squareFactor n := (squarePart n).factor_nonneg
theorem squarefreePart_squarefree (n : ℤ) : Squarefree (squarefreePart n) := (squarePart n).squarefree

theorem squareFactor_sq_mul (n : ℤ) : squareFactor n ^ 2 * squarefreePart n = n :=
  (squarePart n).factorization

theorem squarefreePart_ne_zero (n : ℤ) : squarefreePart n ≠ 0 :=
  (squarefreePart_squarefree n).ne_zero

theorem squareFactor_pos {n : ℤ} (hn : n ≠ 0) : 0 < squareFactor n := by
  have he := squareFactor_sq_mul n
  have hc := squareFactor_nonneg n
  by_contra h
  have hz : squareFactor n = 0 := by omega
  simp [hz] at he
  exact hn he.symm

theorem squarefreePart_dvd (n : ℤ) : squarefreePart n ∣ n :=
  ⟨squareFactor n ^ 2, by rw [mul_comm, squareFactor_sq_mul]⟩

theorem div_squarefreePart (n : ℤ) : n / squarefreePart n = squareFactor n ^ 2 := by
  nth_rw 1 [← squareFactor_sq_mul n]
  exact Int.mul_ediv_cancel _ (squarefreePart_ne_zero n)

/-- The squarefree part is unique, including its sign. -/
theorem squarefree_part_unique {n c c' s s' : ℤ} (hn : n ≠ 0)
    (hs : Squarefree s) (hs' : Squarefree s') (h : c ^ 2 * s = n) (h' : c' ^ 2 * s' = n) :
    s = s' := by
  have hc : c ≠ 0 := by intro hz; simp [hz] at h; exact hn h.symm
  have hc' : c' ≠ 0 := by intro hz; simp [hz] at h'; exact hn h'.symm
  have hprod : IsSquare (s * s') := by
    apply Rat.isSquare_intCast_iff.mp
    refine ⟨(s : ℚ) * c / c', ?_⟩
    have hq : (c : ℚ) ^ 2 * s = (c' : ℚ) ^ 2 * s' := by exact_mod_cast h.trans h'.symm
    have hh := congrArg (fun z : ℚ => (s : ℚ) * z) hq
    have hcz : (c' : ℚ) ≠ 0 := by exact_mod_cast hc'
    push_cast
    field_simp
    nlinarith only [hh]
  rcases Int.associated_iff.mp (hs.associated_of_isSquare_mul hs' hprod) with he | he
  · exact he
  · have hz : s' * (c ^ 2 + c' ^ 2) = 0 := by rw [he] at h; nlinarith only [h, h']
    have hp : 0 < c ^ 2 + c' ^ 2 := add_pos (sq_pos_of_ne_zero hc) (sq_pos_of_ne_zero hc')
    exact False.elim ((mul_ne_zero hs'.ne_zero (ne_of_gt hp)) hz)

theorem squarefreePart_eq_of_factorization {n c s : ℤ} (hn : n ≠ 0)
    (hs : Squarefree s) (h : c ^ 2 * s = n) : squarefreePart n = s :=
  squarefree_part_unique hn (squarefreePart_squarefree n) hs (squareFactor_sq_mul n) h

theorem squarefreePart_eq_one {n : ℤ} (hn : n ≠ 0) (hs : IsSquare n) : squarefreePart n = 1 := by
  obtain ⟨c, hc⟩ := hs
  apply squarefreePart_eq_of_factorization (c := c) hn squarefree_one
  simpa [pow_two] using hc.symm

theorem squarefreePart_eq_neg_one {n : ℤ} (hn : n ≠ 0) (hs : IsSquare (-n)) :
    squarefreePart n = -1 := by
  obtain ⟨c, hc⟩ := hs
  apply squarefreePart_eq_of_factorization (c := c) hn (by simp)
  nlinarith [hc]

end «JNT-2024»
