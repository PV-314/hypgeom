module

public import «JNT-2024».ApproximationGcd
public import «JNT-2024».NormalizerFormula
public import «JNT-2024».Section2Parameters
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Section2

open Hypergeometric

noncomputable def root (S : ℤ) : ℂ := (Real.sqrt (-(S : ℝ)) : ℂ) * Complex.I
noncomputable def U (S u₁ u₂ : ℤ) : ℂ := ((u₁ : ℂ) + u₂ * root S) / 2
noncomputable def omega (S u₁ u₂ : ℤ) : ℂ := U S u₁ u₂ / star (U S u₁ u₂)
noncomputable def A (S u₁ u₂ : ℤ) : ℂ := star (U S u₁ u₂) / (Approximation.g S u₁ u₂ : ℂ)
noncomputable def delta (S u₁ u₂ : ℤ) : ℂ :=
  (U S u₁ u₂ - star (U S u₁ u₂)) / (Approximation.g S u₁ u₂ : ℂ)
def H (S u₁ u₂ : ℤ) : ℝ := (u₁ : ℝ) ^ 2 - S * (u₂ : ℝ) ^ 2

theorem root_sq {S : ℤ} (hS : S ≤ 0) : root S ^ 2 = (S : ℂ) := by
  have hs := Real.sq_sqrt (show (0 : ℝ) ≤ -(S : ℝ) by exact_mod_cast neg_nonneg.mpr hS)
  simp only [root, mul_pow, Complex.I_sq, ← Complex.ofReal_pow, hs]
  push_cast
  ring

theorem U_re (S u₁ u₂ : ℤ) : (U S u₁ u₂).re = (u₁ : ℝ) / 2 := by
  simp [U, root]

theorem U_im (S u₁ u₂ : ℤ) : (U S u₁ u₂).im = (u₂ : ℝ) * Real.sqrt (-(S : ℝ)) / 2 := by
  simp [U, root]

theorem U_ne_zero {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) : U S u₁ u₂ ≠ 0 := by
  have hs : Real.sqrt (-(S : ℝ)) ≠ 0 := ne_of_gt (Real.sqrt_pos.mpr (by exact_mod_cast neg_pos.mpr hS))
  intro hz
  have hh := congrArg Complex.im hz
  rw [U_im, Complex.zero_im] at hh
  exact (div_ne_zero (mul_ne_zero (by exact_mod_cast hu₂) hs) (by norm_num)) hh

theorem U_add_star (S u₁ u₂ : ℤ) : U S u₁ u₂ + star (U S u₁ u₂) = (u₁ : ℂ) := by
  apply Complex.ext <;> simp [U_re, U_im]

theorem U_sub_star (S u₁ u₂ : ℤ) : U S u₁ u₂ - star (U S u₁ u₂) = (u₂ : ℂ) * root S := by
  apply Complex.ext <;> simp [U_re, U_im, root]

theorem H_pos {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) : 0 < H S u₁ u₂ := by
  have hs : (S : ℝ) < 0 := by exact_mod_cast hS
  have hu : (0 : ℝ) < (u₂ : ℝ) ^ 2 := sq_pos_of_ne_zero (by exact_mod_cast hu₂)
  unfold H
  nlinarith [sq_nonneg (u₁ : ℝ)]

theorem U_norm_sq {S : ℤ} (hS : S ≤ 0) (u₁ u₂ : ℤ) : ‖U S u₁ u₂‖ ^ 2 = H S u₁ u₂ / 4 := by
  have hs := Real.sq_sqrt (show (0 : ℝ) ≤ -(S : ℝ) by exact_mod_cast neg_nonneg.mpr hS)
  rw [← Complex.normSq_eq_norm_sq, Complex.normSq_apply, U_re, U_im]
  unfold H
  nlinarith only [congrArg (fun t : ℝ => (u₂ : ℝ) ^ 2 * t) hs]

theorem two_norm_U {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) :
    2 * ‖U S u₁ u₂‖ = Real.sqrt (H S u₁ u₂) := by
  have hh := U_norm_sq hS.le u₁ u₂
  have hs := Real.sq_sqrt (H_pos (u₁ := u₁) hS hu₂).le
  nlinarith [norm_nonneg (U S u₁ u₂), Real.sqrt_nonneg (H S u₁ u₂)]

theorem omega_norm {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) : ‖omega S u₁ u₂‖ = 1 := by
  rw [omega, norm_div, norm_star, div_self (norm_ne_zero_iff.mpr (U_ne_zero hS hu₂))]

theorem omega_ne_one {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) : omega S u₁ u₂ ≠ 1 := by
  have hs : star (U S u₁ u₂) ≠ 0 := star_ne_zero.mpr (U_ne_zero hS hu₂)
  intro he
  have hh := (div_eq_one_iff_eq hs).mp he
  have hi := congrArg Complex.im hh
  simp only [Complex.star_def, Complex.conj_im, U_im] at hi
  have hp : Real.sqrt (-(S : ℝ)) ≠ 0 := ne_of_gt (Real.sqrt_pos.mpr (by exact_mod_cast neg_pos.mpr hS))
  have hz : (u₂ : ℝ) * Real.sqrt (-(S : ℝ)) = 0 := by linarith
  exact (mul_ne_zero (by exact_mod_cast hu₂) hp) hz

theorem g_ne_zero {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) :
    (Approximation.g S u₁ u₂ : ℂ) ≠ 0 := by
  exact_mod_cast ne_of_gt (Approximation.g_pos (ne_of_lt hS) hu₂)

theorem A_ne_zero {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) : A S u₁ u₂ ≠ 0 :=
  div_ne_zero (star_ne_zero.mpr (U_ne_zero hS hu₂)) (g_ne_zero hS hu₂)

theorem omega_eq_one_add {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) :
    omega S u₁ u₂ = 1 + delta S u₁ u₂ / A S u₁ u₂ := by
  have hg := g_ne_zero (u₁ := u₁) hS hu₂
  have hu := star_ne_zero.mpr (U_ne_zero (u₁ := u₁) hS hu₂)
  unfold omega delta A
  field_simp
  ring

theorem dPrimeInteger_complex {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) :
    (Approximation.dPrimeInteger S u₁ u₂ : ℂ) =
      (u₂ : ℂ) ^ 2 * S / (Approximation.g S u₁ u₂ : ℂ) ^ 2 := by
  have hg : (Approximation.g S u₁ u₂ : ℂ) ^ 2 = ((Approximation.gSquared S u₁ u₂ : ℚ) : ℂ) := by
    exact_mod_cast Approximation.g_sq S u₁ u₂
  rw [hg]
  have hh := Approximation.dPrimeInteger_cast (u₁ := u₁) (ne_of_lt hS) hu₂
  unfold Approximation.dPrime at hh
  exact_mod_cast hh

/-- Equation (2.6), with its integer value and chosen complex square root. -/
theorem delta_sq {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) :
    delta S u₁ u₂ ^ 2 = (Approximation.dPrimeInteger S u₁ u₂ : ℂ) := by
  rw [delta, div_pow, U_sub_star, mul_pow, root_sq hS.le, dPrimeInteger_complex hS hu₂]

theorem integral_of_quadratic {z : ℂ} (a b : ℤ) (hz : z ^ 2 - a * z + b = 0) :
    IsIntegral ℤ z := by
  refine ⟨Polynomial.X ^ 2 + (Polynomial.C (-a) * Polynomial.X + Polynomial.C b), ?_, ?_⟩
  · apply Polynomial.monic_X_pow_add
    apply lt_of_le_of_lt (Polynomial.degree_add_le _ _)
    exact max_lt (lt_of_le_of_lt (Polynomial.degree_C_mul_X_le _) (by norm_num))
      (lt_of_le_of_lt Polynomial.degree_C_le (by norm_num))
  · simp only [Polynomial.eval₂_add, Polynomial.eval₂_pow, Polynomial.eval₂_X,
      Polynomial.eval₂_mul, Polynomial.eval₂_C]
    change z ^ 2 + (((-a : ℤ) : ℂ) * z + (b : ℂ)) = 0
    push_cast
    linear_combination hz

theorem integral_of_scaled_trace {z t : ℂ} {T n : ℤ}
    (ht : t ^ 2 = T) (hz : z ^ 2 - t * z + n = 0) : IsIntegral ℤ z := by
  apply IsIntegral.of_pow (by decide : 0 < 2)
  apply integral_of_quadratic (T - 2 * n) (n ^ 2)
  push_cast
  linear_combination (z ^ 2 + t * z + n) * hz + z ^ 2 * ht

theorem A_integral {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) : IsIntegral ℤ (A S u₁ u₂) := by
  obtain ⟨T, hT⟩ := Approximation.normalizer_trace_square_integral (u₁ := u₁) (ne_of_lt hS) hu₂
  obtain ⟨n, hn⟩ := Approximation.normalizer_norm_integral (u₁ := u₁) (ne_of_lt hS) hu₂
  have hg := g_ne_zero (u₁ := u₁) hS hu₂
  have hg2 : (Approximation.g S u₁ u₂ : ℂ) ^ 2 = ((Approximation.gSquared S u₁ u₂ : ℚ) : ℂ) := by
    exact_mod_cast Approximation.g_sq S u₁ u₂
  have ht : ((u₁ : ℂ) / (Approximation.g S u₁ u₂ : ℂ)) ^ 2 = T := by
    rw [div_pow, hg2]
    exact_mod_cast hT
  have hn' : ((u₁ : ℂ) ^ 2 - S * (u₂ : ℂ) ^ 2) /
      (4 * (Approximation.g S u₁ u₂ : ℂ) ^ 2) = n := by
    rw [hg2]
    exact_mod_cast hn
  apply integral_of_scaled_trace ht
  rw [← hn']
  unfold A
  field_simp
  have hbase : 4 * star (U S u₁ u₂) ^ 2 - 4 * u₁ * star (U S u₁ u₂) +
      (u₁ : ℂ) ^ 2 - S * (u₂ : ℂ) ^ 2 = 0 := by
    have hr := root_sq hS.le
    have he : star (U S u₁ u₂) = ((u₁ : ℂ) - u₂ * root S) / 2 := by
      apply Complex.ext <;> simp [U_re, U_im, root]
      ring
    rw [he]
    linear_combination (u₂ : ℂ) ^ 2 * hr
  linear_combination hbase

end Section2
end «JNT-2024»
