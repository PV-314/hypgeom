module

public import «JNT-2024».DenominatorDefinitions
public import «JNT-2024».HypergeometricPolynomials
public import «JNT-2024».HypergeometricRecurrence
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

open Polynomial

def oddDenominatorProduct : ℕ → ℕ
  | 0 => 1
  | r + 1 => oddDenominatorProduct r * (4 * r + 3)

noncomputable def rawX4 : ℕ → Polynomial ℤ
  | 0 => 1
  | 1 => 3 + 5 * Polynomial.X
  | r + 2 => (4 * (2 * (r : Polynomial ℤ) + 3)) * (1 + Polynomial.X) * rawX4 (r + 1) -
      ((4 * (r : Polynomial ℤ) + 5) * (4 * (r : Polynomial ℤ) + 3)) * (1 - Polynomial.X) ^ 2 * rawX4 r

noncomputable def rawScaledX4 : ℕ → Polynomial ℤ
  | 0 => 1
  | 1 => 1 - 5 * Polynomial.X
  | r + 2 => (2 * (r : Polynomial ℤ) + 3) * (1 - 4 * Polynomial.X) * rawScaledX4 (r + 1) -
      ((4 * (r : Polynomial ℤ) + 5) * (4 * (r : Polynomial ℤ) + 3)) * Polynomial.X ^ 2 * rawScaledX4 r

theorem oddDenominatorProduct_odd (r : ℕ) : Odd (oddDenominatorProduct r) := by
  induction r with
  | zero => simp [oddDenominatorProduct]
  | succ r ih =>
    rw [oddDenominatorProduct]
    exact ih.mul ⟨2 * r + 1, by omega⟩


theorem Xpoly_quarter_zero : Xpoly (1 / 4) 0 = 1 := by
  simp [Xpoly, coefficient_zero]

theorem Xpoly_quarter_one : Xpoly (1 / 4) 1 = 1 + C (5 / 3 : ℚ) * Polynomial.X := by
  norm_num [Xpoly, Finset.sum_range_succ, coefficient_zero, coefficient_one]
  simpa using (Polynomial.C_mul_X_pow_eq_monomial (a := (5 / 3 : ℚ)) (n := 1)).symm

theorem Xpoly_quarter_recurrence (r : ℕ) :
    (4 * (r : Polynomial ℚ) + 7) * Xpoly (1 / 4) (r + 2) =
      (4 * (2 * (r : Polynomial ℚ) + 3)) * (1 + Polynomial.X) * Xpoly (1 / 4) (r + 1) -
      (4 * (r : Polynomial ℚ) + 5) * (1 - Polynomial.X) ^ 2 * Xpoly (1 / 4) r := by
  have hh := Xpoly_recurrence (ν := (1 / 4)) (by norm_num) (by norm_num) r
  simp only [map_add, map_sub, map_mul, map_natCast, map_ofNat, map_one] at hh
  have hquarter : (4 : Polynomial ℚ) * C (1 / 4 : ℚ) = 1 := by
    change C (4 : ℚ) * C (1 / 4 : ℚ) = 1
    rw [← map_mul]
    norm_num
  linear_combination (4 : Polynomial ℚ) * hh + Xpoly (1 / 4) (r + 2) * hquarter -
    (1 - Polynomial.X) ^ 2 * Xpoly (1 / 4) r * hquarter

theorem rawX4_map (r : ℕ) :
    (rawX4 r).map (Int.castRingHom ℚ) =
      (oddDenominatorProduct r : Polynomial ℚ) * Xpoly (1 / 4) r := by
  induction r using Nat.twoStepInduction with
  | zero => rw [rawX4, oddDenominatorProduct, Xpoly_quarter_zero]; simp
  | one =>
    rw [rawX4, oddDenominatorProduct, oddDenominatorProduct, Xpoly_quarter_one]
    norm_num
    have hh : (3 : Polynomial ℚ) * C (5 / 3 : ℚ) = 5 := by
      change C (3 : ℚ) * C (5 / 3 : ℚ) = 5
      rw [← map_mul]
      norm_num
      rfl
    linear_combination -Polynomial.X * hh
  | more r h₀ h₁ =>
    rw [rawX4]
    simp only [Polynomial.map_sub, Polynomial.map_mul, Polynomial.map_add, Polynomial.map_pow,
      Polynomial.map_natCast, Polynomial.map_ofNat, Polynomial.map_one, Polynomial.map_X, h₀, h₁,
      oddDenominatorProduct, Nat.cast_mul, Nat.cast_add, Nat.cast_ofNat, Nat.cast_one]
    linear_combination -((oddDenominatorProduct r : Polynomial ℚ) * (4 * r + 3)) *
      Xpoly_quarter_recurrence r

theorem denominator4_dvd_oddDenominatorProduct (r : ℕ) :
    denominator4 r ∣ oddDenominatorProduct r := by
  apply (denominator4_dvd_iff r _).mpr
  intro j
  refine ⟨(rawX4 r).coeff j, ?_⟩
  have hh := congrArg (fun p : Polynomial ℚ => p.coeff j) (rawX4_map r)
  simpa only [Polynomial.coeff_map, Int.coe_castRingHom, Polynomial.coeff_natCast_mul,
    Xpoly_coeff] using hh


/-- Integral scaling at eight, the source of the sharp two-adic content bound. -/
theorem rawX4_comp_eight (r : ℕ) :
    (rawX4 r).comp (1 - 8 * Polynomial.X) = (8 : Polynomial ℤ) ^ r * rawScaledX4 r := by
  induction r using Nat.twoStepInduction with
  | zero => simp [rawX4, rawScaledX4]
  | one => simp [rawX4, rawScaledX4]; ring
  | more r h₀ h₁ =>
    rw [rawX4, rawScaledX4]
    simp only [Polynomial.sub_comp, Polynomial.mul_comp, Polynomial.add_comp, Polynomial.pow_comp,
      Polynomial.natCast_comp, Polynomial.ofNat_comp, Polynomial.one_comp, Polynomial.X_comp,
      h₀, h₁, pow_add, pow_one]
    ring

end Hypergeometric
end «JNT-2024»
