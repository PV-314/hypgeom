module

public import «JNT-2024».Section6Families
public import «JNT-2024».Sequence
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section6

theorem negative_square {n : ℤ} (hn : 0 < n) : -(n^2) < 0 ∧ IsSquare (-(-(n^2))) := by
  refine ⟨by nlinarith, ⟨n, ?_⟩⟩
  ring

theorem abs_negative_square (P : Parameters) {n : ℤ} (hn : P.normAlpha = -(n^2)) :
    |(P.normAlpha : ℝ)| = (n : ℝ)^2 := by simp [hn]

theorem families65_68_negative_square (j : ℕ) :
    ((family65 j).normAlpha < 0 ∧ IsSquare (-(family65 j).normAlpha)) ∧
    ((family66 j).normAlpha < 0 ∧ IsSquare (-(family66 j).normAlpha)) ∧
    ((family67 j).normAlpha < 0 ∧ IsSquare (-(family67 j).normAlpha)) ∧
    ((family68 j).normAlpha < 0 ∧ IsSquare (-(family68 j).normAlpha)) := by
  have hp := pellPair_properties j
  obtain ⟨h65,h66,h67,h68,_⟩ := families65_68_values j
  rw [h65,h66,h67,h68]
  exact ⟨negative_square (by omega), negative_square (by omega),
    negative_square (by omega), negative_square (by omega)⟩

theorem pell_square_bounds (j : ℕ) :
    (pellQ j)^2 < (pellP j-1)^2 ∧ 2*(pellQ j)^2 < (pellP j+1)^2 ∧
    (pellQ j)^2 < 3*((pellP j-1)/2)^2 ∧ (pellQ j)^2 < 2*((pellP j+1)/2)^2 := by
  have hh := pellPair_properties j
  have hm : 2*((pellP j-1)/2)=pellP j-1 := by omega
  have hp : 2*((pellP j+1)/2)=pellP j+1 := by omega
  have hl := mul_nonneg (show 0 ≤ pellP j by omega) (show 0 ≤ pellP j-7 by omega)
  constructor
  · nlinarith only [hh.1, hh.2.2.1, hl]
  constructor
  · nlinarith only [hh.1, hh.2.2.1]
  constructor <;> nlinarith only [hh.1, hh.2.2.1, hl, hm, hp]

theorem families65_68_published_bounds (j : ℕ) :
    ((family65 j).y (families65_68_admissible j).1.pell 1 : ℝ) < |((family65 j).normAlpha : ℝ)| ∧
    ((family66 j).y (families65_68_admissible j).2.1.pell (-1) : ℝ) < |((family66 j).normAlpha : ℝ)|/2 ∧
    ((family67 j).y (families65_68_admissible j).2.2.1.pell 1 : ℝ) < 3*|((family67 j).normAlpha : ℝ)| ∧
    ((family68 j).y (families65_68_admissible j).2.2.2.pell (-1) : ℝ) < 2*|((family68 j).normAlpha : ℝ)| := by
  obtain ⟨h65,h66,h67,h68,hy65,hy66,hy67,hy68⟩ := families65_68_values j
  rw [hy65,hy66,hy67,hy68,abs_negative_square _ h65,abs_negative_square _ h66,
    abs_negative_square _ h67,abs_negative_square _ h68]
  push_cast
  obtain ⟨hb65,hb66,hb67,hb68⟩ := pell_square_bounds j
  refine ⟨by exact_mod_cast hb65, ?_, by exact_mod_cast hb67, by exact_mod_cast hb68⟩
  have hh : (2 : ℝ)*(pellQ j : ℝ)^2 < ((pellP j+1 : ℤ) : ℝ)^2 := by exact_mod_cast hb66
  push_cast at hh
  linarith

theorem families65_68_injective :
    Function.Injective family65 ∧ Function.Injective family66 ∧
    Function.Injective family67 ∧ Function.Injective family68 := by
  have h65 : Function.Injective family65 := by
    intro i j he
    have ht := congrArg Parameters.t he
    dsimp [family65,unitOne] at ht
    apply pellP_strictMono.injective
    omega
  have h66 : Function.Injective family66 := by
    intro i j he
    have ht := congrArg Parameters.t he
    dsimp [family66,unitOne] at ht
    apply pellP_strictMono.injective
    omega
  have h67 : Function.Injective family67 := by
    intro i j he
    have ht := congrArg Parameters.t he
    have hi := pellPair_properties i
    have hj := pellPair_properties j
    dsimp [family67,unitTwo] at ht
    apply pellP_strictMono.injective
    omega
  have h68 : Function.Injective family68 := by
    intro i j he
    have ht := congrArg Parameters.t he
    have hi := pellPair_properties i
    have hj := pellPair_properties j
    dsimp [family68,unitTwo] at ht
    apply pellP_strictMono.injective
    omega
  exact ⟨h65,h66,h67,h68⟩

theorem families65_68_infinite :
    Set.Infinite (Set.range family65) ∧ Set.Infinite (Set.range family66) ∧
    Set.Infinite (Set.range family67) ∧ Set.Infinite (Set.range family68) :=
  ⟨Set.infinite_range_of_injective families65_68_injective.1,
   Set.infinite_range_of_injective families65_68_injective.2.1,
   Set.infinite_range_of_injective families65_68_injective.2.2.1,
   Set.infinite_range_of_injective families65_68_injective.2.2.2⟩

end «JNT-2024».Section6
