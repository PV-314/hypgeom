module

public import «JNT-2024».Section4Case44Published
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.Deriv.MeanValue
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

/-- Exact division of the two sides of (4.18), before decimal rounding.
The letters a,b,k,q stand for 0.1832,0.64,8.537,21.47 respectively. -/
theorem case44_division_identity {N d y F M c a b k q : ℝ} {r : ℕ}
    (hN : N ≠ 0) (hd : d ≠ 0) (hy : y ≠ 0) (hF : F ≠ 0) (hM : M ≠ 0)
    (hc : c ≠ 0) (hc1 : 1-c ≠ 0) (ha : a ≠ 0) (hk : k ≠ 0) (hq : q ≠ 0)
    (hr : 1 ≤ r) :
    ((N*F)^2*(b/(1-c))^4*(q/M)^(4*r)*d^(2*r-2)*y^(4*r+1)) /
      ((k/M)^12*(N/F)^6*c^12*(a*M/N)^(12*r)*d^(6*r)*y^(12*r-3)) =
    (F^8*(N^2*M^4/d^4)*(b^4*q^2/(a^6*c^12*(1-c)^4*k^12))*
      (q^2/a^6)^(2*r-1))/(y^4*d^2*M^8/N^6)^(2*r-1) := by
  rw [pow_sub₀ d hd (by omega : 2 ≤ 2*r),
    pow_sub₀ y hy (by omega : 3 ≤ 12*r),
    pow_sub₀ (q^2/a^6) (by positivity) (by omega : 1 ≤ 2*r),
    pow_sub₀ (y^4*d^2*M^8/N^6) (by positivity) (by omega : 1 ≤ 2*r)]
  simp only [pow_add,pow_one,mul_pow,div_pow,← pow_mul]
  simp only [show 4*r=r*4 by omega,show 2*r=r*2 by omega,
    show 12*r=r*12 by omega,show 6*r=r*6 by omega,
    show 2*(r*2)=r*4 by omega,show 6*(r*2)=r*12 by omega,
    show 4*(r*2)=r*8 by omega,show 8*(r*2)=r*16 by omega]
  simp only [pow_mul]
  field_simp

/-- Equation (4.19), in the equivalent form with M^8 inside the left power.
Both printed roundings and the chosen c are retained. -/
theorem nonexact_equation419_normalized {N d y F M : ℝ} {r : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hy : 0 < y) (hF : 0 < F) (hM : 0 < M) (hr : 1 ≤ r)
    (h418 : ((8537/1000 : ℝ)/M)^12*(N/F)^6*(3/4 : ℝ)^12*
      ((1832/10000 : ℝ)*M/N)^(12*r)*d^(6*r)*y^(12*r-3) <
      (N*F)^2*((64/100 : ℝ)/(1-3/4))^4*((2147/100 : ℝ)/M)^(4*r)*
        d^(2*r-2)*y^(4*r+1)) :
    (y^4*d^2*M^8/N^6)^(2*r-1) <
      F^8*(111/1000 : ℝ)*(N^2*M^4/d^4)*(12200000 : ℝ)^(2*r-1) := by
  have hlow : 0 < ((8537/1000 : ℝ)/M)^12*(N/F)^6*(3/4 : ℝ)^12*
      ((1832/10000 : ℝ)*M/N)^(12*r)*d^(6*r)*y^(12*r-3) := by positivity
  have hratio := (one_lt_div hlow).mpr h418
  rw [case44_division_identity (ne_of_gt hN) (ne_of_gt hd) (ne_of_gt hy)
    (ne_of_gt hF) (ne_of_gt hM) (by norm_num) (by norm_num) (by norm_num)
    (by norm_num) (by norm_num) hr] at hratio
  have hbase : 0 < (y^4*d^2*M^8/N^6)^(2*r-1) := by positivity
  have hh := (one_lt_div hbase).mp hratio
  have hcf : (64/100 : ℝ)^4*(2147/100)^2 /
      ((1832/10000)^6*(3/4)^12*(1-3/4)^4*(8537/1000)^12) < 111/1000 := by
    have hden : (1832/10000 : ℝ)^6*(1237/10000000)*(8537/1000)^12 <
        (1832/10000 : ℝ)^6*(3/4)^12*(1-3/4)^4*(8537/1000)^12 := by
      have hh := mul_lt_mul_of_pos_left cutoff_choice_value
        (by norm_num : 0 < (1832/10000 : ℝ)^6*(8537/1000)^12)
      convert hh using 1 <;> ring
    exact (div_lt_div_of_pos_left (by norm_num) (by norm_num) hden).trans
      case44_rounding_constants.2
  apply hh.trans
  have hpow := pow_le_pow_left₀ (by norm_num : 0 ≤ (2147/100 : ℝ)^2/(1832/10000)^6)
    case44_rounding_constants.1.le (2*r-1)
  have hconst := mul_lt_mul_of_pos_left hcf (by positivity : 0 < F^8*(N^2*M^4/d^4))
  have hm := mul_lt_mul hconst hpow (by positivity) (by positivity)
  convert hm using 1
  ring

/-- The literal placement of M in (4.19). -/
theorem nonexact_equation419 {N d y F M : ℝ} {r : ℕ} (hM : 0 < M)
    (hh : (y^4*d^2*M^8/N^6)^(2*r-1) <
      F^8*(111/1000 : ℝ)*(N^2*M^4/d^4)*(12200000 : ℝ)^(2*r-1)) :
    (y^4*d^2/N^6)^(2*r-1) <
      F^8*(111/1000 : ℝ)*(N^2*M^4/d^4)*((12200000 : ℝ)/M^8)^(2*r-1) := by
  have hp : 0 < (M^8)^(2*r-1) := by positivity
  have hd := (div_lt_div_iff_of_pos_right hp).mpr hh
  convert hd using 1 <;> simp only [mul_pow,div_pow] <;> field_simp

/-- The normalization by 59.11 and Lemma 3.12's bound give (4.20). -/
theorem nonexact_equation420 {N d y M : ℝ} {r : ℕ}
    (_hN : 0 < N) (_hd : 0 < d) (_hy : 0 < y) (_hM : 0 < M)
    (hnorm : N^2*M^4/d^4 ≤ (2:ℝ)^20/17^4)
    (hh : (y^4*d^2*M^8/N^6)^(2*r-1) <
      (111/1000 : ℝ)*(N^2*M^4/d^4)*(12200000 : ℝ)^(2*r-1)) :
    (y^4*d^2*M^8/((5911/100 : ℝ)^4*N^6))^(2*r-1) < 7/5 := by
  have hc : (111/1000 : ℝ)*(N^2*M^4/d^4) < 7/5 := by
    have hh := mul_le_mul_of_nonneg_left hnorm (by norm_num : (0:ℝ)≤111/1000)
    norm_num at hh
    linarith
  have hp : (12200000 : ℝ)^(2*r-1) ≤ ((5911/100 : ℝ)^4)^(2*r-1) :=
    pow_le_pow_left₀ (by norm_num) (by norm_num) _
  have hm := mul_lt_mul_of_pos_right hc (by positivity : 0 < (12200000 : ℝ)^(2*r-1))
  have hu := mul_le_mul_of_nonneg_left hp (by norm_num : (0:ℝ)≤7/5)
  have hfinal := (div_lt_iff₀ (by positivity : 0 < ((5911/100 : ℝ)^4)^(2*r-1))).mpr
    (hh.trans (hm.trans_le hu))
  convert hfinal using 1
  rw [← div_pow]
  congr 1
  ring

end «JNT-2024».Section4
