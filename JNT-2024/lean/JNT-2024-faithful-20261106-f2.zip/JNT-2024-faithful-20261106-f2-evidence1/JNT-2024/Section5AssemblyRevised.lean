module

public import «JNT-2024».AkhtariInput
public import «JNT-2024».DenominatorBounds
public import «JNT-2024».Integrality
public import «JNT-2024».Lemma51Revised
public import «JNT-2024».Lemma52ReductionPublished
public import «JNT-2024».Lemma52Revised
public import «JNT-2024».Lemma53
public import «JNT-2024».Lemma53Revised
public import «JNT-2024».Lemma55Revised
public import «JNT-2024».Lemma56Revised
public import «JNT-2024».Monotonicity
public import «JNT-2024».PaperBridge
public import «JNT-2024».Positivity
public import «JNT-2024».Proposition41
public import «JNT-2024».Section46Calculation
public import «JNT-2024».Section4Published
public import «JNT-2024».Section5Counting
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.Deriv.MeanValue
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Pow.Real
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.LegendreSymbol.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section
namespace «JNT-2024».Section5Revised

theorem two_implies_three {Y:ℤ → ℚ} (h:AtMostSquareValues Y 2) : AtMostSquareValues Y 3 := by
  obtain ⟨S,hS,hs⟩ := h
  exact ⟨S,hS.trans (by decide),hs⟩

theorem nonadjacent_natAbs {k:ℤ} (h0:k ≠ 0) (h1:k ≠ 1) (hm:k ≠ -1) : 2 ≤ k.natAbs := by
  have hh := Int.natCast_natAbs k
  rcases le_total 0 k with hp | hp
  · rw [abs_of_nonneg hp] at hh; omega
  · rw [abs_of_nonpos hp] at hh; omega

end Section5Revised
namespace Parameters

theorem low_adjacent_exceptional_revised (P:Parameters) (h:P.Admissible) (hb:P.b=1)
    (hn:P.normAlpha<0) (hNs:IsSquare (-P.normAlpha)) (hK:P.IsNegativeCutoff h.pell (-1))
    {k:ℤ} (hk:k=1 ∨ k= -1) (hs:IsIntegerSquare (P.y h.pell k))
    (hy:1<P.y h.pell k) (hc:(P.y h.pell k:ℝ) ≤ P.proposition41Threshold) :
    P.Exceptional h.pell := by
  have hadj : P.AdjacentSquare h.pell := by
    rcases hk with rfl | rfl
    · exact Or.inl hs
    · exact Or.inr hs
  rcases Int.even_or_odd (-P.normAlpha) with he | ho
  · rcases P.lemma56_revised h hb hn hNs he hK hk hs hy hc with
      ⟨hu,hunit,hmod,hg⟩ | ⟨hu,hunit,hmod,hg⟩ | ⟨hu,hunit,hmod,hg⟩
    · exact ⟨hunit,hadj,Or.inl ⟨hu,hmod,hg⟩⟩
    · exact ⟨hunit,hadj,Or.inr (Or.inl ⟨hu,hmod,hg⟩)⟩
    · exact ⟨hunit,hadj,Or.inr (Or.inr (Or.inr ⟨hu,hmod,hg⟩))⟩
  · obtain ⟨hu,hunit,hg⟩ := P.lemma55_revised h hb hn hNs ho hK hk hs hy hc
    exact ⟨hunit,hadj,Or.inr (Or.inr (Or.inl ⟨hu,by simpa using ho,hg⟩))⟩

/-- The revised final argument: the large-index assertion bounds the remaining
square values, while both adjacent squares are handled by Lemma 5.3. -/
theorem section5_main_revised (P:Parameters)
    (hPrior:Hypergeometric.DenominatorEstimate4) (hAkhtari:ExternalResults.AkhtariTheorem11)
    (hCalculation:Calculations.Section46Magma) (h:P.Admissible) (hb:P.b=1)
    (hn:P.normAlpha<0) (hNs:IsSquare (-P.normAlpha)) (hK:P.IsNegativeCutoff h.pell (-1))
    (hd:112 ≤ P.d) (hN4:4 ≤ -P.normAlpha) :
    AtMostSquareValues (P.y h.pell) 3 ∧
    (¬P.Exceptional h.pell → AtMostSquareValues (P.y h.pell) 2) := by
  classical
  have above (k:ℤ) (hk:2 ≤ k.natAbs) (hs:IsIntegerSquare (P.y h.pell k)) :=
    P.lemma52_above_revised h hb hn hNs hK hd hN4 hk hs
  constructor
  · by_cases hm:IsIntegerSquare (P.y h.pell (-1))
    · by_cases hp:IsIntegerSquare (P.y h.pell 1)
      · refine ⟨{1,P.y h.pell (-1),P.y h.pell 1},?_,?_⟩
        · exact (Finset.card_insert_le _ _).trans (by have := Section5.card_pair_le (P.y h.pell (-1)) (P.y h.pell 1); omega)
        · intro k hs
          by_cases h0:k=0
          · simp [h0,hb]
          by_cases h1:k=1
          · simp [h1]
          by_cases hn1:k= -1
          · simp [hn1]
          exact (P.lemma53_revised hPrior hAkhtari hCalculation h hb hn hNs hK hm hp
            (ne_of_lt (P.section5_adjacent_order h))
            (by have := Section5Revised.nonadjacent_natAbs h0 h1 hn1; omega) hs).elim
      · apply Section5.atMost_three_of_one_extra (P.y_pos h hn) (P.y h.pell (-1))
        intro i j hi hj hi1 hj1 him hjm
        have nonadj (k:ℤ) (hs:IsIntegerSquare (P.y h.pell k)) (hy:1<P.y h.pell k)
            (hne:P.y h.pell k ≠ P.y h.pell (-1)) : 2 ≤ k.natAbs := by
          apply Section5Revised.nonadjacent_natAbs
          · intro he; simp [he,hb] at hy
          · intro he; rw [he] at hs; exact hp hs
          · intro he; exact hne (congrArg (P.y h.pell) he)
        exact proposition41_published hPrior hAkhtari hCalculation P h hb hn hNs
          i j hi hj (above i (nonadj i hi hi1 him) hi) (above j (nonadj j hj hj1 hjm) hj)
    · apply Section5.atMost_three_of_one_extra (P.y_pos h hn) (P.y h.pell 1)
      intro i j hi hj hi1 hj1 hip hjp
      have nonadj (k:ℤ) (hs:IsIntegerSquare (P.y h.pell k)) (hy:1<P.y h.pell k)
          (hne:P.y h.pell k ≠ P.y h.pell 1) : 2 ≤ k.natAbs := by
        apply Section5Revised.nonadjacent_natAbs
        · intro he; simp [he,hb] at hy
        · intro he; exact hne (congrArg (P.y h.pell) he)
        · intro he; rw [he] at hs; exact hm hs
      exact proposition41_published hPrior hAkhtari hCalculation P h hb hn hNs
        i j hi hj (above i (nonadj i hi hi1 hip) hi) (above j (nonadj j hj hj1 hjp) hj)
  · intro hnot
    apply Section5.atMost_two_of_unique (P.y_pos h hn)
    have hall (k:ℤ) (hs:IsIntegerSquare (P.y h.pell k)) (hy:1<P.y h.pell k) :
        P.proposition41Threshold<(P.y h.pell k:ℝ) := by
      by_cases hadj:k=1 ∨ k= -1
      · by_contra hc
        exact hnot (P.low_adjacent_exceptional_revised h hb hn hNs hK hadj hs hy (le_of_not_gt hc))
      · have h0:k ≠ 0 := by intro he; simp [he,hb] at hy
        exact above k (Section5Revised.nonadjacent_natAbs h0 (by tauto) (by tauto)) hs
    intro i j hi hj hi1 hj1
    exact proposition41_published hPrior hAkhtari hCalculation P h hb hn hNs i j hi hj
      (hall i hi hi1) (hall j hj hj1)

end Parameters

/-- Theorem 1.4, faithful to Section 5 of manuscript 2026-11-06d. -/
theorem theorem14_revised (hPrior:Hypergeometric.DenominatorEstimate4)
    (hAkhtari:ExternalResults.AkhtariTheorem11) (hCalculation:Calculations.Section46Magma) :
    Theorem14 := by
  intro P h hb hn hNs
  have finish (htwo:AtMostSquareValues (P.y h.pell) 2) :
      AtMostSquareValues (P.y h.pell) 3 ∧ (¬P.Exceptional h.pell → AtMostSquareValues (P.y h.pell) 2) :=
    ⟨Section5Revised.two_implies_three htwo,fun _ => htwo⟩
  obtain ⟨K,hK⟩ := P.exists_negative_cutoff h hn
  by_cases hK1:K= -1
  swap
  · exact finish (P.lemma51_revised hPrior hAkhtari hCalculation h hb hn hNs hK (by have := hK.1; omega))
  subst K
  by_cases hN1:P.normAlpha= -1
  · apply finish
    apply Section5.atMost_two_of_unique (P.y_pos h hn)
    intro i j hi hj hi1 hj1
    exact P.section46_norm_minus_one hAkhtari h hb hN1 hi hj hi1 hj1
  by_cases hd:P.d ≤ 111
  · apply finish
    apply Section5.atMost_two_of_unique (P.y_pos h hn)
    intro i j hi hj hi1 hj1
    exact P.section46_small_published hAkhtari hCalculation h hb hn hNs hd hi hj hi1 hj1
  have hN4 : 4 ≤ -P.normAlpha := by
    rcases Int.even_or_odd P.normAlpha with he | ho
    · exact (P.lemma52_norm_lower_bounds hn hNs hN1).1 he
    · have := (P.lemma52_norm_lower_bounds hn hNs hN1).2 ho; omega
  exact P.section5_main_revised hPrior hAkhtari hCalculation h hb hn hNs hK (by omega) hN4

/-- Full ring-of-integers and arbitrary paper-sequence version of Theorem 1.4. -/
theorem theorem14_paper_revised (hPrior:Hypergeometric.DenominatorEstimate4)
    (hAkhtari:ExternalResults.AkhtariTheorem11) (hCalculation:Calculations.Section46Magma)
    (P:Parameters) (h:P.PaperAdmissible) (X Y:ℤ → ℚ) (hseq:P.PaperSequence X Y)
    (hb:P.b=1) (hn:P.normAlpha<0) (hNs:IsSquare (-P.normAlpha)) :
    AtMostSquareValues Y 3 ∧ (¬P.Exceptional h.toAdmissible.pell → AtMostSquareValues Y 2) := by
  obtain ⟨rfl,rfl⟩ := (P.paper_sequence_iff h X Y).mp hseq
  exact theorem14_revised hPrior hAkhtari hCalculation P h.toAdmissible hb hn hNs

end «JNT-2024»
