module

public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».RepresentationSupport
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»



































theorem normalizationGcd_sq_dvd (b r : ℤ) :
    (normalizationGcd b r : ℤ) ^ 2 ∣ 4 * b ^ 2 * r := by
  obtain ⟨k, hk⟩ := Int.gcd_dvd_left (2 * b * squareFactor r) r
  refine ⟨k ^ 2 * squarefreePart r, ?_⟩
  calc
    _ = (2 * b * squareFactor r) ^ 2 * squarefreePart r := by
      nth_rw 1 [← squareFactor_sq_mul r]
      ring
    _ = _ := by rw [hk]; unfold normalizationGcd; ring

namespace Parameters

































































































end Parameters
end «JNT-2024»
