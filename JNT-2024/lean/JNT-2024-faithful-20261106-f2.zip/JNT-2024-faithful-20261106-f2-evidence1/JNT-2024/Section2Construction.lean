module

public import «JNT-2024».ApproximationGcd
public import «JNT-2024».DenominatorContent
public import «JNT-2024».DenominatorDefinitions
public import «JNT-2024».HypergeometricDeterminant
public import «JNT-2024».HypergeometricPolynomials
public import «JNT-2024».RemainderConstruction
public import «JNT-2024».RemainderIdentity
public import «JNT-2024».Section2Complex
public import «JNT-2024».Section2Parameters
public import «JNT-2024».Section2Polynomial
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Section2

open Hypergeometric

noncomputable def rawScale (S u₁ u₂ : ℤ) (r : ℕ) : ℂ :=
  (denominator4 r : ℂ) / numeratorContent4 (Approximation.dPrimeInteger S u₁ u₂) r * A S u₁ u₂ ^ r

/-- The three uncorrected quantities in (2.5). -/
noncomputable def rawP (S u₁ u₂ : ℤ) (r : ℕ) : ℂ := rawScale S u₁ u₂ r * X (1 / 4) r (omega S u₁ u₂)
noncomputable def rawQ (S u₁ u₂ : ℤ) (r : ℕ) : ℂ := rawScale S u₁ u₂ r * Y (1 / 4) r (omega S u₁ u₂)
noncomputable def rawR (S u₁ u₂ : ℤ) (r : ℕ) : ℂ := rawScale S u₁ u₂ r * remainder (1 / 4) r (omega S u₁ u₂)

theorem rawScale_ne_zero {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) (r : ℕ) :
    rawScale S u₁ u₂ r ≠ 0 := by
  exact mul_ne_zero (div_ne_zero (by exact_mod_cast denominator4_ne_zero r)
    (by exact_mod_cast ne_of_gt (numeratorContent4_pos _ r))) (pow_ne_zero _ (A_ne_zero hS hu₂))

theorem A_mul_omega {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) :
    A S u₁ u₂ * omega S u₁ u₂ = star (A S u₁ u₂) := by
  have hg := g_ne_zero (u₁ := u₁) hS hu₂
  have hu := star_ne_zero.mpr (U_ne_zero (u₁ := u₁) hS hu₂)
  have he : star (A S u₁ u₂) = U S u₁ u₂ / (Approximation.g S u₁ u₂ : ℂ) := by
    simp [A]
  rw [he, A, omega]
  field_simp

theorem rawQ_eq_conj {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) (r : ℕ) :
    rawQ S u₁ u₂ r = star (rawP S u₁ u₂ r) := by
  have hw : omega S u₁ u₂ ≠ 0 := norm_ne_zero_iff.mp (by rw [omega_norm hS hu₂]; norm_num)
  rw [rawQ, Y_eq_reciprocal _ _ hw, Complex.inv_eq_conj (omega_norm hS hu₂)]
  simp only [rawP, rawScale, star_mul, star_div₀, star_pow, star_natCast, X_conj]
  have hh := congrArg (fun z : ℂ => z ^ r) (A_mul_omega (u₁ := u₁) hS hu₂)
  rw [mul_pow] at hh
  simp only [← Complex.star_def]
  linear_combination ((denominator4 r : ℂ) /
    numeratorContent4 (Approximation.dPrimeInteger S u₁ u₂) r *
      X (1 / 4) r (star (omega S u₁ u₂))) * hh

theorem rawP_integral {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) (r : ℕ) :
    IsIntegral ℤ (rawP S u₁ u₂ r) := by
  unfold rawP rawScale
  rw [omega_eq_one_add hS hu₂]
  exact scaled_X_integral (ne_of_lt (Approximation.dPrimeInteger_neg hS hu₂))
    (delta_sq hS hu₂) (A_ne_zero hS hu₂) (A_integral hS hu₂) r

theorem rawQ_integral {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) (r : ℕ) :
    IsIntegral ℤ (rawQ S u₁ u₂ r) := by
  rw [rawQ_eq_conj hS hu₂]
  exact (rawP_integral hS hu₂ r).map (starRingEnd ℂ).toIntAlgHom

/-- The error identity following (2.6), using the printed domain of Lemma 2.2(a). -/
theorem raw_error_identity {S u₁ u₂ : ℤ}
    (hnear : ‖omega S u₁ u₂ - 1‖ < 1) (r : ℕ) :
    rawQ S u₁ u₂ r * omega S u₁ u₂ ^ (1 / 4 : ℂ) - rawP S u₁ u₂ r = rawR S u₁ u₂ r := by
  have hh := lemma22a (ν := 1 / 4) (by norm_num) (by norm_num) r hnear
  rw [← remainder_eq_hypergeometric (1 / 4) r hnear] at hh
  norm_num only [Rat.cast_div, Rat.cast_one, Rat.cast_ofNat] at hh
  unfold rawQ rawP rawR
  linear_combination rawScale S u₁ u₂ r * hh

theorem raw_determinant_ne {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) (r : ℕ) :
    rawP S u₁ u₂ r * rawQ S u₁ u₂ (r + 1) ≠ rawP S u₁ u₂ (r + 1) * rawQ S u₁ u₂ r := by
  have hh := lemma22b (ν := 1 / 4) (by norm_num) (by norm_num) r
    (omega_norm (u₁ := u₁) hS hu₂) (omega_ne_one (u₁ := u₁) hS hu₂)
  intro he
  have hz : rawScale S u₁ u₂ r * rawScale S u₁ u₂ (r + 1) *
      (X (1 / 4) r (omega S u₁ u₂) * Y (1 / 4) (r + 1) (omega S u₁ u₂) -
        X (1 / 4) (r + 1) (omega S u₁ u₂) * Y (1 / 4) r (omega S u₁ u₂)) = 0 := by
    unfold rawP rawQ at he
    linear_combination he
  have hf := mul_ne_zero (rawScale_ne_zero (u₁ := u₁) hS hu₂ r)
    (rawScale_ne_zero (u₁ := u₁) hS hu₂ (r + 1))
  exact (sub_ne_zero.mpr hh) ((mul_eq_zero.mp hz).resolve_left hf)

end Section2
end «JNT-2024»
