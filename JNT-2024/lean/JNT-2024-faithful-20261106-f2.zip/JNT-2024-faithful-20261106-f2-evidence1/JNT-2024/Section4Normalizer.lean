module

public import «JNT-2024».NormalizerBounds
public import «JNT-2024».NormalizerFormula
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».Sequence
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

/-- The optimization stated immediately before (4.20), in cleared-denominator form. -/
theorem normalizer_optimization {N G B d : ℝ} (hN : 0 < N) (hG : 0 < G) (hB : 0 ≤ B)
    (hd : G + N ≤ d) (hBN : B ≤ 4 * N) (hBG : B ≤ 64 * G) :
    (17 : ℝ) ^ 4 * N ^ 2 * B ^ 2 ≤ 2 ^ 20 * d ^ 4 := by
  have hd0 : 0 < d := (add_pos hG hN).trans_le hd
  by_cases hn : N ≤ 16 * G
  · have hlin : 17 * N ≤ 16 * d := by linarith
    have hp := pow_le_pow_left₀ (by positivity : 0 ≤ 17 * N) hlin 4
    have hsq := pow_le_pow_left₀ hB hBN 2
    have hm := mul_le_mul_of_nonneg_left hsq (show 0 ≤ (17 : ℝ) ^ 4 * N ^ 2 by positivity)
    nlinarith only [hp, hm]
  · have hprod : 0 ≤ (N - 16 * G) * (16 * N - G) := by
      apply mul_nonneg <;> linarith
    have hs := pow_le_pow_left₀ (add_pos hG hN).le hd 2
    have hc : 289 * G * N ≤ 16 * d ^ 2 := by nlinarith only [hprod, hs]
    have hp := pow_le_pow_left₀ (by positivity : 0 ≤ 289 * G * N) hc 2
    have hsq := pow_le_pow_left₀ hB hBG 2
    have hm := mul_le_mul_of_nonneg_left hsq (show 0 ≤ (17 : ℝ) ^ 4 * N ^ 2 by positivity)
    nlinarith only [hp, hm]

end «JNT-2024».Section4

namespace «JNT-2024».Parameters


/-- The optimization before (4.20), for the actual index-independent normalizer. -/
theorem section4_normalizer_bound (P : Parameters) (h : P.Admissible) (hb : P.b = 1)
    (hn : P.normAlpha < 0) :
    (17 : ℝ) ^ 4 * |(P.normAlpha : ℝ)| ^ 2 * (P.normalizerSquare : ℝ) ^ 2 ≤
      2 ^ 20 * (P.d : ℝ) ^ 4 := by
  have hc : Int.gcd P.a P.b = 1 := by simp [hb]
  have hN : 0 < |(P.normAlpha : ℝ)| := abs_pos.mpr (by exact_mod_cast ne_of_lt hn)
  have hG : (0 : ℝ) < P.baseGcd := by exact_mod_cast P.baseGcd_pos (ne_of_gt h.a_pos)
  have hmul : P.baseGcd * P.normQuotient.natAbs = P.normAlpha.natAbs := by
    simpa only [Int.natAbs_mul, Int.natAbs_natCast] using congrArg Int.natAbs (P.normQuotient_mul hc)
  have hGle : (P.baseGcd : ℤ) ≤ P.a ^ 2 :=
    Int.le_of_dvd (sq_pos_of_pos h.a_pos) (Int.gcd_dvd_left _ _)
  have hGleR : (P.baseGcd : ℝ) ≤ (P.a : ℝ) ^ 2 := by exact_mod_cast hGle
  have hnorm : |(P.normAlpha : ℝ)| = (P.d : ℝ) - (P.a : ℝ) ^ 2 := by
    rw [abs_of_neg (by exact_mod_cast hn)]
    simp [normAlpha, hb]
  have hB16 : Nat.gcd 16 P.normQuotient.natAbs ≤ 16 := Nat.le_of_dvd (by decide) (Nat.gcd_dvd_left _ _)
  have hBT : Nat.gcd 16 P.normQuotient.natAbs ≤ P.normQuotient.natAbs :=
    Nat.le_of_dvd (Int.natAbs_pos.mpr (P.normQuotient_ne_zero hc (ne_of_lt hn))) (Nat.gcd_dvd_right _ _)
  have hBG : P.normalizerSquare ≤ 64 * P.baseGcd := by
    unfold normalizerSquare
    nlinarith
  have hBN : P.normalizerSquare ≤ 4 * P.normAlpha.natAbs := by
    unfold normalizerSquare
    nlinarith [Nat.mul_le_mul_left (4 * P.baseGcd) hBT]
  apply Section4.normalizer_optimization hN hG (Nat.cast_nonneg _)
  · linarith
  · have hh : (P.normalizerSquare : ℝ) ≤ 4 * (P.normAlpha.natAbs : ℝ) := by exact_mod_cast hBN
    simpa using hh
  · exact_mod_cast hBG

end «JNT-2024».Parameters
