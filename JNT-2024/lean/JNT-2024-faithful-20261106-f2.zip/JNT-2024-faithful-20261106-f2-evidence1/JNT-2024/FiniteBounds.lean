module

public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace FiniteBounds

def candidateNumerator (r u n : ℕ) (ν : ℤ) : ℕ :=
  ((r : ℤ) ^ 2 - (n : ℤ) * (u : ℤ) ^ 2 - 4 * ν).natAbs

def candidateA (r u n : ℕ) (ν : ℤ) : ℕ := candidateNumerator r u n ν / (2 * u * r)

def commonSquare (a d n : ℕ) : ℕ :=
  4 * Nat.gcd (a ^ 2) d * Nat.gcd 16 (n / Nat.gcd (a ^ 2) d)

def Check (r u n : ℕ) (ν : ℤ) : Prop :=
  let a := candidateA r u n ν
  let d := a ^ 2 + n
  let y := (r ^ 2 + n * u ^ 2) / 4
  let M := commonSquare a d n
  0 < r → 0 < u → 0 < n → 2 * u * r ∣ candidateNumerator r u n ν →
    4 ∣ r ^ 2 + n * u ^ 2 → 0 < a → 112 ≤ d → 1 < y →
      1832 ^ 2 * M * d * y ^ 2 > 11300 ^ 2 * n ^ 2 ∧
      2112 ^ 2 * d * y ^ 2 > 19000 ^ 2 * M

instance (r u n : ℕ) (ν : ℤ) : Decidable (Check r u n ν) := by
  unfold Check
  infer_instance

set_option maxRecDepth 100000 in
set_option maxHeartbeats 0 in
/-- The finite remainder of Lemma 3.13. Every entry is reduced and checked by
Lean's kernel; no external computation or native evaluation is trusted. -/
theorem certificate : ∀ r u : Fin 17, ∀ n : Fin (288 / u.val ^ 2 + 1),
    Check r.val u.val n.val 1 ∧ Check r.val u.val n.val (-1) := by decide

theorem bounded_check {r u n : ℕ} {ν : ℤ}
    (hr : r < 17) (hu : u < 17) (hu0 : 0 < u) (hbound : n * u ^ 2 ≤ 288)
    (hν : ν = 1 ∨ ν = -1) : Check r u n ν := by
  have hn : n < 288 / u ^ 2 + 1 := by
    have hh := (Nat.le_div_iff_mul_le (by positivity : 0 < u ^ 2)).mpr hbound
    omega
  have hh := certificate ⟨r, hr⟩ ⟨u, hu⟩ ⟨n, hn⟩
  rcases hν with rfl | rfl
  · exact hh.1
  · exact hh.2

end FiniteBounds
end «JNT-2024»
