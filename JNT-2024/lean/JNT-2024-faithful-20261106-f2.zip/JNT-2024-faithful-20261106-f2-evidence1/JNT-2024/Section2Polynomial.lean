module

public import «JNT-2024».DenominatorContent
public import «JNT-2024».DenominatorDefinitions
public import «JNT-2024».HypergeometricPolynomials
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

open Polynomial

theorem integralCoefficient4_cast_complex (r j : ℕ) :
    (integralCoefficient4 r j : ℂ) = (denominator4 r : ℂ) * (coefficient (1 / 4) r j : ℂ) := by
  exact_mod_cast integralCoefficient4_cast r j

theorem integralPolynomial4_eval_complex (r : ℕ) (z : ℂ) :
    (integralPolynomial4 r).eval₂ (Int.castRingHom ℂ) z = (denominator4 r : ℂ) * X (1 / 4) r z := by
  simp only [integralPolynomial4, X, Polynomial.eval₂_finsetSum, Polynomial.eval₂_monomial,
    Int.coe_castRingHom, integralCoefficient4_cast_complex, Finset.mul_sum, mul_assoc]

/-- The substituted polynomial divided by its exact numerator content. -/
noncomputable def contentPolynomial4 (d : ℤ) (r : ℕ) (δ : ℂ) : Polynomial ℂ :=
  C (numeratorContent4 d r : ℂ)⁻¹ *
    ((shiftedIntegralPolynomial4 r).map (Int.castRingHom ℂ)).comp (C δ * Polynomial.X)

theorem contentPolynomial4_coeff (d : ℤ) (r j : ℕ) (δ : ℂ) :
    (contentPolynomial4 d r δ).coeff j =
      ((shiftedIntegralPolynomial4 r).coeff j : ℂ) * δ ^ j / numeratorContent4 d r := by
  simp [contentPolynomial4, Polynomial.coeff_C_mul, Polynomial.comp_C_mul_X_coeff, div_eq_mul_inv]
  ring

theorem contentPolynomial4_degree (d : ℤ) (r : ℕ) (δ : ℂ) :
    (contentPolynomial4 d r δ).natDegree ≤ r := by
  apply (Polynomial.natDegree_C_mul_le _ _).trans
  apply Polynomial.natDegree_comp_le.trans
  calc
    _ ≤ r * 1 := Nat.mul_le_mul
      (Polynomial.natDegree_map_le.trans (shiftedIntegralPolynomial4_natDegree_le r))
      ((Polynomial.natDegree_C_mul_le _ _).trans (by simp))
    _ = r := Nat.mul_one r

theorem contentPolynomial4_eval (d : ℤ) (r : ℕ) (δ z : ℂ) :
    (contentPolynomial4 d r δ).eval z =
      (denominator4 r : ℂ) / numeratorContent4 d r * X (1 / 4) r (1 - δ * z) := by
  simp only [contentPolynomial4, Polynomial.eval_mul, Polynomial.eval_C,
    Polynomial.eval_comp, Polynomial.eval_X, Polynomial.eval_map,
    shiftedIntegralPolynomial4, Polynomial.eval₂_comp, Polynomial.eval₂_sub,
    Polynomial.eval₂_one, Polynomial.eval₂_X]
  rw [integralPolynomial4_eval_complex]
  ring

theorem root_power_parity {d : ℤ} {δ : ℂ} (hδ : δ ^ 2 = d) (j : ℕ) :
    δ ^ j = (d : ℂ) ^ (j / 2) * δ ^ (j % 2) := by
  conv_lhs => rw [show j = 2 * (j / 2) + j % 2 by omega, pow_add, pow_mul, hδ]

theorem squarefree_root_integral {d : ℤ} (hd : d ≠ 0) {δ : ℂ} (hδ : δ ^ 2 = d) :
    IsIntegral ℤ (δ / (squareFactor d : ℂ)) := by
  have hc : (squareFactor d : ℂ) ≠ 0 := by exact_mod_cast ne_of_gt (squareFactor_pos hd)
  have hs : (δ / (squareFactor d : ℂ)) ^ 2 = (squarefreePart d : ℂ) := by
    rw [div_pow, hδ]
    apply (div_eq_iff (pow_ne_zero _ hc)).mpr
    have hh := squareFactor_sq_mul d
    exact_mod_cast (by simpa only [mul_comm] using hh.symm)
  apply IsIntegral.of_pow (by decide : 0 < 2)
  rw [hs]
  exact isIntegral_intCast _

theorem contentPolynomial4_coeff_integral {d : ℤ} (hd : d ≠ 0) (r j : ℕ)
    {δ : ℂ} (hδ : δ ^ 2 = d) : IsIntegral ℤ ((contentPolynomial4 d r δ).coeff j) := by
  have hN : (numeratorContent4 d r : ℂ) ≠ 0 := by exact_mod_cast ne_of_gt (numeratorContent4_pos d r)
  have hc : (squareFactor d : ℂ) ≠ 0 := by exact_mod_cast ne_of_gt (squareFactor_pos hd)
  have hdiv := (numeratorContent4_dvd_iff d r (numeratorContent4 d r)).mp dvd_rfl j
  let n : ℤ := scaledIntegralCoefficient4 d r j / numeratorContent4 d r
  have hn : (scaledIntegralCoefficient4 d r j : ℂ) = (numeratorContent4 d r : ℂ) * n := by
    exact_mod_cast (Int.mul_ediv_cancel' hdiv).symm
  have he : (contentPolynomial4 d r δ).coeff j = (n : ℂ) * (δ / (squareFactor d : ℂ)) ^ (j % 2) := by
    rw [contentPolynomial4_coeff, root_power_parity hδ]
    have hw : ((shiftedIntegralPolynomial4 r).coeff j : ℂ) * (d : ℂ) ^ (j / 2) *
        (squareFactor d : ℂ) ^ (j % 2) = (numeratorContent4 d r : ℂ) * n := by
      simpa only [scaledIntegralCoefficient4, Int.cast_mul, Int.cast_pow] using hn
    rw [div_pow]
    apply (div_eq_iff hN).mpr
    field_simp
    linear_combination δ ^ (j % 2) * hw
  rw [he]
  exact (isIntegral_intCast n).mul ((squarefree_root_integral hd hδ).pow _)

theorem homogenized_eval_integral {r : ℕ} {F : Polynomial ℂ}
    (hdeg : F.natDegree ≤ r) (hF : ∀ j, IsIntegral ℤ (F.coeff j))
    {A : ℂ} (hA : A ≠ 0) (hAi : IsIntegral ℤ A) :
    IsIntegral ℤ (A ^ r * F.eval (-A⁻¹)) := by
  rw [Polynomial.eval_eq_sum_range' (by omega : F.natDegree < r + 1), Finset.mul_sum]
  apply IsIntegral.sum
  intro j hj
  have hjr : j ≤ r := by simpa using hj
  have he : A ^ r * (F.coeff j * (-A⁻¹) ^ j) =
      F.coeff j * (-1 : ℂ) ^ j * A ^ (r - j) := by
    rw [neg_eq_neg_one_mul, mul_pow, inv_pow, pow_sub₀ A hA hjr]
    ring
  rw [he]
  simpa only [Int.cast_neg, Int.cast_one] using
    ((hF j).mul ((isIntegral_intCast (-1)).pow j)).mul (hAi.pow (r - j))

/-- Homogenization proves the integrality claimed after (2.6), for the actual `D/N`. -/
theorem scaled_X_integral {d : ℤ} (hd : d ≠ 0) {δ A : ℂ}
    (hδ : δ ^ 2 = d) (hA : A ≠ 0) (hAi : IsIntegral ℤ A) (r : ℕ) :
    IsIntegral ℤ ((denominator4 r : ℂ) / numeratorContent4 d r * A ^ r *
      X (1 / 4) r (1 + δ / A)) := by
  have hh := homogenized_eval_integral (contentPolynomial4_degree d r δ)
    (fun j => contentPolynomial4_coeff_integral hd r j hδ) hA hAi
  rw [contentPolynomial4_eval] at hh
  rw [show 1 - δ * -A⁻¹ = 1 + δ / A by ring] at hh
  convert hh using 1
  ring

end Hypergeometric
end «JNT-2024»
