module

public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters


theorem not_parity_exception_of_even_squarefree (P : Parameters)
    (hS : (2 : ℤ) ∣ squarefreePart P.normAlpha) : ¬ (P.normAlpha % 4 = 1 ∧ 4 ∣ P.d) := by
  have hN : (2 : ℤ) ∣ P.normAlpha := dvd_trans hS (squarefreePart_dvd _)
  omega


end «JNT-2024».Parameters
