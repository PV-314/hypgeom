module

public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Tactic.Ring

@[expose] public section

/-! The determinant step in Lemma 2.1 (p. 5). This file proves only the
algebraic nonvanishing argument, not the analytic lower bounds of that lemma. -/

namespace «JNT-2024»

/-- If adjacent approximants are independent and `(p,q)` is nonzero, they
cannot both be proportional to `(p,q)`. The result holds in every domain. -/
theorem next_determinant_ne_zero {F : Type*} [CommRing F] [IsDomain F]
    (p q pr qr ps qs : F)
    (hpq : ¬ (p = 0 ∧ q = 0))
    (hindependent : pr * qs - ps * qr ≠ 0)
    (hcurrent : pr * q - qr * p = 0) : ps * q - qs * p ≠ 0 := by
  intro hnext
  have hq : q * (pr * qs - ps * qr) = 0 := calc
    q * (pr * qs - ps * qr) = qs * (pr * q - qr * p) - qr * (ps * q - qs * p) := by ring
    _ = 0 := by rw [hcurrent, hnext]; ring
  have hp : p * (pr * qs - ps * qr) = 0 := calc
    p * (pr * qs - ps * qr) = ps * (pr * q - qr * p) - pr * (ps * q - qs * p) := by ring
    _ = 0 := by rw [hcurrent, hnext]; ring
  exact hpq ⟨(mul_eq_zero.mp hp).resolve_right hindependent,
    (mul_eq_zero.mp hq).resolve_right hindependent⟩

end «JNT-2024»
