module

public import «JNT-2024».FiniteBounds
public import «JNT-2024».NormalizerBounds
public import «JNT-2024».NormalizerFormula
public import «JNT-2024».Sequence
public import «JNT-2024».SequenceRepresentations
public import «JNT-2024».SmallUnitBounds
public import «JNT-2024».SquarefreePart
public import «JNT-2024».UnitNumericalBounds
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Parameters

/-- Lemma 3.13 before taking square roots, with exact integer constants. -/
theorem lemma313_squared (P : Parameters) (h : P.Admissible) (hb : P.b = 1)
    (hn : P.normAlpha < 0) (hd : 112 ≤ P.d) {k Y : ℤ}
    (hy : P.y h.pell k = (Y : ℚ)) (hybig : 1 < Y) :
    (1832 : ℝ) ^ 2 * P.normalizerSquare * P.d * (Y : ℝ) ^ 2 >
      11300 ^ 2 * (P.normAlpha : ℝ) ^ 2 ∧
    (2112 : ℝ) ^ 2 * P.d * (Y : ℝ) ^ 2 > 19000 ^ 2 * P.normalizerSquare := by
  have hk : k ≠ 0 := by
    intro he
    rw [he, P.y_zero h.pell, hb] at hy
    have hh : (1 : ℤ) = Y := by exact_mod_cast hy
    omega
  obtain ⟨T, U, hU, hp, ht⟩ := P.sequence_unit_parameters h hk
  let a := P.a.toNat
  let d := P.d.toNat
  let n := (-P.normAlpha).toNat
  let y := Y.toNat
  have hae : P.a = (a : ℤ) := (Int.toNat_of_nonneg h.a_pos.le).symm
  have hde : P.d = (d : ℤ) := (Int.toNat_of_nonneg h.d_pos.le).symm
  have hne : P.normAlpha = -(n : ℤ) := by
    have hh := Int.toNat_of_nonneg (by omega : 0 ≤ -P.normAlpha)
    change (n : ℤ) = -P.normAlpha at hh
    omega
  have hye : Y = (y : ℤ) := (Int.toNat_of_nonneg (by omega : 0 ≤ Y)).symm
  have ha : 0 < a := by
    have hh := h.a_pos
    rw [hae] at hh
    exact_mod_cast hh
  have hn' : 0 < n := by rw [hne] at hn; exact_mod_cast (by omega : (0 : ℤ) < n)
  have hd' : 112 ≤ d := by rw [hde] at hd; exact_mod_cast hd
  have hy' : 1 < y := by rw [hye] at hybig; exact_mod_cast hybig
  have hdn : d = a ^ 2 + n := by
    have hh : (d : ℤ) = (a : ℤ) ^ 2 + n := by
      have hh := hne
      unfold normAlpha at hh
      rw [hae, hde, hb] at hh
      nlinarith only [hh]
    exact_mod_cast hh
  have hcoord : 4 * (y : ℤ) = (T + a * U) ^ 2 + (n : ℤ) * U ^ 2 := by
    have hm := congrArg QuadraticAlgebra.im ht
    change P.y h.pell k = _ at hm
    rw [hy] at hm
    have hq : (4 : ℚ) * Y = (T : ℚ) ^ 2 + P.d * (U : ℚ) ^ 2 + 2 * P.a * T * U := by
      simp [alpha, epsilon, pow_two, hb] at hm
      nlinarith only [hm]
    have hi : 4 * Y = T ^ 2 + P.d * U ^ 2 + 2 * P.a * T * U := by exact_mod_cast hq
    rw [hye, hae, hde] at hi
    have hdni : (d : ℤ) = (a : ℤ) ^ 2 + n := by exact_mod_cast hdn
    rw [hdni] at hi
    nlinarith only [hi]
  obtain ⟨ν, hν, hnorm⟩ : ∃ ν : ℤ, (ν = 1 ∨ ν = -1) ∧ T ^ 2 - (d : ℤ) * U ^ 2 = 4 * ν := by
    change T ^ 2 - P.d * U ^ 2 = 4 ∨ T ^ 2 - P.d * U ^ 2 = -4 at hp
    rw [hde] at hp
    rcases hp with hp | hp
    · exact ⟨1, Or.inl rfl, by simpa using hp⟩
    · exact ⟨-1, Or.inr rfl, by simpa using hp⟩
  have hh := FiniteBounds.unit_solution ha hd' hn' hdn hy' hU hν hnorm hcoord
  have hM := P.normalizerSquare_eq_commonSquare hb hae hde hne
  rw [hM, hde, hye, hne]
  push_cast
  rw [neg_sq]
  exact_mod_cast hh

/-- Both strict inequalities of Lemma 3.13, with all finite cases certified in Lean. -/
theorem lemma313 (P : Parameters) (h : P.Admissible) (hb : P.b = 1)
    (hn : P.normAlpha < 0) (hd : 112 ≤ P.d) {k X Y ν : ℤ}
    (hx : P.x h.pell k = (X : ℚ)) (hy : P.y h.pell k = (Y : ℚ))
    (hybig : 1 < Y) (hν : ν = 1 ∨ ν = -1) :
    let M := Approximation.normalizerProduct (squarefreePart P.normAlpha) (2 * X)
      (2 * ν * squareFactor P.normAlpha)
    (1832 / 10000 : ℝ) * M * Real.sqrt P.d * (P.y h.pell k : ℝ) / |(P.normAlpha : ℝ)| > 113 / 100 ∧
    (2112 / 100 : ℝ) * Real.sqrt P.d * (P.y h.pell k : ℝ) / M > 190 := by
  let M := Approximation.normalizerProduct (squarefreePart P.normAlpha) (2 * X)
    (2 * ν * squareFactor P.normAlpha)
  have hc : Int.gcd P.a P.b = 1 := by simp [hb]
  have hMe : M = Real.sqrt P.normalizerSquare := (P.lemma312 h hc hn hx hy hν).1
  have hMsq : M ^ 2 = (P.normalizerSquare : ℝ) := by rw [hMe, Real.sq_sqrt (by positivity)]
  have hM : 0 < M := by
    rw [hMe]
    apply Real.sqrt_pos.mpr
    exact_mod_cast (by have hh := (P.normalizerSquare_bounds h hc (ne_of_lt hn)).2.1; omega : 0 < P.normalizerSquare)
  have hdR : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hdS : Real.sqrt (P.d : ℝ) ^ 2 = P.d := Real.sq_sqrt hdR.le
  have hyR : (0 : ℝ) < Y := by exact_mod_cast (by omega : (0 : ℤ) < Y)
  have hN : 0 < |(P.normAlpha : ℝ)| := abs_pos.mpr (by exact_mod_cast ne_of_lt hn)
  have hbounds := P.lemma313_squared h hb hn hd hy hybig
  have hE : 11300 * |(P.normAlpha : ℝ)| < 1832 * (M * Real.sqrt P.d * Y) := by
    apply (sq_lt_sq₀ (by positivity) (by positivity)).mp
    have hs : (M * Real.sqrt P.d * (Y : ℝ)) ^ 2 = (P.normalizerSquare : ℝ) * P.d * (Y : ℝ) ^ 2 := by
      rw [mul_pow, mul_pow, hMsq, hdS]
    nlinarith only [hbounds.1, hs, sq_abs (P.normAlpha : ℝ)]
  have hQ : 19000 * M < 2112 * (Real.sqrt P.d * Y) := by
    apply (sq_lt_sq₀ (by positivity) (by positivity)).mp
    have hs : (Real.sqrt P.d * (Y : ℝ)) ^ 2 = P.d * (Y : ℝ) ^ 2 := by rw [mul_pow, hdS]
    nlinarith only [hbounds.2, hs, hMsq]
  change _ / |(P.normAlpha : ℝ)| > _ ∧ _ / M > _
  rw [hy]
  push_cast
  constructor
  · apply (lt_div_iff₀ hN).mpr
    nlinarith only [hE]
  · apply (lt_div_iff₀ hM).mpr
    nlinarith only [hQ]

end Parameters
end «JNT-2024»
