module

public import «JNT-2024».FourthRootGeometry
public import «JNT-2024».GammaBounds
public import «JNT-2024».HypergeometricPolynomials
public import «JNT-2024».HypergeometricUpperBound
public import «JNT-2024».RemainderCoefficients
public import «JNT-2024».Section2Bounds
public import «JNT-2024».Section4Approximation
public import «JNT-2024».UnitCircleGeometry
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

open Hypergeometric

/-- The two strict square-root chord comparisons in Section 4.3. -/
theorem square_root_chords {ω : ℂ} (hω : ‖ω‖ = 1) (hne : ω ≠ 1) :
    ‖1 + principalSquareRoot ω‖ < 2 ∧
      ‖ω-1‖/2 < ‖principalSquareRoot ω-1‖ := by
  let s := principalSquareRoot ω
  have hs : ‖s‖=1 := principalSquareRoot_norm ω
  have hs2 : s^2=ω := principalSquareRoot_sq hω
  have hsne : s ≠ 1 := by intro hh; apply hne; rw [← hs2,hh]; norm_num
  have hp : 0 < ‖s-1‖ := norm_pos_iff.mpr (sub_ne_zero.mpr hsne)
  have hpar := complex_parallelogram s 1
  rw [hs,norm_one] at hpar
  have hsum : ‖1+s‖ < 2 := by
    rw [add_comm]
    nlinarith [norm_nonneg (s+1),sq_pos_of_pos hp]
  have hid : ‖ω-1‖=‖s-1‖*‖1+s‖ := by
    rw [← norm_mul,← hs2]
    congr 1
    ring
  refine ⟨hsum,?_⟩
  rw [hid]
  have hh := mul_lt_mul_of_pos_left hsum hp
  linarith

/-- The displayed quotient identity and its strict lower bound preceding
(4.15). This retains the printed square-root step, not just the final bound. -/
theorem chord_power_quotient {ω : ℂ} (hω : ‖ω‖ = 1) (hne : ω ≠ 1)
    {r : ℕ} (hr : 1 ≤ r) :
    ‖ω-1‖^(2*r+1)/‖1+principalSquareRoot ω‖^(2*r) =
      ‖ω-1‖*‖principalSquareRoot ω-1‖^(2*r) ∧
    2*(‖ω-1‖/2)^(2*r+1) <
      ‖ω-1‖^(2*r+1)/‖1+principalSquareRoot ω‖^(2*r) := by
  have hδ : 0 < ‖ω-1‖ := norm_pos_iff.mpr (sub_ne_zero.mpr hne)
  have hid : ‖ω-1‖=‖principalSquareRoot ω-1‖*‖1+principalSquareRoot ω‖ := by
    rw [← norm_mul]
    congr 1
    calc
      ω-1 = principalSquareRoot ω^2-1 := by rw [principalSquareRoot_sq hω]
      _ = _ := by ring
  have hsum : ‖1+principalSquareRoot ω‖ ≠ 0 := by
    intro hh
    rw [hh,mul_zero] at hid
    linarith
  have he : ‖ω-1‖^(2*r+1)/‖1+principalSquareRoot ω‖^(2*r) =
      ‖ω-1‖*‖principalSquareRoot ω-1‖^(2*r) := by
    rw [pow_succ]
    nth_rw 1 [hid]
    rw [mul_pow]
    field_simp
  refine ⟨he,?_⟩
  rw [he]
  have hp := pow_lt_pow_left₀ (square_root_chords hω hne).2
    (by positivity) (by omega : 2*r ≠ 0)
  have hh := mul_lt_mul_of_pos_left hp hδ
  convert hh using 1
  rw [pow_succ]
  ring

/-- (4.13), (4.14), the printed chord comparison, and Lemma 2.3(b)
give the numerical error estimate with the published 1.072 constant. -/
theorem exact_error_printed {ω : ℂ} (hω : ‖ω‖=1) (hnear : ‖ω-1‖<1)
    (hne : ω ≠ 1) {r : ℕ} (hr : 1 ≤ r) (hY : Y (1/4) r ω ≠ 0) :
    (2915/10000 : ℝ)/(4^r*Real.sqrt r)*(‖ω-1‖/2)^(2*r+1) <
      ‖ω^(1/4 : ℂ)-X (1/4) r ω/Y (1/4) r ω‖ := by
  let G : ℝ := Section2.paperFactor*(gammaRatio r : ℝ)
  have hG : 0 < G := mul_pos (by norm_num [Section2.paperFactor])
    (by exact_mod_cast gammaRatio_pos r)
  have hC : 0 < (remainderCoefficient r : ℝ) := by exact_mod_cast remainderCoefficient_pos r
  have hδ : 0 < ‖ω-1‖ := norm_pos_iff.mpr (sub_ne_zero.mpr hne)
  have hYb : ‖Y (1/4) r ω‖ < G*‖1+principalSquareRoot ω‖^(2*r) := by
    have hh := (lemma22d (ν := 1/4) (by norm_num) (by norm_num) r hω hnear).2
    have h₁ : 1-((1/4 : ℚ) : ℝ)=3/4 := by norm_num
    have h₂ : (r : ℝ)+1-((1/4 : ℚ) : ℝ)=(r : ℝ)+3/4 := by norm_num; ring
    rw [h₁,h₂,← gammaRatio_eq_gamma] at hh
    exact hh
  have hden := (norm_pos_iff.mpr hY).trans hYb
  have hch := (chord_power_quotient hω hne hr).2
  have hmul := mul_lt_mul_of_pos_left hch (div_pos hC hG)
  have hratio := mul_lt_mul_of_pos_right (remainder_gamma_ratio_lower hr)
    (pow_pos (div_pos hδ (by norm_num : (0 : ℝ) < 2)) (2*r+1))
  have hfirst : (2915/10000 : ℝ)/(4^r*Real.sqrt r)*(‖ω-1‖/2)^(2*r+1) <
      (remainderCoefficient r : ℝ)*‖ω-1‖^(2*r+1)/(G*‖1+principalSquareRoot ω‖^(2*r)) := by
    have he : (2*(remainderCoefficient r : ℝ)/G)*(‖ω-1‖/2)^(2*r+1) =
      ((remainderCoefficient r : ℝ)/G)*(2*(‖ω-1‖/2)^(2*r+1)) := by ring
    change _ < (2*(remainderCoefficient r : ℝ)/G)*(‖ω-1‖/2)^(2*r+1) at hratio
    rw [he] at hratio
    convert hratio.trans hmul using 1
    ring
  have hdiv := div_le_div_of_nonneg_left (by positivity : 0 ≤ (remainderCoefficient r : ℝ)*‖ω-1‖^(2*r+1))
    (norm_pos_iff.mpr hY) hYb.le
  exact (hfirst.trans_le hdiv).trans_le (exact_approximant_error_lower hω hnear r hY)

end «JNT-2024».Section4
