module

public import «JNT-2024».GrowthBounds
public import «JNT-2024».Integrality
public import «JNT-2024».Lemma313AnalyticPublished
public import «JNT-2024».Lemma38
public import «JNT-2024».Lemma53
public import «JNT-2024».Monotonicity
public import «JNT-2024».NegativeCutoff
public import «JNT-2024».Section4Sequence
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.Deriv.MeanValue
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- The three printed steps of Lemma 5.3's cubic chain: gap, cubed seed bound
and exact cancellation of the squared norm. -/
theorem lemma53_cubic_chain (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha))
    (hK : P.IsNegativeCutoff h.pell (-1))
    (hm : IsIntegerSquare (P.y h.pell (-1))) (hp : IsIntegerSquare (P.y h.pell 1)) :
    let C := (5732/100:ℝ)*(P.d:ℝ)^2/|(P.normAlpha:ℝ)|^2
    C*(P.y h.pell (-1):ℝ)^3 < (P.y h.pell 1:ℝ) ∧
    C*(|(P.normAlpha:ℝ)| *(P.u:ℝ)^2/4)^3 ≤ C*(P.y h.pell (-1):ℝ)^3 ∧
    C*(|(P.normAlpha:ℝ)| *(P.u:ℝ)^2/4)^3 =
      (5732/100:ℝ)*(P.d:ℝ)^2*|(P.normAlpha:ℝ)| *(P.u:ℝ)^6/64 := by
  dsimp
  have hm1 : 1 < P.y h.pell (-1) := by simpa [hb] using hK.2.1
  have hN := (P.section4_norm_range h hb hn).1
  have hm' : IsSquare (P.y h.pell (-1)) := by
    obtain ⟨v,hv⟩ := hm; exact ⟨(v:ℚ),by simpa [pow_two] using hv⟩
  have hp' : IsSquare (P.y h.pell 1) := by
    obtain ⟨v,hv⟩ := hp; exact ⟨(v:ℚ),by simpa [pow_two] using hv⟩
  have hg := P.lemma38a h hn hNs (by decide : (-1:ℤ) ≠ 0) (by decide : (1:ℤ) ≠ 0)
    hm' hp' (by exact_mod_cast P.section5_adjacent_order h)
    (P.section4_gap_hypotheses h hb hn hm hm1).2
  rw [hb] at hg
  norm_num only [Int.cast_one,one_pow,one_mul] at hg
  have hseed := P.sequence_seed_bound_published h hb hn (k := -1) (by decide)
  have hcub := pow_le_pow_left₀
    (by positivity : (0:ℝ) ≤ |(P.normAlpha:ℝ)| *(P.u:ℝ)^2/4) hseed 3
  refine ⟨?_,?_,?_⟩
  · convert hg using 1; ring
  · exact mul_le_mul_of_nonneg_left hcub (by positivity)
  · field_simp [ne_of_gt hN]
    ring

theorem lemma53_cubic_lower (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha))
    (hK : P.IsNegativeCutoff h.pell (-1))
    (hm : IsIntegerSquare (P.y h.pell (-1))) (hp : IsIntegerSquare (P.y h.pell 1)) :
    (5732/100:ℝ)*(P.d:ℝ)^2*|(P.normAlpha:ℝ)| *(P.u:ℝ)^6/64 < (P.y h.pell 1:ℝ) := by
  obtain ⟨hgap,hseed,he⟩ := P.lemma53_cubic_chain h hb hn hNs hK hm hp
  rw [← he]
  exact hseed.trans_lt hgap


/-- The literal recurrence identity used to compare the negative tail to y1. -/
theorem lemma53_negative_identity (P : Parameters) (h : P.Pell) (hb : P.b=1) :
    P.y h (-2)-P.y h 1 =
      (((P.t:ℚ)^2+P.d*(P.u:ℚ)^2)/2+1)*(P.y h (-1)-1) := by
  have hr := P.y_recurrence h 0
  rw [P.y_zero,hb] at hr
  rw [P.y_neg_two,hb]
  norm_num only [zero_add,zero_sub,Int.cast_one,one_pow] at hr ⊢
  linarith

/-- Both monotone tails lie strictly above y1 when |k|>1, using the printed
recurrence identity for the negative tail. -/
theorem lemma53_tail_order (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hn : P.normAlpha < 0) (hK : P.IsNegativeCutoff h.pell (-1))
    {k : ℤ} (hk : 1 < k.natAbs) : P.y h.pell 1 < P.y h.pell k := by
  by_cases hkpos : 0 ≤ k
  · have he : (k.toNat:ℤ)=k := Int.toNat_of_nonneg hkpos
    have ht := P.y_strictMono_nonnegative h hn (show 1 < k.toNat by omega)
    simpa only [he,Nat.cast_one] using ht
  · have hm1 : 1 < P.y h.pell (-1) := by simpa [hb] using hK.2.1
    have he := P.lemma53_negative_identity h.pell hb
    have hc : 0 < P.traceCoeff+1 := by dsimp [traceCoeff]; linarith [P.three_le_trace h]
    have hsmall : P.y h.pell 1 < P.y h.pell (-2) := by
      have hh := mul_pos hc (sub_pos.mpr hm1)
      change 0 < (((P.t:ℚ)^2+P.d*(P.u:ℚ)^2)/2+1)*(P.y h.pell (-1)-1) at hh
      rw [← he] at hh
      linarith
    have hmono := (P.y_strictMono_negative_tail h hn (-1) hK).monotone (show 2 ≤ k.natAbs by omega)
    have hki := Int.eq_neg_natAbs_of_nonpos (show k ≤ 0 by omega)
    simp only [neg_add_cancel,zero_sub,Nat.cast_ofNat,← hki] at hmono
    exact hsmall.trans_le hmono


end «JNT-2024».Parameters

