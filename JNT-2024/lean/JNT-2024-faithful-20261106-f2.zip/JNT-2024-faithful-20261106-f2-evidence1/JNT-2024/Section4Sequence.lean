module

public import «JNT-2024».Integrality
public import «JNT-2024».Section4Prerequisites
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

theorem integer_square_ge_four {y : ℚ} (hs : IsIntegerSquare y) (hy : 1 < y) : (4 : ℚ) ≤ y := by
  obtain ⟨m, hm⟩ := hs
  have hm1 : (1 : ℤ) < m ^ 2 := by exact_mod_cast (by simpa only [hm] using hy : (1 : ℚ) < (m : ℚ) ^ 2)
  have hm4 : (4 : ℤ) ≤ m ^ 2 := by
    by_cases hlo : m ≤ -2
    · nlinarith
    by_cases hhi : 2 ≤ m
    · nlinarith
    have hm' : m = -1 ∨ m = 0 ∨ m = 1 := by omega
    rcases hm' with rfl | rfl | rfl <;> norm_num at hm1
  rw [hm]
  exact_mod_cast hm4

namespace Parameters

theorem section4_norm_range (P : Parameters) (h : P.Admissible) (hb : P.b = 1)
    (hn : P.normAlpha < 0) : 0 < |(P.normAlpha : ℝ)| ∧ |(P.normAlpha : ℝ)| < P.d := by
  have hnR : (P.normAlpha : ℝ) < 0 := by exact_mod_cast hn
  have ha : (0 : ℝ) < P.a := by exact_mod_cast h.a_pos
  rw [abs_of_neg hnR]
  constructor
  · linarith
  · have he : (P.normAlpha : ℝ) = (P.a : ℝ) ^ 2 - P.d := by simp [normAlpha, hb]
    nlinarith

/-- The `yₖ≥4` and gap-principle hypotheses at the start of Section 4.1. -/
theorem section4_gap_hypotheses (P : Parameters) (h : P.Admissible) (hb : P.b = 1)
    (hn : P.normAlpha < 0) {k : ℤ} (hs : IsIntegerSquare (P.y h.pell k))
    (hy : 1 < P.y h.pell k) : k ≠ 0 ∧
    max (4 * Real.sqrt (|(P.normAlpha : ℝ)| / P.d))
      ((P.b : ℝ) ^ 2 * |(P.normAlpha : ℝ)| / P.d) ≤ (P.y h.pell k : ℝ) := by
  have hy4 : (4 : ℝ) ≤ (P.y h.pell k : ℝ) := by exact_mod_cast integer_square_ge_four hs hy
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hrange := P.section4_norm_range h hb hn
  have hr : |(P.normAlpha : ℝ)| / P.d < 1 := (div_lt_one hd).mpr hrange.2
  have hroot : Real.sqrt (|(P.normAlpha : ℝ)| / P.d) < 1 := by
    have hsq := Real.sq_sqrt (div_nonneg hrange.1.le hd.le)
    nlinarith [Real.sqrt_nonneg (|(P.normAlpha : ℝ)| / P.d)]
  constructor
  · intro hk
    simp [hk, y_zero, hb] at hy
  · rw [hb]
    norm_num only [Int.cast_one, one_pow, one_mul]
    exact max_le (by linarith) (by linarith)

/-- Integer coordinates for every square term, before choosing the hypergeometric parameters. -/
theorem section4_integer_coordinates (P : Parameters) (hp : P.Pell) {k : ℤ}
    (hs : IsIntegerSquare (P.y hp k)) :
    ∃ X Y : ℤ, P.x hp k = (X : ℚ) ∧ P.y hp k = (Y : ℚ) ∧
      X ^ 2 - P.d * Y ^ 2 = P.normAlpha := by
  obtain ⟨v, hv⟩ := hs
  have hn := P.norm_identity hp k
  have hy : P.y hp k = ((v ^ 2 : ℤ) : ℚ) := by simpa using hv
  obtain ⟨X, hX⟩ := integer_root_of_two_mul_sq (P.x hp k) (by
    refine ⟨2 * (P.d * (v ^ 2) ^ 2 + P.normAlpha), ?_⟩
    rw [hy] at hn
    push_cast at hn ⊢
    nlinarith only [hn])
  refine ⟨X, v ^ 2, hX, hy, ?_⟩
  rw [hX, hy] at hn
  exact_mod_cast hn

/-- The norm-based coordinate estimates (4.3) and (4.4), for the original sequence. -/
theorem section4_coordinate_bounds (P : Parameters) (h : P.Admissible) (hb : P.b = 1)
    (hn : P.normAlpha < 0) {k : ℤ} (hs : IsIntegerSquare (P.y h.pell k))
    (hy : 1 < P.y h.pell k) :
    (15 / 16 : ℝ) * P.d * (P.y h.pell k : ℝ) ^ 2 < (P.x h.pell k : ℝ) ^ 2 ∧
      Real.sqrt P.d * (P.y h.pell k : ℝ) < (26 / 25 : ℝ) * |(P.x h.pell k : ℝ)| := by
  have hrange := P.section4_norm_range h hb hn
  apply Section4.coordinate_comparisons hrange.1 hrange.2
    (by exact_mod_cast integer_square_ge_four hs hy)
  have he : (P.x h.pell k : ℝ) ^ 2 - P.d * (P.y h.pell k : ℝ) ^ 2 = P.normAlpha := by
    exact_mod_cast P.norm_identity h.pell k
  rw [abs_of_neg (by exact_mod_cast hn)]
  linarith


end Parameters
end «JNT-2024»
