module

public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».PaperBridge
public import «JNT-2024».RealBounds
public import «JNT-2024».Sequence
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

/-!
The repeated-value remarks on page 3. The example retains the printed
restriction k >= 1. Its reflection identity for all integers and the signed
power formula for alpha/star(alpha) are stronger supporting lemmas only.
These results require no approximation estimate; DenominatorEstimate4
remains the explicit dependency of the existing approximation/counting results.
-/

open scoped NumberField

namespace «JNT-2024».Parameters

section CoordinateField

variable (P : Parameters) [Fact (¬ IsSquare P.d)]

theorem term_eq_step_zpow (hp : P.Pell) (k : ℤ) :
    P.term hp k = P.alpha * P.step ^ k := by
  simp [term, Units.val_zpow_eq_zpow_val, stepUnit]

omit [Fact (¬ IsSquare P.d)] in
theorem step_ne_zero (hp : P.Pell) : P.step ≠ 0 :=
  Units.ne_zero (P.stepUnit hp)

theorem star_step_eq_inv (hp : P.Pell) : star P.step = P.step⁻¹ := by
  have he : star P.step = P.backStep := by ext <;> simp [step,backStep]
  rw [he]
  exact eq_inv_of_mul_eq_one_right (P.step_mul_backStep hp)

theorem star_term_eq (hp : P.Pell) (k : ℤ) :
    star (P.term hp k) = star P.alpha * P.step ^ (-k) := by
  rw [P.term_eq_step_zpow, star_mul, star_zpow₀, P.star_step_eq_inv hp]
  simp [zpow_neg, mul_comm]

/-- The full algebraic terms never repeat; only their second coordinates can. -/
theorem term_injective (h : P.Admissible) : Function.Injective (P.term h.pell) := by
  have he : P.realEpsilon ≠ 1 := by
    intro he
    have hh : P.realEmbedding h.d_pos P.epsilon = P.realEmbedding h.d_pos 1 := by
      rw [map_one]
      change P.evalAt P.root (P.root_sq h) P.epsilon = 1
      rw [P.evalAt_epsilon]
      exact he
    have hi := congrArg QuadraticAlgebra.im ((P.realEmbedding_injective h.d_pos) hh)
    simp [epsilon,QuadraticAlgebra.im_one] at hi
    exact (ne_of_gt h.u_pos) hi
  intro i j hij
  have hx := congrArg QuadraticAlgebra.re hij
  have hy := congrArg QuadraticAlgebra.im hij
  have hh := P.coordinates_real_formula h.d_pos h.pell i
  have hj := P.coordinates_real_formula h.d_pos h.pell j
  change P.x h.pell i = P.x h.pell j at hx
  change P.y h.pell i = P.y h.pell j at hy
  rw [hx,hy,hj] at hh
  have hp := mul_left_cancel₀ (ne_of_gt (P.realAlpha_pos h)) hh.symm
  have hn := (zpow_right_injective₀ (P.realEpsilon_pos h) he) hp
  omega

/-- Repetition at distinct indices reverses the first coordinate. -/
theorem repeated_value_x_neg (h : P.Admissible) {i j : ℤ} (hij : i ≠ j)
    (hy : P.y h.pell i = P.y h.pell j) : P.x h.pell i = -P.x h.pell j := by
  have hi := P.norm_identity h.pell i
  have hj := P.norm_identity h.pell j
  rw [hy] at hi
  have hs : P.x h.pell i ^ 2 = P.x h.pell j ^ 2 := by linarith
  rcases sq_eq_sq_iff_eq_or_eq_neg.mp hs with hx | hx
  · exfalso
    apply hij (P.term_injective h ?_)
    exact QuadraticAlgebra.ext hx hy
  · exact hx

theorem repeated_value_term (h : P.Admissible) {i j : ℤ} (hij : i ≠ j)
    (hy : P.y h.pell i = P.y h.pell j) :
    P.term h.pell i = -star (P.term h.pell j) := by
  have hx := P.repeated_value_x_neg h hij hy
  apply QuadraticAlgebra.ext
  · simpa [x,y] using hx
  · simpa [y] using hy

/-- The explicit signed unit power behind the necessary condition on page 3. -/
theorem repeated_value_quotient (h : P.Admissible) {i j : ℤ} (hij : i ≠ j)
    (hy : P.y h.pell i = P.y h.pell j) :
    P.alpha / star P.alpha = -(P.step ^ (-(i+j))) := by
  have ha : P.alpha ≠ 0 := by
    intro hz
    have hh := congrArg QuadraticAlgebra.re hz
    have hp : (0 : ℚ) < P.a := by exact_mod_cast h.a_pos
    simp [alpha,ne_of_gt hp] at hh
  have hc : star P.alpha ≠ 0 := star_ne_zero.mpr ha
  have hs := P.step_ne_zero h.pell
  have he := P.repeated_value_term h hij hy
  rw [P.term_eq_step_zpow,P.star_term_eq] at he
  apply (div_eq_iff hc).mpr
  have hm := congrArg (fun z : P.Algebra => z * P.step ^ (-i)) he
  have hcanc : P.step ^ i * P.step ^ (-i) = 1 := by
    rw [← zpow_add₀ hs]; simp
  have hp : P.step ^ (-j) * P.step ^ (-i) = P.step ^ (-(i+j)) := by
    rw [← zpow_add₀ hs]; congr 1; ring
  calc
    P.alpha = (P.alpha * P.step ^ i) * P.step ^ (-i) := by rw [mul_assoc,hcanc,mul_one]
    _ = -(star P.alpha * P.step ^ (-j)) * P.step ^ (-i) := hm
    _ = -(P.step ^ (-(i+j))) * star P.alpha := by rw [neg_mul,mul_assoc,hp]; ring

theorem integer_unit_zpow_coe (v : (𝓞 P.Algebra)ˣ) (k : ℤ) :
    (((v^k : (𝓞 P.Algebra)ˣ) : 𝓞 P.Algebra) : P.Algebra) = ((v : 𝓞 P.Algebra) : P.Algebra)^k := by
  change ((Units.coeHom P.Algebra).comp (Units.map (algebraMap (𝓞 P.Algebra) P.Algebra))) (v^k) = _
  exact map_zpow _ v k

/-- The quotient is a unit of the full ring of integers, not just of the field. -/
theorem repeated_value_integer_unit (h : P.Admissible) {i j : ℤ} (hij : i ≠ j)
    (hy : P.y h.pell i = P.y h.pell j) :
    ∃ e : 𝓞 P.Algebra, (e : P.Algebra) = P.alpha / star P.alpha ∧ IsUnit e := by
  let v : (𝓞 P.Algebra)ˣ := -(P.epsilonIntegerUnit h.pell ^ 2) ^ (-(i+j))
  refine ⟨(v : 𝓞 P.Algebra), ?_, v.isUnit⟩
  rw [P.repeated_value_quotient h hij hy]
  change (((-(P.epsilonIntegerUnit h.pell ^ 2) ^ (-(i+j)) : (𝓞 P.Algebra)ˣ) : 𝓞 P.Algebra) : P.Algebra) = _
  simp only [Units.val_neg, map_neg]
  change -((((P.epsilonIntegerUnit h.pell ^ 2) ^ (-(i+j)) : (𝓞 P.Algebra)ˣ) : 𝓞 P.Algebra) : P.Algebra) = _
  have he : (((P.epsilonIntegerUnit h.pell ^ 2 : (𝓞 P.Algebra)ˣ) : 𝓞 P.Algebra) : P.Algebra) = P.step := by
    exact (congrArg Units.val (P.stepUnit_eq_integerUnit_sq h.pell)).symm
  rw [P.integer_unit_zpow_coe,he]

/-- A single reflected initial term gives the reflection at every integer index. -/
theorem y_reflection_of_term (hp : P.Pell) {m : ℤ}
    (hm : P.term hp m = -star P.alpha) (k : ℤ) : P.y hp (m-k) = P.y hp k := by
  have he : P.term hp (m-k) = -star (P.term hp k) := by
    rw [P.star_term_eq, P.term_eq_step_zpow, sub_eq_add_neg, zpow_add₀ (P.step_ne_zero hp)]
    rw [← mul_assoc, ← P.term_eq_step_zpow hp,hm]
    ring
  have hi := congrArg QuadraticAlgebra.im he
  simpa [y] using hi

end CoordinateField

/-- The algebraic conjugate of alpha in the literal real quadratic field. -/
noncomputable def alphaConjRealField (P : Parameters) : P.RealField :=
  ⟨P.realAlphaConj, sub_mem (intCast_mem _ _)
    (mul_mem (pow_mem (intCast_mem _ _) _) (IntermediateField.subset_adjoin ℚ _ (Set.mem_singleton _)))⟩

theorem realFieldEquiv_star_alpha (P : Parameters) [Fact (¬ IsSquare P.d)] (hd : 0 < P.d) :
    P.realFieldEquiv hd (star P.alpha) = P.alphaConjRealField := by
  apply Subtype.ext
  simp [realFieldEquiv_coe,alpha,alphaConjRealField,realAlphaConj]
  ring

/-- The printed necessary condition, for any coordinates satisfying (1.1). -/
theorem paper_repeated_value_unit (P : Parameters) (h : P.PaperAdmissible)
    {X Y : ℤ → ℚ} (hseq : P.PaperSequence X Y) {i j : ℤ} (hij : i ≠ j)
    (hy : Y i = Y j) :
    ∃ e : 𝓞 P.RealField, (e : P.RealField) = P.alphaRealField / P.alphaConjRealField ∧ IsUnit e := by
  let : Fact (¬ IsSquare P.d) := ⟨h.d_not_square⟩
  obtain ⟨_,rfl⟩ := (P.paper_sequence_iff h X Y).mp hseq
  obtain ⟨e,he,hu⟩ := P.repeated_value_integer_unit h.toAdmissible hij hy
  refine ⟨P.integersEquiv h.d_pos e,?_,hu.map (P.integersEquiv h.d_pos).toRingHom⟩
  change P.realFieldEquiv h.d_pos (e : P.Algebra) = _
  rw [he,map_div₀,P.realFieldEquiv_alpha,P.realFieldEquiv_star_alpha]

end «JNT-2024».Parameters

namespace «JNT-2024».Examples

/-- The repeated-value example in the remarks following Conjecture 1.3. -/
def repeated : Parameters := ⟨42,4,7,16,6⟩

theorem repeated_admissible : repeated.Admissible := by
  refine ⟨by decide,by decide,by decide,by decide,by decide,?_,Or.inl (by decide)⟩
  decide +kernel

/-- The published equality holds for every integer k, in particular for k>=1. -/
theorem repeated_reflection_all (k : ℤ) :
    repeated.y repeated_admissible.pell (-k) = repeated.y repeated_admissible.pell (k-1) := by
  let : Fact (¬ IsSquare repeated.d) := ⟨repeated_admissible.d_not_square⟩
  have hm : repeated.term repeated_admissible.pell (-1) = -star repeated.alpha := by
    have hh := repeated.term_sub_one repeated_admissible.pell 0
    norm_num [Parameters.term_zero,Parameters.alpha,Parameters.backStep,repeated] at hh ⊢
    exact hh
  have hh := repeated.y_reflection_of_term repeated_admissible.pell hm (k-1)
  convert hh using 1
  congr 1
  omega

theorem repeated_reflection {k : ℤ} (_hk : 1 ≤ k) :
    repeated.y repeated_admissible.pell (-k) = repeated.y repeated_admissible.pell (k-1) :=
  repeated_reflection_all k

end «JNT-2024».Examples
