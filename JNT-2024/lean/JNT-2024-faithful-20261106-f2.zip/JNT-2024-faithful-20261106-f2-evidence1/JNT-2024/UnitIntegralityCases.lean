module

public import «JNT-2024».Sequence
public import «JNT-2024».UnitParityPublished
public import «JNT-2024».UnitPowers
public import «JNT-2024».UnitSequenceIntegrality
public import «JNT-2024».UnitSequencePublished
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

theorem integerUnitRecurrence_even_iff_three (t ν a b : ℤ)
    (ht : Odd t) (hν : Odd ν) (ha : Even a) (hb : Odd b) (n : ℕ) :
    Even (integerUnitRecurrence t ν a b n) ↔ 3 ∣ n := by
  have hred := period_three_reduction
    (F := fun k => (integerUnitRecurrence t ν a b k : ZMod 2))
    (integerUnitRecurrence_mod_two_period_three t ν a b ht.intCast_zmod_two hν.intCast_zmod_two) n
  rw [← ZMod.intCast_eq_zero_iff_even, hred, Nat.dvd_iff_mod_eq_zero]
  have hm : n % 3 = 0 ∨ n % 3 = 1 ∨ n % 3 = 2 := by omega
  rcases hm with hm | hm | hm <;>
    simp [hm, integerUnitRecurrence, ht.intCast_zmod_two, hν.intCast_zmod_two,
      ha.intCast_zmod_two, hb.intCast_zmod_two]

theorem integerUnitRecurrence_even_iff_two (t ν a b : ℤ)
    (ht : Even t) (hν : Odd ν) (ha : Even a) (hb : Odd b) (n : ℕ) :
    Even (integerUnitRecurrence t ν a b n) ↔ 2 ∣ n := by
  have hred := period_two_reduction
    (F := fun k => (integerUnitRecurrence t ν a b k : ZMod 2))
    (integerUnitRecurrence_mod_two_period_two t ν a b ht.intCast_zmod_two hν.intCast_zmod_two) n
  rw [← ZMod.intCast_eq_zero_iff_even, hred, Nat.dvd_iff_mod_eq_zero]
  have hm : n % 2 = 0 ∨ n % 2 = 1 := by omega
  rcases hm with hm | hm <;> simp [hm, integerUnitRecurrence, ha.intCast_zmod_two, hb.intCast_zmod_two]

namespace Parameters

/-- Case (i): both coordinate sequences are integral. -/
theorem unit_integral_even_even (P : Parameters) (hp : P.Pell)
    (ht : Even P.t) (hu : Even P.u) (A B : ℤ) (n : ℕ) :
    (∃ X : ℤ, P.unitX A B n = (X : ℚ)) ∧ (∃ Y : ℤ, P.unitY A B n = (Y : ℚ)) :=
  P.unit_integral_of_initial_even hp A B
    ((ht.mul_left _).add (hu.mul_left _)) ((hu.mul_left _).add (ht.mul_left _)) n

/-- Case (ii-a): each coordinate is integral exactly at indices divisible by three. -/
theorem unit_integral_odd_odd_opposite (P : Parameters) (hp : P.Pell)
    (ht : Odd P.t) (hu : Odd P.u) (A B : ℤ)
    (hab : (Even A ∧ Odd B) ∨ (Odd A ∧ Even B)) (n : ℕ) :
    ((∃ X : ℤ, P.unitX A B n = (X : ℚ)) ↔ 3 ∣ n) ∧
    ((∃ Y : ℤ, P.unitY A B n = (Y : ℚ)) ↔ 3 ∣ n) := by
  have hd8 := P.unit_odd_odd_mod_eight hp ht hu
  have hd : Odd P.d := Int.odd_iff.mpr (by omega)
  have hX : Odd (A * P.t + B * P.d * P.u) := by
    rcases hab with ⟨ha,hb⟩ | ⟨ha,hb⟩
    · exact (ha.mul_right _).add_odd ((hb.mul hd).mul hu)
    · exact (ha.mul ht).add_even ((hb.mul_right _).mul_right _)
  have hY : Odd (A * P.u + B * P.t) := by
    rcases hab with ⟨ha,hb⟩ | ⟨ha,hb⟩
    · exact (ha.mul_right _).add_odd (hb.mul ht)
    · exact (ha.mul hu).add_even (hb.mul_right _)
  obtain ⟨ν, hνs, hν, _⟩ := P.unit_norm_integer_sign hp
  have hνo : Odd ν := by rcases hνs with rfl | rfl <;> decide
  obtain ⟨hx,hy⟩ := P.unit_doubled_coordinates hν A B n
  exact ⟨(rational_integral_iff_double_even hx).trans
      (integerUnitRecurrence_even_iff_three _ _ _ _ ht hνo (even_two_mul A) hX n),
    (rational_integral_iff_double_even hy).trans
      (integerUnitRecurrence_even_iff_three _ _ _ _ ht hνo (even_two_mul B) hY n)⟩

/-- Case (ii-b), after the initial coprime normalization: both a,b are odd. -/
theorem unit_integral_odd_odd_same (P : Parameters) (hp : P.Pell)
    (ht : Odd P.t) (hu : Odd P.u) (A B : ℤ) (ha : Odd A) (hb : Odd B) (n : ℕ) :
    (∃ X : ℤ, P.unitX A B n = (X : ℚ)) ∧ (∃ Y : ℤ, P.unitY A B n = (Y : ℚ)) := by
  have hd8 := P.unit_odd_odd_mod_eight hp ht hu
  have hd : Odd P.d := Int.odd_iff.mpr (by omega)
  exact P.unit_integral_of_initial_even hp A B
    ((ha.mul ht).add_odd ((hb.mul hd).mul hu)) ((ha.mul hu).add_odd (hb.mul ht)) n

/-- Case (iii): x is always integral; y is integral iff a or the index is even. -/
theorem unit_integral_even_odd (P : Parameters) (hp : P.Pell)
    (ht : Even P.t) (hu : Odd P.u) (A B : ℤ) (n : ℕ) :
    (∃ X : ℤ, P.unitX A B n = (X : ℚ)) ∧
    ((∃ Y : ℤ, P.unitY A B n = (Y : ℚ)) ↔ Even A ∨ Even n) := by
  have hd : Even P.d := even_iff_two_dvd.mpr
    ((by norm_num : (2 : ℤ) ∣ 4).trans (P.unit_even_odd_four_dvd hp ht hu))
  obtain ⟨ν,hνs,hν,_⟩ := P.unit_norm_integer_sign hp
  obtain ⟨hx,hy⟩ := P.unit_doubled_coordinates hν A B n
  have hX : Even (A * P.t + B * P.d * P.u) :=
    (ht.mul_left _).add ((hd.mul_left _).mul_right _)
  refine ⟨rational_integral_of_even_double hx
    (integerUnitRecurrence_even _ _ _ _ (even_two_mul A) hX n), ?_⟩
  rcases Int.even_or_odd A with ha | ha
  · have hY : Even (A * P.u + B * P.t) := (ha.mul_right _).add (ht.mul_left _)
    have hi := rational_integral_of_even_double hy
      (integerUnitRecurrence_even _ _ _ _ (even_two_mul B) hY n)
    exact ⟨fun _ => Or.inl ha, fun _ => hi⟩
  · have hY : Odd (A * P.u + B * P.t) := (ha.mul hu).add_even (ht.mul_left _)
    have hνo : Odd ν := by rcases hνs with rfl | rfl <;> decide
    have hi := (rational_integral_iff_double_even hy).trans
      (integerUnitRecurrence_even_iff_two _ _ _ _ ht hνo (even_two_mul B) hY n)
    have hnot : ¬ Even A := by
      intro he
      have h₀ := Int.even_iff.mp he
      have h₁ := Int.odd_iff.mp ha
      omega
    constructor
    · intro he
      exact Or.inr (even_iff_two_dvd.mpr (hi.mp he))
    · rintro (he | he)
      · exact (hnot he).elim
      · exact hi.mpr (even_iff_two_dvd.mp he)

end Parameters
end «JNT-2024»
