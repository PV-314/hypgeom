module

public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»


namespace Approximation

def g1 (u₁ u₂ : ℤ) : ℕ := Int.gcd u₁ u₂
def g2 (S u₁ u₂ : ℤ) : ℕ := Int.gcd (u₁ / (g1 u₁ u₂ : ℤ)) S
def g3 (S u₁ u₂ : ℤ) : ℕ :=
  if S % 4 = 1 ∧ Even ((u₁ - u₂) / (g1 u₁ u₂ : ℤ)) then 1
  else if S % 4 = 3 ∧ Even ((u₁ - u₂) / (g1 u₁ u₂ : ℤ)) then 2 else 4

noncomputable def g (S u₁ u₂ : ℤ) : ℝ := (g1 u₁ u₂ : ℝ) * Real.sqrt ((g2 S u₁ u₂ : ℝ) / g3 S u₁ u₂)
def gSquared (S u₁ u₂ : ℤ) : ℚ := (g1 u₁ u₂ : ℚ) ^ 2 * g2 S u₁ u₂ / g3 S u₁ u₂

theorem g3_cases (S u₁ u₂ : ℤ) : g3 S u₁ u₂ = 1 ∨ g3 S u₁ u₂ = 2 ∨ g3 S u₁ u₂ = 4 := by
  unfold g3
  split_ifs <;> simp

theorem g3_pos (S u₁ u₂ : ℤ) : 0 < g3 S u₁ u₂ := by
  rcases g3_cases S u₁ u₂ with hh | hh | hh <;> rw [hh] <;> decide


theorem g_sq (S u₁ u₂ : ℤ) : g S u₁ u₂ ^ 2 = (gSquared S u₁ u₂ : ℝ) := by
  have h₃ : (0 : ℝ) < g3 S u₁ u₂ := by exact_mod_cast g3_pos S u₁ u₂
  unfold g gSquared
  rw [mul_pow, Real.sq_sqrt (by positivity)]
  push_cast
  ring

theorem g1_unit (x c ν : ℤ) (hν : ν = 1 ∨ ν = -1) : g1 (2 * x) (2 * ν * c) = 2 * Int.gcd x c := by
  rcases hν with rfl | rfl <;> simp [g1, Int.gcd_mul_left]

theorem g2_unit (S x c ν : ℤ) (hν : ν = 1 ∨ ν = -1) :
    g2 S (2 * x) (2 * ν * c) = Int.gcd (x / (Int.gcd x c : ℤ)) S := by
  unfold g2
  rw [g1_unit x c ν hν]
  norm_num


end Approximation
end «JNT-2024»
