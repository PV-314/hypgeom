module

public import «JNT-2024».Integrality
public import «JNT-2024».Monotonicity
public import «JNT-2024».Positivity
public import «JNT-2024».Sequence
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- Geometric growth along an increasing positive recurrence. -/
theorem recurrence_geometric_lower (f : ℕ → ℚ) (c r A : ℚ)
    (hr : 0 ≤ r) (hrc : r ≤ c - 1) (hpos : ∀ n, 0 ≤ f n)
    (hmono : Monotone f) (hseed : A ≤ f 1)
    (hrec : ∀ n, f (n + 2) = c * f (n + 1) - f n) (n : ℕ) :
    A * r ^ n ≤ f (n + 1) := by
  induction n with
  | zero => simpa using hseed
  | succ n ih =>
    have hg : r * f (n + 1) ≤ f (n + 2) := by
      have hm := hmono (Nat.le_succ n)
      have hp := mul_nonneg (sub_nonneg.mpr hrc) (hpos (n + 1))
      nlinarith [hrec n]
    calc
      A * r ^ (n + 1) = r * (A * r ^ n) := by rw [pow_succ]; ring
      _ ≤ r * f (n + 1) := mul_le_mul_of_nonneg_left ih hr
      _ ≤ f (n + 2) := hg

namespace Parameters

/-- The common prefactor `|Nα|u²/(4b²)` in (3.13). -/
def lowerSeed (P : Parameters) : ℚ :=
  |(P.normAlpha : ℚ)| * (P.u : ℚ) ^ 2 / (4 * (P.b : ℚ) ^ 2)

def traceCoeff (P : Parameters) : ℚ := ((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) / 2

/-- The recurrence factor displayed in the proof of Lemma 3.5(c). -/
theorem traceCoeff_eq_du_sq_add_norm (P : Parameters) :
    P.traceCoeff = P.d * (P.u : ℚ) ^ 2 + 2 * P.epsilonNorm := by
  unfold traceCoeff epsilonNorm
  ring

/-- The universal lower bound stated after (3.13). -/
theorem five_le_du_sq (P : Parameters) (h : P.Admissible) : 5 ≤ P.d * P.u ^ 2 := by
  have hd := mul_pos h.d_pos (sq_pos_of_pos h.u_pos)
  have ht := h.t_pos
  rcases h.pell with hp | hp
  · have ht3 : 3 ≤ P.t := by nlinarith
    nlinarith
  · nlinarith

theorem lowerSeed_le_y_one (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) : P.lowerSeed ≤ P.y h.pell 1 := by
  have hb : 0 < (P.b : ℚ) ^ 2 := sq_pos_of_pos (by exact_mod_cast h.b_pos)
  have hN : (P.normAlpha : ℚ) < 0 := by exact_mod_cast hn
  unfold lowerSeed
  rw [abs_of_neg hN]
  apply (div_le_iff₀ (mul_pos (by norm_num) hb)).mpr
  nlinarith [P.complete_square_one h.pell,
    sq_nonneg ((P.b : ℚ) ^ 2 * P.t + P.a * P.u)]

theorem lowerSeed_le_y_neg_nat (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (n : ℕ) (hnpos : 1 ≤ n) :
    P.lowerSeed ≤ P.y h.pell (-(n : ℤ)) := by
  have hb : 0 < (P.b : ℚ) ^ 2 := sq_pos_of_pos (by exact_mod_cast h.b_pos)
  have hN : (P.normAlpha : ℚ) < 0 := by exact_mod_cast hn
  have hu : (0 : ℚ) < P.u := by exact_mod_cast h.u_pos
  have hv := P.epsilon_im_lower h n hnpos
  have hs : (P.u : ℚ) ^ 2 / 4 ≤ (P.epsilon ^ n).im ^ 2 := by nlinarith
  have hm := mul_nonneg (neg_nonneg.mpr (le_of_lt hN)) (sub_nonneg.mpr hs)
  unfold lowerSeed
  rw [abs_of_neg hN]
  apply (div_le_iff₀ (mul_pos (by norm_num) hb)).mpr
  nlinarith [P.complete_square_negative h.pell n,
    sq_nonneg ((P.b : ℚ) ^ 2 * (P.epsilon ^ n).re - P.a * (P.epsilon ^ n).im)]

/-- The uniform negative-index bound, including the indices between `K` and zero. -/
theorem lowerSeed_le_y_negative (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (k : ℤ) (hk : k < 0) : P.lowerSeed ≤ P.y h.pell k := by
  have hp : 1 ≤ k.natAbs := Int.natAbs_pos.mpr (ne_of_lt hk)
  simpa only [← Int.eq_neg_natAbs_of_nonpos (le_of_lt hk)] using P.lowerSeed_le_y_neg_nat h hn k.natAbs hp

/-- Both branches of (3.13), with a variable geometric factor.
`(K-k).toNat` is exactly `max(0,K-k)` viewed as a natural exponent. -/
def LowerBoundsAtRate (P : Parameters) (h : P.Pell) (K : ℤ) (r : ℚ) : Prop :=
  (∀ k : ℤ, 0 < k → P.lowerSeed * r ^ (k - 1).toNat ≤ P.y h k) ∧
  (∀ k : ℤ, k < 0 → P.lowerSeed * r ^ (K - k).toNat ≤ P.y h k)

theorem lowerBoundsAtRate (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (K : ℤ) (hK : P.IsNegativeCutoff h.pell K) (r : ℚ)
    (hr : 0 ≤ r) (hrc : r ≤ P.traceCoeff - 1) : P.LowerBoundsAtRate h.pell K r := by
  constructor
  · intro k hk
    have hbnd := recurrence_geometric_lower (fun n : ℕ => P.y h.pell n)
      P.traceCoeff r P.lowerSeed hr hrc (fun n => le_of_lt (P.y_pos h hn n))
      (P.y_strictMono_nonnegative h hn).monotone (P.lowerSeed_le_y_one h hn)
      (fun n => by
        simpa [traceCoeff, Nat.cast_add, Nat.cast_one, add_assoc] using
          P.y_recurrence h.pell ((n : ℤ) + 1)) (k - 1).toNat
    have hi : (((k - 1).toNat + 1 : ℕ) : ℤ) = k := by
      rw [Nat.cast_add, Nat.cast_one, Int.toNat_of_nonneg (by omega)]
      omega
    simpa only [hi] using hbnd
  · intro k hk
    by_cases hle : k ≤ K
    · have hbnd := recurrence_geometric_lower (fun n : ℕ => P.y h.pell (K + 1 - n))
        P.traceCoeff r P.lowerSeed hr hrc (fun n => le_of_lt (P.y_pos h hn _))
        (P.y_strictMono_negative_tail h hn K hK).monotone
        (by simpa using P.lowerSeed_le_y_negative h hn K hK.1)
        (fun n => by
          dsimp
          unfold traceCoeff
          convert P.y_reverse_recurrence h.pell (K + 1 - ((n : ℤ) + 1)) using 1 <;>
            congr 1 <;> ring_nf) (K - k).toNat
      have hi : K + 1 - (((K - k).toNat + 1 : ℕ) : ℤ) = k := by
        rw [Nat.cast_add, Nat.cast_one, Int.toNat_of_nonneg (by omega)]
        omega
      simpa only [hi] using hbnd
    · have hz : (K - k).toNat = 0 := Int.toNat_eq_zero.mpr (by omega)
      simpa [hz] using P.lowerSeed_le_y_negative h hn k hk

theorem basic_rate_le_trace (P : Parameters) (h : P.Admissible) :
    2 * P.d * (P.u : ℚ) ^ 2 / 5 ≤ P.traceCoeff - 1 := by
  have ht : (1 : ℚ) ≤ (P.t : ℚ) ^ 2 := by
    have hi : 1 ≤ P.t ^ 2 := by nlinarith [h.t_pos]
    exact_mod_cast hi
  have hd : (0 : ℚ) < P.d := by exact_mod_cast h.d_pos
  have hdu := mul_nonneg (le_of_lt hd) (sq_nonneg (P.u : ℚ))
  unfold traceCoeff
  rcases h.pell with hp | hp
  · have hq : (P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2 = 4 := by exact_mod_cast hp
    linarith
  · have hq : (P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2 = -4 := by exact_mod_cast hp
    linarith

/-- In the norm-minus-one case, the excluded triple is the only one below 8. -/
theorem eight_le_du_sq (P : Parameters) (h : P.Admissible)
    (hp : P.t ^ 2 - P.d * P.u ^ 2 = -4)
    (hex : ¬ (P.d = 5 ∧ P.t = 1 ∧ P.u = 1)) : 8 ≤ P.d * P.u ^ 2 := by
  by_cases ht : P.t = 1
  · have hprod : P.d * P.u ^ 2 = 5 := by rw [ht] at hp; norm_num at hp; omega
    have hd : 1 ≤ P.d := h.d_pos
    have hu : 1 ≤ P.u := h.u_pos
    have hub : P.u ≤ 2 := by nlinarith [mul_nonneg (sub_nonneg.mpr hd) (sq_nonneg P.u)]
    have huc : P.u = 1 ∨ P.u = 2 := by omega
    rcases huc with hu1 | hu2
    · have hd5 : P.d = 5 := by simpa [hu1] using hprod
      exact False.elim (hex ⟨hd5, ht, hu1⟩)
    · rw [hu2] at hprod; norm_num at hprod; omega
  · have ht2 : 2 ≤ P.t := by have := h.t_pos; omega
    nlinarith

theorem improved_rate_le_trace (P : Parameters) (h : P.Admissible)
    (hex : ¬ (P.d = 5 ∧ P.t = 1 ∧ P.u = 1)) :
    5 * P.d * (P.u : ℚ) ^ 2 / 8 ≤ P.traceCoeff - 1 := by
  have hd : (0 : ℚ) < P.d := by exact_mod_cast h.d_pos
  have hdu := mul_nonneg (le_of_lt hd) (sq_nonneg (P.u : ℚ))
  unfold traceCoeff
  rcases h.pell with hp | hp
  · have hq : (P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2 = 4 := by exact_mod_cast hp
    linarith
  · have hq : (P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2 = -4 := by exact_mod_cast hp
    have h8 : (8 : ℚ) ≤ P.d * (P.u : ℚ) ^ 2 := by exact_mod_cast P.eight_le_du_sq h hp hex
    linarith

/-- Lemma 3.5(c), equation (3.13), for every positive and negative index. -/
theorem lemma35c (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (K : ℤ) (hK : P.IsNegativeCutoff h.pell K) :
    P.LowerBoundsAtRate h.pell K (2 * P.d * (P.u : ℚ) ^ 2 / 5) := by
  apply P.lowerBoundsAtRate h hn K hK _ ?_ (P.basic_rate_le_trace h)
  exact div_nonneg (mul_nonneg (mul_nonneg (by norm_num)
    (by exact_mod_cast (le_of_lt h.d_pos))) (sq_nonneg _)) (by norm_num)

/-- The improvement to `5du²/8` outside the triple `(5,1,1)`. -/
theorem lemma35c_improved (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (K : ℤ) (hK : P.IsNegativeCutoff h.pell K)
    (hex : ¬ (P.d = 5 ∧ P.t = 1 ∧ P.u = 1)) :
    P.LowerBoundsAtRate h.pell K (5 * P.d * (P.u : ℚ) ^ 2 / 8) := by
  apply P.lowerBoundsAtRate h hn K hK _ ?_ (P.improved_rate_le_trace h hex)
  exact div_nonneg (mul_nonneg (mul_nonneg (by norm_num)
    (by exact_mod_cast (le_of_lt h.d_pos))) (sq_nonneg _)) (by norm_num)

/-- The improvement to `du²` when the unit has norm plus one. -/
theorem lemma35c_norm_one (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (K : ℤ) (hK : P.IsNegativeCutoff h.pell K)
    (hp : QuadraticAlgebra.norm P.epsilon = 1) :
    P.LowerBoundsAtRate h.pell K (P.d * (P.u : ℚ) ^ 2) := by
  rw [P.norm_epsilon] at hp
  have he := P.epsilonNorm_eq_one_iff.mp hp
  apply P.lowerBoundsAtRate h hn K hK _ ?_ ?_
  · exact mul_nonneg (by exact_mod_cast (le_of_lt h.d_pos)) (sq_nonneg _)
  · have hq : (P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2 = 4 := by exact_mod_cast he
    unfold traceCoeff
    linarith

end Parameters
end «JNT-2024»
