module

public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».RepresentationBounds
public import «JNT-2024».RepresentationDivisibility
public import «JNT-2024».RepresentationFactors
public import «JNT-2024».RepresentationLemma33Published
public import «JNT-2024».RepresentationNormalization
public import «JNT-2024».RepresentationNormalizationPublished
public import «JNT-2024».RepresentationSupport
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- The set I' on p. 14; swapping the valuations gives I''. -/
def smallerValuationPrimes (n : ℕ) (v w : ℕ → ℤ) : Finset ℕ :=
  n.primeFactors.filter fun p => v p < w p

/-- The set I''' on p. 14. -/
def equalValuationPrimes (n : ℕ) (v w : ℕ → ℤ) : Finset ℕ :=
  n.primeFactors.filter fun p => v p = w p

/-- The three printed sets are pairwise disjoint and exhaust the prime divisors. -/
theorem valuation_prime_partition (n : ℕ) (v w : ℕ → ℤ) :
    Disjoint (smallerValuationPrimes n v w) (smallerValuationPrimes n w v) ∧
    Disjoint (smallerValuationPrimes n v w) (equalValuationPrimes n v w) ∧
    Disjoint (smallerValuationPrimes n w v) (equalValuationPrimes n v w) ∧
    smallerValuationPrimes n v w ∪ smallerValuationPrimes n w v ∪
      equalValuationPrimes n v w = n.primeFactors := by
  simp only [smallerValuationPrimes, equalValuationPrimes, Finset.disjoint_left,
    Finset.mem_filter, Finset.ext_iff, Finset.mem_union]
  constructor
  · intro p hp hq
    omega
  constructor
  · intro p hp hq
    omega
  constructor
  · intro p hp hq
    omega
  · intro p
    constructor
    · tauto
    · intro hp
      rcases lt_trichotomy (v p) (w p) with h | h | h
      · exact Or.inl (Or.inl ⟨hp, h⟩)
      · exact Or.inr ⟨hp, h⟩
      · exact Or.inl (Or.inr ⟨hp, h⟩)

/-- The printed identity d'd''d''' = sf(|N_alpha|), in general squarefree form. -/
theorem valuation_prime_products {n : ℕ} (hn : Squarefree n) (v w : ℕ → ℤ) :
    (∏ p ∈ smallerValuationPrimes n v w, p) *
      (∏ p ∈ smallerValuationPrimes n w v, p) *
      (∏ p ∈ equalValuationPrimes n v w, p) = n := by
  obtain ⟨h12, h13, h23, hu⟩ := valuation_prime_partition n v w
  rw [← Finset.prod_union h12, ← Finset.prod_union (Finset.disjoint_union_left.mpr ⟨h13,h23⟩),
    hu, Nat.prod_primeFactors_of_squarefree hn]

theorem smaller_valuation_product_pos (n : ℕ) (v w : ℕ → ℤ) :
    0 < ∏ p ∈ smallerValuationPrimes n v w, p := by
  apply Finset.prod_pos
  intro p hp
  exact Nat.pos_of_mem_primeFactors (Finset.mem_filter.mp hp).1

theorem equal_valuation_product_pos (n : ℕ) (v w : ℕ → ℤ) :
    0 < ∏ p ∈ equalValuationPrimes n v w, p := by
  apply Finset.prod_pos
  intro p hp
  exact Nat.pos_of_mem_primeFactors (Finset.mem_filter.mp hp).1

/-- The exact quotient used for f' is the smaller of d' and d''. -/
theorem partition_factor_formula {a b c n : ℕ} (ha : 0 < a) (hb : 0 < b) (hc : 0 < c)
    (he : a * b * c = n) : n / max (a * c) (b * c) = min a b := by
  rcases le_total a b with hab | hba
  · rw [max_eq_right (Nat.mul_le_mul_right c hab), min_eq_left hab, ← he, mul_assoc]
    exact Nat.mul_div_cancel _ (Nat.mul_pos hb hc)
  · rw [max_eq_left (Nat.mul_le_mul_right c hba), min_eq_right hba, ← he]
    have hh : a * b * c = b * (a * c) := by ring
    rw [hh]
    exact Nat.mul_div_cancel _ (Nat.mul_pos ha hc)

/-- The strict bound for exactly the factor printed on p. 14. -/
theorem partition_factor_small {a b c n : ℕ} (ha : 0 < a) (hb : 0 < b)
    (hc : 0 < c) (hn : Squarefree n) (he : a * b * c = n) :
    ((n / max (a * c) (b * c) : ℕ) : ℝ) < max 2 (Real.sqrt n) := by
  rw [partition_factor_formula ha hb hc he]
  have hd : a * b ∣ n := ⟨c, he.symm⟩
  have hcop := Nat.coprime_of_squarefree_mul (hn.squarefree_of_dvd hd)
  exact small_coprime_factor ha hb (Nat.pos_of_ne_zero hn.ne_zero) hcop hd

/-- Lemma 3.3(b) makes the selected valuation nonpositive on I' union I'''
(or on I'' union I''' after exchanging the candidates). -/
theorem partition_selected_nonpositive {n : ℕ} {v w : ℕ → ℤ}
    (h : ∀ p ∈ n.primeFactors, min (v p) (w p) ≤ 0) {p : ℕ}
    (hp : p ∈ smallerValuationPrimes n v w ∪ equalValuationPrimes n v w) : v p ≤ 0 := by
  simp only [Finset.mem_union, smallerValuationPrimes, equalValuationPrimes,
    Finset.mem_filter] at hp
  rcases hp with ⟨hp, he⟩ | ⟨hp, he⟩
  · have hh := h p hp
    omega
  · have hh := h p hp
    omega

/-- Positive valuation can survive only in the opposite strict-inequality set. -/
theorem partition_positive_support {n : ℕ} {v w : ℕ → ℤ}
    (h : ∀ p ∈ n.primeFactors, min (v p) (w p) ≤ 0) {p : ℕ}
    (hp : p ∈ n.primeFactors) (hv : 0 < v p) :
    p ∣ ∏ q ∈ smallerValuationPrimes n w v, q := by
  have hh := h p hp
  have hw : w p < v p := by omega
  exact Finset.dvd_prod_of_mem (fun q : ℕ => q) (Finset.mem_filter.mpr ⟨hp, hw⟩)

/-- The displayed chain after deleting a squarefree prime on p. 14.
The nonpositive first term is supplied by the selected partition classes. -/
theorem partition_removed_prime_chain {S : ℤ} (hS : Squarefree S)
    (p : ℕ) [hp : Fact p.Prime] (hpS : (p : ℤ) ∣ S) (G v : ℤ) (hv : v ≤ 0) :
    v ≤ 0 ∧ 0 ≤ (padicValInt p (S / p) : ℤ) ∧
      (padicValInt p (S / p) : ℤ) ≤
        padicValInt p (UniqueFactorizationMonoid.radical ((S / p) * G)) := by
  have hnot : ¬ (p : ℤ) ∣ S / p := by
    intro hh
    obtain ⟨k, hk⟩ := hh
    have he := Int.ediv_mul_cancel hpS
    apply (Int.squarefree_iff_prime_sq_not_dvd.mp hS p hp.out)
    refine ⟨k, ?_⟩
    rw [hk] at he
    nlinarith only [he]
  have hz : padicValInt p (S / p) = 0 := padicValInt.eq_zero_of_not_dvd hnot
  rw [hz]
  exact ⟨hv, by norm_num, by positivity⟩

namespace Parameters

/-- The radical identity displayed before the prime partition on p. 14. -/
theorem representation_radical_factorization (P : Parameters) (ν : ℤ) :
    P.representationRadical ν = UniqueFactorizationMonoid.radical
      (squarefreePart P.normAlpha * (P.sharpGcd ν : ℤ)) := by
  unfold representationRadical sharpGcd
  rw [P.norm_quotient_mul, Int.gcd_mul_right, Nat.cast_mul, Int.natCast_natAbs]
  rcases le_or_gt 0 (squarefreePart P.normAlpha) with hs | hs
  · rw [abs_of_nonneg hs, mul_comm]
  · rw [abs_of_neg hs, mul_neg, UniqueFactorizationDomain.radical_neg, mul_comm]

/-- The sharp bound obtained from the restored Lemma 3.3(a), its printed
radical factorization, and deletion of the primes removed by the partition. -/
theorem candidate_valuation_le_sharpRadical_published (P : Parameters) {x y ν σ : ℤ} {e : ℕ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0)
    (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν) (hσ : σ = 1 ∨ σ = -1) (he : 0 < e)
    (hcover : ∀ p : ℕ, p.Prime → (p : ℤ) ∣ squarefreePart P.normAlpha →
      0 < padicValRat p (normalizationQuotient P.b (P.repCandidate y σ)) → p ∣ e)
    (p : ℕ) [hp : Fact p.Prime] :
    padicValRat p (normalizationQuotient P.b (P.repCandidate y σ)) ≤
      padicValInt p (P.sharpRadical ν e) := by
  have hm := P.lemma33a_published h hb hu hN hν p
  have hv : padicValRat p (normalizationQuotient P.b (P.repCandidate y σ)) ≤
      padicValInt p (P.representationRadical ν) := by
    rcases hσ with rfl | rfl
    · exact (le_max_left _ _).trans hm
    · exact (le_max_right _ _).trans hm
  have hone := valuation_squarefree_le_one p (UniqueFactorizationMonoid.squarefree_radical
    (a := (Int.gcd (P.u * P.normAlpha) (ν * squarefreePart P.normAlpha) : ℤ)))
  change padicValInt p (P.representationRadical ν) ≤ 1 at hone
  by_cases hq : 0 < padicValRat p (normalizationQuotient P.b (P.repCandidate y σ))
  · have hpos : 0 < padicValInt p (P.representationRadical ν) := by omega
    have hdiv : (p : ℤ) ∣ P.representationRadical ν :=
      (prime_dvd_iff_valuation_pos p UniqueFactorizationMonoid.radical_ne_zero).mpr hpos
    rw [P.representation_radical_factorization ν] at hdiv
    have hpI : Prime (p : ℤ) := Nat.prime_iff_prime_int.mp hp.out
    have hG : (P.sharpGcd ν : ℤ) ≠ 0 := by exact_mod_cast ne_of_gt (P.sharpGcd_pos ν hu hN)
    have hsupport := (UniqueFactorizationMonoid.dvd_radical_iff_of_irreducible hpI.irreducible
      (mul_ne_zero (squarefreePart_ne_zero _) hG)).mp hdiv
    have hd : (p : ℤ) ∣ (e : ℤ) * (P.sharpGcd ν : ℤ) := by
      rcases hpI.dvd_mul.mp hsupport with hpS | hpG
      · exact dvd_mul_of_dvd_left (by exact_mod_cast hcover p hp.out hpS hq) _
      · exact dvd_mul_of_dvd_right hpG _
    have hz : (e : ℤ) * (P.sharpGcd ν : ℤ) ≠ 0 :=
      mul_ne_zero (by exact_mod_cast ne_of_gt he) hG
    have hrad := valuation_radical_pos_of_dvd p hz hd
    change _ ≤ (padicValInt p (UniqueFactorizationMonoid.radical _) : ℤ)
    omega
  · have hn : padicValRat p (normalizationQuotient P.b (P.repCandidate y σ)) ≤ 0 := by omega
    by_cases hpS : (p : ℤ) ∣ squarefreePart P.normAlpha
    · have hchain := partition_removed_prime_chain (squarefreePart_squarefree P.normAlpha)
        p hpS (P.sharpGcd ν : ℤ) _ hn
      exact hchain.1.trans (by positivity)
    · exact hn.trans (by positivity)

/-- Valuations of the two quotients r1/g1^2 used in the printed partition. -/
noncomputable def candidateValuation (P : Parameters) (y σ : ℤ) (p : ℕ) : ℤ :=
  padicValRat p (normalizationQuotient P.b (P.repCandidate y σ))

/-- The printed products d', d'', d''', in that order. -/
noncomputable def candidatePrimeProducts (P : Parameters) (y : ℤ) : ℕ × ℕ × ℕ :=
  let n := (squarefreePart P.normAlpha).natAbs
  let v := P.candidateValuation y 1
  let w := P.candidateValuation y (-1)
  (∏ p ∈ smallerValuationPrimes n v w, p,
   ∏ p ∈ smallerValuationPrimes n w v, p,
   ∏ p ∈ equalValuationPrimes n v w, p)

/-- The product identity with exactly the paper's sf(|N_alpha|). -/
theorem candidate_prime_products_paper (P : Parameters) (y : ℤ) (hN : P.normAlpha ≠ 0) :
    let d := P.candidatePrimeProducts y
    ((d.1 * d.2.1 * d.2.2 : ℕ) : ℤ) = squarefreePart |P.normAlpha| := by
  have he := valuation_prime_products
    (Int.squarefree_natAbs.mpr (squarefreePart_squarefree P.normAlpha))
    (P.candidateValuation y 1) (P.candidateValuation y (-1))
  change ((P.candidatePrimeProducts y).1 * (P.candidatePrimeProducts y).2.1 *
    (P.candidatePrimeProducts y).2.2 : ℕ) = (squarefreePart P.normAlpha).natAbs at he
  dsimp only
  rw [squarefreePart_abs hN, ← Int.natCast_natAbs, he]

/-- The exact comparison prescribed on p. 14, including its tie convention. -/
noncomputable def publishedCandidateSign (P : Parameters) (y : ℤ) : ℤ :=
  if (P.candidatePrimeProducts y).2.1 < (P.candidatePrimeProducts y).1 then 1 else -1

/-- The literal printed formula for f'. -/
noncomputable def publishedSmallFactor (P : Parameters) (y : ℤ) : ℕ :=
  let d := P.candidatePrimeProducts y
  (squarefreePart P.normAlpha).natAbs / max (d.1 * d.2.2) (d.2.1 * d.2.2)

/-- The manuscript's exact candidate choice has the stated positive small
factor, and that factor contains every surviving squarefree-norm prime. -/
theorem published_candidate_selection (P : Parameters) {x y : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0) :
    (P.publishedCandidateSign y = 1 ∨ P.publishedCandidateSign y = -1) ∧
    (P.publishedSmallFactor y : ℤ) ∣ squarefreePart P.normAlpha ∧
    0 < P.publishedSmallFactor y ∧
    (P.publishedSmallFactor y : ℝ) < max 2 (Real.sqrt |(squarefreePart P.normAlpha : ℝ)|) ∧
    ∀ p : ℕ, p.Prime → (p : ℤ) ∣ squarefreePart P.normAlpha →
      0 < P.candidateValuation y (P.publishedCandidateSign y) p →
        p ∣ P.publishedSmallFactor y := by
  let n := (squarefreePart P.normAlpha).natAbs
  let v := P.candidateValuation y 1
  let w := P.candidateValuation y (-1)
  let a := ∏ p ∈ smallerValuationPrimes n v w, p
  let b := ∏ p ∈ smallerValuationPrimes n w v, p
  let c := ∏ p ∈ equalValuationPrimes n v w, p
  have hn : Squarefree n := Int.squarefree_natAbs.mpr (squarefreePart_squarefree _)
  have ha : 0 < a := smaller_valuation_product_pos n v w
  have hb' : 0 < b := smaller_valuation_product_pos n w v
  have hc : 0 < c := equal_valuation_product_pos n v w
  have he : a * b * c = n := valuation_prime_products hn v w
  have hf : P.publishedSmallFactor y = min a b := partition_factor_formula ha hb' hc he
  have hsign : P.publishedCandidateSign y = if b < a then 1 else -1 := rfl
  have hmin : ∀ p ∈ n.primeFactors, min (v p) (w p) ≤ 0 := by
    intro p hp
    have hprime := Nat.prime_of_mem_primeFactors hp
    let : Fact p.Prime := ⟨hprime⟩
    apply P.lemma33b h hb hu hN p
    apply (prime_dvd_iff_valuation_pos p (squarefreePart_ne_zero _)).mp
    exact Int.natCast_dvd.mpr (Nat.dvd_of_mem_primeFactors hp)
  have hd : min a b ∣ n := by
    rcases le_total a b with hab | hba
    · rw [min_eq_left hab, ← he]
      exact dvd_mul_of_dvd_left (dvd_mul_right a b) c
    · rw [min_eq_right hba, ← he]
      exact dvd_mul_of_dvd_left (dvd_mul_left b a) c
  refine ⟨?_, ?_, ?_, ?_, ?_⟩
  · rw [hsign]
    split <;> simp
  · rw [hf]
    exact Int.natCast_dvd.mpr hd
  · rw [hf]
    exact lt_min ha hb'
  · have hh := partition_factor_small ha hb' hc hn he
    change (P.publishedSmallFactor y : ℝ) < max 2 (Real.sqrt (n : ℝ)) at hh
    have hcast : (n : ℝ) = |(squarefreePart P.normAlpha : ℝ)| := by simp [n]
    rwa [hcast] at hh
  · intro p hp hpS hv
    have hp' : p ∈ n.primeFactors := Nat.mem_primeFactors.mpr
      ⟨hp, Int.natCast_dvd.mp hpS, hn.ne_zero⟩
    rw [hf]
    rw [hsign] at hv
    by_cases hab : b < a
    · simp only [ite_eq_left hab] at hv
      rw [min_eq_right (le_of_lt hab)]
      exact partition_positive_support hmin hp' hv
    · simp only [ite_eq_right hab] at hv
      rw [min_eq_left (by omega : a ≤ b)]
      apply partition_positive_support (v := w) (w := v) _ hp' hv
      intro q hq
      simpa only [min_comm] using hmin q hq

/-- Proposition 3.1(a) using the printed candidate comparison, literal f'
formula, quotient construction and normalization. The earlier proof is archived in the previous complete releases. -/
theorem proposition31a_published (P : Parameters)
    [Fact (¬ IsSquare P.d)] [Fact (¬ IsSquare P.normAlpha)] {x y : ℤ}
    (h : P.RepresentsSquare x y) (ha : P.a ≠ 0) (hb : 0 < P.b) (hy : 0 < y)
    (hu : P.u ≠ 0) (hi : IsIntegral ℤ P.epsilon) :
    ∃ (ν f r s : ℤ), (ν : ℚ) = P.epsilonNorm ∧ f ≠ 0 ∧
      P.FourthPowerRepresentation x y f r s ∧
      (P.publishedSmallFactor y : ℤ) ∣ squarefreePart P.normAlpha ∧
      0 < P.publishedSmallFactor y ∧
      (P.publishedSmallFactor y : ℝ) < max 2 (Real.sqrt |(squarefreePart P.normAlpha : ℝ)|) ∧
      f ∣ 4 * P.b ^ 2 * P.sharpRadical ν (P.publishedSmallFactor y) := by
  have hd : P.d ≠ 0 := by
    intro hz
    exact (Fact.out : ¬ IsSquare P.d) (hz ▸ IsSquare.zero)
  have hN : P.normAlpha ≠ 0 := by
    intro hz
    exact (Fact.out : ¬ IsSquare P.normAlpha) (hz ▸ IsSquare.zero)
  obtain ⟨ν, hn, hν⟩ := P.exists_integer_norm_relation hi
  obtain ⟨hσ, he, hepos, hsmall, hcover⟩ := P.published_candidate_selection h (ne_of_gt hb) hu hN
  let σ := P.publishedCandidateSign y
  let g : ℤ := normalizationGcd P.b (P.repCandidate y σ)
  let f := σ * 4 * P.b ^ 2 * P.repCandidate y σ / g ^ 2
  obtain ⟨hf, hrep⟩ := P.normalized_representation_from_quotient h ha (ne_of_gt hb) hd
    (ne_of_gt hy) hu hN hi hσ
  refine ⟨ν, f, P.repCandidate y σ / g, -P.u * squareFactor P.normAlpha / g,
    hn, hf, hrep, he, hepos, hsmall, ?_⟩
  have hgf : g ^ 2 ∣ σ * 4 * P.b ^ 2 * P.repCandidate y σ := by
    convert dvd_mul_of_dvd_right (normalizationGcd_sq_dvd P.b (P.repCandidate y σ)) σ using 1
    ring
  have hfg : σ * 4 * P.b ^ 2 * P.repCandidate y σ = g ^ 2 * f := by
    simpa only [f, mul_comm] using (Int.ediv_mul_cancel hgf).symm
  apply normalized_coefficient_dvd_four (ne_of_gt hb) (P.repCandidate_ne_zero h hu hN hσ)
    hf UniqueFactorizationMonoid.radical_ne_zero hσ hfg
  intro p hp
  let : Fact p.Prime := ⟨hp⟩
  exact P.candidate_valuation_le_sharpRadical_published h (ne_of_gt hb) hu hN hν hσ hepos hcover p

end Parameters
end «JNT-2024»
