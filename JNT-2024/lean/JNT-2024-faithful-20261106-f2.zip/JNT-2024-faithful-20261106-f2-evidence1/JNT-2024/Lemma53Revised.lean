module

public import «JNT-2024».AkhtariInput
public import «JNT-2024».DenominatorBounds
public import «JNT-2024».Integrality
public import «JNT-2024».Lemma53
public import «JNT-2024».Lemma53Published
public import «JNT-2024».Monotonicity
public import «JNT-2024».NormalizerBounds
public import «JNT-2024».Positivity
public import «JNT-2024».Proposition41
public import «JNT-2024».Section46Calculation
public import «JNT-2024».Section4Published
public import «JNT-2024».Section4Sequence
public import «JNT-2024».Section5Bounds
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.Deriv.MeanValue
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section
namespace «JNT-2024».Parameters

/-- Revised Lemma 5.3. The existing cubic-chain and recurrence proofs are
reused, with the new manuscript's initial small-d/norm-minus-one reductions. -/
theorem lemma53_revised (P : Parameters) (hPrior : Hypergeometric.DenominatorEstimate4)
    (hAkhtari : ExternalResults.AkhtariTheorem11) (hCalculation : Calculations.Section46Magma)
    (h : P.Admissible) (hb : P.b=1) (hn : P.normAlpha<0) (hNs : IsSquare (-P.normAlpha))
    (hK : P.IsNegativeCutoff h.pell (-1))
    (hm : IsIntegerSquare (P.y h.pell (-1))) (hp : IsIntegerSquare (P.y h.pell 1))
    (_hne : P.y h.pell (-1) ≠ P.y h.pell 1) {k : ℤ} (hk : 1<k.natAbs) :
    ¬ IsIntegerSquare (P.y h.pell k) := by
  intro hs
  have hm1 : 1<P.y h.pell (-1) := by simpa [hb] using hK.2.1
  have horder := P.section5_adjacent_order h
  by_cases hN1 : P.normAlpha= -1
  · exact (ne_of_lt horder) (P.section46_norm_minus_one hAkhtari h hb hN1 hm hp hm1 (hm1.trans horder))
  by_cases hd : P.d ≤ 111
  · exact (ne_of_lt horder) (P.section46_small_published hAkhtari hCalculation h hb hn hNs hd
      hm hp hm1 (hm1.trans horder))
  have hg := P.lemma53_cubic_lower h hb hn hNs hK hm hp
  have hN := (P.section4_norm_range h hb hn).1
  have hdR : (112:ℝ) ≤ P.d := by exact_mod_cast (show 112 ≤ P.d by omega)
  have huR : (1:ℝ) ≤ P.u := by exact_mod_cast (show 1 ≤ P.u by have := h.u_pos; omega)
  have hu6 : (1:ℝ) ≤ (P.u:ℝ)^6 := one_le_pow₀ huR
  have hd2 : (112:ℝ)^2 ≤ (P.d:ℝ)^2 := by nlinarith
  have hdu : (112:ℝ)^2 ≤ (P.d:ℝ)^2*(P.u:ℝ)^6 := by
    nlinarith only [hd2,mul_nonneg (sq_nonneg (P.d:ℝ)) (sub_nonneg.mpr hu6)]
  have hprod := mul_le_mul_of_nonneg_right hdu hN.le
  have hlarge : (137/4:ℝ) * |(P.normAlpha:ℝ)| < (P.y h.pell 1:ℝ) := by
    nlinarith only [hg,hprod,hN]
  have hcut : P.proposition41Threshold < (P.y h.pell 1:ℝ) := by
    apply P.section5_above_cutoff h hb hn (by exact_mod_cast hm1.trans horder)
    have hB : (4:ℝ) ≤ P.normalizerSquare := by
      exact_mod_cast (P.normalizerSquare_bounds h (by simp [hb]) (ne_of_lt hn)).2.1
    have hypos : (0:ℝ) ≤ (P.y h.pell 1:ℝ) := by exact_mod_cast (P.y_pos h hn 1).le
    have hh := mul_le_mul_of_nonneg_right hB hypos
    nlinarith only [hh,hlarge]
  have hv := P.lemma53_tail_order h hb hn hK hk
  exact (ne_of_lt hv) (proposition41_published hPrior hAkhtari hCalculation P h hb hn hNs
    1 k hp hs hcut (hcut.trans (by exact_mod_cast hv)))

end «JNT-2024».Parameters
