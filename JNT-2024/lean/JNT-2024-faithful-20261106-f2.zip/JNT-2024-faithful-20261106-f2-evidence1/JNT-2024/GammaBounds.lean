module

public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

def gammaRatio : ℕ → ℚ
  | 0 => 1
  | r + 1 => gammaRatio r * (4 * (r + 1)) / (4 * r + 3)

/-- `4^r` times the remainder's Pochhammer/factorial coefficient. -/
def scaledRemainder : ℕ → ℚ
  | 0 => 1 / 4
  | r + 1 => scaledRemainder r * (4 * r + 5) / (4 * r + 6)

theorem gammaRatio_pos (r : ℕ) : 0 < gammaRatio r := by
  induction r with
  | zero => norm_num [gammaRatio]
  | succ r ih => rw [gammaRatio]; positivity

theorem scaledRemainder_pos (r : ℕ) : 0 < scaledRemainder r := by
  induction r with
  | zero => norm_num [scaledRemainder]
  | succ r ih => rw [scaledRemainder]; positivity

/-- The fourth-power difference displayed in the proof of Lemma 2.3(b).
The variable is rational here so the identity also serves the exact induction. -/
theorem lemma23b_remainder_fourth_difference {r : ℚ} (hr : 0 ≤ r) :
    ((r + 5 / 4) / (r + 3 / 2)) ^ 4 - r / (r + 1) =
      (224 * r ^ 3 + 944 * r ^ 2 + 1329 * r + 625) /
        (16 * (2 * r + 3) ^ 4 * (r + 1)) := by
  have h₁ : r + 3 / 2 ≠ 0 := by linarith
  have h₂ : r + 1 ≠ 0 := by linarith
  have h₃ : 2 * r + 3 ≠ 0 := by linarith
  field_simp
  ring

theorem lemma23b_remainder_fourth_difference_pos {r : ℚ} (hr : 0 ≤ r) :
    0 < ((r + 5 / 4) / (r + 3 / 2)) ^ 4 - r / (r + 1) := by
  rw [lemma23b_remainder_fourth_difference hr]
  positivity

/-- The corresponding difference in the second induction, which the paper
describes as proceeding in the same way. -/
theorem lemma23b_gamma_fourth_difference {r : ℚ} (hr : 0 < r) :
    (r + 1) / r - (4 * (r + 1) / (4 * r + 3)) ^ 4 =
      (r + 1) * (96 * r ^ 2 + 176 * r + 81) / (r * (4 * r + 3) ^ 4) := by
  have h₁ : r ≠ 0 := ne_of_gt hr
  have h₂ : 4 * r + 3 ≠ 0 := by positivity
  field_simp
  ring

theorem lemma23b_gamma_fourth_difference_pos {r : ℚ} (hr : 0 < r) :
    0 < (r + 1) / r - (4 * (r + 1) / (4 * r + 3)) ^ 4 := by
  rw [lemma23b_gamma_fourth_difference hr]
  positivity

/-- Successive Gamma quotients: the ratio used in the second printed induction. -/
theorem gammaRatio_successive_ratio (r : ℕ) :
    gammaRatio (r + 1) / gammaRatio r = ((r : ℚ) + 1) / (r + 3 / 4) := by
  have h := ne_of_gt (gammaRatio_pos r)
  rw [gammaRatio]
  field_simp

theorem gammaRatio_fourth_bound {r : ℕ} (hr : 1 ≤ r) :
    81 * gammaRatio r ^ 4 ≤ 256 * r := by
  induction r, hr using Nat.le_induction with
  | base => norm_num [gammaRatio]
  | succ r hr ih =>
    have hden : (0 : ℚ) < 4 * r + 3 := by positivity
    have hstep : (r : ℚ) * (4 * (r + 1)) ^ 4 ≤ (r + 1) * (4 * r + 3) ^ 4 := by
      have hrpos : (0 : ℚ) < r := by exact_mod_cast (by omega : 0 < r)
      have hh := sub_pos.mp (lemma23b_gamma_fourth_difference_pos hrpos)
      rw [div_pow] at hh
      have hc := (div_lt_div_iff₀ (pow_pos hden 4) hrpos).mp hh
      nlinarith only [hc]
    have hh := mul_le_mul_of_nonneg_right ih (pow_nonneg (by positivity : (0 : ℚ) ≤ 4 * (r + 1)) 4)
    rw [gammaRatio]
    simp only [div_pow, mul_pow, ← mul_div_assoc]
    apply (div_le_iff₀ (pow_pos hden 4)).mpr
    push_cast
    nlinarith only [hh, hstep]

theorem scaledRemainder_fourth_bound {r : ℕ} (hr : 1 ≤ r) :
    (5 / 24 : ℚ) ^ 4 ≤ r * scaledRemainder r ^ 4 := by
  induction r, hr using Nat.le_induction with
  | base => norm_num [scaledRemainder]
  | succ r hr ih =>
    have hden : (0 : ℚ) < 4 * r + 6 := by positivity
    have hstep : (r : ℚ) * (4 * r + 6) ^ 4 ≤ (r + 1) * (4 * r + 5) ^ 4 := by
      have hh := sub_pos.mp (lemma23b_remainder_fourth_difference_pos
        (by positivity : (0 : ℚ) ≤ r))
      rw [div_pow] at hh
      have hc := (div_lt_div_iff₀ (by positivity : (0 : ℚ) < r + 1)
        (by positivity : (0 : ℚ) < ((r : ℚ) + 3 / 2) ^ 4)).mp hh
      nlinarith only [hc]
    have hh := mul_le_mul_of_nonneg_right ih (pow_nonneg hden.le 4)
    have hh' := mul_le_mul_of_nonneg_right hstep (pow_nonneg (scaledRemainder_pos r).le 4)
    rw [scaledRemainder]
    simp only [div_pow, mul_pow, ← mul_div_assoc]
    apply (le_div_iff₀ (pow_pos hden 4)).mpr
    push_cast
    nlinarith only [hh, hh']

theorem gammaRatio_eq_gamma (r : ℕ) :
    (gammaRatio r : ℝ) = (r.factorial : ℝ) * Real.Gamma (3 / 4) / Real.Gamma (r + 3 / 4) := by
  induction r with
  | zero =>
    have hg := ne_of_gt (Real.Gamma_pos_of_pos (by norm_num : (0 : ℝ) < 3 / 4))
    simp [gammaRatio, hg]
  | succ r ih =>
    have hp : (0 : ℝ) < r + 3 / 4 := by positivity
    rw [show ((r + 1 : ℕ) : ℝ) + 3 / 4 = ((r : ℝ) + 3 / 4) + 1 by push_cast; ring,
      Real.Gamma_add_one (ne_of_gt hp), gammaRatio, Nat.factorial_succ]
    push_cast
    rw [ih]
    field_simp

theorem lemma23b_gamma {r : ℕ} (hr : 1 ≤ r) :
    (r.factorial : ℝ) * Real.Gamma (3 / 4) / Real.Gamma (r + 3 / 4) ≤
      4 * (r : ℝ) ^ (1 / 4 : ℝ) / 3 := by
  rw [← gammaRatio_eq_gamma]
  have hpos : (0 : ℝ) ≤ (gammaRatio r : ℝ) := by exact_mod_cast (gammaRatio_pos r).le
  have hp : ((r : ℝ) ^ (1 / 4 : ℝ)) ^ 4 = (r : ℝ) := by
    simpa using Real.rpow_inv_natCast_pow (x := (r : ℝ)) (by positivity) (by decide : (4 : ℕ) ≠ 0)
  apply le_of_pow_le_pow_left₀ (by decide : (4 : ℕ) ≠ 0) (by positivity)
  have hh : (81 : ℝ) * (gammaRatio r : ℝ) ^ 4 ≤ 256 * r := by exact_mod_cast gammaRatio_fourth_bound hr
  rw [div_pow, mul_pow, hp]
  norm_num
  nlinarith only [hh]

end Hypergeometric
end «JNT-2024»
