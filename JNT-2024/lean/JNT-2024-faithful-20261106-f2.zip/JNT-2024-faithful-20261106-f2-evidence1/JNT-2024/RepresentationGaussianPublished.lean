module

public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».RepresentationDivisibility
public import «JNT-2024».RepresentationFactors
public import «JNT-2024».RepresentationGaussian
public import «JNT-2024».RepresentationLemma33Published
public import «JNT-2024».RepresentationLemma34Published
public import «JNT-2024».RepresentationNormalization
public import «JNT-2024».RepresentationSupport
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- The opening odd-coefficient case of Proposition 3.1(b). -/
theorem odd_divisor_cancel_four {f B : ℤ} (hf : Odd f) (hd : f ∣ 4 * B) : f ∣ B := by
  have hh : f ∣ 2 * (2 * B) := by convert hd using 1; ring
  exact hf.isCoprime_two.dvd_of_dvd_mul_left (hf.isCoprime_two.dvd_of_dvd_mul_left hh)

/-- The two halves printed in case (b-i) are integral and reconstruct r,s. -/
theorem odd_gaussian_halves {r s : ℤ} (hr : Odd r) (hs : Odd s) :
    2 * ((r + s) / 2) = r + s ∧ 2 * ((s - r) / 2) = s - r ∧
    r = (r + s) / 2 - (s - r) / 2 ∧ s = (r + s) / 2 + (s - r) / 2 := by
  obtain ⟨R, hR⟩ := hr
  obtain ⟨S, hS⟩ := hs
  omega

namespace Parameters

/-- The preliminary broad divisor assertion on p. 14, for either candidate,
by an explicit application of the restored Lemma 3.3(a). -/
theorem normalized_coefficient_broad_published (P : Parameters) {x y ν σ f : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0)
    (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν) (hσ : σ = 1 ∨ σ = -1) (hf : f ≠ 0)
    (he : σ * 4 * P.b ^ 2 * P.repCandidate y σ =
      (normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2 * f) :
    f ∣ 4 * P.b ^ 2 * P.representationRadical ν := by
  apply normalized_coefficient_dvd_four hb (P.repCandidate_ne_zero h hu hN hσ) hf
    UniqueFactorizationMonoid.radical_ne_zero hσ he
  intro p hp
  let : Fact p.Prime := ⟨hp⟩
  have hv := P.lemma33a_published h hb hu hN hν p
  rcases hσ with rfl | rfl
  · exact (le_max_left _ _).trans hv
  · exact (le_max_right _ _).trans hv

/-- The broad divisor bound for the actual integer quotient, not an assumed
normalized coefficient. This covers both choices in the manuscript. -/
theorem normalized_quotient_broad_published (P : Parameters) {x y ν σ : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0)
    (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν) (hσ : σ = 1 ∨ σ = -1) :
    (σ * 4 * P.b ^ 2 * P.repCandidate y σ /
      (normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2) ∣
        4 * P.b ^ 2 * P.representationRadical ν := by
  have hs0 : σ ≠ 0 := by rcases hσ with rfl | rfl <;> norm_num
  have hr := P.repCandidate_ne_zero h hu hN hσ
  have hraw : σ * 4 * P.b ^ 2 * P.repCandidate y σ ≠ 0 :=
    mul_ne_zero (mul_ne_zero (mul_ne_zero hs0 (by norm_num)) (pow_ne_zero _ hb)) hr
  have hdiv : (normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2 ∣
      σ * 4 * P.b ^ 2 * P.repCandidate y σ := by
    convert dvd_mul_of_dvd_right (normalizationGcd_sq_dvd P.b (P.repCandidate y σ)) σ using 1
    ring
  have he := Int.ediv_mul_cancel hdiv
  have hf : σ * 4 * P.b ^ 2 * P.repCandidate y σ /
      (normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2 ≠ 0 := by
    intro hz
    rw [hz, zero_mul] at he
    exact hraw he.symm
  apply P.normalized_coefficient_broad_published h hb hu hN hν hσ hf
  simpa only [mul_comm] using he.symm

/-- In the square-negative-norm case, the broad radical is exactly the one
in Proposition 3.1(b). -/
theorem representationRadical_negative_square (P : Parameters) (ν : ℤ)
    (hS : squarefreePart P.normAlpha = -1) : P.representationRadical ν = P.normRadical ν := by
  simp [representationRadical, normRadical, hS]

/-- The opening case of (b) retains the existing coordinates when f is odd. -/
theorem proposition31b_odd_coefficient_published (P : Parameters) {x y ν σ f r s : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0)
    (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν) (hσ : σ = 1 ∨ σ = -1)
    (hS : squarefreePart P.normAlpha = -1) (hf : f ≠ 0) (hfO : Odd f)
    (he : σ * 4 * P.b ^ 2 * P.repCandidate y σ =
      (normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2 * f)
    (hrep : P.FourthPowerRepresentation x y f r s) :
    P.SignedFourthPowerRepresentation x y f r s 1 ∧ f ∣ P.b ^ 2 * P.normRadical ν := by
  have hd := P.normalized_coefficient_broad_published h hb hu hN hν hσ hf he
  rw [P.representationRadical_negative_square ν hS] at hd
  exact ⟨hrep.signed, odd_divisor_cancel_four hfO (by simpa only [mul_assoc] using hd)⟩

/-- The norm-congruence assertion at the start of p. 15. -/
theorem negative_square_norm_mod_four (P : Parameters)
    (hS : squarefreePart P.normAlpha = -1) : P.normAlpha % 4 ≠ 1 := by
  have he := squareFactor_sq_mul P.normAlpha
  rw [hS] at he
  have hm := Int.sq_emod_four (squareFactor P.normAlpha)
  omega

/-- The field hypothesis in the literal Gaussian quotient formula follows
from sf(N_alpha)=-1 and adds no restriction to case (b-i). -/
theorem negative_squarefree_nonsquare (P : Parameters)
    (hS : squarefreePart P.normAlpha = -1) : ¬ IsSquare (squarefreePart P.normAlpha) := by
  rw [hS]
  rintro ⟨z, hz⟩
  nlinarith [sq_nonneg z]

/-- The factor-two improvement uses precisely the printed Lemmas 3.4 and 3.3(c). -/
theorem normalized_coefficient_two_published (P : Parameters) [Fact (¬ IsSquare P.d)]
    {x y ν σ f : ℤ} (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hu : P.u ≠ 0)
    (hN : P.normAlpha ≠ 0) (hi : IsIntegral ℤ P.epsilon)
    (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν) (hσ : σ = 1 ∨ σ = -1)
    (hS : squarefreePart P.normAlpha = -1) (hf : f ≠ 0)
    (he : σ * 4 * P.b ^ 2 * P.repCandidate y σ =
      (normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2 * f) :
    f ∣ 2 * P.b ^ 2 * P.normRadical ν := by
  have heven := P.lemma34_published h hi (fun hh => P.negative_square_norm_mod_four hS hh.1)
  have hev : Even (P.repCandidate y σ) := by
    rcases hσ with rfl | rfl
    · exact heven.1
    · exact heven.2.1
  have hq := lemma33c_published hb (P.repCandidate_ne_zero h hu hN hσ) hev
  apply normalized_coefficient_dvd_two hb (P.repCandidate_ne_zero h hu hN hσ) hf
    UniqueFactorizationMonoid.radical_ne_zero hσ he _ hq
  intro p hp
  let : Fact p.Prime := ⟨hp⟩
  have hv := P.lemma33a_published h hb hu hN hν p
  rw [P.representationRadical_negative_square ν hS] at hv
  rcases hσ with rfl | rfl
  · exact (le_max_left _ _).trans hv
  · exact (le_max_right _ _).trans hv

/-- The identity (1+i)^4=-4 used in case (b-i). -/
theorem gaussian_one_add_i_fourth (P : Parameters) (hS : squarefreePart P.normAlpha = -1) :
    (⟨1, 1⟩ : P.SquarefreeNormAlgebra) ^ 4 = (-4 : ℚ) • (1 : P.SquarefreeNormAlgebra) := by
  ext <;> simp only [pow_succ, pow_zero, QuadraticAlgebra.re_mul, QuadraticAlgebra.im_mul,
    QuadraticAlgebra.re_one, QuadraticAlgebra.im_one, QuadraticAlgebra.re_smul,
    QuadraticAlgebra.im_smul] <;> norm_num [hS]

/-- The literal division formula on p. 14, for arbitrary rational coordinates. -/
theorem gaussian_division_formula (P : Parameters) [Fact (¬ IsSquare (squarefreePart P.normAlpha))]
    (hS : squarefreePart P.normAlpha = -1) (r s : ℚ) :
    (⟨r, s⟩ : P.SquarefreeNormAlgebra) / ⟨1, 1⟩ = ⟨(r + s) / 2, (s - r) / 2⟩ := by
  have hne : (⟨1, 1⟩ : P.SquarefreeNormAlgebra) ≠ 0 := by
    intro he
    have hh := congrArg QuadraticAlgebra.re he
    norm_num at hh
  apply (div_eq_iff hne).mpr
  ext <;> simp [hS] <;> ring

/-- The alternative expression 2b^2 r/g1 for the new coefficient in (b-i),
including the candidate sign from the companion identity. -/
theorem gaussian_half_coefficient (P : Parameters) {y σ f r : ℤ}
    (hg : (normalizationGcd P.b (P.repCandidate y σ) : ℤ) ≠ 0)
    (he : σ * 4 * P.b ^ 2 * P.repCandidate y σ =
      (normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2 * f)
    (hr : P.repCandidate y σ = (normalizationGcd P.b (P.repCandidate y σ) : ℤ) * r)
    (hf : Even f) :
    f / 2 = σ * 2 * P.b ^ 2 * r / (normalizationGcd P.b (P.repCandidate y σ) : ℤ) := by
  have hf2 : 2 * (f / 2) = f := by
    simpa only [mul_comm] using Int.ediv_mul_cancel (even_iff_two_dvd.mp hf)
  have hh : (normalizationGcd P.b (P.repCandidate y σ) : ℤ) *
      (σ * 4 * P.b ^ 2 * r) = (normalizationGcd P.b (P.repCandidate y σ) : ℤ) *
      ((normalizationGcd P.b (P.repCandidate y σ) : ℤ) * f) := by
    have hmul := congrArg (fun z : ℤ => σ * 4 * P.b ^ 2 * z) hr
    nlinarith only [he, hmul]
  have hc := mul_left_cancel₀ hg hh
  have hh' : σ * 2 * P.b ^ 2 * r = (f / 2) * (normalizationGcd P.b (P.repCandidate y σ) : ℤ) := by
    rw [← hf2] at hc
    nlinarith only [hc]
  rw [hh', Int.mul_ediv_cancel _ hg]

/-- Case (b-i): the exact printed integer halves, coefficient f/2, sign -1,
both identities, and sharp divisor bound. Both original candidate signs are allowed. -/
theorem proposition31b_odd_odd_published (P : Parameters) [Fact (¬ IsSquare P.d)]
    {x y ν σ f r s : ℤ} (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hu : P.u ≠ 0)
    (hN : P.normAlpha ≠ 0) (hi : IsIntegral ℤ P.epsilon)
    (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν) (hσ : σ = 1 ∨ σ = -1)
    (hS : squarefreePart P.normAlpha = -1) (hf : f ≠ 0)
    (he : σ * 4 * P.b ^ 2 * P.repCandidate y σ =
      (normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2 * f)
    (hrep : P.FourthPowerRepresentation x y f r s) (hfE : Even f) (hr : Odd r) (hs : Odd s) :
    f / 2 ≠ 0 ∧ P.SignedFourthPowerRepresentation x y (f / 2)
      ((r + s) / 2) ((s - r) / 2) (-1) ∧ f / 2 ∣ P.b ^ 2 * P.normRadical ν := by
  have hf2 : 2 * (f / 2) = f := by
    have hh := Int.ediv_mul_cancel (even_iff_two_dvd.mp hfE)
    simpa only [mul_comm] using hh
  have hhalf : f / 2 ≠ 0 := by intro hz; rw [hz, mul_zero] at hf2; exact hf hf2.symm
  obtain ⟨_, _, hr', hs'⟩ := odd_gaussian_halves hr hs
  have hd := P.normalized_coefficient_two_published h hb hu hN hi hν hσ hS hf he
  refine ⟨hhalf, ?_, ?_⟩
  · apply P.gaussian_halving hS
    simpa only [hf2, ← hr', ← hs'] using hrep
  · obtain ⟨k, hk⟩ := hd
    refine ⟨k, ?_⟩
    rw [← hf2] at hk
    nlinarith only [hk]

end Parameters
end «JNT-2024»
