module

public import «JNT-2024».Integrality
public import «JNT-2024».RealBounds
public import «JNT-2024».Sequence
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»


namespace Parameters


/-- The published proof of positivity in Lemma 3.5(b), using part (a).
 -/
theorem y_pos (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) (k : ℤ) :
    0 < P.y h.pell k := by
  have hy : (0 : ℝ) < (P.y h.pell k : ℝ) := by
    rcases le_or_gt 0 k with hk | hk
    · exact lt_trans (div_pos (mul_pos (P.realAlpha_pos h)
        (pow_pos (P.realEpsilon_pos h) _)) (mul_pos (by norm_num) (P.root_pos h)))
        ((P.lemma35a h hn k).1 hk)
    · exact lt_trans (div_pos (mul_pos (neg_pos.mpr (P.realAlphaConj_neg h hn))
        (pow_pos (P.realEpsilon_pos h) _)) (mul_pos (by norm_num) (P.root_pos h)))
        ((P.lemma35a h hn k).2 hk)
  exact_mod_cast hy

/-- Combined first assertion of Lemma 3.5(b): `2yₖ` is a positive integer. -/
theorem two_y_positive_integer (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (k : ℤ) :
    ∃ n : ℤ, 0 < n ∧ 2 * P.y h.pell k = n := by
  obtain ⟨n, hnInt⟩ := P.two_y_integral h.pell k
  refine ⟨n, ?_, hnInt⟩
  have : (0 : ℚ) < n := by rw [← hnInt]; exact mul_pos (by norm_num) (P.y_pos h hn k)
  exact_mod_cast this

theorem one_half_le_y (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (k : ℤ) : (1 : ℚ) / 2 ≤ P.y h.pell k := by
  obtain ⟨n, hnpos, heq⟩ := P.two_y_positive_integer h hn k
  have hni : (1 : ℤ) ≤ n := by omega
  have hnq : (1 : ℚ) ≤ n := by exact_mod_cast hni
  linarith

end Parameters
end «JNT-2024»
