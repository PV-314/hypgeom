module

public import «JNT-2024».NormalizerBounds
public import «JNT-2024».NormalizerFormula
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».Sequence
public import «JNT-2024».SmallUnitBounds
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- The parenthetical equality case before (4.20), with the normalizer
computed from the actual formula (3.36), not supplied as a premise. -/
theorem section4_normalizer_attained (P : Parameters) (ha : 0 < P.a)
    (hb : P.b=1) (hd : P.d=17*P.a^2) :
    P.normAlpha= -16*P.a^2 ∧
    |(P.normAlpha:ℝ)|^2*(P.normalizerSquare:ℝ)^2/(P.d:ℝ)^4=(2:ℝ)^20/17^4 := by
  have hN : P.normAlpha= -16*P.a^2 := by simp [normAlpha,hb,hd]; ring
  have hG : P.baseGcd=P.a.natAbs^2 := by
    simp only [baseGcd,hb,one_pow,mul_one,hd,Int.gcd_eq_natAbs_gcd_natAbs,
      Int.natAbs_mul,Int.natAbs_pow]
    norm_num
  have hGi : (P.baseGcd:ℤ)=P.a^2 := by rw [hG]; simp
  have hQ : P.normQuotient= -16 := by
    rw [normQuotient,hGi,hN]
    simpa only [mul_comm] using Int.mul_ediv_cancel_left (-16) (ne_of_gt (sq_pos_of_pos ha))
  have hB : (P.normalizerSquare:ℤ)=64*P.a^2 := by
    simp only [normalizerSquare,hQ]
    norm_num
    rw [hGi]
    ring
  refine ⟨hN,?_⟩
  have hBR : (P.normalizerSquare:ℝ)=64*(P.a:ℝ)^2 := by exact_mod_cast hB
  have hNR : (P.normAlpha:ℝ)= -16*(P.a:ℝ)^2 := by exact_mod_cast hN
  have hdR : (P.d:ℝ)=17*(P.a:ℝ)^2 := by exact_mod_cast hd
  have hap : (0:ℝ)<P.a := by exact_mod_cast ha
  rw [sq_abs,hNR,hdR,hBR]
  field_simp
  ring

end «JNT-2024».Parameters

