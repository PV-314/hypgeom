module

public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section5

theorem gcd_square_residue (b : ℤ) (m : ℕ) [NeZero m] (hm : 16 ∣ m) :
    Int.gcd 16 (b ^ 2) = Nat.gcd 16 ((b : ZMod m).val ^ 2) := by
  have he := ZMod.val_intCast (n := m) b
  have hm' : (16 : ℤ) ∣ (m : ℤ) := by exact_mod_cast hm
  have hh : ((b : ZMod m).val : ℤ) % 16 = b % 16 := by
    rw [he, Int.emod_emod_of_dvd b hm']
  have hp : b ^ 2 % 16 = (((b : ZMod m).val : ℤ) ^ 2) % 16 := by
    simp only [pow_two]
    rw [Int.mul_emod b b 16,
      Int.mul_emod ((b : ZMod m).val : ℤ) ((b : ZMod m).val : ℤ) 16, hh]
  rw [Int.gcd_comm, ← Int.gcd_emod (b ^ 2) 16, hp, Int.gcd_emod, Int.gcd_comm]
  simp only [Int.gcd_eq_natAbs_gcd_natAbs, Int.natAbs_pow, Int.natAbs_natCast]
  rfl


end «JNT-2024».Section5

namespace «JNT-2024».Parameters

theorem section5_adjacent_equations (P : Parameters) (hp : P.Pell) (hb : P.b = 1)
    (hs : P.AdjacentSquare hp) : ∃ v : ℤ,
    P.t ^ 2 + P.d * P.u ^ 2 + 2 * P.a * P.t * P.u = 4 * v ^ 2 ∨
    P.t ^ 2 + P.d * P.u ^ 2 - 2 * P.a * P.t * P.u = 4 * v ^ 2 := by
  rcases hs with ⟨v, hv⟩ | ⟨v, hv⟩
  · refine ⟨v, Or.inl ?_⟩
    have he : (P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2 + 2 * P.a * P.t * P.u = 4 * (v : ℚ) ^ 2 := by
      rw [P.y_one, hb] at hv
      norm_num only [Int.cast_one, one_pow, one_mul] at hv
      linarith
    exact_mod_cast he
  · refine ⟨v, Or.inr ?_⟩
    have he : (P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2 - 2 * P.a * P.t * P.u = 4 * (v : ℚ) ^ 2 := by
      rw [P.y_neg_one, hb] at hv
      norm_num only [Int.cast_one, one_pow, one_mul] at hv
      linarith
    exact_mod_cast he


end «JNT-2024».Parameters
