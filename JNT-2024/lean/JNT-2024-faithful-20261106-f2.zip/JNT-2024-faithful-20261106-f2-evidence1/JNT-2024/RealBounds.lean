module

public import «JNT-2024».Integrality
public import «JNT-2024».Sequence
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- Evaluation of the quadratic algebra at a real root of `X²-d`. -/
noncomputable def evalAt (P : Parameters) (r : ℝ) (hr : r ^ 2 = (P.d : ℝ)) :
    P.Algebra →+* ℝ where
  toFun z := (z.re : ℝ) + z.im * r
  map_one' := by simp [QuadraticAlgebra.re_one, QuadraticAlgebra.im_one]
  map_zero' := by simp [QuadraticAlgebra.re_zero, QuadraticAlgebra.im_zero]
  map_add' z w := by simp; ring
  map_mul' z w := by
    simp
    have hh := congrArg (fun s : ℝ => (z.im : ℝ) * w.im * s) hr
    nlinarith only [hh]

noncomputable def root (P : Parameters) : ℝ := Real.sqrt (P.d : ℝ)
noncomputable def realAlpha (P : Parameters) : ℝ := P.a + (P.b : ℝ) ^ 2 * P.root
noncomputable def realAlphaConj (P : Parameters) : ℝ := P.a - (P.b : ℝ) ^ 2 * P.root
noncomputable def realEpsilon (P : Parameters) : ℝ := (P.t + P.u * P.root) / 2
noncomputable def realEpsilonConj (P : Parameters) : ℝ := (P.t - P.u * P.root) / 2

theorem root_pos (P : Parameters) (h : P.Admissible) : 0 < P.root :=
  Real.sqrt_pos.mpr (by exact_mod_cast h.d_pos)

theorem root_sq (P : Parameters) (h : P.Admissible) : P.root ^ 2 = (P.d : ℝ) :=
  Real.sq_sqrt (by exact_mod_cast (le_of_lt h.d_pos))

theorem realAlpha_pos (P : Parameters) (h : P.Admissible) : 0 < P.realAlpha := by
  have ha : (0 : ℝ) < P.a := by exact_mod_cast h.a_pos
  unfold realAlpha
  nlinarith [mul_nonneg (sq_nonneg (P.b : ℝ)) (le_of_lt (P.root_pos h))]

theorem realAlpha_mul_conj (P : Parameters) (h : P.Admissible) :
    P.realAlpha * P.realAlphaConj = (P.normAlpha : ℝ) := by
  have hh := congrArg (fun s : ℝ => (P.b : ℝ) ^ 4 * s) (P.root_sq h)
  simp [realAlpha, realAlphaConj, normAlpha]
  nlinarith only [hh]

theorem realAlphaConj_neg (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) :
    P.realAlphaConj < 0 := by
  have hprod := P.realAlpha_mul_conj h
  have hN : (P.normAlpha : ℝ) < 0 := by exact_mod_cast hn
  exact neg_of_mul_neg_right (hprod ▸ hN) (le_of_lt (P.realAlpha_pos h))

theorem realEpsilon_pos (P : Parameters) (h : P.Admissible) : 0 < P.realEpsilon := by
  have ht : (0 : ℝ) < P.t := by exact_mod_cast h.t_pos
  have hu : (0 : ℝ) < P.u := by exact_mod_cast h.u_pos
  unfold realEpsilon
  linarith [mul_pos hu (P.root_pos h)]

theorem realEpsilon_mul_conj (P : Parameters) (h : P.Admissible) :
    P.realEpsilon * P.realEpsilonConj = (P.epsilonNorm : ℝ) := by
  have hh := congrArg (fun s : ℝ => (P.u : ℝ) ^ 2 * s) (P.root_sq h)
  simp [realEpsilon, realEpsilonConj, epsilonNorm]
  nlinarith only [hh]

theorem realEpsilonConj_ne_zero (P : Parameters) (h : P.Admissible) :
    P.realEpsilonConj ≠ 0 := by
  intro hz
  have hh := P.realEpsilon_mul_conj h
  rcases h.pell with hp | hp
  · rw [hz, P.epsilonNorm_eq_one hp] at hh
    norm_num at hh
  · rw [hz, P.epsilonNorm_eq_neg_one hp] at hh
    norm_num at hh

theorem evalAt_alpha (P : Parameters) (r : ℝ) (hr) :
    P.evalAt r hr P.alpha = P.a + (P.b : ℝ) ^ 2 * r := by simp [evalAt, alpha]

theorem evalAt_epsilon (P : Parameters) (r : ℝ) (hr) :
    P.evalAt r hr P.epsilon = (P.t + P.u * r) / 2 := by simp [evalAt, epsilon]; ring

theorem evalAt_star_epsilon (P : Parameters) (r : ℝ) (hr) :
    P.evalAt r hr (star P.epsilon) = (P.t - P.u * r) / 2 := by
  simp [evalAt, epsilon]; ring

theorem real_term_nat (P : Parameters) (h : P.Admissible) (n : ℕ) :
    (P.x h.pell n : ℝ) + P.y h.pell n * P.root =
      P.realAlpha * P.realEpsilon ^ (2 * n) := by
  have hh := congrArg (P.evalAt P.root (P.root_sq h)) (P.term_nat h.pell n)
  simp only [map_mul, map_pow, P.evalAt_alpha, P.evalAt_epsilon] at hh
  simpa [
    evalAt, x, y, realAlpha, realEpsilon] using hh

theorem real_conj_term_nat (P : Parameters) (h : P.Admissible) (n : ℕ) :
    (P.x h.pell n : ℝ) - P.y h.pell n * P.root =
      P.realAlphaConj * P.realEpsilonConj ^ (2 * n) := by
  have hr : (-P.root) ^ 2 = (P.d : ℝ) := by simpa using P.root_sq h
  have hh := congrArg (P.evalAt (-P.root) hr) (P.term_nat h.pell n)
  simp only [map_mul, map_pow, P.evalAt_alpha, P.evalAt_epsilon] at hh
  simpa [
    evalAt, x, y, realAlphaConj, realEpsilonConj, sub_eq_add_neg] using hh

theorem real_term_neg_nat (P : Parameters) (h : P.Admissible) (n : ℕ) :
    (P.x h.pell (-(n : ℤ)) : ℝ) + P.y h.pell (-(n : ℤ)) * P.root =
      P.realAlpha * P.realEpsilonConj ^ (2 * n) := by
  have hh := congrArg (P.evalAt P.root (P.root_sq h)) (P.term_neg_nat h.pell n)
  simp only [star_pow, map_mul, map_pow, P.evalAt_alpha, P.evalAt_star_epsilon] at hh
  simpa [
    evalAt, x, y, realAlpha, realEpsilonConj, pow_mul, mul_comm] using hh

theorem real_conj_term_neg_nat (P : Parameters) (h : P.Admissible) (n : ℕ) :
    (P.x h.pell (-(n : ℤ)) : ℝ) - P.y h.pell (-(n : ℤ)) * P.root =
      P.realAlphaConj * P.realEpsilon ^ (2 * n) := by
  have hr : (-P.root) ^ 2 = (P.d : ℝ) := by simpa using P.root_sq h
  have hh := congrArg (P.evalAt (-P.root) hr) (P.term_neg_nat h.pell n)
  simp only [star_pow, map_mul, map_pow, P.evalAt_alpha, P.evalAt_star_epsilon] at hh
  simpa [
    evalAt, x, y, realAlphaConj, realEpsilon, pow_mul, mul_comm, sub_eq_add_neg] using hh

/-- The nonnegative-index lower bound of Lemma 3.5(a). -/
theorem lemma35a_nonnegative (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (n : ℕ) :
    P.realAlpha * P.realEpsilon ^ (2 * n) / (2 * P.root) < (P.y h.pell n : ℝ) := by
  apply (div_lt_iff₀ (mul_pos (by norm_num) (P.root_pos h))).mpr
  have hp : 0 < P.realEpsilonConj ^ (2 * n) := by
    rw [pow_mul]
    exact pow_pos (sq_pos_of_ne_zero (P.realEpsilonConj_ne_zero h)) n
  have hm := mul_neg_of_neg_of_pos (P.realAlphaConj_neg h hn) hp
  linarith [P.real_term_nat h n, P.real_conj_term_nat h n]

/-- The negative-index lower bound of Lemma 3.5(a), also valid at index zero. -/
theorem lemma35a_negative (P : Parameters) (h : P.Admissible) (n : ℕ) :
    -P.realAlphaConj * P.realEpsilon ^ (2 * n) / (2 * P.root) <
      (P.y h.pell (-(n : ℤ)) : ℝ) := by
  apply (div_lt_iff₀ (mul_pos (by norm_num) (P.root_pos h))).mpr
  have hp : 0 < P.realEpsilonConj ^ (2 * n) := by
    rw [pow_mul]
    exact pow_pos (sq_pos_of_ne_zero (P.realEpsilonConj_ne_zero h)) n
  have hm := mul_pos (P.realAlpha_pos h) hp
  linarith [P.real_term_neg_nat h n, P.real_conj_term_neg_nat h n]

/-- Equation (3.12). Natural exponents represent the nonnegative integers
`2k` in the first branch and `2|k|` in the second branch. -/
theorem lemma35a (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) (k : ℤ) :
    (0 ≤ k → P.realAlpha * P.realEpsilon ^ (2 * k.toNat) / (2 * P.root) <
      (P.y h.pell k : ℝ)) ∧
    (k < 0 → -P.realAlphaConj * P.realEpsilon ^ (2 * k.natAbs) / (2 * P.root) <
      (P.y h.pell k : ℝ)) := by
  constructor
  · intro hk
    simpa [Int.toNat_of_nonneg hk] using P.lemma35a_nonnegative h hn k.toNat
  · intro hk
    simpa only [← Int.eq_neg_natAbs_of_nonpos (le_of_lt hk)] using P.lemma35a_negative h k.natAbs

end «JNT-2024».Parameters
