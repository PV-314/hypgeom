module

public import «JNT-2024».ApproximationCriterion
public import «JNT-2024».ApproximationProofDetails
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.InfinitePlace.TotallyRealComplex
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- In any imaginary quadratic number field, at either complex embedding,
a nonzero algebraic integer has absolute value at least one. -/
theorem imaginaryQuadratic_integer_norm_ge_one {K : Type*} [Field K] [NumberField K]
    [NumberField.IsTotallyComplex K] (hdegree : Module.finrank ℚ K = 2)
    (f : K →+* ℂ) {z : K} (hz : IsIntegral ℤ z) (hne : z ≠ 0) :
    1 ≤ ‖f z‖ := by
  classical
  have hc : Fintype.card (NumberField.InfinitePlace K) = 1 := by
    rw [NumberField.InfinitePlace.card_eq_nrRealPlaces_add_nrComplexPlaces,
      NumberField.IsTotallyComplex.nrRealPlaces_eq_zero, zero_add]
    have ht := NumberField.IsTotallyComplex.finrank K
    omega
  let : Subsingleton (NumberField.InfinitePlace K) :=
    Fintype.card_le_one_iff_subsingleton.mp (by omega)
  let a : NumberField.RingOfIntegers K := ⟨z, hz⟩
  have ha : a ≠ 0 := by
    intro h
    exact hne (congrArg Subtype.val h)
  have h := NumberField.InfinitePlace.one_le_of_lt_one
    (w := NumberField.InfinitePlace.mk f) ha (fun {_} hv =>
      (hv (Subsingleton.elim _ _)).elim)
  exact h

namespace Approximation

/-- Lemma 2.1 for an arbitrary imaginary quadratic field and either embedding.
Quadratic means degree two over the rationals; imaginary means no real places.
The integrality-to-norm step is proved above, and the printed determinant/cutoff
argument uses the printed successor steps through lemma21_complex_published. -/
theorem lemma21_imaginaryQuadratic {K : Type*} [Field K] [NumberField K]
    [NumberField.IsTotallyComplex K] (hdegree : Module.finrank ℚ K = 2)
    (f : K →+* ℂ) (θ : ℂ)
    (p q : K) (pr qr : ℕ → K)
    (hp : IsIntegral ℤ p) (hq : IsIntegral ℤ q)
    (hpr : ∀ r, IsIntegral ℤ (pr r)) (hqr : ∀ r, IsIntegral ℤ (qr r))
    (hpq : ¬ (p = 0 ∧ q = 0))
    {k ℓ E Q c : ℝ} (hk : 0 < k) (hℓ : 0 < ℓ) (hE : 1 < E) (hQ : 1 < Q)
    (hc : 0 < c) (hc1 : c < 1)
    (hqb : ∀ r, ‖f (qr r)‖ < k * Q ^ r)
    (herr : ∀ r, ‖f (qr r) * θ - f (pr r)‖ ≤ ℓ / E ^ r)
    (hind : ∀ r, pr r * qr (r + 1) - pr (r + 1) * qr r ≠ 0) :
    let r := firstIndex (Q := Q) (ℓ := ℓ) hE hc (f q)
    (1 - c / E) / (k * Q ^ (r + 1)) < ‖f q * θ - f p‖ ∧
      (pr r * q - qr r * p ≠ 0 → (1 - c) / (k * Q ^ r) < ‖f q * θ - f p‖) := by
  have hf : Function.Injective f := f.injective
  have hpq' : ¬ (f p = 0 ∧ f q = 0) := by
    rintro ⟨hp', hq'⟩
    exact hpq ⟨hf (by simpa using hp'), hf (by simpa using hq')⟩
  have hind' : ∀ r, f (pr r) * f (qr (r + 1)) - f (pr (r + 1)) * f (qr r) ≠ 0 := by
    intro r
    simpa only [← map_mul, ← map_sub] using (map_ne_zero f).mpr (hind r)
  have hdiscrete : ∀ r, f (pr r) * f q - f (qr r) * f p ≠ 0 →
      1 ≤ ‖f (pr r) * f q - f (qr r) * f p‖ := by
    intro r hne
    rw [← map_mul, ← map_mul, ← map_sub] at hne ⊢
    exact imaginaryQuadratic_integer_norm_ge_one hdegree f ((hpr r).mul hq |>.sub ((hqr r).mul hp))
      (fun he => hne (by rw [he, map_zero]))
  have hh := lemma21_complex_published hk hℓ hE hQ hc hc1 hpq' hqb herr hind' hdiscrete
    (firstIndex_spec (Q := Q) (ℓ := ℓ) hE hc (f q)).2
  refine ⟨hh.1, fun hne => hh.2 ?_⟩
  simpa only [map_mul, map_sub] using (map_ne_zero f).mpr hne


end Approximation
end «JNT-2024»
