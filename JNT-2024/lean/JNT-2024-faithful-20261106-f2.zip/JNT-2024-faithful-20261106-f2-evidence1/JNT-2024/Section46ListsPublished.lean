module

public import «JNT-2024».Section46Calculation
public import «JNT-2024».Section4Sequence
public import «JNT-2024».Section4SmallPairs
public import «JNT-2024».Sequence
public import «JNT-2024».SmallQuarticCertificates
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

set_option maxRecDepth 10000 in
/-- The finite consequence of the already certified solution lists used after
excluding the two middle solutions. This does not repeat the height search. -/
theorem listed_noninitial_separation : ∀ p ∈ smallPairs,
    ∀ s ∈ listedQuarticSolutions p.1 p.2, ∀ t ∈ listedQuarticSolutions p.1 p.2,
    1 < s.2 → 1 < t.2 →
    (p=(1,4) ∨ p=(2,8) → s.2 ≠ 2 ∧ t.2 ≠ 2) → s.2=t.2 := by decide +kernel

/-- Global interpretation of that finite consequence, using only the explicitly
named Magma calculation for completeness. -/
theorem section46_noninitial_unique (hCalculation : Calculations.Section46Magma)
    {a n x y X Y : ℕ} (hp : (a,n) ∈ smallPairs) (hx : 0 < x) (hX : 0 < X)
    (hy : 1 < y) (hY : 1 < Y)
    (he : x^2+n^2=(a^2+n^2)*y^4) (hE : X^2+n^2=(a^2+n^2)*Y^4)
    (hmid : (a,n)=(1,4) ∨ (a,n)=(2,8) → y ≠ 2 ∧ Y ≠ 2) : y=Y := by
  have hs := (section46_lists_complete hCalculation a n x y hp).mpr ⟨hx,by omega,he⟩
  have ht := (section46_lists_complete hCalculation a n X Y hp).mpr ⟨hX,by omega,hE⟩
  exact listed_noninitial_separation (a,n) hp (x,y) hs (X,Y) ht hy hY hmid

end «JNT-2024».Section4

namespace «JNT-2024».Parameters

/-- A square sequence value >1 gives a positive quartic solution; x may have
either sign in the sequence, so the quartic coordinate is its absolute value. -/
theorem section46_sequence_solution (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hn : P.normAlpha < 0) {a n : ℕ} (ha : P.a=(a : ℤ)) (hd : P.d=(a^2+n^2 : ℕ))
    {k : ℤ} (hs : IsIntegerSquare (P.y h.pell k)) (hy : 1 < P.y h.pell k) :
    ∃ x y : ℕ, 0 < x ∧ 1 < y ∧ P.y h.pell k=(y : ℚ)^2 ∧
      x^2+n^2=(a^2+n^2)*y^4 := by
  obtain ⟨v,hv⟩ := hs
  obtain ⟨X,Y,hX,hY,hXY⟩ := P.section4_integer_coordinates h.pell ⟨v,hv⟩
  have hYY : Y=v^2 := by exact_mod_cast (hY.symm.trans hv)
  have hN : P.normAlpha= -(n : ℤ)^2 := by simp [normAlpha,ha,hb,hd]
  have he : X^2+(n : ℤ)^2=((a : ℤ)^2+(n : ℤ)^2)*v^4 := by
    rw [hYY,hN,hd] at hXY
    push_cast at hXY
    nlinarith only [hXY]
  have hyv : (1 : ℤ) < v^2 := by exact_mod_cast (show (1 : ℚ) < (v : ℚ)^2 by rwa [hv] at hy)
  have hv2 : (v.natAbs : ℤ)^2=v^2 := by simp
  have hX2 : (X.natAbs : ℤ)^2=X^2 := by simp
  have hv4 : (v.natAbs : ℤ)^4=v^4 := by
    rw [show (4 : ℕ)=2*2 from rfl,pow_mul,hv2]
    ring
  have hyNat : 1 < v.natAbs := by
    have hh : (1 : ℤ) < (v.natAbs : ℤ)^2 := by rwa [hv2]
    have hh' : 1 < v.natAbs^2 := by exact_mod_cast hh
    by_contra hlo
    have hh'' : v.natAbs=0 ∨ v.natAbs=1 := by omega
    rcases hh'' with he | he <;> simp [he] at hh'
  have hxne : X ≠ 0 := by
    have hh := (P.section4_coordinate_bounds h hb hn ⟨v,hv⟩ hy).1
    rw [hX] at hh
    intro hz
    simp only [hz,Int.cast_zero,zero_pow (by decide : 2 ≠ 0),Rat.cast_zero] at hh
    have hp : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
    have hh' : (0 : ℝ) ≤ (15/16 : ℝ)*P.d*(P.y h.pell k : ℝ)^2 := by positivity
    linarith
  refine ⟨X.natAbs,v.natAbs,Int.natAbs_pos.mpr hxne,hyNat,?_,?_⟩
  · rw [hv]
    rw [Nat.cast_natAbs,Int.cast_abs,sq_abs]
  · have hh : (X.natAbs : ℤ)^2+(n : ℤ)^2=((a : ℤ)^2+(n : ℤ)^2)*(v.natAbs : ℤ)^4 := by
      simpa only [hX2,hv4] using he
    exact_mod_cast hh

end «JNT-2024».Parameters
