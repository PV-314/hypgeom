module

public import «JNT-2024».AkhtariInput
public import «JNT-2024».DenominatorBounds
public import «JNT-2024».NormalizerBounds
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».Section46Calculation
public import «JNT-2024».Section5AssemblyRevised
public import «JNT-2024».Section62
public import «JNT-2024».Section64
public import «JNT-2024».Section65_68
public import «JNT-2024».Section6Cutoffs
public import «JNT-2024».Section6Families
public import «JNT-2024».Section6Fibonacci
public import «JNT-2024».Section6Normalizers
public import «JNT-2024».Section6Sequence
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Fib.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.FinCases
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section6

theorem negative_square_mod16 {r : ℤ} (hr : r % 4 = 2) : (-(r^2)) % 16 = 12 := by
  have he := Int.emod_add_mul_ediv r 4
  have hform : r=2+4*(r/4) := by omega
  rw [hform]
  ring_nf
  omega

theorem negative_square_dvd {r k : ℤ} (h : k ∣ r) : k^2 ∣ -(r^2) := by
  obtain ⟨v,rfl⟩ := h
  exact ⟨-(v^2), by ring⟩

theorem family64_exceptional (j : ℕ) : (family64 j).Exceptional (family64_admissible j).pell := by
  refine ⟨by simp [family64,unitOne], Or.inl ⟨fibonacciFamily j,family64_square j⟩, Or.inl ⟨rfl,?_,Or.inl ?_⟩⟩
  · rw [family64_norm]
    exact negative_square_mod16 (by dsimp [normRoot64]; omega)
  · simpa [Parameters.baseGcd,family64,unitOne] using (family64_normalizer j).1

theorem family65_exceptional (j : ℕ) :
    (family65 j).Exceptional (families65_68_admissible j).1.pell := by
  obtain ⟨hN,_,_,_,hy,_⟩ := families65_68_values j
  have hp := pellPair_properties j
  refine ⟨by simp [family65,unitOne], Or.inl ⟨pellQ j,hy⟩,Or.inl ⟨rfl,?_,Or.inr ?_⟩⟩
  · rw [hN]; exact negative_square_mod16 (by omega)
  · simpa [Parameters.baseGcd,family65,unitOne] using (families65_68_normalizers j).1

theorem family66_exceptional (j : ℕ) :
    (family66 j).Exceptional (families65_68_admissible j).2.1.pell := by
  obtain ⟨_,hN,_,_,_,hy,_⟩ := families65_68_values j
  have hp := pellPair_properties j
  refine ⟨by simp [family66,unitOne], Or.inr ⟨pellQ j,hy⟩,Or.inr (Or.inl ⟨rfl,?_,?_⟩)⟩
  · rw [hN]
    simpa using negative_square_dvd (k := 8) (Int.dvd_of_emod_eq_zero (by omega : (pellP j+1)%8=0))
  · simpa [Parameters.baseGcd,family66,unitOne] using (families65_68_normalizers j).2.2.1

theorem family67_exceptional (j : ℕ) :
    (family67 j).Exceptional (families65_68_admissible j).2.2.1.pell := by
  obtain ⟨_,_,hN,_,_,_,hy,_⟩ := families65_68_values j
  have hp := pellPair_properties j
  refine ⟨by dsimp [family67,unitTwo]; ring, Or.inl ⟨pellQ j,hy⟩,
    Or.inr (Or.inr (Or.inl ⟨rfl,?_,?_⟩))⟩
  · rw [hN]
    have ho : Odd ((pellP j-1)/2) := Int.odd_iff.mpr (by omega)
    exact ho.pow.neg
  · simp [family67,unitTwo]

theorem family68_exceptional (j : ℕ) :
    (family68 j).Exceptional (families65_68_admissible j).2.2.2.pell := by
  obtain ⟨_,_,_,hN,_,_,_,hy⟩ := families65_68_values j
  have hp := pellPair_properties j
  refine ⟨by dsimp [family68,unitTwo]; ring, Or.inr ⟨pellQ j,hy⟩,
    Or.inr (Or.inr (Or.inr ⟨rfl,?_,?_⟩))⟩
  · rw [hN]
    simpa using negative_square_dvd (k := 4) (Int.dvd_of_emod_eq_zero (by omega : ((pellP j+1)/2)%4=0))
  · simp [family68,unitTwo]


theorem families65_68_two_squares (j : ℕ) :
    AtLeastSquares ((family65 j).y (families65_68_admissible j).1.pell) 2 ∧
    AtLeastSquares ((family66 j).y (families65_68_admissible j).2.1.pell) 2 ∧
    AtLeastSquares ((family67 j).y (families65_68_admissible j).2.2.1.pell) 2 ∧
    AtLeastSquares ((family68 j).y (families65_68_admissible j).2.2.2.pell) 2 := by
  obtain ⟨_,_,_,_,h65,h66,h67,h68⟩ := families65_68_values j
  have hq : 1 < pellQ j := by have hh := (pellPair_properties j).2.1; omega
  refine ⟨?_,?_,?_,?_⟩
  · exact two_square_witnesses (i := 0) (j := 1) (a := 1) (by norm_num) hq
      (by simp [Parameters.y_zero,family65,unitOne]) h65
  · exact two_square_witnesses (i := 0) (j := -1) (a := 1) (by norm_num) hq
      (by simp [Parameters.y_zero,family66,unitOne]) h66
  · exact two_square_witnesses (i := 0) (j := 1) (a := 1) (by norm_num) hq
      (by simp [Parameters.y_zero,family67,unitTwo]) h67
  · exact two_square_witnesses (i := 0) (j := -1) (a := 1) (by norm_num) hq
      (by simp [Parameters.y_zero,family68,unitTwo]) h68

theorem family64_atMost_three (hPrior : Hypergeometric.DenominatorEstimate4)
    (hAkhtari : ExternalResults.AkhtariTheorem11)
    (hCalculation : Calculations.Section46Magma) (j : ℕ) :
    AtMostSquareValues ((family64 j).y (family64_admissible j).pell) 3 :=
  (theorem14_revised hPrior hAkhtari hCalculation (family64 j) (family64_admissible j) rfl
    (family64_negative_square j).1 (family64_negative_square j).2).1

theorem families65_68_atMost_three (hPrior : Hypergeometric.DenominatorEstimate4)
    (hAkhtari : ExternalResults.AkhtariTheorem11)
    (hCalculation : Calculations.Section46Magma) (j : ℕ) :
    AtMostSquareValues ((family65 j).y (families65_68_admissible j).1.pell) 3 ∧
    AtMostSquareValues ((family66 j).y (families65_68_admissible j).2.1.pell) 3 ∧
    AtMostSquareValues ((family67 j).y (families65_68_admissible j).2.2.1.pell) 3 ∧
    AtMostSquareValues ((family68 j).y (families65_68_admissible j).2.2.2.pell) 3 := by
  have h := families65_68_admissible j
  have hn := families65_68_negative_square j
  exact ⟨(theorem14_revised hPrior hAkhtari hCalculation _ h.1 rfl hn.1.1 hn.1.2).1,
    (theorem14_revised hPrior hAkhtari hCalculation _ h.2.1 rfl hn.2.1.1 hn.2.1.2).1,
    (theorem14_revised hPrior hAkhtari hCalculation _ h.2.2.1 rfl hn.2.2.1.1 hn.2.2.1.2).1,
    (theorem14_revised hPrior hAkhtari hCalculation _ h.2.2.2 rfl hn.2.2.2.1 hn.2.2.2.2).1⟩

end «JNT-2024».Section6
