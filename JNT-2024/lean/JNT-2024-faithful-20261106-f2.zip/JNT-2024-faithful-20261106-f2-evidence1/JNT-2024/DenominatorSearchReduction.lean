module

public import «JNT-2024».DenominatorContent
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

/-- Divisibility of radicands gives divisibility of their positive square factors.
This supplies the coefficientwise justification of the content monotonicity
used in the finite search in Lemma 2.3(a). -/
theorem squareFactor_dvd_of_dvd {a b : ℤ} (ha : a ≠ 0) (hb : b ≠ 0)
    (hab : a ∣ b) : squareFactor a ∣ squareFactor b := by
  apply Int.natAbs_dvd_natAbs.mp
  apply (Nat.dvd_iff_prime_pow_dvd_dvd _ _).mpr
  intro p k hp hk
  let : Fact p.Prime := ⟨hp⟩
  have hva := valuation_squarePart p ha
  have hvb := valuation_squarePart p hb
  have hsa := valuation_squarefree_le_one p (squarefreePart_squarefree a)
  have hsb := valuation_squarefree_le_one p (squarefreePart_squarefree b)
  have hvab : padicValInt p a ≤ padicValInt p b := by
    exact ((padicValInt_dvd_iff _ b).mp ((padicValInt_dvd a).trans hab)).resolve_left hb
  have hka : k ≤ padicValInt p (squareFactor a) :=
    (padicValNat_dvd_iff_le (Int.natAbs_ne_zero.mpr (ne_of_gt (squareFactor_pos ha)))).mp hk
  apply (padicValNat_dvd_iff_le
    (Int.natAbs_ne_zero.mpr (ne_of_gt (squareFactor_pos hb)))).mpr
  change k ≤ padicValInt p (squareFactor b)
  omega

/-- The content is nondecreasing under divisibility of nonzero radicands,
including negative radicands. Odd factors therefore cannot reduce it. -/
theorem numeratorContent4_dvd_of_dvd {a b : ℤ} (ha : a ≠ 0) (hb : b ≠ 0)
    (hab : a ∣ b) (r : ℕ) : numeratorContent4 a r ∣ numeratorContent4 b r := by
  apply (numeratorContent4_dvd_iff b r _).mpr
  intro j
  have hcoeff := (numeratorContent4_dvd_iff a r _).mp dvd_rfl j
  apply hcoeff.trans
  unfold scaledIntegralCoefficient4
  exact mul_dvd_mul (mul_dvd_mul_left _ (pow_dvd_pow_of_dvd hab _))
    (pow_dvd_pow_of_dvd (squareFactor_dvd_of_dvd ha hb hab) _)

theorem numeratorContent4_le_of_dvd {a b : ℤ} (ha : a ≠ 0) (hb : b ≠ 0)
    (hab : a ∣ b) (r : ℕ) : numeratorContent4 a r ≤ numeratorContent4 b r :=
  Nat.le_of_dvd (numeratorContent4_pos b r) (numeratorContent4_dvd_of_dvd ha hb hab r)

/-- The finite search does not need separate positive and negative radicands. -/
theorem numeratorContent4_neg {d : ℤ} (hd : d ≠ 0) (r : ℕ) :
    numeratorContent4 (-d) r = numeratorContent4 d r := by
  apply Nat.dvd_antisymm
  · exact numeratorContent4_dvd_of_dvd (neg_ne_zero.mpr hd) hd (by simp) r
  · exact numeratorContent4_dvd_of_dvd hd (neg_ne_zero.mpr hd) (by simp) r

/-- Removing all odd factors gives the smallest content at a fixed 2-adic
valuation. This is the first finite-search reduction printed on page 7. -/
theorem numeratorContent4_two_part_le {d : ℤ} (hd : d ≠ 0) (r : ℕ) :
    numeratorContent4 ((2 : ℤ) ^ padicValInt 2 d) r ≤ numeratorContent4 d r :=
  numeratorContent4_le_of_dvd (by positivity) hd (padicValInt_dvd d) r

/-- Increasing the exponent of two cannot decrease the content. -/
theorem numeratorContent4_two_pow_mono (r : ℕ) :
    Monotone (fun e : ℕ => numeratorContent4 ((2 : ℤ) ^ e) r) := by
  intro e f hef
  exact numeratorContent4_le_of_dvd (by positivity) (by positivity)
    (pow_dvd_pow 2 hef) r

/-- The seven representatives `1,2,4,8,16,32,64` suffice for content lower
bounds. The scale is unchanged at the representative (proved in
`DenominatorBounds`), including every valuation at least six. -/
theorem numeratorContent4_capped_two_part_le {d : ℤ} (hd : d ≠ 0) (r : ℕ) :
    numeratorContent4 ((2 : ℤ) ^ min (padicValInt 2 d) 6) r ≤ numeratorContent4 d r := by
  exact (numeratorContent4_two_pow_mono r (min_le_left _ _)).trans
    (numeratorContent4_two_part_le hd r)

end Hypergeometric
end «JNT-2024»
