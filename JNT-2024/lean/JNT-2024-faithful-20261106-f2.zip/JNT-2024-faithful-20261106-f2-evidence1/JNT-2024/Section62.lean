module

public import «JNT-2024».Section6Families
public import «JNT-2024».Section6Sequence
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.FinCases
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section6

theorem three_square_witnesses {y : ℤ → ℚ} {i j k a b c : ℤ}
    (ha : 0 ≤ a) (hab : a < b) (hbc : b < c)
    (hi : y i = (a : ℚ)^2) (hj : y j = (b : ℚ)^2) (hk : y k = (c : ℚ)^2) :
    AtLeastSquares y 3 := by
  have ha' : (0 : ℚ) ≤ a := by exact_mod_cast ha
  have hab' : (a : ℚ) < b := by exact_mod_cast hab
  have hbc' : (b : ℚ) < c := by exact_mod_cast hbc
  refine ⟨![i,j,k], ?_, ?_⟩
  · intro v w he
    fin_cases v <;> fin_cases w <;> simp [hi,hj,hk] at he ⊢ <;> nlinarith
  · intro v
    fin_cases v
    · exact ⟨a, hi⟩
    · exact ⟨b, hj⟩
    · exact ⟨c, hk⟩

theorem two_square_witnesses {y : ℤ → ℚ} {i j a b : ℤ}
    (ha : 0 ≤ a) (hab : a < b) (hi : y i = (a : ℚ)^2) (hj : y j = (b : ℚ)^2) :
    AtLeastSquares y 2 := by
  have ha' : (0 : ℚ) ≤ a := by exact_mod_cast ha
  have hab' : (a : ℚ) < b := by exact_mod_cast hab
  refine ⟨![i,j], ?_, ?_⟩
  · intro v w he
    fin_cases v <;> fin_cases w <;> simp [hi,hj] at he ⊢ <;> nlinarith
  · intro v
    fin_cases v
    · exact ⟨a, hi⟩
    · exact ⟨b, hj⟩

def quarterSquare (n : ℤ) : ℤ := (n^2-1)/4
def family62a (n : ℤ) : Parameters := unitTwo (quarterSquare n-2) (quarterSquare n)
def family62b (n : ℤ) : Parameters := unitTwo ((n-5)/4) ((n-5)/4+2)

theorem quarterSquare_spec {n : ℤ} (hn : 5 ≤ n) (ho : Odd n) :
    6 ≤ quarterSquare n ∧ n^2 = 4*quarterSquare n+1 := by
  obtain ⟨v,hv⟩ := ho
  have he : n^2 = 4*(v^2+v)+1 := by rw [hv]; ring
  have hsq : 25 ≤ n^2 := by nlinarith
  dsimp [quarterSquare]
  omega

theorem family62a_admissible {n : ℤ} (hn : 5 ≤ n) (ho : Odd n) : (family62a n).Admissible := by
  have hh := quarterSquare_spec hn ho
  exact unitTwo_admissible (by omega) (by omega)

theorem family62a_published {n : ℤ} (hn : 5 ≤ n) (ho : Odd n) :
    (family62a n).a = (n^2-9)/4 ∧
    (family62a n).d = (n^4-2*n^2+17)/16 ∧
    (family62a n).t = (n^2-1)/2 ∧
    (family62a n).normAlpha = 4-n^2 ∧
    (family62a n).y (family62a_admissible hn ho).pell 1 = ((n : ℚ)^2-3)^2/4 ∧
    (family62a n).y (family62a_admissible hn ho).pell (-1) = (n : ℚ)^2 := by
  have hh := quarterSquare_spec hn ho
  have hfour : n^4-2*n^2+17 = 16*((quarterSquare n)^2+1) := by
    nlinarith only [hh.2, congrArg (fun x : ℤ => x^2) hh.2]
  have hq : (n : ℚ)^2 = 4*(quarterSquare n : ℚ)+1 := by exact_mod_cast hh.2
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩
  · dsimp [family62a,unitTwo]; omega
  · dsimp [family62a,unitTwo]; rw [hfour]; omega
  · dsimp [family62a,unitTwo]; omega
  · simp [family62a,unitTwo,Parameters.normAlpha]; nlinarith only [hh.2]
  · rw [Parameters.y_one]
    simp only [family62a,unitTwo]
    push_cast
    nlinarith only [hq, congrArg (fun x : ℚ => x^2) hq]
  · rw [Parameters.y_neg_one]
    simp only [family62a,unitTwo]
    push_cast
    nlinarith only [hq]

theorem family62a_three_squares {n : ℤ} (hn : 5 ≤ n) (ho : Odd n) :
    AtLeastSquares ((family62a n).y (family62a_admissible hn ho).pell) 3 := by
  have hh := quarterSquare_spec hn ho
  have hv := family62a_published hn ho
  have hroot : n < 2*quarterSquare n-1 := by nlinarith only [hn, hh.1, hh.2]
  apply three_square_witnesses (i := 0) (j := -1) (k := 1) (a := 1) (b := n) (c := 2*quarterSquare n-1)
    (by norm_num) (by omega) hroot
  · simp [Parameters.y_zero,family62a,unitTwo]
  · exact hv.2.2.2.2.2
  · rw [hv.2.2.2.2.1]
    have he : (n : ℚ)^2=4*(quarterSquare n : ℚ)+1 := by exact_mod_cast hh.2
    rw [he]
    push_cast
    ring

theorem family62b_admissible {n : ℤ} (hn : 5 < n) (hm : n % 4 = 1) : (family62b n).Admissible := by
  exact unitTwo_admissible (by omega) (by omega)

theorem family62b_published {n : ℤ} (hn : 5 < n) (hm : n % 4 = 1) (_h5 : ¬ 5 ∣ n) :
    (family62b n).a = (n-5)/4 ∧
    (family62b n).d = (n^2+6*n+25)/16 ∧
    (family62b n).t = 2*(family62b n).a+4 ∧
    (family62b n).normAlpha = -n ∧
    (family62b n).y (family62b_admissible hn hm).pell 1 = ((n : ℚ)+1)^2/4 := by
  have he : n = 4*((n-5)/4)+5 := by omega
  have hd : n^2+6*n+25 = 16*((((n-5)/4)+2)^2+1) := by
    nlinarith only [he, congrArg (fun x : ℤ => x^2) he]
  have he' : (n : ℚ) = 4*((((n-5)/4 : ℤ) : ℚ))+5 := by exact_mod_cast he
  refine ⟨rfl, ?_, by dsimp [family62b,unitTwo]; ring, ?_, ?_⟩
  · dsimp [family62b,unitTwo]; rw [hd]; omega
  · simp [family62b,unitTwo,Parameters.normAlpha]; nlinarith only [he]
  · rw [Parameters.y_one]
    simp only [family62b,unitTwo]
    push_cast
    nlinarith only [he', congrArg (fun x : ℚ => x^2) he']

theorem family62b_two_squares {n : ℤ} (hn : 5 < n) (hm : n % 4 = 1) (h5 : ¬ 5 ∣ n) :
    AtLeastSquares ((family62b n).y (family62b_admissible hn hm).pell) 2 := by
  have hv := (family62b_published hn hm h5).2.2.2.2
  have he : 2*((n+1)/2)=n+1 := by omega
  apply two_square_witnesses (i := 0) (j := 1) (a := 1) (b := (n+1)/2) (by norm_num) (by omega)
  · simp [Parameters.y_zero,family62b,unitTwo]
  · rw [hv]
    have he' : (2 : ℚ)*(((n+1)/2 : ℤ) : ℚ) = n+1 := by exact_mod_cast he
    nlinarith only [congrArg (fun x : ℚ => x^2) he']

end «JNT-2024».Section6
