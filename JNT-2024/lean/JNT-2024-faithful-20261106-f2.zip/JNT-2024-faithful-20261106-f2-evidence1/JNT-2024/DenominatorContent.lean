module

public import «JNT-2024».DenominatorDefinitions
public import «JNT-2024».DenominatorRecurrence
public import «JNT-2024».HypergeometricPolynomials
public import «JNT-2024».HypergeometricRecurrence
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

open Polynomial

noncomputable def integralPolynomial4 (r : ℕ) : Polynomial ℤ :=
  ∑ j ∈ Finset.range (r + 1), monomial j (integralCoefficient4 r j)

theorem integralCoefficient4_vanishes {r j : ℕ} (hj : r < j) :
    integralCoefficient4 r j = 0 := by
  apply Int.cast_injective (α := ℚ)
  rw [integralCoefficient4_cast, coefficient_vanishes (1 / 4) hj]
  simp

theorem integralPolynomial4_coeff (r j : ℕ) :
    (integralPolynomial4 r).coeff j = integralCoefficient4 r j := by
  by_cases hj : j < r + 1
  · simp [integralPolynomial4, coeff_monomial, hj]
  · rw [integralCoefficient4_vanishes (by omega : r < j)]
    simp [integralPolynomial4, coeff_monomial, hj]

theorem integralPolynomial4_map (r : ℕ) :
    (integralPolynomial4 r).map (Int.castRingHom ℚ) =
      (denominator4 r : Polynomial ℚ) * Xpoly (1 / 4) r := by
  ext j
  simp only [coeff_map, Int.coe_castRingHom, integralPolynomial4_coeff,
    coeff_natCast_mul, Xpoly_coeff, integralCoefficient4_cast]

theorem rawX4_eq_multiple {r k : ℕ} (hk : oddDenominatorProduct r = denominator4 r * k) :
    rawX4 r = (k : Polynomial ℤ) * integralPolynomial4 r := by
  apply Polynomial.map_injective (Int.castRingHom ℚ) Int.cast_injective
  rw [rawX4_map, Polynomial.map_mul, Polynomial.map_natCast, integralPolynomial4_map, hk]
  push_cast
  ring

noncomputable def shiftedIntegralPolynomial4 (r : ℕ) : Polynomial ℤ :=
  (integralPolynomial4 r).comp (1 - Polynomial.X)

/-- The coefficientwise power of eight obtained from the integral recurrence. -/
theorem eight_pow_dvd_shiftedCoefficient {r j : ℕ} (hj : j ≤ r) :
    (8 : ℤ) ^ (r - j) ∣ (shiftedIntegralPolynomial4 r).coeff j := by
  obtain ⟨k, hk⟩ := denominator4_dvd_oddDenominatorProduct r
  have hkodd : Odd k := (oddDenominatorProduct_odd r).of_dvd_nat
    ⟨denominator4 r, by simpa only [mul_comm] using hk⟩
  have hpoly := rawX4_comp_eight r
  rw [rawX4_eq_multiple hk, Polynomial.mul_comp, Polynomial.natCast_comp] at hpoly
  have he : (integralPolynomial4 r).comp (1 - 8 * Polynomial.X) =
      (shiftedIntegralPolynomial4 r).comp (C 8 * Polynomial.X) := by
    simp [shiftedIntegralPolynomial4, Polynomial.comp_assoc]
  rw [he] at hpoly
  have hcoeff := congrArg (fun p : Polynomial ℤ => p.coeff j) hpoly
  have hp : (8 : Polynomial ℤ) ^ r = C ((8 : ℤ) ^ r) := by simp
  rw [hp, coeff_natCast_mul, comp_C_mul_X_coeff, coeff_C_mul] at hcoeff
  have hd : (8 : ℤ) ^ r ∣ (k : ℤ) * ((shiftedIntegralPolynomial4 r).coeff j * 8 ^ j) :=
    ⟨(rawScaledX4 r).coeff j, hcoeff⟩
  have hn : (8 : ℕ) ^ r ∣ k * ((shiftedIntegralPolynomial4 r).coeff j).natAbs * 8 ^ j := by
    have h := Int.natAbs_dvd_natAbs.mpr hd
    simpa [Int.natAbs_pow, Int.natAbs_mul, mul_assoc] using h
  have hcop : Nat.Coprime (8 ^ r) k := by
    convert hkodd.coprime_two_left.pow_left (3 * r) using 1
    norm_num [pow_mul]
  have hn' : 8 ^ r ∣ ((shiftedIntegralPolynomial4 r).coeff j).natAbs * 8 ^ j :=
    hcop.dvd_of_dvd_mul_left (by simpa only [mul_assoc] using hn)
  have he : (8 : ℕ) ^ r = 8 ^ (r - j) * 8 ^ j := by
    rw [← pow_add, Nat.sub_add_cancel hj]
  rw [he] at hn'
  have hn'' : 8 ^ (r - j) ∣ ((shiftedIntegralPolynomial4 r).coeff j).natAbs :=
    (mul_dvd_mul_iff_right (by positivity : (8 : ℕ) ^ j ≠ 0)).mp hn'
  exact_mod_cast (Int.natCast_dvd.mpr hn'')

theorem integralPolynomial4_natDegree_le (r : ℕ) : (integralPolynomial4 r).natDegree ≤ r := by
  apply Polynomial.natDegree_sum_le_of_forall_le
  intro j hj
  exact (Polynomial.natDegree_monomial_le _).trans (by have := Finset.mem_range.mp hj; omega)

theorem shiftedIntegralPolynomial4_natDegree_le (r : ℕ) :
    (shiftedIntegralPolynomial4 r).natDegree ≤ r := by
  have hlin : (1 - Polynomial.X : Polynomial ℤ).natDegree ≤ 1 :=
    (Polynomial.natDegree_sub_le _ _).trans (by simp)
  exact Polynomial.natDegree_comp_le.trans
    ((Nat.mul_le_mul (integralPolynomial4_natDegree_le r) hlin).trans (by simp))

theorem rawScaledX4_eval_zero_pos (r : ℕ) : 0 < (rawScaledX4 r).eval 0 := by
  induction r using Nat.twoStepInduction with
  | zero => simp [rawScaledX4]
  | one => simp [rawScaledX4]
  | more r _ ih =>
    simpa [rawScaledX4] using mul_pos (by positivity : (0 : ℤ) < 2 * r + 3) ih

theorem shiftedIntegralPolynomial4_coeff_zero_ne (r : ℕ) :
    (shiftedIntegralPolynomial4 r).coeff 0 ≠ 0 := by
  obtain ⟨k, hk⟩ := denominator4_dvd_oddDenominatorProduct r
  have hh := rawX4_comp_eight r
  rw [rawX4_eq_multiple hk] at hh
  have he := congrArg (fun p : Polynomial ℤ => p.eval 0) hh
  have hc : (k : ℤ) * (shiftedIntegralPolynomial4 r).coeff 0 =
      8 ^ r * (rawScaledX4 r).eval 0 := by
    simpa [shiftedIntegralPolynomial4, coeff_zero_eq_eval_zero] using he
  have hp := mul_pos (by positivity : (0 : ℤ) < 8 ^ r) (rawScaledX4_eval_zero_pos r)
  intro hz
  rw [hz, mul_zero] at hc
  omega

/-- The scalar coefficient of the appropriate basis vector after substituting `sqrt(d) x`.
Even powers use `1`; odd powers use `sqrt(sf(d))`. -/
noncomputable def scaledIntegralCoefficient4 (d : ℤ) (r j : ℕ) : ℤ :=
  (shiftedIntegralPolynomial4 r).coeff j * d ^ (j / 2) * squareFactor d ^ (j % 2)

/-- The exact common scalar divisor in the order `ℤ[sqrt(sf(d))]`. -/
noncomputable def numeratorContent4 (d : ℤ) (r : ℕ) : ℕ :=
  (Finset.range (r + 1)).gcd (fun j => (scaledIntegralCoefficient4 d r j).natAbs)

/-- The zero-index content used in the last sentence of Lemma 2.3(a)'s proof. -/
theorem numeratorContent4_zero (d : ℤ) : numeratorContent4 d 0 = 1 := by
  norm_num [numeratorContent4, scaledIntegralCoefficient4, shiftedIntegralPolynomial4,
    integralPolynomial4, integralCoefficient4, denominator4_zero, coefficient_zero]

theorem scaledIntegralCoefficient4_vanishes (d : ℤ) {r j : ℕ} (hj : r < j) :
    scaledIntegralCoefficient4 d r j = 0 := by
  unfold scaledIntegralCoefficient4
  rw [Polynomial.coeff_eq_zero_of_natDegree_lt
    ((shiftedIntegralPolynomial4_natDegree_le r).trans_lt hj)]
  simp

theorem numeratorContent4_dvd_iff (d : ℤ) (r n : ℕ) :
    n ∣ numeratorContent4 d r ↔ ∀ j : ℕ, (n : ℤ) ∣ scaledIntegralCoefficient4 d r j := by
  rw [numeratorContent4, Finset.dvd_gcd_iff]
  constructor
  · intro h j
    by_cases hj : j < r + 1
    · exact Int.natCast_dvd.mpr (h j (Finset.mem_range.mpr hj))
    · rw [scaledIntegralCoefficient4_vanishes d (by omega : r < j)]
      exact dvd_zero _
  · intro h j _
    exact Int.natCast_dvd.mp (h j)

theorem numeratorContent4_pos (d : ℤ) (r : ℕ) : 0 < numeratorContent4 d r := by
  apply Nat.pos_of_ne_zero
  rw [numeratorContent4, Finset.gcd_ne_zero_iff]
  refine ⟨0, by simp, ?_⟩
  simpa [scaledIntegralCoefficient4] using shiftedIntegralPolynomial4_coeff_zero_ne r

theorem squareFactor_two_valuation {d : ℤ} (hd : d ≠ 0) :
    padicValInt 2 (squareFactor d) = padicValInt 2 d / 2 := by
  have hh := valuation_squarePart 2 hd
  have hs := valuation_squarefree_le_one 2 (squarefreePart_squarefree d)
  omega

theorem mul_div_two (a b : ℕ) :
    a * (b / 2) + (a / 2) * (b % 2) = a * b / 2 := by
  have hb := Nat.mod_add_div b 2
  have ha := Nat.mod_add_div a 2
  have hb' : b % 2 = 0 ∨ b % 2 = 1 := by omega
  rcases hb' with hb' | hb'
  · rw [hb']
    have he : a * b = 2 * (a * (b / 2)) := by nlinarith
    rw [he]
    omega
  · rw [hb']
    have he : a * b = 2 * (a * (b / 2) + a / 2) + a % 2 := by nlinarith
    rw [he]
    omega

/-- Uniform two-adic lower bound, including odd valuations and the saturation at six. -/
theorem two_pow_dvd_numeratorContent4 {d : ℤ} (hd : d ≠ 0) (r : ℕ) :
    2 ^ (min (padicValInt 2 d) 6 * r / 2) ∣ numeratorContent4 d r := by
  apply (numeratorContent4_dvd_iff d r _).mpr
  intro j
  by_cases hj : j ≤ r
  · have hc : (2 : ℤ) ^ (3 * (r - j)) ∣ (shiftedIntegralPolynomial4 r).coeff j := by
      simpa [pow_mul] using eight_pow_dvd_shiftedCoefficient hj
    have hdv : (2 : ℤ) ^ padicValInt 2 d ∣ d :=
      (padicValInt_dvd_iff _ d).mpr (Or.inr le_rfl)
    have hsv : (2 : ℤ) ^ (padicValInt 2 d / 2) ∣ squareFactor d := by
      rw [← squareFactor_two_valuation hd]
      exact (padicValInt_dvd_iff _ _).mpr (Or.inr le_rfl)
    have hw := mul_dvd_mul (pow_dvd_pow_of_dvd hdv (j / 2))
      (pow_dvd_pow_of_dvd hsv (j % 2))
    rw [← pow_mul, ← pow_mul, ← pow_add, mul_div_two] at hw
    have ht := mul_dvd_mul hc hw
    rw [← pow_add] at ht
    have hk : min (padicValInt 2 d) 6 * r / 2 ≤
        3 * (r - j) + padicValInt 2 d * j / 2 := by
      have hmul := Nat.mul_le_mul_right j (min_le_left (padicValInt 2 d) 6)
      have hmul' := Nat.mul_le_mul_right (r - j) (min_le_right (padicValInt 2 d) 6)
      have he : min (padicValInt 2 d) 6 * r =
          min (padicValInt 2 d) 6 * j + min (padicValInt 2 d) 6 * (r - j) := by
        rw [← mul_add, Nat.add_sub_of_le hj]
      omega
    exact (pow_dvd_pow (2 : ℤ) hk).trans
      (by simpa only [Nat.cast_pow, Nat.cast_ofNat, scaledIntegralCoefficient4, mul_assoc] using ht)
  · rw [scaledIntegralCoefficient4_vanishes d (by omega : r < j)]
    exact dvd_zero _

end Hypergeometric
end «JNT-2024»
