module

public import «JNT-2024».GammaBounds
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

noncomputable def remainderCoefficient (r : ℕ) : ℚ :=
  (ascPochhammer ℚ (r + 1)).eval (1 / 4) * r.factorial / (2 * r + 1).factorial


theorem scaledRemainder_eq (r : ℕ) : scaledRemainder r = 4 ^ r * remainderCoefficient r := by
  induction r with
  | zero => norm_num [scaledRemainder, remainderCoefficient, ascPochhammer_succ_eval]
  | succ r ih =>
    rw [scaledRemainder, ih]
    simp only [remainderCoefficient, ascPochhammer_succ_eval]
    rw [show 2 * (r + 1) + 1 = (2 * r + 1) + 1 + 1 by omega]
    simp only [Nat.factorial_succ, Nat.cast_mul, Nat.cast_add, Nat.cast_one, pow_succ]
    field_simp; ring

theorem remainderCoefficient_pos (r : ℕ) : 0 < remainderCoefficient r := by
  have hh := scaledRemainder_pos r
  rw [scaledRemainder_eq] at hh
  exact (mul_pos_iff_of_pos_left (by positivity : (0 : ℚ) < 4 ^ r)).mp hh

/-- The ratio of successive products printed in the proof of Lemma 2.3(b). -/
theorem remainderCoefficient_successive_ratio (r : ℕ) :
    remainderCoefficient (r + 1) / remainderCoefficient r =
      (1 / 4 : ℚ) * ((r : ℚ) + 5 / 4) / (r + 3 / 2) := by
  have hcoeff := ne_of_gt (remainderCoefficient_pos r)
  have hscale := scaledRemainder_eq (r + 1)
  rw [scaledRemainder, scaledRemainder_eq r] at hscale
  have hpow : (4 : ℚ) ^ r ≠ 0 := by positivity
  have hden : (4 : ℚ) * r + 6 ≠ 0 := by positivity
  rw [div_eq_iff hden] at hscale
  have he : (4 : ℚ) ^ r *
      (remainderCoefficient (r + 1) * (16 * r + 24) -
        remainderCoefficient r * (4 * r + 5)) = 0 := by
    rw [pow_succ] at hscale
    nlinarith only [hscale]
  have hz := (mul_eq_zero.mp he).resolve_left hpow
  field_simp
  nlinarith only [hz]

theorem lemma23b_remainder {r : ℕ} (hr : 1 ≤ r) :
    (5 : ℝ) / (24 * 4 ^ r * (r : ℝ) ^ (1 / 4 : ℝ)) ≤ (remainderCoefficient r : ℝ) := by
  have hr0 : (0 : ℝ) < r := by exact_mod_cast (by omega : 0 < r)
  have hroot : 0 < (r : ℝ) ^ (1 / 4 : ℝ) := Real.rpow_pos_of_pos hr0 _
  have hp : ((r : ℝ) ^ (1 / 4 : ℝ)) ^ 4 = (r : ℝ) := by
    simpa using Real.rpow_inv_natCast_pow hr0.le (by decide : (4 : ℕ) ≠ 0)
  have hspos : (0 : ℝ) < (scaledRemainder r : ℝ) := by exact_mod_cast scaledRemainder_pos r
  have hh : (5 / 24 : ℝ) ^ 4 ≤ (r : ℝ) * (scaledRemainder r : ℝ) ^ 4 := by
    have hh' := (Rat.cast_le (K := ℝ)).mpr (scaledRemainder_fourth_bound hr)
    simpa only [Rat.cast_pow, Rat.cast_div, Rat.cast_ofNat, Rat.cast_mul, Rat.cast_natCast] using hh'
  have hs : 5 ≤ 24 * (scaledRemainder r : ℝ) * (r : ℝ) ^ (1 / 4 : ℝ) := by
    apply le_of_pow_le_pow_left₀ (by decide : (4 : ℕ) ≠ 0) (by positivity)
    rw [mul_pow, mul_pow, hp]
    nlinarith only [hh]
  have he : (scaledRemainder r : ℝ) = 4 ^ r * (remainderCoefficient r : ℝ) := by
    exact_mod_cast scaledRemainder_eq r
  apply (div_le_iff₀ (by positivity)).mpr
  rw [he] at hs
  nlinarith only [hs]

/-- Both inequalities in Lemma 2.3(b). -/
theorem lemma23b {r : ℕ} (hr : 1 ≤ r) :
    (5 : ℝ) / (24 * 4 ^ r * (r : ℝ) ^ (1 / 4 : ℝ)) ≤ (remainderCoefficient r : ℝ) ∧
    (r.factorial : ℝ) * Real.Gamma (3 / 4) / Real.Gamma (r + 3 / 4) ≤
      4 * (r : ℝ) ^ (1 / 4 : ℝ) / 3 := ⟨lemma23b_remainder hr, lemma23b_gamma hr⟩

/-- Both bounds are attained at the initial positive index. -/
theorem lemma23b_at_one :
    (remainderCoefficient 1 : ℝ) = 5 / 96 ∧
    Real.Gamma (3 / 4) / Real.Gamma (7 / 4) = 4 / 3 := by
  constructor
  · norm_num [remainderCoefficient, ascPochhammer_succ_eval]
  · have hh := gammaRatio_eq_gamma 1
    norm_num [gammaRatio] at hh
    linarith

end Hypergeometric
end «JNT-2024»
