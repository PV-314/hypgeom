module

public import «JNT-2024».Monotonicity
public import «JNT-2024».Section4Sequence
public import «JNT-2024».Section5Growth
public import «JNT-2024».Sequence
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.Deriv.MeanValue
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- The printed nonadjacent lower bound, extracted from the existing Lemma 3.5
growth application, without the former finite-index shortcut. -/
theorem lemma52_growth_published (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hn : P.normAlpha < 0) (hK : P.IsNegativeCutoff h.pell (-1))
    {k : ℤ} (hk : 2 ≤ k.natAbs) :
    |(P.normAlpha:ℝ)| * P.d * (P.u:ℝ)^4 / 10 ≤ (P.y h.pell k:ℝ) := by
  have hk0 : k ≠ 0 := by intro he; simp [he] at hk
  have hg := P.section5_geometric_bound h hb hn hK hk0
  have hr : (2:ℝ) ≤ 2*P.d*(P.u:ℝ)^2/5 := by
    have hd : (5:ℝ) ≤ P.d*(P.u:ℝ)^2 := by exact_mod_cast P.section5_five_le_du_square h
    linarith
  have hp : 2*P.d*(P.u:ℝ)^2/5 ≤ (2*P.d*(P.u:ℝ)^2/5)^(k.natAbs-1) := by
    simpa only [pow_one] using pow_le_pow_right₀ (by linarith : (1:ℝ) ≤ 2*P.d*(P.u:ℝ)^2/5)
      (show 1 ≤ k.natAbs-1 by omega)
  have hm := mul_le_mul_of_nonneg_left hp
    (show 0 ≤ |(P.normAlpha:ℝ)| * (P.u:ℝ)^2/4 by positivity)
  nlinarith only [hg,hm]

/-- The three numerical comparisons printed in Lemma 5.2. -/
theorem lemma52_growth_comparisons (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hn : P.normAlpha < 0) (hK : P.IsNegativeCutoff h.pell (-1)) (hd : 112 ≤ P.d)
    {k : ℤ} (hk : 2 ≤ k.natAbs) :
    (85625/10000:ℝ) * |(P.normAlpha:ℝ)| < (P.y h.pell k:ℝ) ∧
    (2 ≤ P.u → (179:ℝ) * |(P.normAlpha:ℝ)| < (P.y h.pell k:ℝ)) ∧
    (343 ≤ P.d → (343/10:ℝ) * |(P.normAlpha:ℝ)| ≤ (P.y h.pell k:ℝ)) := by
  have hg := P.lemma52_growth_published h hb hn hK hk
  have hN := (P.section4_norm_range h hb hn).1
  have hu1 : (1:ℤ) ≤ P.u^4 := by
    have hs : (1:ℤ) ≤ P.u^2 := by nlinarith [h.u_pos]
    nlinarith only [hs,sq_nonneg (P.u^2-1)]
  have hdu : P.d ≤ P.d*P.u^4 := by nlinarith [mul_nonneg h.d_pos.le (sub_nonneg.mpr hu1)]
  have hmul (c : ℤ) (hc : c ≤ P.d*P.u^4) :
      (c:ℝ) * |(P.normAlpha:ℝ)| ≤ |(P.normAlpha:ℝ)| * P.d * (P.u:ℝ)^4 := by
    have hcR : (c:ℝ) ≤ (P.d:ℝ)*(P.u:ℝ)^4 := by exact_mod_cast hc
    simpa only [mul_assoc,mul_comm (c:ℝ) |(P.normAlpha:ℝ)|] using
      mul_le_mul_of_nonneg_left hcR hN.le
  refine ⟨?_,?_,?_⟩
  · have hh := hmul 112 (by omega)
    norm_num at hh
    nlinarith only [hh,hg,hN]
  · intro hu
    have hu4 : (16:ℤ) ≤ P.u^4 := by
      have hs : (4:ℤ) ≤ P.u^2 := by nlinarith
      nlinarith only [hs,sq_nonneg (P.u^2-4)]
    have hh := hmul 1792 (by nlinarith [mul_nonneg (sub_nonneg.mpr hd) (sub_nonneg.mpr hu4)])
    norm_num at hh
    nlinarith only [hh,hg,hN]
  · intro hd343
    have hh := hmul 343 (by omega)
    norm_num at hh
    nlinarith only [hh,hg]


/-- The stated norm lower bounds after excluding norm -1. -/
theorem lemma52_norm_lower_bounds (P : Parameters) (hn : P.normAlpha < 0)
    (hNs : IsSquare (-P.normAlpha)) (hn1 : P.normAlpha ≠ -1) :
    (Even P.normAlpha → 4 ≤ -P.normAlpha) ∧ (Odd P.normAlpha → 9 ≤ -P.normAlpha) := by
  obtain ⟨n,he⟩ := hNs
  have he' : -P.normAlpha=n^2 := by simpa only [pow_two] using he
  constructor
  · intro _
    by_cases hlo : n ≤ -2
    · nlinarith
    by_cases hhi : 2 ≤ n
    · nlinarith
    have hnb : -1 ≤ n ∧ n ≤ 1 := by omega
    interval_cases n <;> norm_num at he' <;> omega
  · rintro ⟨v,hv⟩
    by_cases hlo : n ≤ -3
    · nlinarith
    by_cases hhi : 3 ≤ n
    · nlinarith
    have hnb : -2 ≤ n ∧ n ≤ 2 := by omega
    interval_cases n <;> norm_num at he' <;> omega


end «JNT-2024».Parameters
