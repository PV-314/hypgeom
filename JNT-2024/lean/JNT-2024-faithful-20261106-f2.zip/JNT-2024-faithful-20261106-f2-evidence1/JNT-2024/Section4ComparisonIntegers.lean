module

public import «JNT-2024».FourthRootGeometry
public import «JNT-2024».GapLattice
public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».Section2Complex
public import «JNT-2024».Section2Gaussian
public import «JNT-2024».Section4Gaussian
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

theorem quadraticPoint_gaussian_U (r s : ℤ) :
    quadraticPoint 1 r s = Section2.U (-1) (2 * r) (2 * s) := by
  rw [gaussian_U]
  apply Complex.ext <;> simp [quadraticPoint]

theorem fourthPhase_integral {η : ℂ} (hη : FourthPhase η) : IsIntegral ℤ η := by
  have hI : IsIntegral ℤ Complex.I := by
    have hh := gaussian_U_integral 0 1
    rw [gaussian_U] at hh
    simpa only [Int.cast_zero, Int.cast_one, one_mul, zero_add] using hh
  rcases hη with rfl | rfl | rfl | rfl
  · exact isIntegral_one
  · exact isIntegral_one.neg
  · exact hI
  · exact hI.neg

theorem fourthPhase_mem_gaussianField {η : ℂ} (hη : FourthPhase η) : η ∈ Section2.gaussianField := by
  rcases hη with rfl | rfl | rfl | rfl
  · exact one_mem _
  · exact neg_mem (one_mem _)
  · exact Section2.I_mem_gaussianField
  · exact neg_mem Section2.I_mem_gaussianField

/-- The comparison pair belongs to the Gaussian ring of integers, including
the fourth-root phase multiplying its numerator. -/
theorem comparison_integers (r s R S : ℤ) {η : ℂ} (hη : FourthPhase η) :
    ∃ p₀ q₀ : Section2.GaussianField, IsIntegral ℤ p₀ ∧ IsIntegral ℤ q₀ ∧
      Section2.gaussianEmbedding p₀ = η * star (star (quadraticPoint 1 r s) * quadraticPoint 1 R S) ∧
      Section2.gaussianEmbedding q₀ = star (quadraticPoint 1 r s) * quadraticPoint 1 R S := by
  have hai : IsIntegral ℤ (quadraticPoint 1 r s) := by
    rw [quadraticPoint_gaussian_U]
    exact gaussian_U_integral r s
  have hbi : IsIntegral ℤ (quadraticPoint 1 R S) := by
    rw [quadraticPoint_gaussian_U]
    exact gaussian_U_integral R S
  have ham : quadraticPoint 1 r s ∈ Section2.gaussianField := by
    rw [quadraticPoint_gaussian_U]
    exact Section2.U_mem_gaussianField _ _
  have hbm : quadraticPoint 1 R S ∈ Section2.gaussianField := by
    rw [quadraticPoint_gaussian_U]
    exact Section2.U_mem_gaussianField _ _
  let q := star (quadraticPoint 1 r s) * quadraticPoint 1 R S
  have hqi : IsIntegral ℤ q := (hai.map (starRingEnd ℂ).toIntAlgHom).mul hbi
  have hqm : q ∈ Section2.gaussianField := mul_mem (Section2.conj_mem_gaussianField ham) hbm
  have hpi : IsIntegral ℤ (η * star q) :=
    (fourthPhase_integral hη).mul (hqi.map (starRingEnd ℂ).toIntAlgHom)
  have hpm : η * star q ∈ Section2.gaussianField :=
    mul_mem (fourthPhase_mem_gaussianField hη) (Section2.conj_mem_gaussianField hqm)
  obtain ⟨p₀, hp₀⟩ := hpm
  obtain ⟨q₀, hq₀⟩ := hqm
  refine ⟨p₀, q₀, ?_, ?_, hp₀, hq₀⟩
  · apply (isIntegral_algHom_iff Section2.gaussianEmbedding.toIntAlgHom Section2.gaussianEmbedding.injective).mp
    simpa only [RingHom.toIntAlgHom_apply, hp₀] using hpi
  · apply (isIntegral_algHom_iff Section2.gaussianEmbedding.toIntAlgHom Section2.gaussianEmbedding.injective).mp
    simpa only [RingHom.toIntAlgHom_apply, hq₀] using hqi

end «JNT-2024».Section4
