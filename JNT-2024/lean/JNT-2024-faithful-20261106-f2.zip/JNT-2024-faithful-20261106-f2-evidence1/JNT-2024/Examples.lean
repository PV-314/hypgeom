module

public import «JNT-2024».Sequence
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Data.Finset.Card
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

/-! Exact checks of examples printed in the paper. These prove only the stated
values and hypotheses, not any global bound on the number of squares. -/

namespace «JNT-2024».Examples


/-- The explicit example in Section 6.4. -/
def section64 : Parameters := ⟨61, 1, 9805, 99, 1⟩


end «JNT-2024».Examples
