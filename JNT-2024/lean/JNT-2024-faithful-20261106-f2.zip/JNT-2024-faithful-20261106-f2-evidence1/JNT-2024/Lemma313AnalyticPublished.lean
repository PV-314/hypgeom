module

public import «JNT-2024».GrowthBounds
public import «JNT-2024».Monotonicity
public import «JNT-2024».NormalizerBounds
public import «JNT-2024».NormalizerFormula
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- The printed strict 0.091 sqrt(d) lower estimate. -/
theorem lemma313_first_analytic {d N M y : ℝ} (hd : 0 < d) (hN : 0 < N)
    (hM : 2 ≤ M) (hy : N / 4 ≤ y) :
    (91 / 1000 : ℝ) * Real.sqrt d < (1832 / 10000 : ℝ) * M * Real.sqrt d * y / N := by
  have hs := Real.sqrt_pos.mpr hd
  have hMy : N / 2 ≤ M * y := by
    have hh := mul_le_mul hM hy (by positivity : 0 ≤ N / 4) (by linarith : 0 ≤ M)
    nlinarith only [hh]
  have hh := mul_le_mul_of_nonneg_right hMy hs.le
  apply (lt_div_iff₀ hN).mpr
  have hpos := mul_pos hN hs
  nlinarith only [hh,hpos]

/-- Both inequalities in the printed 0.66 sqrt(d) comparison. -/
theorem lemma313_second_analytic {d N M y : ℝ} (hd : 0 < d) (hN : 1 ≤ N)
    (hM : 0 < M) (hMu : M ≤ 8 * Real.sqrt N) (hy : N / 4 ≤ y) :
    (66 / 100 : ℝ) * Real.sqrt d ≤
      (2112 / 100 : ℝ) * Real.sqrt d * (N / 4) / (8 * Real.sqrt N) ∧
    (2112 / 100 : ℝ) * Real.sqrt d * (N / 4) / (8 * Real.sqrt N) ≤
      (2112 / 100 : ℝ) * Real.sqrt d * y / M := by
  have hNp : 0 < N := by linarith
  have hsN := Real.sqrt_pos.mpr hNp
  have hsD := Real.sqrt_pos.mpr hd
  have hNs : Real.sqrt N ≤ N := by
    have hh := Real.sq_sqrt hNp.le
    nlinarith [Real.sqrt_nonneg N]
  constructor
  · apply (le_div_iff₀ (mul_pos (by norm_num) hsN)).mpr
    have hh := mul_le_mul_of_nonneg_left hNs hsD.le
    nlinarith only [hh]
  · calc
      _ ≤ (2112 / 100 : ℝ) * Real.sqrt d * y / (8 * Real.sqrt N) := by
        exact div_le_div_of_nonneg_right
          (mul_le_mul_of_nonneg_left hy (by positivity)) (by positivity)
      _ ≤ _ := div_le_div_of_nonneg_left (by have : 0 ≤ y := le_trans (by positivity) hy; positivity) hM hMu

theorem lemma313_first_cutoff {d : ℝ} (hd : 155 ≤ d) :
    (113 / 100 : ℝ) < (91 / 1000 : ℝ) * Real.sqrt d := by
  have hs := Real.sq_sqrt (by linarith : 0 ≤ d)
  have hp := Real.sqrt_nonneg d
  nlinarith

theorem lemma313_second_cutoff {d : ℝ} (hd : 109000 ≤ d) :
    (190 : ℝ) < (66 / 100 : ℝ) * Real.sqrt d := by
  have hs := Real.sq_sqrt (by linarith : 0 ≤ d)
  have hp := Real.sqrt_nonneg d
  nlinarith

namespace Parameters

/-- Existing proof from Section5Bounds.section5_seed_bound, extracted here
without changing its argument because Section 3 cannot import Section 5. -/
theorem sequence_seed_bound_published (P : Parameters) (h : P.Admissible) (hb : P.b = 1)
    (hn : P.normAlpha < 0) {k : ℤ} (hk : k ≠ 0) :
    |(P.normAlpha : ℝ)| * (P.u : ℝ) ^ 2 / 4 ≤ (P.y h.pell k : ℝ) := by
  have hh : P.lowerSeed ≤ P.y h.pell k := by
    rcases lt_or_gt_of_ne hk with hk | hk
    · exact P.lowerSeed_le_y_negative h hn k hk
    · have hm := (P.y_strictMono_nonnegative h hn).monotone
        (show 1 ≤ k.toNat by omega)
      rw [Int.toNat_of_nonneg (by omega : 0 ≤ k)] at hm
      exact (P.lowerSeed_le_y_one h hn).trans hm
  dsimp [lowerSeed] at hh
  rw [hb] at hh
  norm_num only [Int.cast_one, one_pow, mul_one] at hh
  exact_mod_cast hh

/-- The actual input bounds M>=2, M<=8 sqrt(|N|), y>=|N|/4 used in the printed reduction. -/
theorem lemma313_analytic_inputs (P : Parameters) (h : P.Admissible) (hb : P.b = 1)
    (hn : P.normAlpha < 0) {k X Y ν : ℤ} (hx : P.x h.pell k = X) (hy : P.y h.pell k = Y)
    (hybig : 1 < Y) (hν : ν = 1 ∨ ν = -1) :
    let M := Approximation.normalizerProduct (squarefreePart P.normAlpha) (2 * X)
      (2 * ν * squareFactor P.normAlpha)
    1 ≤ |(P.normAlpha : ℝ)| ∧ 2 ≤ M ∧ M ≤ 8 * Real.sqrt |(P.normAlpha : ℝ)| ∧
      |(P.normAlpha : ℝ)| / 4 ≤ (Y : ℝ) := by
  let M := Approximation.normalizerProduct (squarefreePart P.normAlpha) (2 * X)
    (2 * ν * squareFactor P.normAlpha)
  have hc : Int.gcd P.a P.b = 1 := by simp [hb]
  have hMe : M = Real.sqrt P.normalizerSquare := (P.lemma312 h hc hn hx hy hν).1
  have hMsq : M ^ 2 = (P.normalizerSquare : ℝ) := by rw [hMe,Real.sq_sqrt (by positivity)]
  have hMp : 0 ≤ M := Approximation.normalizerProduct_nonneg _ _ _
  have hB := P.normalizerSquare_bounds h hc (ne_of_lt hn)
  have hN : 1 ≤ |(P.normAlpha : ℝ)| := by
    have hi : (1 : ℤ) ≤ |P.normAlpha| := by rw [abs_of_neg hn]; omega
    exact_mod_cast hi
  have hMlower : (4 : ℝ) ≤ P.normalizerSquare := by exact_mod_cast hB.2.1
  have hMupper : (P.normalizerSquare : ℝ) ≤ 64 * |(P.normAlpha : ℝ)| := by
    have hh : (P.normalizerSquare : ℤ) ≤ 64 * |P.normAlpha| := by
      simpa only [Int.natCast_mul, Nat.cast_ofNat, Int.natCast_natAbs] using
        (Int.ofNat_le.mpr hB.2.2)
    exact_mod_cast hh
  have hMu : M ≤ 8 * Real.sqrt |(P.normAlpha : ℝ)| := by
    have hs := Real.sq_sqrt (abs_nonneg (P.normAlpha : ℝ))
    have hp := Real.sqrt_nonneg |(P.normAlpha : ℝ)|
    nlinarith only [hMsq,hMupper,hs,hp,hMp]
  have hk : k ≠ 0 := by
    intro hk
    rw [hk,P.y_zero h.pell,hb] at hy
    norm_num at hy
    have : Y = 1 := by exact_mod_cast hy.symm
    omega
  have hs := P.sequence_seed_bound_published h hb hn hk
  rw [hy] at hs
  have hu : (1 : ℝ) ≤ (P.u : ℝ) ^ 2 := by
    have hi : 1 ≤ P.u ^ 2 := by nlinarith [h.u_pos]
    exact_mod_cast hi
  have hprod := mul_le_mul_of_nonneg_left hu (abs_nonneg (P.normAlpha : ℝ))
  refine ⟨hN,by nlinarith only [hMsq,hMlower,hMp],hMu,?_⟩
  exact le_trans (by nlinarith only [hprod]) hs

/-- The two printed comparisons, now applied to the actual sequence and its
normalizer; no approximation estimate is assumed as an extra hypothesis. -/
theorem lemma313_analytic_comparisons (P : Parameters) (h : P.Admissible) (hb : P.b = 1)
    (hn : P.normAlpha < 0) {k X Y ν : ℤ} (hx : P.x h.pell k = X) (hy : P.y h.pell k = Y)
    (hybig : 1 < Y) (hν : ν = 1 ∨ ν = -1) :
    let M := Approximation.normalizerProduct (squarefreePart P.normAlpha) (2 * X)
      (2 * ν * squareFactor P.normAlpha)
    (91 / 1000 : ℝ) * Real.sqrt P.d <
      (1832 / 10000 : ℝ) * M * Real.sqrt P.d * (Y : ℝ) / |(P.normAlpha : ℝ)| ∧
    (66 / 100 : ℝ) * Real.sqrt P.d ≤ (2112 / 100 : ℝ) * Real.sqrt P.d * (Y : ℝ) / M := by
  have hh := P.lemma313_analytic_inputs h hb hn hx hy hybig hν
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  exact ⟨lemma313_first_analytic hd (by linarith [hh.1]) hh.2.1 hh.2.2.2,
    (lemma313_second_analytic hd hh.1 (by linarith [hh.2.1]) hh.2.2.1 hh.2.2.2).1.trans
      (lemma313_second_analytic hd hh.1 (by linarith [hh.2.1]) hh.2.2.1 hh.2.2.2).2⟩

/-- The printed large-d reduction for the first inequality. -/
theorem lemma313_first_large_d (P : Parameters) (h : P.Admissible) (hb : P.b = 1)
    (hn : P.normAlpha < 0) (hd : 155 ≤ P.d) {k X Y ν : ℤ}
    (hx : P.x h.pell k = X) (hy : P.y h.pell k = Y)
    (hybig : 1 < Y) (hν : ν = 1 ∨ ν = -1) :
    let M := Approximation.normalizerProduct (squarefreePart P.normAlpha) (2 * X)
      (2 * ν * squareFactor P.normAlpha)
    (113 / 100 : ℝ) <
      (1832 / 10000 : ℝ) * M * Real.sqrt P.d * (Y : ℝ) / |(P.normAlpha : ℝ)| := by
  exact (lemma313_first_cutoff (by exact_mod_cast hd)).trans
    (P.lemma313_analytic_comparisons h hb hn hx hy hybig hν).1

/-- The printed large-d reduction for the second inequality. -/
theorem lemma313_second_large_d (P : Parameters) (h : P.Admissible) (hb : P.b = 1)
    (hn : P.normAlpha < 0) (hd : 109000 ≤ P.d) {k X Y ν : ℤ}
    (hx : P.x h.pell k = X) (hy : P.y h.pell k = Y)
    (hybig : 1 < Y) (hν : ν = 1 ∨ ν = -1) :
    let M := Approximation.normalizerProduct (squarefreePart P.normAlpha) (2 * X)
      (2 * ν * squareFactor P.normAlpha)
    (190 : ℝ) < (2112 / 100 : ℝ) * Real.sqrt P.d * (Y : ℝ) / M := by
  exact (lemma313_second_cutoff (by exact_mod_cast hd)).trans_le
    (P.lemma313_analytic_comparisons h hb hn hx hy hybig hν).2

end Parameters
end «JNT-2024»
