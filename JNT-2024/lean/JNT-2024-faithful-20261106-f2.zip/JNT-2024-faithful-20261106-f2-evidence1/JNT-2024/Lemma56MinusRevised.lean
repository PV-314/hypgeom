module

public import «JNT-2024».NormalizerPowers
public import «JNT-2024».Section5CongruencesRevised
public import «JNT-2024».Section5GcdNormalization
public import «JNT-2024».Section5ResidueTransfer
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.Deriv.MeanValue
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Pow.Real
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.LegendreSymbol.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section
namespace «JNT-2024».Parameters

theorem lemma56_minus_units_revised (P : Parameters) (hu : 0<P.u) (hu4 : P.u ≤ 4)
    (he : P.t^2-P.d*P.u^2= -4) : P.u=1 ∨ P.u=2 := by
  have hall : P.u=1 ∨ P.u=2 ∨ P.u=3 ∨ P.u=4 := by omega
  rcases hall with h1 | h2 | h3 | h4
  · exact Or.inl h1
  · exact Or.inr h2
  · have hh := congrArg (fun z:ℤ => (z:ZMod 9)) he
    norm_num [h3,show (9:ZMod 9)=0 by decide] at hh
    simp only [show (9:ZMod 9)=0 by decide,mul_zero,sub_zero] at hh
    exact (Section5Revised.minus_nine_impossible P.t hh).elim
  · have hh := congrArg (fun z:ℤ => (z:ZMod 16)) he
    norm_num [h4,show (16:ZMod 16)=0 by decide] at hh
    simp only [show (16:ZMod 16)=0 by decide,mul_zero,sub_zero] at hh
    exact (Section5Revised.minus_sixteen_impossible P.t hh).elim

/-- The u=2 half-trace and complete-square identities printed in Lemma 5.6. -/
theorem lemma56_minus_two_identities (P : Parameters) (hp : P.Pell) (hb : P.b=1)
    {n : ℤ} (hn : -P.normAlpha=n^2) (hu : P.u=2)
    (he : P.t^2-P.d*P.u^2= -4) :
    ∃ T:ℤ, P.t=2*T ∧ T^2+1=P.d ∧ P.d=P.a^2+n^2 ∧
      P.y hp 1=((T:ℚ)+P.a)^2+n^2 ∧ P.y hp (-1)=((T:ℚ)-P.a)^2+n^2 := by
  have ht : Even (P.t^2) := by
    have hh : P.t^2=4*(P.d-1) := by rw [hu] at he; nlinarith only [he]
    rw [hh]; exact (by decide : Even (4:ℤ)).mul_right _
  have hte : Even P.t := by simpa [Int.even_pow] using ht
  obtain ⟨T,hT⟩ := hte
  have hT' : P.t=2*T := by omega
  have hTd : T^2+1=P.d := by rw [hu,hT'] at he; nlinarith only [he]
  have hd : P.d=P.a^2+n^2 := by simp only [normAlpha,hb,one_pow,one_mul] at hn; linarith
  refine ⟨T,hT',hTd,hd,?_,?_⟩
  · rw [P.y_one,hb,hu,hT']
    push_cast
    have hTq : (T:ℚ)^2+1=(P.d:ℚ) := by exact_mod_cast hTd
    have hdq : (P.d:ℚ)=(P.a:ℚ)^2+(n:ℚ)^2 := by exact_mod_cast hd
    nlinarith only [hTq,hdq]
  · rw [P.y_neg_one,hb,hu,hT']
    push_cast
    have hTq : (T:ℚ)^2+1=(P.d:ℚ) := by exact_mod_cast hTd
    have hdq : (P.d:ℚ)=(P.a:ℚ)^2+(n:ℚ)^2 := by exact_mod_cast hd
    nlinarith only [hTq,hdq]

theorem lemma56_minus_two_revised (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    {n : ℤ} (hn2 : -P.normAlpha=n^2) (hne : Even n)
    (hu : P.u=2) (he : P.t^2-P.d*P.u^2= -4) (hadj : P.AdjacentSquare h.pell)
    (hg : Int.gcd P.a n=1 ∨ Int.gcd P.a n=2 ∨ Int.gcd P.a n=4 ∨ Int.gcd P.a n=8) :
    16 ∣ P.normAlpha ∧ Int.gcd (P.a^2) P.d=1 := by
  obtain ⟨T,_,hTd,hd,hyp,hym⟩ := P.lemma56_minus_two_identities h.pell hb hn2 hu he
  have heq : T^2+1=P.a^2+n^2 := hTd.trans hd
  have he16 := congrArg (fun z:ℤ => (z:ZMod 16)) heq
  push_cast at he16
  have hnv := ZMod.val_intCast (n:=16) n
  have hnev := Int.even_iff.mp hne
  have hn0 : (n:ZMod 16)^2=0 := by
    rcases Section5Revised.even_square_sixteen n (by omega) with hn0 | hn4
    · exact hn0
    rw [hn4] at he16
    have hm := Section5Revised.minus_two_bad_norm P.a T he16
    exfalso
    rcases hadj with ⟨v,hv⟩ | ⟨v,hv⟩
    · rw [hyp] at hv
      have hvZ : (T+P.a)^2+n^2=v^2 := by exact_mod_cast hv
      have hv16 := congrArg (fun z:ℤ => (z:ZMod 16)) hvZ
      push_cast at hv16; rw [hn4] at hv16
      rcases hm.2.2.1 with hh | hh
      · exact (Section5Revised.five_thirteen_not_square v).1 (hv16.symm.trans hh)
      · exact (Section5Revised.five_thirteen_not_square v).2 (hv16.symm.trans hh)
    · rw [hym] at hv
      have hvZ : (T-P.a)^2+n^2=v^2 := by exact_mod_cast hv
      have hv16 := congrArg (fun z:ℤ => (z:ZMod 16)) hvZ
      push_cast at hv16; rw [hn4] at hv16
      rcases hm.2.2.2 with hh | hh
      · exact (Section5Revised.five_thirteen_not_square v).1 (hv16.symm.trans hh)
      · exact (Section5Revised.five_thirteen_not_square v).2 (hv16.symm.trans hh)
  have ha := Section5Revised.minus_two_good_parity P.a T (by simpa [hn0] using he16)
  have hav := ZMod.val_intCast (n:=16) P.a
  have hao : P.a%2=1 := by omega
  have hga := Int.gcd_dvd_left P.a n
  have hg1 : Int.gcd P.a n=1 := by
    rcases hg with hg | hg | hg | hg
    · exact hg
    all_goals rw [hg] at hga; norm_num at hga; obtain ⟨z,hz⟩ := hga; omega
  constructor
  · apply dvd_neg.mp
    rw [hn2]
    apply (ZMod.intCast_zmod_eq_zero_iff_dvd (n^2) 16).mp
    simpa using hn0
  · have hh := P.section5_baseGcd hb hn2
    simpa [baseGcd,hb,hg1] using hh

theorem lemma56_minus_one_revised (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    {n : ℤ} (hn2 : -P.normAlpha=n^2) (hne : Even n)
    (hu : P.u=1) (he : P.t^2-P.d*P.u^2= -4) (hadj : P.AdjacentSquare h.pell)
    (hg : Int.gcd P.a n=1 ∨ Int.gcd P.a n=2 ∨ Int.gcd P.a n=4 ∨ Int.gcd P.a n=8) :
    (P.normAlpha%16=12 ∧ (Int.gcd (P.a^2) P.d=1 ∨ Int.gcd (P.a^2) P.d=4)) ∨
    (64 ∣ P.normAlpha ∧ Int.gcd (P.a^2) P.d=4) := by
  have hd : P.d=P.a^2+n^2 := by simp only [normAlpha,hb,one_pow,one_mul] at hn2; linarith
  have heq : P.t^2=P.a^2+n^2-4 := by rw [hu,hd] at he; nlinarith only [he]
  have he16 := congrArg (fun z:ℤ => (z:ZMod 16)) heq
  push_cast at he16
  have hnv := ZMod.val_intCast (n:=16) n
  have hnev := Int.even_iff.mp hne
  have hga := Int.gcd_dvd_left P.a n
  have hgn := Int.gcd_dvd_right P.a n
  have hG := P.section5_baseGcd hb hn2
  rcases Section5Revised.even_square_sixteen n (by omega) with hn0 | hn4
  · rw [hn0,add_zero] at he16
    have hm := Section5Revised.minus_one_good_parity P.a P.t he16
    have hav := ZMod.val_intCast (n:=16) P.a
    have htv := ZMod.val_intCast (n:=16) P.t
    have ha2 : P.a%4=2 := by omega
    have ht0 : P.t%4=0 := by omega
    have hnmod4 : n%4=0 := by have := Section5Revised.square_zero_root n hn0; omega
    have hn8 : n%8=0 := by
      by_contra hh
      have hn4 : n%8=4 := by omega
      have hn32v := ZMod.val_intCast (n:=32) n
      have hn32 := Section5Revised.square_sixteen_root n (by omega)
      have ha32v := ZMod.val_intCast (n:=32) P.a
      have ht32v := ZMod.val_intCast (n:=32) P.t
      have hm32 := Section5Revised.minus_one_bad_root P.a P.t (by omega) (by omega)
      obtain ⟨v,hv | hv⟩ := P.section5_adjacent_equations h.pell hb hadj
      · have hv' : (P.t+P.a)^2+n^2=4*v^2 := by rw [hu,hd] at hv; nlinarith only [hv]
        have hv32 := congrArg (fun z:ℤ => (z:ZMod 32)) hv'
        push_cast at hv32; rw [hn32,hm32.1] at hv32
        exact Section5Revised.twenty_not_four_square v hv32.symm
      · have hv' : (P.t-P.a)^2+n^2=4*v^2 := by rw [hu,hd] at hv; nlinarith only [hv]
        have hv32 := congrArg (fun z:ℤ => (z:ZMod 32)) hv'
        push_cast at hv32; rw [hn32,hm32.2] at hv32
        exact Section5Revised.twenty_not_four_square v hv32.symm
    have hg2div : 2 ∣ Int.gcd P.a n := Int.dvd_gcd
      (Int.dvd_of_emod_eq_zero (by omega)) (even_iff_two_dvd.mp hne)
    have hg2 : Int.gcd P.a n=2 := by
      rcases hg with hg | hg | hg | hg
      · rw [hg] at hg2div; norm_num at hg2div
      · exact hg
      all_goals rw [hg] at hga; norm_num at hga; obtain ⟨z,hz⟩ := hga; omega
    right
    constructor
    · apply dvd_neg.mp
      rw [hn2]
      exact pow_dvd_pow_of_dvd (Int.dvd_of_emod_eq_zero hn8) 2
    · simpa [baseGcd,hb,hg2] using hG
  · have hnmod4 : n%4=2 := by have := Section5Revised.square_four_root n hn4; omega
    have hg12 : Int.gcd P.a n=1 ∨ Int.gcd P.a n=2 := by
      rcases hg with hg | hg | hg | hg
      · exact Or.inl hg
      · exact Or.inr hg
      all_goals rw [hg] at hgn; norm_num at hgn; obtain ⟨z,hz⟩ := hgn; omega
    left
    constructor
    · have hv := ZMod.val_intCast (n:=16) (n^2)
      rw [Int.cast_pow,hn4] at hv
      norm_num [ZMod.val_ofNat] at hv
      omega
    · rcases hg12 with hg1 | hg2
      · left; simpa [baseGcd,hb,hg1] using hG
      · right; simpa [baseGcd,hb,hg2] using hG

end «JNT-2024».Parameters
