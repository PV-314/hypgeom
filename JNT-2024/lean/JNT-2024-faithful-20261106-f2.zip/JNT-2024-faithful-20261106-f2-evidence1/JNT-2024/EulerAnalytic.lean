module

public import «JNT-2024».EulerBeta
public import «JNT-2024».EulerIntegral
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

open MeasureTheory Filter
open scoped Topology Interval

namespace «JNT-2024»
namespace Hypergeometric

noncomputable def eulerKernelDeriv (a : ℂ) (r : ℕ) (z : ℂ) (t : ℝ) : ℂ :=
  (t : ℂ) ^ r * (1 - (t : ℂ)) ^ r * (-a * chord z t ^ (-a - 1) * t)

theorem hasDerivAt_eulerKernel (a : ℂ) (r : ℕ) {z : ℂ} (hz : z ∈ Complex.slitPlane)
    {t : ℝ} (ht : t ∈ Set.Icc 0 1) :
    HasDerivAt (fun w => eulerKernel a r w t) (eulerKernelDeriv a r z t) z := by
  have hh : HasDerivAt (fun w : ℂ => chord w t) (t : ℂ) z := by
    simpa [chord] using (((hasDerivAt_id z).sub_const 1).mul_const (t : ℂ)).const_add 1
  simpa [eulerKernel, eulerKernelDeriv] using
    (hh.cpow_const (c := -a) (chord_mem_slitPlane hz ht)).const_mul ((t : ℂ) ^ r * (1 - (t : ℂ)) ^ r)

theorem eulerKernelDeriv_continuousOn (a : ℂ) (r : ℕ) :
    ContinuousOn (fun p : ℂ × ℝ => eulerKernelDeriv a r p.1 p.2)
      (Complex.slitPlane ×ˢ Set.Icc 0 1) := by
  apply continuousOn_of_forall_continuousAt
  intro p hp
  unfold eulerKernelDeriv
  apply ContinuousAt.mul (by fun_prop)
  apply ContinuousAt.mul _ (by fun_prop)
  apply ContinuousAt.mul continuousAt_const
  exact ContinuousAt.cpow (by unfold chord; fun_prop) continuousAt_const
    (chord_mem_slitPlane hp.1 hp.2)

theorem eulerKernelDeriv_intervalIntegrable (a : ℂ) (r : ℕ) {z : ℂ}
    (hz : z ∈ Complex.slitPlane) : IntervalIntegrable (eulerKernelDeriv a r z) volume 0 1 := by
  apply ContinuousOn.intervalIntegrable_of_Icc zero_le_one
  have hc : ContinuousOn (fun t : ℝ => (z, t)) (Set.Icc 0 1) := by fun_prop
  exact (eulerKernelDeriv_continuousOn a r).comp hc (fun _ ht => ⟨hz, ht⟩)

/-- Differentiation under the Euler integral, with a locally uniform bound obtained on
a compact disk times the closed integration interval. -/
theorem hasDerivAt_eulerHypergeometric (a : ℂ) (r : ℕ) {z : ℂ} (hz : z ∈ Complex.slitPlane) :
    HasDerivAt (eulerHypergeometric a r)
      (eulerNormalizer r * ∫ t : ℝ in 0..1, eulerKernelDeriv a r z t) z := by
  obtain ⟨ε, hε, hεs⟩ := Metric.isOpen_iff.mp Complex.isOpen_slitPlane z hz
  have hδ : 0 < ε / 2 := by linarith
  have hclosed : Metric.closedBall z (ε / 2) ⊆ Complex.slitPlane := by
    intro w hw
    apply hεs
    rw [Metric.mem_closedBall] at hw
    rw [Metric.mem_ball]
    exact lt_of_le_of_lt hw (by linarith)
  have hcompact := (isCompact_closedBall z (ε / 2)).prod (isCompact_Icc (a := (0 : ℝ)) (b := 1))
  obtain ⟨C, hC⟩ := hcompact.exists_bound_of_continuousOn
    ((eulerKernelDeriv_continuousOn a r).mono (fun p hp => ⟨hclosed hp.1, hp.2⟩))
  have hmeas : ∀ᶠ w in 𝓝 z,
      AEStronglyMeasurable (eulerKernel a r w) (volume.restrict (Ι (0 : ℝ) 1)) := by
    filter_upwards [Metric.ball_mem_nhds z hδ] with w hw
    simpa only [Set.uIoc_of_le zero_le_one] using
      (eulerKernel_intervalIntegrable a r (hclosed (Metric.ball_subset_closedBall hw))).1.aestronglyMeasurable
  have hdmeas : AEStronglyMeasurable (eulerKernelDeriv a r z) (volume.restrict (Ι (0 : ℝ) 1)) := by
    simpa only [Set.uIoc_of_le zero_le_one] using
      (eulerKernelDeriv_intervalIntegrable a r hz).1.aestronglyMeasurable
  have htmem : ∀ {t : ℝ}, t ∈ Ι (0 : ℝ) 1 → t ∈ Set.Icc 0 1 := by
    intro t ht
    simp only [Set.uIoc_of_le zero_le_one] at ht
    exact ⟨ht.1.le, ht.2⟩
  have hh := intervalIntegral.hasDerivAt_integral_of_dominated_loc_of_deriv_le
    (F := eulerKernel a r) (F' := eulerKernelDeriv a r) (bound := fun _ => C)
    (Metric.ball_mem_nhds z hδ) hmeas (eulerKernel_intervalIntegrable a r hz) hdmeas
    (ae_of_all _ (fun t ht w hw => hC (w, t)
      ⟨Metric.ball_subset_closedBall hw, htmem ht⟩))
    intervalIntegrable_const
    (ae_of_all _ (fun t ht w hw => hasDerivAt_eulerKernel a r
      (hclosed (Metric.ball_subset_closedBall hw)) (htmem ht)))
  convert hh.2.const_mul (eulerNormalizer r) using 1
  rfl

/-- The Euler integral gives a holomorphic continuation throughout the principal slit plane. -/
theorem eulerHypergeometric_analyticOnNhd (a : ℂ) (r : ℕ) :
    AnalyticOnNhd ℂ (eulerHypergeometric a r) Complex.slitPlane := by
  apply DifferentiableOn.analyticOnNhd _ Complex.isOpen_slitPlane
  intro z hz
  exact (hasDerivAt_eulerHypergeometric a r hz).differentiableAt.differentiableWithinAt

/-- Uniqueness of this continuation from the defining disk to the principal slit plane. -/
theorem eulerHypergeometric_unique (a : ℂ) (r : ℕ) {f : ℂ → ℂ}
    (hf : AnalyticOnNhd ℂ f Complex.slitPlane)
    (hseries : ∀ z : ℂ, ‖1 - z‖ < 1 → f z = ₂F₁ a (r + 1) (2 * r + 2) (1 - z)) :
    Set.EqOn f (eulerHypergeometric a r) Complex.slitPlane := by
  have hone : (1 : ℂ) ∈ Complex.slitPlane := Or.inl (by norm_num)
  apply hf.eqOn_of_preconnected_of_eventuallyEq (eulerHypergeometric_analyticOnNhd a r)
    (Complex.starConvex_one_slitPlane.isPathConnected hone).isConnected.isPreconnected hone
  filter_upwards [Metric.ball_mem_nhds (1 : ℂ) (by norm_num : (0 : ℝ) < 1)] with z hz
  have hh : ‖1 - z‖ < 1 := by simpa only [Metric.mem_ball, dist_eq_norm, norm_sub_rev] using hz
  exact (hseries z hh).trans (eulerHypergeometric_eq_series a r hh).symm

end Hypergeometric
end «JNT-2024»
