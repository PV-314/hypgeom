module

public import «JNT-2024».ComplexRepresentation
public import «JNT-2024».FourthRootGeometry
public import «JNT-2024».GapLattice
public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».Section2Complex
public import «JNT-2024».Section2Gaussian
public import «JNT-2024».Section4Comparison
public import «JNT-2024».Section4ComparisonIntegers
public import «JNT-2024».Section4Representation
public import «JNT-2024».Section4Sequence
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- The Gaussian imaginary coordinate and norm identity used in Section 4. -/
theorem section4_gaussian_coordinates (P : Parameters) (h : P.Admissible)
    (hb : P.b = 1) (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha))
    {k X ν : ℤ} (hx : P.x h.pell k = (X : ℚ)) (hν : ν = 1 ∨ ν = -1)
    (hs : IsIntegerSquare (P.y h.pell k)) (hy : 1 < P.y h.pell k) :
    let Z := ν * squareFactor P.normAlpha
    (Z : ℝ) ^ 2 = |(P.normAlpha : ℝ)| ∧ Z ≠ 0 ∧ 15 * Z ^ 2 ≤ X ^ 2 ∧
      (X : ℝ) ^ 2 + (Z : ℝ) ^ 2 =
        (Real.sqrt (P.d : ℝ) * (P.y h.pell k : ℝ)) ^ 2 := by
  let Z := ν * squareFactor P.normAlpha
  have hS := squarefreePart_eq_neg_one (ne_of_lt hn) hNs
  have hN : 0 < |(P.normAlpha : ℝ)| := (P.section4_norm_range h hb hn).1
  have hzsq : (Z : ℝ) ^ 2 = |(P.normAlpha : ℝ)| := by
    have hh := squareFactor_sq_mul P.normAlpha
    rw [hS] at hh
    have hhR : (squareFactor P.normAlpha : ℝ) ^ 2 * (-1) = P.normAlpha := by exact_mod_cast hh
    dsimp [Z]
    rw [abs_of_neg (by exact_mod_cast hn)]
    rcases hν with rfl | rfl <;> push_cast <;> nlinarith only [hhR]
  have hz : Z ≠ 0 := by
    intro he
    simp only [he, Int.cast_zero, zero_pow (by decide : (2 : ℕ) ≠ 0)] at hzsq
    linarith
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hcoord : (X : ℝ) ^ 2 + (Z : ℝ) ^ 2 =
      (Real.sqrt (P.d : ℝ) * (P.y h.pell k : ℝ)) ^ 2 := by
    have hh := P.norm_identity h.pell k
    rw [hx] at hh
    have hhR : (X : ℝ) ^ 2 - P.d * (P.y h.pell k : ℝ) ^ 2 = P.normAlpha := by exact_mod_cast hh
    rw [mul_pow, Real.sq_sqrt hd.le, hzsq, abs_of_neg (by exact_mod_cast hn)]
    linarith
  have hy4 : (4 : ℝ) ≤ (P.y h.pell k : ℝ) := by exact_mod_cast integer_square_ge_four hs hy
  have hnlt := (P.section4_norm_range h hb hn).2
  have hlarge : 15 * (Z : ℝ) ^ 2 ≤ (X : ℝ) ^ 2 := by
    have hh := mul_le_mul_of_nonneg_left (show (16 : ℝ) ≤ (P.y h.pell k : ℝ) ^ 2 by nlinarith) hd.le
    rw [mul_pow, Real.sq_sqrt hd.le] at hcoord
    nlinarith only [hh, hcoord, hzsq, hnlt]
  exact ⟨hzsq, hz, by exact_mod_cast hlarge, hcoord⟩

/-- The actual Gaussian comparison pair, its ring-of-integers membership,
its norm (4.9), and its error bound (4.2). -/
theorem section4_comparison (P : Parameters) (h : P.Admissible) (hb : P.b = 1)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha)) {i j : ℤ}
    (hsi : IsIntegerSquare (P.y h.pell i)) (hsj : IsIntegerSquare (P.y h.pell j))
    (hyi : 1 < P.y h.pell i) (hyj : 1 < P.y h.pell j) :
    ∃ X ν : ℤ, P.x h.pell i = (X : ℚ) ∧ (ν = 1 ∨ ν = -1) ∧
      ∃ p₀ q₀ : Section2.GaussianField, IsIntegral ℤ p₀ ∧ IsIntegral ℤ q₀ ∧ q₀ ≠ 0 ∧
        ‖Section2.gaussianEmbedding q₀‖ ^ 4 = (P.y h.pell i : ℝ) * (P.y h.pell j : ℝ) ∧
        ‖Section2.omega (-1) (2 * X) (2 * (ν * squareFactor P.normAlpha)) ^ (1 / 4 : ℂ) -
          Section2.gaussianEmbedding p₀ / Section2.gaussianEmbedding q₀‖ <
          2 * Real.sqrt |(P.normAlpha : ℝ)| /
            ((3959 / 1000 : ℝ) * Real.sqrt P.d * (P.y h.pell j : ℝ)) := by
  have hi := (P.section4_gap_hypotheses h hb hn hsi hyi).1
  have hj := (P.section4_gap_hypotheses h hb hn hsj hyj).1
  obtain ⟨X, ν, r, s, τ, hx, hν, hτ, ha, hay, he⟩ :=
    P.section4_representation h hb hn hNs hi hsi (by linarith)
  obtain ⟨X', ν', R, S, σ, hx', hν', hσ, hb', hby, he'⟩ :=
    P.section4_representation h hb hn hNs hj hsj (by linarith)
  let Zi := ν * squareFactor P.normAlpha
  let Zj := ν' * squareFactor P.normAlpha
  let a := quadraticPoint 1 r s
  let b := quadraticPoint 1 R S
  let Ui := Section2.U (-1) (2 * X) (2 * Zi)
  let Uj := Section2.U (-1) (2 * X') (2 * Zj)
  let ω := Section2.omega (-1) (2 * X) (2 * Zi)
  let ψ := Section2.omega (-1) (2 * X') (2 * Zj)
  let v := (a / star a) / (b / star b)
  have hci := P.section4_gaussian_coordinates h hb hn hNs hx hν hsi hyi
  have hcj := P.section4_gaussian_coordinates h hb hn hNs hx' hν' hsj hyj
  have hω : ‖ω‖ = 1 := Section2.omega_norm (by norm_num) (mul_ne_zero (by decide) hci.2.1)
  have hψ : ‖ψ‖ = 1 := Section2.omega_norm (by norm_num) (mul_ne_zero (by decide) hcj.2.1)
  have hv : ‖v‖ = 1 := by
    change ‖a / star a / (b / star b)‖ = 1
    rw [norm_div, norm_div, norm_div, norm_star, norm_star,
      div_self (norm_ne_zero_iff.mpr ha), div_self (norm_ne_zero_iff.mpr hb'), div_one]
  have hres : ‖ω - v ^ 4‖ = ‖ψ - 1‖ :=
    Section4.cross_ratio_residual (P.complexAlpha_ne_zero hn) hb'
      (by rcases hτ with rfl | rfl <;> decide) (by rcases hσ with rfl | rfl <;> decide)
      he he' hω hψ
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hyjR : (0 : ℝ) < (P.y h.pell j : ℝ) := by exact_mod_cast (by linarith : 0 < P.y h.pell j)
  have hroot : |(Zj : ℝ)| = Real.sqrt |(P.normAlpha : ℝ)| := by
    rw [← hcj.1, Real.sqrt_sq_eq_abs]
  have hchord := Section4.gaussian_chord (mul_pos (Real.sqrt_pos.mpr hd) hyjR) hcj.2.2.2
  have hres' : ‖ω - v ^ 4‖ =
      2 * Real.sqrt |(P.normAlpha : ℝ)| / (Real.sqrt P.d * (P.y h.pell j : ℝ)) := by
    rw [hres]
    change ‖ψ - 1‖ = 2 * |(Zj : ℝ)| / (Real.sqrt P.d * (P.y h.pell j : ℝ)) at hchord
    rwa [hroot] at hchord
  have hN := P.section4_norm_range h hb hn
  have hsmall : ‖ω - v ^ 4‖ ≤ 1 / 2 := by
    rw [hres']
    apply (div_le_iff₀ (mul_pos (Real.sqrt_pos.mpr hd) hyjR)).mpr
    have hsr : Real.sqrt |(P.normAlpha : ℝ)| < Real.sqrt (P.d : ℝ) :=
      Real.sqrt_lt_sqrt hN.1.le hN.2
    have hy4 : (4 : ℝ) ≤ (P.y h.pell j : ℝ) := by exact_mod_cast integer_square_ge_four hsj hyj
    nlinarith [mul_le_mul_of_nonneg_left hy4 (Real.sqrt_nonneg (P.d : ℝ))]
  obtain ⟨η, hη, herr⟩ := Section4.comparison_phase hω hv hN.1 hd hyjR hres' hsmall
  obtain ⟨p₀, q₀, hp₀, hq₀, hep, heq⟩ := Section4.comparison_integers r s R S hη
  have hqne : q₀ ≠ 0 := by
    intro hh
    have hh' : (0 : ℂ) = star a * b := by simpa only [hh, map_zero] using heq
    exact mul_ne_zero (star_ne_zero.mpr ha) hb' hh'.symm
  refine ⟨X, ν, hx, hν, p₀, q₀, hp₀, hq₀, hqne, ?_, ?_⟩
  · rw [heq]
    exact Section4.comparison_norm hay hby
  · rw [hep, heq, mul_div_assoc, Section4.comparison_ratio]
    exact herr

end «JNT-2024».Parameters
