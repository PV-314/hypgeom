module

public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».RepresentationDivisibility
public import «JNT-2024».RepresentationNormalization
public import «JNT-2024».RepresentationValuationCaseTwo
public import «JNT-2024».RepresentationValuationCases
public import «JNT-2024».RepresentationValuationLowerBounds
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section
namespace «JNT-2024».Parameters

/-- The prime-two version of the candidate-difference step, using the printed
valuation chain. This supplies detail omitted by “similar” in Lemma 3.2. -/
theorem lemma32_two_other_from_chain (P : Parameters) {x y σ ν : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hy : y ≠ 0)
    (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0) (hσ : σ = 1 ∨ σ = -1)
    (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν) :
    min (padicValInt 2 (P.repCandidate y σ)) (2 * padicValInt 2 P.b + 2) ≤
      padicValInt 2 (P.repCandidate y (-σ)) := by
  have hroot := P.lemma32_two_lower_from_chain h hb hy hu hN hσ hν
  let k := min (padicValInt 2 (P.repCandidate y σ)) (2 * padicValInt 2 P.b + 2)
  have hr : (2 : ℤ) ^ k ∣ P.repCandidate y σ :=
    (padicValInt_dvd_iff _ _).mpr (Or.inr (min_le_left _ _))
  have h4 : padicValInt 2 (4 : ℤ) = 2 := by
    have he : (4 : ℤ) = 2 ^ 2 := by norm_num
    rw [he, valuation_int_pow]
    norm_num [padicValInt]
  have hby : (2 : ℤ) ^ k ∣ 4 * P.b * y := by
    apply (padicValInt_dvd_iff _ _).mpr
    right
    rw [padicValInt.mul (mul_ne_zero (by norm_num) hb) hy,
      padicValInt.mul (by norm_num) hb, h4]
    dsimp [k]
    omega
  have he : P.repCandidate y (-σ) = P.repCandidate y σ - σ * (4 * P.b * y) := by
    unfold repCandidate
    ring
  have hd : (2 : ℤ) ^ k ∣ P.repCandidate y (-σ) := by
    rw [he]
    exact dvd_sub hr (dvd_mul_of_dvd_right hby _)
  have hσ' : -σ = 1 ∨ -σ = -1 := by rcases hσ with rfl | rfl <;> norm_num
  exact ((padicValInt_dvd_iff _ _).mp hd).resolve_left (P.repCandidate_ne_zero h hu hN hσ')

/-- Valuations of the two entries and their gcd at two, for the case split
specified after (3.6). -/
theorem lemma32_two_gcd_setup (P : Parameters) {r : ℤ} (hb : P.b ≠ 0) (hr : r ≠ 0) :
    padicValInt 2 (4 * P.b ^ 2 * r / squarefreePart r) =
      2 + 2 * padicValInt 2 P.b + 2 * padicValInt 2 (squareFactor r) ∧
    padicValInt 2 ((normalizationGcd P.b r : ℤ) ^ 2) =
      2 * min (1 + padicValInt 2 P.b + padicValInt 2 r / 2) (padicValInt 2 r) := by
  have he : 4 * P.b ^ 2 * r / squarefreePart r = (2 * P.b * squareFactor r) ^ 2 := by
    have he' : 4 * P.b ^ 2 * r = (2 * P.b * squareFactor r) ^ 2 * squarefreePart r := by
      nth_rw 1 [← squareFactor_sq_mul r]
      ring
    rw [he', Int.mul_ediv_cancel _ (squarefreePart_ne_zero r)]
  have h2 : padicValInt 2 (2 : ℤ) = 1 := by norm_num [padicValInt]
  constructor
  · rw [he, valuation_int_pow,
      padicValInt.mul (mul_ne_zero (by norm_num) hb) (ne_of_gt (squareFactor_pos hr)),
      padicValInt.mul (by norm_num) hb, h2]
    omega
  · simpa only [h2] using normalizationGcd_sq_valuation 2 hb hr

/-- Prime-two gcd case (1). The other candidate has valuation at least k₂;
squarefree removal and evenness of the target square give the conclusion. -/
theorem lemma32_two_case1 (P : Parameters) {x y σ ν : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hy : y ≠ 0)
    (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0) (hσ : σ = 1 ∨ σ = -1)
    (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν)
    (hc : padicValInt 2 (P.repCandidate y σ ^ 2) ≤
      padicValInt 2 (4 * P.b ^ 2 * P.repCandidate y σ / squarefreePart (P.repCandidate y σ))) :
    padicValInt 2 ((normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2) ≤
      padicValInt 2 ((-P.u * squareFactor P.normAlpha) ^ 2) := by
  have hr := P.repCandidate_ne_zero h hu hN hσ
  have hσ' : -σ = 1 ∨ -σ = -1 := by rcases hσ with rfl | rfl <;> norm_num
  have hr' := P.repCandidate_ne_zero h hu hN hσ'
  obtain ⟨hfirst, hg⟩ := P.lemma32_two_gcd_setup hb hr
  rw [valuation_int_pow, hfirst] at hc
  have hs := valuation_squarePart 2 hr
  have hf := valuation_squareFactor_eq_half 2 hr
  have ho := P.lemma32_two_other_from_chain h hb hy hu hN hσ hν
  have hv := (lemma32_case2_product_valuation 2 hr hr' hu hN
    (P.lemma32_signed_candidate_product h hσ)).1
  have hsf := valuation_squarefree_le_one 2 (squarefreePart_squarefree P.normAlpha)
  have heven := valuation_int_pow 2 (-P.u * squareFactor P.normAlpha) 2
  have hk : padicValInt 2 (P.repCandidate y σ) ≤ 2 * padicValInt 2 P.b + 2 := by omega
  have hother : padicValInt 2 (P.repCandidate y σ) ≤ padicValInt 2 (P.repCandidate y (-σ)) := by omega
  have hg' : padicValInt 2 ((normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2) =
      2 * padicValInt 2 (P.repCandidate y σ) := by omega
  omega

/-- Prime-two gcd case (2), using the same odd/even squarefree argument as
the printed odd-prime case, with k₁ replaced by k₁+1. -/
theorem lemma32_two_case2 (P : Parameters) {x y σ ν : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hy : y ≠ 0)
    (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0) (hσ : σ = 1 ∨ σ = -1)
    (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν)
    (hc : padicValInt 2 (4 * P.b ^ 2 * P.repCandidate y σ / squarefreePart (P.repCandidate y σ)) <
      padicValInt 2 (P.repCandidate y σ ^ 2)) :
    padicValInt 2 ((normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2) ≤
      padicValInt 2 ((-P.u * squareFactor P.normAlpha) ^ 2) := by
  have hr := P.repCandidate_ne_zero h hu hN hσ
  have hσ' : -σ = 1 ∨ -σ = -1 := by rcases hσ with rfl | rfl <;> norm_num
  have hr' := P.repCandidate_ne_zero h hu hN hσ'
  obtain ⟨hfirst, hg⟩ := P.lemma32_two_gcd_setup hb hr
  rw [valuation_int_pow, hfirst] at hc
  have hs := valuation_squarePart 2 hr
  have hf := valuation_squareFactor_eq_half 2 hr
  have hsf := valuation_squarefree_le_one 2 (squarefreePart_squarefree (P.repCandidate y σ))
  have ho := P.lemma32_two_other_from_chain h hb hy hu hN hσ hν
  have hlower : 2 * (padicValInt 2 P.b + 1) ≤ padicValInt 2 (P.repCandidate y (-σ)) := by omega
  have hprod := P.lemma32_signed_candidate_product h hσ
  have hv := (lemma32_case2_product_valuation 2 hr hr' hu hN hprod).1
  have hpar := (lemma32_case2_parity 2 hr hr' hu hN hprod (padicValInt 2 P.b + 1) hlower).2.2.2
  have hg' : padicValInt 2 ((normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2) +
      padicValInt 2 (squarefreePart (P.repCandidate y σ)) =
      2 * (padicValInt 2 P.b + 1) + padicValInt 2 (P.repCandidate y σ) := by omega
  omega

/-- The prime-two proof specified after (3.6), with both gcd cases supplied. -/
theorem lemma32_two_published_valuation (P : Parameters) [Fact (¬ IsSquare P.d)] {x y σ : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hy : y ≠ 0)
    (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0) (hσ : σ = 1 ∨ σ = -1)
    (hi : IsIntegral ℤ P.epsilon) :
    padicValInt 2 (Int.gcd (4 * P.b ^ 2 * P.repCandidate y σ / squarefreePart (P.repCandidate y σ))
      (P.repCandidate y σ ^ 2) : ℤ) ≤ padicValInt 2 ((-P.u * squareFactor P.normAlpha) ^ 2) := by
  obtain ⟨ν, hν⟩ := P.four_dvd_epsilon_discriminant hi
  have hg : (normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2 =
      (Int.gcd (4 * P.b ^ 2 * P.repCandidate y σ / squarefreePart (P.repCandidate y σ))
        (P.repCandidate y σ ^ 2) : ℤ) := by rw [← Nat.cast_pow, normalizationGcd_sq]
  rw [← hg]
  rcases le_or_gt (padicValInt 2 (P.repCandidate y σ ^ 2))
      (padicValInt 2 (4 * P.b ^ 2 * P.repCandidate y σ / squarefreePart (P.repCandidate y σ))) with hc | hc
  · exact P.lemma32_two_case1 h hb hy hu hN hσ hν hc
  · exact P.lemma32_two_case2 h hb hy hu hN hσ hν hc

/-- Lemma 3.2 with the original gcd, proved by the manuscript's odd-prime
case division and the supplied details of its prime-two case division. -/
theorem lemma32_published (P : Parameters) [Fact (¬ IsSquare P.d)] {x y σ : ℤ}
    (h : P.RepresentsSquare x y) (ha : P.a ≠ 0) (hb : P.b ≠ 0) (hd : P.d ≠ 0)
    (hy : y ≠ 0) (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0)
    (hi : IsIntegral ℤ P.epsilon) (hσ : σ = 1 ∨ σ = -1) :
    (Int.gcd (4 * P.b ^ 2 * P.repCandidate y σ / squarefreePart (P.repCandidate y σ))
      (P.repCandidate y σ ^ 2) : ℤ) ∣ (-P.u * squareFactor P.normAlpha) ^ 2 := by
  apply Int.natCast_dvd.mpr
  apply (Nat.dvd_iff_prime_pow_dvd_dvd _ _).mpr
  intro p k hp hpk
  let : Fact p.Prime := ⟨hp⟩
  have htarget : (-P.u * squareFactor P.normAlpha) ^ 2 ≠ 0 :=
    pow_ne_zero _ (mul_ne_zero (neg_ne_zero.mpr hu) (ne_of_gt (squareFactor_pos hN)))
  apply (padicValNat_dvd_iff_le (Int.natAbs_ne_zero.mpr htarget)).mpr
  have hgpos := Int.gcd_pos_of_ne_zero_right
    (4 * P.b ^ 2 * P.repCandidate y σ / squarefreePart (P.repCandidate y σ))
    (pow_ne_zero 2 (P.repCandidate_ne_zero h hu hN hσ))
  have hk := (padicValNat_dvd_iff_le (ne_of_gt hgpos)).mp hpk
  have hv : padicValInt p
      (Int.gcd (4 * P.b ^ 2 * P.repCandidate y σ / squarefreePart (P.repCandidate y σ))
        (P.repCandidate y σ ^ 2) : ℤ) ≤ padicValInt p ((-P.u * squareFactor P.normAlpha) ^ 2) := by
    by_cases hp2 : p = 2
    · subst p
      exact P.lemma32_two_published_valuation h hb hy hu hN hσ hi
    · exact P.lemma32_odd_published_valuation h ha hb hd hy hu hN hσ p hp2
  change k ≤ padicValInt p ((-P.u * squareFactor P.normAlpha) ^ 2)
  exact hk.trans (by simpa only [padicValInt.of_nat] using hv)

/-- Lemma 3.2 under the paper's sign and nonsquare hypotheses. The auxiliary
nonvanishing conditions used in the valuation proof are derived here. -/
theorem lemma32_published_of_paper_hypotheses (P : Parameters) [Fact (¬ IsSquare P.d)]
    {x y σ : ℤ} (h : P.RepresentsSquare x y) (ha : P.a ≠ 0) (hb : 0 < P.b)
    (hy : 0 < y) (hu : P.u ≠ 0) (hN : ¬ IsSquare P.normAlpha)
    (hi : IsIntegral ℤ P.epsilon) (hσ : σ = 1 ∨ σ = -1) :
    (Int.gcd (4 * P.b ^ 2 * P.repCandidate y σ / squarefreePart (P.repCandidate y σ))
      (P.repCandidate y σ ^ 2) : ℤ) ∣ (-P.u * squareFactor P.normAlpha) ^ 2 := by
  have hd : P.d ≠ 0 := by
    intro hz
    have hn : ¬ IsSquare P.d := Fact.out
    apply hn
    rw [hz]
    exact ⟨0, by ring⟩
  have hn : P.normAlpha ≠ 0 := by
    intro hz
    apply hN
    rw [hz]
    exact ⟨0, by ring⟩
  exact P.lemma32_published h ha (ne_of_gt hb) hd (ne_of_gt hy) hu hn hi hσ

/-- The unsquared coordinate divisor, now obtained from the published proof
of Lemma 3.2. The earlier stronger proof is retained separately. -/
theorem candidate_gcd_dvd_coordinate_published (P : Parameters) [Fact (¬ IsSquare P.d)]
    {x y σ : ℤ} (h : P.RepresentsSquare x y) (ha : P.a ≠ 0) (hb : P.b ≠ 0)
    (hd : P.d ≠ 0) (hy : y ≠ 0) (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0)
    (hi : IsIntegral ℤ P.epsilon) (hσ : σ = 1 ∨ σ = -1) :
    (normalizationGcd P.b (P.repCandidate y σ) : ℤ) ∣ -P.u * squareFactor P.normAlpha := by
  apply (Int.pow_dvd_pow_iff (by norm_num : (2 : ℕ) ≠ 0)).mp
  rw [← Nat.cast_pow, normalizationGcd_sq]
  exact P.lemma32_published h ha hb hd hy hu hN hi hσ



























end «JNT-2024».Parameters
