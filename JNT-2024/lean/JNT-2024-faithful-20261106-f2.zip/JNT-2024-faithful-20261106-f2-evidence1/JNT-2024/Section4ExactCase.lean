module

public import «JNT-2024».HypergeometricPolynomials
public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».Section2
public import «JNT-2024».Section2Complex
public import «JNT-2024».Section2Construction
public import «JNT-2024».Section2Gaussian
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

/-- The Gaussian correction and common denominator cancel in the approximant ratio. -/
theorem corrected_ratio {u₁ u₂ : ℤ} {r : ℕ} (hq : Section2.q u₁ u₂ r ≠ 0) :
    Section2.p u₁ u₂ r / Section2.q u₁ u₂ r =
      Hypergeometric.X (1 / 4) r (Section2.omega (-1) u₁ u₂) /
        Hypergeometric.Y (1 / 4) r (Section2.omega (-1) u₁ u₂) := by
  have hf : Section2.correction u₁ u₂ r * Section2.rawScale (-1) u₁ u₂ r ≠ 0 := by
    intro hh
    apply hq
    simp only [Section2.q, Section2.rawQ, ← mul_assoc, hh, zero_mul]
  simp only [Section2.p, Section2.q, Section2.rawP, Section2.rawQ, ← mul_assoc,
    mul_div_mul_left _ _ hf]

/-- In the vanishing-determinant case, adjacent independence proves the denominator
nonzero and identifies the comparison fraction with the actual hypergeometric ratio. -/
theorem exact_comparison_ratio {u₁ u₂ : ℤ} (data : Section2.PaperApproximants u₁ u₂)
    {p₀ q₀ : Section2.GaussianField} (hq₀ : q₀ ≠ 0) (r : ℕ)
    (he : data.pr r * q₀ - data.qr r * p₀ = 0) :
    Hypergeometric.Y (1 / 4) r (Section2.omega (-1) u₁ u₂) ≠ 0 ∧
      Section2.gaussianEmbedding p₀ / Section2.gaussianEmbedding q₀ =
        Hypergeometric.X (1 / 4) r (Section2.omega (-1) u₁ u₂) /
          Hypergeometric.Y (1 / 4) r (Section2.omega (-1) u₁ u₂) := by
  have hqr : data.qr r ≠ 0 := by
    intro hh
    have hp : data.pr r = 0 := by
      simp only [hh, zero_mul, sub_zero, mul_eq_zero] at he
      exact he.resolve_right hq₀
    have hi := data.independent r
    simp [hh, hp] at hi
  have hq : Section2.q u₁ u₂ r ≠ 0 := by
    rw [← data.embed_q]
    exact (map_ne_zero Section2.gaussianEmbedding).mpr hqr
  have hY : Hypergeometric.Y (1 / 4) r (Section2.omega (-1) u₁ u₂) ≠ 0 := by
    intro hh
    apply hq
    simp only [Section2.q, Section2.rawQ, hh, mul_zero]
  refine ⟨hY, ?_⟩
  have he' : p₀ / q₀ = data.pr r / data.qr r :=
    (div_eq_div_iff hq₀ hqr).mpr (by linear_combination -he)
  have hh := congrArg Section2.gaussianEmbedding he'
  simp only [map_div₀, data.embed_p, data.embed_q] at hh
  exact hh.trans (corrected_ratio hq)


end «JNT-2024».Section4
