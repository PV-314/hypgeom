module

public import «JNT-2024».AkhtariInput
public import «JNT-2024».DenominatorBounds
public import «JNT-2024».Integrality
public import «JNT-2024».Lemma52ReductionPublished
public import «JNT-2024».Monotonicity
public import «JNT-2024».NormalizerBounds
public import «JNT-2024».Proposition41
public import «JNT-2024».Section46Calculation
public import «JNT-2024».Section4Published
public import «JNT-2024».Section4Sequence
public import «JNT-2024».Section5Bounds
public import «JNT-2024».Section5Growth
public import «JNT-2024».Section5OpeningPublished
public import «JNT-2024».Section5RecurrenceRevised
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.Deriv.MeanValue
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section
namespace «JNT-2024».Parameters

/-- The sentence following revised Lemma 5.1, for every nonzero signed index. -/
theorem section5_nonzero_gt_one_revised (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hn : P.normAlpha<0) (hK : P.IsNegativeCutoff h.pell (-1))
    {k : ℤ} (hk : k ≠ 0) : 1<P.y h.pell k := by
  have hm : 1<P.y h.pell (-1) := by simpa [hb] using hK.2.1
  rcases le_total 0 k with hkp | hkn
  · have hh := (P.y_strictMono_nonnegative h hn) (show 0<k.natAbs by omega)
    have he : (k.natAbs:ℤ)=k := by simp [abs_of_nonneg hkp]
    simpa [he,hb] using hh
  · have hh := (P.y_strictMono_negative_tail h hn (-1) hK).monotone (show 1 ≤ k.natAbs by omega)
    have he : -(k.natAbs:ℤ)=k := (Int.eq_neg_natAbs_of_nonpos hkn).symm
    have hh' : P.y h.pell (-1) ≤ P.y h.pell k := by
      simpa only [neg_add_cancel,zero_sub,Nat.cast_one,he] using hh
    exact hm.trans_le hh'

/-- The new large-index estimate for u=1, with the printed constant 1/25. -/
theorem lemma52_cubic_index_revised (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hn : P.normAlpha<0) (hK : P.IsNegativeCutoff h.pell (-1)) (hu : P.u=1)
    {k : ℤ} (hk : 3 ≤ k.natAbs) :
    |(P.normAlpha:ℝ)| * (P.d:ℝ)^2/25 ≤ (P.y h.pell k:ℝ) := by
  have hk0 : k ≠ 0 := by intro he; simp [he] at hk
  have hg := P.section5_geometric_bound h hb hn hK hk0
  simp only [hu,Int.cast_one,one_pow,mul_one] at hg
  have hd5 : (5:ℝ) ≤ P.d := by
    have hh := P.section5_five_le_du_square h
    simp only [hu,one_pow,mul_one] at hh
    exact_mod_cast hh
  have hp := pow_le_pow_right₀ (by linarith : (1:ℝ) ≤ 2*P.d/5)
    (show 2 ≤ k.natAbs-1 by omega)
  have hm := mul_le_mul_of_nonneg_left hp (show 0 ≤ |(P.normAlpha:ℝ)| /4 by positivity)
  nlinarith only [hg,hm]

/-- The two strict cutoff comparisons at the start of the printed proof. -/
theorem lemma52_coarse_cutoffs_revised (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hn : P.normAlpha<0) (hNs : IsSquare (-P.normAlpha)) (hN4 : 4 ≤ -P.normAlpha) :
    (Even P.normAlpha → P.proposition41Threshold < (137/16:ℝ)* |(P.normAlpha:ℝ)|) ∧
    P.proposition41Threshold < (137/4:ℝ)* |(P.normAlpha:ℝ)| := by
  have hnR : (P.normAlpha:ℝ)<0 := by exact_mod_cast hn
  have hN : (4:ℝ) ≤ |(P.normAlpha:ℝ)| := by
    rw [abs_of_neg hnR]
    exact_mod_cast hN4
  constructor
  · intro he
    apply P.section5_above_cutoff h hb hn (by linarith only [hN])
    have hB : (16:ℝ) ≤ P.normalizerSquare := by
      exact_mod_cast P.section5_normalizer_ge_sixteen h hb (ne_of_lt hn) (P.section5_four_dvd_norm hNs he)
    have hh := mul_le_mul_of_nonneg_right hB (by positivity : (0:ℝ) ≤ (137/16:ℝ)* |(P.normAlpha:ℝ)|)
    nlinarith only [hh]
  · apply P.section5_above_cutoff h hb hn (by linarith only [hN])
    have hB : (4:ℝ) ≤ P.normalizerSquare := by
      exact_mod_cast (P.normalizerSquare_bounds h (by simp [hb]) (ne_of_lt hn)).2.1
    have hh := mul_le_mul_of_nonneg_right hB (by positivity : (0:ℝ) ≤ (137/4:ℝ)* |(P.normAlpha:ℝ)|)
    nlinarith only [hh]

/-- The supplementary assertion in the revised Lemma 5.2, with its full
integer-index scope. The odd-norm u=1 case uses the recurrence, not enumeration. -/
theorem lemma52_above_revised (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hn : P.normAlpha<0) (hNs : IsSquare (-P.normAlpha))
    (hK : P.IsNegativeCutoff h.pell (-1)) (hd : 112 ≤ P.d)
    (hN4 : 4 ≤ -P.normAlpha) {k : ℤ} (hk : 2 ≤ k.natAbs)
    (hs : IsIntegerSquare (P.y h.pell k)) :
    P.proposition41Threshold < (P.y h.pell k:ℝ) := by
  have hy := P.section5_nonzero_gt_one_revised h hb hn hK
    (show k ≠ 0 by intro he; simp [he] at hk)
  have hcut := P.lemma52_coarse_cutoffs_revised h hb hn hNs hN4
  have hlarge := P.lemma52_growth_comparisons h hb hn hK hd hk
  by_cases he : Even P.normAlpha
  · exact (hcut.1 he).trans (by nlinarith only [hlarge.1])
  by_cases hu : 2 ≤ P.u
  · apply hcut.2.trans
    have hh := hlarge.2.1 hu
    have hN := (P.section4_norm_range h hb hn).1
    nlinarith only [hh,hN]
  have hu1 : P.u=1 := by have := h.u_pos; omega
  have ho : Odd (-P.normAlpha) := by simpa using he
  have hint : ∃ z:ℤ, P.y h.pell k=(z:ℚ) := by
    obtain ⟨n,hn⟩ := hs
    exact ⟨n^2,by simpa using hn⟩
  have hdiv := (P.integral_iff_three_revised h.pell hb hNs ho hu1 k).mp hint
  have hkn : 3 ∣ k.natAbs := by exact Int.natAbs_dvd_natAbs.mpr hdiv
  have hk3 : 3 ≤ k.natAbs := Nat.le_of_dvd (by omega) hkn
  have hg := P.lemma52_cubic_index_revised h hb hn hK hu1 hk3
  have hN := (P.section4_norm_range h hb hn).1
  have hdR : (112:ℝ) ≤ P.d := by exact_mod_cast hd
  have hd2 : (112:ℝ)^2 ≤ (P.d:ℝ)^2 := by nlinarith
  have hdN := mul_le_mul_of_nonneg_left hd2 hN.le
  have hlarge : (137/4:ℝ) * |(P.normAlpha:ℝ)| < (P.y h.pell k:ℝ) := by
    nlinarith only [hg,hdN,hN]
  exact hcut.2.trans hlarge

/-- The revised Lemma 5.2: two increasing noninitial square values force
the first index to be adjacent, by the printed large-index argument. -/
theorem lemma52_revised (P : Parameters) (hPrior : Hypergeometric.DenominatorEstimate4)
    (hAkhtari : ExternalResults.AkhtariTheorem11) (hCalculation : Calculations.Section46Magma)
    (h : P.Admissible) (hb : P.b=1) (hn : P.normAlpha<0)
    (hNs : IsSquare (-P.normAlpha)) (hK : P.IsNegativeCutoff h.pell (-1))
    {k l : ℤ} (hsk : IsIntegerSquare (P.y h.pell k)) (hsl : IsIntegerSquare (P.y h.pell l))
    (hy : 1<P.y h.pell k) (hkl : P.y h.pell k<P.y h.pell l) : k=1 ∨ k= -1 := by
  have hn1 : P.normAlpha ≠ -1 := by
    intro he
    exact (ne_of_lt hkl) (P.section46_norm_minus_one hAkhtari h hb he hsk hsl hy (hy.trans hkl))
  have hd : 112 ≤ P.d := by
    by_contra he
    exact (ne_of_lt hkl) (P.section46_small_published hAkhtari hCalculation h hb hn hNs
      (by omega) hsk hsl hy (hy.trans hkl))
  have hN4 : 4 ≤ -P.normAlpha := by
    rcases Int.even_or_odd P.normAlpha with he | ho
    · exact (P.lemma52_norm_lower_bounds hn hNs hn1).1 he
    · have := (P.lemma52_norm_lower_bounds hn hNs hn1).2 ho; omega
  by_contra he
  have hk0 : k ≠ 0 := by intro hh; simp [hh,hb] at hy
  have hk2 : 2 ≤ k.natAbs := by
    have hh := Int.natCast_natAbs k
    rcases le_total 0 k with hp | hp
    · rw [abs_of_nonneg hp] at hh; omega
    · rw [abs_of_nonpos hp] at hh; omega
  have hc := P.lemma52_above_revised h hb hn hNs hK hd hN4 hk2 hsk
  exact (ne_of_lt hkl) (proposition41_published hPrior hAkhtari hCalculation P h hb hn hNs
    k l hsk hsl hc (hc.trans (by exact_mod_cast hkl)))

end «JNT-2024».Parameters
