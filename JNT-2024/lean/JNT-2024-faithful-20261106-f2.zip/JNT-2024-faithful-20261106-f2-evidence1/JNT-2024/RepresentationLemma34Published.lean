module

public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».Sequence
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section
namespace «JNT-2024»

theorem lemma34_even_square_mod_four {z : ℤ} (h : Even z) : z ^ 2 % 4 = 0 := by
  obtain ⟨k, hk⟩ := h
  have he : z ^ 2 = 4 * k ^ 2 := by rw [hk]; ring
  rw [he]
  omega

theorem lemma34_odd_square_mod_four {z : ℤ} (h : Odd z) : z ^ 2 % 4 = 1 := by
  obtain ⟨k, hk⟩ := h
  have he : z ^ 2 = 4 * (k ^ 2 + k) + 1 := by rw [hk]; ring
  omega

namespace Parameters

/-- The discriminant congruence used in each printed case. -/
theorem lemma34_discriminant_congruence (P : Parameters)
    (hn : 4 ∣ P.t ^ 2 - P.d * P.u ^ 2) (hu : Odd P.u) :
    P.d % 4 = P.t ^ 2 % 4 := by
  have hm := Int.emod_eq_zero_of_dvd hn
  have hu2 := lemma34_odd_square_mod_four hu
  rw [Int.sub_emod, Int.mul_emod, hu2, mul_one] at hm
  omega

/-- Printed case (i), with t even. -/
theorem lemma34_case_i_even (P : Parameters)
    (hn : 4 ∣ P.t ^ 2 - P.d * P.u ^ 2) (ht : Even P.t) (hau : Odd (P.a * P.u)) :
    P.normAlpha % 4 = 1 ∧ 4 ∣ P.d := by
  obtain ⟨ha, hu⟩ := Int.odd_mul.mp hau
  have hd := P.lemma34_discriminant_congruence hn hu
  rw [lemma34_even_square_mod_four ht] at hd
  have ha2 := lemma34_odd_square_mod_four ha
  constructor
  · unfold normAlpha
    rw [Int.sub_emod, Int.mul_emod, ha2, hd]
    norm_num
  · exact Int.dvd_of_emod_eq_zero hd

/-- Congruences in printed case (i) with t odd, before using (3.4) to
exclude the case. -/
theorem lemma34_case_i_odd_data (P : Parameters)
    (hn : 4 ∣ P.t ^ 2 - P.d * P.u ^ 2) (ht : Odd P.t)
    (htb : Even (P.t * P.b ^ 2)) (hau : Odd (P.a * P.u)) :
    Even P.b ∧ P.d % 4 = 1 ∧ P.normAlpha % 4 = 1 ∧
      (2 * P.a * P.t * P.u + P.b ^ 2 * P.t ^ 2 + P.b ^ 2 * P.d * P.u ^ 2) % 4 = 2 := by
  obtain ⟨ha, hu⟩ := Int.odd_mul.mp hau
  have hb : Even P.b := (Int.even_pow.mp
    ((Int.even_mul.mp htb).resolve_left (Int.not_even_iff_odd.mpr ht))).1
  have hb2 := lemma34_even_square_mod_four hb
  have hb4 : P.b ^ 4 % 4 = 0 := by
    have he : P.b ^ 4 = P.b ^ 2 * P.b ^ 2 := by ring
    rw [he, Int.mul_emod, hb2]
    norm_num
  have hd := P.lemma34_discriminant_congruence hn hu
  rw [lemma34_odd_square_mod_four ht] at hd
  have ha2 := lemma34_odd_square_mod_four ha
  have hN : P.normAlpha % 4 = 1 := by
    unfold normAlpha
    rw [Int.sub_emod, Int.mul_emod, ha2, hb4, hd]
    norm_num
  have hatu : Odd (P.a * P.t * P.u) := (ha.mul ht).mul hu
  obtain ⟨k, hk⟩ := hatu
  have he : 2 * P.a * P.t * P.u = 4 * k + 2 := by nlinarith only [hk]
  have hm1 : (2 * P.a * P.t * P.u) % 4 = 2 := by rw [he]; omega
  have hm2 : (P.b ^ 2 * P.t ^ 2) % 4 = 0 := by rw [Int.mul_emod, hb2]; norm_num
  have hbd : (P.b ^ 2 * P.d) % 4 = 0 := by rw [Int.mul_emod, hb2]; norm_num
  have hm3 : (P.b ^ 2 * P.d * P.u ^ 2) % 4 = 0 := by rw [Int.mul_emod, hbd]; norm_num
  have hm12 : (2 * P.a * P.t * P.u + P.b ^ 2 * P.t ^ 2) % 4 = 2 := by
    rw [Int.add_emod, hm1, hm2]
    norm_num
  refine ⟨hb, hd, hN, ?_⟩
  rw [Int.add_emod, hm12, hm3]
  norm_num

/-- The contradiction 4y² = 2 mod 4 in printed case (i), t odd. -/
theorem lemma34_case_i_odd_impossible (P : Parameters) {x y : ℤ}
    (h : P.RepresentsSquare x y) (hn : 4 ∣ P.t ^ 2 - P.d * P.u ^ 2)
    (ht : Odd P.t) (htb : Even (P.t * P.b ^ 2)) (hau : Odd (P.a * P.u)) : False := by
  have hm := (P.lemma34_case_i_odd_data hn ht htb hau).2.2.2
  rw [← P.representation_y h] at hm
  norm_num [Int.mul_emod] at hm

/-- In printed case (ii), even u would make the norm nonintegral. -/
theorem lemma34_case_ii_even_u_impossible (P : Parameters)
    (hn : 4 ∣ P.t ^ 2 - P.d * P.u ^ 2) (ht : Odd P.t) (hu : Even P.u) : False := by
  have hm := Int.emod_eq_zero_of_dvd hn
  rw [Int.sub_emod, Int.mul_emod, lemma34_odd_square_mod_four ht,
    lemma34_even_square_mod_four hu] at hm
  norm_num at hm

/-- The remaining congruences in printed case (ii), before its contradiction. -/
theorem lemma34_case_ii_odd_u_data (P : Parameters)
    (hn : 4 ∣ P.t ^ 2 - P.d * P.u ^ 2) (htb : Odd (P.t * P.b ^ 2))
    (hau : Even (P.a * P.u)) (hu : Odd P.u) :
    Even P.a ∧ Odd P.b ∧ Odd P.t ∧ P.d % 4 = 1 ∧ P.normAlpha % 4 = 3 ∧
      ((P.b ^ 2 * P.t + P.a * P.u) ^ 2 - P.normAlpha * P.u ^ 2) % 4 = 2 := by
  obtain ⟨ht, hb2odd⟩ := Int.odd_mul.mp htb
  have hb : Odd P.b := by
    apply Int.not_even_iff_odd.mp
    intro hb
    exact (Int.not_even_iff_odd.mpr hb2odd) ((Int.even_pow).mpr ⟨hb, by decide⟩)
  have ha : Even P.a := (Int.even_mul.mp hau).resolve_right (Int.not_even_iff_odd.mpr hu)
  have hd := P.lemma34_discriminant_congruence hn hu
  rw [lemma34_odd_square_mod_four ht] at hd
  have ha2 := lemma34_even_square_mod_four ha
  have hb4 := lemma34_odd_square_mod_four hb2odd
  have he4 : (P.b ^ 2) ^ 2 = P.b ^ 4 := by ring
  rw [he4] at hb4
  have hN : P.normAlpha % 4 = 3 := by
    unfold normAlpha
    rw [Int.sub_emod, Int.mul_emod, ha2, hb4, hd]
    norm_num
  have hcenter : Odd (P.b ^ 2 * P.t + P.a * P.u) := by
    simpa only [mul_comm (P.b ^ 2) P.t] using htb.add_even hau
  have hc2 := lemma34_odd_square_mod_four hcenter
  have hu2 := lemma34_odd_square_mod_four hu
  refine ⟨ha, hb, ht, hd, hN, ?_⟩
  rw [Int.sub_emod, Int.mul_emod, hc2, hN, hu2]
  norm_num

/-- The identity linking the last congruence of case (ii) to (3.4). -/
theorem lemma34_center_square_identity (P : Parameters) {x y : ℤ}
    (h : P.RepresentsSquare x y) :
    (P.b ^ 2 * P.t + P.a * P.u) ^ 2 - P.normAlpha * P.u ^ 2 = 4 * P.b ^ 2 * y ^ 2 := by
  have hy := congrArg (fun z : ℤ => P.b ^ 2 * z) (P.representation_y h)
  unfold normAlpha
  nlinarith only [hy]

/-- The contradiction in the remaining branch of printed case (ii). -/
theorem lemma34_case_ii_odd_u_impossible (P : Parameters) {x y : ℤ}
    (h : P.RepresentsSquare x y) (hn : 4 ∣ P.t ^ 2 - P.d * P.u ^ 2)
    (htb : Odd (P.t * P.b ^ 2)) (hau : Even (P.a * P.u)) (hu : Odd P.u) : False := by
  have hm := (P.lemma34_case_ii_odd_u_data hn htb hau hu).2.2.2.2.2
  rw [P.lemma34_center_square_identity h] at hm
  norm_num [Int.mul_emod] at hm

/-- The printed case (i)/(ii) proof of the parity obstruction. -/
theorem lemma34_odd_center_published (P : Parameters) {x y : ℤ}
    (h : P.RepresentsSquare x y) (hn : 4 ∣ P.t ^ 2 - P.d * P.u ^ 2)
    (ho : Odd (P.t * P.b ^ 2 + P.a * P.u)) : P.normAlpha % 4 = 1 ∧ 4 ∣ P.d := by
  by_cases htb : Even (P.t * P.b ^ 2)
  · have hau : Odd (P.a * P.u) := by
      convert ho.sub_even htb using 1
      ring
    by_cases ht : Even P.t
    · exact P.lemma34_case_i_even hn ht hau
    · exact (P.lemma34_case_i_odd_impossible h hn (Int.not_even_iff_odd.mp ht) htb hau).elim
  · have htb' := Int.not_even_iff_odd.mp htb
    have hau : Even (P.a * P.u) := by
      convert ho.sub_odd htb' using 1
      ring
    have ht := (Int.odd_mul.mp htb').1
    by_cases hu : Even P.u
    · exact (P.lemma34_case_ii_even_u_impossible hn ht hu).elim
    · exact (P.lemma34_case_ii_odd_u_impossible h hn htb' hau (Int.not_even_iff_odd.mp hu)).elim

/-- Lemma 3.4 from all the printed parity cases. Integral epsilon is arbitrary:
no unit, positivity, squarefree-d, or sign restriction has been introduced. -/
theorem lemma34_published (P : Parameters) [Fact (¬ IsSquare P.d)] {x y : ℤ}
    (h : P.RepresentsSquare x y) (hi : IsIntegral ℤ P.epsilon)
    (hex : ¬ (P.normAlpha % 4 = 1 ∧ 4 ∣ P.d)) :
    Even (P.repCandidate y 1) ∧ Even (P.repCandidate y (-1)) ∧
      Even (Int.gcd (P.repCandidate y 1) (P.repCandidate y (-1))) := by
  have hc : Even (P.t * P.b ^ 2 + P.a * P.u) := by
    by_contra hno
    exact hex (P.lemma34_odd_center_published h (P.four_dvd_epsilon_discriminant hi)
      (Int.not_even_iff_odd.mp hno))
  have hr (σ : ℤ) : Even (P.repCandidate y σ) := by
    obtain ⟨c, hc⟩ := hc
    refine ⟨c + σ * P.b * y, ?_⟩
    dsimp [repCandidate]
    nlinarith only [hc]
  refine ⟨hr 1, hr (-1), ?_⟩
  apply even_iff_two_dvd.mpr
  have hg : (2 : ℤ) ∣ (Int.gcd (P.repCandidate y 1) (P.repCandidate y (-1)) : ℤ) :=
    Int.dvd_coe_gcd (even_iff_two_dvd.mp (hr 1)) (even_iff_two_dvd.mp (hr (-1)))
  exact_mod_cast hg

/-- The literal “even unless” statement, without assuming away the exceptional
case. The theorem permits all parameter signs and every integral epsilon
allowed in the paper (and does not need its additional nonzero hypotheses). -/
theorem lemma34_published_statement (P : Parameters) [Fact (¬ IsSquare P.d)] {x y : ℤ}
    (h : P.RepresentsSquare x y) (hi : IsIntegral ℤ P.epsilon) :
    Even (Int.gcd (P.repCandidate y 1) (P.repCandidate y (-1))) ∨
      (P.normAlpha % 4 = 1 ∧ 4 ∣ P.d) := by
  by_cases hex : P.normAlpha % 4 = 1 ∧ 4 ∣ P.d
  · exact Or.inr hex
  · exact Or.inl (P.lemma34_published h hi hex).2.2

end Parameters
end «JNT-2024»
