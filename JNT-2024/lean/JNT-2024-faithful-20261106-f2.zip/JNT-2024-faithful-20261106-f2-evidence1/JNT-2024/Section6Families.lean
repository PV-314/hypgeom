module

public import «JNT-2024».Sequence
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section6

theorem not_square_between {d r : ℤ} (hr : 0 ≤ r) (hlo : r^2 < d) (hhi : d < (r+1)^2) :
    ¬ IsSquare d := by
  rintro ⟨v, hv⟩
  have hv' : d = |v|^2 := by rw [sq_abs]; simpa only [pow_two] using hv
  have habs := abs_nonneg v
  by_cases hh : |v| ≤ r
  · nlinarith
  · have hh' : r+1 ≤ |v| := by omega
    nlinarith

def unitOne (a t : ℤ) : Parameters := ⟨a,1,t^2+4,t,1⟩
def unitTwo (a r : ℤ) : Parameters := ⟨a,1,r^2+1,2*r,2⟩

theorem unitOne_admissible {a t : ℤ} (ha : 0 < a) (ht : 2 ≤ t) :
    (unitOne a t).Admissible := by
  refine ⟨ha, by norm_num [unitOne], by dsimp [unitOne]; positivity,
    by dsimp [unitOne]; omega, by norm_num [unitOne], ?_, Or.inr ?_⟩
  · apply not_square_between (r := t) (by omega) <;> dsimp [unitOne] <;> nlinarith
  · norm_num [unitOne]

theorem unitTwo_admissible {a r : ℤ} (ha : 0 < a) (hr : 1 ≤ r) :
    (unitTwo a r).Admissible := by
  refine ⟨ha, by norm_num [unitTwo], by dsimp [unitTwo]; positivity,
    by dsimp [unitTwo]; omega, by norm_num [unitTwo], ?_, Or.inr ?_⟩
  · apply not_square_between (r := r) (by omega) <;> dsimp [unitTwo] <;> nlinarith
  · dsimp [unitTwo]; ring

theorem unitOne_values (a t : ℤ) (hp : (unitOne a t).Pell) :
    (unitOne a t).normAlpha = a^2-t^2-4 ∧
    (unitOne a t).y hp 1 = ((t : ℚ)^2+a*t+2)/2 ∧
    (unitOne a t).y hp (-1) = ((t : ℚ)^2-a*t+2)/2 := by
  simp only [Parameters.normAlpha, Parameters.y_one, Parameters.y_neg_one, unitOne]
  push_cast
  constructor
  · ring
  constructor <;> ring

theorem unitTwo_values (a r : ℤ) (hp : (unitTwo a r).Pell) :
    (unitTwo a r).normAlpha = a^2-r^2-1 ∧
    (unitTwo a r).y hp 1 = 2*(r : ℚ)^2+2*a*r+1 ∧
    (unitTwo a r).y hp (-1) = 2*(r : ℚ)^2-2*a*r+1 := by
  simp only [Parameters.normAlpha, Parameters.y_one, Parameters.y_neg_one, unitTwo]
  push_cast
  constructor
  · ring
  constructor <;> ring

/-- Integer Pell coordinates of `(1+√2)^(4j+3)`. -/
def pellPair : ℕ → ℤ × ℤ
  | 0 => (7,5)
  | j+1 => (17*(pellPair j).1+24*(pellPair j).2,
             12*(pellPair j).1+17*(pellPair j).2)

def pellP (j : ℕ) : ℤ := (pellPair j).1
def pellQ (j : ℕ) : ℤ := (pellPair j).2

theorem pellPair_properties (j : ℕ) :
    7 ≤ pellP j ∧ 5 ≤ pellQ j ∧ (pellP j)^2-2*(pellQ j)^2 = -1 ∧
    pellP j % 8 = 7 ∧ pellQ j % 4 = 1 := by
  induction j with
  | zero => norm_num [pellP, pellQ, pellPair]
  | succ j ih =>
    change 7 ≤ 17*pellP j+24*pellQ j ∧ 5 ≤ 12*pellP j+17*pellQ j ∧
      (17*pellP j+24*pellQ j)^2-2*(12*pellP j+17*pellQ j)^2 = -1 ∧
      (17*pellP j+24*pellQ j)%8=7 ∧ (12*pellP j+17*pellQ j)%4=1
    refine ⟨by omega, by omega, ?_, by omega, by omega⟩
    nlinarith only [ih.2.2.1]

theorem pellP_strictMono : StrictMono pellP := by
  apply strictMono_nat_of_lt_succ
  intro j
  have hh := pellPair_properties j
  change pellP j < 17*pellP j+24*pellQ j
  omega

/-- The recurrence is exactly the power formula printed in Section 6.5. -/
theorem pellPair_power (j : ℕ) :
    (⟨pellP j, pellQ j⟩ : QuadraticAlgebra ℤ 2 0) =
      (⟨1,1⟩ : QuadraticAlgebra ℤ 2 0)^(4*j+3) := by
  induction j with
  | zero => ext <;> norm_num [pellP, pellQ, pellPair, pow_succ, QuadraticAlgebra.mk_mul_mk]
  | succ j ih =>
    have he : 4*(j+1)+3 = (4*j+3)+4 := by omega
    rw [he, pow_add, ← ih]
    ext <;> simp [pellP, pellQ, pellPair, pow_succ, QuadraticAlgebra.mk_mul_mk] <;> ring

def family65 (j : ℕ) : Parameters := unitOne 2 (pellP j-1)
def family66 (j : ℕ) : Parameters := unitOne 2 (pellP j+1)
def family67 (j : ℕ) : Parameters := unitTwo 1 ((pellP j-1)/2)
def family68 (j : ℕ) : Parameters := unitTwo 1 ((pellP j+1)/2)

theorem families65_68_admissible (j : ℕ) :
    (family65 j).Admissible ∧ (family66 j).Admissible ∧
    (family67 j).Admissible ∧ (family68 j).Admissible := by
  have hh := pellPair_properties j
  exact ⟨unitOne_admissible (by norm_num) (by omega),
    unitOne_admissible (by norm_num) (by omega),
    unitTwo_admissible (by norm_num) (by omega),
    unitTwo_admissible (by norm_num) (by omega)⟩

theorem families65_68_values (j : ℕ) :
    (family65 j).normAlpha = -(pellP j-1)^2 ∧
    (family66 j).normAlpha = -(pellP j+1)^2 ∧
    (family67 j).normAlpha = -((pellP j-1)/2)^2 ∧
    (family68 j).normAlpha = -((pellP j+1)/2)^2 ∧
    (family65 j).y (families65_68_admissible j).1.pell 1 = (pellQ j : ℚ)^2 ∧
    (family66 j).y (families65_68_admissible j).2.1.pell (-1) = (pellQ j : ℚ)^2 ∧
    (family67 j).y (families65_68_admissible j).2.2.1.pell 1 = (pellQ j : ℚ)^2 ∧
    (family68 j).y (families65_68_admissible j).2.2.2.pell (-1) = (pellQ j : ℚ)^2 := by
  have hh := pellPair_properties j
  have hm : 2*((pellP j-1)/2)=pellP j-1 := by omega
  have hp : 2*((pellP j+1)/2)=pellP j+1 := by omega
  have hq : (pellP j : ℚ)^2-2*(pellQ j : ℚ)^2 = -1 := by exact_mod_cast hh.2.2.1
  have hm' : (2 : ℚ)*(((pellP j-1)/2 : ℤ) : ℚ) = pellP j-1 := by exact_mod_cast hm
  have hp' : (2 : ℚ)*(((pellP j+1)/2 : ℤ) : ℚ) = pellP j+1 := by exact_mod_cast hp
  simp only [family65, family66, family67, family68,
    (unitOne_values _ _ _).2.1, (unitOne_values _ _ _).2.2,
    (unitTwo_values _ _ _).2.1, (unitTwo_values _ _ _).2.2]
  push_cast
  refine ⟨by simp [Parameters.normAlpha, unitOne], by simp [Parameters.normAlpha, unitOne],
    by simp [Parameters.normAlpha, unitTwo], by simp [Parameters.normAlpha, unitTwo], ?_, ?_, ?_, ?_⟩ <;>
    nlinarith only [hq, hm', hp']

end «JNT-2024».Section6
