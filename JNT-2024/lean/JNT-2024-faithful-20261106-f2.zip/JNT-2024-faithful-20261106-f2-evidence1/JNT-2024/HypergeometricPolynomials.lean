module

public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

def risingQ (a : ℚ) (j : ℕ) : ℚ := ∏ i ∈ Finset.range j, (a + i)

theorem risingQ_eq_pochhammer (a : ℚ) (j : ℕ) : risingQ a j = (ascPochhammer ℚ j).eval a := by
  induction j with
  | zero => simp [risingQ]
  | succ j ih => rw [risingQ, Finset.prod_range_succ, ← risingQ, ih, ascPochhammer_succ_eval]

def coefficient (ν : ℚ) (r j : ℕ) : ℚ :=
  risingQ (-(r : ℚ) - ν) j * risingQ (-(r : ℚ)) j /
    (risingQ (1 - ν) j * j.factorial)

noncomputable def Xpoly (ν : ℚ) (r : ℕ) : Polynomial ℚ :=
  ∑ j ∈ Finset.range (r + 1), Polynomial.monomial j (coefficient ν r j)

noncomputable def X (ν : ℚ) (r : ℕ) (z : ℂ) : ℂ :=
  ∑ j ∈ Finset.range (r + 1), (coefficient ν r j : ℂ) * z ^ j

noncomputable def Y (ν : ℚ) (r : ℕ) (z : ℂ) : ℂ :=
  ∑ j ∈ Finset.range (r + 1), (coefficient ν r j : ℂ) * z ^ (r - j)

theorem Xpoly_eval (ν : ℚ) (r : ℕ) (z : ℂ) :
    (Xpoly ν r).eval₂ (algebraMap ℚ ℂ) z = X ν r z := by
  simp [Xpoly, X, Polynomial.eval₂_finsetSum]

theorem pochhammer_ratCast (a : ℚ) (j : ℕ) :
    (((ascPochhammer ℚ j).eval a : ℚ) : ℂ) = (ascPochhammer ℂ j).eval (a : ℂ) := by
  induction j with
  | zero => simp
  | succ j ih => simp only [ascPochhammer_succ_eval, Rat.cast_mul, Rat.cast_add, Rat.cast_natCast, ih]

theorem coefficient_eq_hypergeometric (ν : ℚ) (r j : ℕ) :
    (coefficient ν r j : ℂ) =
      ordinaryHypergeometricCoefficient (-(r : ℂ) - ν) (-(r : ℂ)) (1 - ν) j := by
  simp only [coefficient, risingQ_eq_pochhammer, Rat.cast_div, Rat.cast_mul,
    Rat.cast_natCast, pochhammer_ratCast, Rat.cast_sub, Rat.cast_neg, Rat.cast_one,
    ordinaryHypergeometricCoefficient]
  ring

theorem coefficient_vanishes (ν : ℚ) {r j : ℕ} (hj : r < j) : coefficient ν r j = 0 := by
  have hz : risingQ (-(r : ℚ)) j = 0 := by
    rw [risingQ_eq_pochhammer]
    exact (ascPochhammer_eval_eq_zero_iff j _).mpr ⟨r, hj, by simp⟩
  simp [coefficient, hz]

/-- The finite rational polynomial is exactly mathlib's terminating `₂F₁`. -/
theorem X_eq_hypergeometric (ν : ℚ) (r : ℕ) (z : ℂ) :
    X ν r z = ₂F₁ (-(r : ℂ) - ν) (-(r : ℂ)) (1 - ν) z := by
  rw [ordinaryHypergeometric_eq_tsum]
  change X ν r z = ∑' j : ℕ, ordinaryHypergeometricCoefficient
    (-(r : ℂ) - ν) (-(r : ℂ)) (1 - ν) j * z ^ j
  rw [tsum_eq_sum (s := Finset.range (r + 1)) (fun j hj => ?_)]
  · simp only [X, coefficient_eq_hypergeometric]
  · rw [← coefficient_eq_hypergeometric, coefficient_vanishes ν (by simpa using hj)]
    simp

theorem Y_eq_reciprocal (ν : ℚ) (r : ℕ) {z : ℂ} (hz : z ≠ 0) :
    Y ν r z = z ^ r * X ν r z⁻¹ := by
  unfold X Y
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro j hj
  have hjr : j ≤ r := by simpa using hj
  rw [pow_sub₀ z hz hjr, inv_pow]
  ring

theorem X_conj (ν : ℚ) (r : ℕ) (z : ℂ) : star (X ν r z) = X ν r (star z) := by
  simp [X]

/-- The equality of absolute values in Lemma 2.2(d). -/
theorem norm_X_eq_norm_Y (ν : ℚ) (r : ℕ) {z : ℂ} (hz : ‖z‖ = 1) : ‖X ν r z‖ = ‖Y ν r z‖ := by
  have hne : z ≠ 0 := by intro he; simp [he] at hz
  have hinv : z⁻¹ = star z := Complex.inv_eq_conj hz
  rw [Y_eq_reciprocal ν r hne, norm_mul, norm_pow, hz, one_pow, one_mul, hinv, ← X_conj, norm_star]

end Hypergeometric
end «JNT-2024»
