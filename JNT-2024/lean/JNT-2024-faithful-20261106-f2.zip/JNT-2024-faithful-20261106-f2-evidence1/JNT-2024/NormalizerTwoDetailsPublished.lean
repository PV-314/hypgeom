module

public import «JNT-2024».ApproximationGcd
public import «JNT-2024».NormalizerOddPrimePublished
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».NormalizerTwoPublished
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- The remaining printed assertions in case (2.2.2): ell is odd,
v_2(d)=ell, y_k is odd, and 2^(ell+1) divides x_k². The divisibility form
also covers x_k=0, where the usual extended valuation is infinite. -/
theorem normalizer_two_unequal_details (P : Parameters) (h : P.Admissible)
    (hc : Int.gcd P.a P.b = 1) (hn : P.normAlpha < 0) {k X Y : ℤ}
    (hx : P.x h.pell k = X) (hy : P.y h.pell k = Y)
    (hs : padicValInt 2 (squarefreePart P.normAlpha) = 1)
    (hne : padicValInt 2 (P.a ^ 2) ≠ padicValInt 2 (P.d * P.b ^ 4)) :
    Odd (padicValNat 2 P.baseGcd) ∧
    padicValInt 2 P.d = padicValNat 2 P.baseGcd ∧ Odd Y ∧
    (2 : ℤ) ^ (padicValNat 2 P.baseGcd + 1) ∣ X ^ 2 := by
  let e := padicValNat 2 P.baseGcd
  have hvN : padicValInt 2 P.normAlpha = e :=
    (P.initial_norm_two_valuation_cases h (ne_of_lt hn)).2 hne
  have hcN := valuation_squarePart 2 (ne_of_lt hn)
  rw [hs, hvN] at hcN
  have ho : Odd e := ⟨padicValInt 2 (squareFactor P.normAlpha), hcN⟩
  have hodd := Nat.odd_iff.mp ho
  have he : X ^ 2 - P.d * Y ^ 2 = P.normAlpha := by
    have hh := P.norm_identity h.pell k
    rw [hx, hy] at hh
    exact_mod_cast hh
  have hd := P.base_prime_power_divides_norm_and_square hc 2 he
  have hgd : e = min (2 * padicValInt 2 P.a) (padicValInt 2 P.d) := by
    dsimp [e]
    rw [P.baseGcd_eq_ad_published hc, valuation_gcd 2
      (pow_ne_zero _ (ne_of_gt h.a_pos)) (ne_of_gt h.d_pos), valuation_int_pow]
  have hdv : padicValInt 2 P.d = e := by omega
  have hxplus : (2 : ℤ) ^ (e + 1) ∣ X ^ 2 := by
    by_cases hz : X = 0
    · simp [hz]
    have hv := ((padicValInt_dvd_iff _ _).mp hd.2).resolve_left (pow_ne_zero _ hz)
    apply (padicValInt_dvd_iff _ _).mpr
    right
    rw [valuation_int_pow] at hv ⊢
    change e ≤ 2 * padicValInt 2 X at hv
    simp only [padicValInt] at hv ⊢
    omega
  have hyodd : Odd Y := by
    apply Int.not_even_iff_odd.mp
    intro hyE
    have hD : (2 : ℤ) ^ e ∣ P.d := (padicValInt_dvd_iff _ _).mpr (Or.inr (by rw [hdv]))
    have hY : (2 : ℤ) ∣ Y ^ 2 := dvd_pow (even_iff_two_dvd.mp hyE) (by decide)
    have hDY : (2 : ℤ) ^ (e + 1) ∣ P.d * Y ^ 2 := by
      rw [pow_succ]
      exact mul_dvd_mul hD hY
    have hN := dvd_sub hxplus hDY
    rw [he] at hN
    have hv := ((padicValInt_dvd_iff _ _).mp hN).resolve_left (ne_of_lt hn)
    rw [hvN] at hv
    omega
  exact ⟨ho,hdv,hyodd,hxplus⟩

end «JNT-2024».Parameters

namespace «JNT-2024».Approximation

/-- The last displayed comparison in case (2.2.2), as integer divisibility.
For a nonzero quotient this is exactly valuation at least one. -/
theorem normalized_first_coordinate_even_of_g2_valuation {S u₁ u₂ : ℤ}
    (hv : padicValNat 2 (g2 S u₁ u₂) = 1) : Even (u₁ / (g1 u₁ u₂ : ℤ)) := by
  have hd : (2 : ℕ) ∣ g2 S u₁ u₂ := dvd_of_one_le_padicValNat (by omega : 1 ≤ padicValNat 2 (g2 S u₁ u₂))
  have hd' : (2 : ℤ) ∣ (g2 S u₁ u₂ : ℤ) := by exact_mod_cast hd
  exact even_iff_two_dvd.mpr (hd'.trans (Int.gcd_dvd_left _ _))

end «JNT-2024».Approximation
