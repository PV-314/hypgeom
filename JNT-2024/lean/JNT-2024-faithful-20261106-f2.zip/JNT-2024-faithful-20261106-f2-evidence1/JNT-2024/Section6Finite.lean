module

public import «JNT-2024».Section6Sequence
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.IsPrimePow
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.NormNum.Prime
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section6

/-- All fourteen rows of Table 2, with the printed indices and roots. -/
def table2 : Fin 14 → Row 4 := ![
  ⟨⟨1,3,2,2,2⟩, ![0,-1,3,-5], ![3,5,31,167]⟩,
  ⟨⟨1019,27,2,2,2⟩, ![0,1,-3,-7], ![27,65,29,983]⟩,
  ⟨⟨167,13,2,2,2⟩, ![0,1,-3,4], ![13,29,71,407]⟩,
  ⟨⟨157,29,2,2,2⟩, ![0,-1,3,-4], ![29,47,307,649]⟩,
  ⟨⟨1,41,2,2,2⟩, ![0,-1,-9,11], ![41,71,80753,470861]⟩,
  ⟨⟨1633,65,2,2,2⟩, ![0,-1,-4,7], ![65,97,1331,24791]⟩,
  ⟨⟨48479,211,2,2,2⟩, ![0,-3,4,-7], ![211,1007,6743,34205]⟩,
  ⟨⟨45649,677,2,2,2⟩, ![0,-1,-4,4], ![677,1133,15679,16825]⟩,
  ⟨⟨1940147,1217,2,2,2⟩, ![0,-3,4,-11], ![1217,3289,40573,3794239]⟩,
  ⟨⟨600589,2213,2,2,2⟩, ![0,-1,-4,4], ![2213,3673,50801,55415]⟩,
  ⟨⟨20509501,8689,2,2,2⟩, ![0,-1,3,-4], ![8689,13619,94393,187603]⟩,
  ⟨⟨255488029,13457,2,2,2⟩, ![0,-1,3,-4], ![13457,5683,189241,15821]⟩,
  ⟨⟨409660129,17023,2,2,2⟩, ![0,-1,-4,-8], ![17023,7073,7949,269495]⟩,
  ⟨⟨3032771269,46313,2,2,2⟩, ![0,-1,-4,-8], ![46313,19213,15269,516625]⟩]

/-- The six additional examples in Section 6.1; omitted indices are supplied explicitly. -/
def additional61 : Fin 6 → Row 4 := ![
  ⟨⟨672,91,3,4,2⟩, ![0,-2,-4,2], ![91,875,12187,917]⟩,
  ⟨⟨78,7,6,10,4⟩, ![0,-1,-2,2], ![7,29,287,623]⟩,
  ⟨⟨34986,149,6,10,4⟩, ![0,-1,-3,1], ![149,623,61033,1337]⟩,
  ⟨⟨3663828,2257,6,10,4⟩, ![0,-1,-5,1], ![2257,13279,127492799,17969]⟩,
  ⟨⟨826320,1111,30,22,4⟩, ![0,-1,-2,1], ![1111,16159,354761,18271]⟩,
  ⟨⟨138,5,37,12,2⟩, ![0,-1,-2,1], ![5,13,157,59]⟩]

/-- Section 6.3 uses the unsquared unit and the printed indices. -/
def triples63 : Fin 4 → Row 3 := ![
  ⟨⟨43,3,5,1,1⟩, ![-3,0,11], ![5,3,53]⟩,
  ⟨⟨1,1,10,6,2⟩, ![0,1,2], ![1,2,5]⟩,
  ⟨⟨153,4,5,1,1⟩, ![-3,0,30], ![11,4,8862]⟩,
  ⟨⟨2,1,51,100,14⟩, ![-1,0,1], ![6,1,8]⟩]

def quadruples63 : Fin 2 → Row 4 := ![
  ⟨⟨7,1,5,1,1⟩, ![-9,0,1,3], ![9,1,2,3]⟩,
  ⟨⟨2,3,6,10,4⟩, ![-3,0,1,3], ![63,3,7,69]⟩]

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option synthInstance.maxSize 1000

theorem table2_checked : ∀ i, (table2 i).Checked false := by decide +kernel
theorem additional61_checked : ∀ i, (additional61 i).Checked false := by decide +kernel
theorem triples63_checked : ∀ i, (triples63 i).Checked true := by decide +kernel
theorem quadruples63_checked : ∀ i, (quadruples63 i).Checked true := by decide +kernel

theorem table2_four_squares (i : Fin 14) :
    AtLeastSquares ((table2 i).parameters.y (table2_checked i).1.admissible.pell) 4 :=
  Row.lower_bound (table2_checked i)

theorem additional61_four_squares (i : Fin 6) :
    AtLeastSquares ((additional61 i).parameters.y (additional61_checked i).1.admissible.pell) 4 :=
  Row.lower_bound (additional61_checked i)

theorem triples63_three_squares (i : Fin 4) :
    AtLeastSquares ((triples63 i).parameters.generalY (triples63_checked i).1.admissible.pell) 3 :=
  Row.lower_bound (triples63_checked i)

theorem quadruples63_four_squares (i : Fin 2) :
    AtLeastSquares ((quadruples63 i).parameters.generalY (quadruples63_checked i).1.admissible.pell) 4 :=
  Row.lower_bound (quadruples63_checked i)

theorem section63_norms :
    (triples63 0).parameters.normAlpha = 38^2 ∧
    (triples63 1).parameters.normAlpha = -(3^2) ∧
    (triples63 2).parameters.normAlpha = 22129 ∧
    (triples63 3).parameters.normAlpha = -47 ∧
    (quadruples63 0).parameters.normAlpha = 2^2*11 ∧
    (quadruples63 1).parameters.normAlpha = -2*241 := by decide +kernel

theorem section63_primes : Nat.Prime 22129 ∧ Nat.Prime 47 ∧ Nat.Prime 11 ∧ Nat.Prime 241 := by
  norm_num

theorem section63_arithmetic_classes :
    IsSquare |(triples63 0).parameters.normAlpha| ∧
    IsSquare |(triples63 1).parameters.normAlpha| ∧
    IsPrimePow (triples63 2).parameters.normAlpha.natAbs ∧
    IsPrimePow (triples63 3).parameters.normAlpha.natAbs ∧
    ¬ IsPrimePow (quadruples63 0).parameters.normAlpha.natAbs ∧
    squarefreePart |(quadruples63 0).parameters.normAlpha| = 11 ∧
    squarefreePart |(quadruples63 1).parameters.normAlpha| = 2*241 := by
  change IsSquare (1444 : ℤ) ∧ IsSquare (9 : ℤ) ∧ IsPrimePow (22129 : ℕ) ∧
    IsPrimePow (47 : ℕ) ∧ ¬ IsPrimePow (44 : ℕ) ∧ squarefreePart 44=11 ∧ squarefreePart 482=482
  refine ⟨⟨38,by norm_num⟩,⟨3,by norm_num⟩,section63_primes.1.isPrimePow,
    section63_primes.2.1.isPrimePow,by decide +kernel,?_,?_⟩
  · apply squarefreePart_eq_of_factorization (c := 2) (by norm_num)
    · exact Int.squarefree_natCast.mpr (by decide +kernel : Squarefree (11 : ℕ))
    · norm_num
  · apply squarefreePart_eq_of_factorization (c := 1) (by norm_num)
    · exact Int.squarefree_natCast.mpr (by decide +kernel : Squarefree (482 : ℕ))
    · norm_num

/-- Every even-power example also occurs in the general sequence at doubled indices. -/
theorem even_examples_general {P : Parameters} {hp : P.Pell} {m : ℕ}
    (h : AtLeastSquares (P.y hp) m) : AtLeastSquares (P.generalY hp) m := by
  obtain ⟨k, hi, hs⟩ := h
  refine ⟨fun i => 2*k i, ?_, ?_⟩
  · simpa only [P.generalY_even] using hi
  · simpa only [P.generalY_even] using hs

end «JNT-2024».Section6
