module

public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- The inequality obtained by comparing the lattice lower bound with (3.21). -/
def GapInequality (C A x y : ℝ) : Prop :=
  C * A * x ^ 3 * y ^ 3 < (5051 / 10000 : ℝ) ^ 4 * (x + y) ^ 4

theorem gap_bootstrap {C A x y r K : ℝ} (hA : 0 < A) (hx : 0 < x) (hy : 0 < y) (hr : 0 < r)
    (_hK : 0 < K) (hC : K * (5051 / 10000 : ℝ) ^ 4 * (1 + 1 / r) ^ 4 ≤ C)
    (hxy : r * x ≤ y) (hgap : GapInequality C A x y) : K * A * x ^ 3 < y := by
  have hb : x + y ≤ (1 + 1 / r) * y := by
    have hh := (le_div_iff₀ hr).mpr (show x * r ≤ y by simpa only [mul_comm] using hxy)
    calc
      x + y ≤ y / r + y := by linarith only [hh]
      _ = (1 + 1 / r) * y := by ring
  have hb' : (x + y) ^ 4 ≤ ((1 + 1 / r) * y) ^ 4 := by
    exact pow_le_pow_left₀ (by positivity) hb 4
  have hm := mul_le_mul_of_nonneg_left hb' (by norm_num : (0 : ℝ) ≤ (5051 / 10000) ^ 4)
  have he : C * A * x ^ 3 * y ^ 3 <
      ((5051 / 10000 : ℝ) ^ 4 * (1 + 1 / r) ^ 4 * y) * y ^ 3 := by
    dsimp [GapInequality] at hgap
    calc
      _ < _ := hgap
      _ ≤ _ := by convert hm using 1; ring
  have he' := (mul_lt_mul_iff_left₀ (pow_pos hy 3)).mp he
  have hc := mul_le_mul_of_nonneg_right hC (show 0 ≤ A * x ^ 3 by positivity)
  have hD : 0 < (5051 / 10000 : ℝ) ^ 4 * (1 + 1 / r) ^ 4 := by positivity
  apply (mul_lt_mul_iff_right₀ hD).mp
  calc
    _ ≤ C * A * x ^ 3 := by convert hc using 1 <;> ring
    _ < _ := he'

theorem gap_basic {C A x y K : ℝ} (hA : 0 < A) (hx : 0 < x) (hxy : x < y)
    (hK : 0 < K) (hc : K * (5051 / 10000 : ℝ) ^ 4 * 16 ≤ C)
    (hg : GapInequality C A x y) : K * A * x ^ 3 < y := by
  apply gap_bootstrap hA hx (lt_trans hx hxy) (r := 1) (by norm_num) hK
    (by norm_num at hc ⊢; exact hc) (by linarith) hg

theorem gap_ratio {A x y K ρ : ℝ} (hx : 0 < x) (hK : 0 < K)
    (hscale : ρ ≤ A * x ^ 2) (hg : K * A * x ^ 3 < y) : (K * ρ) * x < y := by
  have hh := mul_le_mul_of_nonneg_left hscale (le_of_lt (mul_pos hK hx))
  nlinarith only [hg, hh]

/-- The Gaussian-lattice bootstrap in Lemma 3.8(a), with all decimals exact. -/
theorem gap_gaussian {A x y : ℝ} (hA : 0 < A) (hx : 0 < x) (hxy : x < y)
    (hscale : 1 ≤ A * x ^ 2) (hg : GapInequality 4 A x y) :
    (5732 / 100 : ℝ) * A * x ^ 3 < y := by
  have h₀ := gap_basic hA hx hxy (K := 384 / 100) (by norm_num) (by norm_num) hg
  have h₁ := gap_bootstrap hA hx (lt_trans hx hxy) (r := 384 / 100) (K := 2434 / 100)
    (by norm_num) (by norm_num) (by norm_num)
    (by simpa using (gap_ratio hx (by norm_num) hscale h₀).le) hg
  have h₂ := gap_bootstrap hA hx (lt_trans hx hxy) (r := 2434 / 100) (K := 5231 / 100)
    (by norm_num) (by norm_num) (by norm_num)
    (by simpa using (gap_ratio hx (by norm_num) hscale h₁).le) hg
  have h₃ := gap_bootstrap hA hx (lt_trans hx hxy) (r := 5231 / 100) (K := 5697 / 100)
    (by norm_num) (by norm_num) (by norm_num)
    (by simpa using (gap_ratio hx (by norm_num) hscale h₂).le) hg
  exact gap_bootstrap hA hx (lt_trans hx hxy) (r := 5697 / 100) (K := 5732 / 100)
    (by norm_num) (by norm_num) (by norm_num)
    (by simpa using (gap_ratio hx (by norm_num) hscale h₃).le) hg

/-- The first bound in Lemma 3.8(b). -/
theorem gap_quadratic {A x y : ℝ} (hA : 0 < A) (hx : 0 < x) (hxy : x < y)
    (hg : GapInequality 16 A x y) : (1536 / 100 : ℝ) * A * x ^ 3 < y :=
  gap_basic hA hx hxy (by norm_num) (by norm_num) hg


/-- Published 1.09 step, followed by the stated nine further iterations. -/
theorem gap_quadratic_strong {A x y : ℝ} (hA : 0 < A) (hx : 0 < x) (hxy : x < y)
    (hscale : (427 / 1600 : ℝ) ^ 2 ≤ A * x ^ 2) (hg : GapInequality 16 A x y) :
    182 * A * x ^ 3 < y := by
  have h₀ := gap_quadratic hA hx hxy hg
  have step : ∀ K L : ℝ, 0 < K → 0 < L →
      L * (5051 / 10000 : ℝ) ^ 4 * (1 + 1 / (K * (427 / 1600) ^ 2)) ^ 4 ≤ 16 →
      K * A * x ^ 3 < y → L * A * x ^ 3 < y := by
    intro K L hK hL hc hh
    exact gap_bootstrap hA hx (lt_trans hx hxy) (by positivity) hL hc
      (gap_ratio hx hK hscale hh).le hg
  have h09 : (109 / 100 : ℝ) * x < y := by
    have hh := gap_ratio hx (by norm_num) hscale h₀
    have hnum : (109 / 100 : ℝ) < (1536 / 100) * (427 / 1600) ^ 2 := by norm_num
    exact lt_trans (mul_lt_mul_of_pos_right hnum hx) hh
  have h₁ := gap_bootstrap hA hx (lt_trans hx hxy) (r := 109 / 100) (K := 1818 / 100)
    (by norm_num) (by norm_num) (by norm_num) h09.le hg
  have h₂ := step (1818 / 100) (2491 / 100) (by norm_num) (by norm_num) (by norm_num) h₁
  have h₃ := step (2491 / 100) (4111 / 100) (by norm_num) (by norm_num) (by norm_num) h₂
  have h₄ := step (4111 / 100) (7589 / 100) (by norm_num) (by norm_num) (by norm_num) h₃
  have h₅ := step (7589 / 100) (12465 / 100) (by norm_num) (by norm_num) (by norm_num) h₄
  have h₆ := step (12465 / 100) (16039 / 100) (by norm_num) (by norm_num) (by norm_num) h₅
  have h₇ := step (16039 / 100) (17572 / 100) (by norm_num) (by norm_num) (by norm_num) h₆
  have h₈ := step (17572 / 100) (18074 / 100) (by norm_num) (by norm_num) (by norm_num) h₇
  have h₉ := step (18074 / 100) 182 (by norm_num) (by norm_num) (by norm_num) h₈
  exact step 182 182 (by norm_num) (by norm_num) (by norm_num) h₉

end «JNT-2024»
