module

public import «JNT-2024».ApproximationCriterion
public import «JNT-2024».EulerIntegral
public import «JNT-2024».GammaBounds
public import «JNT-2024».HypergeometricPolynomials
public import «JNT-2024».RemainderCoefficients
public import «JNT-2024».RemainderConstruction
public import «JNT-2024».RemainderIdentity
public import «JNT-2024».RemainderLowerBoundRevised
public import «JNT-2024».Section2Bounds
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

open Hypergeometric

/-- The strict last inequality of (4.16), derived from minimality of the actual cutoff. -/
theorem cutoff_norm_lower {E Q ℓ c : ℝ} (hE : 1 < E) (hQ : 190 < Q)
    (hℓ : 0 < ℓ) (hc : 0 < c) (z : ℂ)
    (hr : 1 < Approximation.firstIndex (Q := Q) (ℓ := ℓ) hE hc z) :
    (994 / 1000 : ℝ) * c * E ^ (Approximation.firstIndex (Q := Q) (ℓ := ℓ) hE hc z - 1) / ℓ < ‖z‖ := by
  let r := Approximation.firstIndex (Q := Q) (ℓ := ℓ) hE hc z
  have hE0 : 0 < E := by linarith
  have hQ0 : 0 < Q := by linarith
  have hnot : ¬ Approximation.Cutoff E Q ℓ c z (r - 1) := by
    intro hh
    have hm := Approximation.firstIndex_le hE hc z (show 0 < r - 1 by dsimp [r]; omega) hh
    change r ≤ r - 1 at hm
    dsimp [r] at hm
    omega
  have hb : c * E ^ (r - 1) ≤ (Q - 1 / E) * ℓ * ‖z‖ / (Q - 1) := le_of_not_gt hnot
  have hb' := (le_div_iff₀ (show 0 < Q - 1 by linarith)).mp hb
  have hconst : (994 / 1000 : ℝ) * Q < Q - 1 := by linarith
  have hh := mul_lt_mul_of_pos_left hconst (mul_pos hc (pow_pos hE0 (r - 1)))
  have hu := mul_le_mul_of_nonneg_right (sub_le_self Q (one_div_nonneg.mpr hE0.le))
    (show 0 ≤ ℓ * ‖z‖ by positivity)
  apply (div_lt_iff₀ hℓ).mpr
  apply (mul_lt_mul_iff_left₀ hQ0).mp
  change (994 / 1000 : ℝ) * c * E ^ (r - 1) * Q < ‖z‖ * ℓ * Q
  nlinarith only [hh, hb', hu]

/-- Equation (4.13), as an inequality of norms, for the paper's actual hypergeometric functions. -/
theorem exact_approximant_error_lower {ω : ℂ} (hω : ‖ω‖ = 1) (hnear : ‖ω - 1‖ < 1)
    (r : ℕ) (hY : Y (1 / 4) r ω ≠ 0) :
    (remainderCoefficient r : ℝ) * ‖ω - 1‖ ^ (2 * r + 1) / ‖Y (1 / 4) r ω‖ ≤
      ‖ω ^ (1 / 4 : ℂ) - X (1 / 4) r ω / Y (1 / 4) r ω‖ := by
  have hF := lemma22e_revised (ν := 1 / 4) (by norm_num) (by norm_num) r hω hnear
  have hidentity := lemma22a (ν := 1 / 4) (by norm_num) (by norm_num) r hnear
  rw [← remainder_eq_hypergeometric (1 / 4) r hnear] at hidentity
  have he : ω ^ (1 / 4 : ℂ) - X (1 / 4) r ω / Y (1 / 4) r ω =
      remainder (1 / 4) r ω / Y (1 / 4) r ω := by
    apply (eq_div_iff hY).mpr
    rw [sub_mul, div_mul_cancel₀ _ hY]
    simpa only [Rat.cast_div, Rat.cast_one, Rat.cast_ofNat] using hidentity
  rw [he, norm_div]
  apply (div_le_div_iff_of_pos_right (norm_pos_iff.mpr hY)).mpr
  have hcoef : (0 : ℝ) ≤ (remainderCoefficient r : ℝ) := by exact_mod_cast (remainderCoefficient_pos r).le
  have hh := mul_le_mul_of_nonneg_left hF
    (show 0 ≤ (remainderCoefficient r : ℝ) * ‖ω - 1‖ ^ (2 * r + 1) by positivity)
  rw [remainder, norm_mul, norm_mul, norm_pow, remainderPrefactor_quarter,
    Complex.norm_ratCast, abs_of_nonneg hcoef]
  convert hh using 1 <;> ring

/-- The numerical coefficient in Section 4.3, using the printed `1.072` from Lemma 2.2(d). -/
theorem remainder_gamma_ratio_lower {r : ℕ} (hr : 1 ≤ r) :
    (2915 / 10000 : ℝ) / (4 ^ r * Real.sqrt r) <
      2 * (remainderCoefficient r : ℝ) / (Section2.paperFactor * (gammaRatio r : ℝ)) := by
  have hr0 : (0 : ℝ) < r := by exact_mod_cast (by omega : 0 < r)
  let t : ℝ := (r : ℝ) ^ (1 / 4 : ℝ)
  have ht : 0 < t := Real.rpow_pos_of_pos hr0 _
  have ht2 : t ^ 2 = Real.sqrt r := by
    dsimp [t]
    rw [← Real.rpow_mul_natCast hr0.le, Real.sqrt_eq_rpow]
    norm_num
  have hgamma : (gammaRatio r : ℝ) ≤ 4 * t / 3 := by
    simpa only [gammaRatio_eq_gamma] using lemma23b_gamma hr
  have hc := lemma23b_remainder hr
  change (5 : ℝ) / (24 * 4 ^ r * t) ≤ (remainderCoefficient r : ℝ) at hc
  have hc' := (div_le_iff₀ (show 0 < 24 * (4 : ℝ) ^ r * t by positivity)).mp hc
  have hg : (0 : ℝ) < (gammaRatio r : ℝ) := by exact_mod_cast gammaRatio_pos r
  apply (div_lt_div_iff₀ (mul_pos (by positivity) (Real.sqrt_pos.mpr hr0))
    (mul_pos (by norm_num [Section2.paperFactor]) hg)).mpr
  rw [← ht2]
  have hlow := mul_le_mul_of_nonneg_right hc' ht.le
  have hhigh := mul_le_mul_of_nonneg_left hgamma
    (by norm_num [Section2.paperFactor] : 0 ≤ (2915 / 10000 : ℝ) * Section2.paperFactor)
  norm_num [Section2.paperFactor] at hhigh ⊢
  nlinarith only [hlow, hhigh, ht]


end «JNT-2024».Section4
