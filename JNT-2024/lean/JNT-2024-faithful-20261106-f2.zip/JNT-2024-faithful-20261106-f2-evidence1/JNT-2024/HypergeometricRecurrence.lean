module

public import «JNT-2024».HypergeometricPolynomials
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

theorem risingQ_succ (a : ℚ) (j : ℕ) : risingQ a (j + 1) = risingQ a j * (a + j) := by
  simp only [risingQ_eq_pochhammer, ascPochhammer_succ_eval]

theorem risingQ_succ_left (a : ℚ) (j : ℕ) :
    risingQ (a - 1) (j + 1) = (a - 1) * risingQ a j := by
  simp [risingQ_eq_pochhammer, ascPochhammer_succ_left, Polynomial.eval_mul,
    Polynomial.eval_comp]

theorem risingQ_shift (a : ℚ) (j : ℕ) :
    risingQ (a - 1) j * (a + j - 1) = (a - 1) * risingQ a j := by
  simpa [risingQ_succ, sub_add_eq_add_sub] using risingQ_succ_left a j

theorem coefficient_lower_degree (ν : ℚ) (r j : ℕ) :
    (r + 1 : ℚ) * (r + 1 + ν) * coefficient ν r j =
      (r + 1 - j) * (r + 1 + ν - j) * coefficient ν (r + 1) j := by
  have h₁ : risingQ (-(r + 1 : ℚ) - ν) j * (r + 1 + ν - j) =
      (r + 1 + ν) * risingQ (-(r : ℚ) - ν) j := by
    have h := risingQ_shift (-(r : ℚ) - ν) j
    convert congrArg Neg.neg h using 1 <;> ring_nf
  have h₂ : risingQ (-(r + 1 : ℚ)) j * (r + 1 - j) =
      (r + 1) * risingQ (-(r : ℚ)) j := by
    have h := risingQ_shift (-(r : ℚ)) j
    convert congrArg Neg.neg h using 1 <;> ring_nf
  simp only [coefficient, Nat.cast_add, Nat.cast_one]
  calc
    _ = ((r + 1 + ν) * risingQ (-(r : ℚ) - ν) j) *
        ((r + 1) * risingQ (-(r : ℚ)) j) /
        (risingQ (1 - ν) j * j.factorial) := by ring
    _ = _ := by rw [← h₁, ← h₂]; ring

theorem coefficient_lower_diagonal {ν : ℚ} (hν : ν < 1) (r j : ℕ) :
    (r + 1 : ℚ) * (r + 1 + ν) * coefficient ν r j =
      (j + 1) * (j + 1 - ν) * coefficient ν (r + 1) (j + 1) := by
  have hd : risingQ (1 - ν) j ≠ 0 :=
    ne_of_gt (risingQ_eq_pochhammer (1 - ν) j ▸ ascPochhammer_pos j (1 - ν) (by linarith))
  have hf : (j.factorial : ℚ) ≠ 0 := by positivity
  have hj : (j + 1 - ν : ℚ) ≠ 0 := by
    have : (0 : ℚ) ≤ j := Nat.cast_nonneg j
    linarith
  have h₁ : risingQ (-(r + 1 : ℚ) - ν) (j + 1) =
      (-(r : ℚ) - ν - 1) * risingQ (-(r : ℚ) - ν) j := by
    convert risingQ_succ_left (-(r : ℚ) - ν) j using 1
    congr 1
    ring
  have h₂ : risingQ (-(r + 1 : ℚ)) (j + 1) =
      (-(r : ℚ) - 1) * risingQ (-(r : ℚ)) j := by
    convert risingQ_succ_left (-(r : ℚ)) j using 1
    congr 1
    ring
  simp only [coefficient, Nat.cast_add, Nat.cast_one, h₁, h₂, risingQ_succ,
    Nat.factorial_succ, Nat.cast_mul]
  have hj' : (1 - ν + j : ℚ) ≠ 0 := by linarith
  field_simp
  ring

theorem coefficient_zero (ν : ℚ) (r : ℕ) : coefficient ν r 0 = 1 := by
  simp [coefficient, risingQ]

theorem coefficient_one (ν : ℚ) (r : ℕ) :
    coefficient ν r 1 = (r : ℚ) * (r + ν) / (1 - ν) := by
  simp [coefficient, risingQ]
  ring

theorem coefficient_recurrence {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1) (r j : ℕ) :
    (r + 2 - ν : ℚ) * coefficient ν (r + 2) (j + 2) =
      (2 * r + 3) * (coefficient ν (r + 1) (j + 2) + coefficient ν (r + 1) (j + 1)) -
      (r + 1 + ν) * (coefficient ν r (j + 2) - 2 * coefficient ν r (j + 1) + coefficient ν r j) := by
  have h₁ := coefficient_lower_degree ν (r + 1) (j + 2)
  have h₂ := coefficient_lower_diagonal hν₁ (r + 1) (j + 1)
  have h₃ := coefficient_lower_degree ν r (j + 2)
  have h₄ := coefficient_lower_degree ν r (j + 1)
  have h₅ := coefficient_lower_diagonal hν₁ r j
  simp only [Nat.cast_add, Nat.cast_one, Nat.cast_ofNat, Nat.add_assoc] at h₁ h₂ h₃ h₄ h₅
  have hk : ((r : ℚ) + 2) * (r + 2 + ν) * ((r + 1) * (r + 1 + ν)) ≠ 0 := by positivity
  apply mul_left_cancel₀ hk
  linear_combination
    ((r + 1 + ν) * (r - j - 1) * (r + ν - j - 1) -
      (2 * r + 3) * ((r + 1) * (r + 1 + ν))) * h₁ +
    ((r + 1 + ν) * ((j + 1) * (j + 1 - ν) - 2 * (r - j) * (r + ν - j)) -
      (2 * r + 3) * ((r + 1) * (r + 1 + ν))) * h₂ +
    ((r + 2) * (r + 2 + ν) * (r + 1 + ν)) * (h₃ - 2 * h₄ + h₅)

theorem Xpoly_coeff (ν : ℚ) (r j : ℕ) : (Xpoly ν r).coeff j = coefficient ν r j := by
  simp only [Xpoly, Polynomial.finsetSum_coeff, Polynomial.coeff_monomial]
  by_cases hj : j < r + 1
  · simp [Finset.mem_range.mpr hj]
  · simp [Finset.mem_range, hj, coefficient_vanishes ν (by omega : r < j)]

theorem Xpoly_recurrence {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1) (r : ℕ) :
    Polynomial.C (r + 2 - ν) * Xpoly ν (r + 2) =
      Polynomial.C (2 * r + 3 : ℚ) * (1 + Polynomial.X) * Xpoly ν (r + 1) -
      Polynomial.C (r + 1 + ν) * (1 - Polynomial.X) ^ 2 * Xpoly ν r := by
  have he : Polynomial.C (2 * r + 3 : ℚ) * (1 + Polynomial.X) * Xpoly ν (r + 1) -
      Polynomial.C (r + 1 + ν) * (1 - Polynomial.X) ^ 2 * Xpoly ν r =
      Polynomial.C (2 * r + 3 : ℚ) * (Xpoly ν (r + 1) + Polynomial.X * Xpoly ν (r + 1)) -
      Polynomial.C (r + 1 + ν) * (Xpoly ν r - 2 * (Polynomial.X * Xpoly ν r) +
        Polynomial.X * (Polynomial.X * Xpoly ν r)) := by ring
  rw [he]
  ext j
  rcases j with _ | (_ | j)
  · simp [Xpoly_coeff, coefficient_zero]
    ring
  · simp only [Nat.zero_add]
    simp only [Polynomial.coeff_C_mul, Polynomial.coeff_add, Polynomial.coeff_sub,
      Polynomial.coeff_ofNat_mul, Polynomial.coeff_X_mul, Polynomial.coeff_X_mul_zero,
      Xpoly_coeff, coefficient_zero, coefficient_one]
    have hn : 1 - ν ≠ 0 := by linarith
    push_cast
    field_simp
    ring
  · simp only [Polynomial.coeff_C_mul, Polynomial.coeff_add, Polynomial.coeff_sub,
      Polynomial.coeff_ofNat_mul, Polynomial.coeff_X_mul, Xpoly_coeff]
    exact coefficient_recurrence hν₀ hν₁ r j

theorem X_recurrence {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1) (r : ℕ) (z : ℂ) :
    (r + 2 - (ν : ℂ)) * X ν (r + 2) z =
      (2 * r + 3) * (1 + z) * X ν (r + 1) z -
      (r + 1 + ν) * (1 - z) ^ 2 * X ν r z := by
  have h := congrArg (Polynomial.eval₂ (algebraMap ℚ ℂ) z) (Xpoly_recurrence hν₀ hν₁ r)
  simpa only [Polynomial.eval₂_mul, Polynomial.eval₂_C, Polynomial.eval₂_add,
    Polynomial.eval₂_one, Polynomial.eval₂_X, Polynomial.eval₂_sub, Polynomial.eval₂_pow,
    Xpoly_eval, eq_ratCast, Rat.cast_sub, Rat.cast_add, Rat.cast_mul, Rat.cast_natCast,
    Rat.cast_ofNat, Rat.cast_one] using h

end Hypergeometric
end «JNT-2024»
