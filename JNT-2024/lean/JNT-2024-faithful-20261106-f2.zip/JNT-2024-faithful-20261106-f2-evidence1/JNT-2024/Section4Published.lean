module

public import «JNT-2024».AkhtariInput
public import «JNT-2024».DenominatorBounds
public import «JNT-2024».Lemma38
public import «JNT-2024».NormalizerBounds
public import «JNT-2024».NormalizerFormula
public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».PaperBridge
public import «JNT-2024».Proposition41
public import «JNT-2024».Section2
public import «JNT-2024».Section2Complex
public import «JNT-2024».Section2Gaussian
public import «JNT-2024».Section2Geometry
public import «JNT-2024».Section46Calculation
public import «JNT-2024».Section4Comparison
public import «JNT-2024».Section4FourCasesPublished
public import «JNT-2024».Section4Gaussian
public import «JNT-2024».Section4Inputs
public import «JNT-2024».Section4Normalizer
public import «JNT-2024».Section4ParametersPublished
public import «JNT-2024».Section4Prerequisites
public import «JNT-2024».Section4Sequence
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.Deriv.MeanValue
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- The large-d branch of Proposition 4.1, supplying every Section 4.1 input
to the printed four-case proof. Lemma 3.13 uses the accepted certified calculation. -/
theorem proposition41_ordered_large_published (P : Parameters)
    (hPrior : Hypergeometric.DenominatorEstimate4) (h : P.Admissible)
    (hb : P.b=1) (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha))
    (hd112 : 112 ≤ P.d) {i j : ℤ}
    (hsi : IsIntegerSquare (P.y h.pell i)) (hsj : IsIntegerSquare (P.y h.pell j))
    (hcut : P.proposition41Threshold < (P.y h.pell i : ℝ))
    (hij : (P.y h.pell i : ℝ) < (P.y h.pell j : ℝ)) : False := by
  let y : ℝ := P.y h.pell i
  let z : ℝ := P.y h.pell j
  let N : ℝ := |(P.normAlpha:ℝ)|
  let M := Real.sqrt (P.normalizerSquare:ℝ)
  have hy1 : 1 < P.y h.pell i := by
    exact_mod_cast ((le_max_left _ _).trans_lt hcut : (1:ℝ)<(P.y h.pell i:ℝ))
  have hj1 : 1 < P.y h.pell j := by
    exact_mod_cast ((le_max_left _ _).trans_lt hcut |>.trans hij : (1:ℝ)<(P.y h.pell j:ℝ))
  have hy : 0 < y := by dsimp [y]; exact_mod_cast (by linarith : 0<P.y h.pell i)
  have hz : 0 < z := hy.trans hij
  have hN : 0 < N := (P.section4_norm_range h hb hn).1
  have hNd : N < (P.d:ℝ) := (P.section4_norm_range h hb hn).2
  have hd : (0:ℝ)<P.d := by exact_mod_cast h.d_pos
  have hc : Int.gcd P.a P.b=1 := by simp [hb]
  have hM2 : M^2=(P.normalizerSquare:ℝ) := Real.sq_sqrt (by positivity)
  have hMlower : (2:ℝ) ≤ M := by
    have hh : (4:ℝ) ≤ P.normalizerSquare := by exact_mod_cast (P.normalizerSquare_bounds h hc (ne_of_lt hn)).2.1
    have hp : 0 ≤ M := Real.sqrt_nonneg _
    nlinarith only [hh,hM2,hp]
  have hM : 0 < M := by linarith
  have hcut' : 137*N*Real.sqrt N/(Real.sqrt (P.d:ℝ)*M^2) < y := by
    rw [hM2]
    exact (le_max_right _ _).trans_lt hcut
  have hMN : N^2*M^4/(P.d:ℝ)^4 ≤ (2:ℝ)^20/17^4 := by
    have hh := P.section4_normalizer_bound h hb hn
    have hM4 : M^4=(P.normalizerSquare:ℝ)^2 := by rw [show (4:ℕ)=2*2 from rfl,pow_mul,hM2]
    rw [hM4]
    apply (div_le_div_iff₀ (pow_pos hd 4) (by norm_num : (0:ℝ)<17^4)).mpr
    convert hh using 1
    ring
  obtain ⟨X,ν,hx,hν,p₀,q₀,hp₀,hq₀,hqne,hnorm,herr⟩ :=
    P.section4_comparison h hb hn hNs hsi hsj hy1 hj1
  let Z := ν*squareFactor P.normAlpha
  obtain ⟨_,Y,_,hyY,_⟩ := P.section4_integer_coordinates h.pell hsi
  have hcoords := P.section4_gaussian_coordinates h hb hn hNs hx hν hsi hy1
  have hZ : Z ≠ 0 := hcoords.2.1
  have hnear := (Section4.gaussian_input_bounds hZ hcoords.2.2.1).1
  obtain ⟨data⟩ := Section4.gaussian_approximants hPrior hZ hcoords.2.2.1
  have hS := squarefreePart_eq_neg_one (ne_of_lt hn) hNs
  have hMe : Approximation.normalizerProduct (-1) (2*X) (2*Z)=M := by
    simpa only [hS,mul_assoc] using (P.lemma312 h hc hn hx hyY hν).1
  have hpars := P.section4_parameter_bounds_published h hb hn hNs hsi hx hyY hν hd112 hy1
  have hYe : (Y:ℝ)=y := by dsimp [y]; exact_mod_cast hyY.symm
  change 113/100 < Section2.E (-1) (2*X) (2*Z) ∧
    190 < Section2.Q (-1) (2*X) (2*Z) ∧
    (1832/10000 : ℝ)*Approximation.normalizerProduct (-1) (2*X) (2*Z)*
      (Real.sqrt P.d*(Y:ℝ))/N < Section2.E (-1) (2*X) (2*Z) ∧
    Section2.Q (-1) (2*X) (2*Z) < (2147/100 : ℝ)*(Real.sqrt P.d*(Y:ℝ))/
      Approximation.normalizerProduct (-1) (2*X) (2*Z) at hpars
  rw [hMe,hYe] at hpars
  have hphys : 0 < Real.sqrt (P.d:ℝ)*y := mul_pos (Real.sqrt_pos.mpr hd) hy
  have hzabs : |(Z:ℝ)|=Real.sqrt N := by
    dsimp [N]
    rw [← hcoords.1,Real.sqrt_sq_eq_abs]
  have hxlow : (9682/10000 : ℝ)*(Real.sqrt P.d*y) < |(X:ℝ)| := by
    apply Section4.coordinate_ratio_lower hphys
    have hh := (P.section4_coordinate_bounds h hb hn hsi hy1).1
    rw [hx] at hh
    rw [mul_pow,Real.sq_sqrt hd.le]
    push_cast at hh
    nlinarith only [hh]
  have hell : Section2.ell (-1) (2*X) (2*Z) < (615/1000 : ℝ)*Real.sqrt N/|(X:ℝ)| := by
    simpa only [hzabs] using (Section4.gaussian_input_bounds hZ hcoords.2.2.1).2
  have hchord : ‖Section2.omega (-1) (2*X) (2*Z)-1‖/2=Real.sqrt N/(Real.sqrt P.d*y) := by
    have hh := Section4.gaussian_chord hphys hcoords.2.2.2
    change ‖Section2.omega (-1) (2*X) (2*Z)-1‖=2*|(Z:ℝ)|/(Real.sqrt P.d*y) at hh
    rw [hh,hzabs]
    ring
  have hi := P.section4_gap_hypotheses h hb hn hsi hy1
  have hj := P.section4_gap_hypotheses h hb hn hsj hj1
  have hyN := P.section4_value_lower_published h hb hn hi.1
  have hgap : (5732/100 : ℝ)*(P.d:ℝ)^2*y^3 < N^2*z := by
    have hsi' : IsSquare (P.y h.pell i) := by obtain ⟨v,hv⟩ := hsi; exact ⟨(v:ℚ),by simpa [pow_two] using hv⟩
    have hsj' : IsSquare (P.y h.pell j) := by obtain ⟨v,hv⟩ := hsj; exact ⟨(v:ℚ),by simpa [pow_two] using hv⟩
    have hh := P.lemma38a h hn hNs hi.1 hj.1 hsi' hsj' hij hi.2
    rw [hb] at hh
    norm_num only [Int.cast_one,one_pow,one_mul] at hh
    have hm := mul_lt_mul_of_pos_left hh (sq_pos_of_pos hN)
    have hNne : |(P.normAlpha:ℝ)| ≠ 0 := ne_of_gt hN
    convert hm using 1
    dsimp [N,y,z]
    field_simp [hNne]
    norm_num
  apply Section4.four_cases_published data (mul_ne_zero (by decide) hZ) hnear
    hp₀ hq₀ hqne hN hNd (by exact_mod_cast hd112) hy hz hMlower hyN hcut'.le hMN
    (by linarith [hpars.1]) hpars.2.1
    (by simpa only [mul_assoc] using hpars.2.2.1)
    (by simpa only [mul_assoc] using hpars.2.2.2) hxlow hell hchord hnorm hgap herr

end «JNT-2024».Parameters

namespace «JNT-2024»

/-- Proposition 4.1 by the printed large/small-d split. The external theorem
and global Magma calculation are explicit inputs, alongside DenominatorEstimate4.
The proof uses the manuscript's small-d calculation input. -/
theorem proposition41_published (hPrior : Hypergeometric.DenominatorEstimate4)
    (hAkhtari : ExternalResults.AkhtariTheorem11) (hCalculation : Calculations.Section46Magma) :
    Proposition41 := by
  intro P h hb hn hNs i j hsi hsj hci hcj
  by_cases hd : 112 ≤ P.d
  · rcases lt_trichotomy (P.y h.pell i) (P.y h.pell j) with hij | hij | hij
    · exact (P.proposition41_ordered_large_published hPrior h hb hn hNs hd hsi hsj hci
        (by exact_mod_cast hij)).elim
    · exact hij
    · exact (P.proposition41_ordered_large_published hPrior h hb hn hNs hd hsj hsi hcj
        (by exact_mod_cast hij)).elim
  · apply P.section46_small_published hAkhtari hCalculation h hb hn hNs (by omega) hsi hsj
    · exact_mod_cast ((le_max_left _ _).trans_lt hci : (1:ℝ)<(P.y h.pell i:ℝ))
    · exact_mod_cast ((le_max_left _ _).trans_lt hcj : (1:ℝ)<(P.y h.pell j:ℝ))

/-- The hypotheses literally stated in Proposition 4.1: with b=1 and
nonsquare d, square -N_alpha already forces strict negative norm. -/
theorem proposition41_published_statement (hPrior : Hypergeometric.DenominatorEstimate4)
    (hAkhtari : ExternalResults.AkhtariTheorem11) (hCalculation : Calculations.Section46Magma)
    (P : Parameters) (h : P.Admissible) (hb : P.b=1) (hNs : IsSquare (-P.normAlpha))
    {i j : ℤ} (hsi : IsIntegerSquare (P.y h.pell i)) (hsj : IsIntegerSquare (P.y h.pell j))
    (hci : P.proposition41Threshold < (P.y h.pell i:ℝ))
    (hcj : P.proposition41Threshold < (P.y h.pell j:ℝ)) : P.y h.pell i=P.y h.pell j := by
  have hn : P.normAlpha < 0 := by
    obtain ⟨v,hv⟩ := hNs
    have hnle : P.normAlpha ≤ 0 := by nlinarith [sq_nonneg v]
    by_contra hnot
    have hz : P.normAlpha=0 := by omega
    apply h.d_not_square
    simp only [Parameters.normAlpha,hb,one_pow,one_mul] at hz
    exact ⟨P.a,by nlinarith only [hz]⟩
  exact proposition41_published hPrior hAkhtari hCalculation P h hb hn hNs i j hsi hsj hci hcj

/-- The same statement for any sequence given by the paper's equation (1.1),
with its full ring-of-integers unit hypothesis. The previously proved bridge
supplies the coordinate model; it imposes no restriction to a special unit. -/
theorem proposition41_paper (hPrior : Hypergeometric.DenominatorEstimate4)
    (hAkhtari : ExternalResults.AkhtariTheorem11) (hCalculation : Calculations.Section46Magma)
    (P : Parameters) (h : P.PaperAdmissible) (X Y : ℤ → ℚ) (hseq : P.PaperSequence X Y)
    (hb : P.b=1) (hNs : IsSquare (-P.normAlpha)) {i j : ℤ}
    (hsi : IsIntegerSquare (Y i)) (hsj : IsIntegerSquare (Y j))
    (hci : P.proposition41Threshold < (Y i:ℝ))
    (hcj : P.proposition41Threshold < (Y j:ℝ)) : Y i=Y j := by
  obtain ⟨rfl,rfl⟩ := (P.paper_sequence_iff h X Y).mp hseq
  exact proposition41_published_statement hPrior hAkhtari hCalculation P h.toAdmissible hb hNs hsi hsj hci hcj

end «JNT-2024»
