module

public import «JNT-2024».FiniteBounds
public import «JNT-2024».NormalizerBounds
public import «JNT-2024».NormalizerFormula
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».Sequence
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace FiniteBounds

/-- Coverage of the finite certificate by an arbitrary integral unit square. -/
theorem small_unit_solution {a d n y : ℕ} {T U ν : ℤ}
    (ha : 0 < a) (hd : 112 ≤ d) (hn : 0 < n) (hdn : d = a ^ 2 + n)
    (hy : 1 < y) (hsmall : y ≤ 72) (hu : U ≠ 0) (hν : ν = 1 ∨ ν = -1)
    (hnorm : T ^ 2 - (d : ℤ) * U ^ 2 = 4 * ν)
    (hcoord : 4 * (y : ℤ) = (T + a * U) ^ 2 + (n : ℤ) * U ^ 2) :
    1832 ^ 2 * commonSquare a d n * d * y ^ 2 > 11300 ^ 2 * n ^ 2 ∧
      2112 ^ 2 * d * y ^ 2 > 19000 ^ 2 * commonSquare a d n := by
  let r : ℤ := T + a * U
  let R : ℕ := r.natAbs
  let V : ℕ := U.natAbs
  have hdni : (d : ℤ) = (a : ℤ) ^ 2 + n := by exact_mod_cast hdn
  have hfactor : (R : ℤ) ^ 2 - n * (V : ℤ) ^ 2 - 4 * ν = 2 * a * U * r := by
    dsimp [R, V, r]
    rw [Int.natAbs_sq, Int.natAbs_sq]
    rw [hdni] at hnorm
    nlinarith only [hnorm]
  have hr0 : r ≠ 0 := by
    intro he
    have hcoord' : 4 * (y : ℤ) = r ^ 2 + (n : ℤ) * U ^ 2 := hcoord
    have hf : r ^ 2 - n * U ^ 2 - 4 * ν = 2 * a * U * r := by
      simpa only [R, V, Int.natAbs_sq] using hfactor
    rw [he] at hcoord' hf
    have hyi : (1 : ℤ) < y := by exact_mod_cast hy
    rcases hν with hν | hν <;> rw [hν] at hf <;> nlinarith
  have hR : 0 < R := Int.natAbs_pos.mpr hr0
  have hV : 0 < V := Int.natAbs_pos.mpr hu
  have hcoordNat : 4 * y = R ^ 2 + n * V ^ 2 := by
    have hh : (4 : ℤ) * y = (R : ℤ) ^ 2 + n * (V : ℤ) ^ 2 := by
      simpa only [R, V, Int.natAbs_sq] using hcoord
    exact_mod_cast hh
  have hbound : n * V ^ 2 ≤ 288 := by nlinarith only [hcoordNat, hsmall]
  have hRlt : R < 17 := by nlinarith only [hcoordNat, hsmall, Nat.zero_le (n * V ^ 2)]
  have hVlt : V < 17 := by
    have hh : V ^ 2 ≤ n * V ^ 2 := by nlinarith
    nlinarith
  have hnum : candidateNumerator R V n ν = (2 * V * R) * a := by
    have hh := congrArg Int.natAbs hfactor
    simpa [candidateNumerator, Int.natAbs_mul, R, V,
      mul_assoc, mul_comm, mul_left_comm] using hh
  have hden : 0 < 2 * V * R := by positivity
  have hae : candidateA R V n ν = a := by
    rw [candidateA, hnum, Nat.mul_div_cancel_left _ hden]
  have hye : (R ^ 2 + n * V ^ 2) / 4 = y := by
    rw [← hcoordNat, Nat.mul_div_cancel_left _ (by decide : 0 < 4)]
  have hh := bounded_check hRlt hVlt hV hbound hν
  dsimp only [Check] at hh
  rw [hae, ← hdn, hye] at hh
  apply hh hR hV hn
  · rw [hnum]
    exact dvd_mul_right _ _
  · rw [← hcoordNat]
    exact dvd_mul_right _ _
  · exact ha
  · exact hd
  · exact hy

end FiniteBounds
namespace Parameters

theorem normalizerSquare_eq_commonSquare (P : Parameters) (hb : P.b = 1)
    {a d n : ℕ} (ha : P.a = (a : ℤ)) (hd : P.d = (d : ℤ)) (hn : P.normAlpha = -(n : ℤ)) :
    P.normalizerSquare = FiniteBounds.commonSquare a d n := by
  have hc : Int.gcd P.a P.b = 1 := by simp [hb]
  have hG : P.baseGcd = Nat.gcd (a ^ 2) d := by
    simp only [baseGcd, ha, hd, hb, one_pow, mul_one, ← Nat.cast_pow, Int.gcd_natCast_natCast]
  rw [normalizerSquare, normQuotient, Int.natAbs_ediv_of_dvd (P.baseGcd_dvd_norm hc), hn, hG]
  simp only [Int.natAbs_neg, Int.natAbs_natCast, FiniteBounds.commonSquare]

end Parameters
end «JNT-2024»
