module

public import «JNT-2024».RepresentationValuations
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- The common-factor extraction underlying the printed equation (3.11). -/
theorem normalizationGcd_sq_factorization (b r : ℤ) :
    (normalizationGcd b r : ℤ) ^ 2 =
      squareFactor r ^ 2 * (Int.gcd (4 * b ^ 2) (r * squarefreePart r) : ℤ) := by
  have h₁ : 4 * b ^ 2 * r / squarefreePart r = squareFactor r ^ 2 * (4 * b ^ 2) := by
    have he : 4 * b ^ 2 * r = (squareFactor r ^ 2 * (4 * b ^ 2)) * squarefreePart r := by
      calc
        _ = 4 * b ^ 2 * (squareFactor r ^ 2 * squarefreePart r) :=
          congrArg (fun x : ℤ => 4 * b ^ 2 * x) (squareFactor_sq_mul r).symm
        _ = _ := by ring
    rw [he, Int.mul_ediv_cancel _ (squarefreePart_ne_zero r)]
  have h₂ : r ^ 2 = squareFactor r ^ 2 * (r * squarefreePart r) := by
    have h := congrArg (fun x : ℤ => x * r) (squareFactor_sq_mul r)
    nlinarith only [h]
  rw [← Nat.cast_pow, normalizationGcd_sq, h₁, h₂, Int.gcd_mul_left, Nat.cast_mul,
    Int.natCast_natAbs, abs_of_nonneg (sq_nonneg _)]

/-- Equation (3.11), with the signed squarefree part used in the attachment. -/
theorem paper_eq311 (b r : ℤ) :
    (Int.gcd (4 * b ^ 2 * r / squarefreePart r) (r ^ 2) : ℤ) =
      r * Int.gcd (4 * b ^ 2) (r * squarefreePart r) / squarefreePart r := by
  rw [← normalizationGcd_sq, Nat.cast_pow, normalizationGcd_sq_factorization]
  have he : r * (Int.gcd (4 * b ^ 2) (r * squarefreePart r) : ℤ) =
      (squareFactor r ^ 2 * (Int.gcd (4 * b ^ 2) (r * squarefreePart r) : ℤ)) * squarefreePart r := by
    have h := congrArg (fun x : ℤ => x * (Int.gcd (4 * b ^ 2) (r * squarefreePart r) : ℤ))
      (squareFactor_sq_mul r)
    nlinarith only [h]
  rw [he, Int.mul_ediv_cancel _ (squarefreePart_ne_zero r)]

/-- Equation (3.8), for either nonzero candidate r₁. -/
theorem paper_eq38 (b : ℤ) {r : ℤ} (hr : r ≠ 0) :
    normalizationQuotient b r =
      (squarefreePart r : ℚ) / Int.gcd (4 * b ^ 2) (r * squarefreePart r) := by
  have ht : (squareFactor r : ℚ) ≠ 0 := by
    exact_mod_cast (ne_of_gt (squareFactor_pos hr))
  have hf : (normalizationGcd b r : ℚ) ^ 2 =
      (squareFactor r : ℚ) ^ 2 * (Int.gcd (4 * b ^ 2) (r * squarefreePart r) : ℚ) := by
    exact_mod_cast normalizationGcd_sq_factorization b r
  have hs : (r : ℚ) = (squareFactor r : ℚ) ^ 2 * (squarefreePart r : ℚ) := by
    exact_mod_cast (squareFactor_sq_mul r).symm
  rw [normalizationQuotient, hf, hs]
  exact mul_div_mul_left _ _ (pow_ne_zero 2 ht)

end «JNT-2024»
