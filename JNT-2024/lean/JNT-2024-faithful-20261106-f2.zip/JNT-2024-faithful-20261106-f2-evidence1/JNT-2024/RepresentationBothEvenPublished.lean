module

public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».RepresentationBounds
public import «JNT-2024».RepresentationFactors
public import «JNT-2024».RepresentationGaussian
public import «JNT-2024».RepresentationGaussianPublished
public import «JNT-2024».RepresentationLemma33Published
public import «JNT-2024».RepresentationLemma34Published
public import «JNT-2024».RepresentationMixedParityPublished
public import «JNT-2024».RepresentationNormalization
public import «JNT-2024».RepresentationNormalizationPublished
public import «JNT-2024».RepresentationSupport
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- The opening valuation calculation in case (b-iv), including both
lower bounds and the two displayed square-coordinate differences. -/
theorem gaussian_case_iv_valuations {B k l g R S F : ℕ}
    (hg : g = min (1 + B + k / 2) k) (hr : k = g + R)
    (hs : k + l = 2 * g + 2 * S) (hf : F + 2 * g = 2 + 2 * B + k)
    (hR : 0 < R) (hS : 0 < S) :
    F = k % 2 ∧ (F = 1 →
      2 * g = 2 * B + k + 1 ∧
      2 * S + (2 * B + 1) = l ∧ 2 * R + (2 * B + 1) = k ∧
      2 * B + 3 ≤ k ∧ 2 * B + 3 ≤ l ∧ 6 ≤ k + l) := by
  constructor
  · omega
  · intro hF
    omega

/-- The odd-square congruence used in the modulo-eight cases. -/
theorem odd_square_mod_eight {z : ℤ} (hz : Odd z) : z ^ 2 % 8 = 1 := by
  have hh := Int.emod_eq_zero_of_dvd (Int.eight_dvd_sq_sub_one_of_odd hz)
  omega

namespace Parameters

/-- Equation (3.4) in exactly the form used at the start of case (b-iv). -/
theorem gaussian_case_iv_root_identity (P : Parameters) {x y ν : ℤ}
    (h : P.RepresentsSquare x y) (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν) :
    4 * y ^ 2 = 2 * P.a * P.t * P.u + 2 * P.b ^ 2 * P.d * P.u ^ 2 + 4 * P.b ^ 2 * ν := by
  have hh := P.representation_y h
  have hn := congrArg (fun z : ℤ => P.b ^ 2 * z) hν
  nlinarith only [hh, hn]

/-- The two terms atu and b²du² have the same parity. -/
theorem gaussian_case_iv_term_parity (P : Parameters) {x y ν : ℤ}
    (h : P.RepresentsSquare x y) (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν) :
    Even (P.a * P.t * P.u + P.b ^ 2 * P.d * P.u ^ 2) := by
  refine ⟨y ^ 2 - P.b ^ 2 * ν, ?_⟩
  have hh := P.gaussian_case_iv_root_identity h hν
  nlinarith only [hh]

/-- In (b-iv-1), the discriminant forces d=1 mod4; the two possible
modulo-eight classes give the printed norm residues. -/
theorem gaussian_case_iv_odd_data (P : Parameters) {x y ν : ℤ}
    (h : P.RepresentsSquare x y) (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν)
    (hodd : Odd (P.b ^ 2 * P.d * P.u ^ 2)) :
    Odd P.a ∧ Odd P.t ∧ Odd P.b ∧ Odd P.u ∧ P.d % 4 = 1 ∧
    (P.d % 8 = 1 ∨ P.d % 8 = 5) ∧
    P.normAlpha % 8 = (1 - P.d) % 8 := by
  have hterm := P.gaussian_case_iv_term_parity h hν
  have hatu : Odd (P.a * P.t * P.u) := by
    convert hterm.sub_odd hodd using 1; ring
  obtain ⟨hat, hu⟩ := Int.odd_mul.mp hatu
  obtain ⟨ha, ht⟩ := Int.odd_mul.mp hat
  have hb2 := (Int.odd_mul.mp (Int.odd_mul.mp hodd).1).1
  have hb : Odd P.b := by
    rw [pow_two] at hb2
    exact (Int.odd_mul.mp hb2).1
  have hd := P.lemma34_discriminant_congruence (show 4 ∣ P.t ^ 2 - P.d * P.u ^ 2 from ⟨ν, hν⟩) hu
  rw [lemma34_odd_square_mod_four ht] at hd
  refine ⟨ha, ht, hb, hu, hd, by omega, ?_⟩
  have ha8 := odd_square_mod_eight ha
  have hb8 := odd_square_mod_eight hb
  unfold normAlpha
  rw [show P.b ^ 4 = (P.b ^ 2) ^ 2 by ring, Int.sub_emod, Int.mul_emod,
    show ((P.b ^ 2) ^ 2) % 8 = 1 by rw [pow_two, Int.mul_emod, hb8]; norm_num, ha8]
  simp

/-- The d=1 mod8 branch makes the integer norm of epsilon even. -/
theorem gaussian_case_iv_norm_even_mod_eight (P : Parameters) {ν : ℤ}
    (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν) (ht : Odd P.t) (hu : Odd P.u)
    (hd : P.d % 8 = 1) : Even ν := by
  have hh := congrArg (fun z : ℤ => z % 8) hν
  rw [Int.sub_emod, Int.mul_emod, odd_square_mod_eight ht, odd_square_mod_eight hu, hd] at hh
  have hz : (4 * ν) % 8 = 0 := by norm_num at hh ⊢; omega
  exact even_iff_two_dvd.mpr (by omega)

/-- The d=5 mod8 branch contradicts 64 dividing u²N_alpha. -/
theorem gaussian_case_iv_mod_five_impossible (P : Parameters) {ν x y : ℤ}
    (h : P.RepresentsSquare x y) (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν)
    (hodd : Odd (P.b ^ 2 * P.d * P.u ^ 2)) (hd : P.d % 8 = 5)
    (h64 : (64 : ℤ) ∣ P.u ^ 2 * P.normAlpha) : False := by
  obtain ⟨_, _, _, hu, _, _, hN⟩ := P.gaussian_case_iv_odd_data h hν hodd
  have h8 : (8 : ℤ) ∣ P.u ^ 2 * P.normAlpha := dvd_trans (by norm_num) h64
  have hh := Int.emod_eq_zero_of_dvd h8
  rw [Int.mul_emod, odd_square_mod_eight hu, hN, Int.sub_emod, hd] at hh
  norm_num at hh

/-- In (b-iv-2), an odd norm forces y odd, treating u odd and u even
as in the manuscript. The two terms before 4b²N_epsilon are divisible by 8. -/
theorem gaussian_case_iv_odd_norm_forces_odd_y (P : Parameters) {x y ν : ℤ}
    (h : P.RepresentsSquare x y) (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν)
    (hb : Odd P.b) (hdu : Even (P.d * P.u ^ 2)) (huN : Even (P.u * P.normAlpha))
    (hνO : Odd ν) :
    Even P.t ∧ (4 : ℤ) ∣ P.d * P.u ^ 2 ∧
      (8 : ℤ) ∣ 2 * P.a * P.t * P.u ∧ (8 : ℤ) ∣ 2 * P.b ^ 2 * P.d * P.u ^ 2 ∧ Odd y := by
  have ht2 : Even (P.t ^ 2) := by
    have he : P.t ^ 2 = 4 * ν + P.d * P.u ^ 2 := by linarith
    rw [he]
    exact (show Even (4 * ν) from ⟨2 * ν, by ring⟩).add hdu
  have ht : Even P.t := by
    rw [pow_two] at ht2
    exact (Int.even_mul.mp ht2).elim id id
  have hdu4 : (4 : ℤ) ∣ P.d * P.u ^ 2 := by
    have hh := congrArg (fun z : ℤ => z % 4) hν
    rw [Int.sub_emod, lemma34_even_square_mod_four ht] at hh
    exact Int.dvd_of_emod_eq_zero (by omega)
  have hatu4 : (4 : ℤ) ∣ P.a * P.t * P.u := by
    by_cases hu : Even P.u
    · have hh := mul_dvd_mul (even_iff_two_dvd.mp ht) (even_iff_two_dvd.mp hu)
      have hh' : (4 : ℤ) ∣ P.t * P.u := by simpa using hh
      simpa only [mul_assoc] using dvd_mul_of_dvd_right hh' P.a
    · have huO := Int.not_even_iff_odd.mp hu
      have hN : Even P.normAlpha := (Int.even_mul.mp huN).resolve_left hu
      have hd4 : (4 : ℤ) ∣ P.d := by
        have hh := Int.emod_eq_zero_of_dvd hdu4
        rw [Int.mul_emod, lemma34_odd_square_mod_four huO, mul_one] at hh
        exact Int.dvd_of_emod_eq_zero (by simpa using hh)
      have hdE : Even (P.d * P.b ^ 4) := even_iff_two_dvd.mpr
        (dvd_mul_of_dvd_left (dvd_trans (by norm_num : (2 : ℤ) ∣ 4) hd4) _)
      have ha2 : Even (P.a ^ 2) := by
        convert hN.add hdE using 1
        unfold normAlpha
        ring
      rw [pow_two] at ha2
      have ha := (Int.even_mul.mp ha2).elim id id
      have hh : (4 : ℤ) ∣ P.a * P.t := by
        simpa using mul_dvd_mul (even_iff_two_dvd.mp ha) (even_iff_two_dvd.mp ht)
      exact dvd_mul_of_dvd_left hh _
  obtain ⟨A, hA⟩ := hatu4
  obtain ⟨D, hD⟩ := hdu4
  have hroot := P.gaussian_case_iv_root_identity h hν
  have hh : y ^ 2 = P.b ^ 2 * ν + 2 * (A + P.b ^ 2 * D) := by
    have hm := congrArg (fun z : ℤ => P.b ^ 2 * z) hD
    nlinarith only [hroot, hA, hm]
  have hy2 : Odd (y ^ 2) := by
    rw [hh]
    exact (hb.pow.mul hνO).add_even ⟨A + P.b ^ 2 * D, by ring⟩
  have hyO : Odd y := by
    rw [pow_two] at hy2
    exact (Int.odd_mul.mp hy2).1
  refine ⟨ht, ⟨D, hD⟩, ⟨A, ?_⟩, ⟨P.b ^ 2 * D, ?_⟩, hyO⟩
  · nlinarith only [hA]
  · have hm := congrArg (fun z : ℤ => P.b ^ 2 * z) hD
    nlinarith only [hm]

end Parameters

/-- At the prime two, equal valuations make the nonzero difference have
strictly larger valuation: the equal case in the last paragraph of (b-iv). -/
theorem valuation_two_sub_of_eq {a b : ℤ} (ha : a ≠ 0) (hb : b ≠ 0)
    (hab : a - b ≠ 0) (he : padicValInt 2 a = padicValInt 2 b) :
    padicValInt 2 a + 1 ≤ padicValInt 2 (a - b) := by
  let k := padicValInt 2 a
  obtain ⟨A, hA⟩ := padicValInt_dvd (p := 2) a
  change a = (2 : ℤ) ^ k * A at hA
  have hdb : (2 : ℤ) ^ k ∣ b := by
    dsimp [k]
    rw [he]
    exact padicValInt_dvd b
  obtain ⟨B, hB⟩ := hdb
  have hA0 : A ≠ 0 := by intro hz; rw [hz, mul_zero] at hA; exact ha hA
  have hB0 : B ≠ 0 := by intro hz; rw [hz, mul_zero] at hB; exact hb hB
  have hvpow : padicValInt 2 ((2 : ℤ) ^ k) = k := by
    rw [valuation_int_pow]
    norm_num [padicValInt]
  have hvA := congrArg (padicValInt 2) hA
  have hvB := congrArg (padicValInt 2) hB
  change padicValInt 2 a = padicValInt 2 ((2 : ℤ) ^ k * A) at hvA
  rw [padicValInt.mul (pow_ne_zero _ (by norm_num)) hA0, hvpow] at hvA
  rw [padicValInt.mul (pow_ne_zero _ (by norm_num)) hB0, hvpow, ← he] at hvB
  have hAO := odd_of_valuation_two_zero hA0 (by dsimp [k] at hvA; omega)
  have hBO := odd_of_valuation_two_zero hB0 (by dsimp [k] at hvB; omega)
  obtain ⟨c, hc⟩ := even_iff_two_dvd.mp (hAO.sub_odd hBO)
  have hd : (2 : ℤ) ^ (k + 1) ∣ a - b := by
    refine ⟨c, ?_⟩
    rw [hA, hB, pow_succ]
    have hh := congrArg (fun z : ℤ => (2 : ℤ) ^ k * z) hc
    nlinarith only [hh]
  exact ((padicValInt_dvd_iff (p := 2) _ _).mp hd).resolve_left hab

/-- The last three candidate-valuation comparisons in (b-iv-2).
All three yield even y, with the printed strict inequality in the equal case. -/
theorem gaussian_case_iv_difference {a a' b y σ : ℤ}
    (ha : a ≠ 0) (ha' : a' ≠ 0) (hb : b ≠ 0) (hy : y ≠ 0) (hσ : σ = 1 ∨ σ = -1)
    (hd : a - a' = σ * 4 * b * y)
    (hlo : 2 * padicValInt 2 b + 3 ≤ padicValInt 2 a)
    (hlo' : 2 * padicValInt 2 b + 3 ≤ padicValInt 2 a') :
    (padicValInt 2 a = padicValInt 2 a' → padicValInt 2 a < 2 + padicValInt 2 b + padicValInt 2 y) ∧
    (padicValInt 2 a < padicValInt 2 a' → 2 + padicValInt 2 b + padicValInt 2 y = padicValInt 2 a) ∧
    (padicValInt 2 a' < padicValInt 2 a → 2 + padicValInt 2 b + padicValInt 2 y = padicValInt 2 a') ∧ Even y := by
  have hz : a - a' ≠ 0 := by
    rw [hd]
    have hs : σ ≠ 0 := by rcases hσ with rfl | rfl <;> norm_num
    exact mul_ne_zero (mul_ne_zero (mul_ne_zero hs (by norm_num)) hb) hy
  have h4 : padicValInt 2 (4 : ℤ) = 2 := by
    have hh := valuation_int_pow 2 (2 : ℤ) 2
    have h2 : padicValInt 2 (2 : ℤ) = 1 := by norm_num [padicValInt]
    simpa only [show (2 : ℤ) ^ 2 = 4 by norm_num, h2, mul_one] using hh
  have hv : padicValInt 2 (a - a') = 2 + padicValInt 2 b + padicValInt 2 y := by
    rw [hd]
    rcases hσ with rfl | rfl <;> simp only [one_mul, neg_mul, valuation_neg] <;>
      rw [padicValInt.mul (mul_ne_zero (by norm_num) hb) hy, padicValInt.mul (by norm_num) hb] <;>
      rw [h4]
  have hneq (hn : padicValInt 2 a ≠ padicValInt 2 a') :
      2 + padicValInt 2 b + padicValInt 2 y = min (padicValInt 2 a) (padicValInt 2 a') := by
    have hh := valuation_two_add_of_ne ha (neg_ne_zero.mpr ha')
      (by simpa only [sub_eq_add_neg] using hz) (by simpa only [valuation_neg] using hn)
    simpa only [← sub_eq_add_neg, hv, valuation_neg] using hh
  have heq (he : padicValInt 2 a = padicValInt 2 a') :
      padicValInt 2 a < 2 + padicValInt 2 b + padicValInt 2 y := by
    have hh := valuation_two_sub_of_eq ha ha' hz he
    rw [hv] at hh
    omega
  refine ⟨heq, ?_, ?_, ?_⟩
  · intro hh
    simpa only [min_eq_left (le_of_lt hh)] using hneq (ne_of_lt hh)
  · intro hh
    simpa only [min_eq_right (le_of_lt hh)] using hneq (ne_of_gt hh)
  · have hY : 0 < padicValInt 2 y := by
      rcases lt_trichotomy (padicValInt 2 a) (padicValInt 2 a') with hh | hh | hh
      · have hm := hneq (ne_of_lt hh); omega
      · have hm := heq hh; omega
      · have hm := hneq (ne_of_gt hh); omega
    exact even_iff_two_dvd.mpr ((prime_dvd_iff_valuation_pos 2 hy).mpr hY)

namespace Parameters

/-- The printed two branches of (b-iv) force the norm of epsilon even
when b is odd. The contradiction uses the proved odd/even statements for y. -/
theorem gaussian_case_iv_norm_even (P : Parameters) {x y ν : ℤ}
    (h : P.RepresentsSquare x y) (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν)
    (hb : Odd P.b) (hy : Even y) (h64 : (64 : ℤ) ∣ P.u ^ 2 * P.normAlpha) : Even ν := by
  have huN : Even (P.u * P.normAlpha) := by
    have hd : (2 : ℤ) ∣ P.u ^ 2 * P.normAlpha := dvd_trans (by norm_num) h64
    have hp : Prime (2 : ℤ) := Nat.prime_iff_prime_int.mp Nat.prime_two
    apply even_iff_two_dvd.mpr
    rcases hp.dvd_mul.mp hd with hh | hh
    · exact dvd_mul_of_dvd_left (hp.dvd_of_dvd_pow hh) _
    · exact dvd_mul_of_dvd_right hh _
  by_cases hterm : Odd (P.b ^ 2 * P.d * P.u ^ 2)
  · obtain ⟨_, ht, _, hu, _, hd, _⟩ := P.gaussian_case_iv_odd_data h hν hterm
    rcases hd with hd | hd
    · exact P.gaussian_case_iv_norm_even_mod_eight hν ht hu hd
    · exact (P.gaussian_case_iv_mod_five_impossible h hν hterm hd h64).elim
  · have hdu : Even (P.d * P.u ^ 2) := by
      have hh : Even (P.b ^ 2 * (P.d * P.u ^ 2)) := by
        simpa only [mul_assoc] using Int.not_odd_iff_even.mp hterm
      exact (Int.even_mul.mp hh).resolve_left (Int.not_even_iff_odd.mpr hb.pow)
    by_contra hn
    have hyO := (P.gaussian_case_iv_odd_norm_forces_odd_y h hν hb hdu huN (Int.not_even_iff_odd.mp hn)).2.2.2.2
    exact (Int.not_even_iff_odd.mpr hyO) hy

/-- Case (b-iv), with the proved valuation and parity arguments supplying
the sharp bound for the actual normalized coefficient, for either sign. -/
theorem proposition31b_both_even_published (P : Parameters) {x y ν σ f r s : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hy : y ≠ 0) (hu : P.u ≠ 0)
    (hN : P.normAlpha ≠ 0) (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν)
    (hσ : σ = 1 ∨ σ = -1) (hS : squarefreePart P.normAlpha = -1) (hf0 : f ≠ 0)
    (he : σ * 4 * P.b ^ 2 * P.repCandidate y σ =
      (normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2 * f)
    (hr : P.repCandidate y σ = (normalizationGcd P.b (P.repCandidate y σ) : ℤ) * r)
    (hs : -P.u * squareFactor P.normAlpha = (normalizationGcd P.b (P.repCandidate y σ) : ℤ) * s)
    (hrep : P.FourthPowerRepresentation x y f r s) (hrE : Even r) (hsE : Even s) :
    P.SignedFourthPowerRepresentation x y f r s 1 ∧ f ∣ P.b ^ 2 * P.normRadical ν := by
  obtain ⟨hr0, hs0, hgv, hrv, hsv, hfv, _, _⟩ :=
    P.gaussian_mixed_parity_identities h hb hy hu hN hν hσ hS hf0 he hr hs
  have hR := (prime_dvd_iff_valuation_pos 2 hr0).mp (even_iff_two_dvd.mp hrE)
  have hSv := (prime_dvd_iff_valuation_pos 2 hs0).mp (even_iff_two_dvd.mp hsE)
  obtain ⟨hF, hhigh⟩ := gaussian_case_iv_valuations hgv hrv hsv hfv hR hSv
  have h1 := P.repCandidate_ne_zero h hu hN hσ
  have hσ' : -σ = 1 ∨ -σ = -1 := by rcases hσ with rfl | rfl <;> norm_num
  have h2 := P.repCandidate_ne_zero h hu hN hσ'
  have hRad : P.normRadical ν ≠ 0 := UniqueFactorizationMonoid.radical_ne_zero
  refine ⟨hrep.signed, normalized_coefficient_dvd_square hb h1 hf0 hRad hσ he ?_ ?_⟩
  · intro p hp
    let : Fact p.Prime := ⟨hp⟩
    have hv := P.lemma33a_published h hb hu hN hν p
    rw [P.representationRadical_negative_square ν hS] at hv
    rcases hσ with rfl | rfl
    · exact (le_max_left _ _).trans hv
    · exact (le_max_right _ _).trans hv
  · rw [padicValInt.mul (pow_ne_zero _ hb) hRad, valuation_int_pow]
    by_cases hf : padicValInt 2 f = 0
    · omega
    have hf1 : padicValInt 2 f = 1 := by omega
    obtain ⟨_, _, _, hk, hl, hsum⟩ := hhigh hf1
    by_cases hbE : Even P.b
    · have hB := (prime_dvd_iff_valuation_pos 2 hb).mp (even_iff_two_dvd.mp hbE)
      omega
    have hprod : P.repCandidate y σ * P.repCandidate y (-σ) = P.u ^ 2 * P.normAlpha := by
      rcases hσ with rfl | rfl <;> simpa only [neg_neg, mul_comm] using P.repCandidate_product h
    have hp := congrArg (padicValInt 2) hprod
    rw [padicValInt.mul h1 h2] at hp
    have h64 : (64 : ℤ) ∣ P.u ^ 2 * P.normAlpha := by
      have hd := (padicValInt_dvd_iff (p := 2) 6 (P.u ^ 2 * P.normAlpha)).mpr (Or.inr (by omega))
      simpa using hd
    have hdiff : P.repCandidate y σ - P.repCandidate y (-σ) = σ * 4 * P.b * y := by
      unfold repCandidate
      ring
    have hyE := (gaussian_case_iv_difference h1 h2 hb hy hσ hdiff hk hl).2.2.2
    have hνE := P.gaussian_case_iv_norm_even h hν (Int.not_even_iff_odd.mp hbE) hyE h64
    have hp2 : Prime (2 : ℤ) := Nat.prime_iff_prime_int.mp Nat.prime_two
    have huN : (2 : ℤ) ∣ P.u * P.normAlpha := by
      have hd : (2 : ℤ) ∣ P.u ^ 2 * P.normAlpha := dvd_trans (by norm_num) h64
      rcases hp2.dvd_mul.mp hd with hh | hh
      · exact dvd_mul_of_dvd_left (hp2.dvd_of_dvd_pow hh) _
      · exact dvd_mul_of_dvd_right hh _
    have hgN : (Int.gcd (P.u * P.normAlpha) ν : ℤ) ≠ 0 := by
      exact_mod_cast ne_of_gt (Int.gcd_pos_of_ne_zero_left ν (mul_ne_zero hu hN))
    have hvRad := valuation_radical_pos_of_dvd 2 hgN
      (Int.dvd_coe_gcd huN (even_iff_two_dvd.mp hνE))
    change 1 ≤ padicValInt 2 (P.normRadical ν) at hvRad
    omega

/-- Proposition 3.1(b) assembled from the manuscript's parity cases.
The first identity is supplied by the restored quotient argument. -/
theorem proposition31b_published (P : Parameters) [Fact (¬ IsSquare P.d)]
    [Fact (¬ IsSquare P.normAlpha)] {x y : ℤ}
    (h : P.RepresentsSquare x y) (ha : P.a ≠ 0) (hb : P.b ≠ 0) (hy : y ≠ 0)
    (hu : P.u ≠ 0) (hN : P.normAlpha ≠ 0) (hi : IsIntegral ℤ P.epsilon)
    (hsquare : IsSquare (-P.normAlpha)) :
    ∃ ν f r s τ : ℤ, (ν : ℚ) = P.epsilonNorm ∧ f ≠ 0 ∧ (τ = 1 ∨ τ = -1) ∧
      P.SignedFourthPowerRepresentation x y f r s τ ∧ f ∣ P.b ^ 2 * P.normRadical ν := by
  have hd : P.d ≠ 0 := by
    intro hz
    exact (Fact.out : ¬ IsSquare P.d) (hz ▸ IsSquare.zero)
  obtain ⟨ν, hn, hν⟩ := P.exists_integer_norm_relation hi
  have hS := squarefreePart_eq_neg_one hN hsquare
  obtain ⟨f, r, s, hf, he, hr, hs, hrep⟩ :=
    P.candidate_representation_from_published_quotient h ha hb hd hy hu hN hi (Or.inl rfl)
  by_cases hfO : Odd f
  · obtain ⟨hrep', hdvd⟩ := P.proposition31b_odd_coefficient_published h hb hu hN hν
      (Or.inl rfl) hS hf hfO he hrep
    exact ⟨ν, f, r, s, 1, hn, hf, Or.inl rfl, hrep', hdvd⟩
  have hfE := Int.not_odd_iff_even.mp hfO
  by_cases hrO : Odd r
  · by_cases hsO : Odd s
    · obtain ⟨hhalf, hrep', hdvd⟩ := P.proposition31b_odd_odd_published h hb hu hN hi hν
        (Or.inl rfl) hS hf he hrep hfE hrO hsO
      exact ⟨ν, f / 2, (r + s) / 2, (s - r) / 2, -1, hn, hhalf, Or.inr rfl, hrep', hdvd⟩
    · obtain ⟨_, hrep', hdvd⟩ := P.proposition31b_mixed_parity_published h hb hy hu hN hν
        (Or.inl rfl) hS hf he hr hs hrep (Or.inl ⟨hrO, Int.not_odd_iff_even.mp hsO⟩)
      exact ⟨ν, f, r, s, 1, hn, hf, Or.inl rfl, hrep', hdvd⟩
  · have hrE := Int.not_odd_iff_even.mp hrO
    by_cases hsO : Odd s
    · obtain ⟨_, hrep', hdvd⟩ := P.proposition31b_mixed_parity_published h hb hy hu hN hν
        (Or.inl rfl) hS hf he hr hs hrep (Or.inr ⟨hrE, hsO⟩)
      exact ⟨ν, f, r, s, 1, hn, hf, Or.inl rfl, hrep', hdvd⟩
    · obtain ⟨hrep', hdvd⟩ := P.proposition31b_both_even_published h hb hy hu hN hν
        (Or.inl rfl) hS hf he hr hs hrep hrE (Int.not_odd_iff_even.mp hsO)
      exact ⟨ν, f, r, s, 1, hn, hf, Or.inl rfl, hrep', hdvd⟩

end Parameters
end «JNT-2024»
