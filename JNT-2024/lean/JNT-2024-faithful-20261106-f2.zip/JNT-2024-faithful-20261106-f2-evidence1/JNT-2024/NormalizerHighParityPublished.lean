module

public import «JNT-2024».NormalizerHighInitialPublished
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».RepresentationFactors
public import «JNT-2024».RepresentationLemma34Published
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».Sequence
public import «JNT-2024».SequenceRepresentations
public import «JNT-2024».UnitParityPublished
public import «JNT-2024».UnitPowers
public import «JNT-2024».UnitSequenceIntegrality
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

theorem unit_even_even_of_d_one_mod_eight (P : Parameters) (hp : P.Pell) (hd : P.d % 8 = 1) :
    Even P.t ∧ Even P.u := by
  rcases Int.even_or_odd P.t with ht | ht <;> rcases Int.even_or_odd P.u with hu | hu
  · exact ⟨ht,hu⟩
  · have hh := P.unit_even_odd_four_dvd hp ht hu; omega
  · exact (P.unit_not_odd_even hp ht hu).elim
  · have hh := P.unit_odd_odd_mod_eight hp ht hu; omega

theorem unit_t_even_of_four_dvd_d (P : Parameters) (hp : P.Pell) (hd : (4 : ℤ) ∣ P.d) : Even P.t := by
  have hnorm : (4 : ℤ) ∣ P.t ^ 2 - P.d * P.u ^ 2 := by
    rcases hp with hh | hh
    · rw [hh]
    · rw [hh]; norm_num
  have ht₂ : (4 : ℤ) ∣ P.t ^ 2 := by
    have hh := dvd_add hnorm (dvd_mul_of_dvd_left hd (P.u ^ 2))
    simpa using hh
  rcases Int.even_or_odd P.t with ht | ht
  · exact ht
  · have hh := lemma34_odd_square_mod_four ht
    have hz := Int.emod_eq_zero_of_dvd ht₂
    omega

/-- The printed expansion of 4y_k after replacing epsilon by its kth power. -/
theorem unit_square_y_formula_published (P : Parameters) {Y : ℤ}
    (hy : (P.alpha * P.epsilon ^ 2).im = Y) :
    4 * Y = P.b ^ 2 * (P.t ^ 2 + P.d * P.u ^ 2) + 2 * P.a * P.t * P.u := by
  have hq : (4 : ℚ) * Y = P.b ^ 2 * ((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) +
      2 * P.a * P.t * P.u := by
    rw [← hy]
    simp [alpha, epsilon, pow_two]
    ring
  exact_mod_cast hq

/-- Both printed parity cases make the two nonconstant summands divisible
by eight, and therefore force the integral y coordinate odd. -/
theorem unit_square_y_odd_printed_cases (P : Parameters) (hp : P.Pell) (hb : Odd P.b)
    (hcase : (Even P.t ∧ Even P.u) ∨ ((4 : ℤ) ∣ P.d ∧ Even P.a ∧ Even P.t))
    {Y : ℤ} (hy : 4 * Y = P.b ^ 2 * (P.t ^ 2 + P.d * P.u ^ 2) + 2 * P.a * P.t * P.u) : Odd Y := by
  obtain ⟨ν,hν,_,hn⟩ := P.unit_norm_integer_sign hp
  have hoν : Odd ν := by rcases hν with rfl | rfl <;> decide
  have h8 : (8 : ℤ) ∣ 2 * P.d * P.u ^ 2 ∧ (8 : ℤ) ∣ 2 * P.a * P.t * P.u := by
    rcases hcase with ⟨⟨T,hT⟩,⟨U,hU⟩⟩ | ⟨⟨D,hD⟩,⟨A,hA⟩,⟨T,hT⟩⟩
    · constructor
      · exact ⟨P.d * U ^ 2, by rw [hU]; ring⟩
      · exact ⟨P.a * T * U, by rw [hT,hU]; ring⟩
    · constructor
      · exact ⟨D * P.u ^ 2, by rw [hD]; ring⟩
      · exact ⟨A * T * P.u, by rw [hA,hT]; ring⟩
  have hrest : (8 : ℤ) ∣ 4 * (Y - P.b ^ 2 * ν) := by
    have hh := dvd_add (dvd_mul_of_dvd_right h8.1 (P.b ^ 2)) h8.2
    convert hh using 1
    have hn' := congrArg (fun z : ℤ => P.b ^ 2 * z) hn
    nlinarith only [hy,hn']
  have ho := Int.odd_iff.mp (hb.pow (n := 2) |>.mul hoν)
  apply Int.odd_iff.mpr
  omega

/-- The literal ell=0 / ell>0 proof that y_k is odd in Lemma 3.12. -/
theorem high_norm_sequence_y_odd_published (P : Parameters) (h : P.Admissible)
    (hc : Int.gcd P.a P.b = 1) (hn : P.normAlpha < 0)
    (hh : padicValNat 2 P.baseGcd + 5 ≤ padicValInt 2 P.normAlpha)
    {k Y : ℤ} (hy : P.y h.pell k = Y) : Odd Y := by
  have hi := P.high_norm_initial_valuations_published h hc hn hh
  by_cases hk : k = 0
  · subst k
    have hY : Y = P.b ^ 2 := by
      have hh := P.y_zero h.pell
      rw [hy] at hh
      exact_mod_cast hh
    rw [hY]
    exact hi.1.pow
  obtain ⟨T,U,_,hp,ht⟩ := P.sequence_unit_parameters h hk
  let Q := P.withUnit T U
  have hY : (Q.alpha * Q.epsilon ^ 2).im = Y := by
    have hh := congrArg QuadraticAlgebra.im ht
    change P.y h.pell k = _ at hh
    rw [hy] at hh
    exact hh.symm
  apply Q.unit_square_y_odd_printed_cases hp hi.1 ?_ (Q.unit_square_y_formula_published hY)
  by_cases he : padicValNat 2 P.baseGcd = 0
  · have hd := P.high_norm_normalized_d_mod_eight h hc hn hh
    simp only [he, pow_zero, Int.ediv_one] at hd
    exact Or.inl (Q.unit_even_even_of_d_one_mod_eight hp hd)
  · have he2 : 2 ≤ padicValNat 2 P.baseGcd := by
      have heE := Nat.even_iff.mp hi.2.2.2.2
      omega
    have hd : (4 : ℤ) ∣ P.d := by
      have hh : (2 : ℤ) ^ 2 ∣ P.d := (padicValInt_dvd_iff _ _).mpr
        (Or.inr (by rw [hi.2.2.2.1]; exact he2))
      simpa using hh
    have ha : Even P.a := by
      have hv := hi.2.1
      rw [valuation_int_pow] at hv
      apply even_iff_two_dvd.mpr
      exact (prime_dvd_iff_valuation_pos 2 (ne_of_gt h.a_pos)).mpr (by omega)
    exact Or.inr ⟨hd,ha,Q.unit_t_even_of_four_dvd_d hp hd⟩

end «JNT-2024».Parameters
