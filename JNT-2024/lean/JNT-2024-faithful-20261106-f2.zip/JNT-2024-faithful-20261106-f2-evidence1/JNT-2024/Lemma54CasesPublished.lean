module

public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section5

set_option maxRecDepth 100000
set_option synthInstance.maxSize 1000

/-- The first paragraph of Lemma 5.4: odd trace forces the impossible residue
2 for four times either adjacent integer value. -/
theorem lemma54_odd_trace_cases : ∀ a d t u : ZMod 4,
    (d-a^2).val % 2 = 1 → t.val % 2 = 1 → t^2-d*u^2=0 →
    d=1 ∧ u^2=1 ∧ a.val % 2=0 ∧
    t^2+d*u^2+2*a*t*u=2 ∧ t^2+d*u^2-2*a*t*u=2 := by decide +kernel

/-- The printed odd/even-a residues and the complete six-residue list for d. -/
theorem lemma54_norm_cases : ∀ a d : ZMod 16, (d-a^2=1 ∨ d-a^2=9) →
    (a.val % 2=1 → (a^2).val % 8=1 ∧ d.val % 8=2) ∧
    (a.val % 2=0 → (a^2=0 ∨ a^2=4) ∧ d.val % 4=1) ∧
    (d=1 ∨ d=2 ∨ d=5 ∨ d=9 ∨ d=10 ∨ d=13) := by decide +kernel

/-- Trace residues used in both parts. -/
theorem lemma54_trace_squares : ∀ t : ZMod 16,
    (t.val % 4=0 → t^2=0) ∧ (t.val % 4=2 → t^2=4) := by decide +kernel

/-- Part (a), 4|t and a odd: the printed impossible square residue 6 mod 8. -/
theorem lemma54_plus_zero_odd : ∀ d u : ZMod 16,
    d.val % 8=2 → d*u^2=12 → (u^2).val % 8=6 := by decide +kernel

/-- Part (a), 4|t and a even: the printed impossible residue 12 mod 16. -/
theorem lemma54_plus_zero_even : ∀ d u : ZMod 16,
    d.val % 4=1 → d*u^2=12 → u^2=12 := by decide +kernel

/-- Part (a), t=2 mod 4: the six d residues imply 8|u^2. -/
theorem lemma54_plus_two : ∀ d u : ZMod 16,
    (d=1 ∨ d=2 ∨ d=5 ∨ d=9 ∨ d=10 ∨ d=13) →
    d*u^2=0 → (u^2).val % 8=0 := by decide +kernel

/-- Part (b), 4|t and a odd. -/
theorem lemma54_minus_zero_odd : ∀ d u : ZMod 16,
    d.val % 8=2 → d*u^2=4 → (u^2).val % 8=2 := by decide +kernel

/-- Part (b), 4|t and a even. -/
theorem lemma54_minus_zero_even : ∀ d u : ZMod 16,
    d.val % 4=1 → d*u^2=4 → u^2=4 := by decide +kernel

/-- Part (b), t=2 mod 4 and a odd. -/
theorem lemma54_minus_two_odd : ∀ d u : ZMod 16,
    d.val % 8=2 → d*u^2=8 → (u^2).val % 8=4 := by decide +kernel

/-- Part (b), t=2 mod 4 and a even. -/
theorem lemma54_minus_two_even : ∀ d u : ZMod 16,
    d.val % 4=1 → d*u^2=8 → u^2=8 := by decide +kernel

/-- Elementary square residues close precisely the contradictions and the
divisibility conclusions appearing in the printed argument. -/
theorem lemma54_square_residues : ∀ u : ZMod 16,
    (u^2).val % 8 ≠ 6 ∧ u^2 ≠ 12 ∧ (u^2).val % 8 ≠ 2 ∧ u^2 ≠ 8 ∧
    ((u^2).val % 8=0 → u.val % 4=0) ∧
    (u^2=4 → u.val % 4=2) ∧ ((u^2).val % 8=4 → u.val % 4=2) := by decide +kernel

/-- Assembly of the printed cases after the odd-trace exclusion. -/
theorem lemma54_cases_assembled (a d t u : ZMod 16)
    (hN : d-a^2=1 ∨ d-a^2=9) (ht : t.val % 2=0) :
    (t^2-d*u^2=4 → t.val % 4=2 ∧ u.val % 4=0) ∧
    (t^2-d*u^2= -4 → u.val % 4=2) := by
  obtain ⟨hodd,heven,hd⟩ := lemma54_norm_cases a d hN
  have ha : a.val % 2=0 ∨ a.val % 2=1 := by omega
  have htr : t.val % 4=0 ∨ t.val % 4=2 := by omega
  obtain ⟨ht0,ht2⟩ := lemma54_trace_squares t
  obtain ⟨hs6,hs12,hs2,hs8,hu0,hu4,hu8⟩ := lemma54_square_residues u
  constructor
  · intro hp
    have htwo : t.val % 4=2 := by
      rcases htr with hzero | htwo
      · have hprod : d*u^2=12 := by
          have hh:=ht0 hzero
          linear_combination (norm := ring_nf) hh-hp
          decide +kernel
        rcases ha with ha | ha
        · exact (hs12 (lemma54_plus_zero_even d u (heven ha).2 hprod)).elim
        · exact (hs6 (lemma54_plus_zero_odd d u (hodd ha).2 hprod)).elim
      · exact htwo
    have hprod : d*u^2=0 := by have hh:=ht2 htwo; linear_combination hh-hp
    exact ⟨htwo,hu0 (lemma54_plus_two d u hd hprod)⟩
  · intro hp
    rcases htr with hzero | htwo
    · have hprod : d*u^2=4 := by have hh:=ht0 hzero; linear_combination hh-hp
      rcases ha with ha | ha
      · exact hu4 (lemma54_minus_zero_even d u (heven ha).2 hprod)
      · exact (hs2 (lemma54_minus_zero_odd d u (hodd ha).2 hprod)).elim
    · have hprod : d*u^2=8 := by have hh:=ht2 htwo; linear_combination hh-hp
      rcases ha with ha | ha
      · exact (hs8 (lemma54_minus_two_even d u (heven ha).2 hprod)).elim
      · exact hu8 (lemma54_minus_two_odd d u (hodd ha).2 hprod)

end «JNT-2024».Section5
