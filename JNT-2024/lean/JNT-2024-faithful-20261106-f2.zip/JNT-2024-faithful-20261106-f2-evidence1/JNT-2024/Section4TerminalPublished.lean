module

public import «JNT-2024».Section4CutoffBounds
public import «JNT-2024».Section4Numerical
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.Deriv.MeanValue
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4

/-- The printed c<0.7505 numerical check at the end of Section 4.2. -/
theorem case42_cutoff_fraction {d c : ℝ} (hd : 112 ≤ d) (hc : c < 1501/2000) :
    (66/100 : ℝ)/((1-c)*Real.sqrt d) < 1/4 := by
  have hd0 : 0 < d := by linarith
  have hs := Real.sq_sqrt hd0.le
  have hsp := Real.sqrt_pos.mpr hd0
  have hcp : 0 < 1-c := by linarith
  have hsl : (5280/499 : ℝ) < Real.sqrt d := by nlinarith
  have hprod := mul_lt_mul_of_pos_right (show (499/2000 : ℝ)<1-c by linarith) hsp
  apply (div_lt_iff₀ (mul_pos hcp hsp)).mpr
  nlinarith only [hprod,hsl]

/-- The displayed 0.66 chain in Section 4.2, at the selected c=3/4. -/
theorem case42_printed_chain {N d y z : ℝ} (hN : 0 < N) (hNd : N < d)
    (hd : 112 ≤ d) (hy : 0 < y)
    (hgap : (5732/100 : ℝ)*d^2*y^3 < N^2*z)
    (hu : z^3 < (35700*256 : ℝ)*N^2*y^5) :
    y < (66/100 : ℝ)*N^2/((1-3/4)*d*Real.sqrt d) ∧
    (66/100 : ℝ)*N^2/((1-3/4)*d*Real.sqrt d) <
      (66/100 : ℝ)*N/((1-3/4)*Real.sqrt d) ∧
    (66/100 : ℝ)*N/((1-3/4)*Real.sqrt d) < N/4 := by
  have hd0 := hN.trans hNd
  have hs := Real.sqrt_pos.mpr hd0
  refine ⟨?_,?_,?_⟩
  · have hh : y < (66/25 : ℝ)*N^2/(d*Real.sqrt d) :=
      (lt_div_iff₀ (mul_pos hd0 hs)).mpr (by simpa only [mul_assoc] using case42_upper_bound hN hd0 hy hgap hu)
    convert hh using 1
    ring
  · apply (div_lt_div_iff₀ (by positivity) (by positivity)).mpr
    have hh := mul_lt_mul_of_pos_left hNd (by positivity : 0 < (66/100 : ℝ)*N*(1-3/4)*Real.sqrt d)
    nlinarith only [hh]
  · have hh := mul_lt_mul_of_pos_right (case42_cutoff_fraction hd (by norm_num : (3/4:ℝ)<1501/2000)) hN
    convert hh using 1 <;> ring

/-- The contradiction in the paper's Section 4.2, now using the printed chain. -/
theorem case42_contradiction_printed {N d y z : ℝ} (hN : 0 < N) (hNd : N < d)
    (hd : 112 ≤ d) (hy : N/4 ≤ y)
    (hgap : (5732/100 : ℝ)*d^2*y^3 < N^2*z)
    (hu : z^3 < (35700*256 : ℝ)*N^2*y^5) : False := by
  have h := case42_printed_chain hN hNd hd ((div_pos hN (by norm_num)).trans_le hy) hgap hu
  exact (not_lt_of_ge hy) (h.1.trans (h.2.1.trans h.2.2))

/-- The last displayed powers in Section 4.5, including 0.00005328 and 18768.8. -/
theorem case45_final_chain {N d M y : ℝ} {r : ℕ} (hN : 0 < N) (hd : 0 < d)
    (hM : 0 < M) (hy : 0 < y) (hr : 1 < r)
    (hh : (22725/100000 : ℝ)*
      ((23447/100000000 : ℝ)*M^4*d*y^2/N^3)^(r-1) < 1) :
    ((5328/100000000 : ℝ)*M^4*d*y^2/N^3)^(r-1) < 1 ∧
      (y^2*d*M^4/((187688/10 : ℝ)*N^3))^(r-1) <
        ((5328/100000000 : ℝ)*M^4*d*y^2/N^3)^(r-1) := by
  have hn : 0 < r-1 := by omega
  have hcp : (22725/100000 : ℝ)^(r-1) ≤ 22725/100000 := by
    simpa only [pow_one] using pow_le_pow_of_le_one
      (by norm_num : (0:ℝ)≤22725/100000) (by norm_num : (22725/100000:ℝ)≤1)
      (show 1 ≤ r-1 by omega)
  have hb : (5328/100000000 : ℝ) < (22725/100000)*(23447/100000000) := by norm_num
  have hfactor : 0 < M^4*d*y^2/N^3 := by positivity
  have hp := pow_lt_pow_left₀ (mul_lt_mul_of_pos_right hb hfactor) (by positivity) (by omega : r-1 ≠ 0)
  have hm := mul_le_mul_of_nonneg_right hcp
    (by positivity : 0 ≤ ((23447/100000000 : ℝ)*M^4*d*y^2/N^3)^(r-1))
  have hfirst : ((5328/100000000 : ℝ)*M^4*d*y^2/N^3)^(r-1) < 1 := by
    apply lt_trans _ hh
    have he : (22725/100000 : ℝ)*(23447/100000000)*(M^4*d*y^2/N^3) =
        (22725/100000 : ℝ)*((23447/100000000)*M^4*d*y^2/N^3) := by ring
    rw [he] at hp
    rw [← mul_pow] at hm
    have hcombined := hp.trans_le hm
    convert hcombined using 1
    ring
  refine ⟨hfirst,?_⟩
  apply pow_lt_pow_left₀ _ (by positivity) (by omega : r-1 ≠ 0)
  have hc : 1/(187688/10 : ℝ) < 5328/100000000 := by norm_num
  have hm := mul_lt_mul_of_pos_right hc hfactor
  convert hm using 1 <;> ring

/-- The paper's final contradiction using the last denominator 18768.8. -/
theorem case45_contradiction_printed {N d M y : ℝ} {r : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hM : 0 < M) (hr : 1 < r)
    (hy : 137*N*Real.sqrt N/(Real.sqrt d*M^2) ≤ y)
    (hh : (22725/100000 : ℝ)*
      ((23447/100000000 : ℝ)*M^4*d*y^2/N^3)^(r-1) < 1) : False := by
  have hyp : 0 < y := (by positivity : 0 < 137*N*Real.sqrt N/(Real.sqrt d*M^2)).trans_le hy
  have hchain := case45_final_chain hN hd hM hyp hr hh
  have hsq := threshold_squared hN hd hM hy
  have hbase : 1 < y^2*d*M^4/((187688/10 : ℝ)*N^3) := by
    apply (one_lt_div (by positivity)).mpr
    nlinarith only [hsq,pow_pos hN 3]
  have hp := one_le_pow₀ (n := r-1) hbase.le
  exact (not_lt_of_ge hp) (hchain.2.trans hchain.1)

end «JNT-2024».Section4
