module

public import «JNT-2024».ApproximationGcd
public import «JNT-2024».DenominatorBounds
public import «JNT-2024».NormalizerFormula
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Approximation

theorem g1_pos {u₁ u₂ : ℤ} (hu₂ : u₂ ≠ 0) : 0 < g1 u₁ u₂ :=
  Int.gcd_pos_of_ne_zero_right _ hu₂

theorem g2_pos {S : ℤ} (hS : S ≠ 0) (u₁ u₂ : ℤ) : 0 < g2 S u₁ u₂ :=
  Int.gcd_pos_of_ne_zero_right _ hS

theorem g_pos {S u₁ u₂ : ℤ} (hS : S ≠ 0) (hu₂ : u₂ ≠ 0) : 0 < g S u₁ u₂ := by
  unfold g
  exact mul_pos (by exact_mod_cast g1_pos hu₂)
    (Real.sqrt_pos.mpr (div_pos (by exact_mod_cast g2_pos hS u₁ u₂)
      (by exact_mod_cast g3_pos S u₁ u₂)))

def dPrimeInteger (S u₁ u₂ : ℤ) : ℤ :=
  (u₂ / (g1 u₁ u₂ : ℤ)) ^ 2 * (S / (g2 S u₁ u₂ : ℤ)) * g3 S u₁ u₂

theorem dPrimeInteger_cast {S u₁ u₂ : ℤ} (hS : S ≠ 0) (hu₂ : u₂ ≠ 0) :
    (dPrimeInteger S u₁ u₂ : ℚ) = dPrime S u₁ u₂ := by
  have hG : (g1 u₁ u₂ : ℚ) ≠ 0 := by exact_mod_cast ne_of_gt (g1_pos hu₂)
  have hH : (g2 S u₁ u₂ : ℚ) ≠ 0 := by exact_mod_cast ne_of_gt (g2_pos hS u₁ u₂)
  have hK : (g3 S u₁ u₂ : ℚ) ≠ 0 := by exact_mod_cast ne_of_gt (g3_pos S u₁ u₂)
  unfold dPrimeInteger dPrime gSquared
  rw [Int.cast_mul, Int.cast_mul, Int.cast_pow,
    Int.cast_div (m := u₂) (n := (g1 u₁ u₂ : ℤ)) (Int.gcd_dvd_right u₁ u₂) (by simpa using hG),
    Int.cast_div (m := S) (n := (g2 S u₁ u₂ : ℤ))
      (Int.gcd_dvd_right (u₁ / (g1 u₁ u₂ : ℤ)) S) (by simpa using hH)]
  push_cast
  field_simp

theorem dPrimeInteger_neg {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) :
    dPrimeInteger S u₁ u₂ < 0 := by
  have hg : (0 : ℚ) < gSquared S u₁ u₂ := by
    unfold gSquared
    exact div_pos (mul_pos (sq_pos_of_pos (by exact_mod_cast g1_pos hu₂))
      (by exact_mod_cast g2_pos (ne_of_lt hS) u₁ u₂)) (by exact_mod_cast g3_pos S u₁ u₂)
  have hh : (dPrime S u₁ u₂ : ℚ) < 0 := by
    unfold dPrime
    exact div_neg_of_neg_of_pos (mul_neg_of_pos_of_neg
      (sq_pos_of_ne_zero (by exact_mod_cast hu₂)) (by exact_mod_cast hS)) hg
  rw [← dPrimeInteger_cast (ne_of_lt hS) hu₂] at hh
  exact_mod_cast hh

theorem N4_dPrime_eq {S u₁ u₂ : ℤ} (hS : S ≠ 0) (hu₂ : u₂ ≠ 0) :
    N4 (dPrime S u₁ u₂) = Hypergeometric.twoAdicScale4 (dPrimeInteger S u₁ u₂) := by
  rw [← dPrimeInteger_cast hS hu₂, N4, Hypergeometric.twoAdicScale4, padicValRat.of_int]
  congr 1
  rw [show min (padicValInt 2 (dPrimeInteger S u₁ u₂) : ℤ) 6 =
    (min (padicValInt 2 (dPrimeInteger S u₁ u₂)) 6 : ℕ) by omega, zpow_natCast]

theorem normalizer_trace_square_integral {S u₁ u₂ : ℤ} (hS : S ≠ 0) (hu₂ : u₂ ≠ 0) :
    ∃ n : ℤ, (u₁ : ℚ) ^ 2 / gSquared S u₁ u₂ = n := by
  let a := u₁ / (g1 u₁ u₂ : ℤ)
  refine ⟨a * (a / (g2 S u₁ u₂ : ℤ)) * g3 S u₁ u₂, ?_⟩
  have hG : (g1 u₁ u₂ : ℚ) ≠ 0 := by exact_mod_cast ne_of_gt (g1_pos hu₂)
  have hH : (g2 S u₁ u₂ : ℚ) ≠ 0 := by exact_mod_cast ne_of_gt (g2_pos hS u₁ u₂)
  have hK : (g3 S u₁ u₂ : ℚ) ≠ 0 := by exact_mod_cast ne_of_gt (g3_pos S u₁ u₂)
  have ha : (a : ℚ) = (u₁ : ℚ) / g1 u₁ u₂ :=
    Int.cast_div (Int.gcd_dvd_left u₁ u₂) (by simpa using hG)
  push_cast
  rw [Int.cast_div (m := a) (n := (g2 S u₁ u₂ : ℤ)) (Int.gcd_dvd_left a S) (by simpa using hH), ha]
  unfold gSquared
  push_cast
  field_simp

theorem four_dvd_normalized_norm {S a b : ℤ} {h : ℕ} (_hh : 0 < h)
    (ha : (h : ℤ) ∣ a) (hS : (h : ℤ) ∣ S) :
    4 ∣ ((a ^ 2 - S * b ^ 2) / h) *
      (if S % 4 = 1 ∧ Even (a - b) then 1 else if S % 4 = 3 ∧ Even (a - b) then 2 else 4) := by
  have hd : (h : ℤ) ∣ a ^ 2 - S * b ^ 2 :=
    dvd_sub (dvd_pow ha (by decide : 2 ≠ 0)) (dvd_mul_of_dvd_left hS _)
  have hmul := Int.mul_ediv_cancel' hd
  split_ifs with hc hc
  · obtain ⟨t, ht⟩ := hc.2
    have hs : S = 4 * (S / 4) + 1 := by omega
    have hfour : (4 : ℤ) ∣ a ^ 2 - S * b ^ 2 := by
      refine ⟨b * t + t ^ 2 - (S / 4) * b ^ 2, ?_⟩
      have hat : a = b + 2 * t := by omega
      rw [hat]
      linear_combination -(b ^ 2) * hs
    have hoddS : Odd S := ⟨2 * (S / 4), by omega⟩
    have hodd : Odd h := hoddS.natAbs.of_dvd_nat (Int.natCast_dvd.mp hS)
    have hcop : Int.gcd 4 (h : ℤ) = 1 := by
      simpa [Int.gcd] using (hodd.coprime_two_left.pow_left 2).gcd_eq_one
    simp only [mul_one]
    exact Int.dvd_of_dvd_mul_right_of_gcd_one (by rwa [hmul]) hcop
  · obtain ⟨t, ht⟩ := hc.2
    have hs : S = 4 * (S / 4) + 3 := by omega
    have hfour : (4 : ℤ) ∣ (a ^ 2 - S * b ^ 2) * 2 := by
      refine ⟨2 * b * t + 2 * t ^ 2 - 2 * (S / 4) * b ^ 2 - b ^ 2, ?_⟩
      have hat : a = b + 2 * t := by omega
      rw [hat]
      linear_combination -(2 * b ^ 2) * hs
    have hoddS : Odd S := ⟨2 * (S / 4) + 1, by omega⟩
    have hodd : Odd h := hoddS.natAbs.of_dvd_nat (Int.natCast_dvd.mp hS)
    have hcop : Int.gcd 4 (h : ℤ) = 1 := by
      simpa [Int.gcd] using (hodd.coprime_two_left.pow_left 2).gcd_eq_one
    exact Int.dvd_of_dvd_mul_right_of_gcd_one
      (by simpa only [← mul_assoc, hmul] using hfour) hcop
  · exact dvd_mul_left _ _

theorem normalizer_norm_integral {S u₁ u₂ : ℤ} (hS : S ≠ 0) (hu₂ : u₂ ≠ 0) :
    ∃ n : ℤ, ((u₁ : ℚ) ^ 2 - S * (u₂ : ℚ) ^ 2) / (4 * gSquared S u₁ u₂) = n := by
  let G := g1 u₁ u₂
  let H := g2 S u₁ u₂
  let K := g3 S u₁ u₂
  let a := u₁ / (G : ℤ)
  let b := u₂ / (G : ℤ)
  have hGz : (G : ℤ) ≠ 0 := by exact_mod_cast ne_of_gt (g1_pos hu₂)
  have hGa : (G : ℤ) * a = u₁ := Int.mul_ediv_cancel' (Int.gcd_dvd_left u₁ u₂)
  have hGb : (G : ℤ) * b = u₂ := Int.mul_ediv_cancel' (Int.gcd_dvd_right u₁ u₂)
  have hHa : (H : ℤ) ∣ a := Int.gcd_dvd_left a S
  have hHS : (H : ℤ) ∣ S := Int.gcd_dvd_right a S
  have hsub : (u₁ - u₂) / (G : ℤ) = a - b := by
    rw [← hGa, ← hGb, ← mul_sub, Int.mul_ediv_cancel_left _ hGz]
  have hk : (K : ℤ) = if S % 4 = 1 ∧ Even (a - b) then 1
      else if S % 4 = 3 ∧ Even (a - b) then 2 else 4 := by
    dsimp [K, g3]
    change ((if S % 4 = 1 ∧ Even ((u₁ - u₂) / (G : ℤ)) then 1
      else if S % 4 = 3 ∧ Even ((u₁ - u₂) / (G : ℤ)) then 2 else 4 : ℕ) : ℤ) = _
    rw [hsub]
    split_ifs <;> rfl
  have hfour := four_dvd_normalized_norm (g2_pos hS u₁ u₂) hHa hHS (b := b)
  rw [← hk] at hfour
  obtain ⟨n, hn⟩ := hfour
  refine ⟨n, ?_⟩
  let T := (a ^ 2 - S * b ^ 2) / (H : ℤ)
  have hHT : (H : ℤ) * T = a ^ 2 - S * b ^ 2 := Int.mul_ediv_cancel'
    (dvd_sub (dvd_pow hHa (by decide : 2 ≠ 0)) (dvd_mul_of_dvd_left hHS _))
  have hGaQ : (G : ℚ) * a = u₁ := by exact_mod_cast hGa
  have hGbQ : (G : ℚ) * b = u₂ := by exact_mod_cast hGb
  have hHTQ : (H : ℚ) * T = (a : ℚ) ^ 2 - S * (b : ℚ) ^ 2 := by exact_mod_cast hHT
  have hnQ : (T : ℚ) * K = 4 * n := by exact_mod_cast hn
  have hG : (G : ℚ) ≠ 0 := by exact_mod_cast hGz
  have hH : (H : ℚ) ≠ 0 := by exact_mod_cast ne_of_gt (g2_pos hS u₁ u₂)
  have hK : (K : ℚ) ≠ 0 := by exact_mod_cast ne_of_gt (g3_pos S u₁ u₂)
  change ((u₁ : ℚ) ^ 2 - S * (u₂ : ℚ) ^ 2) / (4 * ((G : ℚ) ^ 2 * H / K)) = _
  have he : (u₁ : ℚ) ^ 2 - S * (u₂ : ℚ) ^ 2 = (G : ℚ) ^ 2 * H * T := by
    rw [← hGaQ, ← hGbQ, mul_assoc ((G : ℚ) ^ 2), hHTQ]
    ring
  rw [he]
  field_simp
  exact hnQ

end Approximation
end «JNT-2024»
