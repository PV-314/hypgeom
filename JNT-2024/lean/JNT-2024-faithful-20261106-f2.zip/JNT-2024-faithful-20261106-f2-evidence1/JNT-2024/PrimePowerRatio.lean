module

public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- The elementary unique-factorization conclusion of the prime-by-prime
proof of Lemma 3.11. -/
theorem nat_eq_two_power_mul_of_valuations {A B : ℕ} (hA : A ≠ 0) (hB : B ≠ 0)
    (ho : ∀ p : ℕ, p.Prime → p ≠ 2 → padicValNat p A = padicValNat p B)
    (h₂ : padicValNat 2 B ≤ padicValNat 2 A) : ∃ m : ℕ, A = 2 ^ m * B := by
  refine ⟨padicValNat 2 A - padicValNat 2 B, ?_⟩
  apply Nat.eq_of_factorization_eq hA (mul_ne_zero (pow_ne_zero _ (by decide)) hB)
  intro p
  by_cases hp : p.Prime
  · let : Fact p.Prime := ⟨hp⟩
    rw [Nat.factorization_def _ hp, Nat.factorization_def _ hp,
      padicValNat.mul (pow_ne_zero _ (by decide)) hB, padicValNat.pow]
    by_cases hp₂ : p = 2
    · subst p
      norm_num
      omega
    · rw [padicValNat_primes hp₂, mul_zero, zero_add]
      exact ho p hp hp₂
  · rw [Nat.factorization_eq_zero_of_not_prime _ hp, Nat.factorization_eq_zero_of_not_prime _ hp]

end «JNT-2024»
