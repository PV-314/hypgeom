module

public import «JNT-2024».Examples
public import «JNT-2024».NormalizerBounds
public import «JNT-2024».NormalizerFormula
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».Section5GcdNormalization
public import «JNT-2024».Section5ResidueTransfer
public import «JNT-2024».Section6Families
public import «JNT-2024».Section6Fibonacci
public import «JNT-2024».Sequence
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Fib.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section6

def lucasIndex (j : ℕ) : ℤ := (lucasFamily j-99)/100
def family64 (j : ℕ) : Parameters := unitOne (30*lucasIndex j+31) (50*lucasIndex j+49)
def normRoot64 (j : ℕ) : ℤ := 40*lucasIndex j+38

theorem lucasIndex_spec (j : ℕ) :
    1 ≤ lucasIndex j ∧ lucasFamily j = 100*lucasIndex j+99 := by
  have hh := lucasFamily_properties j
  dsimp [lucasIndex]
  omega

/-- The integer formulas above are exactly the fractions printed in Section 6.4. -/
theorem family64_published_parameters (j : ℕ) :
    (family64 j).a = (3*lucasFamily j+13)/10 ∧
    (family64 j).t = (lucasFamily j-1)/2 ∧
    (family64 j).u = 1 ∧ (family64 j).b = 1 ∧
    (family64 j).d = ((family64 j).t)^2+4 ∧
    normRoot64 j = 2*(lucasFamily j-4)/5 := by
  have hh := lucasIndex_spec j
  dsimp [family64, unitOne, normRoot64]
  omega

theorem family64_admissible (j : ℕ) : (family64 j).Admissible := by
  have hh := lucasIndex_spec j
  exact unitOne_admissible (by omega) (by omega)

theorem family64_norm (j : ℕ) : (family64 j).normAlpha = -(normRoot64 j)^2 := by
  simp [family64, unitOne, normRoot64, Parameters.normAlpha]
  ring

theorem family64_square (j : ℕ) :
    (family64 j).y (family64_admissible j).pell 1 = (fibonacciFamily j : ℚ)^2 := by
  have hn := (lucasFamily_properties j).2.2.1
  rw [(lucasIndex_spec j).2] at hn
  have hn' : (100*(lucasIndex j : ℚ)+99)^2-5*(fibonacciFamily j : ℚ)^2 = -4 := by exact_mod_cast hn
  rw [Parameters.y_one]
  simp only [family64, unitOne]
  push_cast
  nlinarith only [hn']

theorem family64_coprime (j : ℕ) : Int.gcd (family64 j).a (normRoot64 j) = 1 := by
  let a := (family64 j).a
  let n := normRoot64 j
  let g := Int.gcd a n
  have ha : (g : ℤ) ∣ a := Int.gcd_dvd_left a n
  have hn : (g : ℤ) ∣ n := Int.gcd_dvd_right a n
  have he : 4*a-3*n=10 := by dsimp [a,n,family64,unitOne,normRoot64]; ring
  have hg10 : (g : ℤ) ∣ 10 := by
    rw [← he]
    exact dvd_sub (dvd_mul_of_dvd_right ha 4) (dvd_mul_of_dvd_right hn 3)
  have hamod : a % 10 = 1 := by dsimp [a,family64,unitOne]; omega
  have hac : Int.gcd a 10 = 1 := by rw [← Int.gcd_emod a 10, hamod]; decide
  have hg1 := Int.dvd_gcd ha hg10
  rw [hac] at hg1
  exact Nat.dvd_one.mp hg1

theorem gcd16_square_two {r : ℤ} (hr : r % 4 = 2) : Int.gcd 16 (r^2) = 4 := by
  rw [Section5.gcd_square_residue r 16 (by decide)]
  have hc : ∀ v : ZMod 16, v.val % 4 = 2 → Nat.gcd 16 (v.val^2) = 4 := by decide +kernel
  apply hc
  have hv := ZMod.val_intCast (n := 16) r
  omega

theorem family64_normalizer (j : ℕ) :
    (family64 j).baseGcd = 1 ∧ (family64 j).normalizerSquare = 16 := by
  have hN := family64_norm j
  have hG := (family64 j).section5_baseGcd (by rfl : (family64 j).b=1)
    (show -(family64 j).normAlpha=(normRoot64 j)^2 by omega)
  rw [family64_coprime, one_pow] at hG
  have hq : (family64 j).normQuotient = -(normRoot64 j)^2 := by
    simp [Parameters.normQuotient, hN, hG]
  have hr : normRoot64 j % 4 = 2 := by dsimp [normRoot64]; omega
  have hc := gcd16_square_two hr
  refine ⟨hG, ?_⟩
  simp only [Parameters.normalizerSquare, hG, hq, Int.natAbs_neg, mul_one]
  have hh : Nat.gcd 16 ((normRoot64 j)^2).natAbs = 4 := hc
  rw [hh]

theorem family64_initial : family64 0 = Examples.section64 := by decide +kernel

theorem family64_injective : Function.Injective family64 := by
  intro i j he
  have ht := congrArg Parameters.t he
  have hi := lucasIndex_spec i
  have hj := lucasIndex_spec j
  apply lucasFamily_strictMono.injective
  dsimp [family64, unitOne] at ht
  omega

theorem family64_infinite : Set.Infinite (Set.range family64) :=
  Set.infinite_range_of_injective family64_injective

end «JNT-2024».Section6
