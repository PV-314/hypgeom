module

public import «JNT-2024».GrowthBounds
public import «JNT-2024».Section6Families
public import «JNT-2024».Sequence
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Analysis.SpecificLimits.Basic
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

open Filter Topology

namespace «JNT-2024».Section6

def family69 (n : ℤ) : Parameters := unitOne (2*n^2-3) (2*n^2-2)

theorem family69_admissible {n : ℤ} (hn : 3 ≤ n) : (family69 n).Admissible := by
  exact unitOne_admissible (by nlinarith) (by nlinarith)

theorem family69_published {n : ℤ} (hn : 3 ≤ n) (_h5 : ¬ 5 ∣ 2*n^2-3) :
    (family69 n).a = 2*n^2-3 ∧ (family69 n).d = 4*n^4-8*n^2+8 ∧
    (family69 n).t = (family69 n).a+1 ∧ (family69 n).u = 1 ∧
    (family69 n).normAlpha = 1-4*n^2 ∧
    (family69 n).y (family69_admissible hn).pell (-1) = (n : ℚ)^2 := by
  refine ⟨rfl, ?_, ?_, rfl, ?_, ?_⟩
  · dsimp [family69,unitOne]; ring
  · dsimp [family69,unitOne]; ring
  · dsimp [family69,unitOne,Parameters.normAlpha]; ring
  · rw [Parameters.y_neg_one]
    simp only [family69,unitOne]
    push_cast
    ring

theorem family69_ratio {n : ℤ} (hn : 3 ≤ n) :
    ((family69 n).y (family69_admissible hn).pell (-1) : ℝ) /
      |((family69 n).normAlpha : ℝ)| = (n : ℝ)^2/(4*(n : ℝ)^2-1) := by
  have hy : (family69 n).y (family69_admissible hn).pell (-1) = (n : ℚ)^2 := by
    rw [Parameters.y_neg_one]; simp only [family69,unitOne]; push_cast; ring
  have hN : (family69 n).normAlpha = 1-4*n^2 := by dsimp [family69,unitOne,Parameters.normAlpha]; ring
  rw [hy,hN]
  push_cast
  have hn' : (3 : ℝ) ≤ n := by exact_mod_cast hn
  rw [abs_of_neg (by nlinarith : (1 : ℝ)-4*(n : ℝ)^2<0)]
  ring

theorem quadratic_ratio_limit :
    Tendsto (fun x : ℝ => x^2/(4*x^2-1)) atTop (𝓝 (1/4 : ℝ)) := by
  have hi : Tendsto (fun x : ℝ => x⁻¹) atTop (𝓝 0) := tendsto_inv_atTop_zero
  have hh : Tendsto (fun x : ℝ => 1/(4-(x⁻¹)^2)) atTop (𝓝 (1/4 : ℝ)) := by
    convert tendsto_const_nhds.div (tendsto_const_nhds.sub (hi.pow 2)) (by norm_num : (4 : ℝ)-0^2 ≠ 0) using 1; norm_num
  apply hh.congr'
  filter_upwards [eventually_gt_atTop (1 : ℝ)] with x hx
  have hx0 : x ≠ 0 := by linarith
  have hd : 4*x^2-1 ≠ 0 := by nlinarith
  field_simp [hx0,hd]

theorem quadratic_ratio_above {x : ℝ} (hx : 1 ≤ x) : (1/4 : ℝ) < x^2/(4*x^2-1) := by
  apply (lt_div_iff₀ (show (0 : ℝ) < 4*x^2-1 by nlinarith)).mpr
  linarith

/-- An explicit family supplying the square-negative-norm existence assertion in 6.9. -/
def squareNorm69 (n : ℤ) : Parameters := unitOne (4*n^3-6*n) (4*n^3+2*n)

theorem squareNorm69_admissible {n : ℤ} (hn : 2 ≤ n) : (squareNorm69 n).Admissible := by
  have hn0 : 0 ≤ n := by omega
  have hh := mul_le_mul_of_nonneg_right (show 4 ≤ n^2 by nlinarith) hn0
  exact unitOne_admissible (by nlinarith) (by nlinarith)

theorem squareNorm69_values {n : ℤ} (hn : 2 ≤ n) :
    (squareNorm69 n).normAlpha = -(8*n^2-2)^2 ∧
    (squareNorm69 n).y (squareNorm69_admissible hn).pell (-1) = (4*(n : ℚ)^2+1)^2 := by
  constructor
  · dsimp [squareNorm69,unitOne,Parameters.normAlpha]; ring
  · rw [Parameters.y_neg_one]
    simp only [squareNorm69,unitOne]
    push_cast
    ring

theorem square_norm_ratio_limit :
    Tendsto (fun x : ℝ => (4*x^2+1)^2/(8*x^2-2)^2) atTop (𝓝 (1/4 : ℝ)) := by
  have hi : Tendsto (fun x : ℝ => x⁻¹) atTop (𝓝 0) := tendsto_inv_atTop_zero
  have hh : Tendsto (fun x : ℝ => ((4+(x⁻¹)^2)/(8-2*(x⁻¹)^2))^2) atTop (𝓝 (1/4 : ℝ)) := by
    convert ((tendsto_const_nhds.add (hi.pow 2)).div
      (tendsto_const_nhds.sub (tendsto_const_nhds.mul (hi.pow 2)))
      (by norm_num : (8 : ℝ)-2*0^2 ≠ 0)).pow 2 using 1; norm_num
  apply hh.congr'
  filter_upwards [eventually_gt_atTop (1 : ℝ)] with x hx
  have hx0 : x ≠ 0 := by linarith
  have hd : 8*x^2-2 ≠ 0 := by nlinarith
  field_simp [hx0,hd]

theorem square_norm_ratio_above {x : ℝ} (hx : 1 ≤ x) :
    (1/4 : ℝ) < (4*x^2+1)^2/(8*x^2-2)^2 := by
  apply (lt_div_iff₀ (sq_pos_of_pos (show 0 < 8*x^2-2 by nlinarith))).mpr
  nlinarith [sq_nonneg x]

/-- The lower bound one is attained, as claimed in the final paragraph of Section 6. -/
theorem lower_bound_attained :
    (unitOne 2 2).y (unitOne_admissible (by norm_num) (by norm_num)).pell (-1) = 1 ∧
    (unitOne 2 2).lowerSeed = 1 := by
  rw [Parameters.y_neg_one]
  norm_num [unitOne,Parameters.lowerSeed,Parameters.normAlpha]

end «JNT-2024».Section6
