module

public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

theorem RepresentsSquare.neg_y {P : Parameters} {x y : ℤ}
    (h : P.RepresentsSquare x y) : P.RepresentsSquare x (-y) := by
  simpa only [RepresentsSquare, Int.cast_neg, neg_sq] using h

theorem repCandidate_neg_y (P : Parameters) (y σ : ℤ) :
    P.repCandidate (-y) σ = P.repCandidate y (-σ) := by
  unfold repCandidate
  ring

/-- The integer radical on the right side of Lemma 3.3(a). -/
noncomputable def representationRadical (P : Parameters) (ν : ℤ) : ℤ :=
  UniqueFactorizationMonoid.radical
    (Int.gcd (P.u * P.normAlpha) (ν * squarefreePart P.normAlpha) : ℤ)

/-- A common candidate prime away from `2b` divides the integer norm of `ε`. -/
theorem candidate_common_prime_dvd_norm (P : Parameters) {x y ν : ℤ}
    (h : P.RepresentsSquare x y) (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν)
    (p : ℕ) [hp : Fact p.Prime] (hpb : ¬ (p : ℤ) ∣ 2 * P.b)
    (hr : (p : ℤ) ∣ P.repCandidate y 1)
    (hr' : (p : ℤ) ∣ P.repCandidate y (-1)) : (p : ℤ) ∣ ν := by
  have hpI : Prime (p : ℤ) := Nat.prime_iff_prime_int.mp hp.out
  have hp4b : ¬ (p : ℤ) ∣ 4 * P.b := by
    intro hd
    have hh : (p : ℤ) ∣ 2 * (2 * P.b) := by convert hd using 1; ring
    rcases hpI.dvd_mul.mp hh with hh | hh
    · exact hpb (dvd_mul_of_dvd_left hh P.b)
    · exact hpb hh
  have hy : (p : ℤ) ∣ y := by
    have hd := dvd_sub hr hr'
    have he : P.repCandidate y 1 - P.repCandidate y (-1) = (4 * P.b) * y := by
      unfold repCandidate
      ring
    rw [he] at hd
    exact (hpI.dvd_mul.mp hd).resolve_left hp4b
  have hd : (p : ℤ) ∣ P.t * (P.repCandidate y 1 + P.repCandidate y (-1)) - 4 * y ^ 2 :=
    dvd_sub (dvd_mul_of_dvd_right (dvd_add hr hr') P.t)
      (by simpa only [pow_two] using dvd_mul_of_dvd_right (dvd_mul_of_dvd_left hy y) 4)
  have he : P.t * (P.repCandidate y 1 + P.repCandidate y (-1)) - 4 * y ^ 2 =
      (2 * P.b) ^ 2 * ν := by
    have hyy := P.representation_y h
    have hnn := congrArg (fun z : ℤ => P.b ^ 2 * z) hν
    dsimp [repCandidate]
    nlinarith only [hyy, hnn]
  rw [he] at hd
  exact (hpI.dvd_mul.mp hd).resolve_left (fun hh => hpb (hpI.dvd_of_dvd_pow hh))






































































































end «JNT-2024».Parameters
