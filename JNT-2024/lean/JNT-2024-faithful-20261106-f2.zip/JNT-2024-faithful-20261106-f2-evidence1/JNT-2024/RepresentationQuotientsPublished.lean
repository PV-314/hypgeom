module

public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».RepresentationNormalization
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section
namespace «JNT-2024».Parameters

/-- The divisor a+sqrt(N_alpha) cannot vanish: its root coordinate is one. -/
theorem repBeta_ne_zero (P : Parameters) : P.repBeta ≠ 0 := by
  intro hz
  have hh := congrArg QuadraticAlgebra.im hz
  norm_num [repBeta] at hh

/-- Multiplying by the conjugate gives the printed denominator b^4*d. -/
theorem representation_conjugate_product (P : Parameters) :
    P.repBeta * (⟨(P.a : ℚ), -1⟩ : P.NormAlgebra) =
      ((P.b : ℚ) ^ 4 * P.d) • (1 : P.NormAlgebra) := by
  ext <;> simp only [repBeta, QuadraticAlgebra.re_mul, QuadraticAlgebra.im_mul,
    QuadraticAlgebra.re_smul, QuadraticAlgebra.im_smul, QuadraticAlgebra.re_one,
    QuadraticAlgebra.im_one, smul_eq_mul] <;> simp [normAlpha]; ring

/-- All scalar denominators in the printed quotient calculation are nonzero
under the paper's hypotheses; no positivity of d or N_alpha is needed. -/
theorem representation_quotient_denominators (P : Parameters) [Fact (¬ IsSquare P.d)]
    (hb : 0 < P.b) :
    (4 * (P.b : ℚ) ^ 4 * P.d ≠ 0) ∧ (4 * (P.b : ℚ) ^ 4 ≠ 0) ∧
      (2 * (P.b : ℚ) ^ 2 ≠ 0) := by
  have hbq : (P.b : ℚ) ≠ 0 := by exact_mod_cast ne_of_gt hb
  have hd : P.d ≠ 0 := by
    intro hz
    have hn : ¬ IsSquare P.d := Fact.out
    apply hn
    rw [hz]
    exact ⟨0, by ring⟩
  have hdq : (P.d : ℚ) ≠ 0 := by exact_mod_cast hd
  exact ⟨mul_ne_zero (mul_ne_zero (by norm_num) (pow_ne_zero _ hbq)) hdq,
    mul_ne_zero (by norm_num) (pow_ne_zero _ hbq),
    mul_ne_zero (by norm_num) (pow_ne_zero _ hbq)⟩

section Quotient
variable (P : Parameters) [Fact (¬ IsSquare P.normAlpha)]

/-- Rationalisation by the conjugate, before substituting the two norms. -/
theorem representation_quotient_conjugate (x : ℤ) (hb : P.b ≠ 0) (hd : P.d ≠ 0) :
    P.repGamma x / P.repBeta =
      (1 / ((P.b : ℚ) ^ 4 * P.d)) •
        (P.repGamma x * (⟨(P.a : ℚ), -1⟩ : P.NormAlgebra)) := by
  apply (div_eq_iff P.repBeta_ne_zero).mpr
  have hc : (⟨(P.a : ℚ), -1⟩ : P.NormAlgebra) * P.repBeta =
      ((P.b : ℚ) ^ 4 * P.d) • (1 : P.NormAlgebra) := by
    rw [mul_comm]
    exact P.representation_conjugate_product
  have hbq : (P.b : ℚ) ≠ 0 := by exact_mod_cast hb
  have hdq : (P.d : ℚ) ≠ 0 := by exact_mod_cast hd
  rw [smul_mul_assoc, mul_assoc, hc, mul_smul_comm, mul_one, smul_smul]
  have hs : (1 / ((P.b : ℚ) ^ 4 * P.d)) * ((P.b : ℚ) ^ 4 * P.d) = 1 := by
    field_simp
  rw [hs, one_smul]

/-- The first displayed rationalised quotient on p. 13, with exactly its
printed numerator and denominator. -/
theorem representation_quotient_expanded (x : ℤ) (hb : P.b ≠ 0) (hd : P.d ≠ 0) :
    P.repGamma x / P.repBeta =
      (1 / (4 * (P.b : ℚ) ^ 4 * P.d)) •
        (⟨4 * P.a * (x : ℚ) - (P.a : ℚ) ^ 2 * (P.t : ℚ) ^ 2 +
            (P.b : ℚ) ^ 4 * P.d * (P.t : ℚ) ^ 2 +
            (P.a : ℚ) ^ 2 * P.d * (P.u : ℚ) ^ 2 -
            (P.b : ℚ) ^ 4 * (P.d : ℚ) ^ 2 * (P.u : ℚ) ^ 2,
          P.a * (P.t : ℚ) ^ 2 - P.a * P.d * (P.u : ℚ) ^ 2 - 4 * x⟩ : P.NormAlgebra) := by
  rw [P.representation_quotient_conjugate x hb hd]
  have hbq : (P.b : ℚ) ≠ 0 := by exact_mod_cast hb
  have hdq : (P.d : ℚ) ≠ 0 := by exact_mod_cast hd
  ext <;> simp only [repGamma, QuadraticAlgebra.re_mul, QuadraticAlgebra.im_mul,
    QuadraticAlgebra.re_smul, QuadraticAlgebra.im_smul, smul_eq_mul] <;>
    simp [epsilonNorm, normAlpha] <;> field_simp <;> ring

/-- The second displayed quotient, after substitution of the existing (3.9). -/
theorem representation_quotient_substituted {x y : ℤ} (h : P.RepresentsSquare x y)
    (hb : P.b ≠ 0) (hd : P.d ≠ 0) :
    P.repGamma x / P.repBeta =
      (1 / (4 * (P.b : ℚ) ^ 4)) •
        (⟨2 * (P.a : ℚ) ^ 2 * (P.u : ℚ) ^ 2 +
            2 * P.a * (P.b : ℚ) ^ 2 * P.t * P.u +
            (P.b : ℚ) ^ 4 * (P.t : ℚ) ^ 2 - P.d * (P.b : ℚ) ^ 4 * (P.u : ℚ) ^ 2,
          -2 * P.u * ((P.a : ℚ) * P.u + (P.b : ℚ) ^ 2 * P.t)⟩ : P.NormAlgebra) := by
  rw [P.representation_quotient_expanded x hb hd]
  have hx : (4 : ℚ) * x = P.a * ((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) +
      2 * (P.b : ℚ) ^ 2 * P.d * P.t * P.u := by exact_mod_cast P.representation_x h
  have hxe : (x : ℚ) = (P.a * ((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) +
      2 * (P.b : ℚ) ^ 2 * P.d * P.t * P.u) / 4 := by linarith
  have hbq : (P.b : ℚ) ≠ 0 := by exact_mod_cast hb
  have hdq : (P.d : ℚ) ≠ 0 := by exact_mod_cast hd
  rw [hxe]
  ext <;> simp <;> field_simp <;> ring

omit [Fact (¬ IsSquare P.normAlpha)] in
/-- The completion of the square explicitly stated before the first square
identity on p. 13. -/
theorem representation_completed_square :
    2 * (P.a : ℚ) ^ 2 * (P.u : ℚ) ^ 2 +
      2 * P.a * (P.b : ℚ) ^ 2 * P.t * P.u +
      (P.b : ℚ) ^ 4 * (P.t : ℚ) ^ 2 - P.d * (P.b : ℚ) ^ 4 * (P.u : ℚ) ^ 2 =
    ((P.a : ℚ) * P.u + (P.b : ℚ) ^ 2 * P.t) ^ 2 + (P.u : ℚ) ^ 2 * P.normAlpha := by
  simp [normAlpha]
  ring

/-- The first square in its printed quotient form, obtained through the two
printed quotient expansions and completion of the square. -/
theorem representation_quotient_square {x y : ℤ} (h : P.RepresentsSquare x y)
    (hb : P.b ≠ 0) (hd : P.d ≠ 0) :
    P.repGamma x / P.repBeta = ((1 / (2 * (P.b : ℚ) ^ 2)) • P.repMiddle) ^ 2 := by
  rw [P.representation_quotient_substituted h hb hd, P.representation_completed_square]
  have hbq : (P.b : ℚ) ≠ 0 := by exact_mod_cast hb
  ext <;> simp [repMiddle, pow_two] <;> field_simp <;> ring

/-- Clear the first square's denominator after the printed quotient proof. -/
theorem representation_first_square_published {x y : ℤ} (h : P.RepresentsSquare x y)
    (hb : P.b ≠ 0) (hd : P.d ≠ 0) :
    P.repBeta * P.repMiddle ^ 2 = (4 * (P.b : ℚ) ^ 4) • P.repGamma x := by
  have hx := (div_eq_iff P.repBeta_ne_zero).mp (P.representation_quotient_square h hb hd)
  have hbq : (P.b : ℚ) ≠ 0 := by exact_mod_cast hb
  have hs : (4 * (P.b : ℚ) ^ 4) * (1 / (2 * (P.b : ℚ) ^ 2)) ^ 2 = 1 := by
    field_simp
    ring
  rw [hx, smul_pow, smul_mul_assoc, smul_smul, hs, one_smul, mul_comm]

/-- Equation (3.10), using the printed quotient proof and the existing
second square identity, for either candidate sign. -/
theorem representation_fourth_power_published {x y σ : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hd : P.d ≠ 0) (hσ : σ ^ 2 = 1) :
    (4 * (P.b : ℚ) ^ 2 * P.repCandidate y σ) ^ 2 • P.repGamma x =
      P.repBeta * P.repRoot y σ ^ 4 := by
  calc
    _ = (2 * (P.repCandidate y σ : ℚ)) ^ 2 • ((4 * (P.b : ℚ) ^ 4) • P.repGamma x) := by
      rw [smul_smul]
      congr 1
      ring
    _ = (2 * (P.repCandidate y σ : ℚ)) ^ 2 • (P.repBeta * P.repMiddle ^ 2) := by
      rw [P.representation_first_square_published h hb hd]
    _ = P.repBeta * ((2 * (P.repCandidate y σ : ℚ)) • P.repMiddle) ^ 2 := by
      rw [smul_pow, mul_smul_comm]
    _ = _ := by rw [← P.representation_second_square h hσ, ← pow_mul]

/-- The squarefree substitution in (3.10), supplied with the printed quotient
proof. Reuses the existing generator map and companion identity. -/
theorem unnormalized_representation_from_quotient {x y σ : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hd : P.d ≠ 0) (hσ : σ ^ 2 = 1) :
    P.FourthPowerRepresentation x y (σ * 4 * P.b ^ 2 * P.repCandidate y σ)
      (P.repCandidate y σ) (-P.u * squareFactor P.normAlpha) := by
  constructor
  · have hh := congrArg P.normToSquarefree (P.representation_fourth_power_published h hb hd hσ)
    simp only [map_smul, map_mul, map_pow] at hh
    simp only [P.normToSquarefree_apply] at hh
    have hs : (σ : ℚ) ^ 2 = 1 := by exact_mod_cast hσ
    have hf : ((σ * 4 * P.b ^ 2 * P.repCandidate y σ : ℤ) : ℚ) ^ 2 =
        (4 * (P.b : ℚ) ^ 2 * P.repCandidate y σ) ^ 2 := by
      push_cast
      calc
        _ = (σ : ℚ) ^ 2 * (4 * (P.b : ℚ) ^ 2 * P.repCandidate y σ) ^ 2 := by ring
        _ = _ := by rw [hs, one_mul]
    change _ = _
    rw [hf]
    simpa [repGamma, repBeta, repRoot, mul_comm, mul_left_comm, mul_assoc] using hh
  · have hc := congrArg (fun z : ℤ => P.b * z) (P.representation_companion h hσ)
    have hs := squareFactor_sq_mul P.normAlpha
    have hm := congrArg (fun z : ℤ => P.b * P.u ^ 2 * z) hs
    nlinarith only [hc, hm]

end Quotient
end «JNT-2024».Parameters
