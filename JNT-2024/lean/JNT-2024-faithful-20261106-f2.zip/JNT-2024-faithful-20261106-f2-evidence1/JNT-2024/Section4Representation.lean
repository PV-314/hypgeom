module

public import «JNT-2024».ComplexRepresentation
public import «JNT-2024».GapLattice
public import «JNT-2024».GapRepresentationBounds
public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».RepresentationBothEvenPublished
public import «JNT-2024».RepresentationGaussian
public import «JNT-2024».Section2Complex
public import «JNT-2024».Section4Gaussian
public import «JNT-2024».Section4Sequence
public import «JNT-2024».Sequence
public import «JNT-2024».SequenceRepresentations
public import «JNT-2024».SquarefreePart
public import «JNT-2024».Targets
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters


/-- Section 4's representation retains the signed complex identity, the original
sequence coordinate, and the exact coefficient `f=1`. -/
theorem section4_representation (P : Parameters) (h : P.Admissible) (hb : P.b = 1)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha)) {k : ℤ}
    (hk : k ≠ 0) (hs : IsIntegerSquare (P.y h.pell k)) (hy : 0 < P.y h.pell k) :
    ∃ X ν r s τ : ℤ, P.x h.pell k = (X : ℚ) ∧ (ν = 1 ∨ ν = -1) ∧
      (τ = 1 ∨ τ = -1) ∧ quadraticPoint 1 r s ≠ 0 ∧
      ‖quadraticPoint 1 r s‖ ^ 4 = (P.y h.pell k : ℝ) ∧
      (τ : ℂ) * Section2.U (-1) (2 * X) (2 * (ν * squareFactor P.normAlpha)) =
        P.complexAlpha * quadraticPoint 1 r s ^ 4 := by
  obtain ⟨v₀, hv₀⟩ := hs
  let v := |v₀|
  have hv : P.y h.pell k = (v : ℚ) ^ 2 := by simpa [v] using hv₀
  have hvpos : 0 < v := by
    have hvq : (0 : ℚ) < v := by
      have hh : (0 : ℚ) ≤ v := by exact_mod_cast abs_nonneg v₀
      nlinarith
    exact_mod_cast hvq
  obtain ⟨X, Y, hx, _, _⟩ := P.section4_integer_coordinates h.pell ⟨v₀, hv₀⟩
  obtain ⟨T, U, hU, hp, he⟩ := P.sequence_unit_parameters h hk
  let Q := P.withUnit T U
  let : Fact (¬ IsSquare Q.d) := ⟨h.d_not_square⟩
  let : Fact (¬ IsSquare Q.normAlpha) := ⟨by
    intro hsN
    have hh := IsSquare.nonneg hsN
    change 0 ≤ P.normAlpha at hh
    omega⟩
  have hrep : Q.RepresentsSquare X v := by
    change (⟨(X : ℚ), (v : ℚ) ^ 2⟩ : P.Algebra) = P.alpha * Q.epsilon ^ 2
    rw [← he]
    ext
    · exact hx.symm
    · exact hv.symm
  obtain ⟨ν, f, r, s, τ, hν, hf, hτ, hF, hd⟩ := Q.proposition31b_published hrep (ne_of_gt h.a_pos)
    (ne_of_gt h.b_pos) (ne_of_gt hvpos) hU (ne_of_lt hn) (Q.epsilon_isIntegral hp) hNs
  have hνunit := Q.integer_unit_norm hp hν
  have hS := squarefreePart_eq_neg_one (ne_of_lt hn) hNs
  have hQN : Q.normAlpha = P.normAlpha := rfl
  have hQb : Q.b = 1 := hb
  have hdiv : f ∣ (1 : ℤ) := by
    simpa only [hQb, one_pow, Q.normRadical_of_unit hνunit, one_mul] using hd
  have hcomp : f * v = r ^ 2 + s ^ 2 := by
    simpa only [hQN, hQb, hS, neg_mul, one_mul, sub_neg_eq_add] using hF.2
  have hfpos : 0 < f := by
    have hh : 0 ≤ f * v := by nlinarith only [hcomp, sq_nonneg r, sq_nonneg s]
    have hh' : 0 ≤ f := (mul_nonneg_iff_of_pos_right hvpos).mp hh
    omega
  have hf1 : f = 1 := by have hh := Int.le_of_dvd (by decide : (0 : ℤ) < 1) hdiv; omega
  subst f
  let z := quadraticPoint 1 r s
  have hzsq : ‖z‖ ^ 2 = (v : ℝ) := by
    rw [quadraticPoint_norm_sq 1 r s (by norm_num)]
    have hh : (v : ℝ) = (r : ℝ) ^ 2 + (s : ℝ) ^ 2 := by exact_mod_cast (by simpa using hcomp)
    simpa only [Int.cast_one, one_mul] using hh.symm
  have hz : z ≠ 0 := by
    intro hh
    rw [hh, norm_zero, zero_pow (by decide)] at hzsq
    have hvR : (0 : ℝ) < v := by exact_mod_cast hvpos
    linarith
  refine ⟨X, ν, r, s, τ, hx, hνunit, hτ, hz, ?_, ?_⟩
  · have hh := congrArg (fun a : ℝ => a ^ 2) hzsq
    rw [hv]
    push_cast
    simpa only [z, ← pow_mul, show (2 : ℕ) * 2 = 4 by rfl] using hh
  · have hS0 : squarefreePart Q.normAlpha ≤ 0 := by change squarefreePart P.normAlpha ≤ 0; omega
    have hh := congrArg (imaginaryEmbedding (squarefreePart Q.normAlpha) hS0) hF.1
    rw [map_mul, map_pow] at hh
    have hνR : (ν : ℝ) = (Q.epsilonNorm : ℝ) := by exact_mod_cast hν
    rw [Section4.gaussian_U]
    convert hh using 1
    · apply Complex.ext <;>
        simp [imaginaryEmbedding, hQN, hS, ← hνR]
    · have ha : P.complexAlpha =
          imaginaryEmbedding (squarefreePart Q.normAlpha) hS0
            (⟨(Q.a : ℚ), (squareFactor Q.normAlpha : ℚ)⟩) := by
        apply Complex.ext <;> simp [complexAlpha, negativeNormRoot, imaginaryEmbedding, hQN]
        rfl
      have hz' : quadraticPoint 1 r s =
          imaginaryEmbedding (squarefreePart Q.normAlpha) hS0 (⟨(r : ℚ), (s : ℚ)⟩) := by
        apply Complex.ext <;> simp [quadraticPoint, imaginaryEmbedding, hQN, hS]
      rw [ha, hz']

end «JNT-2024».Parameters
