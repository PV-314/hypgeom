module

public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

/-- The numerical cutoff in the proof of Lemma 2.3(a), certified by a finite
Taylor lower bound for the exponential. This does not assume any denominator estimate. -/
theorem lemma23a_exponential_crossover {r : ℕ} (hr : 139 ≤ r) :
    100 * Real.exp ((327 / 200 : ℝ) * r) <
      (1 / 5 : ℝ) * Real.exp ((42 / 25 : ℝ) * r) := by
  have hseries := Real.sum_le_exp_of_nonneg (by norm_num : (0 : ℝ) ≤ 1251 / 200) 18
  have hn : (500 : ℝ) < ∑ i ∈ Finset.range 18, (1251 / 200 : ℝ) ^ i / i.factorial := by
    norm_num [Finset.sum_range_succ]
  have harg : (1251 / 200 : ℝ) ≤ (9 / 200 : ℝ) * r := by
    have hr' : (139 : ℝ) ≤ r := by exact_mod_cast hr
    linarith
  have he : 500 < Real.exp ((9 / 200 : ℝ) * r) :=
    lt_of_lt_of_le (lt_of_lt_of_le hn hseries) (Real.exp_le_exp.mpr harg)
  have hm := mul_lt_mul_of_pos_left he (Real.exp_pos ((327 / 200 : ℝ) * r))
  rw [show (42 / 25 : ℝ) * r = (327 / 200 : ℝ) * r + (9 / 200 : ℝ) * r by ring,
    Real.exp_add]
  nlinarith only [hm]

theorem lemma23a_scaled_crossover {r : ℕ} (hr : 139 ≤ r) {M : ℝ} (hM : 0 < M) :
    100 * (Real.exp (327 / 200) / M) ^ r <
      (1 / 5 : ℝ) * (Real.exp (42 / 25) / M) ^ r := by
  have hh : 100 * Real.exp (327 / 200) ^ r < (1 / 5 : ℝ) * Real.exp (42 / 25) ^ r := by
    simpa only [← Real.exp_nat_mul, mul_comm (r : ℝ)] using lemma23a_exponential_crossover hr
  have hm := mul_lt_mul_of_pos_right hh (inv_pos.mpr (pow_pos hM r))
  simpa only [div_pow, div_eq_mul_inv, mul_pow, inv_pow, mul_assoc] using hm

/-- The large-index reduction used in Lemma 2.3(a). The estimate cited from [17]
remains an explicit hypothesis, not an axiom or a proved denominator bound. -/
theorem lemma23a_large_of_prior_bound {r : ℕ} (hr : 139 ≤ r)
    {A B M : ℝ} (hM : 0 < M)
    (hPrior : max A (4 * B) < 100 * (Real.exp (327 / 200) / M) ^ r) :
    A < (293 / 250 : ℝ) * (Real.exp (42 / 25) / M) ^ r ∧
    B < (537 / 2000 : ℝ) * (Real.exp (42 / 25) / M) ^ r := by
  have hh := lt_trans hPrior (lemma23a_scaled_crossover hr hM)
  have ha := lt_of_le_of_lt (le_max_left A (4 * B)) hh
  have hb := lt_of_le_of_lt (le_max_right A (4 * B)) hh
  have hp : 0 < (Real.exp (42 / 25) / M) ^ r := pow_pos (div_pos (Real.exp_pos _) hM) r
  constructor <;> nlinarith

end Hypergeometric
end «JNT-2024»
