module

public import «JNT-2024».Monotonicity
public import «JNT-2024».NegativeCutoff
public import «JNT-2024».Sequence
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.Deriv.MeanValue
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- All four printed families, including their alpha/epsilon identities and
norms. Table 1's norm -3 row is excluded by the square-norm hypothesis. -/
theorem lemma51_cases_published (P : Parameters) (h : P.Admissible)
    (hb : P.b=1) (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha))
    {K : ℤ} (hK : P.IsNegativeCutoff h.pell K) (hK1 : K < -1) :
    (P.d=P.a^2+4 ∧ P.t=P.a ∧ P.u=1 ∧ P.alpha=2*P.epsilon ∧ P.normAlpha= -4) ∨
    (P.d=P.a^2+1 ∧ P.t=2*P.a ∧ P.u=2 ∧ P.alpha=P.epsilon ∧ P.normAlpha= -1) ∨
    (P.a=2 ∧ P.d=5 ∧ P.t=3 ∧ P.u=1 ∧ P.alpha^2=P.epsilon^3 ∧ P.normAlpha= -1) ∨
    (P.a=2 ∧ P.d=5 ∧ P.t=1 ∧ P.u=1 ∧ P.alpha=P.epsilon^3 ∧ P.normAlpha= -1) := by
  have hc : P.LowNeighborCases := by
    apply P.low_neighbor_cases_of_le_one h hb hn
    simpa [hb] using hK.2.2 (-1) hK1 (by norm_num)
  rcases hc with ⟨hd,ht,hu⟩ | ⟨hd,ht,hu⟩ | ⟨ha,hd,ht,hu⟩ |
    ⟨ha,hd,ht,hu⟩ | ⟨ha,hd,ht,hu⟩
  · refine Or.inl ⟨hd,ht,hu,?_,?_⟩
    · rw [two_mul]
      ext <;> simp [alpha,epsilon,hb,ht,hu]
      ring
    · simp [normAlpha,hb,hd]
  · refine Or.inr (Or.inl ⟨hd,ht,hu,?_,?_⟩)
    · ext <;> simp [alpha,epsilon,hb,ht,hu]
    · simp [normAlpha,hb,hd]
  · exact ((show ¬ IsSquare (3:ℤ) by decide +kernel) (by simpa [normAlpha,hb,ha,hd] using hNs)).elim
  · refine Or.inr (Or.inr (Or.inl ⟨ha,hd,ht,hu,?_,?_⟩))
    · ext <;> norm_num [alpha,epsilon,hb,ha,hd,ht,hu,pow_succ]
    · norm_num [normAlpha,hb,ha,hd]
  · refine Or.inr (Or.inr (Or.inr ⟨ha,hd,ht,hu,?_,?_⟩))
    · ext <;> norm_num [alpha,epsilon,hb,ha,hd,ht,hu,pow_succ]
    · norm_num [normAlpha,hb,ha,hd]


end «JNT-2024».Parameters
