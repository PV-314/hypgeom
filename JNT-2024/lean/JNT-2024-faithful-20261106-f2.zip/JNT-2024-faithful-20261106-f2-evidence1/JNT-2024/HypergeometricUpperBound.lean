module

public import «JNT-2024».HypergeometricPolynomials
public import «JNT-2024».HypergeometricRecurrence
public import «JNT-2024».UnitCircleGeometry
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

noncomputable def normalizingFactor (ν : ℚ) (r : ℕ) : ℝ :=
  (r.factorial : ℝ) / (risingQ (1 - ν) r : ℝ)

theorem normalizingFactor_pos {ν : ℚ} (hν : ν < 1) (r : ℕ) : 0 < normalizingFactor ν r := by
  have hh : (0 : ℚ) < risingQ (1 - ν) r := by
    rw [risingQ_eq_pochhammer]
    exact ascPochhammer_pos _ _ (by linarith)
  have hh' : (0 : ℝ) < (risingQ (1 - ν) r : ℝ) := by exact_mod_cast hh
  exact div_pos (by positivity) hh'

theorem normalizingFactor_zero (ν : ℚ) : normalizingFactor ν 0 = 1 := by
  simp [normalizingFactor, risingQ]

theorem normalizingFactor_succ (ν : ℚ) (r : ℕ) :
    normalizingFactor ν (r + 1) = normalizingFactor ν r * (r + 1) / (r + 1 - ν) := by
  simp only [normalizingFactor, Nat.factorial_succ, Nat.cast_mul, Nat.cast_add,
    Nat.cast_one, risingQ_succ, Rat.cast_mul, Rat.cast_add, Rat.cast_sub,
    Rat.cast_one, Rat.cast_natCast]
  rw [show 1 - (ν : ℝ) + r = r + 1 - ν by ring]
  simp only [div_eq_mul_inv, mul_inv_rev]
  ring

theorem normalizingFactor_eq_gamma {ν : ℚ} (hν : ν < 1) (r : ℕ) :
    normalizingFactor ν r =
      (r.factorial : ℝ) * Real.Gamma (1 - ν) / Real.Gamma (r + 1 - ν) := by
  have hv : (ν : ℝ) < 1 := by exact_mod_cast hν
  induction r with
  | zero =>
    have hg := ne_of_gt (Real.Gamma_pos_of_pos (by linarith : (0 : ℝ) < 1 - ν))
    simp [normalizingFactor_zero, hg]
  | succ r ih =>
    have hp : (0 : ℝ) < r + 1 - ν := by have := Nat.cast_nonneg (α := ℝ) r; linarith
    rw [show ((r + 1 : ℕ) : ℝ) + 1 - ν = ((r : ℝ) + 1 - ν) + 1 by push_cast; ring,
      Real.Gamma_add_one (ne_of_gt hp), normalizingFactor_succ, ih, Nat.factorial_succ]
    push_cast
    simp only [div_eq_mul_inv, mul_inv_rev]
    ring

theorem normalizingFactor_comparison {ν : ℚ} (hν : ν < 1) (r : ℕ) :
    (r + 1 + (ν : ℝ)) * normalizingFactor ν r ≤
      (r + 1) * normalizingFactor ν (r + 1) := by
  have hv : (ν : ℝ) < 1 := by exact_mod_cast hν
  have hp : (0 : ℝ) < r + 1 - ν := by have := Nat.cast_nonneg (α := ℝ) r; linarith
  rw [normalizingFactor_succ, ← mul_div_assoc]
  apply (le_div_iff₀ hp).mpr
  have := mul_nonneg (sq_nonneg (ν : ℝ)) (normalizingFactor_pos hν r).le
  nlinarith

theorem unit_circle_norm_identity {z : ℂ} (hz : ‖z‖ = 1) :
    ‖1 + z‖ ^ 2 + ‖1 - z‖ ^ 2 = 4 := by
  have hh : z.re ^ 2 + z.im ^ 2 = 1 := by
    simpa [Complex.normSq_apply, pow_two, hz] using Complex.normSq_eq_norm_sq z
  simp only [← Complex.normSq_eq_norm_sq, Complex.normSq_apply, Complex.add_re,
    Complex.add_im, Complex.sub_re, Complex.sub_im, Complex.one_re, Complex.one_im]
  nlinarith

theorem norm_X_one_le {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1) {z : ℂ} (hz : ‖z‖ = 1) :
    ‖X ν 1 z‖ ≤ 2 * normalizingFactor ν 1 := by
  have hv₀ : (0 : ℝ) < ν := by exact_mod_cast hν₀
  have hv₁ : (ν : ℝ) < 1 := by exact_mod_cast hν₁
  have he : X ν 1 z = 1 + ((1 + (ν : ℝ)) / (1 - ν) : ℝ) * z := by
    simp [X, Finset.sum_range_succ, coefficient_zero, coefficient_one]
  rw [he]
  calc
    _ ≤ ‖(1 : ℂ)‖ + ‖(((1 + (ν : ℝ)) / (1 - ν) : ℝ) : ℂ) * z‖ := norm_add_le _ _
    _ = 1 + (1 + (ν : ℝ)) / (1 - ν) := by
      rw [norm_mul, hz, Complex.norm_real, Real.norm_eq_abs, abs_of_pos (by positivity)]
      simp
    _ = _ := by rw [normalizingFactor_succ, normalizingFactor_zero]; norm_num; field_simp; ring

/-- A stronger non-strict bound than Lemma 2.2(d), obtained from the recurrence. -/
theorem norm_X_le {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1) (r : ℕ)
    {z : ℂ} (hz : ‖z‖ = 1) :
    ‖X ν r z‖ ≤ normalizingFactor ν r * (2 + ‖1 + z‖) ^ r := by
  have hv₀ : (0 : ℝ) < ν := by exact_mod_cast hν₀
  have hv₁ : (ν : ℝ) < 1 := by exact_mod_cast hν₁
  let L : ℝ := 2 + ‖1 + z‖
  have hL : 0 < L := by dsimp [L]; positivity
  have hLid : L ^ 2 = 2 * ‖1 + z‖ * L + ‖1 - z‖ ^ 2 := by
    dsimp [L]
    nlinarith [unit_circle_norm_identity hz]
  change ‖X ν r z‖ ≤ normalizingFactor ν r * L ^ r
  induction r using Nat.twoStepInduction with
  | zero => simp [X, coefficient_zero, normalizingFactor_zero]
  | one =>
    calc
      _ ≤ 2 * normalizingFactor ν 1 := norm_X_one_le hν₀ hν₁ hz
      _ ≤ _ := by dsimp [L]; nlinarith [normalizingFactor_pos hν₁ 1, norm_nonneg (1 + z)]
  | more r ih₀ ih₁ =>
    have hr : (0 : ℝ) < r + 2 - ν := by have := Nat.cast_nonneg (α := ℝ) r; linarith
    have hrec := congrArg norm (X_recurrence hν₀ hν₁ r z)
    have hbound : (r + 2 - (ν : ℝ)) * ‖X ν (r + 2) z‖ ≤
        (2 * r + 3) * ‖1 + z‖ * ‖X ν (r + 1) z‖ +
        (r + 1 + ν) * ‖1 - z‖ ^ 2 * ‖X ν r z‖ := by
      have ht := norm_sub_le ((2 * (r : ℂ) + 3) * (1 + z) * X ν (r + 1) z)
        ((r + 1 + ν) * (1 - z) ^ 2 * X ν r z)
      rw [← hrec] at ht
      have ha : ‖(r : ℂ) + 2 - ν‖ = r + 2 - (ν : ℝ) := by
        have he : (r : ℂ) + 2 - ν = (((r : ℝ) + 2 - ν : ℝ) : ℂ) := by push_cast; rfl
        rw [he, Complex.norm_real, Real.norm_eq_abs, abs_of_pos hr]
      have hb : ‖2 * (r : ℂ) + 3‖ = 2 * (r : ℝ) + 3 := by
        have he : 2 * (r : ℂ) + 3 = ((2 * (r : ℝ) + 3 : ℝ) : ℂ) := by push_cast; rfl
        rw [he, Complex.norm_real, Real.norm_eq_abs, abs_of_pos (by positivity)]
      have hc : ‖(r : ℂ) + 1 + ν‖ = r + 1 + (ν : ℝ) := by
        have he : (r : ℂ) + 1 + ν = (((r : ℝ) + 1 + ν : ℝ) : ℂ) := by push_cast; rfl
        rw [he, Complex.norm_real, Real.norm_eq_abs, abs_of_pos (by positivity)]
      simpa only [norm_mul, norm_pow, ha, hb, hc] using ht
    have hG := normalizingFactor_comparison hν₁ r
    have hstep : (r + 2 - (ν : ℝ)) * normalizingFactor ν (r + 2) =
        (r + 2) * normalizingFactor ν (r + 1) := by
      rw [show r + 2 = (r + 1) + 1 by omega, normalizingFactor_succ]
      push_cast
      rw [show (r : ℝ) + 1 + 1 = r + 2 by ring]
      field_simp
    apply (mul_le_mul_iff_right₀ hr).mp
    calc
      _ ≤ _ := hbound
      _ ≤ (2 * r + 3) * ‖1 + z‖ * (normalizingFactor ν (r + 1) * L ^ (r + 1)) +
          (r + 1 + ν) * ‖1 - z‖ ^ 2 * (normalizingFactor ν r * L ^ r) := by
        gcongr
      _ ≤ (2 * r + 3) * ‖1 + z‖ * (normalizingFactor ν (r + 1) * L ^ (r + 1)) +
          (r + 1) * ‖1 - z‖ ^ 2 * (normalizingFactor ν (r + 1) * L ^ r) := by
        have hm := mul_le_mul_of_nonneg_right hG (by positivity : 0 ≤ ‖1 - z‖ ^ 2 * L ^ r)
        nlinarith only [hm]
      _ ≤ (r + 2) * normalizingFactor ν (r + 1) * L ^ (r + 2) := by
        rw [pow_add L r 2, pow_succ L r, hLid]
        have hGp := normalizingFactor_pos hν₁ (r + 1)
        have h₁ : 0 ≤ normalizingFactor ν (r + 1) * L ^ r * ‖1 + z‖ * L := by positivity
        have h₂ : 0 ≤ normalizingFactor ν (r + 1) * L ^ r * ‖1 - z‖ ^ 2 := by positivity
        nlinarith only [h₁, h₂]
      _ = _ := by rw [← hstep]; ring


/-- Lemma 2.2(d), including the strict printed constant; the disk restriction is unnecessary. -/
theorem lemma22d_unitCircle {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1 / 2) (r : ℕ)
    {ω : ℂ} (hω : ‖ω‖ = 1) :
    ‖X ν r ω‖ = ‖Y ν r ω‖ ∧
    ‖Y ν r ω‖ < (134 / 125 : ℝ) *
      ((r.factorial : ℝ) * Real.Gamma (1 - ν) / Real.Gamma (r + 1 - ν)) *
      ‖1 + principalSquareRoot ω‖ ^ (2 * r) := by
  have hv : ν < 1 := by linarith
  have he := norm_X_eq_norm_Y ν r hω
  refine ⟨he, ?_⟩
  rw [← he, ← normalizingFactor_eq_gamma hv, pow_mul, principalSquareRoot_chord hω]
  have hb := norm_X_le hν₀ hv r hω
  have hp : 0 < normalizingFactor ν r * (2 + ‖1 + ω‖) ^ r :=
    mul_pos (normalizingFactor_pos hv r) (pow_pos (by positivity) r)
  nlinarith only [hb, hp]

/-- The printed Lemma 2.2(d). Downstream paper proofs use this interface and `1.072`. -/
theorem lemma22d {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1 / 2) (r : ℕ)
    {ω : ℂ} (hω : ‖ω‖ = 1) (_hnear : ‖ω - 1‖ < 1) :
    ‖X ν r ω‖ = ‖Y ν r ω‖ ∧
    ‖Y ν r ω‖ < (134 / 125 : ℝ) *
      ((r.factorial : ℝ) * Real.Gamma (1 - ν) / Real.Gamma (r + 1 - ν)) *
      ‖1 + principalSquareRoot ω‖ ^ (2 * r) :=
  lemma22d_unitCircle hν₀ hν₁ r hω

end Hypergeometric
end «JNT-2024»
