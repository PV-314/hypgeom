module

public import «JNT-2024».NormalizerBounds
public import «JNT-2024».Proposition41
public import «JNT-2024».Section4Sequence
public import «JNT-2024».Sequence
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- A division-free sufficient condition for exceeding the published cutoff. -/
theorem section5_above_cutoff (P : Parameters) (h : P.Admissible) (hb : P.b = 1)
    (hn : P.normAlpha < 0) {y : ℝ} (hy : 1 < y)
    (hbound : 137 * |(P.normAlpha : ℝ)| ≤ P.normalizerSquare * y) :
    P.proposition41Threshold < y := by
  have hN := P.section4_norm_range h hb hn
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hc : Int.gcd P.a P.b = 1 := by simp [hb]
  have hB : (0 : ℝ) < P.normalizerSquare := by
    exact_mod_cast (by have hh := (P.normalizerSquare_bounds h hc (ne_of_lt hn)).2.1; omega : 0 < P.normalizerSquare)
  apply max_lt hy
  apply (div_lt_iff₀ (mul_pos (Real.sqrt_pos.mpr hd) hB)).mpr
  have hs := Real.sqrt_lt_sqrt hN.1.le hN.2
  have hl := mul_lt_mul_of_pos_left hs (mul_pos (by norm_num : (0 : ℝ) < 137) hN.1)
  have hu := mul_le_mul_of_nonneg_right hbound (Real.sqrt_nonneg (P.d : ℝ))
  nlinarith only [hl, hu]


/-- The printed lower bound `M≥4` when `4∣Nα`, in squared form. -/
theorem section5_normalizer_ge_sixteen (P : Parameters) (h : P.Admissible) (hb : P.b = 1)
    (hn : P.normAlpha ≠ 0) (h4 : 4 ∣ P.normAlpha) : 16 ≤ P.normalizerSquare := by
  have hv : 2 ≤ padicValInt 2 P.normAlpha := by
    have hh := (padicValInt_dvd_iff (p := 2) 2 P.normAlpha).mp (by simpa using h4)
    exact hh.resolve_left hn
  have hp : (4 : ℕ) ≤ 2 ^ min 4 (padicValInt 2 P.normAlpha) := by
    calc
      4 = 2 ^ 2 := by norm_num
      _ ≤ _ := Nat.pow_le_pow_right (by decide) (by omega)
  have hh := (P.normalizerSquare_bounds h (by simp [hb]) hn).1
  omega


end «JNT-2024».Parameters
