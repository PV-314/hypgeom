module

public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- The square root with the argument convention fixed in Section 2.1. -/
noncomputable def principalSquareRoot (ω : ℂ) : ℂ :=
  Complex.exp (Complex.I * (ω.arg / 2 : ℝ))

theorem principalSquareRoot_norm (ω : ℂ) : ‖principalSquareRoot ω‖ = 1 :=
  Complex.norm_exp_I_mul_ofReal _

theorem principalSquareRoot_sq {ω : ℂ} (hω : ‖ω‖ = 1) : principalSquareRoot ω ^ 2 = ω := by
  rw [principalSquareRoot, ← Complex.exp_nat_mul]
  have he := Complex.norm_mul_exp_arg_mul_I ω
  rw [hω, Complex.ofReal_one, one_mul] at he
  convert he using 1
  congr 1
  push_cast
  ring

theorem principalSquareRoot_re_nonneg (ω : ℂ) : 0 ≤ (principalSquareRoot ω).re := by
  have hl := Complex.neg_pi_lt_arg ω
  have hu := Complex.arg_le_pi ω
  have hh : 0 ≤ Real.cos (ω.arg / 2) :=
    Real.cos_nonneg_of_mem_Icc ⟨by linarith, by linarith⟩
  simpa [principalSquareRoot, Complex.exp_re] using hh

theorem principalSquareRoot_chord {ω : ℂ} (hω : ‖ω‖ = 1) :
    ‖1 + principalSquareRoot ω‖ ^ 2 = 2 + ‖1 + ω‖ := by
  let w := principalSquareRoot ω
  have hw : w.re ^ 2 + w.im ^ 2 = 1 := by
    simpa [Complex.normSq_apply, pow_two, principalSquareRoot_norm, w] using Complex.normSq_eq_norm_sq w
  have hz : ω.re ^ 2 + ω.im ^ 2 = 1 := by
    simpa [Complex.normSq_apply, pow_two, hω] using Complex.normSq_eq_norm_sq ω
  have hs : w.re ^ 2 - w.im ^ 2 = ω.re := by
    have hh := congrArg Complex.re (principalSquareRoot_sq hω)
    simpa [pow_two, Complex.mul_re, w] using hh
  have hc : ‖1 + ω‖ ^ 2 = 4 * w.re ^ 2 := by
    simp only [← Complex.normSq_eq_norm_sq, Complex.normSq_apply, Complex.add_re,
      Complex.add_im, Complex.one_re, Complex.one_im]
    nlinarith
  have hn : ‖1 + ω‖ = 2 * w.re := by
    nlinarith [norm_nonneg (1 + ω), principalSquareRoot_re_nonneg ω]
  change ‖1 + w‖ ^ 2 = _
  rw [hn]
  simp only [← Complex.normSq_eq_norm_sq, Complex.normSq_apply, Complex.add_re,
    Complex.add_im, Complex.one_re, Complex.one_im]
  nlinarith

end «JNT-2024»
