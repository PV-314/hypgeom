module

public import «JNT-2024».RepresentationFactors
public import «JNT-2024».RepresentationNormalization
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

theorem valuation_neg (p : ℕ) (a : ℤ) : padicValInt p (-a) = padicValInt p a := by
  simp only [padicValInt, Int.natAbs_neg]


theorem odd_of_valuation_two_zero {a : ℤ} (ha : a ≠ 0) (hv : padicValInt 2 a = 0) : Odd a := by
  apply Int.not_even_iff_odd.mp
  intro he
  have hp := (prime_dvd_iff_valuation_pos 2 ha).mp (even_iff_two_dvd.mp he)
  omega

theorem normalized_coefficient_dvd_square {b r f σ R : ℤ}
    (hb : b ≠ 0) (hr : r ≠ 0) (hf : f ≠ 0) (hR : R ≠ 0) (hσ : σ = 1 ∨ σ = -1)
    (he : σ * 4 * b ^ 2 * r = (normalizationGcd b r : ℤ) ^ 2 * f)
    (hv : ∀ p : ℕ, p.Prime → padicValRat p (normalizationQuotient b r) ≤ padicValInt p R)
    (h2 : padicValInt 2 f ≤ padicValInt 2 (b ^ 2 * R)) : f ∣ b ^ 2 * R := by
  apply int_dvd_of_valuation_le hf (mul_ne_zero (pow_ne_zero _ hb) hR)
  intro p hp
  by_cases hp2 : p = 2
  · simpa only [hp2] using h2
  let : Fact p.Prime := ⟨hp⟩
  have hh := normalized_coefficient_valuation p hb hr hσ he
  rw [valuation_four_mul_square p hb, valuation_two_eq_zero hp2] at hh
  have hv' := hv p hp
  rw [padicValInt.mul (pow_ne_zero _ hb) hR, valuation_int_pow]
  omega

namespace Parameters

/-- The radical in Proposition 3.1(b). -/
noncomputable def normRadical (P : Parameters) (ν : ℤ) : ℤ :=
  UniqueFactorizationMonoid.radical (Int.gcd (P.u * P.normAlpha) ν : ℤ)


/-- The signed first identity allowed in Proposition 3.1(b), with the same companion identity. -/
def SignedFourthPowerRepresentation (P : Parameters) (x y f r s τ : ℤ) : Prop :=
  ((τ : ℚ) * (f : ℚ) ^ 2) •
      (⟨(x : ℚ), P.epsilonNorm * squareFactor P.normAlpha⟩ : P.SquarefreeNormAlgebra) =
      (⟨(P.a : ℚ), (squareFactor P.normAlpha : ℚ)⟩ : P.SquarefreeNormAlgebra) *
        (⟨(r : ℚ), (s : ℚ)⟩ : P.SquarefreeNormAlgebra) ^ 4 ∧
    f * y = P.b * (r ^ 2 - squarefreePart P.normAlpha * s ^ 2)

theorem FourthPowerRepresentation.signed {P : Parameters} {x y f r s : ℤ}
    (h : P.FourthPowerRepresentation x y f r s) : P.SignedFourthPowerRepresentation x y f r s 1 := by
  simpa only [SignedFourthPowerRepresentation, FourthPowerRepresentation, Int.cast_one, one_mul] using h

/-- Division by `1+i` halves `f` and changes the sign of the first identity. -/
theorem gaussian_halving (P : Parameters) {x y f r s : ℤ}
    (hS : squarefreePart P.normAlpha = -1)
    (h : P.FourthPowerRepresentation x y (2 * f) (r - s) (r + s)) :
    P.SignedFourthPowerRepresentation x y f r s (-1) := by
  obtain ⟨hpow, hnorm⟩ := h
  let J : P.SquarefreeNormAlgebra := ⟨1, 1⟩
  let z : P.SquarefreeNormAlgebra := ⟨(r : ℚ), (s : ℚ)⟩
  have hJ : J ^ 4 = (-4 : ℚ) • (1 : P.SquarefreeNormAlgebra) := by
    dsimp [J]
    ext <;> simp only [pow_succ, pow_zero, QuadraticAlgebra.re_mul, QuadraticAlgebra.im_mul,
      QuadraticAlgebra.re_one, QuadraticAlgebra.im_one, QuadraticAlgebra.re_smul, QuadraticAlgebra.im_smul]
      <;> norm_num [hS]
  have hz : (⟨((r - s : ℤ) : ℚ), ((r + s : ℤ) : ℚ)⟩ : P.SquarefreeNormAlgebra) = J * z := by
    dsimp [J, z]
    ext <;> simp [hS] <;> ring
  rw [hz, mul_pow, hJ, smul_mul_assoc, one_mul, mul_smul_comm] at hpow
  have hf : (((2 * f : ℤ) : ℚ) ^ 2) = 4 * (f : ℚ) ^ 2 := by push_cast; ring
  rw [hf] at hpow
  have hh := congrArg (fun w : P.SquarefreeNormAlgebra => (-1 / 4 : ℚ) • w) hpow
  simp only [smul_smul] at hh
  have hc : (-1 / 4 : ℚ) * (4 * (f : ℚ) ^ 2) = -1 * (f : ℚ) ^ 2 := by ring
  have hd : (-1 / 4 : ℚ) * (-4) = 1 := by norm_num
  rw [hc, hd, one_smul] at hh
  constructor
  · exact hh
  · rw [hS] at hnorm ⊢
    nlinarith only [hnorm]


end Parameters
end «JNT-2024»
