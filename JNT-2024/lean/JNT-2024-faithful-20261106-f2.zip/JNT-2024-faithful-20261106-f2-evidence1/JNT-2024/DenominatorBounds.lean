module

public import «JNT-2024».DenominatorContent
public import «JNT-2024».DenominatorDefinitions
public import «JNT-2024».DenominatorEstimateReduction
public import «JNT-2024».DenominatorFinite
public import «JNT-2024».DenominatorSearchReduction
public import «JNT-2024».GammaBounds
public import «JNT-2024».HypergeometricPolynomials
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»
namespace Hypergeometric

/-- `N_{d,4} = 2 ^ min(v₂(d)/2,3)`, expressed without a fractional exponent. -/
noncomputable def twoAdicScale4 (d : ℤ) : ℝ :=
  Real.sqrt ((2 : ℝ) ^ min (padicValInt 2 d) 6)

theorem twoAdicScale4_eq_rpow (d : ℤ) :
    twoAdicScale4 d = (2 : ℝ) ^ min ((padicValInt 2 d : ℝ) / 2) 3 := by
  rw [twoAdicScale4, Real.sqrt_eq_rpow, ← Real.rpow_natCast,
    ← Real.rpow_mul (by norm_num : (0 : ℝ) ≤ 2)]
  congr 1
  rw [mul_one_div, Nat.cast_min, ← min_div_div_right (by norm_num : (0 : ℝ) ≤ 2)]
  norm_num

theorem twoAdicScale4_pos (d : ℤ) : 0 < twoAdicScale4 d := by
  exact Real.sqrt_pos.mpr (by positivity)

theorem twoAdicScale4_sq (d : ℤ) :
    twoAdicScale4 d ^ 2 = (2 : ℝ) ^ min (padicValInt 2 d) 6 := by
  exact Real.sq_sqrt (by positivity)

/-- The scale depends only on the 2-adic valuation, as used on page 7. -/
theorem twoAdicScale4_eq_of_valuation_eq {a b : ℤ}
    (h : padicValInt 2 a = padicValInt 2 b) : twoAdicScale4 a = twoAdicScale4 b := by
  simp only [twoAdicScale4, h]

theorem twoAdicScale4_saturated {d : ℤ} (hd : 6 ≤ padicValInt 2 d) :
    twoAdicScale4 d = 8 := by
  have hs := twoAdicScale4_sq d
  rw [min_eq_right hd] at hs
  have hp := twoAdicScale4_pos d
  norm_num at hs
  nlinarith

/-- The representative with exponent capped at six has exactly the same scale. -/
theorem twoAdicScale4_capped_two_part (d : ℤ) :
    twoAdicScale4 ((2 : ℤ) ^ min (padicValInt 2 d) 6) = twoAdicScale4 d := by
  simp [twoAdicScale4, padicValInt]

/-- Literal finite-domain reduction in Lemma 2.3(a). Both Gamma numerators
are positive, so the same seven representatives work for both inequalities. -/
theorem lemma23a_finite_domain_reduction {d : ℤ} (hd : d ≠ 0) (r : ℕ)
    {A : ℝ} (hA : 0 ≤ A) :
    ∃ e : Fin 7,
      twoAdicScale4 ((2 : ℤ) ^ e.val) = twoAdicScale4 d ∧
      A / numeratorContent4 d r ≤ A / numeratorContent4 ((2 : ℤ) ^ e.val) r := by
  refine ⟨⟨min (padicValInt 2 d) 6, by omega⟩, twoAdicScale4_capped_two_part d, ?_⟩
  apply div_le_div_of_nonneg_left hA
    (by exact_mod_cast numeratorContent4_pos ((2 : ℤ) ^ min (padicValInt 2 d) 6) r)
  exact_mod_cast numeratorContent4_capped_two_part_le hd r

/-- The two left-hand sides at `r=0`: the first is one and the second a
quarter. There is no extra factor four in the second printed inequality. -/
theorem lemma23a_zero_values (d : ℤ) :
    gammaRatio 0 * denominator4 0 / numeratorContent4 d 0 = (1 : ℚ) ∧
    gammaNumeratorRatio 0 * denominator4 0 / numeratorContent4 d 0 = (1 / 4 : ℚ) := by
  norm_num [gammaRatio, gammaNumeratorRatio, risingQ, denominator4_zero,
    numeratorContent4_zero]

theorem numeratorContent4_scale_bound {d : ℤ} (hd : d ≠ 0) (r : ℕ) :
    (twoAdicScale4 d ^ r) ^ 2 ≤ (parityLoss r : ℝ) * (numeratorContent4 d r : ℝ) ^ 2 := by
  let e := min (padicValInt 2 d) 6
  have hn : (2 : ℝ) ^ (e * r / 2) ≤ numeratorContent4 d r := by
    exact_mod_cast Nat.le_of_dvd (numeratorContent4_pos d r) (two_pow_dvd_numeratorContent4 hd r)
  have hpar : (2 : ℝ) ^ (e * r % 2) ≤ (parityLoss r : ℝ) := by
    by_cases hr : r % 2 = 0
    · have he : e * r % 2 = 0 := by simp [Nat.mul_mod, hr]
      simp [parityLoss, hr, he]
    · have he : e * r % 2 = 0 ∨ e * r % 2 = 1 := by omega
      rcases he with he | he <;> norm_num [parityLoss, hr, he]
  have hparpos : (0 : ℝ) ≤ parityLoss r := by unfold parityLoss; split <;> norm_num
  calc
    (twoAdicScale4 d ^ r) ^ 2 = (2 : ℝ) ^ (e * r) := by
      rw [pow_right_comm, twoAdicScale4_sq, ← pow_mul]
    _ = 2 ^ (e * r % 2) * (2 ^ (e * r / 2)) ^ 2 := by
      rw [← pow_mul, ← pow_add]
      congr 1
      omega
    _ ≤ (parityLoss r : ℝ) * (numeratorContent4 d r : ℝ) ^ 2 :=
      mul_le_mul hpar (pow_le_pow_left₀ (by positivity) hn 2) (by positivity) hparpos

theorem finite_bound_of_squared_check {r : ℕ} {A C N M : ℝ}
    (hC : 0 < C) (hN : 0 < N) (hM : 0 < M)
    (hscale : (M ^ r) ^ 2 ≤ (parityLoss r : ℝ) * N ^ 2)
    (hcheck : (parityLoss r : ℝ) * A ^ 2 < C ^ 2 *
      (denominatorExponentialLower : ℝ) ^ (2 * r)) :
    A / N < C * (Real.exp (42 / 25) / M) ^ r := by
  have hq : (0 : ℝ) < denominatorExponentialLower := by norm_num [denominatorExponentialLower]
  have h₁ := mul_le_mul_of_nonneg_left hscale (sq_nonneg A)
  have h₂ := mul_lt_mul_of_pos_right hcheck (sq_pos_of_pos hN)
  have hsq : (A * M ^ r) ^ 2 < (C * (denominatorExponentialLower : ℝ) ^ r * N) ^ 2 := by
    rw [mul_comm 2 r, pow_mul] at h₂
    nlinarith only [h₁, h₂]
  have hright : 0 < C * (denominatorExponentialLower : ℝ) ^ r * N := by positivity
  have hlt : A * M ^ r < C * (denominatorExponentialLower : ℝ) ^ r * N := by
    nlinarith only [hsq, hright, sq_nonneg (A * M ^ r - C * (denominatorExponentialLower : ℝ) ^ r * N)]
  have hpow := pow_le_pow_left₀ hq.le denominatorExponentialLower_lt_exp.le r
  have he : A * M ^ r < C * Real.exp (42 / 25) ^ r * N :=
    hlt.trans_le (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hpow hC.le) hN.le)
  rw [div_pow, ← mul_div_assoc, div_lt_div_iff₀ hN (pow_pos hM r)]
  exact he

/-- Both estimates in Lemma 2.3(a), for the complete finite range used in the paper. -/
theorem lemma23a_finite {d : ℤ} (hd : d ≠ 0) {r : ℕ} (hr : r < 139) :
    Real.Gamma (3 / 4) * r.factorial / Real.Gamma ((r : ℝ) + 3 / 4) *
        (denominator4 r : ℝ) / numeratorContent4 d r <
      (293 / 250 : ℝ) * (Real.exp (42 / 25) / twoAdicScale4 d) ^ r ∧
    Real.Gamma ((r : ℝ) + 5 / 4) / (Real.Gamma (1 / 4) * r.factorial) *
        (denominator4 r : ℝ) / numeratorContent4 d r <
      (537 / 2000 : ℝ) * (Real.exp (42 / 25) / twoAdicScale4 d) ^ r := by
  have hh := denominator_finite_certificate ⟨r, hr⟩
  rcases hh with ⟨h₁, h₂⟩
  have hN : (0 : ℝ) < numeratorContent4 d r := by exact_mod_cast numeratorContent4_pos d r
  have ha := finite_bound_of_squared_check (A := (gammaRatio r : ℝ) * denominator4 r)
    (by norm_num : (0 : ℝ) < 293 / 250) hN
    (twoAdicScale4_pos d) (numeratorContent4_scale_bound hd r)
    (by simpa only [Rat.cast_mul, Rat.cast_pow, Rat.cast_div, Rat.cast_ofNat, Rat.cast_natCast]
          using (Rat.cast_lt (K := ℝ)).mpr h₁)
  have hb := finite_bound_of_squared_check (A := (gammaNumeratorRatio r : ℝ) * denominator4 r)
    (by norm_num : (0 : ℝ) < 537 / 2000) hN
    (twoAdicScale4_pos d) (numeratorContent4_scale_bound hd r)
    (by simpa only [Rat.cast_mul, Rat.cast_pow, Rat.cast_div, Rat.cast_ofNat, Rat.cast_natCast]
          using (Rat.cast_lt (K := ℝ)).mpr h₂)
  constructor
  · simpa only [gammaRatio_eq_gamma, mul_comm (r.factorial : ℝ) (Real.Gamma (3 / 4))] using ha
  · simpa only [gammaNumeratorRatio_eq_gamma] using hb

/-- The unresolved arithmetic input from [17], Theorem 2.2(a), Table 1 (`n=4`).
This is a proposition definition, not an axiom or an established theorem.
Only the large-index instances needed for the paper's argument are requested. -/
def DenominatorEstimate4 : Prop :=
  ∀ (d : ℤ), d ≠ 0 → ∀ r : ℕ, 139 ≤ r →
    max ((gammaRatio r : ℝ) * denominator4 r / numeratorContent4 d r)
      (4 * ((gammaNumeratorRatio r : ℝ) * denominator4 r / numeratorContent4 d r)) <
      100 * (Real.exp (327 / 200) / twoAdicScale4 d) ^ r

/-- Full statement of Lemma 2.3(a), with its denominator and content now constructed. -/
def Lemma23a : Prop :=
  ∀ (d : ℤ), d ≠ 0 → ∀ r : ℕ,
    Real.Gamma (3 / 4) * r.factorial / Real.Gamma ((r : ℝ) + 3 / 4) *
        (denominator4 r : ℝ) / numeratorContent4 d r <
      (293 / 250 : ℝ) * (Real.exp (42 / 25) / twoAdicScale4 d) ^ r ∧
    Real.Gamma ((r : ℝ) + 5 / 4) / (Real.Gamma (1 / 4) * r.factorial) *
        (denominator4 r : ℝ) / numeratorContent4 d r <
      (537 / 2000 : ℝ) * (Real.exp (42 / 25) / twoAdicScale4 d) ^ r

/-- The finite part is unconditional; the infinite part still explicitly requires [17]. -/
theorem lemma23a_of_denominatorEstimate4 (hPrior : DenominatorEstimate4) : Lemma23a := by
  intro d hd r
  by_cases hr : r < 139
  · exact lemma23a_finite hd hr
  · have hh := lemma23a_large_of_prior_bound (by omega : 139 ≤ r)
      (twoAdicScale4_pos d) (hPrior d hd r (by omega))
    simpa only [gammaRatio_eq_gamma, gammaNumeratorRatio_eq_gamma,
      mul_comm (r.factorial : ℝ) (Real.Gamma (3 / 4))] using hh

end Hypergeometric
end «JNT-2024»
