module

public import «JNT-2024».ApproximationGcd
public import «JNT-2024».RepresentationValuations
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

theorem valuation_exact_integer_quotient (p : ℕ) [Fact p.Prime] {a b : ℤ}
    (ha : a ≠ 0) (hb : b ≠ 0) (hd : b ∣ a) :
    padicValInt p (a / b) = padicValInt p a - padicValInt p b := by
  have he : b * (a / b) = a := Int.mul_ediv_cancel' hd
  have hq : a / b ≠ 0 := by intro hq; rw [hq, mul_zero] at he; exact ha he.symm
  have hv := padicValInt.mul (p := p) hb hq
  rw [he] at hv
  omega

namespace Approximation

/-- The printed ell_1, computed from g1, with the factor at p=2 retained. -/
theorem g1_square_valuation_published (p : ℕ) [Fact p.Prime] {X C ν : ℤ}
    (hX : X ≠ 0) (hC : C ≠ 0) (hν : ν = 1 ∨ ν = -1) :
    padicValNat p (g1 (2 * X) (2 * ν * C) ^ 2) =
      2 * (padicValNat p 2 + min (padicValInt p X) (padicValInt p C)) := by
  rw [padicValNat.pow, g1_unit X C ν hν,
    padicValNat.mul (by decide) (ne_of_gt (Int.gcd_pos_of_ne_zero_right X hC)),
    valuation_gcd p hX hC]

/-- The printed ell_2 comes from the quotient by g1, not from an assumed bound. -/
theorem g2_valuation_published (p : ℕ) [Fact p.Prime] {S X C ν : ℤ}
    (hS : S ≠ 0) (hX : X ≠ 0) (hC : C ≠ 0) (hν : ν = 1 ∨ ν = -1) :
    padicValNat p (g2 S (2 * X) (2 * ν * C)) =
      min (padicValInt p X - min (padicValInt p X) (padicValInt p C)) (padicValInt p S) := by
  have hg : (Int.gcd X C : ℤ) ≠ 0 := by exact_mod_cast ne_of_gt (Int.gcd_pos_of_ne_zero_right X hC)
  have hd := Int.gcd_dvd_left X C
  have hq : X / (Int.gcd X C : ℤ) ≠ 0 := by
    intro he
    have hh := Int.mul_ediv_cancel' hd
    rw [he, mul_zero] at hh
    exact hX hh.symm
  rw [g2_unit S X C ν hν, valuation_gcd p hq hS,
    valuation_exact_integer_quotient p hX hg hd, padicValInt.of_nat, valuation_gcd p hX hC]


theorem g3_valuation_odd_published (p : ℕ) [Fact p.Prime] (hp : p ≠ 2) (S u₁ u₂ : ℤ) :
    padicValNat p (g3 S u₁ u₂) = 0 := by
  rcases g3_cases S u₁ u₂ with he | he | he
  · simp [he]
  · rw [he]; exact padicValNat_primes hp
  · rw [he, show 4 = 2 ^ 2 by decide, padicValNat.pow, padicValNat_primes hp, mul_zero]

/-- The decomposition ell=ell_1+ell_2-v_p(g3), valid also when X=0. -/
theorem gSquared_valuation_published (p : ℕ) [Fact p.Prime] {S u₁ u₂ : ℤ}
    (hS : S ≠ 0) (hu₂ : u₂ ≠ 0) :
    padicValRat p (gSquared S u₁ u₂) =
      (padicValNat p (g1 u₁ u₂ ^ 2) : ℤ) + padicValNat p (g2 S u₁ u₂) -
        padicValNat p (g3 S u₁ u₂) := by
  have h₁ : (g1 u₁ u₂ : ℚ) ≠ 0 := by exact_mod_cast ne_of_gt (Int.gcd_pos_of_ne_zero_right u₁ hu₂)
  have h₂ : (g2 S u₁ u₂ : ℚ) ≠ 0 := by exact_mod_cast ne_of_gt (Int.gcd_pos_of_ne_zero_right _ hS)
  have h₃ : (g3 S u₁ u₂ : ℚ) ≠ 0 := by exact_mod_cast ne_of_gt (g3_pos S u₁ u₂)
  rw [gSquared, padicValRat.div (mul_ne_zero (pow_ne_zero _ h₁) h₂) h₃,
    padicValRat.mul (pow_ne_zero _ h₁) h₂, padicValRat.pow,
    padicValRat.of_nat, padicValRat.of_nat, padicValRat.of_nat, padicValNat.pow]
  push_cast
  ring

/-- Zero-coordinate case: the gcd definitions give finite values directly,
so no finite-valued convention for v_p(0) is used in the printed minimum. -/
theorem normalizer_zero_coordinate (S C ν : ℤ) (hν : ν = 1 ∨ ν = -1) :
    g1 (2 * 0) (2 * ν * C) = 2 * C.natAbs ∧
    g2 S (2 * 0) (2 * ν * C) = S.natAbs := by
  rw [g1_unit 0 C ν hν, g2_unit S 0 C ν hν]
  simp

end Approximation
end «JNT-2024»
