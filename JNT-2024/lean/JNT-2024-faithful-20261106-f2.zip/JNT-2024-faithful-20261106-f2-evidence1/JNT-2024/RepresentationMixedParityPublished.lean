module

public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».RepresentationFactors
public import «JNT-2024».RepresentationGaussian
public import «JNT-2024».RepresentationGaussianPublished
public import «JNT-2024».RepresentationNormalization
public import «JNT-2024».RepresentationValuationCases
public import «JNT-2024».RepresentationValuationLowerBounds
public import «JNT-2024».RepresentationValuations
public import «JNT-2024».Sequence
public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

/-- The standard unequal-valuation rule used for the sum and difference
of the two candidates in cases (b-ii) and (b-iii). -/
theorem valuation_two_add_of_ne {a b : ℤ} (ha : a ≠ 0) (hb : b ≠ 0)
    (hab : a + b ≠ 0) (hne : padicValInt 2 a ≠ padicValInt 2 b) :
    padicValInt 2 (a + b) = min (padicValInt 2 a) (padicValInt 2 b) := by
  have haq : (a : ℚ) ≠ 0 := by exact_mod_cast ha
  have hbq : (b : ℚ) ≠ 0 := by exact_mod_cast hb
  have habq : (a : ℚ) + b ≠ 0 := by exact_mod_cast hab
  have hnq : padicValRat 2 (a : ℚ) ≠ padicValRat 2 (b : ℚ) := by
    rw [padicValRat.of_int, padicValRat.of_int]
    exact_mod_cast hne
  have hh := padicValRat.add_eq_min habq haq hbq hnq
  rw [← Int.cast_add, padicValRat.of_int, padicValRat.of_int, padicValRat.of_int] at hh
  exact_mod_cast hh

/-- Unequal candidate valuations force equal center/offset valuations;
each candidate then has at least one additional factor two. -/
theorem valuation_two_center_offset {C B A A' : ℤ} (hB : B ≠ 0)
    (hA : A ≠ 0) (hA' : A' ≠ 0) (he : A = C + B) (he' : A' = C - B)
    (hne : padicValInt 2 A ≠ padicValInt 2 A') :
    C ≠ 0 ∧ padicValInt 2 C = padicValInt 2 B ∧
      min (padicValInt 2 A) (padicValInt 2 A') = 1 + padicValInt 2 B := by
  have hC : C ≠ 0 := by
    intro hz
    apply hne
    rw [he, he', hz, zero_add, zero_sub, valuation_neg]
  have hsum : A + A' = 2 * C := by omega
  have hdiff : A + -A' = 2 * B := by omega
  have hvsum := valuation_two_add_of_ne hA hA'
    (by rw [hsum]; exact mul_ne_zero (by norm_num) hC) hne
  have hvdiff := valuation_two_add_of_ne hA (neg_ne_zero.mpr hA')
    (by rw [hdiff]; exact mul_ne_zero (by norm_num) hB)
    (by simpa only [valuation_neg] using hne)
  rw [hsum, padicValInt.mul (by norm_num) hC] at hvsum
  rw [hdiff, padicValInt.mul (by norm_num) hB, valuation_neg] at hvdiff
  have htwo : padicValInt 2 (2 : ℤ) = 1 := by norm_num [padicValInt]
  rw [htwo] at hvsum hvdiff
  exact ⟨hC, by omega, hvdiff.symm⟩

/-- Case (b-ii-1): the even valuation must be exactly v2(4b²);
the strict alternative contradicts the root lower bound. -/
theorem gaussian_case_ii_even {B Y k l g R S F : ℕ}
    (hg : g = min (1 + B + k / 2) k) (hr : k = g + R)
    (hs : k + l = 2 * g + 2 * S) (hf : F + 2 * g = 2 + 2 * B + k)
    (hy : B ≤ Y ∨ k ≤ 2 * Y + 1)
    (hne : k ≠ l → min k l = 2 + B + Y)
    (hR : R = 0) (hS : 0 < S) (hk : k % 2 = 0) :
    g = k ∧ k < l ∧ k = 2 + 2 * B ∧ F = 0 := by
  have hgk : g = k := by omega
  have hkl : k < l := by omega
  have hm := hne (by omega : k ≠ l)
  have hkbound : k ≤ 2 * B + 2 := by omega
  by_cases heq : k = 2 + 2 * B
  · exact ⟨hgk, hkl, heq, by omega⟩
  · have hB : k ≤ 2 * B := by omega
    have hY : k ≤ 2 * Y := by omega
    have hoffset : k + 1 ≤ 1 + B + Y := by omega
    have hsum : k = 2 + B + Y := by omega
    omega

/-- Case (b-ii-2): the odd valuation contradicts (3.6) and the
extra factor two in the sum of equal-valuation center and offset. -/
theorem gaussian_case_ii_odd {B Y k l g R S : ℕ}
    (hg : g = min (1 + B + k / 2) k) (hr : k = g + R)
    (hs : k + l = 2 * g + 2 * S) (hy : B ≤ Y ∨ k ≤ 2 * Y + 1)
    (hne : k ≠ l → min k l = 2 + B + Y)
    (hR : R = 0) (hS : 0 < S) (hk : k % 2 = 1) : False := by
  have hgk : g = k := by omega
  have hkl : k < l := by omega
  have hB : k ≤ 2 * B + 1 := by omega
  have hY : k ≤ 2 * Y + 1 := by omega
  have hoffset : k ≤ 1 + B + Y := by omega
  have hm := hne (by omega : k ≠ l)
  have hsum : k = 2 + B + Y := by omega
  omega

/-- Case (b-iii-1): the other branch of the gcd minimum is selected;
an even candidate valuation makes the coefficient odd. -/
theorem gaussian_case_iii_even {B k g R F : ℕ}
    (hg : g = min (1 + B + k / 2) k) (hr : k = g + R)
    (hf : F + 2 * g = 2 + 2 * B + k) (hR : 0 < R) (hk : k % 2 = 0) :
    2 * g = 2 + 2 * B + k ∧ 2 * g < 2 * k ∧ F = 0 := by omega

/-- Case (b-iii-2): the product identity forces the other valuation to
be 2v2(b)+1, while (3.6) and the center/offset argument make it larger. -/
theorem gaussian_case_iii_odd {B Y k l g R S : ℕ}
    (hg : g = min (1 + B + k / 2) k) (hr : k = g + R)
    (hs : k + l = 2 * g + 2 * S) (hy : B ≤ Y ∨ k ≤ 2 * Y + 1)
    (hne : k ≠ l → min k l = 2 + B + Y)
    (hR : 0 < R) (hS : S = 0) (hk : k % 2 = 1) : False := by
  have hglt : g < k := by omega
  have hgsq : 2 * g = 1 + 2 * B + k := by omega
  have hother : l = 1 + 2 * B := by omega
  have hB : B < k / 2 := by omega
  have hY : B ≤ Y := by omega
  have hoffset : 2 * B + 1 ≤ 1 + B + Y := by omega
  have hm := hne (by omega : k ≠ l)
  have hfirst : 2 * B + 2 ≤ k := by omega
  have hsecond : 2 * B + 2 ≤ l := by omega
  omega

namespace Parameters

/-- All valuation identities used in the mixed-parity cases, derived
from the actual candidate and normalized coordinates, for either sign. -/
theorem gaussian_mixed_parity_identities (P : Parameters) {x y ν σ f r s : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hy : y ≠ 0) (hu : P.u ≠ 0)
    (hN : P.normAlpha ≠ 0) (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν)
    (hσ : σ = 1 ∨ σ = -1) (hS : squarefreePart P.normAlpha = -1) (_hf0 : f ≠ 0)
    (he : σ * 4 * P.b ^ 2 * P.repCandidate y σ =
      (normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2 * f)
    (hr : P.repCandidate y σ = (normalizationGcd P.b (P.repCandidate y σ) : ℤ) * r)
    (hs : -P.u * squareFactor P.normAlpha = (normalizationGcd P.b (P.repCandidate y σ) : ℤ) * s) :
    let B := padicValInt 2 P.b
    let Y := padicValInt 2 y
    let k := padicValInt 2 (P.repCandidate y σ)
    let l := padicValInt 2 (P.repCandidate y (-σ))
    let g := padicValInt 2 (normalizationGcd P.b (P.repCandidate y σ) : ℤ)
    r ≠ 0 ∧ s ≠ 0 ∧ g = min (1 + B + k / 2) k ∧ k = g + padicValInt 2 r ∧
    k + l = 2 * g + 2 * padicValInt 2 s ∧ padicValInt 2 f + 2 * g = 2 + 2 * B + k ∧
    (B ≤ Y ∨ k ≤ 2 * Y + 1) ∧ (k ≠ l → min k l = 2 + B + Y) := by
  dsimp only
  have hσ' : -σ = 1 ∨ -σ = -1 := by rcases hσ with rfl | rfl <;> norm_num
  have h1 := P.repCandidate_ne_zero h hu hN hσ
  have h2 := P.repCandidate_ne_zero h hu hN hσ'
  have hcN := ne_of_gt (squareFactor_pos hN)
  have hg : (normalizationGcd P.b (P.repCandidate y σ) : ℤ) ≠ 0 := by
    exact_mod_cast ne_of_gt (normalizationGcd_pos P.b h1)
  have hr0 : r ≠ 0 := by intro hz; rw [hz, mul_zero] at hr; exact h1 hr
  have hs0 : s ≠ 0 := by
    intro hz
    rw [hz, mul_zero] at hs
    exact mul_ne_zero (neg_ne_zero.mpr hu) hcN hs
  have htwo : padicValInt 2 (2 : ℤ) = 1 := by norm_num [padicValInt]
  have hgv := normalizationGcd_sq_valuation 2 hb h1
  rw [valuation_int_pow, htwo] at hgv
  have hrv := congrArg (padicValInt 2) hr
  rw [padicValInt.mul hg hr0] at hrv
  have hsv := congrArg (padicValInt 2) hs
  rw [neg_mul, valuation_neg, padicValInt.mul hu hcN, padicValInt.mul hg hs0] at hsv
  have hNv := valuation_squarePart 2 hN
  have hmone : padicValInt 2 (-1 : ℤ) = 0 := by norm_num [padicValInt]
  rw [hS, hmone, add_zero] at hNv
  have hprod : P.repCandidate y σ * P.repCandidate y (-σ) = P.u ^ 2 * P.normAlpha := by
    rcases hσ with rfl | rfl <;> simpa only [neg_neg, mul_comm] using P.repCandidate_product h
  have hp := congrArg (padicValInt 2) hprod
  rw [padicValInt.mul h1 h2, padicValInt.mul (pow_ne_zero _ hu) hN, valuation_int_pow] at hp
  have hfv := normalized_coefficient_valuation 2 hb h1 hσ he
  have hqv := normalizationQuotient_valuation 2 hb h1
  have hgv' : padicValInt 2 (normalizationGcd P.b (P.repCandidate y σ) : ℤ) =
      min (1 + padicValInt 2 P.b + padicValInt 2 (P.repCandidate y σ) / 2)
        (padicValInt 2 (P.repCandidate y σ)) := by omega
  rw [valuation_four_mul_square 2 hb, htwo] at hfv
  rw [padicValInt.mul (by norm_num) hb, htwo] at hqv
  rw [valuation_squareFactor_eq_half 2 h1] at hqv
  refine ⟨hr0, hs0, hgv', hrv, by omega, by omega,
    P.lemma32_two_lower_from_chain h hb hy hu hN hσ hν, ?_⟩
  intro hne
  have hs0' : σ ≠ 0 := by rcases hσ with rfl | rfl <;> norm_num
  have hB : σ * 2 * P.b * y ≠ 0 := mul_ne_zero (mul_ne_zero (mul_ne_zero hs0' (by norm_num)) hb) hy
  have hh := valuation_two_center_offset hB h1 h2
    (show P.repCandidate y σ = (P.a * P.u + P.b ^ 2 * P.t) + σ * 2 * P.b * y by unfold repCandidate; ring)
    (show P.repCandidate y (-σ) = (P.a * P.u + P.b ^ 2 * P.t) - σ * 2 * P.b * y by unfold repCandidate; ring) hne
  have hvB : padicValInt 2 (σ * 2 * P.b * y) = 1 + padicValInt 2 P.b + padicValInt 2 y := by
    rcases hσ with rfl | rfl <;>
      simp only [one_mul, neg_mul, valuation_neg] <;>
      rw [padicValInt.mul (mul_ne_zero (by norm_num) hb) hy, padicValInt.mul (by norm_num) hb, htwo]
  rw [hvB] at hh
  omega

/-- Both printed mixed-parity cases, with their even/odd valuation subcases.
The odd subcases are impossible; the even subcases leave f odd, and hence
give the sharp bound without changing the normalized coordinates. -/
theorem proposition31b_mixed_parity_published (P : Parameters) {x y ν σ f r s : ℤ}
    (h : P.RepresentsSquare x y) (hb : P.b ≠ 0) (hy : y ≠ 0) (hu : P.u ≠ 0)
    (hN : P.normAlpha ≠ 0) (hν : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν)
    (hσ : σ = 1 ∨ σ = -1) (hS : squarefreePart P.normAlpha = -1) (hf0 : f ≠ 0)
    (he : σ * 4 * P.b ^ 2 * P.repCandidate y σ =
      (normalizationGcd P.b (P.repCandidate y σ) : ℤ) ^ 2 * f)
    (hr : P.repCandidate y σ = (normalizationGcd P.b (P.repCandidate y σ) : ℤ) * r)
    (hs : -P.u * squareFactor P.normAlpha = (normalizationGcd P.b (P.repCandidate y σ) : ℤ) * s)
    (hrep : P.FourthPowerRepresentation x y f r s)
    (hpar : (Odd r ∧ Even s) ∨ (Even r ∧ Odd s)) :
    Odd f ∧ P.SignedFourthPowerRepresentation x y f r s 1 ∧ f ∣ P.b ^ 2 * P.normRadical ν := by
  obtain ⟨hr0, hs0, hgv, hrv, hsv, hfv, hyv, hne⟩ :=
    P.gaussian_mixed_parity_identities h hb hy hu hN hν hσ hS hf0 he hr hs
  have odd_val {z : ℤ} (hz : Odd z) : padicValInt 2 z = 0 := by
    apply padicValInt.eq_zero_of_not_dvd
    intro hd
    exact (Int.not_even_iff_odd.mpr hz) (even_iff_two_dvd.mpr hd)
  have even_val {z : ℤ} (hz0 : z ≠ 0) (hz : Even z) : 0 < padicValInt 2 z :=
    (prime_dvd_iff_valuation_pos 2 hz0).mp (even_iff_two_dvd.mp hz)
  have hfval : padicValInt 2 f = 0 := by
    have hk : padicValInt 2 (P.repCandidate y σ) % 2 = 0 ∨
        padicValInt 2 (P.repCandidate y σ) % 2 = 1 := by omega
    rcases hpar with ⟨hrO, hsE⟩ | ⟨hrE, hsO⟩
    · rcases hk with hk | hk
      · exact (gaussian_case_ii_even hgv hrv hsv hfv hyv hne (odd_val hrO) (even_val hs0 hsE) hk).2.2.2
      · exact (gaussian_case_ii_odd hgv hrv hsv hyv hne (odd_val hrO) (even_val hs0 hsE) hk).elim
    · rcases hk with hk | hk
      · exact (gaussian_case_iii_even hgv hrv hfv (even_val hr0 hrE) hk).2.2
      · exact (gaussian_case_iii_odd hgv hrv hsv hyv hne (even_val hr0 hrE) (odd_val hsO) hk).elim
  have hfO := odd_of_valuation_two_zero hf0 hfval
  exact ⟨hfO, P.proposition31b_odd_coefficient_published h hb hu hN hν hσ hS hf0 hfO he hrep⟩

end Parameters
end «JNT-2024»
