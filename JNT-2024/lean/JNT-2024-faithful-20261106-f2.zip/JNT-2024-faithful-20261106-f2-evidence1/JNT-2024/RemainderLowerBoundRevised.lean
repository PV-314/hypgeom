module

public import «JNT-2024».EulerIntegral
public import «JNT-2024».RemainderLowerBound
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Hypergeometric

/-- Lemma 2.2(e), with the exact neighborhood hypothesis in the revised manuscript.
The supplied continuation proof is specialized to this neighborhood. -/
theorem lemma22e_revised {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1 / 2) (r : ℕ)
    {z : ℂ} (hz : ‖z‖ = 1) (hnear : ‖z - 1‖ < 1) :
    1 ≤ ‖eulerHypergeometric (r + 1 - (ν : ℂ)) r z‖ := by
  apply lemma22e hν₀ hν₁ r hz
  have hh := Complex.re_le_norm (1 - z)
  rw [Complex.sub_re, Complex.one_re, norm_sub_rev] at hh
  linarith

theorem lemma22e_revised_minimum {ν : ℚ} (hν₀ : 0 < ν) (hν₁ : ν < 1 / 2) (r : ℕ) :
    ‖eulerHypergeometric (r + 1 - (ν : ℂ)) r 1‖ = 1 ∧
      ∀ z : ℂ, ‖z‖ = 1 → ‖z - 1‖ < 1 →
        ‖eulerHypergeometric (r + 1 - (ν : ℂ)) r 1‖ ≤
          ‖eulerHypergeometric (r + 1 - (ν : ℂ)) r z‖ := by
  simp only [eulerHypergeometric_one, norm_one, true_and]
  exact fun _ hz hnear => lemma22e_revised hν₀ hν₁ r hz hnear

end «JNT-2024».Hypergeometric
