module

public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».Sequence
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

open scoped NumberField

namespace «JNT-2024».Parameters

/-- The elementary integrality test implicit in the two printed quotients
in Section 4.6: the trace of an algebraic integer is an integer. -/
theorem twice_re_integer (P : Parameters) [Fact (¬ IsSquare P.d)]
    {z : P.Algebra} (hz : IsIntegral ℤ z) : ∃ m : ℤ, (m : ℚ)=2*z.re := by
  have hh : IsIntegral ℤ (algebraMap ℚ P.Algebra (QuadraticAlgebra.trace z)) := by
    rw [QuadraticAlgebra.algebraMap_trace_eq_add_star]
    exact hz.add (map_isIntegral_int (starRingEnd P.Algebra) hz)
  have hr : IsIntegral ℤ (QuadraticAlgebra.trace z) := isIntegral_algebraMap_iff.mp hh
  obtain ⟨m,hm⟩ := IsIntegrallyClosedIn.algebraMap_eq_of_integral hr
  exact ⟨m,by simpa [QuadraticAlgebra.trace_def] using hm⟩

/-- Every quotient term/alpha is an algebraic integer because it is the
integer power of the ring-of-integers unit epsilon squared. -/
theorem term_quotient_integral (P : Parameters) [Fact (¬ IsSquare P.d)]
    (hp : P.Pell) (ha : P.alpha ≠ 0) (k : ℤ) :
    IsIntegral ℤ (P.term hp k / P.alpha) := by
  let v := (P.epsilonIntegerUnit hp^2)^k
  have he : ((P.stepUnit hp^k : P.Algebraˣ) : P.Algebra) = ((v : 𝓞 P.Algebra) : P.Algebra) := by
    rw [P.stepUnit_eq_integerUnit_sq,← map_zpow]
    rfl
  rw [term,mul_div_cancel_left₀ _ ha,he]
  exact (v : 𝓞 P.Algebra).property

/-- The d=17 quotients printed on page 40, allowing either sign of x. -/
theorem section46_quotients_17 (P : Parameters) (hd : P.d=17)
    (ha : P.a=1) (hb : P.b=1) :
    (⟨16,4⟩ : P.Algebra) = P.alpha*(⟨13/4,3/4⟩ : P.Algebra) ∧
    (⟨-16,4⟩ : P.Algebra) = P.alpha*(⟨21/4,-5/4⟩ : P.Algebra) := by
  constructor <;> ext <;> norm_num [alpha,hd,ha,hb]

/-- The identical two real parts after scaling the d=17 calculation to d=68. -/
theorem section46_quotients_68 (P : Parameters) (hd : P.d=68)
    (ha : P.a=2) (hb : P.b=1) :
    (⟨32,4⟩ : P.Algebra) = P.alpha*(⟨13/4,3/8⟩ : P.Algebra) ∧
    (⟨-32,4⟩ : P.Algebra) = P.alpha*(⟨21/4,-5/8⟩ : P.Algebra) := by
  constructor <;> ext <;> norm_num [alpha,hd,ha,hb]

/-- Neither 13/2 nor 21/2 is an integral trace. -/
theorem section46_nonintegral_quotient (P : Parameters) [Fact (¬ IsSquare P.d)]
    {z : P.Algebra} (hz : z.re=13/4 ∨ z.re=21/4) : ¬ IsIntegral ℤ z := by
  intro hi
  obtain ⟨m,hm⟩ := P.twice_re_integer hi
  rcases hz with hz | hz
  · rw [hz] at hm
    have he : (2 : ℚ)*m=13 := by linarith
    have he' : 2*m=13 := by exact_mod_cast he
    omega
  · rw [hz] at hm
    have he : (2 : ℚ)*m=21 := by linarith
    have he' : 2*m=21 := by exact_mod_cast he
    omega

/-- A term cannot equal alpha times either of the nonintegral quotients. -/
theorem section46_not_term_of_quotient (P : Parameters) [Fact (¬ IsSquare P.d)]
    (hp : P.Pell) (ha : P.alpha ≠ 0) (k : ℤ) {z : P.Algebra}
    (hz : z.re=13/4 ∨ z.re=21/4) : P.term hp k ≠ P.alpha*z := by
  intro he
  have hi := P.term_quotient_integral hp ha k
  rw [he,mul_div_cancel_left₀ _ ha] at hi
  exact P.section46_nonintegral_quotient hz hi

/-- The middle positive quartic solution for d=17 is absent for either sign
of its x-coordinate, for every allowed unit and every integer index. -/
theorem section46_y_ne_four_17 (P : Parameters) (h : P.Admissible)
    (hd : P.d=17) (ha : P.a=1) (hb : P.b=1) (k : ℤ) : P.y h.pell k ≠ 4 := by
  let : Fact (¬ IsSquare P.d) := ⟨h.d_not_square⟩
  have hα : P.alpha ≠ 0 := by
    intro he
    have hh := congrArg QuadraticAlgebra.re he
    norm_num [alpha,ha] at hh
  intro hy
  have hn := P.norm_identity h.pell k
  rw [hy,hd] at hn
  have hN : P.normAlpha = -16 := by norm_num [normAlpha,ha,hb,hd]
  rw [hN] at hn
  norm_num at hn
  have hx : P.x h.pell k=16 ∨ P.x h.pell k= -16 :=
    (sq_eq_sq_iff_eq_or_eq_neg).mp (by nlinarith only [hn] : P.x h.pell k^2=(16 : ℚ)^2)
  rcases hx with hx | hx
  · apply P.section46_not_term_of_quotient h.pell hα k (z := ⟨13/4,3/4⟩) (Or.inl rfl)
    rw [← (P.section46_quotients_17 hd ha hb).1]
    ext <;> assumption
  · apply P.section46_not_term_of_quotient h.pell hα k (z := ⟨21/4,-5/4⟩) (Or.inr rfl)
    rw [← (P.section46_quotients_17 hd ha hb).2]
    ext <;> assumption

/-- The scaled d=68 argument, with the same two nonintegral traces. -/
theorem section46_y_ne_four_68 (P : Parameters) (h : P.Admissible)
    (hd : P.d=68) (ha : P.a=2) (hb : P.b=1) (k : ℤ) : P.y h.pell k ≠ 4 := by
  let : Fact (¬ IsSquare P.d) := ⟨h.d_not_square⟩
  have hα : P.alpha ≠ 0 := by
    intro he
    have hh := congrArg QuadraticAlgebra.re he
    norm_num [alpha,ha] at hh
  intro hy
  have hn := P.norm_identity h.pell k
  rw [hy,hd] at hn
  have hN : P.normAlpha = -64 := by norm_num [normAlpha,ha,hb,hd]
  rw [hN] at hn
  norm_num at hn
  have hx : P.x h.pell k=32 ∨ P.x h.pell k= -32 :=
    (sq_eq_sq_iff_eq_or_eq_neg).mp (by nlinarith only [hn] : P.x h.pell k^2=(32 : ℚ)^2)
  rcases hx with hx | hx
  · apply P.section46_not_term_of_quotient h.pell hα k (z := ⟨13/4,3/8⟩) (Or.inl rfl)
    rw [← (P.section46_quotients_68 hd ha hb).1]
    ext <;> assumption
  · apply P.section46_not_term_of_quotient h.pell hα k (z := ⟨21/4,-5/8⟩) (Or.inr rfl)
    rw [← (P.section46_quotients_68 hd ha hb).2]
    ext <;> assumption

end «JNT-2024».Parameters
