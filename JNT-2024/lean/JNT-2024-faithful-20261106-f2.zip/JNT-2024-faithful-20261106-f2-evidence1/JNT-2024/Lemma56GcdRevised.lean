module

public import «JNT-2024».Lemma55PrimePublished
public import «JNT-2024».Lemma55Revised
public import «JNT-2024».Lemma56NormalizerPublished
public import «JNT-2024».NormalizerBounds
public import «JNT-2024».NormalizerFormula
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».Proposition41
public import «JNT-2024».Section5Bounds
public import «JNT-2024».Section5GcdNormalization
public import «JNT-2024».Section5OpeningPublished
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.Deriv.MeanValue
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Pow.Real
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.LegendreSymbol.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section
namespace «JNT-2024».Parameters

/-- The first reduction of Lemma 5.6: M>=4 and uM<=18 imply u<=4. -/
theorem lemma56_unit_bound_revised (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hn : P.normAlpha<0) (hNs : IsSquare (-P.normAlpha)) (heven : Even (-P.normAlpha))
    {k : ℤ} (hk : k=1 ∨ k= -1) (hs : IsIntegerSquare (P.y h.pell k))
    (hy : 1<P.y h.pell k) (hcut : (P.y h.pell k:ℝ) ≤ P.proposition41Threshold) :
    P.u ≤ 4 ∧ (P.normalizerSquare:ℤ) ≤ 324 := by
  have hbound := P.small_normalizer_square_revised h hb hn hNs hk hs hy hcut
  have hM : (16:ℤ) ≤ P.normalizerSquare := by
    exact_mod_cast P.section5_normalizer_ge_sixteen h hb (ne_of_lt hn)
      (P.section5_four_dvd_norm hNs (by simpa using heven))
  have hu1 : (1:ℤ) ≤ P.u^2 := by have := h.u_pos; nlinarith
  have hprod := mul_le_mul_of_nonneg_right hM (sq_nonneg P.u)
  have hprod' := mul_le_mul_of_nonneg_left hu1 (by positivity : (0:ℤ) ≤ P.normalizerSquare)
  constructor
  · by_contra hh
    have hu5 : 5 ≤ P.u := by omega
    nlinarith
  · nlinarith only [hbound,hprod']

/-- For even negative square norm, an odd prime in the root gcd gives M>=4p.
This is the two-parity argument printed in Lemma 5.6. -/
theorem lemma56_prime_normalizer_revised (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hNs : IsSquare (-P.normAlpha)) (heven : Even (-P.normAlpha))
    {n : ℤ} (hn2 : -P.normAlpha=n^2) {p : ℕ} (hp : p.Prime) (hp2 : p ≠ 2)
    (hpg : p ∣ Int.gcd P.a n) : 16*p^2 ≤ P.normalizerSquare := by
  have hpG : p^2 ∣ P.baseGcd := by
    rw [P.section5_baseGcd hb hn2]
    exact pow_dvd_pow_of_dvd hpg 2
  have hGpos := P.baseGcd_pos (ne_of_gt h.a_pos)
  rcases Int.even_or_odd P.a with hae | hao
  · have h4 := ((P.lemma56_even_normalizer_cases h hb hNs heven).1 hae).2
    have hcop : Nat.Coprime 4 (p^2) := by
      have hc : Nat.Coprime 2 p := (hp.eq_two_or_odd'.resolve_left hp2).coprime_two_left
      exact hc.pow_left 2 |>.pow_right 2
    have hdiv := hcop.mul_dvd_of_dvd_of_dvd h4 hpG
    have hg := Nat.le_of_dvd hGpos hdiv
    have hm := P.lemma56_normalizer_ge_four_gcd h hb hNs
    omega
  · have hm := ((P.lemma56_even_normalizer_cases h hb hNs heven).2 hao).2
    have hg := Nat.le_of_dvd hGpos hpG
    omega

/-- The printed exclusion of every odd prime divisor of gcd(a,sqrt(|N|)). -/
theorem lemma56_no_odd_prime_revised (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hNs : IsSquare (-P.normAlpha)) (heven : Even (-P.normAlpha))
    {n : ℤ} (hn2 : -P.normAlpha=n^2) (hminus : P.t^2-P.d*P.u^2= -4)
    (hM : (P.normalizerSquare:ℤ) ≤ 324) :
    ∀ p:ℕ, p.Prime → p ∣ Int.gcd P.a n → p=2 := by
  intro p hp hpg
  by_contra hp2
  have ha : (p:ℤ) ∣ P.a := dvd_trans (by exact_mod_cast hpg) (Int.gcd_dvd_left P.a n)
  have hn : (p:ℤ) ∣ n := dvd_trans (by exact_mod_cast hpg) (Int.gcd_dvd_right P.a n)
  have hd : P.d=P.a^2+n^2 := by simp only [normAlpha,hb,one_pow,one_mul] at hn2; linarith
  have hpd : (p:ℤ) ∣ P.d := by
    rw [hd]
    exact dvd_add (dvd_trans ha (dvd_pow_self _ (by decide : 2 ≠ 0)))
      (dvd_trans hn (dvd_pow_self _ (by decide : 2 ≠ 0)))
  have ht : (p:ℤ) ∣ P.t^2+4 := by
    have he : P.t^2+4=P.d*P.u^2 := by linarith
    rw [he]; exact dvd_mul_of_dvd_left hpd _
  have hp4 := Section5.lemma55_prime_mod_four hp hp2 ht
  have hp5 : 5 ≤ p := by have := hp.two_le; omega
  have hh := P.lemma56_prime_normalizer_revised h hb hNs heven hn2 hp hp2 hpg
  have hMn : P.normalizerSquare ≤ 324 := by exact_mod_cast hM
  nlinarith

/-- The root gcd is a power of two; the bound 18 leaves only 1,2,4,8.
The tiny final case split merely expresses the preceding prime-divisor proof. -/
theorem lemma56_root_gcd_revised (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hNs : IsSquare (-P.normAlpha)) {n : ℤ} (hn2 : -P.normAlpha=n^2)
    (hM : (P.normalizerSquare:ℤ) ≤ 324)
    (hprime : ∀ p:ℕ, p.Prime → p ∣ Int.gcd P.a n → p=2) :
    Int.gcd P.a n=1 ∨ Int.gcd P.a n=2 ∨ Int.gcd P.a n=4 ∨ Int.gcd P.a n=8 := by
  have hg := Int.gcd_pos_of_ne_zero_left n (ne_of_gt h.a_pos)
  have hm := P.lemma56_normalizer_ge_four_gcd h hb hNs
  rw [P.section5_baseGcd hb hn2] at hm
  have hMn : P.normalizerSquare ≤ 324 := by exact_mod_cast hM
  have hg9 : Int.gcd P.a n ≤ 9 := by nlinarith
  have h3 : ¬3 ∣ Int.gcd P.a n := by intro hh; have := hprime 3 (by decide) hh; omega
  have h5 : ¬5 ∣ Int.gcd P.a n := by intro hh; have := hprime 5 (by decide) hh; omega
  have h7 : ¬7 ∣ Int.gcd P.a n := by intro hh; have := hprime 7 (by decide) hh; omega
  omega

end «JNT-2024».Parameters
