module

public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

/-!
# The sequences in Section 1.2

Coordinates live in `ℚ`: the paper allows half-integer terms. We use mathlib's
quadratic algebra, so multiplication really represents multiplication of
`x + y √d`. The unit used for integer powers is `ε²`, of norm one.
-/

namespace «JNT-2024»

/-- Raw integer parameters. Positivity and nonsquareness are imposed separately. -/
structure Parameters where
  a : ℤ
  b : ℤ
  d : ℤ
  t : ℤ
  u : ℤ
  deriving DecidableEq

namespace Parameters

def normAlpha (P : Parameters) : ℤ := P.a ^ 2 - P.b ^ 4 * P.d

/-- The Pell condition expressing that `(t + u √d) / 2` has norm `±1`. -/
def Pell (P : Parameters) : Prop :=
  P.t ^ 2 - P.d * P.u ^ 2 = 4 ∨ P.t ^ 2 - P.d * P.u ^ 2 = -4

/-- Arithmetic assumptions from Section 1.2; `d` need not be squarefree. -/
structure Admissible (P : Parameters) : Prop where
  a_pos : 0 < P.a
  b_pos : 0 < P.b
  d_pos : 0 < P.d
  t_pos : 0 < P.t
  u_pos : 0 < P.u
  d_not_square : ¬ IsSquare P.d
  pell : P.Pell

abbrev Algebra (P : Parameters) := QuadraticAlgebra ℚ (P.d : ℚ) 0

def alpha (P : Parameters) : P.Algebra := ⟨P.a, (P.b : ℚ) ^ 2⟩

def epsilon (P : Parameters) : P.Algebra := ⟨(P.t : ℚ) / 2, (P.u : ℚ) / 2⟩

def step (P : Parameters) : P.Algebra :=
  ⟨((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) / 4, P.t * P.u / 2⟩

def backStep (P : Parameters) : P.Algebra :=
  ⟨((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) / 4, -(P.t * P.u / 2)⟩

theorem step_eq_epsilon_sq (P : Parameters) : P.step = P.epsilon ^ 2 := by
  ext <;> simp [step, epsilon, pow_two] <;> ring

theorem pell_sq (P : Parameters) (h : P.Pell) :
    ((P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2) ^ 2 = 16 := by
  rcases h with h | h
  · have hq : (P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2 = 4 := by exact_mod_cast h
    rw [hq]; norm_num
  · have hq : (P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2 = -4 := by exact_mod_cast h
    rw [hq]; norm_num

theorem step_mul_backStep (P : Parameters) (h : P.Pell) :
    P.step * P.backStep = 1 := by
  have hp := P.pell_sq h
  ext <;> simp [step, backStep, QuadraticAlgebra.re_one, QuadraticAlgebra.im_one]
  · nlinarith [hp]
  · ring

def stepUnit (P : Parameters) (h : P.Pell) : P.Algebraˣ where
  val := P.step
  inv := P.backStep
  val_inv := P.step_mul_backStep h
  inv_val := by rw [mul_comm]; exact P.step_mul_backStep h

/-- Equation (1.1), using `(ε²)^k` to make negative indices exact. -/
def term (P : Parameters) (h : P.Pell) (k : ℤ) : P.Algebra :=
  P.alpha * ↑(P.stepUnit h ^ k)

def x (P : Parameters) (h : P.Pell) (k : ℤ) : ℚ := (P.term h k).re
def y (P : Parameters) (h : P.Pell) (k : ℤ) : ℚ := (P.term h k).im

@[simp] theorem term_zero (P : Parameters) (h : P.Pell) : P.term h 0 = P.alpha := by
  simp [term]

@[simp] theorem x_zero (P : Parameters) (h : P.Pell) : P.x h 0 = P.a := by
  simp [x, alpha]

@[simp] theorem y_zero (P : Parameters) (h : P.Pell) : P.y h 0 = (P.b : ℚ) ^ 2 := by
  simp [y, alpha]

theorem term_add_one (P : Parameters) (h : P.Pell) (k : ℤ) :
    P.term h (k + 1) = P.term h k * P.step := by
  simp [term, zpow_add, mul_assoc, stepUnit]

theorem term_sub_one (P : Parameters) (h : P.Pell) (k : ℤ) :
    P.term h (k - 1) = P.term h k * P.backStep := by
  simp [term, sub_eq_add_neg, zpow_add, mul_assoc, stepUnit]

/-- The positive-index formula in (1.2). -/
theorem y_one (P : Parameters) (h : P.Pell) :
    P.y h 1 = ((P.b : ℚ) ^ 2 * ((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2)
      + 2 * P.a * P.t * P.u) / 4 := by
  simp [y, term, stepUnit, alpha, step]
  ring

/-- The negative-index formula in (1.2). -/
theorem y_neg_one (P : Parameters) (h : P.Pell) :
    P.y h (-1) = ((P.b : ℚ) ^ 2 * ((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2)
      - 2 * P.a * P.t * P.u) / 4 := by
  simp [y, term, stepUnit, alpha, backStep]
  ring

/-- Equation (1.3) for the `y` coordinates, for every integer index. -/
theorem y_recurrence (P : Parameters) (h : P.Pell) (k : ℤ) :
    P.y h (k + 1) = ((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) / 2 * P.y h k
      - P.y h (k - 1) := by
  simp only [y, term_add_one, term_sub_one]
  simp [step, backStep]
  ring

/-- Equation (1.3) for the `x` coordinates, for every integer index. -/
theorem x_recurrence (P : Parameters) (h : P.Pell) (k : ℤ) :
    P.x h (k + 1) = ((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) / 2 * P.x h k
      - P.x h (k - 1) := by
  simp only [x, term_add_one, term_sub_one]
  simp [step, backStep]
  ring

theorem norm_step (P : Parameters) (h : P.Pell) :
    QuadraticAlgebra.norm P.step = 1 := by
  have hp := P.pell_sq h
  simp [QuadraticAlgebra.norm, step]
  nlinarith [hp]

theorem norm_backStep (P : Parameters) (h : P.Pell) :
    QuadraticAlgebra.norm P.backStep = 1 := by
  have hp := P.pell_sq h
  simp [QuadraticAlgebra.norm, backStep]
  nlinarith [hp]

theorem norm_term (P : Parameters) (h : P.Pell) (k : ℤ) :
    QuadraticAlgebra.norm (P.term h k) = (P.normAlpha : ℚ) := by
  induction k using Int.induction_on with
  | zero => simp [alpha, QuadraticAlgebra.norm, normAlpha]; ring
  | succ k ih => rw [term_add_one, map_mul, norm_step P h, mul_one, ih]
  | pred k ih => rw [term_sub_one, map_mul, norm_backStep P h, mul_one, ih]

/-- The norm identity immediately following (1.3), for all `k : ℤ`. -/
theorem norm_identity (P : Parameters) (h : P.Pell) (k : ℤ) :
    P.x h k ^ 2 - P.d * P.y h k ^ 2 = (P.normAlpha : ℚ) := by
  have hn := P.norm_term h k
  simpa [QuadraticAlgebra.norm, x, y, pow_two, mul_assoc] using hn

/-- Equation (3.14), the square-completion identity in Lemma 3.5(c). -/
theorem complete_square_one (P : Parameters) (h : P.Pell) :
    4 * (P.b : ℚ) ^ 2 * P.y h 1 =
      ((P.b : ℚ) ^ 2 * P.t + P.a * P.u) ^ 2 - P.normAlpha * (P.u : ℚ) ^ 2 := by
  rw [y_one]
  simp [normAlpha]
  ring

end Parameters
end «JNT-2024»
