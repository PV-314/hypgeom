module

public import «JNT-2024».NormalizerPowers
public import «JNT-2024».Section5GcdNormalization
public import «JNT-2024».Sequence
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.Deriv.MeanValue
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.LegendreSymbol.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section5

/-- The printed prime-divisor implication t^2=-4 mod p gives p=1 mod4. -/
theorem lemma55_prime_mod_four {p : ℕ} (hp : p.Prime) (hp2 : p ≠ 2) {t : ℤ}
    (ht : (p:ℤ) ∣ t^2+4) : p % 4=1 := by
  let : Fact p.Prime := ⟨hp⟩
  have hh := (ZMod.intCast_zmod_eq_zero_iff_dvd (t^2+4) p).mpr ht
  push_cast at hh
  have h2 : (2:ZMod p) ≠ 0 := by
    intro he
    have hd : p ∣ 2 := (ZMod.natCast_eq_zero_iff 2 p).mp (by simpa using he)
    exact hp2 ((Nat.prime_dvd_prime_iff_eq hp Nat.prime_two).mp hd)
  have hs : (t:ZMod p)^2= -(2:ZMod p)^2 := by linear_combination hh
  have h3 := ZMod.mod_four_ne_three_of_sq_eq_neg_sq' h2 hs
  have ho := hp.eq_two_or_odd.resolve_left hp2
  omega

end «JNT-2024».Section5

namespace «JNT-2024».Parameters

/-- Every prime selected from a nontrivial odd gcd has the properties used in
Lemma 5.5(2-iii). Squarehood of the gcd is reused, not reproved. -/
theorem lemma55_gcd_prime_bounds (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hNs : IsSquare (-P.normAlpha)) (ho : Odd (-P.normAlpha))
    (he : P.t^2-P.d*P.u^2= -4) (hg : P.baseGcd ≠ 1) :
    Odd P.baseGcd ∧ ∃ p:ℕ, p.Prime ∧ p ∣ P.baseGcd ∧ p % 4=1 ∧
      (p:ℤ)^2 ∣ P.d ∧ 5 ≤ p ∧ (p:ℤ) ≤ P.a ∧ 25 ≤ P.baseGcd := by
  obtain ⟨n,hn⟩ := hNs
  have hn2 : -P.normAlpha=n^2 := by simpa [pow_two] using hn
  have hd : P.d=P.a^2+n^2 := by simp only [normAlpha,hb,one_pow,one_mul] at hn2; linarith
  have hG := P.section5_baseGcd hb hn2
  have hno : Odd n := by have hh : Odd (n^2) := hn2 ▸ ho; simpa [Int.odd_pow] using hh
  obtain ⟨v,hv⟩ := Int.gcd_dvd_right P.a n
  have hgo : Odd (Int.gcd P.a n) := by
    have hh := (Int.odd_mul.mp (hv ▸ hno)).1
    exact_mod_cast hh
  refine ⟨by rw [hG]; exact hgo.pow,?_⟩
  obtain ⟨p,hp,hpg⟩ := Nat.exists_prime_and_dvd hg
  have hpg' : p ∣ Int.gcd P.a n := hp.dvd_of_dvd_pow (hG ▸ hpg)
  have hpa : (p:ℤ) ∣ P.a := dvd_trans (by exact_mod_cast hpg') (Int.gcd_dvd_left P.a n)
  have hpn : (p:ℤ) ∣ n := dvd_trans (by exact_mod_cast hpg') (Int.gcd_dvd_right P.a n)
  have hp2 : p ≠ 2 := by
    intro hh
    have hm := Int.emod_eq_zero_of_dvd hpn
    rw [hh] at hm
    have hnmod := Int.odd_iff.mp hno
    norm_num at hm
    omega
  have hpd2 : (p:ℤ)^2 ∣ P.d := by
    rw [hd]
    exact dvd_add (pow_dvd_pow_of_dvd hpa 2) (pow_dvd_pow_of_dvd hpn 2)
  have hpd : (p:ℤ) ∣ P.d := dvd_trans (dvd_pow_self _ (by decide : 2 ≠ 0)) hpd2
  have hpt : (p:ℤ) ∣ P.t^2+4 := by
    have hh : P.t^2+4=P.d*P.u^2 := by linarith
    rw [hh]
    exact dvd_mul_of_dvd_left hpd _
  have hp4 := Section5.lemma55_prime_mod_four hp hp2 hpt
  have hp5 : 5 ≤ p := by have := hp.two_le; omega
  have hpa' : (p:ℤ) ≤ P.a := Int.le_of_dvd h.a_pos hpa
  have hpG : p^2 ∣ P.baseGcd := by rw [hG]; exact pow_dvd_pow_of_dvd hpg' 2
  have hpG' := Nat.le_of_dvd (P.baseGcd_pos (ne_of_gt h.a_pos)) hpG
  exact ⟨p,hp,hpg,hp4,hpd2,hp5,hpa',by nlinarith⟩


end «JNT-2024».Parameters
