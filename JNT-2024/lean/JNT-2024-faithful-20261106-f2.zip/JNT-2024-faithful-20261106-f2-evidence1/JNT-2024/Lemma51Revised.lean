module

public import «JNT-2024».AkhtariInput
public import «JNT-2024».DenominatorBounds
public import «JNT-2024».Integrality
public import «JNT-2024».Lemma51Published
public import «JNT-2024».Monotonicity
public import «JNT-2024».NegativeCutoff
public import «JNT-2024».NormalizerBounds
public import «JNT-2024».Positivity
public import «JNT-2024».Proposition41
public import «JNT-2024».Section46Calculation
public import «JNT-2024».Section4Published
public import «JNT-2024».Section5Bounds
public import «JNT-2024».Section5Counting
public import «JNT-2024».Section5NormalizerRevised
public import «JNT-2024».Sequence
public import «JNT-2024».Targets
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.Deriv.MeanValue
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Pow.Real
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section
namespace «JNT-2024».Parameters

/-- The repeated-value family in the revised proof of Lemma 5.1. -/
theorem lemma51_family_values_revised (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hd : P.d=P.a^2+4) (ht : P.t=P.a) (hu : P.u=1) :
    P.y h.pell (-1)=1 ∧ P.y h.pell 0=1 ∧
    P.y h.pell (-2)=(P.a:ℚ)^2+1 ∧ P.y h.pell 1=(P.a:ℚ)^2+1 := by
  have hh := P.table1_row_i h hb hd ht hu
  refine ⟨hh.1,by simp [hb],hh.2.1,?_⟩
  rw [P.y_one]
  simp [hb,hd,ht,hu]
  ring

theorem lemma51_family_lower_revised (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hn : P.normAlpha<0) (hd : P.d=P.a^2+4) (ht : P.t=P.a) (hu : P.u=1)
    {k : ℤ} (hy : 1<P.y h.pell k) : (P.a:ℚ)^2+1 ≤ P.y h.pell k := by
  have hv := P.lemma51_family_values_revised h hb hd ht hu
  by_cases hk : 0 ≤ k
  · have hk0 : k ≠ 0 := by intro he; simp [he,hb] at hy
    have hh := (P.y_strictMono_nonnegative h hn).monotone (show 1 ≤ k.toNat by omega)
    simpa only [Int.toNat_of_nonneg hk,Nat.cast_one,hv.2.2.2] using hh
  · have hkm : k ≠ -1 := by intro he; rw [he,hv.1] at hy; exact (lt_irrefl _ hy)
    have hh := (P.y_strictMono_negative_tail h hn (-2)
      (P.table1_row_i h hb hd ht hu).2.2).monotone (show 1 ≤ (-k-1).toNat by omega)
    have he : (-2:ℤ)+1-((-k-1).toNat:ℤ)=k := by rw [Int.toNat_of_nonneg (by omega)]; ring
    simpa only [he,Nat.cast_one,show (-2:ℤ)+1-1= -2 by norm_num,hv.2.2.1] using hh

/-- The exact 68.5/sqrt(d) cutoff printed for the norm-minus-four family. -/
theorem lemma51_family_cutoff_revised (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hN : P.normAlpha= -4) (hd : 112 ≤ P.d) :
    P.normalizerSquare=16 ∧
    P.proposition41Threshold=max 1 ((685/10:ℝ)/Real.sqrt P.d) ∧
    P.proposition41Threshold<7 ∧ (7:ℝ)<(P.a:ℝ)^2+1 := by
  have hn : P.normAlpha<0 := by omega
  have hNs : IsSquare (-P.normAlpha) := ⟨2,by norm_num [hN]⟩
  obtain ⟨M,_,_,he,hle⟩ := P.normalizer_integer_revised h hb hn hNs
  have hlow := P.section5_normalizer_ge_sixteen h hb (ne_of_lt hn) (by rw [hN]; norm_num)
  have hM : P.normalizerSquare=16 := by rw [hN] at hle; omega
  have hs4 : Real.sqrt (4:ℝ)=2 := by
    rw [show (4:ℝ)=2^2 by norm_num,Real.sqrt_sq (by norm_num : (0:ℝ)≤2)]
  have hth : P.proposition41Threshold=max 1 ((685/10:ℝ)/Real.sqrt P.d) := by
    simp only [proposition41Threshold,hN,hM]
    norm_num [hs4]
    congr 1
    ring
  have hs : (10:ℝ)<Real.sqrt P.d := by
    apply (Real.lt_sqrt (by norm_num)).mpr
    have hdR : (112:ℝ) ≤ P.d := by exact_mod_cast hd
    norm_num; linarith
  refine ⟨hM,hth,?_,?_⟩
  · rw [hth]
    apply max_lt (by norm_num)
    apply (div_lt_iff₀ (by linarith : 0<Real.sqrt (P.d:ℝ))).mpr
    linarith
  · have hn' := hN
    simp only [normAlpha,hb,one_pow,one_mul] at hn'
    have ha : (108:ℤ) ≤ P.a^2 := by omega
    have haR : (108:ℝ) ≤ (P.a:ℝ)^2 := by exact_mod_cast ha
    linarith

/-- Revised Lemma 5.1 follows its classification, monotonicity, and
Proposition 4.1. It no longer uses the former Ljunggren-based alternative. -/
theorem lemma51_revised (P : Parameters) (hPrior : Hypergeometric.DenominatorEstimate4)
    (hAkhtari : ExternalResults.AkhtariTheorem11) (hCalculation : Calculations.Section46Magma)
    (h : P.Admissible) (hb : P.b=1) (hn : P.normAlpha<0)
    (hNs : IsSquare (-P.normAlpha)) {K : ℤ} (hK : P.IsNegativeCutoff h.pell K)
    (hK1 : K< -1) : AtMostSquareValues (P.y h.pell) 2 := by
  apply Section5.atMost_two_of_unique (P.y_pos h hn)
  intro i j hi hj hi1 hj1
  by_cases hN : P.normAlpha= -1
  · exact P.section46_norm_minus_one hAkhtari h hb hN hi hj hi1 hj1
  by_cases hd : P.d ≤ 111
  · exact P.section46_small_published hAkhtari hCalculation h hb hn hNs hd hi hj hi1 hj1
  have hcase := P.lemma51_cases_published h hb hn hNs hK hK1
  obtain ⟨hdf,ht,hu,_,hN4⟩ := hcase.resolve_right (by
    rintro (⟨_,_,_,_,he⟩ | ⟨_,_,_,_,_,he⟩ | ⟨_,_,_,_,_,he⟩) <;> exact hN he)
  have hc := P.lemma51_family_cutoff_revised h hb hN4 (by omega)
  have above (k : ℤ) (hy : 1<P.y h.pell k) : P.proposition41Threshold<(P.y h.pell k:ℝ) := by
    have hlo : (P.a:ℝ)^2+1 ≤ (P.y h.pell k:ℝ) := by
      exact_mod_cast P.lemma51_family_lower_revised h hb hn hdf ht hu hy
    exact hc.2.2.1.trans (hc.2.2.2.trans_le hlo)
  exact proposition41_published hPrior hAkhtari hCalculation P h hb hn hNs
    i j hi hj (above i hi1) (above j hj1)

end «JNT-2024».Parameters
