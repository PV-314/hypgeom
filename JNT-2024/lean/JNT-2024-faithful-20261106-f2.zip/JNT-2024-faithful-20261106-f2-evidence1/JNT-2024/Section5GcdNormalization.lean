module

public import «JNT-2024».NormalizerBounds
public import «JNT-2024».NormalizerFormula
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».Sequence
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- The common gcd is a square when the negative norm is a square. -/
theorem section5_baseGcd (P : Parameters) (hb : P.b = 1) {n : ℤ}
    (hn : -P.normAlpha = n ^ 2) : P.baseGcd = (Int.gcd P.a n) ^ 2 := by
  have hd : P.d = P.a ^ 2 + n ^ 2 := by
    simp only [normAlpha, hb, one_pow, one_mul] at hn
    linarith
  simp only [baseGcd, hb, one_pow, mul_one, hd, Int.gcd_self_add_right,
    Int.pow_gcd_pow]

/-- Normalize the two coordinates by their positive gcd. -/
theorem section5_normalized_coordinates (P : Parameters) (h : P.Admissible)
    (hb : P.b = 1) {n : ℤ} (hn : -P.normAlpha = n ^ 2) :
    ∃ (g : ℕ) (A b : ℤ), 0 < g ∧ 0 < A ∧ P.a = g * A ∧ n = g * b ∧
      P.baseGcd = g ^ 2 ∧ P.normQuotient = -(b ^ 2) ∧
      P.normalizerSquare = 4 * g ^ 2 * Int.gcd 16 (b ^ 2) ∧ Int.gcd A b = 1 := by
  let g := Int.gcd P.a n
  have hg : 0 < g := Int.gcd_pos_of_ne_zero_left n (ne_of_gt h.a_pos)
  obtain ⟨A, ha⟩ := Int.gcd_dvd_left P.a n
  obtain ⟨b, hnb⟩ := Int.gcd_dvd_right P.a n
  have hA : 0 < A := by
    have hg' : (0 : ℤ) < g := by exact_mod_cast hg
    change P.a = (g : ℤ) * A at ha
    nlinarith [h.a_pos]
  have hG : P.baseGcd = g ^ 2 := P.section5_baseGcd hb hn
  have hq : P.normQuotient = -(b ^ 2) := by
    dsimp [normQuotient]
    rw [hG]
    have he : P.normAlpha = -(b ^ 2) * ((g ^ 2 : ℕ) : ℤ) := by
      change n = (g : ℤ) * b at hnb
      push_cast
      rw [hnb] at hn
      nlinarith only [hn]
    rw [he, Int.mul_ediv_cancel _ (by positivity)]
  refine ⟨g, A, b, hg, hA, ha, hnb, hG, hq, ?_, ?_⟩
  · simp only [normalizerSquare, hG, hq, Int.natAbs_neg,
      Int.gcd_eq_natAbs_gcd_natAbs]
    rfl
  · have he : g = g * Int.gcd A b := by
      calc
        g = Int.gcd P.a n := rfl
        _ = Int.gcd ((g : ℤ) * A) ((g : ℤ) * b) := congrArg₂ Int.gcd ha hnb
        _ = g * Int.gcd A b := by rw [Int.gcd_mul_left, Int.natAbs_natCast]
    nlinarith

end «JNT-2024».Parameters
