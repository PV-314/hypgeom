module

public import «JNT-2024».FourthRootTrig
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

theorem complex_parallelogram (w z : ℂ) :
    ‖w + z‖ ^ 2 + ‖w - z‖ ^ 2 = 2 * ‖w‖ ^ 2 + 2 * ‖z‖ ^ 2 := by
  simp only [Complex.sq_norm, Complex.normSq_add, Complex.normSq_sub]
  ring


/-- Lemma 3.7(a), following the printed product, trigonometric identity
and decreasing-factor argument. The older algebraic proof is archived in the previous complete releases. -/
theorem lemma37a {w z : ℂ} {c : ℝ} (hw : ‖w‖ = 1) (hz : ‖z‖ = 1)
    (hc : 0 < c) (hc2 : c < Real.sqrt 2)
    (hd : 0 < ‖w - z‖) (hdc : ‖w - z‖ < c) :
    (2 - c ^ 2) * Real.sqrt (4 - c ^ 2) * ‖w - z‖ < ‖w ^ 4 - z ^ 4‖ := by
  have htwo := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
  have htwo0 := Real.sqrt_nonneg (2 : ℝ)
  have hcs : c ^ 2 < 2 := by nlinarith
  have hds : ‖w - z‖ ^ 2 < 2 := by nlinarith
  have hs : Real.sqrt (4 - ‖w - z‖ ^ 2) ^ 2 = 4 - ‖w - z‖ ^ 2 :=
    Real.sq_sqrt (by linarith)
  have he : ((2 - ‖w - z‖ ^ 2) * Real.sqrt (4 - ‖w - z‖ ^ 2) * ‖w - z‖) ^ 2 =
      ‖w ^ 4 - z ^ 4‖ ^ 2 := by
    rw [mul_pow, mul_pow, hs, fourth_power_chord_identity_published hw hz]
    ring
  have hnonneg : 0 ≤ (2 - ‖w - z‖ ^ 2) * Real.sqrt (4 - ‖w - z‖ ^ 2) * ‖w - z‖ := by
    positivity
  have heq : (2 - ‖w - z‖ ^ 2) * Real.sqrt (4 - ‖w - z‖ ^ 2) * ‖w - z‖ =
      ‖w ^ 4 - z ^ 4‖ := by nlinarith [norm_nonneg (w ^ 4 - z ^ 4)]
  have hlim : c < Real.sqrt (10 / 3) := by
    have hb := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 10 / 3)
    have hb0 := Real.sqrt_nonneg (10 / 3 : ℝ)
    nlinarith
  have hm := mul_lt_mul_of_pos_right (fourth_expansion_factor_strictAnti hd hdc hlim) hd
  rwa [heq] at hm

/-- The polynomial in Lemma 3.7(b), written as a polynomial in chord length. -/
def fourthChordPolynomial (c x : ℝ) : ℝ := x ^ 8 - 8 * x ^ 6 + 20 * x ^ 4 - 16 * x ^ 2 + c ^ 2

theorem fourthChordPolynomial_eq_squared (c x : ℝ) :
    fourthChordPolynomial c x = fourthChordSquaredPolynomial c (x ^ 2) := by
  unfold fourthChordPolynomial fourthChordSquaredPolynomial
  ring

theorem fourthChordPolynomial_factor (c x : ℝ) :
    fourthChordPolynomial c x = c ^ 2 - x ^ 2 * (2 - x ^ 2) ^ 2 * (4 - x ^ 2) := by
  unfold fourthChordPolynomial
  ring

def FourthPhase (ζ : ℂ) : Prop := ζ = 1 ∨ ζ = -1 ∨ ζ = Complex.I ∨ ζ = -Complex.I

theorem FourthPhase.norm {ζ : ℂ} (h : FourthPhase ζ) : ‖ζ‖ = 1 := by
  rcases h with rfl | rfl | rfl | rfl <;> simp

theorem FourthPhase.pow_four {ζ : ℂ} (h : FourthPhase ζ) : ζ ^ 4 = 1 := by
  rcases h with rfl | rfl | rfl | rfl <;> norm_num [pow_succ, Complex.I_mul_I]

theorem unit_chord_sq {w z : ℂ} (hw : ‖w‖ = 1) (hz : ‖z‖ = 1) :
    ‖w - z‖ ^ 2 = 2 - 2 * (star w * z).re := by
  have hw' : Complex.normSq w = 1 := by rw [Complex.normSq_eq_norm_sq, hw]; norm_num
  have hz' : Complex.normSq z = 1 := by rw [Complex.normSq_eq_norm_sq, hz]; norm_num
  rw [Complex.sq_norm, Complex.normSq_sub, hw', hz']
  simp only [Complex.mul_re, Complex.conj_re, Complex.conj_im, Complex.star_def]
  ring

theorem large_coordinate {a b : ℝ} (he : a ^ 2 + b ^ 2 = 1) (ha : 0 ≤ a) (hb : |b| ≤ a) :
    Real.sqrt 2 ≤ 2 * a := by
  have hh : b ^ 2 ≤ a ^ 2 := by nlinarith [sq_abs b, abs_nonneg b]
  have hs := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
  have hs0 := Real.sqrt_nonneg (2 : ℝ)
  nlinarith

theorem exists_large_quarter_turn {z : ℂ} (hz : ‖z‖ = 1) :
    ∃ ζ : ℂ, FourthPhase ζ ∧ Real.sqrt 2 ≤ 2 * (ζ * z).re := by
  have he : z.re ^ 2 + z.im ^ 2 = 1 := by
    have hh := Complex.sq_norm z
    rw [hz, Complex.normSq_apply] at hh
    nlinarith only [hh]
  by_cases hri : |z.im| ≤ |z.re|
  · by_cases hr : 0 ≤ z.re
    · refine ⟨1, Or.inl rfl, ?_⟩
      simpa only [one_mul] using large_coordinate he hr (by simpa [abs_of_nonneg hr] using hri)
    · refine ⟨-1, Or.inr (Or.inl rfl), ?_⟩
      have hh := large_coordinate (a := -z.re) (b := z.im) (by nlinarith only [he]) (by linarith)
        (by simpa [abs_of_nonpos (by linarith : z.re ≤ 0)] using hri)
      simpa using hh
  · have hir : |z.re| ≤ |z.im| := by linarith
    by_cases hi : 0 ≤ z.im
    · refine ⟨-Complex.I, Or.inr (Or.inr (Or.inr rfl)), ?_⟩
      have hh := large_coordinate (a := z.im) (b := z.re) (by linarith only [he]) hi
        (by simpa [abs_of_nonneg hi] using hir)
      simpa using hh
    · refine ⟨Complex.I, Or.inr (Or.inr (Or.inl rfl)), ?_⟩
      have hh := large_coordinate (a := -z.im) (b := z.re) (by nlinarith only [he]) (by linarith)
        (by simpa [abs_of_nonpos (by linarith : z.im ≤ 0)] using hir)
      simpa using hh

theorem exists_near_fourth_phase {w z : ℂ} (hw : ‖w‖ = 1) (hz : ‖z‖ = 1) :
    ∃ ζ : ℂ, FourthPhase ζ ∧ ‖w - ζ * z‖ ^ 2 ≤ 2 - Real.sqrt 2 := by
  have hq : ‖star w * z‖ = 1 := by simp [hw, hz]
  obtain ⟨ζ, hζ, hh⟩ := exists_large_quarter_turn hq
  refine ⟨ζ, hζ, ?_⟩
  have hv : ‖ζ * z‖ = 1 := by rw [norm_mul, hζ.norm, hz, mul_one]
  rw [unit_chord_sq hw hv]
  have he : star w * (ζ * z) = ζ * (star w * z) := by ring
  rw [he]
  linarith

/-- The literal minimum over the four phases in (3.20), with the nearest-phase
range needed for the smallest-root selection. -/
theorem exists_minimizing_fourth_phase {w z : ℂ} (hw : ‖w‖ = 1) (hz : ‖z‖ = 1) :
    ∃ ζ : ℂ, FourthPhase ζ ∧ ‖w - ζ * z‖ ^ 2 ≤ 2 - Real.sqrt 2 ∧
      ∀ η : ℂ, FourthPhase η → ‖w - ζ * z‖ ≤ ‖w - η * z‖ := by
  classical
  let S : Finset ℂ := {1, -1, Complex.I, -Complex.I}
  have hS (η : ℂ) : η ∈ S ↔ FourthPhase η := by simp [S, FourthPhase]
  obtain ⟨ζ, hζ, hmin⟩ := S.exists_min_image (fun η => ‖w - η * z‖) (by simp [S])
  obtain ⟨η, hη, hnear⟩ := exists_near_fourth_phase hw hz
  have hh := hmin η ((hS η).mpr hη)
  refine ⟨ζ, (hS ζ).mp hζ, ?_, fun η hη => hmin η ((hS η).mpr hη)⟩
  exact le_trans (pow_le_pow_left₀ (norm_nonneg _) hh 2) hnear

def fourthChordMap (t : ℝ) : ℝ := t * (2 - t) ^ 2 * (4 - t)

theorem fourthChordMap_complement (t : ℝ) :
    fourthChordMap t = 4 - ((2 - t) ^ 2 - 2) ^ 2 := by unfold fourthChordMap; ring

theorem fourthChordMap_strict {x y : ℝ} (hxy : x < y) (hy : y ≤ 2 - Real.sqrt 2) :
    fourthChordMap x < fourthChordMap y := by
  have hs := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
  have hs0 := Real.sqrt_nonneg (2 : ℝ)
  have hy0 : 0 ≤ (2 - y) ^ 2 - 2 := by nlinarith
  have hxy' : (2 - y) ^ 2 - 2 < (2 - x) ^ 2 - 2 := by nlinarith
  rw [fourthChordMap_complement, fourthChordMap_complement]
  nlinarith

/-- The smallest positive root in Lemma 3.7(b), given explicitly. -/
noncomputable def fourthRootRadius (c : ℝ) : ℝ := Real.sqrt (2 - Real.sqrt (2 + Real.sqrt (4 - c ^ 2)))

theorem fourthRootRadius_properties {c : ℝ} (hc : 0 < c) (hc2 : c ≤ 2) :
    0 < fourthRootRadius c ∧ (fourthRootRadius c) ^ 2 ≤ 2 - Real.sqrt 2 ∧
      fourthChordMap ((fourthRootRadius c) ^ 2) = c ^ 2 := by
  have h0 : 0 ≤ 4 - c ^ 2 := by nlinarith
  have hs := Real.sq_sqrt h0
  have hs0 := Real.sqrt_nonneg (4 - c ^ 2)
  have hslt : Real.sqrt (4 - c ^ 2) < 2 := by nlinarith
  have ht := Real.sq_sqrt (show 0 ≤ 2 + Real.sqrt (4 - c ^ 2) by positivity)
  have ht0 := Real.sqrt_nonneg (2 + Real.sqrt (4 - c ^ 2))
  have htlt : Real.sqrt (2 + Real.sqrt (4 - c ^ 2)) < 2 := by nlinarith
  have htle := Real.sqrt_le_sqrt (show (2 : ℝ) ≤ 2 + Real.sqrt (4 - c ^ 2) by linarith)
  have hr : fourthRootRadius c ^ 2 = 2 - Real.sqrt (2 + Real.sqrt (4 - c ^ 2)) :=
    Real.sq_sqrt (by linarith)
  refine ⟨Real.sqrt_pos.mpr (by linarith), ?_, ?_⟩
  · rw [hr]; linarith
  · rw [hr, fourthChordMap_complement]
    have he : (2 - (2 - Real.sqrt (2 + Real.sqrt (4 - c ^ 2)))) ^ 2 - 2 =
        Real.sqrt (4 - c ^ 2) := by nlinarith only [ht]
    rw [he]
    linarith

theorem fourthRootRadius_is_least_root {c : ℝ} (hc : 0 < c) (hc2 : c ≤ 2) :
    fourthChordPolynomial c (fourthRootRadius c) = 0 ∧
      ∀ x : ℝ, 0 < x → fourthChordPolynomial c x = 0 → fourthRootRadius c ≤ x := by
  obtain ⟨hr, hlim, he⟩ := fourthRootRadius_properties hc hc2
  have hf (x : ℝ) : fourthChordPolynomial c x = c ^ 2 - fourthChordMap (x ^ 2) :=
    fourthChordPolynomial_factor c x
  constructor
  · rw [hf, he, sub_self]
  · intro x hx hxroot
    by_contra hn
    have hxs : x ^ 2 < fourthRootRadius c ^ 2 := by nlinarith
    have hh := fourthChordMap_strict hxs hlim
    rw [he] at hh
    rw [hf] at hxroot
    linarith

/-- Monotonicity of the least positive root as c increases, including c=2. -/
theorem fourthRootRadius_strictMono {c d : ℝ} (hc : 0 < c) (hcd : c < d) (hd : d ≤ 2) :
    fourthRootRadius c < fourthRootRadius d := by
  obtain ⟨hcr, hclim, hce⟩ := fourthRootRadius_properties hc (le_trans (le_of_lt hcd) hd)
  obtain ⟨hdr, hdlim, hde⟩ := fourthRootRadius_properties (lt_trans hc hcd) hd
  by_contra hn
  have hs : fourthRootRadius d ^ 2 ≤ fourthRootRadius c ^ 2 := by nlinarith
  rcases lt_or_eq_of_le hs with hh | hh
  · have hm := fourthChordMap_strict hh hclim
    rw [hce, hde] at hm
    nlinarith
  · rw [hh, hce] at hde
    nlinarith

/-- The chosen nearest phase gives the smallest positive root, not another
positive root of the degree-eight polynomial. -/
theorem fourthRootRadius_eq_of_chord {c x : ℝ} (hc : 0 < c) (hc2 : c ≤ 2)
    (hx : 0 < x) (hlim : x ^ 2 ≤ 2 - Real.sqrt 2)
    (he : fourthChordMap (x ^ 2) = c ^ 2) : x = fourthRootRadius c := by
  obtain ⟨hr, hrlim, hre⟩ := fourthRootRadius_properties hc hc2
  have hs : x ^ 2 = fourthRootRadius c ^ 2 := by
    rcases lt_trichotomy (x ^ 2) (fourthRootRadius c ^ 2) with hh | hh | hh
    · have hm := fourthChordMap_strict hh hrlim
      rw [he, hre] at hm
      exact False.elim (lt_irrefl _ hm)
    · exact hh
    · have hm := fourthChordMap_strict hh hlim
      rw [he, hre] at hm
      exact False.elim (lt_irrefl _ hm)
  nlinarith

end «JNT-2024»
