module

public import «JNT-2024».ComplexRepresentation
public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».Sequence
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»

theorem abs_arg_le_abs_tan {z : ℂ} (hz : 0 < z.re) : |z.arg| ≤ |Real.tan z.arg| := by
  have hh := Complex.abs_arg_lt_pi_div_two_iff.mpr (Or.inl hz)
  have he := Real.arctan_tan (abs_lt.mp hh).1 (abs_lt.mp hh).2
  simpa only [he] using (Real.abs_arctan_le_abs (x := Real.tan z.arg))

noncomputable def conjugateRatio (x z : ℝ) : ℂ := (⟨x, z⟩ : ℂ) / star (⟨x, z⟩ : ℂ)

theorem conjugateRatio_norm {x z : ℝ} (hz : z ≠ 0) : ‖conjugateRatio x z‖ = 1 := by
  have hne : (⟨x, z⟩ : ℂ) ≠ 0 := by
    intro he
    exact hz (congrArg Complex.im he)
  rw [conjugateRatio, norm_div, norm_star, div_self (norm_ne_zero_iff.mpr hne)]

theorem conjugateRatio_re (x z : ℝ) : (conjugateRatio x z).re = (x ^ 2 - z ^ 2) / (x ^ 2 + z ^ 2) := by
  simp [conjugateRatio, Complex.div_re, Complex.normSq_apply, pow_two]
  ring

theorem conjugateRatio_im (x z : ℝ) : (conjugateRatio x z).im = 2 * x * z / (x ^ 2 + z ^ 2) := by
  simp [conjugateRatio, Complex.div_im, Complex.normSq_apply, pow_two]
  ring


theorem conjugateRatio_argument_bound {x z : ℝ} (hz : z ≠ 0) (hlarge : 15 * z ^ 2 ≤ x ^ 2) :
    |(conjugateRatio x z).arg| < (229 / 100 : ℝ) * |z| / |x| ∧
      (229 / 100 : ℝ) * |z| / |x| < 3 / 5 := by
  have hzs : 0 < z ^ 2 := sq_pos_of_ne_zero hz
  have hxs : 0 < x ^ 2 := by nlinarith
  have hx : x ≠ 0 := by intro he; simp [he] at hxs
  have hsum : 0 < x ^ 2 + z ^ 2 := by positivity
  have hdiff : 0 < x ^ 2 - z ^ 2 := by nlinarith
  have harg := abs_arg_le_abs_tan (z := conjugateRatio x z) (by
    rw [conjugateRatio_re]; exact div_pos hdiff hsum)
  have htan : |Real.tan (conjugateRatio x z).arg| = 2 * |x| * |z| / (x ^ 2 - z ^ 2) := by
    rw [Complex.tan_arg, conjugateRatio_re, conjugateRatio_im]
    have he : (2 * x * z / (x ^ 2 + z ^ 2)) / ((x ^ 2 - z ^ 2) / (x ^ 2 + z ^ 2)) =
        2 * x * z / (x ^ 2 - z ^ 2) := by field_simp
    rw [he, abs_div, abs_mul, abs_mul, abs_of_pos hdiff]
    norm_num
  have hxp := abs_pos.mpr hx
  have hzp := abs_pos.mpr hz
  have hseven : (7 / 8 : ℝ) * (x ^ 2 + z ^ 2) ≤ x ^ 2 - z ^ 2 := by
    nlinarith only [hlarge]
  have hseven_strict : (7 / 8 : ℝ) * x ^ 2 < (7 / 8 : ℝ) * (x ^ 2 + z ^ 2) := by
    nlinarith only [hzs]
  have hstrict : 2 * |x| * |z| / (x ^ 2 - z ^ 2) < (229 / 100 : ℝ) * |z| / |x| := by
    calc
      _ < 2 * |x| * |z| / ((7 / 8 : ℝ) * x ^ 2) :=
        div_lt_div_of_pos_left (by positivity) (by positivity) (lt_of_lt_of_le hseven_strict hseven)
      _ < _ := by
        apply (div_lt_div_iff₀ (by positivity) hxp).mpr
        rw [← sq_abs x]
        have hm : 0 < |x| ^ 2 * |z| := by positivity
        nlinarith only [hm]
  refine ⟨lt_of_le_of_lt (by simpa only [htan] using harg) hstrict, ?_⟩
  have hr : 0 < Real.sqrt 15 := Real.sqrt_pos.mpr (by norm_num)
  have hrs : Real.sqrt 15 ^ 2 = 15 := Real.sq_sqrt (by norm_num)
  have hsx : |x| ^ 2 = x ^ 2 := sq_abs x
  have hsz : |z| ^ 2 = z ^ 2 := sq_abs z
  have hroot : Real.sqrt 15 * |z| ≤ |x| := by
    nlinarith only [hlarge, hrs, hsx, hsz, hxp, hzp, hr,
      sq_nonneg (Real.sqrt 15 * |z| - |x|)]
  calc
    _ ≤ (229 / 100 : ℝ) / Real.sqrt 15 := by
      apply (div_le_div_iff₀ hxp hr).mpr
      nlinarith only [hroot]
    _ < 3 / 5 := by
      apply (div_lt_iff₀ hr).mpr
      nlinarith only [hrs, hr]

noncomputable def principalFourthRoot (ω : ℂ) : ℂ := Complex.exp (Complex.I * (ω.arg / 4 : ℝ))

theorem principalFourthRoot_norm (ω : ℂ) : ‖principalFourthRoot ω‖ = 1 :=
  Complex.norm_exp_I_mul_ofReal _

theorem principalFourthRoot_pow_four {ω : ℂ} (hω : ‖ω‖ = 1) : principalFourthRoot ω ^ 4 = ω := by
  rw [principalFourthRoot, ← Complex.exp_nat_mul]
  have he := Complex.norm_mul_exp_arg_mul_I ω
  rw [hω, Complex.ofReal_one, one_mul] at he
  convert he using 1
  congr 1
  push_cast
  ring

theorem principalFourthRoot_close {ω : ℂ} (harg : |ω.arg| < 3 / 5) :
    ‖principalFourthRoot ω - 1‖ < 3 / 20 := by
  have hh := Real.norm_exp_I_mul_ofReal_sub_one_le (x := ω.arg / 4)
  dsimp [principalFourthRoot]
  have habs : ‖ω.arg / 4‖ < 3 / 20 := by rw [Real.norm_eq_abs, abs_div]; norm_num; linarith
  exact lt_of_le_of_lt hh habs

namespace Parameters

theorem epsilonNorm_zpow_sign (P : Parameters) (hp : P.Pell) (k : ℤ) :
    P.epsilonNorm ^ k = 1 ∨ P.epsilonNorm ^ k = -1 := by
  rcases P.pell_iff_epsilonNorm.mp hp with hh | hh
  · simp [hh]
  · rw [hh, neg_one_zpow_eq_ite]
    split_ifs <;> simp

noncomputable def sequenceOmega (P : Parameters) (hp : P.Pell) (k : ℤ) : ℂ :=
  conjugateRatio (P.x hp k) ((P.epsilonNorm ^ k : ℚ) * P.negativeNormRoot)

theorem sequenceOmega_norm (P : Parameters) (hp : P.Pell) (hn : P.normAlpha < 0) (k : ℤ) :
    ‖P.sequenceOmega hp k‖ = 1 := by
  have hr := ne_of_gt (P.negativeNormRoot_pos hn)
  rcases P.epsilonNorm_zpow_sign hp k with he | he
  · simpa [sequenceOmega, he] using (conjugateRatio_norm (x := (P.x hp k : ℝ)) hr)
  · simpa [sequenceOmega, he] using (conjugateRatio_norm (x := (P.x hp k : ℝ)) (neg_ne_zero.mpr hr))

theorem large_term_coordinate_bound (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    {k : ℤ} (hlarge : 4 * Real.sqrt (|(P.normAlpha : ℝ)| / P.d) ≤ (P.y h.pell k : ℝ)) :
    15 * P.negativeNormRoot ^ 2 ≤ (P.x h.pell k : ℝ) ^ 2 := by
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have ht := P.gapScale_pos h.b_pos hn
  rw [← P.gapScale_eq_sqrt h.b_pos hn] at hlarge
  have hs := pow_le_pow_left₀ (show 0 ≤ 4 * P.gapScale by positivity) hlarge 2
  have hm := mul_le_mul_of_nonneg_left hs hd.le
  have ht2 : (P.d : ℝ) * P.gapScale ^ 2 = -(P.normAlpha : ℝ) := by
    rw [P.gapScale_sq h.b_pos hn]
    field_simp
  have he : (P.x h.pell k : ℝ) ^ 2 - P.d * (P.y h.pell k : ℝ) ^ 2 = P.normAlpha := by
    exact_mod_cast P.norm_identity h.pell k
  rw [P.negativeNormRoot_sq hn]
  nlinarith only [hm, ht2, he]

/-- Lemma 3.9(a). Squarehood is not needed for the argument estimate. -/
theorem lemma39a (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) {k : ℤ}
    (hlarge : 4 * Real.sqrt (|(P.normAlpha : ℝ)| / P.d) ≤ (P.y h.pell k : ℝ)) :
    |(P.sequenceOmega h.pell k).arg| < (229 / 100 : ℝ) * Real.sqrt |(P.normAlpha : ℝ)| / |(P.x h.pell k : ℝ)| ∧
      (229 / 100 : ℝ) * Real.sqrt |(P.normAlpha : ℝ)| / |(P.x h.pell k : ℝ)| < 3 / 5 := by
  have hr := P.negativeNormRoot_pos hn
  have hn' : (P.normAlpha : ℝ) < 0 := by exact_mod_cast hn
  have he : P.negativeNormRoot = Real.sqrt |(P.normAlpha : ℝ)| := by
    rw [abs_of_neg hn', ← P.negativeNormRoot_sq hn, Real.sqrt_sq hr.le]
  have hcoords := P.large_term_coordinate_bound h hn hlarge
  have hs := P.epsilonNorm_zpow_sign h.pell k
  rcases hs with hs | hs
  · have hh := conjugateRatio_argument_bound (ne_of_gt hr) hcoords
    simpa [sequenceOmega, hs, abs_of_pos hr, he, abs_of_nonneg (Real.sqrt_nonneg _)] using hh
  · have hh := conjugateRatio_argument_bound (neg_ne_zero.mpr (ne_of_gt hr))
      (by simpa only [neg_sq] using hcoords)
    simpa [sequenceOmega, hs, abs_of_pos hr, he, abs_of_nonneg (Real.sqrt_nonneg _)] using hh

end Parameters
end «JNT-2024»
