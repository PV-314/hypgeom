module

public import «JNT-2024».Sequence
public import «JNT-2024».UnitGcdStepsPublished
public import «JNT-2024».UnitIntegralityCases
public import «JNT-2024».UnitParityPublished
public import «JNT-2024».UnitPowers
public import «JNT-2024».UnitSequenceIntegrality
public import «JNT-2024».UnitSequencePublished
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

theorem unit_gcd_zero (P : Parameters) (A B : ℤ) {X Y : ℤ}
    (hx : P.unitX A B 0 = X) (hy : P.unitY A B 0 = Y) :
    Int.gcd X Y = Int.gcd A B := by
  have h := P.unit_coordinates_zero A B
  have hX : X = A := by exact_mod_cast hx.symm.trans h.1
  have hY : Y = B := by exact_mod_cast hy.symm.trans h.2
  simp [hX, hY]

/-- The complete descent in printed case (i). -/
theorem unit_gcd_even_even (P : Parameters) (hp : P.Pell) (ht : Even P.t) (hu : Even P.u)
    (A B : ℤ) (n : ℕ) {X Y : ℤ}
    (hx : P.unitX A B n = X) (hy : P.unitY A B n = Y) :
    Int.gcd X Y ∣ Int.gcd A B := by
  induction n generalizing X Y with
  | zero => rw [P.unit_gcd_zero A B hx hy]
  | succ n ih =>
    obtain ⟨⟨X₀,hx₀⟩,⟨Y₀,hy₀⟩⟩ := P.unit_integral_even_even hp ht hu A B n
    exact (P.unit_gcd_step_one hp ht hu A B n hx hy hx₀ hy₀).trans (ih hx₀ hy₀)

/-- The complete descent along multiples of three in printed case (ii-a). -/
theorem unit_gcd_odd_odd_opposite (P : Parameters) (hp : P.Pell) (ht : Odd P.t) (hu : Odd P.u)
    (A B : ℤ) (hab : (Even A ∧ Odd B) ∨ (Odd A ∧ Even B)) (n : ℕ) {X Y : ℤ}
    (hx : P.unitX A B n = X) (hy : P.unitY A B n = Y) :
    Int.gcd X Y ∣ Int.gcd A B := by
  induction n using Nat.strong_induction_on generalizing X Y with
  | h n ih =>
    have hn := (P.unit_integral_odd_odd_opposite hp ht hu A B hab n).1.mp ⟨X,hx⟩
    by_cases hz : n = 0
    · subst n; rw [P.unit_gcd_zero A B hx hy]
    have hn3 : 3 ≤ n := Nat.le_of_dvd (Nat.pos_of_ne_zero hz) hn
    have hn' : n - 3 + 3 = n := by omega
    have hd : 3 ∣ n - 3 := by omega
    have hi := P.unit_integral_odd_odd_opposite hp ht hu A B hab (n - 3)
    obtain ⟨X₀,hx₀⟩ := hi.1.mpr hd
    obtain ⟨Y₀,hy₀⟩ := hi.2.mpr hd
    have hh := P.unit_gcd_step_three hp ht hu A B (n - 3)
      (by simpa [hn'] using hx) (by simpa [hn'] using hy) hx₀ hy₀
    exact hh.trans (ih (n - 3) (by omega) hx₀ hy₀)

/-- The two-step descent, including the integral index-one case, in printed case (iii). -/
theorem unit_gcd_even_odd (P : Parameters) (hp : P.Pell) (ht : Even P.t) (hu : Odd P.u)
    (A B : ℤ) (n : ℕ) {X Y : ℤ}
    (hx : P.unitX A B n = X) (hy : P.unitY A B n = Y) :
    Int.gcd X Y ∣ 2 * Int.gcd A B := by
  induction n using Nat.strong_induction_on generalizing X Y with
  | h n ih =>
    by_cases hz : n = 0
    · subst n; rw [P.unit_gcd_zero A B hx hy]; exact dvd_mul_left _ _
    by_cases ho : n = 1
    · subst n
      exact P.unit_gcd_one_dvd_two hp A B 0 hx hy
        (P.unit_coordinates_zero A B).1 (P.unit_coordinates_zero A B).2
    have hn' : n - 2 + 2 = n := by omega
    have hi := P.unit_integral_even_odd hp ht hu A B (n - 2)
    have hh := (P.unit_integral_even_odd hp ht hu A B n).2.mp ⟨Y,hy⟩
    have he : Even A ∨ Even (n - 2) := by
      rcases hh with hh | hh
      · exact Or.inl hh
      · exact Or.inr (Nat.even_iff.mpr (by rw [Nat.even_iff] at hh; omega))
    obtain ⟨X₀,hx₀⟩ := hi.1
    obtain ⟨Y₀,hy₀⟩ := hi.2.mpr he
    have hh := P.unit_gcd_step_two hp ht hu A B (n - 2)
      (by simpa [hn'] using hx) (by simpa [hn'] using hy) hx₀ hy₀
    exact hh.trans (ih (n - 2) (by omega) hx₀ hy₀)

end «JNT-2024».Parameters

namespace «JNT-2024»

/-- The two parity branches at index two in case (ii-b), for either coordinate. -/
theorem gcd_two_steps_odd_initial {G₀ G₁ G₂ : ℕ} {t ν c₀ c₁ c₂ : ℤ}
    (hν : Odd ν) (hc₀ : Odd c₀) (hc₂ : c₂ = t * c₁ - ν * c₀)
    (h₁ : G₁ ∣ 2 * G₀) (h₂ : G₂ ∣ 2 * G₁)
    (hd₁ : G₁ ∣ c₁.natAbs) (hd₂ : G₂ ∣ c₂.natAbs) : G₂ ∣ 2 * G₀ := by
  rcases Int.even_or_odd c₁ with he | ho
  · have ho₂ : Odd c₂ := hc₂ ▸ (he.mul_left t).sub_odd (hν.mul hc₀)
    have hg₂ := ho₂.natAbs.of_dvd_nat hd₂
    exact (hg₂.coprime_two_right.dvd_of_dvd_mul_left h₂).trans h₁
  · have hg₁ := ho.natAbs.of_dvd_nat hd₁
    exact h₂.trans (Nat.mul_dvd_mul_left 2 (hg₁.coprime_two_right.dvd_of_dvd_mul_left h₁))

namespace Parameters

theorem unit_gcd_index_two (P : Parameters) (hp : P.Pell) (A B : ℤ)
    (hab : Odd A ∨ Odd B) {X₁ Y₁ X₂ Y₂ : ℤ}
    (hx₁ : P.unitX A B 1 = X₁) (hy₁ : P.unitY A B 1 = Y₁)
    (hx₂ : P.unitX A B 2 = X₂) (hy₂ : P.unitY A B 2 = Y₂) :
    Int.gcd X₂ Y₂ ∣ 2 * Int.gcd A B := by
  have h₁ := P.unit_gcd_one_dvd_two hp A B 0 hx₁ hy₁
    (P.unit_coordinates_zero A B).1 (P.unit_coordinates_zero A B).2
  have h₂ := P.unit_gcd_one_dvd_two hp A B 1 hx₂ hy₂ hx₁ hy₁
  obtain ⟨ν,hνs,hν,_⟩ := P.unit_norm_integer_sign hp
  have hνo : Odd ν := by rcases hνs with rfl | rfl <;> decide
  rcases hab with ha | hb
  · have hr := P.unitX_recurrence A B 0
    rw [hx₂, hx₁, (P.unit_coordinates_zero A B).1, ← hν] at hr
    have hr' : X₂ = P.t * X₁ - ν * A := by exact_mod_cast hr
    exact gcd_two_steps_odd_initial hνo ha hr' h₁ h₂
      (Nat.gcd_dvd_left _ _) (Nat.gcd_dvd_left _ _)
  · have hr := P.unitY_recurrence A B 0
    rw [hy₂, hy₁, (P.unit_coordinates_zero A B).2, ← hν] at hr
    have hr' : Y₂ = P.t * Y₁ - ν * B := by exact_mod_cast hr
    exact gcd_two_steps_odd_initial hνo hb hr' h₁ h₂
      (Nat.gcd_dvd_right _ _) (Nat.gcd_dvd_right _ _)

/-- The three residue classes and both index-two parity branches in case (ii-b). -/
theorem unit_gcd_odd_odd_same (P : Parameters) (hp : P.Pell) (ht : Odd P.t) (hu : Odd P.u)
    (A B : ℤ) (ha : Odd A) (hb : Odd B) (n : ℕ) {X Y : ℤ}
    (hx : P.unitX A B n = X) (hy : P.unitY A B n = Y) :
    Int.gcd X Y ∣ 2 * Int.gcd A B := by
  induction n using Nat.strong_induction_on generalizing X Y with
  | h n ih =>
    by_cases hz : n = 0
    · subst n; rw [P.unit_gcd_zero A B hx hy]; exact dvd_mul_left _ _
    by_cases ho : n = 1
    · subst n
      exact P.unit_gcd_one_dvd_two hp A B 0 hx hy
        (P.unit_coordinates_zero A B).1 (P.unit_coordinates_zero A B).2
    by_cases ht₂ : n = 2
    · subst n
      obtain ⟨⟨X₁,hx₁⟩,⟨Y₁,hy₁⟩⟩ := P.unit_integral_odd_odd_same hp ht hu A B ha hb 1
      exact P.unit_gcd_index_two hp A B (Or.inl ha) hx₁ hy₁ hx hy
    have hn' : n - 3 + 3 = n := by omega
    obtain ⟨⟨X₀,hx₀⟩,⟨Y₀,hy₀⟩⟩ := P.unit_integral_odd_odd_same hp ht hu A B ha hb (n - 3)
    have hh := P.unit_gcd_step_three hp ht hu A B (n - 3)
      (by simpa [hn'] using hx) (by simpa [hn'] using hy) hx₀ hy₀
    exact hh.trans (ih (n - 3) (by omega) hx₀ hy₀)

/-- Assembly of all four printed cases after the paper's coprime normalization. -/
theorem unit_gcd_coprime_published (P : Parameters) (hp : P.Pell) (A B : ℤ)
    (hab : Int.gcd A B = 1) (n : ℕ) {X Y : ℤ}
    (hx : P.unitX A B n = X) (hy : P.unitY A B n = Y) :
    Int.gcd X Y = 1 ∨ Int.gcd X Y = 2 := by
  apply (Nat.dvd_prime Nat.prime_two).mp
  have hbound : Int.gcd X Y ∣ 2 * Int.gcd A B := by
    rcases Int.even_or_odd P.t with ht | ht <;> rcases Int.even_or_odd P.u with hu | hu
    · exact (P.unit_gcd_even_even hp ht hu A B n hx hy).trans (dvd_mul_left _ _)
    · exact P.unit_gcd_even_odd hp ht hu A B n hx hy
    · exact (P.unit_not_odd_even hp ht hu).elim
    · rcases Int.even_or_odd A with ha | ha <;> rcases Int.even_or_odd B with hb | hb
      · have hd : (2 : ℕ) ∣ Int.gcd A B :=
          Int.dvd_gcd (even_iff_two_dvd.mp ha) (even_iff_two_dvd.mp hb)
        norm_num [hab] at hd
      · exact (P.unit_gcd_odd_odd_opposite hp ht hu A B (Or.inl ⟨ha,hb⟩) n hx hy).trans (dvd_mul_left _ _)
      · exact (P.unit_gcd_odd_odd_opposite hp ht hu A B (Or.inr ⟨ha,hb⟩) n hx hy).trans (dvd_mul_left _ _)
      · exact P.unit_gcd_odd_odd_same hp ht hu A B ha hb n hx hy
  simpa [hab] using hbound

end Parameters
end «JNT-2024»
