module

public import «JNT-2024».Integrality
public import «JNT-2024».Monotonicity
public import «JNT-2024».Sequence
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- The five rows of Table 1 in Lemma 3.6, in their printed order.
The assumptions `a>0` and `b=1` are supplied to the classification theorem. -/
def LowNeighborCases (P : Parameters) : Prop :=
  (P.d = P.a ^ 2 + 4 ∧ P.t = P.a ∧ P.u = 1) ∨
  (P.d = P.a ^ 2 + 1 ∧ P.t = 2 * P.a ∧ P.u = 2) ∨
  (P.a = 3 ∧ P.d = 12 ∧ P.t = 4 ∧ P.u = 1) ∨
  (P.a = 2 ∧ P.d = 5 ∧ P.t = 3 ∧ P.u = 1) ∨
  (P.a = 2 ∧ P.d = 5 ∧ P.t = 1 ∧ P.u = 1)

/-- The integer inequality driving the exhaustive classification in Lemma 3.6. -/
theorem low_neighbor_inequality (P : Parameters) (h : P.Pell) (hb : P.b = 1)
    (hy : P.y h (-1) ≤ 1) :
    (P.t - P.a * P.u) ^ 2 + (P.d - P.a ^ 2) * P.u ^ 2 ≤ 4 := by
  rw [P.y_neg_one, hb] at hy
  norm_num at hy
  have hq : ((P.t : ℚ) - P.a * P.u) ^ 2 +
      ((P.d : ℚ) - (P.a : ℚ) ^ 2) * (P.u : ℚ) ^ 2 ≤ 4 := by nlinarith
  exact_mod_cast hq

/-- Necessity: there are no cases missing from Table 1. -/
theorem low_neighbor_cases_of_le_one (P : Parameters) (h : P.Admissible)
    (hb : P.b = 1) (hn : P.normAlpha < 0) (hy : P.y h.pell (-1) ≤ 1) :
    P.LowNeighborCases := by
  have hmain := P.low_neighbor_inequality h.pell hb hy
  have hD : 1 ≤ P.d - P.a ^ 2 := by
    simp only [normAlpha, hb, one_pow, one_mul] at hn
    omega
  have huPos := h.u_pos
  have htPos := h.t_pos
  have haPos := h.a_pos
  have hmul := mul_nonneg (sub_nonneg.mpr hD) (sq_nonneg P.u)
  have huBound : P.u ≤ 2 := by nlinarith [sq_nonneg (P.t - P.a * P.u)]
  have huCases : P.u = 1 ∨ P.u = 2 := by omega
  rcases huCases with hu | hu
  · rw [hu] at hmain
    norm_num at hmain
    have hdiff : -1 ≤ P.t - P.a ∧ P.t - P.a ≤ 1 := by constructor <;> nlinarith
    have htCases : P.t = P.a - 1 ∨ P.t = P.a ∨ P.t = P.a + 1 := by omega
    rcases htCases with ht | ht | ht
    · rw [ht] at hmain htPos
      have ha : P.a = 2 := by
        rcases h.pell with hp | hp <;> rw [hu, ht] at hp <;> norm_num at hp <;> nlinarith
      have hd : P.d = 5 := by
        rcases h.pell with hp | hp <;> rw [hu, ht, ha] at hp <;> norm_num at hp <;>
          nlinarith [sq_nonneg P.a]
      exact Or.inr (Or.inr (Or.inr (Or.inr ⟨ha, hd, by omega, hu⟩)))
    · rw [ht] at hmain htPos
      have hd : P.d = P.a ^ 2 + 4 := by
        rcases h.pell with hp | hp <;> rw [hu, ht] at hp <;> norm_num at hp <;> omega
      exact Or.inl ⟨hd, ht, hu⟩
    · rw [ht] at hmain htPos
      have ha : P.a = 2 ∨ P.a = 3 := by
        have hlo : 2 ≤ P.a := by
          rcases h.pell with hp | hp <;> rw [hu, ht] at hp <;> norm_num at hp <;> nlinarith
        have hhi : P.a ≤ 3 := by
          rcases h.pell with hp | hp <;> rw [hu, ht] at hp <;> norm_num at hp <;> nlinarith
        omega
      rcases ha with ha | ha
      · have hd : P.d = 5 := by
          rcases h.pell with hp | hp <;> rw [hu, ht, ha] at hp <;> norm_num at hp <;> nlinarith
        exact Or.inr (Or.inr (Or.inr (Or.inl ⟨ha, hd, by omega, hu⟩)))
      · have hd : P.d = 12 := by
          rcases h.pell with hp | hp <;> rw [hu, ht, ha] at hp <;> norm_num at hp <;> nlinarith
        exact Or.inr (Or.inr (Or.inl ⟨ha, hd, by omega, hu⟩))
  · rw [hu] at hmain
    have hd : P.d = P.a ^ 2 + 1 := by nlinarith [sq_nonneg (P.t - 2 * P.a)]
    have ht : P.t = 2 * P.a := by
      have heq : (P.t - 2 * P.a) ^ 2 = 0 := by nlinarith
      have hh := (sq_eq_zero_iff).mp heq
      linarith
    exact Or.inr (Or.inl ⟨hd, ht, hu⟩)

/-- Sufficiency, verifying that each of the five rows has `y₋₁≤1`. -/
theorem low_neighbor_le_one_of_cases (P : Parameters) (h : P.Pell)
    (hb : P.b = 1) (hc : P.LowNeighborCases) : P.y h (-1) ≤ 1 := by
  rw [P.y_neg_one, hb]
  rcases hc with ⟨hd, ht, hu⟩ | ⟨hd, ht, hu⟩ | ⟨ha, hd, ht, hu⟩ |
    ⟨ha, hd, ht, hu⟩ | ⟨ha, hd, ht, hu⟩
  · norm_num [hd, ht, hu]
    ring_nf
    norm_num
  · norm_num [hd, ht, hu]
    ring_nf
    norm_num
  · norm_num [ha, hd, ht, hu]
  · norm_num [ha, hd, ht, hu]
  · norm_num [ha, hd, ht, hu]

/-- Lemma 3.6's exhaustive exceptional-case classification. -/
theorem lemma36_cases (P : Parameters) (h : P.Admissible)
    (hb : P.b = 1) (hn : P.normAlpha < 0) :
    P.y h.pell (-1) ≤ 1 ↔ P.LowNeighborCases :=
  ⟨P.low_neighbor_cases_of_le_one h hb hn, P.low_neighbor_le_one_of_cases h.pell hb⟩

theorem y_neg_two (P : Parameters) (h : P.Pell) :
    P.y h (-2) = ((P.t : ℚ) ^ 2 + P.d * (P.u : ℚ) ^ 2) / 2 * P.y h (-1)
      - (P.b : ℚ) ^ 2 := by
  simpa using P.y_reverse_recurrence h (-1)

theorem cutoff_neg_two_of_values (P : Parameters) (h : P.Pell) (hb : P.b = 1)
    (h1 : P.y h (-1) ≤ 1) (h2 : 1 < P.y h (-2)) : P.IsNegativeCutoff h (-2) := by
  refine ⟨by norm_num, ?_, ?_⟩
  · simpa [hb] using h2
  · intro j hj hj0
    have heq : j = -1 := by omega
    simpa [hb, heq] using h1

/-- Table 1(i), including the cutoff and the printed value at `-2`. -/
theorem table1_row_i (P : Parameters) (h : P.Admissible) (hb : P.b = 1)
    (hd : P.d = P.a ^ 2 + 4) (ht : P.t = P.a) (hu : P.u = 1) :
    P.y h.pell (-1) = 1 ∧ P.y h.pell (-2) = (P.a : ℚ) ^ 2 + 1 ∧
      P.IsNegativeCutoff h.pell (-2) := by
  have h1 : P.y h.pell (-1) = 1 := by
    rw [P.y_neg_one]; simp [hb, hd, ht, hu]; ring
  have h2 : P.y h.pell (-2) = (P.a : ℚ) ^ 2 + 1 := by
    rw [P.y_neg_two, h1]; simp [hb, hd, ht, hu]; ring
  refine ⟨h1, h2, P.cutoff_neg_two_of_values h.pell hb (le_of_eq h1) ?_⟩
  rw [h2]
  have ha : (0 : ℚ) < P.a := by exact_mod_cast h.a_pos
  nlinarith [sq_pos_of_pos ha]

/-- Table 1(ii). -/
theorem table1_row_ii (P : Parameters) (h : P.Admissible) (hb : P.b = 1)
    (hd : P.d = P.a ^ 2 + 1) (ht : P.t = 2 * P.a) (hu : P.u = 2) :
    P.y h.pell (-1) = 1 ∧ P.y h.pell (-2) = 4 * (P.a : ℚ) ^ 2 + 1 ∧
      P.IsNegativeCutoff h.pell (-2) := by
  have h1 : P.y h.pell (-1) = 1 := by
    rw [P.y_neg_one]; simp [hb, hd, ht, hu]; ring
  have h2 : P.y h.pell (-2) = 4 * (P.a : ℚ) ^ 2 + 1 := by
    rw [P.y_neg_two, h1]; simp [hb, hd, ht, hu]; ring
  refine ⟨h1, h2, P.cutoff_neg_two_of_values h.pell hb (le_of_eq h1) ?_⟩
  rw [h2]
  have ha : (0 : ℚ) < P.a := by exact_mod_cast h.a_pos
  nlinarith [sq_pos_of_pos ha]

/-- Table 1(iii). -/
theorem table1_row_iii (P : Parameters) (h : P.Pell) (hb : P.b = 1)
    (ha : P.a = 3) (hd : P.d = 12) (ht : P.t = 4) (hu : P.u = 1) :
    P.y h (-1) = 1 ∧ P.y h (-2) = 13 ∧ P.IsNegativeCutoff h (-2) := by
  have h1 : P.y h (-1) = 1 := by rw [P.y_neg_one]; norm_num [hb, ha, hd, ht, hu]
  have h2 : P.y h (-2) = 13 := by rw [P.y_neg_two, h1]; norm_num [hb, hd, ht, hu]
  exact ⟨h1, h2, P.cutoff_neg_two_of_values h hb (by rw [h1]) (by rw [h2]; norm_num)⟩

/-- Table 1(iv). -/
theorem table1_row_iv (P : Parameters) (h : P.Pell) (hb : P.b = 1)
    (ha : P.a = 2) (hd : P.d = 5) (ht : P.t = 3) (hu : P.u = 1) :
    P.y h (-1) = 1 / 2 ∧ P.y h (-2) = 5 / 2 ∧ P.IsNegativeCutoff h (-2) := by
  have h1 : P.y h (-1) = 1 / 2 := by rw [P.y_neg_one]; norm_num [hb, ha, hd, ht, hu]
  have h2 : P.y h (-2) = 5 / 2 := by rw [P.y_neg_two, h1]; norm_num [hb, hd, ht, hu]
  exact ⟨h1, h2, P.cutoff_neg_two_of_values h hb (by rw [h1]; norm_num)
    (by rw [h2]; norm_num)⟩

/-- Table 1(v), including all four printed negative-index values. -/
theorem table1_row_v (P : Parameters) (h : P.Pell) (hb : P.b = 1)
    (ha : P.a = 2) (hd : P.d = 5) (ht : P.t = 1) (hu : P.u = 1) :
    P.y h (-1) = 1 / 2 ∧ P.y h (-2) = 1 / 2 ∧ P.y h (-3) = 1 ∧
      P.y h (-4) = 5 / 2 ∧ P.IsNegativeCutoff h (-4) := by
  have h1 : P.y h (-1) = 1 / 2 := by rw [P.y_neg_one]; norm_num [hb, ha, hd, ht, hu]
  have h2 : P.y h (-2) = 1 / 2 := by rw [P.y_neg_two, h1]; norm_num [hb, hd, ht, hu]
  have h3 : P.y h (-3) = 1 := by
    have hr := P.y_reverse_recurrence h (-2)
    norm_num [hd, ht, hu, h1, h2] at hr
    exact hr
  have h4 : P.y h (-4) = 5 / 2 := by
    have hr := P.y_reverse_recurrence h (-3)
    norm_num [hd, ht, hu, h2, h3] at hr
    exact hr
  refine ⟨h1, h2, h3, h4, by norm_num, ?_, ?_⟩
  · norm_num [hb, h4]
  · intro j hj hj0
    have hjCases : j = -3 ∨ j = -2 ∨ j = -1 := by omega
    rcases hjCases with rfl | rfl | rfl <;> norm_num [hb, h1, h2, h3]

/-- Outside the five exceptional rows, the cutoff equals `-1`. -/
theorem cutoff_neg_one_of_not_cases (P : Parameters) (h : P.Admissible)
    (hb : P.b = 1) (hn : P.normAlpha < 0) (hc : ¬ P.LowNeighborCases) :
    P.IsNegativeCutoff h.pell (-1) := by
  have hy : 1 < P.y h.pell (-1) :=
    lt_of_not_ge (fun hle => hc (P.low_neighbor_cases_of_le_one h hb hn hle))
  refine ⟨by norm_num, by simpa [hb] using hy, ?_⟩
  intro j hj hj0
  omega

/-- Complete classification of the cutoff: `-1` in the ordinary case, `-2`
in Table 1(i)--(iv), and `-4` only in Table 1(v). The individual row theorems
above also verify all sequence values printed in the table. -/
theorem lemma36_cutoff (P : Parameters) (h : P.Admissible)
    (hb : P.b = 1) (hn : P.normAlpha < 0) {K : ℤ}
    (hK : P.IsNegativeCutoff h.pell K) :
    (K = -1 ∧ ¬ P.LowNeighborCases) ∨
    (K = -2 ∧ P.LowNeighborCases) ∨
    (K = -4 ∧ P.a = 2 ∧ P.d = 5 ∧ P.t = 1 ∧ P.u = 1) := by
  by_cases hc : P.LowNeighborCases
  · have hc0 := hc
    rcases hc with ⟨hd, ht, hu⟩ | ⟨hd, ht, hu⟩ | ⟨ha, hd, ht, hu⟩ |
      ⟨ha, hd, ht, hu⟩ | ⟨ha, hd, ht, hu⟩
    · exact Or.inr (Or.inl ⟨P.negative_cutoff_unique h.pell hK
        (P.table1_row_i h hb hd ht hu).2.2, hc0⟩)
    · exact Or.inr (Or.inl ⟨P.negative_cutoff_unique h.pell hK
        (P.table1_row_ii h hb hd ht hu).2.2, hc0⟩)
    · exact Or.inr (Or.inl ⟨P.negative_cutoff_unique h.pell hK
        (P.table1_row_iii h.pell hb ha hd ht hu).2.2, hc0⟩)
    · exact Or.inr (Or.inl ⟨P.negative_cutoff_unique h.pell hK
        (P.table1_row_iv h.pell hb ha hd ht hu).2.2, hc0⟩)
    · exact Or.inr (Or.inr ⟨P.negative_cutoff_unique h.pell hK
        (P.table1_row_v h.pell hb ha hd ht hu).2.2.2.2, ha, hd, ht, hu⟩)
  · exact Or.inl ⟨P.negative_cutoff_unique h.pell hK
      (P.cutoff_neg_one_of_not_cases h hb hn hc), hc⟩

end «JNT-2024».Parameters
