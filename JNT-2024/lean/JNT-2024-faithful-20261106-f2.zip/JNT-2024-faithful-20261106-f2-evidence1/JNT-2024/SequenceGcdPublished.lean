module

public import «JNT-2024».Sequence
public import «JNT-2024».SequenceRepresentations
public import «JNT-2024».UnitGcdPublished
public import «JNT-2024».UnitPowers
public import «JNT-2024».UnitSequenceIntegrality
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- The unit epsilon inverse used for negative indices in the printed proof of Lemma 3.11. -/
abbrev inverseUnitParameters (P : Parameters) (ν : ℤ) : Parameters :=
  P.withUnit (ν * P.t) (-ν * P.u)

theorem inverse_unit_pell (P : Parameters) (hp : P.Pell) {ν : ℤ} (hν : ν = 1 ∨ ν = -1) :
    (P.inverseUnitParameters ν).Pell := by
  rcases hν with rfl | rfl <;> simpa [Pell, inverseUnitParameters, withUnit] using hp

theorem inverse_unit_epsilon (P : Parameters) {ν : ℤ} (hν : ν = 1 ∨ ν = -1)
    (hn : P.t ^ 2 - P.d * P.u ^ 2 = 4 * ν) :
    P.epsilon * (P.inverseUnitParameters ν).epsilon = 1 := by
  have hnq : (P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2 = 4 * ν := by exact_mod_cast hn
  rcases hν with rfl | rfl
  · norm_num at hnq
    ext
    · simp [epsilon, inverseUnitParameters, withUnit, QuadraticAlgebra.re_one]
      linear_combination hnq / 4
    · simp [epsilon, inverseUnitParameters, withUnit, QuadraticAlgebra.im_one]
      ring
  · norm_num at hnq
    ext
    · simp [epsilon, inverseUnitParameters, withUnit, QuadraticAlgebra.re_one]
      linear_combination -hnq / 4
    · simp [epsilon, inverseUnitParameters, withUnit, QuadraticAlgebra.im_one]
      ring

theorem inverse_unit_square (P : Parameters) {ν : ℤ} (hν : ν = 1 ∨ ν = -1) :
    (P.inverseUnitParameters ν).epsilon ^ 2 = (star P.epsilon) ^ 2 := by
  rcases hν with rfl | rfl <;> ext <;>
    simp [epsilon, inverseUnitParameters, withUnit, pow_two] <;> ring

theorem term_neg_inverse_unit (P : Parameters) (hp : P.Pell) {ν : ℤ}
    (hν : ν = 1 ∨ ν = -1) (n : ℕ) :
    P.term hp (-(n : ℤ)) = P.alpha * (P.inverseUnitParameters ν).epsilon ^ (2 * n) := by
  rw [P.term_neg_nat, pow_mul, P.inverse_unit_square hν, ← pow_mul, star_pow, ← pow_mul]
  rw [Nat.mul_comm n 2]

/-- Lemma 3.10 applied directly to nonnegative indices, and to epsilon inverse
for negative indices, as specified in the printed proof of Lemma 3.11. -/
theorem sequence_integral_gcd_published (P : Parameters) (h : P.Admissible)
    (hc : Int.gcd P.a P.b = 1) {k X Y : ℤ}
    (hx : P.x h.pell k = (X : ℚ)) (hy : P.y h.pell k = (Y : ℚ)) :
    Int.gcd X Y = 1 ∨ Int.gcd X Y = 2 := by
  have hab : Int.gcd P.a (P.b ^ 2) = 1 :=
    Int.isCoprime_iff_gcd_eq_one.mp (Int.isCoprime_iff_gcd_eq_one.mpr hc).pow_right
  have he : (⟨(X : ℚ), (Y : ℚ)⟩ : P.Algebra) = P.term h.pell k := by
    ext
    · exact hx.symm
    · exact hy.symm
  have ho : Odd (Int.gcd P.a (P.b ^ 2)) := by rw [hab]; decide
  cases k with
  | ofNat n =>
    change (⟨(X : ℚ), (Y : ℚ)⟩ : P.Algebra) = P.term h.pell (n : ℤ) at he
    rw [P.term_nat] at he
    have he' : (⟨(X : ℚ), (Y : ℚ)⟩ : P.Algebra) =
        (⟨(P.a : ℚ), ((P.b ^ 2 : ℤ) : ℚ)⟩ : P.Algebra) * P.epsilon ^ (2 * n) := by
      simpa only [alpha, Int.cast_pow] using he
    simpa only [hab, mul_one] using P.lemma310_published h.pell (ne_of_gt h.a_pos) ho (2 * n) he'
  | negSucc n =>
    obtain ⟨ν,hν,_,hn⟩ := P.unit_norm_integer_sign h.pell
    have hi := P.inverse_unit_epsilon hν hn
    have he' : (⟨(X : ℚ), (Y : ℚ)⟩ : (P.inverseUnitParameters ν).Algebra) =
        (⟨(P.a : ℚ), ((P.b ^ 2 : ℤ) : ℚ)⟩ : P.Algebra) *
          (P.inverseUnitParameters ν).epsilon ^ (2 * (n + 1)) := by
      have ht := P.term_neg_inverse_unit h.pell hν (n + 1)
      have hk : -((n + 1 : ℕ) : ℤ) = Int.negSucc n := by omega
      rw [hk] at ht
      simpa only [alpha, Int.cast_pow] using he.trans ht
    simpa only [hab, mul_one] using (P.inverseUnitParameters ν).lemma310_published
      (P.inverse_unit_pell h.pell hν) (ne_of_gt h.a_pos) ho (2 * (n + 1)) he'

end «JNT-2024».Parameters
