module

public import «JNT-2024».ComplexRepresentation
public import «JNT-2024».GapPrinciple
public import «JNT-2024».NumberFieldBridge
public import «JNT-2024».RepresentationAlgebra
public import «JNT-2024».RepresentationBothEvenPublished
public import «JNT-2024».RepresentationBounds
public import «JNT-2024».RepresentationGaussian
public import «JNT-2024».Sequence
public import «JNT-2024».SequenceRepresentations
public import «JNT-2024».SquarefreePart
public import «JNT-2024».UnitPowers
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024»


namespace Parameters

theorem integer_unit_norm (P : Parameters) {ν : ℤ} (hp : P.Pell) (hν : (ν : ℚ) = P.epsilonNorm) :
    ν = 1 ∨ ν = -1 := by
  rcases P.pell_iff_epsilonNorm.mp hp with hh | hh
  · left; exact_mod_cast hν.trans hh
  · right; exact_mod_cast hν.trans hh

theorem normRadical_of_unit (P : Parameters) {ν : ℤ} (hν : ν = 1 ∨ ν = -1) : P.normRadical ν = 1 := by
  rcases hν with rfl | rfl <;> simp [normRadical, UniqueFactorizationMonoid.radical_one]

theorem sharpRadical_dvd_factor (P : Parameters) {ν : ℤ} (hν : ν = 1 ∨ ν = -1) (e : ℕ) :
    P.sharpRadical ν e ∣ (e : ℤ) := by
  have hg : P.sharpGcd ν = 1 := by rcases hν with rfl | rfl <;> simp [sharpGcd]
  simpa [sharpRadical, hg] using (UniqueFactorizationMonoid.radical_dvd_self (a := (e : ℤ)))


theorem sequence_gaussian_datum (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (hNs : IsSquare (-P.normAlpha)) {k : ℤ} (hk : k ≠ 0) (hs : IsSquare (P.y h.pell k))
    (hy : 0 < P.y h.pell k) :
    ∃ p : FourthPowerDatum 1 P.b P.gapScale P.gapOmega,
      p.y = (P.y h.pell k : ℝ) ∧ p.f ≤ (P.b : ℝ) ^ 2 := by
  obtain ⟨T, U, x, v, hU, hv, hp, hrep, hyv⟩ := P.sequence_square_representation_input h hk hs hy
  let Q := P.withUnit T U
  let : Fact (¬ IsSquare Q.d) := ⟨h.d_not_square⟩
  let : Fact (¬ IsSquare Q.normAlpha) := ⟨by
    rintro ⟨m, hm⟩
    change P.normAlpha = m * m at hm
    nlinarith [sq_nonneg m]⟩
  obtain ⟨ν, f, r, s, τ, hν, hf, hτ, hF, hd⟩ := Q.proposition31b_published hrep (ne_of_gt h.a_pos) (ne_of_gt h.b_pos)
    (ne_of_gt hv) hU (ne_of_lt hn) (Q.epsilon_isIntegral hp) hNs
  have hSf : -squarefreePart P.normAlpha = 1 := by
    rw [squarefreePart_eq_neg_one (ne_of_lt hn) hNs]; norm_num
  have hex := Q.signed_representation_datum h.b_pos hn hp hv hf hτ hF
  change ∃ p : FourthPowerDatum (-squarefreePart P.normAlpha) P.b P.gapScale P.gapOmega,
    p.y = (v : ℝ) ^ 2 ∧ p.f = (f : ℝ) ∧ p.r = r ∧ p.s = s at hex
  rw [hSf] at hex
  obtain ⟨p, hpy, hpf, _, _⟩ := hex
  refine ⟨p, ?_, ?_⟩
  · rw [hpy, hyv]
    norm_cast
  · have hr := Q.normRadical_of_unit (Q.integer_unit_norm hp hν)
    rw [hr, mul_one] at hd
    have hle : f ≤ P.b ^ 2 := Int.le_of_dvd (sq_pos_of_pos h.b_pos) hd
    rw [hpf]
    exact_mod_cast hle

/-- The coefficient and integer coordinates are those of an actual Proposition 3.1 representation. -/
def SequenceGapCertificate (P : Parameters) (hp : P.Pell) (k : ℤ)
    (p : FourthPowerDatum (-squarefreePart P.normAlpha) P.b P.gapScale P.gapOmega) : Prop :=
  p.y = (P.y hp k : ℝ) ∧ ∃ T U x v f τ : ℤ, U ≠ 0 ∧ 0 < v ∧ (P.withUnit T U).Pell ∧
    (P.withUnit T U).RepresentsSquare x v ∧ p.f = (f : ℝ) ∧
    (τ = 1 ∨ τ = -1) ∧ (P.withUnit T U).SignedFourthPowerRepresentation x v f p.r p.s τ ∧
    P.x hp k = (x : ℚ) ∧ (P.withUnit T U).epsilonNorm = P.epsilonNorm ^ k


end Parameters
end «JNT-2024»
