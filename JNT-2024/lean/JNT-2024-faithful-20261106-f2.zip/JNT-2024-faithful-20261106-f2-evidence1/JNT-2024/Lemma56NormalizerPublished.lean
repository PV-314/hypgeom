module

public import «JNT-2024».NormalizerBounds
public import «JNT-2024».NormalizerFormula
public import «JNT-2024».NormalizerPowers
public import «JNT-2024».Section5GcdNormalization
public import «JNT-2024».Sequence
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.Deriv.MeanValue
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.LegendreSymbol.Basic
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- The basic M²>=4G consequence of the already established normalizer formula. -/
theorem lemma56_normalizer_ge_four_gcd (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hNs : IsSquare (-P.normAlpha)) : 4*P.baseGcd ≤ P.normalizerSquare := by
  obtain ⟨n,hn⟩ := hNs
  have hn2 : -P.normAlpha=n^2 := by simpa [pow_two] using hn
  obtain ⟨g,A,b,_,_,_,_,hG,_,hB,_⟩ := P.section5_normalized_coordinates h hb hn2
  have hc : 1 ≤ Int.gcd 16 (b^2) := by
    have := Int.gcd_pos_of_ne_zero_left (b^2) (by norm_num : (16:ℤ) ≠ 0)
    omega
  rw [hG,hB]
  nlinarith [Nat.mul_le_mul_left (4*g^2) hc]

/-- The two printed parity alternatives in Lemma 5.6(1-i): even a gives 4|G;
odd a gives 4|b' and M²>=16G. The square-root normalization is reused. -/
theorem lemma56_even_normalizer_cases (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hNs : IsSquare (-P.normAlpha)) (heven : Even (-P.normAlpha)) :
    (Even P.a → 4 ∣ P.d ∧ 4 ∣ P.baseGcd) ∧
    (Odd P.a → 4 ∣ P.normQuotient ∧ 16*P.baseGcd ≤ P.normalizerSquare) := by
  obtain ⟨n,hn⟩ := hNs
  have hn2 : -P.normAlpha=n^2 := by simpa [pow_two] using hn
  have hne : Even n := by have hh : Even (n^2) := hn2 ▸ heven; simpa [Int.even_pow] using hh
  obtain ⟨g,A,b,_,_,ha,hnb,hG,hq,hB,_⟩ := P.section5_normalized_coordinates h hb hn2
  constructor
  · intro hae
    have hd : P.d=P.a^2+n^2 := by simp only [normAlpha,hb,one_pow,one_mul] at hn2; linarith
    have ha4 : (4:ℤ) ∣ P.a^2 := pow_dvd_pow_of_dvd (even_iff_two_dvd.mp hae) 2
    have hn4 : (4:ℤ) ∣ n^2 := pow_dvd_pow_of_dvd (even_iff_two_dvd.mp hne) 2
    have hd4 : (4:ℤ) ∣ P.d := by rw [hd]; exact dvd_add ha4 hn4
    refine ⟨hd4,?_⟩
    simpa [baseGcd,hb] using Int.dvd_gcd ha4 hd4
  · intro hao
    have hgo : Odd (g:ℤ) := (Int.odd_mul.mp (ha ▸ hao)).1
    have hbe : Even b := (Int.even_mul.mp (hnb ▸ hne)).resolve_left (Int.not_even_iff_odd.mpr hgo)
    have hb4 : (4:ℤ) ∣ b^2 := by
      obtain ⟨c,hc⟩ := hbe
      refine ⟨c^2,?_⟩
      rw [hc]; ring
    have hgc : 4 ∣ Int.gcd 16 (b^2) := Int.dvd_gcd (by norm_num) hb4
    have hgc4 : 4 ≤ Int.gcd 16 (b^2) := Nat.le_of_dvd
      (Int.gcd_pos_of_ne_zero_left (b^2) (by norm_num : (16:ℤ) ≠ 0)) hgc
    refine ⟨by rw [hq]; exact dvd_neg.mpr hb4,?_⟩
    rw [hG,hB]
    nlinarith [Nat.mul_le_mul_left (4*g^2) hgc4]

/-- Combining the two parity cases with 9|G gives the printed M²>=144. -/
theorem lemma56_even_nine_normalizer (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hNs : IsSquare (-P.normAlpha)) (heven : Even (-P.normAlpha))
    (h9 : 9 ∣ P.baseGcd) : 144 ≤ P.normalizerSquare := by
  have hg9 : 9 ≤ P.baseGcd := Nat.le_of_dvd (P.baseGcd_pos (ne_of_gt h.a_pos)) h9
  rcases Int.even_or_odd P.a with hae | hao
  · have h4 := ((P.lemma56_even_normalizer_cases h hb hNs heven).1 hae).2
    have h36 : 36 ∣ P.baseGcd := by
      rw [← show Nat.lcm 4 9=36 by decide]
      exact Nat.lcm_dvd h4 h9
    have hg36 := Nat.le_of_dvd (P.baseGcd_pos (ne_of_gt h.a_pos)) h36
    have hm := P.lemma56_normalizer_ge_four_gcd h hb hNs
    omega
  · have hm := (P.lemma56_even_normalizer_cases h hb hNs heven).2 hao
    omega


end «JNT-2024».Parameters

