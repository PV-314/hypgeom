module

public import «JNT-2024».Sequence
public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.Deriv.MeanValue
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Analysis.Convex.SpecificFunctions.Deriv
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Fin.VecNotation
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.Rat.Sqrt
public import Mathlib.Data.ZMod.Basic
public import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Parameters

/-- Lemma 5.5(2-i), the printed modulo-nine exclusion. -/
theorem lemma55_u6_impossible (P : Parameters) (he : P.t^2-P.d*P.u^2= -4) : P.u ≠ 6 := by
  intro hu
  have hh := congrArg (fun z:ℤ => (z:ZMod 9)) he
  norm_num [hu] at hh
  have hc : ∀ t:ZMod 9, t^2 ≠ -4 := by decide +kernel
  have h36 : (36:ZMod 9)=0 := by decide
  simp only [h36,mul_zero,sub_zero] at hh
  exact hc P.t hh


end «JNT-2024».Parameters
