module

public import Mathlib.Algebra.Field.Subfield.Basic
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Algebra.Polynomial.Eval.Degree
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Algebra.QuadraticAlgebra.NormDeterminant
public import Mathlib.Algebra.Ring.Defs
public import Mathlib.Algebra.Ring.Parity
public import Mathlib.Analysis.Analytic.Binomial
public import Mathlib.Analysis.Analytic.Uniqueness
public import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Complex.Arg
public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import Mathlib.Analysis.SpecialFunctions.Gamma.Beta
public import Mathlib.Analysis.SpecialFunctions.OrdinaryHypergeometric
public import Mathlib.Analysis.SpecialFunctions.Pow.Complex
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
public import Mathlib.Data.Finset.Card
public import Mathlib.Data.Int.ModEq
public import Mathlib.Data.Nat.Factorization.Basic
public import Mathlib.Data.Nat.Squarefree
public import Mathlib.Data.Rat.Lemmas
public import Mathlib.Data.ZMod.Basic
public import Mathlib.MeasureTheory.Integral.DominatedConvergence
public import Mathlib.NumberTheory.NumberField.Norm
public import Mathlib.NumberTheory.Padics.PadicVal.Basic
public import Mathlib.RingTheory.Int.Basic
public import Mathlib.RingTheory.Polynomial.Pochhammer
public import Mathlib.RingTheory.Radical.Basic
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.LinearCombination
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Ring

@[expose] public section

namespace «JNT-2024».Section4


/-- The intermediate upper bound in Section 4.2 before imposing `d≥112`. -/
theorem case42_upper_bound {N d y z : ℝ} (hN : 0 < N) (hd : 0 < d) (hy : 0 < y)
    (hgap : (5732 / 100 : ℝ) * d ^ 2 * y ^ 3 < N ^ 2 * z)
    (hupper : z ^ 3 < (35700 * 256 : ℝ) * N ^ 2 * y ^ 5) :
    y * d * Real.sqrt d < (66 / 25 : ℝ) * N ^ 2 := by
  have hg3 : (5732 / 100 : ℝ) ^ 3 * d ^ 6 * y ^ 9 < N ^ 6 * z ^ 3 := by
    convert pow_lt_pow_left₀ hgap (by positivity) (by decide : 3 ≠ 0) using 1 <;> ring
  have hu3 : N ^ 6 * z ^ 3 < (35700 * 256 : ℝ) * N ^ 8 * y ^ 5 := by
    convert mul_lt_mul_of_pos_left hupper (pow_pos hN 6) using 1; ring
  have hcancel : (5732 / 100 : ℝ) ^ 3 * d ^ 6 * y ^ 4 < (35700 * 256 : ℝ) * N ^ 8 := by
    apply (mul_lt_mul_iff_right₀ (pow_pos hy 5)).mp
    convert hg3.trans hu3 using 1 <;> ring
  have hs : y ^ 4 * d ^ 6 < (66 / 25 : ℝ) ^ 4 * N ^ 8 := by
    nlinarith only [hcancel, pow_pos hN 8]
  have hd4 : Real.sqrt d ^ 4 = d ^ 2 := by
    rw [show (4 : ℕ) = 2 * 2 by rfl, pow_mul, Real.sq_sqrt hd.le]
  apply (pow_lt_pow_iff_left₀ (by positivity) (by positivity) (by decide : 4 ≠ 0)).mp
  simpa only [mul_pow, hd4, ← pow_mul, show (2 : ℕ) * 4 = 8 by rfl,
    mul_assoc, ← pow_add, show (4 : ℕ) + 2 = 6 by rfl] using hs


end «JNT-2024».Section4
