// Reconstructed documented input; not the historical V2.28-2 transcript.
// Paper coordinates (x,y) are Magma coordinates [y,x].
// The one-argument overload is inapplicable: the constant term is negative.
count := 0;
for a in [1..10] do
  for n in [2..10] do
    d := a^2+n^2;
    if d le 111 and not IsSquare(d) then
      count +:= 1;
      Q := [d,0,0,0,-n^2];
      P := [1,a];
      assert P[2]^2 eq d*P[1]^4-n^2;
      points := IntegralQuarticPoints(Q,P);
      positive := { <Abs(s[2]),Abs(s[1])> : s in points |
                    s[1] ne 0 and s[2] ne 0 };
      assert forall{s : s in positive | s[1]^2+n^2 eq d*s[2]^4};
      <a,d,-n^2,positive>;
    end if;
  end for;
end for;
assert count eq 63;
