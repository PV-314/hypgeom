"""Independent exact bounded search; does not assert global completeness."""
from pathlib import Path
from math import isqrt
import hashlib
import json
import re
import time

root = Path(__file__).resolve().parents[1]
start = time.perf_counter()
source = root / "JNT-2024/SmallQuarticCertificates.lean"
text = source.read_text(encoding="utf-8")
block = text.split("def extraQuarticSolutions", 1)[1].split("def listedQuarticSolutions", 1)[0]
extras = [(int(a), int(n), int(x), int(y)) for a,n,x,y in
          re.findall(r"\(\((\d+),(\d+)\),\((\d+),(\d+)\)\)", block)]
assert len(extras) == 20
rows = []
for a in range(1,11):
    for n in range(2,11):
        d = a*a+n*n
        if d > 111 or isqrt(d)**2 == d:
            continue
        solutions = []
        for y in range(1,110):
            square = d*y**4-n*n
            x = isqrt(square)
            if x > 0 and x*x == square:
                solutions.append([x,y])
        expected = sorted([[a,1]] + [[x,y] for aa,nn,x,y in extras if (aa,nn)==(a,n)], key=lambda s:s[1])
        assert solutions == expected, (a,n,solutions,expected)
        rows.append(dict(a=a, n=n, d=d, norm=-n*n, solutions=solutions,
                         magma_coefficients=[d,0,0,0,-n*n], magma_base_point=[1,a]))
assert len(rows) == 63
multiple = [r for r in rows if len(r['solutions'])>=2]
triples = [r for r in rows if len(r['solutions'])==3]
assert len(multiple)==18
assert [(r['a'],r['d'],r['solutions']) for r in triples] == [
    (1,17,[[1,1],[16,2],[103,5]]), (2,68,[[2,1],[32,2],[206,5]])]
assert all(len(r['solutions'])<=3 for r in rows)
out = dict(scope="Positive x; 1 <= y <= 109. No global completeness claim.",
           equations=len(rows), at_least_two=len(multiple), exactly_three=len(triples),
           lean_source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
           elapsed_seconds=time.perf_counter()-start, rows=rows)
dest = root / 'audit/section46-small-search.json'
dest.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k!='rows'}))
