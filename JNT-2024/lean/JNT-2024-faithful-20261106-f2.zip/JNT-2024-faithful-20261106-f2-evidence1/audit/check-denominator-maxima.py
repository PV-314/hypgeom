"""Exact finite arithmetic for Lemma 2.3(a), with retained indices and values.

Uses the same coefficient recurrence and parity envelope as the checked Lean
DenominatorComputation / DenominatorBounds modules. This is a reproducible
numerical audit, not a claim that its output has been certified by Lean.
"""
from fractions import Fraction as Q
from math import comb, gcd, lcm
from decimal import Decimal, localcontext
from pathlib import Path
import json
from time import perf_counter

start = perf_counter()
L, U = Q(107311, 20000), Q(134139, 25000)
peaks = (Q(32768), Q(225450225, 131072))
# Exact Taylor enclosure: after degree 32, successive tail terms have ratio
# at most x/34. No floating-point comparison is used in certification checks.
x = Q(42,25)
term = total = Q(1)
for k in range(1,33):
    term *= x/k
    total += term
tail_bound = term*x/33/(1-x/34)
assert L < total and total + tail_bound < U
rows = []
attainers = [[], []]
g, h = Q(1), Q(1, 4)

def rational(x):
    return str(x.numerator) + '/' + str(x.denominator)

with localcontext() as ctx:
    ctx.prec = 40
    E = (Decimal(42) / 25).exp()
    peak_values = [(Decimal(p.numerator) / p.denominator).sqrt() / E**3 for p in peaks]
    for r in range(139):
        cs = [Q(1)]
        for j in range(r):
            cs.append(cs[-1] * (r-j) * (4*r+1-4*j) / ((j+1)*(4*j+3)))
        D = lcm(*(c.denominator for c in cs))
        integral = [int(D*c) for c in cs]
        shifted = [(-1)**j * sum(integral[k]*comb(k,j) for k in range(j,r+1))
                   for j in range(r+1)]
        contents = [gcd(*(shifted[j]*2**(e*j//2) for j in range(r+1))) for e in range(7)]
        As = (g*D, h*D)
        envelope = [(1 if r % 2 == 0 else 2)*a*a for a in As]
        # The original indexed upper bounds, and the new strict peak comparison.
        for i, b in enumerate(envelope):
            assert b < (Q(293,250), Q(537,2000))[i]**2 * L**(2*r), (r,i,'old bound')
            assert (b == peaks[i]) if r == 3 else (b*U**6 < peaks[i]*L**(2*r)), (r,i,'peak')
        values = []
        for e, N in enumerate(contents):
            assert N > 0
            pair = []
            for i, a in enumerate(As):
                b = (a/N)**2 * 2**(e*r)
                assert b <= envelope[i], (r,e,i,'envelope')
                assert (b <= peaks[i]) if r == 3 else (b*U**6 < peaks[i]*L**(2*r)), (r,e,i)
                if r == 3 and b == peaks[i]:
                    attainers[i].append({'r': r, 'e': e, 'd': 2**e})
                pair.append(str((Decimal(b.numerator)/b.denominator).sqrt()/E**r))
            values.append({'e': e, 'd': 2**e, 'N': str(N), 'normalized_values': pair})
        rows.append({'r': r, 'D': str(D), 'gammaRatio': rational(g),
                     'gammaNumeratorRatio': rational(h),
                     'squared_envelope': list(map(rational, envelope)), 'values': values})
        if r == 3:
            r3 = {'integral_coefficients': integral, 'shifted_coefficients': shifted,
                  'contents': contents}
        g *= Q(4*(r+1), 4*r+3)
        h *= Q(4*r+5, 4*(r+1))

assert all(x == [{'r':3,'e':e,'d':2**e} for e in (1,3,5)] for x in attainers)
result = {'status': 'exact arithmetic checked; not a Lean certificate',
          'domain': {'r': [0,138], 'e': [0,6], 'pairs': 973},
          'exponential_bracket': {'lower': rational(L), 'upper': rational(U)},
          'exponential_check': 'degree-32 rational Taylor sum with geometric tail bound',
          'peak_squared_numerators': list(map(rational, peaks)),
          'maxima_decimal': list(map(str, peak_values)), 'attainers': attainers,
          'r3_data': r3, 'rows': rows}
out = Path(__file__).with_name('denominator-maxima-values.json')
out.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'seconds': round(perf_counter()-start,3), 'pairs': 973,
                  'maxima': result['maxima_decimal'], 'attainers': attainers,
                  'output': str(out)}, indent=2))
