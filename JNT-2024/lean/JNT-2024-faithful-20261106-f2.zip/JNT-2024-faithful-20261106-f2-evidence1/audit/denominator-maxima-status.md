# Lemma 2.3(a): indexed numerical calculation

Current decision: accepted computational input CALC-001 in
[CALCULATIONS.md](../reports/CALCULATIONS.md). Further Lean certification
is waived by the user.

The full finite calculation has been reproduced using exact rational/integer
arithmetic by `check-denominator-maxima.py`. All 139 indices and all seven
representative radicands are retained in `denominator-maxima-values.json`.
Decimal values are for display only; all comparisons use exact rationals.

Both maxima occur at r = 3, attained among the representatives at d = 2, 8, 32:

- 128 sqrt(2) exp(-126/25) = 1.171873621902706285868474535513541427334...
- (15015/512) sqrt(2) exp(-126/25) = 0.2684888066538869458361075615041477131869...

The script uses the existing Lean coefficient recurrence and the same indexed
parity envelopes used in `FastDenominatorCheck`. It verifies the old bounds,
then verifies the stronger comparisons needed for maximality. With
L = 107311/20000, U = 134139/25000, P = 32768 or 225450225/131072,
and B the appropriate squared parity envelope, the exact comparisons are:

- r != 3: B U^6 < P L^(2r).
- r = 3: B = P.

Since L < exp(42/25) < U, these imply the desired strict comparisons of
normalized values for r != 3. The exponential bracket is also checked using
an exact rational Taylor sum and geometric tail bound. The independently
calculated contents verify attainment at r = 3. Its integral coefficients are
[77,1001,1287,195], its translated coefficients are [2560,-4160,1872,-195],
and its seven contents are [1,2,8,16,64,128,512].

Status: numerical verification complete; maximality is an approved calculation input.
The original `denominator_fast_certificate` proves the original bounds, not
these stronger comparisons. The main theorem does not assume this maxima input.
The printed constants and the certified finite inequalities are retained.

The exact-maxima evidence is the indexed external calculation above. No
uncertified Lean draft or experimental reduction is included in this release.
