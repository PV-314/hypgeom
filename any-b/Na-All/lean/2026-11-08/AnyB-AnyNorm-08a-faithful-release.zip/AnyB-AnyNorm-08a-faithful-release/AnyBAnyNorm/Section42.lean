module

public import AnyBAnyNorm.Prerequisites
public import AnyBAnyNorm.Diophantine

@[expose] public section
namespace AnyBAnyNorm
open «JNT-2024» Section2

private noncomputable abbrev quadField (S : ℤ) := IntermediateField.adjoin ℚ ({root S} : Set ℂ)

private theorem base_mem {S : ℤ} {x : ℂ} (hx : x ∈ Construction.baseField S) :
    x ∈ quadField S :=
  (Subfield.closure_le.mpr (show ({root S} : Set ℂ) ⊆ (quadField S).toSubfield from
    IntermediateField.subset_adjoin ℚ _)) hx

private theorem quad_degree {S : ℤ} (hS : S < 0) :
    Module.finrank ℚ (quadField S) = 2 := by
  open Polynomial in
  let f := (X^2 - C (S : ℚ) : ℚ[X])
  have hm : f.Monic := Polynomial.monic_X_pow_sub_C _ (by decide)
  have he : Polynomial.aeval (root S) f = 0 := by
    simp [f, root_sq hS.le]
  have hi : IsIntegral ℚ (root S) := ⟨f,hm,he⟩
  let _ := IntermediateField.adjoin.finiteDimensional hi
  have hle := Polynomial.natDegree_le_of_dvd (minpoly.dvd ℚ (root S) he) hm.ne_zero
  rw [show f.natDegree = 2 from Polynomial.natDegree_X_pow_sub_C,
    ← IntermediateField.adjoin.finrank hi] at hle
  have hpos := Module.finrank_pos (R := ℚ) (M := quadField S)
  have hne : Module.finrank ℚ (quadField S) ≠ 1 := by
    intro h
    obtain ⟨a,ha⟩ := IntermediateField.finrank_adjoin_simple_eq_one_iff.mp h
    have hh := congrArg Complex.im ha
    have hp : 0 < Real.sqrt (-(S : ℝ)) := Real.sqrt_pos.mpr (by exact_mod_cast neg_pos.mpr hS)
    simp [Section2.root] at hh
    linarith
  change Module.finrank ℚ (quadField S) ≤ 2 at hle
  omega

private theorem quad_complex {S : ℤ} (hS : S < 0) :
    NumberField.IsTotallyComplex (quadField S) := by
  constructor
  intro v
  apply NumberField.InfinitePlace.not_isReal_iff_isComplex.mp
  intro hv
  let e := NumberField.InfinitePlace.embedding_of_isReal hv
  let t : quadField S := ⟨root S,IntermediateField.subset_adjoin ℚ _ (Set.mem_singleton _)⟩
  have he : t^2 = (S : quadField S) := Subtype.ext (root_sq hS.le)
  have hh : e t ^ 2 = (S : ℝ) := by simpa using congrArg e he
  have hs : (S : ℝ) < 0 := by exact_mod_cast hS
  linarith [sq_nonneg (e t)]

private theorem quadratic_point_data {S : ℤ} (hS : S < 0) (r s : ℤ) :
    let z := quadraticPoint (-S) r s
    z ∈ Construction.baseField S ∧ star z ∈ Construction.baseField S ∧
      IsIntegral ℤ z ∧ IsIntegral ℤ (star z) := by
  let K := Construction.baseField S
  have ht : root S ∈ K := Subfield.subset_closure (Set.mem_singleton _)
  have hi : IsIntegral ℤ (root S) := IsIntegral.of_pow (by decide : 0 < 2)
    (root_sq hS.le ▸ (isIntegral_intCast (R := ℤ) S))
  have he : quadraticPoint (-S) r s = (r : ℂ) + s * root S := by
    apply Complex.ext <;> simp [quadraticPoint,root]
  have hstar : star (root S) = -root S := by simp [root]
  dsimp only
  rw [he,star_add,star_mul,hstar]
  simp only [star_intCast]
  exact ⟨add_mem (intCast_mem K _) (mul_mem (intCast_mem K _) ht),
    add_mem (intCast_mem K _) (mul_mem (neg_mem ht) (intCast_mem K _)),
    (isIntegral_intCast (R := ℤ) r).add ((isIntegral_intCast (R := ℤ) s).mul hi),
    (isIntegral_intCast (R := ℤ) r).add (hi.neg.mul (isIntegral_intCast (R := ℤ) s))⟩

/-- Equation (4.12) and the field and integrality conditions on the comparison
pair. The numerator in the determinant is η times the manuscript's p. -/
theorem section42_pair {P : Parameters} (h : P.Admissible) (hn : P.normAlpha < 0)
    {i j : ℤ} (p : SquarePhase P h.pell i) (q : SquarePhase P h.pell j)
    {η : ℂ} (hη : FourthPhase η) (hfield : η ∈ Construction.baseField (squarefreePart P.normAlpha)) :
    let z := star p.datum.point * q.datum.point
    let K := Construction.baseField (squarefreePart P.normAlpha)
    z ≠ 0 ∧ z ∈ K ∧ η*star z ∈ K ∧ IsIntegral ℤ z ∧ IsIntegral ℤ (η*star z) ∧
    ‖z‖ = Real.sqrt (p.datum.f*q.datum.f)*(p.datum.y*q.datum.y)^(1/4 : ℝ)/P.b := by
  have hp := quadratic_point_data (squarefreePart_neg hn) p.datum.r p.datum.s
  have hq := quadratic_point_data (squarefreePart_neg hn) q.datum.r q.datum.s
  have hi : IsIntegral ℤ η := IsIntegral.of_pow (by decide : 0 < 4) (hη.pow_four ▸ isIntegral_one)
  dsimp only
  rw [star_mul,star_star]
  refine ⟨mul_ne_zero (star_ne_zero.mpr p.datum.point_ne) q.datum.point_ne, mul_mem hp.2.1 hq.1,
    mul_mem hfield (mul_mem hq.2.1 hp.1), hp.2.2.2.mul hq.2.2.1,
    hi.mul (hq.2.2.2.mul hp.2.2.1),?_⟩
  have hh := p.datum.cross_denominator_norm q.datum (by exact_mod_cast h.b_pos)
  simp only [norm_mul,norm_star] at hh ⊢
  have hroot : Real.sqrt (Real.sqrt (p.datum.y*q.datum.y)) =
      (p.datum.y*q.datum.y)^(1/4 : ℝ) := by
    rw [Real.sqrt_eq_rpow,Real.sqrt_eq_rpow,← Real.rpow_mul (mul_nonneg p.datum.y_pos.le q.datum.y_pos.le)]
    norm_num
  rwa [hroot] at hh

/-- Lemma 2.1 at c = 3/4 with the §2.1 field descent and the all-index
denominator and error estimates. -/
theorem section42_apply (hPrior : Hypergeometric.DenominatorEstimate4)
    {S u v : ℤ} (hS : S < 0) (hv : v ≠ 0) (hU : IsIntegral ℤ (U S u v))
    (hw : ‖omega S u v-1‖ < 1)
    {p q : ℂ} (hp : p ∈ Construction.baseField S) (hq : q ∈ Construction.baseField S)
    (hpi : IsIntegral ℤ p) (hqi : IsIntegral ℤ q) (hq0 : q ≠ 0)
    (hE : 1 < E S u v) (hQ : 1 < Q S u v) :
    ApproximationConclusion (omega S u v ^ (1/4 : ℂ)) p q (rawP S u v) (rawQ S u v)
      AnyBNormSquare.paperK0 (ell S u v) (E S u v) (Q S u v) (3/4) hE (by norm_num) := by
  let K := quadField S
  have hdeg := quad_degree hS
  let _ : FiniteDimensional ℚ K := Module.finite_of_finrank_pos (by rw [hdeg]; decide)
  let _ : NumberField K := { to_charZero := inferInstance, to_finiteDimensional := inferInstance }
  let _ : NumberField.IsTotallyComplex K := quad_complex hS
  let a : K := ⟨p,base_mem hp⟩
  let b : K := ⟨q,base_mem hq⟩
  let d : K := (squarefreePart (Construction.radicand S u v) : K)
  have hd : d ≠ 0 := by dsimp [d]; exact_mod_cast squarefreePart_ne_zero (Construction.radicand S u v)
  have hsq : Construction.gPrime S u v ^ 2 = algebraMap K ℂ d := by
    simpa [d] using Construction.gPrime_sq hS u v
  have hbnd := section42_approximant_bounds hPrior hS hv hw
  apply lemma21 (K := K) hdeg (RingHom.id ℂ) _ d hd hsq _ a b (rawP S u v) (rawQ S u v)
  · exact (isIntegral_algebraMap_iff (R := ℤ) (B := ℂ)).mp hpi
  · exact (isIntegral_algebraMap_iff (R := ℤ) (B := ℂ)).mp hqi
  · exact fun r => (Construction.approximant_fields hS hv hU r).1
  · exact fun r => (Construction.approximant_fields hS hv hU r).2.1
  · intro r
    exact ⟨⟨_,base_mem (Construction.scaled_approximants_mem hS r).1⟩,rfl⟩
  · intro r
    exact ⟨⟨_,base_mem (Construction.scaled_approximants_mem hS r).2⟩,rfl⟩
  · rintro ⟨_,hb⟩; exact hq0 (congrArg Subtype.val hb)
  · norm_num [AnyBNormSquare.paperK0]
  · exact ell_pos hS hv
  · exact hQ
  · norm_num
  · exact fun r => (hbnd r).1
  · intro r; simpa only [RingHom.id_apply,zpow_neg,zpow_natCast,div_eq_mul_inv] using (hbnd r).2
  · exact raw_determinant_ne hS hv

/-- The end of §4.2. Obtain the two §2.2 estimates and the least positive
index for the comparison pair associated with the selected squares. -/
theorem section42_cutoff (hPrior : Hypergeometric.DenominatorEstimate4)
    {P : Parameters} (h : P.Admissible) (hn : P.normAlpha < 0) {i j : ℤ}
    (p : SquarePhase P h.pell i) (q : SquarePhase P h.pell j)
    (hi : i ≠ 0) (hs : IsIntegerSquare (P.y h.pell i))
    (hl : 16*|(P.normAlpha : ℝ)|/Real.sqrt P.d ≤ (P.y h.pell i : ℝ))
    {η : ℂ} (hη : FourthPhase η) (hm : η ∈ Construction.baseField (squarefreePart P.normAlpha)) :
    ∃ X Y : ℤ, P.x h.pell i = (X : ℚ) ∧ P.y h.pell i = (Y : ℚ) ∧
    let S := squarefreePart P.normAlpha
    let u := 2*X
    let v := 2*(AnyBNormSquare.unitPowerNorm P i*squareFactor P.normAlpha)
    let z := star p.datum.point*q.datum.point
    ∃ hE : 1 < E S u v, ApproximationConclusion (P.sequenceOmega h.pell i ^ (1/4 : ℂ))
      (η*star z) z (rawP S u v) (rawQ S u v) AnyBNormSquare.paperK0 (ell S u v)
      (E S u v) (Q S u v) (3/4) hE (by norm_num) := by
  obtain ⟨X,Y,hx,hy,_⟩ := P.section4_integer_coordinates h.pell hs
  have hsize : 16*|(P.normAlpha : ℝ)|/Real.sqrt P.d ≤ (Y : ℝ) := by
    simpa only [hy,Rat.cast_intCast] using hl
  obtain ⟨_,_,_,_,he,hq₁,hq₂,hq₃,_,_,hw⟩ := section42_parameters h hn hi hs hx hy hsize
  obtain ⟨hv,_,_,hω⟩ := section42_coordinates h hn hx hy
  obtain ⟨hz,hzK,hnK,hzi,hni,_⟩ := section42_pair h hn p q hη hm
  refine ⟨X,Y,hx,hy,lt_trans (by norm_num) he,?_⟩
  rw [← hω]
  let Z := AnyBNormSquare.unitPowerNorm P i*squareFactor P.normAlpha
  have hU : U (squarefreePart P.normAlpha) (2*X) (2*Z) =
      quadraticPoint (-squarefreePart P.normAlpha) X Z := by
    apply Complex.ext <;> simp [U_re,U_im,quadraticPoint]
    ring
  have hint := (quadratic_point_data (squarefreePart_neg hn) X Z).2.2.1
  exact section42_apply hPrior (squarefreePart_neg hn) (mul_ne_zero (by decide) hv) (hU ▸ hint) hw
    hnK hzK hni hzi hz (lt_trans (by norm_num) he)
    ((by norm_num : (1 : ℝ) < 2112/100).trans_le (hq₃.trans (hq₂.le.trans hq₁)))

end AnyBAnyNorm
