module

public import AnyBAnyNorm.Section55
public import AnyBNormSquare.Section5Opening

@[expose] public section
namespace AnyBAnyNorm.Section56
open «JNT-2024»

/-- Bounds used in 07g §5.6 after taking the largest value over r₀ ≥ 2. -/
def preliminaryBounds (b d N y : ℝ) : Prop :=
  y < (109/10 : ℝ)*b^(26/11 : ℝ)*N^(26/11 : ℝ)/d^(12/11 : ℝ) ∨
  y < (91/10 : ℝ)*b^(8/3 : ℝ)*N^(5/2 : ℝ)/d^(7/6 : ℝ) ∨
  y ≤ (148/10 : ℝ)*N^(3/2 : ℝ)/Real.sqrt d*(334*b^4*N^(5/2 : ℝ)/d)^(1/3 : ℝ) ∨
  y < (1633/100 : ℝ)*N^(3/2 : ℝ)/Real.sqrt d*Real.sqrt (1340*b^4*N^3/d)

/-- The contradiction on p. 22, retaining both ranges of the integer norm. -/
private theorem third_base {b d N y : ℝ} (hb : 1 ≤ b) (hd : 0 < d) (hN : 1 ≤ N)
    (hy : 0 < y) (hy4 : 4 ≤ y) (hcase : 5 ≤ N ∨ N ≤ 4)
    (hsmall : 334 ≤ d → (2475/10000 : ℝ)*N/b^2 ≤ y)
    (hroot : 334*b^4*N^(5/2 : ℝ)/d ≤ 1 →
      Real.log y ≤ Real.log (148/10 : ℝ)+(3/2)*Real.log N-(1/2)*Real.log d) :
    1 < 334*b^4*N^(5/2 : ℝ)/d := by
  have hpN : 0 < N := by linarith
  have hpb : 0 < b := by linarith
  by_contra! hbad
  have hD := (div_le_one hd).mp hbad
  have hD0 : 334 ≤ d := by
    apply le_trans _ hD
    calc (334 : ℝ) = 334*1*1 := by ring
         _ ≤ _ := by gcongr
                     · exact one_le_pow₀ hb
                     · exact Real.one_le_rpow hN (by norm_num)
  have hL := Real.log_le_log (by positivity) hD
  simp (disch := positivity) only [Real.log_mul,Real.log_pow,Real.log_rpow] at hL
  have hr := Real.log_lt_log (by norm_num : (0 : ℝ)<(148/10)^2)
    (by norm_num : (148/10 : ℝ)^2 < (81/100)^2*334)
  rw [Real.log_mul (by norm_num) (by norm_num)] at hr
  simp only [Real.log_pow,Nat.cast_ofNat] at hr hL
  have hupper : Real.log y < Real.log (81/100 : ℝ)+(1/4)*Real.log N-2*Real.log b := by
    linarith only [hroot hbad,hL,hr]
  rcases hcase with hbig | hfour
  · have hlow := Real.log_le_log (by positivity) (hsmall hD0)
    rw [Real.log_div (by positivity) (by positivity),
      Real.log_mul (by norm_num) hpN.ne',Real.log_pow] at hlow
    have hround := Real.log_lt_log (by norm_num : (0 : ℝ)<(81/100)^4)
      (by norm_num : (81/100 : ℝ)^4 < (2475/10000)^4*5^3)
    rw [Real.log_mul (by norm_num) (by norm_num)] at hround
    simp only [Real.log_pow,Nat.cast_ofNat] at hround hlow
    linarith only [hupper,hlow,hround,Real.log_le_log (by norm_num : (0 : ℝ)<5) hbig]
  · have hround := Real.log_lt_log (by norm_num : (0 : ℝ)<(81/100)^4*4)
      (by norm_num : (81/100 : ℝ)^4*4 < (115/100)^4)
    rw [Real.log_mul (by norm_num) (by norm_num)] at hround
    simp only [Real.log_pow,Nat.cast_ofNat] at hround
    have hy115 : Real.log y < Real.log (115/100 : ℝ) := by
      linarith only [hupper,hround,Real.log_nonneg hb,Real.log_le_log hpN hfour]
    exact (not_lt_of_ge hy4) (((Real.log_lt_log_iff hy (by norm_num)).mp hy115).trans (by norm_num))

theorem preliminary_of_cases (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (K : ℤ) (hK : P.IsNegativeCutoff h.pell K) {k : ℤ} (hk : 3 ≤ k ∨ k ≤ K-2)
    (hs : IsIntegerSquare (P.y h.pell k))
    (hh : CaseBounds P.b P.d |(P.normAlpha : ℝ)| (P.y h.pell k : ℝ)) :
    preliminaryBounds P.b P.d |(P.normAlpha : ℝ)| (P.y h.pell k : ℝ) := by
  let N : ℝ := |(P.normAlpha : ℝ)|
  let b : ℝ := P.b
  let d : ℝ := P.d
  let y : ℝ := P.y h.pell k
  have hb : 1 ≤ b := by dsimp [b]; exact_mod_cast h.b_pos
  have hpb : 0 < b := by linarith
  have hd : 0 < d := by dsimp [d]; exact_mod_cast h.d_pos
  have hNe : N = (-P.normAlpha : ℤ) := by dsimp [N]; rw [abs_of_neg (by exact_mod_cast hn)]; simp
  have hN : 1 ≤ N := by rw [hNe]; exact_mod_cast (show (1 : ℤ) ≤ -P.normAlpha by omega)
  have hpN : 0 < N := by linarith
  have hqby := AnyBNormSquare.Section5Opening.tail_gt_initial P h hn K hK (k := k) (by rcases hk with hh|hh <;> omega)
  have hby : b^2 < y := by dsimp [b,y]; exact_mod_cast hqby
  have hy := (sq_pos_of_pos hpb).trans hby
  rcases hh with h1 | h2 | ⟨n,M,h3,hM,hroot⟩ | ⟨n,M,h1,hM,hroot⟩
  · exact Or.inl h1
  · exact Or.inr (Or.inl h2)
  · apply Or.inr ∘ Or.inr ∘ Or.inl
    change y ≤ (148/10 : ℝ)*N^(3/2 : ℝ)/Real.sqrt d*(334*b^4*N^(5/2 : ℝ)/d)^(1/3 : ℝ)
    have hlog := section45_log_bound hN hd hb hM hby.le h3 hroot
    have hn3 : (3 : ℝ) ≤ n := by exact_mod_cast h3
    let A := 334*b^4*N^(5/2 : ℝ)/d
    have hA : 0 < A := by dsimp [A]; positivity
    have hLA : Real.log A = Real.log 334+4*Real.log b+(5/2)*Real.log N-Real.log d := by
      dsimp [A]; simp (disch := positivity) only [Real.log_div,Real.log_mul,Real.log_pow,Real.log_rpow,Nat.cast_ofNat]
    have hlog' : (n : ℝ)*(Real.log y-(Real.log (148/10 : ℝ)+(3/2)*Real.log N-(1/2)*Real.log d)) ≤ Real.log A := by
      rw [hLA]; nlinarith only [hlog]
    have hy4 : 4 ≤ y := by
      obtain ⟨z,hz⟩ := hs
      have hbi : P.b^2 < z^2 := by
        have hh' : (P.b : ℚ)^2 < P.y h.pell k := hqby
        rw [hz] at hh'; exact_mod_cast hh'
      have hzi : 4 ≤ z^2 := by
        by_cases hzneg : z ≤ -2
        · nlinarith only [mul_nonneg_of_nonpos_of_nonpos (show z+2 ≤ 0 by omega) (show z-2 ≤ 0 by omega)]
        by_cases h' : 2 ≤ z
        · nlinarith only [mul_nonneg (show 0 ≤ z+2 by omega) (show 0 ≤ z-2 by omega)]
        have hh' : z = -1 ∨ z = 0 ∨ z = 1 := by omega
        have := h.b_pos
        rcases hh' with hh'|hh'|hh' <;> subst z <;> norm_num at hbi <;> nlinarith
      dsimp [y]; rw [hz]; exact_mod_cast hzi
    have hgt : 1 < A := by
      apply third_base hb hd hN hy hy4
      · rw [hNe]; exact_mod_cast (show 5 ≤ -P.normAlpha ∨ -P.normAlpha ≤ 4 by omega)
      · intro h334
        have hd334 : 334 ≤ P.d := by dsimp [d] at h334; exact_mod_cast h334
        have hu : (1 : ℤ) ≤ P.u^2 := one_le_pow₀ h.u_pos
        have hdu : 300 ≤ P.d*P.u^2 := by nlinarith only [le_mul_of_one_le_right h.d_pos.le hu,hd334]
        let R : ℚ := (99/100)*P.d*(P.u : ℚ)^2
        have hR : 1 ≤ R := by
          have hdu' : (300 : ℚ) ≤ P.d*(P.u : ℚ)^2 := by exact_mod_cast hdu
          dsimp [R]; nlinarith only [hdu']
        have hseed : 0 ≤ P.lowerSeed := by unfold Parameters.lowerSeed; positivity
        have hg := (lemma33b P h hn K hK).1 (Or.inr hdu)
        have hL : P.lowerSeed ≤ P.y h.pell k := by
          rcases hk with hpos | hneg
          · exact (le_mul_of_one_le_right hseed (one_le_pow₀ hR)).trans (hg.1 k (by omega))
          · exact (le_mul_of_one_le_right hseed (one_le_pow₀ hR)).trans (hg.2 k (by have := hK.1; omega))
        have hu2 : (1 : ℚ) ≤ (P.u : ℚ)^2 := by exact_mod_cast hu
        have hq : (2475/10000 : ℚ)*|(P.normAlpha : ℚ)|/(P.b : ℚ)^2 ≤ P.y h.pell k := by
          apply le_trans _ hL
          unfold Parameters.lowerSeed
          have hbp : (0 : ℚ) < P.b := by exact_mod_cast h.b_pos
          rw [div_le_div_iff₀ (sq_pos_of_pos hbp) (mul_pos (by norm_num) (sq_pos_of_pos hbp))]
          have hm := le_mul_of_one_le_right (abs_nonneg (P.normAlpha : ℚ)) hu2
          have hb2 := sq_nonneg (P.b : ℚ)
          nlinarith only [mul_le_mul_of_nonneg_right hm hb2,mul_nonneg (abs_nonneg (P.normAlpha : ℚ)) hb2]
        dsimp [N,b,y]
        have hr : (((2475/10000 : ℚ)*|(P.normAlpha : ℚ)|/(P.b : ℚ)^2 : ℚ) : ℝ) ≤ (P.y h.pell k : ℝ) := by exact_mod_cast hq
        push_cast at hr
        exact hr
      · intro hbad
        have hla := Real.log_nonpos hA.le hbad
        by_contra! hfail
        exact (not_lt_of_ge (hlog'.trans hla)) (mul_pos (by linarith) (sub_pos.mpr hfail))
    apply (Real.log_le_log_iff hy (by positivity)).mp
    rw [Real.log_mul (by positivity) (by positivity),Real.log_div (by positivity) (by positivity),
      Real.log_mul (by norm_num) (by positivity),Real.log_rpow hpN,Real.log_sqrt hd.le,Real.log_rpow hA]
    by_contra! hf
    have hm := mul_nonneg (show 0 ≤ (n : ℝ)-3 by linarith) (Real.log_nonneg hgt.le)
    have H := mul_lt_mul_of_pos_left hf (show 0 < (n : ℝ) by linarith)
    nlinarith only [hm,H,hlog']
  · exact Or.inr (Or.inr (Or.inr (section46_max hpN hd hb hM hby.le h1 hroot)))

end AnyBAnyNorm.Section56
