module

public import AnyBAnyNorm.Section5Low

@[expose] public section
namespace AnyBAnyNorm

private theorem log_power_round {a b : ℝ} (ha : 0 < a) (k l : ℕ) (h : a^k < b^l) :
    (k : ℝ)*Real.log a < l*Real.log b := by
  simpa only [Real.log_pow] using Real.log_lt_log (pow_pos ha k) h

/-- §5.3. Write n = 2r₀−1. Clearing the positive root exponent gives
the printed discriminant comparison in logarithmic coordinates. -/
theorem section53_separation {b d N u M n : ℝ}
    (hb : 1 ≤ b) (hd : 0 < d) (hN : 1 ≤ N) (hu : 1 ≤ u) (hM : 2 ≤ M)
    (hn : 3 ≤ n)
    (h : (85/10 : ℝ)*b^(20/17 : ℝ)*N^(8/17 : ℝ)/u^(36/17 : ℝ) < d) :
    (592/10 : ℝ)*N^(3/2 : ℝ)/(Real.sqrt d*M^2)*(167*b^4*N^(5/2 : ℝ)*M/d)^(1/(n)) <
      (98/100 : ℝ)*N*d^2*u^6/(4*b^2) := by
  have hbp : 0 < b := by linarith
  have hNp : 0 < N := by linarith
  have hup : 0 < u := by linarith
  have hMp : 0 < M := by linarith
  have hnp : 0 < n := by linarith
  let D := 5*n+2
  have hD : 0 < D := by dsimp [D]; linarith
  have hround := Real.log_lt_log (by norm_num : (0 : ℝ) < (592/10)*4/(98/100))
    (by norm_num : ((592/10)*4/(98/100) : ℝ) < 242)
  have h1 := log_power_round (a := (242 : ℝ)^2/2^4) (b := (5161/1000 : ℝ))
    (by norm_num) 1 5 (by norm_num)
  have h2 := log_power_round (a := (167 : ℝ)^10*2^18/242^4) (b := (1634/1000 : ℝ))
    (by norm_num) 1 85 (by norm_num)
  have hc := Real.log_lt_log (by norm_num : (0 : ℝ) < (5161/1000)*(1634/1000))
    (by norm_num : ((5161/1000)*(1634/1000) : ℝ) < 85/10)
  have h2pos := Real.log_nonneg (show (1 : ℝ) ≤ (1634/1000) by norm_num)
  have ht := Real.log_lt_log (by positivity) h
  simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_pow, Real.log_rpow] at h1 h2 hc h2pos hround ht
  norm_num1 at h1 h2 hc h2pos hround ht
  have hscale := mul_lt_mul_of_pos_left ht hD
  have hcoef := mul_lt_mul_of_pos_left h1 hD
  have hprod := mul_lt_mul_of_pos_left hc hD
  have hrem := mul_nonneg (show 0 ≤ D-17 by dsimp [D]; linarith) h2pos
  have hbexp := mul_nonneg (sub_nonneg.mpr hn) (Real.log_nonneg hb)
  have hNexp := mul_nonneg (sub_nonneg.mpr hn) (Real.log_nonneg hN)
  have huexp := mul_nonneg (sub_nonneg.mpr hn) (Real.log_nonneg hu)
  have hm := Real.log_le_log (by norm_num : (0 : ℝ)<2) hM
  have hMexp := mul_le_mul_of_nonneg_left hm (show 0 ≤ 4*n-2 by linarith)
  have hr := mul_lt_mul_of_pos_left hround hnp
  dsimp [D] at hscale hcoef hprod hrem
  by_contra! hbad
  have hl := Real.log_le_log (by positivity) hbad
  simp (disch := positivity) only [Real.log_mul,Real.log_div,Real.log_sqrt,Real.log_rpow,Real.log_pow] at hl
  norm_num1 at hl
  field_simp at hl
  nlinarith only [hl, hscale, hcoef, hprod, h2, hrem, hbexp, hNexp, huexp, hMexp, hr]

/-- §5.3, last display. Substitute |Nα| < db⁴. -/
theorem section53_norm_free {b d N u : ℝ} (hb : 0 < b) (hd : 0 < d) (hN : 0 < N)
    (hu : 0 < u) (hs : N < d*b^4)
    (h : 57*b^(52/9 : ℝ)/u^4 ≤ d) :
    (85/10 : ℝ)*b^(20/17 : ℝ)*N^(8/17 : ℝ)/u^(36/17 : ℝ) < d := by
  apply (Real.log_lt_log_iff (by positivity) hd).mp
  have ht := Real.log_le_log (by positivity) h
  have hsub := Real.log_lt_log hN hs
  have hc := log_power_round (a := (85/10:ℝ)) (b := 57) (by norm_num)
    17 9 (by norm_num)
  simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_rpow, Real.log_pow] at ht hsub hc ⊢
  norm_num1 at ht hsub hc ⊢
  linarith only [ht,hsub,hc]

/-- §5.4. Write n = r₀−1. Clearing the positive root exponent gives
the printed discriminant comparison in logarithmic coordinates. -/
theorem section54_separation {b d N u M n : ℝ}
    (hb : 1 ≤ b) (hd : 0 < d) (hN : 1 ≤ N) (hu : 1 ≤ u) (hM : 2 ≤ M)
    (hn : 1 ≤ n)
    (h : (135/10 : ℝ)*b^(4/3 : ℝ)*N^(2/3 : ℝ)/u^(2 : ℝ) < d) :
    (6532/100 : ℝ)*N^(3/2 : ℝ)/(Real.sqrt d*M^2)*(1340*b^4*N^3/d)^(1/(2*n)) <
      (98/100 : ℝ)*N*d^2*u^6/(4*b^2) := by
  have hbp : 0 < b := by linarith
  have hNp : 0 < N := by linarith
  have hup : 0 < u := by linarith
  have hMp : 0 < M := by linarith
  have hnp : 0 < n := by linarith
  let D := 5*n+1
  have hD : 0 < D := by dsimp [D]; linarith
  have hround := Real.log_lt_log (by norm_num : (0 : ℝ) < (6532/100)*4/(98/100))
    (by norm_num : ((6532/100)*4/(98/100) : ℝ) < 267)
  have h1 := log_power_round (a := (267 : ℝ)^2/2^4) (b := (5368/1000 : ℝ))
    (by norm_num) 1 5 (by norm_num)
  have h2 := log_power_round (a := (1340 : ℝ)^5*2^4/267^2) (b := (251/100 : ℝ))
    (by norm_num) 1 30 (by norm_num)
  have hc := Real.log_lt_log (by norm_num : (0 : ℝ) < (5368/1000)*(251/100))
    (by norm_num : ((5368/1000)*(251/100) : ℝ) < 135/10)
  have h2pos := Real.log_nonneg (show (1 : ℝ) ≤ (251/100) by norm_num)
  have ht := Real.log_lt_log (by positivity) h
  simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_pow, Real.log_rpow] at h1 h2 hc h2pos hround ht
  norm_num1 at h1 h2 hc h2pos hround ht
  have hscale := mul_lt_mul_of_pos_left ht hD
  have hcoef := mul_lt_mul_of_pos_left h1 hD
  have hprod := mul_lt_mul_of_pos_left hc hD
  have hrem := mul_nonneg (show 0 ≤ D-6 by dsimp [D]; linarith) h2pos
  have hbexp := mul_nonneg (sub_nonneg.mpr hn) (Real.log_nonneg hb)
  have hNexp := mul_nonneg (sub_nonneg.mpr hn) (Real.log_nonneg hN)
  have huexp := mul_nonneg (sub_nonneg.mpr hn) (Real.log_nonneg hu)
  have hm := Real.log_le_log (by norm_num : (0 : ℝ)<2) hM
  have hMexp := mul_le_mul_of_nonneg_left hm (show 0 ≤ 4*n by linarith)
  have hr := mul_lt_mul_of_pos_left hround hnp
  dsimp [D] at hscale hcoef hprod hrem
  by_contra! hbad
  have hl := Real.log_le_log (by positivity) hbad
  simp (disch := positivity) only [Real.log_mul,Real.log_div,Real.log_sqrt,Real.log_rpow,Real.log_pow] at hl
  norm_num1 at hl
  field_simp at hl
  nlinarith only [hl, hscale, hcoef, hprod, h2, hrem, hbexp, hNexp, huexp, hMexp, hr]

/-- §5.4, last display. Substitute |Nα| < db⁴. -/
theorem section54_norm_free {b d N u : ℝ} (hb : 0 < b) (hd : 0 < d) (hN : 0 < N)
    (hu : 0 < u) (hs : N < d*b^4)
    (h : 2461*b^12/u^6 ≤ d) :
    (135/10 : ℝ)*b^(4/3 : ℝ)*N^(2/3 : ℝ)/u^(2 : ℝ) < d := by
  apply (Real.log_lt_log_iff (by positivity) hd).mp
  have ht := Real.log_le_log (by positivity) h
  have hsub := Real.log_lt_log hN hs
  have hc := log_power_round (a := (135/10:ℝ)) (b := 2461) (by norm_num)
    3 1 (by norm_num)
  simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_rpow, Real.log_pow] at ht hsub hc ⊢
  norm_num1 at ht hsub hc ⊢
  linarith only [ht,hsub,hc]

end AnyBAnyNorm
