module

public import «JNT-2024».ImaginaryQuadraticApproximation

@[expose] public section

namespace AnyBAnyNorm
open «JNT-2024» «JNT-2024».Approximation

/-- The literal conclusion, including the least positive cutoff index and both
strict estimates. -/
def ApproximationConclusion (θ p q : ℂ) (pr qr : ℕ → ℂ)
    (k₀ ℓ₀ E Q c : ℝ) (hE : 1 < E) (hc : 0 < c) : Prop :=
  let r₀ := firstIndex (Q := Q) (ℓ := ℓ₀) hE hc q
  IsLeast {r : ℕ | 0 < r ∧ (Q - 1/E)*ℓ₀*‖q‖/(Q-1) < c*E^r} r₀ ∧
    (1-c/E)/(k₀*Q^(r₀+1)) < ‖q*θ-p‖ ∧
    (p*qr r₀ ≠ q*pr r₀ → (1-c)/(k₀*Q^r₀) < ‖q*θ-p‖)

/-- The algebraic-integer norm step after descent to the imaginary quadratic field. -/
theorem descended_integer_norm {K L : Type*} [Field K] [NumberField K]
    [NumberField.IsTotallyComplex K] [Field L] [Algebra K L]
    (hdegree : Module.finrank ℚ K = 2) (f : L →+* ℂ) (z : L)
    (hz : IsIntegral ℤ z) (hne : z ≠ 0)
    (hbase : ∃ a : K, algebraMap K L a = z) : 1 ≤ ‖f z‖ := by
  obtain ⟨a,ha⟩ := hbase
  have hi : IsIntegral ℤ a := (isIntegral_algebraMap_iff (R := ℤ) (B := L)).mp
    (by rw [ha]; exact hz)
  have hn : a ≠ 0 := by intro h; apply hne; rw [← ha,h,map_zero]
  simpa only [RingHom.comp_apply,ha] using
    imaginaryQuadratic_integer_norm_ge_one hdegree (f.comp (algebraMap K L)) hi hn

/-- The final sentence of the printed extension argument: descend the integral
square, then use |z²|=|z|² to conclude |z|≥1. -/
theorem descended_square_norm {K L : Type*} [Field K] [NumberField K]
    [NumberField.IsTotallyComplex K] [Field L] [Algebra K L]
    (hdegree : Module.finrank ℚ K = 2) (f : L →+* ℂ) (z : L)
    (hz : IsIntegral ℤ z) (hne : z ≠ 0)
    (hbase : ∃ a : K, algebraMap K L a = z^2) : 1 ≤ ‖f z‖ := by
  have hh := descended_integer_norm hdegree f (z^2) (hz.pow 2) (pow_ne_zero 2 hne) hbase
  rw [map_pow,norm_pow] at hh
  nlinarith [norm_nonneg (f z)]

/-- Reuse the original published determinant/successor proof once the new
discreteness premise is established. This is not the alternative proof. -/
theorem approximation_of_discrete (θ p q : ℂ) (pr qr : ℕ → ℂ)
    (hpq : ¬ (p=0 ∧ q=0))
    {k₀ ℓ₀ E Q c : ℝ} (hk : 0 < k₀) (hℓ : 0 < ℓ₀)
    (hE : 1 < E) (hQ : 1 < Q) (hc : 0 < c) (hc1 : c < 1)
    (hqb : ∀ r, ‖qr r‖ < k₀*Q^r)
    (herr : ∀ r, ‖qr r*θ-pr r‖ ≤ ℓ₀*E^(-(r : ℤ)))
    (hind : ∀ r, pr r*qr (r+1) ≠ pr (r+1)*qr r)
    (hdiscrete : ∀ r, pr r*q-qr r*p ≠ 0 → 1 ≤ ‖pr r*q-qr r*p‖) :
    ApproximationConclusion θ p q pr qr k₀ ℓ₀ E Q c hE hc := by
  have he : ∀ r, ‖qr r*θ-pr r‖ ≤ ℓ₀/E^r := by
    intro r; simpa only [zpow_neg,zpow_natCast,div_eq_mul_inv] using herr r
  have hh := lemma21_complex_published hk hℓ hE hQ hc hc1 hpq hqb he
    (fun r => sub_ne_zero.mpr (hind r)) hdiscrete (firstIndex_spec (Q := Q) (ℓ := ℓ₀) hE hc q).2
  refine ⟨⟨firstIndex_spec hE hc q, fun _ hr => firstIndex_le hE hc q hr.1 hr.2⟩,hh.1,?_⟩
  intro hne
  apply hh.2
  apply sub_ne_zero.mpr
  simpa only [mul_comm] using hne.symm

/-- Direct descent: squaring cancels the common quadratic scaling. No field
generation, automorphism, or integrality of the scaling data is needed. -/
theorem square_of_scaled_mem {K L : Type*} [Field K] [Field L] [Algebra K L]
    (g z : L) (d : K) (hd : d ≠ 0) (hsq : g^2 = algebraMap K L d)
    (r : ℕ) (hz : ∃ a : K, algebraMap K L a = g^r*z) :
    ∃ a : K, algebraMap K L a = z^2 := by
  obtain ⟨a,ha⟩ := hz
  refine ⟨a^2/d^r,?_⟩
  have hdn : algebraMap K L (d^r) ≠ 0 :=
    (map_ne_zero (algebraMap K L)).mpr (pow_ne_zero r hd)
  rw [map_div₀, div_eq_iff hdn, map_pow, ha, mul_pow]
  have hg : (g^r)^2 = algebraMap K L (d^r) := by
    rw [← pow_mul, Nat.mul_comm r 2, pow_mul, hsq, map_pow]
  rw [hg, mul_comm]

/-- The determinant has a common scale in K, so its square descends directly. -/
theorem determinant_norm {K L : Type*} [Field K] [NumberField K]
    [NumberField.IsTotallyComplex K] [Field L] [Algebra K L]
    (hdegree : Module.finrank ℚ K = 2) (f : L →+* ℂ)
    (g : L) (d : K) (hd : d ≠ 0) (hsq : g^2 = algebraMap K L d)
    (p q : K) (hp : IsIntegral ℤ p) (hq : IsIntegral ℤ q)
    (pr qr : L) (hpr : IsIntegral ℤ pr) (hqr : IsIntegral ℤ qr) (r : ℕ)
    (hps : ∃ a : K, algebraMap K L a = g^r*pr)
    (hqs : ∃ a : K, algebraMap K L a = g^r*qr)
    (hne : pr*algebraMap K L q-qr*algebraMap K L p ≠ 0) :
    1 ≤ ‖f (pr*algebraMap K L q-qr*algebraMap K L p)‖ := by
  have hpi : IsIntegral ℤ (algebraMap K L p) :=
    (isIntegral_algebraMap_iff (R := ℤ) (B := L)).mpr hp
  have hqi : IsIntegral ℤ (algebraMap K L q) :=
    (isIntegral_algebraMap_iff (R := ℤ) (B := L)).mpr hq
  apply descended_square_norm hdegree f _ ((hpr.mul hqi).sub (hqr.mul hpi)) hne
  apply square_of_scaled_mem g _ d hd hsq r
  obtain ⟨a,ha⟩ := hps
  obtain ⟨b,hb⟩ := hqs
  refine ⟨a*q-b*p,?_⟩
  simp only [map_sub,map_mul,ha,hb]
  ring

/-- Lemma 2.1, TeX lines 632–684 and PDF page 7. The chosen complex
embedding represents the ambient field inclusion. -/
theorem lemma21 {K L : Type*} [Field K] [NumberField K]
    [NumberField.IsTotallyComplex K] [Field L] [Algebra K L]
    (hdegree : Module.finrank ℚ K = 2) (f : L →+* ℂ)
    (g : L) (d : K) (hd : d ≠ 0) (hsq : g^2 = algebraMap K L d)
    (θ : ℂ) (p q : K) (pr qr : ℕ → L)
    (hp : IsIntegral ℤ p) (hq : IsIntegral ℤ q)
    (hpr : ∀ r, IsIntegral ℤ (pr r)) (hqr : ∀ r, IsIntegral ℤ (qr r))
    (hps : ∀ r, ∃ a : K, algebraMap K L a = g^r*pr r)
    (hqs : ∀ r, ∃ a : K, algebraMap K L a = g^r*qr r)
    (hpq : ¬ (p=0 ∧ q=0))
    {k₀ ℓ₀ E Q c : ℝ} (hk : 0 < k₀) (hℓ : 0 < ℓ₀)
    (hE : 1 < E) (hQ : 1 < Q) (hc : 0 < c) (hc1 : c < 1)
    (hqb : ∀ r, ‖f (qr r)‖ < k₀*Q^r)
    (herr : ∀ r, ‖f (qr r)*θ-f (pr r)‖ ≤ ℓ₀*E^(-(r : ℤ)))
    (hind : ∀ r, pr r*qr (r+1) ≠ pr (r+1)*qr r) :
    ApproximationConclusion θ (f (algebraMap K L p)) (f (algebraMap K L q))
      (fun r => f (pr r)) (fun r => f (qr r)) k₀ ℓ₀ E Q c hE hc := by
  apply approximation_of_discrete θ _ _ _ _ ?_ hk hℓ hE hQ hc hc1 hqb herr ?_ ?_
  · intro hh
    apply hpq
    exact ⟨(map_eq_zero (f.comp (algebraMap K L))).mp hh.1,
      (map_eq_zero (f.comp (algebraMap K L))).mp hh.2⟩
  · intro r he
    exact hind r (f.injective (by simpa only [map_mul] using he))
  · intro r hn
    rw [← map_mul,← map_mul,← map_sub] at hn ⊢
    apply determinant_norm hdegree f g d hd hsq p q hp hq (pr r) (qr r)
      (hpr r) (hqr r) r (hps r) (hqs r)
    exact fun h => hn (by rw [h,map_zero])

end AnyBAnyNorm
