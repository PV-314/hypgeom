module

public import AnyBAnyNorm.PostJava
public import AnyBNormSquare.Targets
public import Mathlib.Algebra.IsPrimePow
public import Mathlib.Data.Nat.MaxPowDiv

@[expose] public section
namespace AnyBAnyNorm.Section56
open «JNT-2024» AnyBNormSquare

/-- §5.6 tests the square case and the PP case, including exponent zero. -/
def coveredNorm (n : ℕ) : Bool :=
  let oddPart := n.divMaxPow 2
  decide (n.sqrt ^ 2 = n ∨ oddPart = 1 ∨ IsPrimePow oddPart)

/-- Distinct equations are identified by the pair (d,Nα). -/
def postJavaEquations : Finset (ℤ × ℤ) :=
  (postJavaTuples.map fun P => (P.d, P.normAlpha)).toFinset

set_option maxRecDepth 16384 in
set_option maxHeartbeats 6000000 in
theorem postJava_partition :
    (postJavaEquations.filter (fun e => coveredNorm e.2.natAbs = true)).card = 68 ∧
    (postJavaEquations.filter (fun e => coveredNorm e.2.natAbs = false)).card = 94 := by
  decide +kernel

/-- Theorem 1.8(a) of [13], as cited in 07e. This is an explicit external premise. -/
def PrimePowerTheorem18a : Prop :=
  ∀ (P : Parameters) (h : P.Admissible), P.normAlpha < 0 →
    (∃ p ℓ m : ℕ, p.Prime ∧ p ≠ 2 ∧ P.normAlpha.natAbs = 2^ℓ * p^m) →
    SmallestInitialSquare P h.pell → P.b ≤ 7 → ∀ K, P.IsNegativeCutoff h.pell K →
      AtMostSquareValuesOn (P.y h.pell) (fun k => 2 ≤ k ∨ k ≤ K-1) 4

/-- Restrict the two cited tail bounds to the indices of Theorem 1.8(a). -/
theorem covered_tail (hSquare : AnyBNormSquare.Theorem14a) (hPP : PrimePowerTheorem18a)
    (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (hmin : SmallestInitialSquare P h.pell) (hb : P.b ≤ 4)
    (hc : coveredNorm P.normAlpha.natAbs = true) (K : ℤ) (hK : P.IsNegativeCutoff h.pell K) :
    AtMostSquareValuesOn (P.y h.pell) (fun k => 3 ≤ k ∨ k ≤ K-2) 4 := by
  let n := P.normAlpha.natAbs
  have hcast : (n : ℤ) = -P.normAlpha := by
    simp [n, abs_of_neg hn]
  have hn0 : n ≠ 0 := Int.natAbs_ne_zero.mpr hn.ne
  have hh : n.sqrt ^ 2 = n ∨ n.divMaxPow 2 = 1 ∨ IsPrimePow (n.divMaxPow 2) := by
    simpa [coveredNorm, n] using hc
  have small : AtMostSquareValuesOn (P.y h.pell) (fun k => 2 ≤ k ∨ k ≤ K-1) 4 := by
    rcases hh with hs | hodd
    · have hs' : IsSquare (-P.normAlpha) := by
        refine ⟨(n.sqrt : ℤ), ?_⟩
        rw [← hcast]
        exact_mod_cast (by simpa [pow_two] using hs.symm : n = n.sqrt * n.sqrt)
      have had : AdmissibleB P.b := by
        have hbpos := h.b_pos
        refine ⟨1, P.b.toNat, by simp [Int.toNat_of_nonneg hbpos.le], by omega, Or.inl rfl, ?_⟩
        intro p hp hd
        have hle := Nat.le_of_dvd (show 0 < P.b.toNat by omega) hd
        have := hp.two_le
        omega
      obtain ⟨S, hcard, hcover⟩ := hSquare P h hn hs' hmin had K hK
      exact ⟨S, by omega, hcover⟩
    · have hspec : n.divMaxPow 2 * 2^(Nat.maxPowDvdDiv 2 n).1 = n := by
        simpa [Nat.divMaxPow, Nat.maxPowDvdDiv, hn0] using
          (Nat.maxPowDvdDiv.go_spec (n := n) (p := 2) ⟨by decide, hn0⟩).1
      apply hPP P h hn _ hmin (by omega) K hK
      rcases hodd with hone | hpow
      · exact ⟨3, _, 0, by decide, by decide, by simpa [hone] using hspec.symm⟩
      · obtain ⟨p, m, hp, hm, he⟩ := (isPrimePow_nat_iff _).mp hpow
        have hn2 := Nat.not_dvd_divMaxPow (by decide : 1 < 2) hn0
        have hp2 : p ≠ 2 := by
          rintro rfl
          exact hn2 (he ▸ dvd_pow_self 2 hm.ne')
        refine ⟨p, (Nat.maxPowDvdDiv 2 n).1, m, hp, hp2, ?_⟩
        change n = 2^(Nat.maxPowDvdDiv 2 n).1 * p^m
        rw [he, mul_comm]
        exact hspec.symm
  obtain ⟨S, hcard, hcover⟩ := small
  exact ⟨S, hcard, fun k hk => hcover k (by rcases hk with hk | hk <;> omega)⟩

end AnyBAnyNorm.Section56
