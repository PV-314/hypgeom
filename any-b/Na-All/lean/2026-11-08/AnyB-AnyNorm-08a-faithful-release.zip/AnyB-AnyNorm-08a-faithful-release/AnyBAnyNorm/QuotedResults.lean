module

public import AnyBNormSquare.Corollary16
public import «JNT-2024».Section5AssemblyRevised

@[expose] public section
namespace AnyBAnyNorm.QuotedResults
open «JNT-2024» AnyBNormSquare

/-- The two conjectures quoted in §1.3, with their original quantifiers. -/
abbrev conjecture11 := AnyBNormSquare.Conjecture11
abbrev conjecture12 := AnyBNormSquare.Conjecture12

/-- 07g Theorem 1.3, including the four exceptional cases as corrected in [10]. -/
abbrev theorem13 := @«JNT-2024».theorem14_paper_revised

/-- 07g Theorem 1.4, quoted from [11]. The paper supplies no proof of [11] here. -/
def Theorem14 : Prop :=
  ∀ (P : Parameters) (h : P.Admissible), P.b=1 →
    (∃ (p m s : ℕ), p.Prime ∧ s ≤ 4 ∧ -P.normAlpha = ((2^s*p^m : ℕ) : ℤ)) →
    AtMostSquareValues (P.y h.pell) 4 ∧
    ((∃ p : ℕ, p.Prime ∧ Odd p ∧ squarefreePart |P.normAlpha| ∣ 2*(p : ℤ)) →
      AtMostSquareValues (P.y h.pell) 3) ∧
    (IsSquare |P.normAlpha| → AtMostSquareValues (P.y h.pell) 2)

/-- 07g Theorem 1.5(a) and (b), proved in the supplied square-norm release. -/
abbrev theorem15a := @AnyBNormSquare.CorollaryProof.corollary15a_conditional
abbrev theorem15b := @AnyBNormSquare.CorollaryProof.corollary15b_conditional

/-- 07g Theorem 1.6, quoted from [13]. Its cited sequence bound for the
indices used in §5.6 is separately identified in Section56Norms. -/
def Theorem16 : Prop :=
  ∀ (P : Parameters) (h : P.Admissible), P.normAlpha < 0 →
    (∃ (p m l : ℕ), p.Prime ∧ p ≠ 2 ∧ -P.normAlpha = ((2^l*p^m : ℕ) : ℤ)) →
    SmallestInitialSquare P h.pell →
    (P.b ≤ 7 ∨ (8 ≤ P.b ∧ 37*(P.b : ℝ)^(28/13 : ℝ)*|(P.normAlpha : ℝ)|^(1/2 : ℝ)/
       (P.u : ℝ)^(24/13 : ℝ) ≤ P.d)) → AtMostSquareValues (P.y h.pell) 7

end AnyBAnyNorm.QuotedResults
