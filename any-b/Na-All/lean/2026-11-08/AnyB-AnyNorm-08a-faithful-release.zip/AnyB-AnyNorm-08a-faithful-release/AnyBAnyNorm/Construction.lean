module

public import AnyBNormSquare.Construction

@[expose] public section

namespace AnyBAnyNorm.Construction

open «JNT-2024» «JNT-2024».Approximation «JNT-2024».Section2 «JNT-2024».Hypergeometric

/-- The integer whose squarefree part defines g′ in §2.1, lines 604–610. -/
def radicand (t u₁ u₂ : ℤ) : ℤ := (g2 t u₁ u₂ : ℤ) * g3 t u₁ u₂

noncomputable def gPrime (t u₁ u₂ : ℤ) : ℂ :=
  (Real.sqrt (squarefreePart (radicand t u₁ u₂) : ℝ) : ℂ)

/-- The subfields ℚ(√t′) and ℚ(√t′, g′) of the chosen complex embedding. -/
noncomputable def baseField (t : ℤ) : Subfield ℂ := Subfield.closure {root t}
noncomputable def extensionField (t u₁ u₂ : ℤ) : Subfield ℂ := Subfield.closure {root t, gPrime t u₁ u₂}

private theorem radicand_pos {t : ℤ} (ht : t < 0) (u₁ u₂ : ℤ) :
    0 < radicand t u₁ u₂ := by
  exact mul_pos (by exact_mod_cast g2_pos ht.ne u₁ u₂) (by exact_mod_cast g3_pos t u₁ u₂)

private theorem core_pos {b : ℤ} (hb : 0 < b) : 0 < squarefreePart b := by
  exact pos_of_mul_pos_right (squareFactor_sq_mul b ▸ hb) (sq_nonneg _)

theorem gPrime_sq {t : ℤ} (ht : t < 0) (u₁ u₂ : ℤ) :
    gPrime t u₁ u₂ ^ 2 = (squarefreePart (radicand t u₁ u₂) : ℂ) := by
  have hs := core_pos (radicand_pos ht u₁ u₂)
  unfold gPrime
  exact_mod_cast Real.sq_sqrt (by exact_mod_cast hs.le :
    0 ≤ (squarefreePart (radicand t u₁ u₂) : ℝ))

private theorem gPrime_ne_zero {t : ℤ} (ht : t < 0) (u₁ u₂ : ℤ) : gPrime t u₁ u₂ ≠ 0 := by
  unfold gPrime
  exact_mod_cast (Real.sqrt_pos.mpr (by exact_mod_cast core_pos (radicand_pos ht u₁ u₂) :
    0 < (squarefreePart (radicand t u₁ u₂) : ℝ))).ne'

/-- Extract the rational square factor from g = g₁√(g₂/g₃). -/
private theorem g_eq_rational_mul_gPrime (t u₁ u₂ : ℤ) :
    (g t u₁ u₂ : ℂ) =
      ((g1 u₁ u₂ : ℂ) * (squareFactor (radicand t u₁ u₂) : ℂ) / g3 t u₁ u₂) *
        gPrime t u₁ u₂ := by
  let b := radicand t u₁ u₂
  have h₃ : (0 : ℝ) < g3 t u₁ u₂ := by exact_mod_cast g3_pos t u₁ u₂
  have hfac : (squareFactor b : ℝ) ^ 2 * (squarefreePart b : ℝ) = (b : ℝ) := by
    exact_mod_cast squareFactor_sq_mul b
  have hroot : Real.sqrt (b : ℝ) = (squareFactor b : ℝ) * Real.sqrt (squarefreePart b : ℝ) := by
    conv_lhs => rw [← hfac, Real.sqrt_mul (sq_nonneg _), Real.sqrt_sq
      (by exact_mod_cast squareFactor_nonneg b)]
  have hdiv : (g2 t u₁ u₂ : ℝ) / g3 t u₁ u₂ = (b : ℝ) / (g3 t u₁ u₂ : ℝ) ^ 2 := by
    simp only [b, radicand, Int.cast_mul, Int.cast_natCast]
    field_simp
  unfold g gPrime
  push_cast
  rw [hdiv, Real.sqrt_div' _ (sq_nonneg _), hroot, Real.sqrt_sq h₃.le]
  push_cast
  ring

private theorem scaled_A_mem {t u₁ u₂ : ℤ} (ht : t < 0) :
    gPrime t u₁ u₂ * A t u₁ u₂ ∈ baseField t := by
  have hroot : root t ∈ baseField t := Subfield.subset_closure (Set.mem_singleton _)
  rw [A, g_eq_rational_mul_gPrime, mul_div_assoc', mul_comm (gPrime t u₁ u₂),
    mul_div_mul_right _ _ (gPrime_ne_zero ht u₁ u₂), AnyBNormSquare.Construction.conjugate_U]
  exact div_mem (div_mem (sub_mem (intCast_mem _ _) (mul_mem (intCast_mem _ _) hroot))
    (ofNat_mem _ _)) (div_mem (mul_mem (natCast_mem _ _) (intCast_mem _ _)) (natCast_mem _ _))

/-- The scaling premise needed in Lemma 2.1, for the actual pᵣ and qᵣ. -/
theorem scaled_approximants_mem {t u₁ u₂ : ℤ} (ht : t < 0) (r : ℕ) :
    gPrime t u₁ u₂ ^ r * rawP t u₁ u₂ r ∈ baseField t ∧
    gPrime t u₁ u₂ ^ r * rawQ t u₁ u₂ r ∈ baseField t := by
  have hroot : root t ∈ baseField t := Subfield.subset_closure (Set.mem_singleton _)
  have hw : omega t u₁ u₂ ∈ baseField t := by
    rw [omega, AnyBNormSquare.Construction.conjugate_U, U]
    apply div_mem <;> apply div_mem _ (ofNat_mem _ _)
    · exact add_mem (intCast_mem _ _) (mul_mem (intCast_mem _ _) hroot)
    · exact sub_mem (intCast_mem _ _) (mul_mem (intCast_mem _ _) hroot)
  have hs : gPrime t u₁ u₂ ^ r * rawScale t u₁ u₂ r ∈ baseField t := by
    rw [rawScale, mul_left_comm, ← mul_pow]
    exact mul_mem (div_mem (natCast_mem _ _) (natCast_mem _ _)) (pow_mem (scaled_A_mem ht) _)
  constructor
  · rw [rawP, ← mul_assoc]
    exact mul_mem hs (sum_mem fun _ _ => mul_mem (SubfieldClass.ratCast_mem _ _) (pow_mem hw _))
  · rw [rawQ, ← mul_assoc]
    exact mul_mem hs (sum_mem fun _ _ => mul_mem (SubfieldClass.ratCast_mem _ _) (pow_mem hw _))

private theorem parity_membership {K L : Subfield ℂ} {s z : ℂ} {r : ℕ}
    (hs : s ≠ 0) (hsq : s ^ 2 ∈ K) (hKL : K ≤ L) (hsL : s ∈ L)
    (hz : s ^ r * z ∈ K) :
    (Even r → z ∈ K) ∧ (Odd r → z ∈ L ∧ s * z ∈ K) := by
  constructor
  · rintro ⟨j, rfl⟩
    have hpow : s ^ (j + j) ∈ K := by rw [← two_mul, pow_mul]; exact pow_mem hsq _
    simpa only [mul_div_cancel_left₀ _ (pow_ne_zero _ hs)] using div_mem hz hpow
  · rintro ⟨j, rfl⟩
    have hpow : s ^ (2 * j) ∈ K := by rw [pow_mul]; exact pow_mem hsq _
    rw [pow_succ, mul_assoc] at hz
    have hsz : s * z ∈ K := by
      simpa only [mul_div_cancel_left₀ _ (pow_ne_zero _ hs)] using div_mem hz hpow
    exact ⟨by simpa only [mul_div_cancel_left₀ _ hs] using div_mem (hKL hsz) hsL, hsz⟩

/-- §2.1, lines 604–609. Both raw approximants are integral. For even r
they lie in K. For odd r they lie in K(g′), and multiplying once by g′
puts each of them in K. -/
theorem approximant_fields {t u₁ u₂ : ℤ} (ht : t < 0) (hu₂ : u₂ ≠ 0)
    (_hU : IsIntegral ℤ (U t u₁ u₂)) (r : ℕ) :
    let p := rawP t u₁ u₂ r
    let q := rawQ t u₁ u₂ r
    let K := baseField t
    let L := extensionField t u₁ u₂
    let s := gPrime t u₁ u₂
    IsIntegral ℤ p ∧ IsIntegral ℤ q ∧ (Even r → p ∈ K ∧ q ∈ K) ∧
      (Odd r → p ∈ L ∧ q ∈ L ∧ s * p ∈ K ∧ s * q ∈ K) := by
  dsimp only
  have hKL : baseField t ≤ extensionField t u₁ u₂ := Subfield.closure_mono (by simp)
  have hsL : gPrime t u₁ u₂ ∈ extensionField t u₁ u₂ := Subfield.subset_closure (by simp)
  have hsq : gPrime t u₁ u₂ ^ 2 ∈ baseField t := by rw [gPrime_sq ht]; exact intCast_mem _ _
  obtain ⟨hp, hq⟩ := scaled_approximants_mem (u₁ := u₁) (u₂ := u₂) ht r
  have p := parity_membership (gPrime_ne_zero ht u₁ u₂) hsq hKL hsL hp
  have q := parity_membership (gPrime_ne_zero ht u₁ u₂) hsq hKL hsL hq
  exact ⟨rawP_integral ht hu₂ r, rawQ_integral ht hu₂ r, fun h => ⟨p.1 h, q.1 h⟩,
    fun h => ⟨(p.2 h).1, (q.2 h).1, (p.2 h).2, (q.2 h).2⟩⟩

/-- §2.1, lines 595 and 612–614. On the printed domain, the approximation
error is the common scale times the displayed Gauss remainder. -/
theorem error_eq_scaled_gauss {t u₁ u₂ : ℤ} (r : ℕ)
    (hnear : ‖omega t u₁ u₂ - 1‖ < 1) :
    let w := omega t u₁ u₂
    rawQ t u₁ u₂ r * w ^ (1 / 4 : ℂ) - rawP t u₁ u₂ r =
      rawScale t u₁ u₂ r * ((w - 1) ^ (2 * r + 1) *
        (remainderPrefactor (1 / 4) r : ℂ) *
        ₂F₁ (r + 1 - (1 / 4 : ℂ)) (r + 1) (2 * r + 2) (1 - w)) := by
  dsimp only
  rw [raw_error_identity hnear r, rawR, AnyBNormSquare.Construction.remainder_formula r hnear]

end AnyBAnyNorm.Construction
