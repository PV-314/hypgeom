module

public import AnyBAnyNorm.MainStatements
public import AnyBAnyNorm.ZeroRealSequence
public import AnyBNormSquare.Reindex

@[expose] public section
namespace AnyBAnyNorm
open «JNT-2024» AnyBNormSquare AnyBNormSquare.Reindex

/-- The hypothesis on the least square in either parity in Corollary 1.10. -/
def LeastSmallSquare (y : ℤ → ℚ) : Prop :=
  ∃ i b : ℤ, 0 < b ∧ b ≤ 4 ∧ y i = (b : ℚ)^2 ∧
    ∀ j, IsIntegerSquare (y j) → (b : ℚ)^2 ≤ y j

def Corollary110 : Prop :=
  ∀ (P : Parameters) (h : P.Admissible), P.normAlpha < 0 → P.epsilonNorm = 1 →
    LeastSmallSquare (fun j => P.generalY h.pell (2*j)) →
    LeastSmallSquare (fun j => P.generalY h.pell (2*j+1)) →
    AtMostSquareValues (P.generalY h.pell) 18

/-- Replacing α by a purely imaginary term at a square, as in §1.2. -/
private theorem zero_orbit (hc : ExternalResults.CohnTheorem) (P : Parameters) (h : P.Admissible)
    (w : P.Algebra) {b : ℤ} (hb : 0 < b) (hx : w.re=0) (hy : w.im=(b : ℚ)^2) :
    AtMostSquareValues (orbitY P h.pell w) 2 := by
  let Q : Parameters := {P with a:=0,b:=b}
  let : Fact (¬ IsSquare Q.d) := ⟨h.d_not_square⟩
  have hw : Q.alpha = w := by ext <;> simp [Q,Parameters.alpha,hx,hy]
  obtain ⟨S,hS,hm⟩ := lemma31 hc Q h.pell rfl hb h.d_pos h.t_pos h.u_pos
  refine ⟨S,hS,?_⟩
  intro j hj
  have he : Q.y h.pell j=orbitY P h.pell w j := by
    change (Q.alpha * (P.stepUnit h.pell ^ j : P.Algebraˣ)).im=_
    rw [hw]; rfl
  exact he ▸ hm j trivial (he ▸ hj)

/-- Remove a zero rational coordinate at any square before applying Corollary 1.9(a). -/
private theorem nine_at_minimum (hc : ExternalResults.CohnTheorem) (h9 : Corollary19)
    (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (hm : SmallestInitialSquare P h.pell) (hb : P.b ≤ 4) : AtMostSquareValues (P.y h.pell) 9 := by
  by_cases hnz : ∀ k, IsIntegerSquare (P.y h.pell k) → P.x h.pell k ≠ 0
  · exact h9 P h hn ⟨hm,hnz⟩ (Or.inl hb)
  push Not at hnz
  obtain ⟨i,⟨v,hv⟩,hx⟩ := hnz
  have hv0 : v ≠ 0 := by
    intro hz
    have hh := P.y_pos h hn i
    rw [hv,hz] at hh
    norm_num at hh
  obtain ⟨S,hS,hmem⟩ := zero_orbit hc P h (P.term h.pell i) (abs_pos.mpr hv0) hx
    (by change P.y h.pell i = _; simpa [Int.cast_abs,sq_abs] using hv)
  have shift (j : ℤ) : orbitY P h.pell (P.term h.pell i) j = P.y h.pell (i+j) :=
    translated P h.pell P.alpha i j
  refine ⟨S,by omega,?_⟩
  intro j hs
  have he := shift (j-i)
  rw [show i+(j-i)=j by omega] at he
  exact he ▸ hmem (j-i) (he ▸ hs)

private theorem parity_nine (hc : ExternalResults.CohnTheorem) (h9 : Corollary19)
    (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) (r : ℤ)
    (hmin : LeastSmallSquare (fun j => P.generalY h.pell (2*j+r)))
    (hnorm : ∀ i : ℤ, QuadraticAlgebra.norm
      (P.alpha * ((P.epsilonUnit h.pell ^ (2*i+r) : P.Algebraˣ) : P.Algebra)) = (P.normAlpha:ℚ)) :
    AtMostSquareValues (fun j => P.generalY h.pell (2*j+r)) 9 := by
  obtain ⟨i,b,hb,hb4,hi,hm⟩ := hmin
  let w : P.Algebra := P.alpha * ((P.epsilonUnit h.pell ^ (2*i+r) : P.Algebraˣ) : P.Algebra)
  let y (j : ℤ) := P.generalY h.pell (2*j+r)
  have hy : w.im=(b : ℚ)^2 := hi
  have shift (j : ℤ) : orbitY P h.pell w j=y (i+j) := by
    unfold w y; rw [general_orbit]; congr 1; ring
  by_cases hzero : w.re=0
  · obtain ⟨S,hS,hcover⟩ := zero_orbit hc P h w hb hzero hy
    refine ⟨S,by omega,?_⟩
    intro j hj
    have he := shift (j-i)
    rw [show i+(j-i)=j by omega] at he
    change y j ∈ S
    rw [← he]
    apply hcover
    rwa [he]
  have hnorm' : QuadraticAlgebra.norm w=(P.normAlpha:ℚ) := hnorm i
  have heq : w.re^2-(P.d:ℚ)*(b:ℚ)^4=P.normAlpha := by
    simp [QuadraticAlgebra.norm,hy] at hnorm'
    linear_combination hnorm'
  obtain ⟨X,hX⟩ := integer_root_of_two_mul_sq w.re ⟨2*(P.normAlpha+P.d*b^4),by push_cast; linarith only [heq]⟩
  have hXi : X^2-P.d*b^4=P.normAlpha := by rw [hX] at heq; exact_mod_cast heq
  have hX0 : X ≠ 0 := by intro hh; exact hzero (by simpa [hh] using hX)
  let Q : Parameters := {P with a:=|X|, b:=b}
  have hq : Q.Admissible := ⟨abs_pos.mpr hX0,hb,h.d_pos,h.t_pos,h.u_pos,h.d_not_square,h.pell⟩
  have hnQ : Q.normAlpha=P.normAlpha := by simpa [Q,Parameters.normAlpha,sq_abs,mul_comm] using hXi
  have transfer (e : ℤ → ℤ) (onto : Function.Surjective e)
      (he : ∀ j, Q.y hq.pell j=y (e j)) : AtMostSquareValues y 9 := by
    have hqm : SmallestInitialSquare Q hq.pell := by
      intro j hj
      rw [he] at hj ⊢
      exact hm (e j) hj
    obtain ⟨S,hS,hcover⟩ := nine_at_minimum hc h9 Q hq (by rwa [hnQ]) hqm hb4
    refine ⟨S,hS,?_⟩
    intro j hj
    obtain ⟨k,rfl⟩ := onto j
    rw [← he] at hj ⊢
    exact hcover k hj
  by_cases hx : 0 ≤ X
  · apply transfer (fun j => i+j) (fun k => ⟨k-i,by dsimp; omega⟩)
    have hw : Q.alpha = w := by ext <;> simp [Q,Parameters.alpha,abs_of_nonneg hx,hX,hy]
    intro j; change (Q.alpha * (P.stepUnit h.pell ^ j : P.Algebraˣ)).im=_
    rw [hw]; exact shift j
  · apply transfer (fun j => i+ -j) (fun k => ⟨i-k,by dsimp; omega⟩)
    have hw : Q.alpha = -star w := by ext <;> simp [Q,Parameters.alpha,abs_of_neg (lt_of_not_ge hx),hX,hy]
    intro j; change (Q.alpha * (P.stepUnit h.pell ^ j : P.Algebraˣ)).im=_
    rw [hw]; exact (negative_conjugate P h.pell w j).trans (shift (-j))

theorem corollary110_of_corollary19 (hc : ExternalResults.CohnTheorem) (h9 : Corollary19) : Corollary110 := by
  classical
  intro P h hn hε hEven hOdd
  have he (i : ℤ) : QuadraticAlgebra.norm
      (P.alpha * ((P.epsilonUnit h.pell ^ (2*i+0) : P.Algebraˣ) : P.Algebra)) = (P.normAlpha:ℚ) := by
    rw [add_zero,zpow_mul,zpow_ofNat,P.epsilonUnit_sq]; exact P.norm_term h.pell i
  obtain ⟨E,hE,coverE⟩ := parity_nine hc h9 P h hn 0 (by simpa only [add_zero] using hEven) he
  obtain ⟨O,hO,coverO⟩ := parity_nine hc h9 P h hn 1 hOdd (fun i => general_norm P h.pell hε _)
  refine ⟨E ∪ O,(Finset.card_union_le E O).trans (by omega),?_⟩
  intro k hk
  by_cases hpar : k%2=0
  · have hki : 2*(k/2)+0=k := by omega
    exact Finset.mem_union_left _ (hki ▸ coverE (k/2) (by simpa only [hki] using hk))
  · have hki : 2*(k/2)+1=k := by omega
    exact Finset.mem_union_right _ (hki ▸ coverO (k/2) (by simpa only [hki] using hk))

end AnyBAnyNorm
