module

public import AnyBNormSquare.Section5Main
public import AnyBAnyNorm.Corollary110
public import AnyBAnyNorm.Section56Bounds
public import AnyBAnyNorm.FiniteRange
public import AnyBAnyNorm.QuarticMembership

@[expose] public section
namespace AnyBAnyNorm
open «JNT-2024» AnyBNormSquare Section56

namespace Section56

/-- The numerical coverage assertion from b1-4-nAAll-post-java-checks.gp.
It concerns one integer square on one of the 192 finite inputs. f is the
least coefficient from (3.3); g ranges over the coefficient allowed at m₃.
Both the preliminary and coefficient-specific tests use their §4 bounds. -/
def PostJavaSearch : Prop :=
  ∀ (row : SizeRow), row ∈ javaRows → ∀ (h : row.params.Admissible), row.params.normAlpha < 0 →
    ∀ K, row.params.IsNegativeCutoff h.pell K → ∀ k, (3 ≤ k ∨ k ≤ K-2) →
    IsIntegerSquare (row.params.y h.pell k) →
    ∀ p : SquarePhase row.params h.pell k, PaperPhase p →
    (∀ q : SquarePhase row.params h.pell k, PaperPhase q → p.datum.f ≤ q.datum.f) →
    let P := row.params
    let y := (P.y h.pell k : ℝ)
    let N := |(P.normAlpha : ℝ)|
    preliminaryBounds P.b P.d N y → ∀ g : ℝ, 0 < g →
      g ≤ 4*(P.b : ℝ)^2*Real.sqrt |(squarefreePart P.normAlpha : ℝ)| →
      BeforeCoefficientBound P.b P.d N y (p.datum.f*g) → P ∈ postJavaTuples

/-- Use (4.4) and the choice of phases for the same five squares before
using the computed f at the first of the three selected indices. -/
private theorem keep_of_five (hp : Hypergeometric.DenominatorEstimate4) (hc : PostJavaSearch)
    (row : SizeRow) (hr : row ∈ javaRows) (h : row.params.Admissible) (hn : row.params.normAlpha < 0)
    (hm : Normalized row.params h.pell) (K : ℤ) (hK : row.params.IsNegativeCutoff h.pell K)
    (k : Fin 5 → ℤ) (hk : ∀ i, 3 ≤ k i ∨ k i ≤ K-2)
    (hs : ∀ i, IsIntegerSquare (row.params.y h.pell (k i)))
    (ho : StrictMono (fun i => row.params.y h.pell (k i))) : row.params ∈ postJavaTuples := by
  by_cases small : row.params ∈ belowSizeTuples
  · exact java_size_records.2.2.2.1 _ small
  have hsize := (equation44_of_five hr h hn K hK small k hk hs ho).2
  have hnz (i : Fin 5) : k i ≠ 0 := by have := hk i; have := hK.1; omega
  have hex (i : Fin 5) := least_phase (paperPhase_exists h hn (hnz i) (hs i)
    (lt_of_lt_of_le (by exact_mod_cast sq_pos_of_pos h.b_pos) (hm.1 _ (hs i))) (hm.2 _ (hs i)))
  choose ph hpure hleast using hex
  obtain ⟨i,j,l,hij,hjl,hab,hbc,hac⟩ := select_three_indices k ph
  have h0i : (row.params.y h.pell (k 0) : ℝ) ≤ (row.params.y h.pell (k i) : ℝ) := by
    exact_mod_cast ho.monotone (Fin.zero_le i)
  have hweak : 4*|(row.params.normAlpha : ℝ)|/Real.sqrt row.params.d ≤
      16*|(row.params.normAlpha : ℝ)|/Real.sqrt row.params.d := by
    apply div_le_div_of_nonneg_right _ (Real.sqrt_nonneg _)
    linarith [abs_nonneg (row.params.normAlpha : ℝ)]
  have hlo := (Prerequisites.threshold_implies_coordinate_size row.params h hn (hweak.trans hsize)).trans h0i
  obtain ⟨η,hη,hfield,hmin⟩ := comparison_phase h hn (ph i) (ph l)
    (by exact_mod_cast ho (hij.trans hjl)) hlo hac
  have H := selected_coefficient_bounds hp h hn hm (ph i) (ph j) (ph l) (hnz i) (hs i)
    (by exact_mod_cast ho hij) (by exact_mod_cast ho hjl) hlo (hsize.trans h0i) hab hbc hη hfield hmin
  exact hc row hr h hn K hK (k i) (hk i) (hs i) (ph i) (hpure i) (hleast i)
    (preliminary_of_cases row.params h hn K hK (hk i) (hs i) H.2.1) _ (ph l).datum.f_pos (ph l).f_bound H.2.2

end Section56

/-- 07g Theorem 1.8(a), using the finite calculations in §5.6 as explicit
inputs, following the computational interface of the attached square-norm release. -/
theorem theorem18a (hp : Hypergeometric.DenominatorEstimate4)
    (hj : JavaSquareSearch) (hpost : PostJavaSearch) (hq : QuarticResultsComplete)
    (hSquare : AnyBNormSquare.Theorem14a) (hPP : PrimePowerTheorem18a)
    (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) (hm : Normalized P h.pell)
    (hb : P.b ≤ 4) (K : ℤ) (hK : P.IsNegativeCutoff h.pell K) :
    AtMostSquareValuesOn (P.y h.pell) (fun k => 3 ≤ k ∨ k ≤ K-2) 4 := by
  by_cases hd : finiteBound P.b P.u ≤ P.d
  · exact section55_four hp P h hn hm K hK (conditions_of_finiteBound P h hn hd)
  by_cases hjr : ∃ r ∈ javaRows, r.params=P
  · obtain ⟨row,hr,rfl⟩ := hjr
    by_cases hret : row.params ∈ postJavaTuples
    · by_cases hcov : coveredNorm row.params.normAlpha.natAbs = true
      · exact covered_tail hSquare hPP row.params h hn hm.1 hb hcov K hK
      · exact solver_sequence_bound hq hret h hn hm hcov K hK
    · apply tail_count h K
      intro k hk hs ho
      exact hret (keep_of_five hp hpost row hr h hn hm K hK k hk hs ho)
  · exact outside_java hp hj P h hn hm hb (lt_of_not_ge hd) K hK hjr

/-- Theorem 1.8, both parts with the standing assumptions and cited inputs. -/
theorem theorem18 (hp : Hypergeometric.DenominatorEstimate4) (hA : ExternalResults.AkhtariTheorem11)
    (hj : JavaSquareSearch) (hpost : PostJavaSearch) (hq : QuarticResultsComplete)
    (hSquare : AnyBNormSquare.Theorem14a) (hPP : PrimePowerTheorem18a) : Theorem18 := by
  intro P h hn hm hb K hK
  rcases hb with ha | ⟨hb,hd⟩
  · exact theorem18a hp hj hpost hq hSquare hPP P h hn hm ha K hK
  · exact theorem18b hp hA P h hn hm hb hd K hK

theorem corollary19 (hp : Hypergeometric.DenominatorEstimate4) (hA : ExternalResults.AkhtariTheorem11)
    (hj : JavaSquareSearch) (hpost : PostJavaSearch) (hq : QuarticResultsComplete)
    (hSquare : AnyBNormSquare.Theorem14a) (hPP : PrimePowerTheorem18a) : Corollary19 :=
  corollary19_of_theorem18 (theorem18 hp hA hj hpost hq hSquare hPP)

/-- Remaining computational inputs of the cited square-norm release. -/
structure SquareNormCalculations : Prop where
  magma : «JNT-2024».Calculations.Section46Magma
  enumeration : AnyBNormSquare.Section56Calculations.JavaEnumeration
  squareSearch : AnyBNormSquare.Section56Calculations.JavaSquareSearch
  quartics : AnyBNormSquare.Section56Calculations.ExceptionalQuartics

/-- Apply the attached proof of [12, Theorem 1.4(a)] at the §5.6 norm split. -/
theorem theorem18_paper (hp : Hypergeometric.DenominatorEstimate4) (hA : ExternalResults.AkhtariTheorem11)
    (hj : JavaSquareSearch) (hpost : PostJavaSearch) (hq : QuarticResultsComplete)
    (hS : SquareNormCalculations) (hPP : PrimePowerTheorem18a) : Theorem18 :=
  theorem18 hp hA hj hpost hq (AnyBNormSquare.Section5Proof.theorem14a_conditional hp hA
    hS.magma hS.enumeration hS.squareSearch hS.quartics) hPP

theorem corollaries19_110 (hp : Hypergeometric.DenominatorEstimate4) (hA : ExternalResults.AkhtariTheorem11)
    (hj : JavaSquareSearch) (hpost : PostJavaSearch) (hq : QuarticResultsComplete)
    (hS : SquareNormCalculations) (hPP : PrimePowerTheorem18a) (hc : ExternalResults.CohnTheorem) :
    Corollary19 ∧ Corollary110 := by
  have h9 := corollary19_of_theorem18 (theorem18_paper hp hA hj hpost hq hS hPP)
  exact ⟨h9,corollary110_of_corollary19 hc h9⟩

end AnyBAnyNorm
