import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.BigInteger;

/** Exact boundary audit for the pinned BAllNaAllSearch.java in the 07g release. */
public class CheckJavaBounds {
    static BigInteger z(long n) { return BigInteger.valueOf(n); }

    record Term(BigInteger numerator, BigInteger denominator, int exponent) {
        boolean allows(long d) {
            return z(d).pow(exponent).multiply(denominator).compareTo(numerator) <= 0;
        }
    }

    static long floorBound(long b, long u) {
        BigInteger B = z(b), U = z(u);
        Term[] terms = {
            new Term(z(300), U.pow(2), 1),
            new Term(z(54).pow(5).multiply(B.pow(4)), z(10).pow(5).multiply(U.pow(12)), 5),
            new Term(z(10).pow(19).multiply(B.pow(108)), U.pow(66), 19),
            new Term(z(9).pow(5).multiply(B.pow(32)), U.pow(18), 5),
            new Term(z(57).pow(9).multiply(B.pow(52)), U.pow(36), 9),
            new Term(z(2461).multiply(B.pow(12)), U.pow(6), 1)
        };
        long result = 0;
        for (Term term : terms) {
            long lo = 0, hi = 1;
            while (term.allows(hi)) hi *= 2;
            while (hi-lo > 1) {
                long mid = (lo+hi)/2;
                if (term.allows(mid)) lo=mid;
                else hi=mid;
            }
            result = Math.max(lo,result);
        }
        return result;
    }

    static void require(boolean condition, String message) {
        if (!condition) throw new IllegalStateException(message);
    }

    static void checkLimit(long b, long d, double limit) {
        // Any integer no larger than nextDown(limit) rounds to a double below limit.
        BigInteger L = new BigDecimal(Math.nextDown(limit)).toBigInteger();
        BigInteger B = z(b), D = z(d);
        BigInteger N = D.multiply(B.pow(4)).subtract(BigInteger.ONE);
        BigInteger tenL = L.multiply(z(10));
        require(L.compareTo(z(4*b*b)) > 0, "initial value");
        require(tenL.pow(11).multiply(D.pow(12)).compareTo(
                z(4*109).pow(11).multiply(B.multiply(N).pow(26))) >= 0, "(4.14)");
        require(tenL.pow(6).multiply(D.pow(7)).compareTo(
                z(4*91).pow(6).multiply(B.pow(16)).multiply(N.pow(15))) >= 0, "(4.16)");
        require(L.multiply(D).compareTo(z(4*598).multiply(B.pow(2)).multiply(N.pow(3))) >= 0,
                "third threshold in Proposition 4.1");
    }

    public static void main(String[] args) throws Exception {
        Class<?> search = Class.forName("BAllNaAllSearch");
        Constructor<?> constructor = search.getDeclaredConstructor(long.class);
        Method dUpper = search.getDeclaredMethod("getDUpperBound", long.class, long.class);
        Method yUpper = search.getDeclaredMethod("getYM1UpperBound", long.class, long.class,
                long.class, long.class, long.class);
        constructor.setAccessible(true);
        dUpper.setAccessible(true);
        yUpper.setAccessible(true);
        long[][] expected = {{13,2489L},{14,40959738L},{30,11961962029L},{53,671349959367L}};
        for (long b=1; b<=4; b++) {
            Object app = constructor.newInstance(b);
            long rows=0, count=0;
            long stop=expected[(int)b-1][0];
            for (long u=1; u<=stop; u++) {
                long D = floorBound(b,u);
                double dFloat = ((double[])dUpper.invoke(app,b,u))[0];
                require((dFloat > 1.999) == (D >= 2) && (D < 2) == (u==stop), "u cutoff");
                if (u==stop) break;
                long tMax = z(D*u*u+4).sqrt().longValueExact();
                // D is the floor of the right side. For nonintegral u^2*bound,
                // the Java t loop may try extra t, which the d test must reject.
                long tJava = (long)Math.floor(Math.sqrt(u*u*dFloat+4L));
                for (long t=1; t<=Math.max(tMax,tJava); t++) {
                    for (long delta : new long[]{-4,4}) {
                        long num=t*t+delta;
                        if (num<=0 || num%(u*u)!=0) continue;
                        long d=num/(u*u);
                        require((t<=tJava && d<=dFloat)==(d<=D), "d or t cutoff");
                        if (d>D) continue;
                        long aMax=z(d*b*b*b*b-1).sqrt().longValueExact();
                        if (aMax==0) continue;
                        require(d>=2, "positive nonsquare d");
                        double limit=4.0*(double)yUpper.invoke(app,1L,b,d,t,u);
                        checkLimit(b,d,limit);
                        rows++;
                        count+=aMax;
                    }
                }
            }
            require(count==expected[(int)b-1][1], "Table 1 count");
            System.out.printf("b=%d: verified Java d,t,u and square cutoffs on %d (d,t,u) rows covering %d tuples.%n",b,rows,count);
        }
    }
}
