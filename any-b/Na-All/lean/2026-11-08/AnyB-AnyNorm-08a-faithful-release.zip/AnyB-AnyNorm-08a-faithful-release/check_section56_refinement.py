"""Replay Table 1 and the refined square tests in 07g with exact arithmetic."""
import argparse
import ast
import re
from fractions import Fraction as Q
from functools import cache
from math import gcd, isqrt
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def require(test, message):
    if not test:
        raise ValueError(str(message))


def floor_root(a, c, p):
    lo, hi = 0, 1
    while c*hi**p <= a:
        hi *= 2
    while hi-lo > 1:
        mid = (lo+hi)//2
        if c*mid**p <= a:
            lo = mid
        else:
            hi = mid
    return lo


def bound_terms(b, u):
    return [(300, u**2, 1), (54**5*b**4, 10**5*u**12, 5),
            (10**19*b**108, u**66, 19), (9**5*b**32, u**18, 5),
            (57**9*b**52, u**36, 9), (2461*b**12, u**6, 1)]


def table():
    for b, (D, U, c1) in enumerate(zip(
            [2461, 10080256, 1307876301, 41288728576], [13, 14, 30, 53],
            [2489, 40959738, 11961962029, 671349959367]), 1):
        require(max(floor_root(*term) for term in bound_terms(b, 1)) == D, (b, D))
        count = 0
        for u in range(1, U+1):
            terms = bound_terms(b, u)
            limit = max(floor_root(*term) for term in terms)
            require((limit < 2) == (u == U), (b, u))
            if u == U:
                break
            for t in range(1, isqrt(limit*u*u+4)+1):
                for num in (t*t+4, t*t-4):
                    if num <= 0 or num % (u*u):
                        continue
                    d = num//(u*u)
                    if d <= limit:
                        require(any(c*d**p < a for a, c, p in terms), ("equality", b, d, t, u))
                        count += isqrt(d*b**4-1)
        require(count == c1, (b, count, c1))
        print(f"Table 1: b={b}, D={D}, U={U}, c1={count}")


@cache
def squarefree(n):
    result, p = 1, 2
    while p*p <= n:
        if n % p == 0:
            n //= p
            if n % p:
                result *= p
            else:
                n //= p
            continue
        p = 3 if p == 2 else p+2
    return result*n


def primitive_coefficient(r, s, f):
    # Rescale the primitive integer direction until its coefficient is integral.
    base = Q(f, gcd(r, s)**2)
    return base.numerator * squarefree(base.denominator)


def check_representation(P, k, y, triple):
    a, b, d, t, u = P
    N = d*b**4-a*a
    S = squarefree(N)
    v = isqrt(N//S)
    norm = (t*t-d*u*u)//4
    T, U = 2, 0
    t1, u1 = (t, u) if k > 0 else (norm*t, -norm*u)
    for _ in range(abs(k)):
        T, U = Q(T*t1+d*U*u1, 2), Q(T*u1+U*t1, 2)
    x = Q(a*(T*T+d*U*U)+2*b*b*d*T*U, 4)
    require(y == Q(b*b*(T*T+d*U*U)+2*a*T*U, 4), ("coordinate", P, k))
    # Diagnostic equalities in calc_fk, in the basis 1, sqrt(normAlpha).
    def multiply(l, r):
        return (l[0]*r[0]-N*l[1]*r[1], l[0]*r[1]+l[1]*r[0])

    alpha = (a, 1)
    target = (x, norm**(k % 2))
    factor = (Q(a*U+b*b*T, 2*b*b), Q(-U, 2*b*b))
    require(multiply(alpha, multiply(factor, factor)) == target, ("myLHS-myRHS", P, k))
    for sign in (-1, 1):
        r1 = T*b*b+a*U+sign*2*b*isqrt(y)
        factor2 = multiply((r1, -U), (r1, -U))
        lhs = tuple((4*b*b*r1)**2 * c for c in target)
        require(lhs == multiply(alpha, multiply(factor2, factor2)), ("branch diagnostic", P, k, sign))
    f, r, s = triple
    A, B = r*r-S*s*s, 2*r*s
    A, B = A*A-S*B*B, 2*A*B
    require(f*f*x == a*A-v*S*B and f*f*norm**(k % 2)*v == v*A+a*B, ("(3.3)", P, k))
    require(f*isqrt(y) == b*(r*r+S*s*s) and f > 0 and 4*b*b*S % f == 0
            and f*f <= 16*b**4*S, ("Lemma 3.2", P, k))
    # The quotient of two fourth roots of a positive real has argument a
    # multiple of pi/2. In Q(sqrt(-S)) this leaves precisely these two lines.
    least = min(primitive_coefficient(r, s, f), primitive_coefficient(-S*s, r, S*f))
    require(least == f, ("least coefficient", P, k, f, least))
    return f


def candidates(P):
    a, b, d, t, u = P
    N = d*b**4-a*a
    require(334**2*b**8*N**5 > d*d and 1340*b**4*N**3 > d, ("root bases", P))
    trace = Q(t*t+d*u*u, 2)
    for sign in (-1, 1):
        prev = b*b
        y = Q(b*b*(t*t+d*u*u)+sign*2*a*t*u, 4)
        cutoff = None
        for i in range(1, 31):
            if cutoff is None and y > b*b:
                cutoff = i
            low1 = y**11*d**12 < Q(109, 10)**11*b**26*N**26
            low2 = y**6*d**7 < Q(91, 10)**6*b**16*N**15
            high3 = y**6*d**5 <= Q(148, 10)**6*334**2*b**8*N**14
            high4 = y**2*d**2 < Q(1633, 100)**2*1340*b**4*N**6
            if y > prev and not any((low1, low2, high3, high4)):
                break
            eligible = i >= 3 if sign == 1 else cutoff is not None and i >= cutoff+2
            if eligible and y.denominator == 1 and isqrt(int(y))**2 == y:
                yield sign*i, int(y), low1, low2, high3, high4
            prev, y = y, trace*y-prev
        else:
            raise ValueError(("30 indices insufficient", P, sign))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("representations", type=Path)
    args = parser.parse_args()
    table()
    files = ROOT / "AnyBAnyNorm"
    rows = [tuple(map(int, row)) for row in re.findall(
        r"^  ⟨⟨(\d+), (\d+), (\d+), (\d+), (\d+)⟩",
        (files / "Section56Size.lean").read_text(encoding="utf8"), re.M)]
    retained = {tuple(map(int, row)) for row in re.findall(
        r"^  ⟨(\d+), (\d+), (\d+), (\d+), (\d+)⟩",
        (files / "PostJava.lean").read_text(encoding="utf8"), re.M)}
    records = {}
    for line in args.representations.read_text(encoding="utf8").splitlines():
        key, triple = ast.literal_eval("(" + line.replace("][", "],[") + ")")
        key = tuple(key)
        require(key not in records, ("duplicate", key))
        records[key] = triple
    occurrences = len(records)
    require(occurrences == 205, "candidate square count")
    require(len(rows) == len(set(rows)) == 192, "Java row count")
    selected, small = set(), set()
    for P in rows:
        a, b, d, t, u = P
        N = d*b**4-a*a
        for k, y, low1, low2, high3, high4 in candidates(P):
            f = check_representation(P, k, y, records.pop((*P, k, y)))
            if d*y*y < 256*N*N:
                small.add(P)
            # In (4.17) the ratio grows as M^(8n-4), and in (4.22)
            # as M^(4n). Use M=2. Using 4*b^2*sqrt(N) for f at m3
            # enlarges its permitted range. Both right-hand bases exceed
            # one here, so the largest root is attained at r0=2.
            M = 2
            c3 = Q(181, 1000)*16**4*f**8*N**6*M**4/d**4
            c4 = Q(16*f*f*N*N, 1)/(Q(1911, 10000)*d)
            a3 = Q(y**4*d*d*M**8, 1)/(Q(592, 10)**4*N**6)
            a4 = Q(2344, 10**7)*M**4*d*y*y/N**3
            require(c3 > 1 and c4 > 1, ("refined root bases", P, k))
            if low1 or low2 or (high3 and a3**3 < c3) or (high4 and a4 < c4):
                selected.add(P)
    require(not records, ("unused representations", len(records)))
    require(len(small) == 43 and small <= retained, "07g size paragraph")
    require(selected | small == retained and len(retained) == 175, "post-Java result")
    equations = {(d, a*a-d*b**4) for a,b,d,t,u in retained}
    require(len(equations) == 162, "quartic equation count")
    print(f"Verified {3*occurrences} exact calc_fk diagnostic identities.")
    print(f"Verified both identities, divisibility and minimum f for {occurrences} candidate squares.")
    print("43 tuples below (4.4); 175 retained; 162 equations.")


if __name__ == "__main__":
    main()
