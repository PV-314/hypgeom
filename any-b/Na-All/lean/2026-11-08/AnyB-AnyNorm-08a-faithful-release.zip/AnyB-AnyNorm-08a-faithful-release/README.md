# Arbitrary negative norm, 08a faithful release

Lean development of Paul M. Voutier's *Bounds on the number of squares in recurrence sequences: y₀ = b² (III)*. The target is the 24-page 08a PDF and its matching TeX. For citations to JNT-2024, the author supplied the 47-page post-proofs revision and its TeX earlier in the conversation. The JNT dependency is the original GitHub release. The 07b dependency contains the Lean sources from the original square-norm release. The [input lock](inputs.lock.json) identifies all six files by SHA-256 and records their bundle-relative paths. The JNT manuscript pair now has the filename suffix `-for-axiom`; both files match their original digests. TeX line numbers in the proof ledger refer to the target paper.

**Fidelity review.** The target is the author's `08a` revision. Page 15 retains the §4.4 footnote, and page 18 omits the former §5.1 footnote. The Lean proof of Lemma 3.1 multiplies the two identities at lines 786–798. The [fidelity review](FIDELITY_REVIEW.md) records the source comparison, mathematical checks and remaining proof obligations.

The principal release endpoint is `AnyBAnyNorm.theorem18_paper`. It uses the supplied proof of the square-norm theorem, the cited prime-power theorem, the JNT denominator estimate, the cited theorem of Akhtari and explicit finite computational premises. `AnyBAnyNorm.corollaries19_110` gives the two corollaries, using Cohn in the zero-coordinate case. [Theorem 1.8](AnyBAnyNorm/Theorem18.lean) · [Corollary 1.10](AnyBAnyNorm/Corollary110.lean).

The revised §1.8(3) is formalised in [NonnegativeIndex.lean](AnyBAnyNorm/NonnegativeIndex.lean). The [08a audit](FIDELITY_REVIEW.md) records the check of the updated GP diagnostics and the author’s clarification of the input unit at line 179.

## Proof ledger

| Paper location | Lean entry point | Scope |
|---|---|---|
| §1.2, lines 171–207 | JNT `Parameters.term`, `x`, `y`, `y_one`, `y_neg_one`, `y_recurrence`, `x_recurrence`, `norm_identity` | Reuse the rational coordinates of the quadratic-algebra element at every integer index. The integer-square predicate and distinct-value counting also come from the releases. |
| §1.5, lines 369–414 and §4.7, lines 1504–1517 | [MainStatements.lean](AnyBAnyNorm/MainStatements.lean) | Defines the statements of Proposition 4.1, Theorems 1.7–1.8 and Corollary 1.9. Real powers, the strict size threshold, both inclusive index ranges and the standing normalisation are explicit. See §4.7 below for the first two proofs. |
| Corollary 1.9, lines 398–414 | `corollary19_of_theorem18` | Proves the deduction from Theorem 1.8. Its four tail values and the five possible values at K−1, K, 0, 1 and 2 cover every square. Maximality of K and minimality of b² handle the intermediate negative indices. |
| §2.1, lines 538–603 | JNT `Hypergeometric.X_eq_hypergeometric`, `Y_eq_reciprocal`; AnyB `Construction.denominator_least`, `content_greatest`, `scale_formula`, `raw_formulas`, `dPrime_formula` | Uses the released rational polynomials and the printed normalisers and approximants at the working specialisation m=1, n=4. GeneralNormalizers.lean defines the simultaneous least denominator, greatest content and prime product for the allowed numerators. It identifies all three with the released definitions for n = 4. The Gauss expression for the remainder is used on the domain specified at line 612. |
| §2.1, lines 604–617 | [Construction.lean](AnyBAnyNorm/Construction.lean), `approximant_fields`, `scaled_approximants_mem`, `gPrime_sq`, `error_eq_scaled_gauss` | Both JNT raw approximants are algebraic integers. For even r they belong to K = ℚ(√t′). For odd r they belong to K(g′) and multiplying by g′ places them in K. For every r, multiplying by (g′)ʳ gives the field-membership premise of Lemma 2.1. The printed hypothesis `‖ω − 1‖ < 1` gives both the error identity and its scaled Gauss expression. |
| Lemma 2.1, lines 632–684, PDF p. 7 | [Diophantine.lean](AnyBAnyNorm/Diophantine.lean), `lemma21` | Descent of the integral determinant square to the imaginary quadratic field, the norm bound, then JNT `lemma21_complex_published`. The conclusion contains the least positive cutoff and both strict inequalities. The embedding represents the ambient subfield of ℂ; ℂ itself can serve as ambient field. |
| Lemma 3.1, lines 707–847 | [ZeroRealSequence.lean](AnyBAnyNorm/ZeroRealSequence.lean), `lemma31_paper` | Conditional on [the cited result of Cohn](AnyBAnyNorm/Cohn.lean). The application follows reflection, the trace/denominator argument, the positive unit coordinates, the quartic equation and squarefree reduction. For squarefree part 1785 the trace rules out 13, leaving 239. The endpoint uses the ring-of-integers unit and equation (1.1). |
| Lemma 3.2, lines 852–880 | [SequenceLemmas.lean](AnyBAnyNorm/SequenceLemmas.lean), `lemma32` | Specialises JNT `proposition31a_published` to unit norm. A single triple of witnesses satisfies both identities, the divisibility and the absolute bound. Retains nonsquare Nα of either sign. |
| Lemma 3.3, lines 886–917 | `lemma33a`, `lemma33b` | Applies AnyB `lemma32a`, `lemma32c`, `lemma32c_uniform` as cited. Includes both monotone sequences, positive half-integrality, the 0.99 bound under its disjunction and the 0.4 bound. |
| Lemma 3.4, lines 921–976 | [Gap.lean](AnyBAnyNorm/Gap.lean), `phase_of_representation`, `lemma34_pair`, `lemma34_paper` | Fixes the actual Lemma 3.2 witnesses and a minimizing phase. For every ordered pair in the same phase class, applies the parallel-phase separation in the proof of JNT 3.8(b), then the product bound at line 973. The triple theorem starts from the square, cutoff, ordering and size assumptions. |
| Lemma 3.5, lines 982–1026 | `lemma35a`, `lemma35b` | Part (a) uses the principal-argument bound with both strict inequalities. Part (b) applies JNT `lemma39b_of_minimizers` to the same fixed coordinates, with comparison point equal to the conjugate of the first point times the second. |
| Lemma 3.6, lines 1029–1047 | `lemma36` | Uses the AnyB lower and upper normalizer estimates for both signs of u₂. JNT's `normalizerProduct` is the defined product in the inequality. AnyB's `squareFactor_eq_paper_root` and `N4_eq_paper` identify the radical and the real-power formula. |
| §4.1, through line 1131 | [IndexSelection.lean](AnyBAnyNorm/IndexSelection.lean), `section41_select` | From (4.1) on the first index and the ordering of the five square values, deduces the index condition for all five. From (4.4) derives the size hypothesis for Lemma 3.5(b). Fixes five representations, selects the three ordered positions and chooses a minimizing η in ℚ(√sf(Nα)) for the first and last of those three. |
| §4.2, equations (4.5)–(4.12) | [Prerequisites.lean](AnyBAnyNorm/Prerequisites.lean) and [Section42.lean](AnyBAnyNorm/Section42.lean), `section42_cutoff` | Uses the selected minimizing phase and both signed quadratic coordinates. The sequence norm gives the bounds for E, Q and ℓ₀. The angular estimate supplies the domain condition. Both approximation estimates use JNT Lemma 2.3(a) for every non-negative r. Lemma 2.1 applies to the actual integral numerator ηp and denominator q in the degree-two imaginary field, with c = 3/4. |
| §§4.3–4.4, equations (4.13)–(4.16) | [NonexactCase.lean](AnyBAnyNorm/NonexactCase.lean) and [ExactCase.lean](AnyBAnyNorm/ExactCase.lean) | At r₀ = 1 the two consecutive uses of Lemma 3.4 give the ninth power. In the nonzero-determinant case (3.6) and cancellation give the 22nd root and 10.9. In the equality case the sequence chord and the corrected JNT (4.13) give (4.15), then (4.16) with 9.1. The footnote's single-gap calculation is proved separately. |
| §§4.5–4.6, equations (4.17)–(4.24) | [HigherCases.lean](AnyBAnyNorm/HigherCases.lean) | Replays the cited AnyB estimates with the general product of the fixed coefficients. The nonzero-determinant case uses M ≥ 2 and y ≥ b² before bounding the r-dependent coefficient by its value at 2. The equality case rules out 1340 b⁴ abs(Nα)³/d ≤ 1 before taking r₀ = 2 in the bound. |
| §4.7, Proposition 4.1 and Theorem 1.7 | [FourCases.lean](AnyBAnyNorm/FourCases.lean) and [Consolidation.lean](AnyBAnyNorm/Consolidation.lean), `proposition41`, `theorem17` | The four branches use the same triple, phase, approximants and least positive cutoff. The precise threshold dominates the auxiliary size hypothesis and excludes five ordered distinct square values. Comparing exponents term by term gives the single threshold in Theorem 1.7. Both endpoints carry the approved JNT external premise. |
| §5 opening and §§5.1–5.2, lines 1538–1632 | [Section5Low.lean](AnyBAnyNorm/Section5Low.lean) | Deduces (5.3) from Lemma 3.3(b) and proves both discriminant comparisons in each of the first two cases. |
| §§5.3–5.4 | [Section5High.lean](AnyBAnyNorm/Section5High.lean) | Proves both high-index separations and their norm-free versions. |
| §5.5 | [Section55.lean](AnyBAnyNorm/Section55.lean) | Proves Theorem 1.8(b), including the norm −1 branch via Akhtari. |
| §5.6, lines 1902–1909 | [SizeCheck.lean](AnyBAnyNorm/SizeCheck.lean), [Section56Size.lean](AnyBAnyNorm/Section56Size.lean) | Checks the 43 of 192 tuples and inclusion in the 175. Proves (4.4) if five distinct squares exist on the stated indices for any of the other tuples. |
| §5.6, lines 1943–1950 | [PostJava.lean](AnyBAnyNorm/PostJava.lean) | Checks the 175 tuples, their 162 distinct equations and the tuple attaining both maxima on the reproduced post-Java output. |
| §5.6, lines 1949–1954 | [Section56Norms.lean](AnyBAnyNorm/Section56Norms.lean) | Counts the two norm classes on the finite list. Restricts the tail bounds of [12] and [13] to Theorem 1.8(a), with the cited results explicit. |
| §5.6, lines 1979–1985 | [QuarticResults.lean](AnyBAnyNorm/QuarticResults.lean) | Checks the 94 equation records, positive integral witnesses and reported 84/6/4 distribution. Exhaustiveness is an explicit external premise. |
| §5.6, final two tuples, lines 1982–1990 | [ExceptionalSequence.lean](AnyBAnyNorm/ExceptionalSequence.lean) | Checks the two norms, equality of the entire y-sequences via recurrence (1.3), and the four specified square values at −5, −1, 0 and 3. The quartic lists carry an external completeness premise. |
| §5.6, equation (5.17), Table 1 and the paragraph after (4.4) | [FiniteRange.lean](AnyBAnyNorm/FiniteRange.lean), [Section56Bounds.lean](AnyBAnyNorm/Section56Bounds.lean) | Takes the six bounds with the printed constants and uses Proposition 4.1 outside the Java list. The bases of the two powers exceed one in the higher cases. |
| §5.6, minimum coefficient and final count | [Theorem18.lean](AnyBAnyNorm/Theorem18.lean), [QuarticMembership.lean](AnyBAnyNorm/QuarticMembership.lean) | Uses the least coefficient before selecting three of five consistent phases, then applies (4.17) or (4.22) to those witnesses. Outside the 68 equations covered by citations, uses the positive-point records and Lemma 3.3(a) to bound the number of sequence squares. |
| Corollaries 1.9 and 1.10 | [Corollary110.lean](AnyBAnyNorm/Corollary110.lean) | The five remaining indices give nine squares. Each parity class contributes at most nine, including the zero-real-part case. |

The earlier local AnyB-AnyNorm project supplied reusable Lean proof code for Lemmas 2.1 and 3.1. Those steps were compared to the 7 November manuscript, then ported to the two requested releases. The older manuscript, its temporary JNT-2026 adaptation and its build records are outside the source and dependency graph of this project.

## Computational premises and scope

Theorem 1.8(a) uses three finite inputs for §5.6.

- `JavaSquareSearch` states coverage of individual eligible squares in the finite range of (5.17) by the recorded 192 tuples.
- `PostJavaSearch` states coverage of an individual eligible square satisfying the preliminary bounds and (4.14), (4.16), (4.17) or (4.22) at the least allowed coefficient. Lean proves the preliminary bounds, including the two norm ranges on page 22 and the choice of r₀ = 2. The exact-arithmetic replay checks the numerical filter.
- `QuarticResultsComplete` gives exhaustiveness of the positive integral point lists for 94 equations. The kernel checks every recorded point and the sequence-membership calculation. The bundled transcript preserves the PARI/GP output and supplies the results of the descent.

The main endpoints use the choice of α stated in §1.2. Corollary 1.10 explicitly handles a zero rational coordinate at a square by restarting the sequence and applying Lemma 3.1. For the two parity classes it uses the translated orbit and the negative conjugate when required. Section 1.3 contains conjectures. The two results from the prime-power papers in §1.4 are recorded as cited statements. [Quoted results](AnyBAnyNorm/QuotedResults.lean).

## Restore and check

To repeat the §5.6 evidence audit, run `python check_section56.py PATH_TO_TRANSCRIPT` with the bundled solver transcript. The check verifies its SHA-256 digest, reconciles the tuple and equation lists with Lean, checks each integral point and reproduces the exceptional sequence membership calculation.

From this directory, with Python 3.11+ and Lake on PATH:

```sh
python restore.py
lake build
lake env lean Audit.lean
```

The ZIP includes the six locked inputs in `inputs/`. Restore uses these bundled copies when present. From the extracted project root, the additional evidence commands are

```sh
python check_section56.py evidence/b1-4-nAAll-solve-output-2026-10-28a.txt
python check_section56_refinement.py evidence/refined-representations.txt
python check_section56_size.py evidence/hypgeom/any-b/Na-All/pari/b1-4-nAAll-post-java-checks.gp evidence/BAllNaAllSearch-b-1-4-2026-10-28a.txt
```

The accompanying `evidence/release-checks/verify-refinement.gp` replays the coefficient calls with the pinned source. Run PARI/GP from `evidence/hypgeom/any-b/Na-All/pari/` with the harness as its input. Compare the output with `evidence/refined-representations.txt`.

If the files move, use `--tex` and `--pdf` for the target, `--jnt-tex` and `--jnt-pdf` for the cited manuscript, and `--jnt` and `--anyb` for the release archives. Restore verifies all six hashes before extracting. A repeat run checks the restored files against the ZIP members. The square-norm source bundle retains every upstream Lean file, the Lake configuration and the pinned JNT dependency. Its UPSTREAM.json records the original GitHub archive and the hash of every retained upstream member. Its bundled JNT ZIP matches the separately supplied ZIP byte-for-byte by SHA-256. The [Lake manifest](lake-manifest.json) locks the transitive Git revisions, including mathlib at `56a005855ea17e0b0958f73ec801ae140b0a1679`. The [toolchain](lean-toolchain) pins Lean 4.35.0.

The workstation build reuses dependency build artifacts after comparing their Lean sources and package configuration with the extracted releases. The local mathlib and companion checkouts were checked against the locked revisions and for tracked changes. A fresh machine can populate its own Lake cache. [Audit.lean](Audit.lean) checks the axiom closure of every local declaration and prints the principal theorem types, including their external hypotheses.

## Source provenance

The computational programs under `evidence/hypgeom/` reproduce GitHub commit `2dbf585df104582e6fcb7dd1a7357996cf460bd2` byte for byte. The two Java searches use the default package. The two original release-specific Java and GP harnesses are under `evidence/release-checks/`. The source list and blob hashes are in `release-evidence/github-inputs.txt`. The solver transcript uses the program filename in its two echoed commands. All calculation lines retain their original bytes.
