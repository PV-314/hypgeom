import AnyBAnyNorm
import Lean

open Lean Elab Command

/- Check the full axiom closure of each declaration defined by this package,
including the auxiliaries produced by tactics. Cited hypotheses remain
visible in theorem types and require separate mathematical review. -/
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    let some idx := env.getModuleIdxFor? name | continue
    let mod := env.header.moduleNames[idx.toNat]!
    unless mod.getRoot == `AnyBAnyNorm do continue
    let axioms ← collectAxioms name
    for ax in axioms do
      unless [`propext, `Classical.choice, `Quot.sound].contains ax do
        throwError "{name} depends on {ax}"
    count := count + 1
  if count == 0 then throwError "No local declarations were audited"
  logInfo m!"Checked axiom closures of {count} local declarations."

#check AnyBAnyNorm.Construction.gPrime_sq
#check AnyBAnyNorm.Construction.scaled_approximants_mem
#check AnyBAnyNorm.Construction.approximant_fields
#check AnyBNormSquare.section21_error_identity
#check AnyBAnyNorm.Construction.error_eq_scaled_gauss
#check AnyBNormSquare.section41_near_one
#check AnyBAnyNorm.lemma21
#check AnyBAnyNorm.lemma31_paper
#check AnyBAnyNorm.lemma32
#check AnyBAnyNorm.lemma33a
#check AnyBAnyNorm.lemma33b
#check AnyBAnyNorm.phase_of_representation
#check AnyBAnyNorm.lemma34_paper
#check AnyBAnyNorm.lemma34_pair
#check AnyBAnyNorm.lemma35b
#check AnyBAnyNorm.select_three_indices
#check AnyBAnyNorm.comparison_phase
#check AnyBAnyNorm.section41_select
#check AnyBAnyNorm.section41_normalizer
#check AnyBAnyNorm.section42_comparison
#check «JNT-2024».Hypergeometric.lemma23a_of_denominatorEstimate4
#check AnyBAnyNorm.section42_approximant_bounds
section
  open «JNT-2024».Hypergeometric
  variable (hPrior : DenominatorEstimate4) (d' : ℤ) (hd' : d' ≠ 0)
  #check lemma23a_of_denominatorEstimate4 hPrior d' hd' 0
end
#check AnyBAnyNorm.section42_coordinates
#check AnyBAnyNorm.section42_parameters
#check AnyBAnyNorm.section42_pair
#check AnyBAnyNorm.section42_cutoff
#check AnyBAnyNorm.jnt413_modulus
#check AnyBAnyNorm.section44_equation415
#check AnyBAnyNorm.section44_one_gap
#check AnyBAnyNorm.section44_two_gaps
#check AnyBAnyNorm.section44_bound
#check AnyBAnyNorm.section43_bound
#check AnyBAnyNorm.section45_root
#check AnyBAnyNorm.section45_bound
#check AnyBAnyNorm.section46_bound
#check AnyBAnyNorm.selected_four_cases
#check (AnyBAnyNorm.proposition41 :
  «JNT-2024».Hypergeometric.DenominatorEstimate4 → AnyBAnyNorm.Proposition41)
#check (AnyBAnyNorm.theorem17 :
  «JNT-2024».Hypergeometric.DenominatorEstimate4 → AnyBAnyNorm.Theorem17)
#check AnyBAnyNorm.lemma35a
#check AnyBAnyNorm.lemma36
#check AnyBAnyNorm.corollary19_of_theorem18
#check AnyBAnyNorm.exceptional_four_squares
#check AnyBAnyNorm.exceptional_same_sequence
#check AnyBAnyNorm.section5_tail_lower
#check AnyBAnyNorm.section51_separation
#check AnyBAnyNorm.section51_norm_free
#check AnyBAnyNorm.section52_separation
#check AnyBAnyNorm.section52_norm_free
#check AnyBAnyNorm.Section56.postJava_counts
#check AnyBAnyNorm.Section56.postJava_maxima
#check AnyBAnyNorm.Section56.postJava_partition
#check AnyBAnyNorm.Section56.covered_tail
#check AnyBAnyNorm.Section56.quartic_records_valid
#check AnyBAnyNorm.Section56.quartic_reported_counts
#check AnyBAnyNorm.Section56.positive_solution_iff_mem
#check AnyBAnyNorm.section53_separation
#check AnyBAnyNorm.section53_norm_free
#check AnyBAnyNorm.section54_separation
#check AnyBAnyNorm.section54_norm_free
#check AnyBAnyNorm.selected_case_bounds
#check AnyBAnyNorm.section55_conditions
#check AnyBAnyNorm.section55_four
#check AnyBAnyNorm.theorem18b
#check AnyBAnyNorm.Section56.small_iff
#check AnyBAnyNorm.Section56.java_size_records
#check AnyBAnyNorm.Section56.belowSizeTuples_spec
#check AnyBAnyNorm.Section56.equation44_of_five

#check AnyBAnyNorm.least_phase
#check AnyBAnyNorm.selected_coefficient_bounds
#check AnyBAnyNorm.Section56.conditions_of_finiteBound
#check AnyBAnyNorm.Section56.JavaSquareSearch
#check AnyBAnyNorm.Section56.preliminary_of_cases
#check AnyBAnyNorm.Section56.PostJavaSearch
#check AnyBAnyNorm.Section56.QuarticResultsComplete
#check AnyBAnyNorm.Section56.solver_sequence_bound
#check AnyBAnyNorm.theorem18a
#check AnyBAnyNorm.theorem18_paper
#check AnyBAnyNorm.corollaries19_110

#check AnyBAnyNorm.Construction.commonDenominator_least
#check AnyBAnyNorm.Construction.commonContent_greatest
#check AnyBAnyNorm.Construction.primeProduct_four

#check AnyBAnyNorm.nonnegative_index_integral
