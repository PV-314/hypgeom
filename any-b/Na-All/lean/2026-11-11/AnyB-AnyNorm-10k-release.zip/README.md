# Revision 10k · Theorems 1.7 and 1.8 with explicit hypotheses

The Lean proofs use the denominator estimate and Akhtari’s theorem under the same explicit hypotheses as the earlier releases. The proof of Theorem 1.8(a) applies [13, Theorem 1.4(a)] and [14, Theorem 1.8(a)] and records the three calculations of §5.6 as explicit hypotheses. The conjectures are outside the verification. The earlier declarations of the conjectures remain in the sources.

[Main theorem proofs and external hypotheses](MAIN_THEOREMS_FAITHFULNESS_AUDIT.md) · [Manuscript changes](FAITHFULNESS_AUDIT.md) · [Computational evidence](SECTION56_TUPLE_AUDIT.md)

From the extracted directory with Python 3.11+ and the pinned Lean toolchain, run

~~~sh
python restore.py
lake exe cache get
lake build
lake env lean Audit.lean
lake env lean release-evidence/MainTheoremDependencies.lean
lake env lean release-evidence/Lemma21Nonvanishing.lean
lake env lean release-evidence/Section56SquareNorms.lean
lake env lean release-evidence/Reference14Lemma21.lean
~~~

For the §5.6 calculation, use JDK 21 and supply your PARI/GP executable in place of `/path/to/gp`.
~~~sh
javac -d release-evidence release-evidence/hypgeom/any-b/Na-All/java/BAllNaAllSearch.java release-evidence/CheckJavaBounds.java
java -cp release-evidence CheckJavaBounds
python release-evidence/check_cutoffs.py evidence/BAllNaAllSearch-b-1-4-2026-10-28a.txt
python check_section56_size.py release-evidence/hypgeom/any-b/Na-All/pari/b1-4-nAAll-post-java-checks.gp release-evidence/BAllNaAllSearch-b-1-4-2026-11-10a.txt
python check_section56_refinement.py evidence/refined-representations.txt
python check_section56.py evidence/b1-4-nAAll-solve-output-2026-10-28a.txt
python release-evidence/check_section56_alignment.py release-evidence/hypgeom /path/to/gp evidence reproduced-tuples.csv
python release-evidence/check_quartic_reduction.py /path/to/gp
~~~

The first three full Java reruns use the command `java -cp release-evidence BAllNaAllSearch b` with the integer value of b. The transcript for all four rows and the solver inputs are bundled. The axiom check permits propext, Classical.choice and Quot.sound. The main theorem audit lists the external mathematical and computational hypotheses separately.
