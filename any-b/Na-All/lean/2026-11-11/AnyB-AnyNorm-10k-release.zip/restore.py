"""Restore both release packages from the exact user-supplied ZIPs."""
import argparse
import hashlib
import json
import os
import tempfile
import zipfile
from contextlib import nullcontext
from pathlib import Path

ROOT = Path(__file__).resolve().parent
# Nested release members can exceed MAX_PATH even in ordinary extraction directories.
if os.name == "nt":
    location = str(ROOT)
    extended = "\\\\?\\"
    if not location.startswith(extended):
        location = extended + ("UNC\\" + location[2:] if location.startswith("\\\\") else location)
        ROOT = Path(location)
JNT = "JNT-2024-faithful-20261106-f2-evidence1"


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def check(path, expected):
    if digest(path) != expected:
        raise SystemExit(f"SHA-256 mismatch: {path}")


def unpack_or_verify(archive, directory, verify):
    with zipfile.ZipFile(archive) as release:
        if not verify:
            release.extractall(directory)
        for entry in release.infolist():
            if not entry.is_dir():
                with release.open(entry) as stream:
                    check(directory / entry.filename,
                          hashlib.file_digest(stream, "sha256").hexdigest())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    inputs = json.loads((ROOT / "inputs.lock.json").read_text())
    for name, entry in inputs.items():
        original = Path(entry["path"])
        bundled = ROOT / "inputs" / original.name
        parser.add_argument("--" + name.replace("_", "-"), type=Path,
                            default=bundled if bundled.is_file() else original)
    args = parser.parse_args()
    for name, entry in inputs.items():
        check(getattr(args, name), entry["sha256"])
    destination = ROOT / ".deps"
    verify = destination.exists()
    with (nullcontext() if verify else tempfile.TemporaryDirectory(dir=ROOT)) as staging:
        base = destination if verify else Path(staging) / "packages"
        unpack_or_verify(args.anyb, base, verify)
        nested = base / "AnyB-NormSquare" / ".dependencies"
        check(nested / (JNT + ".zip"), inputs["jnt"]["sha256"])
        unpack_or_verify(args.jnt, nested, verify)
        if not verify:
            base.rename(destination)
    print("Verified the 10k and JNT manuscript pairs, the supplied [13] PDF, both release archives and all restored members.")


if __name__ == "__main__":
    main()
