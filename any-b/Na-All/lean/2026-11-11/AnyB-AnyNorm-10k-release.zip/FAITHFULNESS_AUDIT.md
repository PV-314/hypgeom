# Revision 10k · faithfulness audit of the changes since 10i

Comparison with the supplied 10i TeX and PDF confirms the deletion at the end of the opening paragraph of §2.2, PDF p. 7. The paragraph now ends “when $r$ is odd.” It also describes Lemma 2.1 as “a generalisation” in place of “a slight generalisation”. The TeX comparison shows no change to the statement or proof of Lemma 2.1, its applications, or the statements or proofs of Theorems 1.7 and 1.8. The main theorem audit records the Lean checks and the external premises carried over from 10i.

## §1.3, PDF p. 2 · which squares count

The 10k TeX specifies “distinct non-zero integer squares” in all three clauses of Conjecture 1.1 (lines 228–234) and both clauses of Conjecture 1.2 (lines 249–252). The PDF agrees. The 10i declarations in `AnyBAnyNorm/QuotedResults.lean` use `AtMostSquareValues`, which includes zero. For both conjectures the standing hypothesis in §1.2, lines 209–210, concerns the unprimed sequence.

In Conjecture 1.1 every square among the unprimed terms is at least $b^2>0$, so either count gives the same bounds. In Conjecture 1.2 a zero can occur at an odd index. For $a=b=1$ and $d=t=u=2$, we have $α=ε=1+√2$ and $N_α=-1$. Equation (1.4) excludes an unprimed zero and $y_0=1$, so 1 is the smallest integer square. At any square $y_k≥1$, equation (1.4) gives $x_k^2=2y_k^2-1≥1$, as required by §1.2. Equation (1.5) gives $αε^{-1}=1$, hence $y′_{-1}=0$. The example distinguishes the sets of values counted. Both numerical bounds allow the values exhibited here.

The author excluded the conjectures from the 10k verification on 11 November 2026. The earlier declarations and this example are historical evidence. [Lean check of the example](release-evidence/Conjecture12OddZero.lean)

## §2.2, proof of Lemma 2.1 · strict inequality in the cited proof

At lines 691–705 the manuscript expands the square of the determinant, proves it is integral in the imaginary quadratic field, and takes its norm. The corresponding Lean proof derives the lower bound 1 on the absolute value of every nonzero determinant. Line 706 then refers to the proof in [11].

In the supplied 7 November version of [11], p. 5, lines 425–433, the first displayed estimate is strict for a general index with nonzero determinant. The text says “From our upper bounds” and only afterwards specifies “With r = r₀”. The triangle inequality and the cited bounds give the weak estimate directly. Multiplication of the strict bound on |qᵣ| by |R| preserves strictness if |R| is positive.

At the two indices actually used, the cutoff gives ℓ₀ E⁻ʳ |q| < 1. Hence the nonzero determinant bound gives |qᵣ| |R| ≥ 1 − ℓ₀ E⁻ʳ |q| > 0, as needed. The Lean proof supplies exactly this premise to `determinant_error_bound`. For a general index, nonvanishing of R can also be proved from the full sequence hypotheses. If R vanished, then |Δᵣ| ≤ |q| ℓ₀ E⁻ʳ would force every sufficiently late determinant to vanish, contradicting the consecutive determinant condition and the nonzero comparison pair. This extra argument does not appear in the cited passage.

The author confirmed that the newer proof in [11] establishes R ≠ 0. The local TeX for [11], `sequence-version-b-1-post-proofs-version-no-corrections-section.tex`, lines 418–423, contains the argument described above (SHA-256 `d3317f5092a84ffe5de43a9586bba21fe0d826a62ce0cbd46d38bc451b4b28cc`). In the setting of 10k, the lower bound for a nonzero determinant comes from its squared determinant in the base field. Multiplication by |R| therefore preserves the strict inequality. The proposed weakening was withdrawn. This check uses the newer passage as manuscript evidence alongside the pinned Lean release of [11]. [Earlier check at the two cutoff indices](release-evidence/Lemma21StrictInequality.lean)

The [Lean proof of the newer paragraph](release-evidence/Lemma21Nonvanishing.lean) takes the integrality and product-membership hypotheses of 10k and calls its proved determinant bound. Assuming R = 0, it shows q ≠ 0 and takes n with Eⁿ > |q|ℓ₀. At every r ≥ n, the approximation bound forces |pᵣq − qᵣp| < 1. Thus the determinant vanishes and pᵣ = (p/q)qᵣ. At n and n+1 this contradicts the consecutive determinant hypothesis. Lean checked this standalone proof with only propext, Classical.choice and Quot.sound. The main proofs keep their dependency on the previously formalised lemma.

Both verified dependency archives were retained. This release applies [13] and [14] as cited in §5.6, under explicit hypotheses. The previous release expanded the small-b proof in [13]. [Theorems 1.7 and 1.8 and their external hypotheses](MAIN_THEOREMS_FAITHFULNESS_AUDIT.md)
