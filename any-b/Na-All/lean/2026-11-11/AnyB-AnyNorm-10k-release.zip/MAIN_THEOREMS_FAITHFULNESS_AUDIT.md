# Theorems 1.7 and 1.8 in revision 10k

The author requested that cited theorems and external calculations appear as explicit hypotheses, following the JNT-2024 and JNT-2026 releases. The entry point is [theorem18_paper](AnyBAnyNorm/Theorem18.lean). No conjecture enters a main theorem.

The deleted final sentence of the introductory paragraph in §2.2 is historical to 10i. The current [revision audit](FAITHFULNESS_AUDIT.md) records the newer proof in [11]. The [10i audit](MAIN_THEOREMS_FAITHFULNESS_AUDIT_10i.md) preserves the earlier author decisions on [12] and [14].

## Applications of Lemma 2.1 in the 10k argument

The [general lemma](AnyBAnyNorm/Diophantine.lean) is proved. The proof of [section42_apply](AnyBAnyNorm/Section42.lean#L116) supplies the two integral comparison elements, field membership of the approximants and the three products, the nonzero denominator, the numerical hypotheses, both approximation bounds at every nonnegative index, and the nonzero consecutive determinant. The large-index denominator estimate described below enters through the approximation bounds.
In §4.2, $t'=\operatorname{core}(N_\alpha)$, $u_1=2x_{m_1}$, and $u_2=2N_{\varepsilon^{m_1}}\sqrt{N_\alpha/t'}$. The comparison field is $\mathbb Q(\sqrt{t'})$, the target is the specified fourth root of $\omega_{m_1}$, and $c=3/4$. With $q=(r_{m_1}-s_{m_1}\sqrt{t'})(r_{m_3}+s_{m_3}\sqrt{t'})$ and the local $p=\bar q$, the numerator passed to Lemma 2.1 is **ηp**. The denominator passed is **q**. The least positive index $r_0$ is chosen for this same pair.

| 10k passage | Use of the result of §4.2 |
|---|---|
| §4.3 | At $r_0=1$ and unequal cross-products, part (b) supplies the strict lower bound for the approximation error. |
| §4.4 | At $r_0=1$ and equal cross-products, the proof uses the error for the explicit approximant. |
| §4.5 | At $r_0>1$ and unequal cross-products, the proof uses part (b) and failure of the strict cutoff at $r_0-1$ by minimality. |
| §4.6 | At $r_0>1$ and equal cross-products, the proof uses the explicit approximant error and the same minimality at $r_0-1$. |
The general lower bound in part (a) is proved and is dropped at the [four-case split](AnyBAnyNorm/FourCases.lean#L90). Section 5 reuses the resulting estimates. It makes no further direct application of the revised lemma.

## Hypotheses of the Lean endpoints

Both endpoints quantify over the paper's admissible parameters, negative norm, the cutoff $K$, and the two standing conditions in [Normalized](AnyBAnyNorm/MainStatements.lean#L11). These say that $b^2$ is the least square and that $x_k\ne0$ whenever $y_k$ is an integer square. The conclusions count distinct square **values**. Theorem 1.7 uses the strict printed threshold and $k\ge1$ or $k\le K$. Theorem 1.8 uses $k\ge3$ or $k\le K-2$, with its respective restrictions on $b,d$. The endpoints start with these normalised data. The full reduction from arbitrary initial data is outside them.

* [Theorem 1.7](AnyBAnyNorm/Consolidation.lean#L82) takes one external premise, `Hypergeometric.DenominatorEstimate4`. It is the strict maximum estimate in [DenominatorBounds.lean](.deps/AnyB-NormSquare/.dependencies/JNT-2024-faithful-20261106-f2-evidence1/JNT-2024/DenominatorBounds.lean#L174), for every nonzero integer denominator parameter and every integer index $r\ge139$. The finite range $0\le r\le138$ of the denominator inequalities used in the proof is checked in the imported development.

* [Theorem 1.8(b)](AnyBAnyNorm/Section55.lean#L198) takes that estimate and `AkhtariTheorem11`, the assertion that $AX^4-BY^2=1$ has at most two positive solution pairs for positive integral $A,B$. The direct proof uses Akhtari for $N_\alpha=-1$.

* Theorem 1.8(a) uses the denominator estimate, [13, Theorem 1.4(a)], [14, Theorem 1.8(a)], and the three calculation hypotheses below. For [13] Lean proves its factorisation condition with b₁ = 1 and b₂ = b: a prime dividing b ≤ 4 must be 2 or 3. The resulting bound is two square values on k ≥ 2 or k ≤ K−1. For [14] the bound is four on those same tails when the odd part of the norm magnitude is 1 or a prime power. The current tails k ≥ 3 or k ≤ K−2 are contained in them. [Application of the two cited results](AnyBAnyNorm/Section56Norms.lean) · [Specialisation of the statement of [13]](AnyBAnyNorm/Theorem18.lean)

The following three calculation hypotheses concern §5.6 of this paper.

1. [JavaSquareSearch](AnyBAnyNorm/FiniteRange.lean#L42) says that an admissible tuple with $d\le D_{b,u}$ and a square on the indicated tail at or below the threshold of Proposition 4.1 occurs among the 189 listed tuples.
2. [PostJavaSearch](AnyBAnyNorm/Theorem18.lean#L19) says that such a row is retained if a tail square satisfies the preliminary and refined bounds using its least admissible coefficient multiplied by $4b^2\sqrt{|N_\alpha|}$. The declaration specifies the quantifiers and inequalities.
3. [QuarticResultsComplete](AnyBAnyNorm/QuarticResults.lean#L127) says that every positive integral solution of each of the 94 listed quartic equations occurs in its result list. Membership implies that the pair solves the equation by a separate checked result. Completeness is the external direction.
The current [Lean premise for the prime-power result](AnyBAnyNorm/Section56Norms.lean#L29) supplies at most four distinct tail square values for $b\le7$, negative norm of absolute value $2^\ell p^m$ with odd prime $p$, both standing conditions (the initial square is least and $x_k\ne0$ at each square), and $k\ge2$ or $k\le K-1$.

## Computational coverage and the imported proofs

Of the 162 distinct retained equations, 68 have a norm covered by the two citations. The other 94 use the solution lists checked in this development, with exhaustiveness an explicit premise. All 11 square-norm equations also satisfy the norm condition of [14]. The proof applies [13] in the square case and [14] in the other covered cases. [Partition and norm conditions](AnyBAnyNorm/Section56Norms.lean) · [Finite check](release-evidence/Section56SquareNorms.lean)

The combined Theorem 1.8 takes seven external hypotheses: the denominator estimate, Akhtari’s Theorem 1.1, the cited results from [13] and [14], and the three §5.6 calculation results listed above. The Magma height bound from [11] belongs to the separately available proof of the small-b branch of [13]. The Java enumeration, square search and exceptional quartics for b = 5, 13, 17 belong to the general proof in [13]. These computations enter only when expanding the corresponding cited proofs. [Lean declarations](AnyBAnyNorm/Theorem18.lean)

The axiom check permits propext, Classical.choice and Quot.sound. The proof-dependency check follows the applications of Lemmas 2.1 and 3.6 and verifies the use of the cited hypotheses at the §5.6 norm split. [Axiom check](release-evidence/10k-cited-Audit.txt) · [Proof-dependency check](release-evidence/10k-cited-MainTheoremDependencies.txt)
