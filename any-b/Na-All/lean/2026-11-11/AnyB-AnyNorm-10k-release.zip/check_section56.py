"""Check the §5.6 solver transcript and its ten exceptional sequences."""
import argparse
import ast
import hashlib
import re
from collections import Counter
from fractions import Fraction
from math import isqrt
from pathlib import Path

PROJECT = Path(__file__).resolve().parent
TRANSCRIPT_SHA256 = "5c47154466e761ce4cb010957637f209d6b3ca1c3a93ac3435f79e2074d57b7d"


def check(condition, message):
    if not condition:
        raise ValueError(message)


def solver_results(path):
    data = path.read_bytes()
    check(hashlib.sha256(data).hexdigest() == TRANSCRIPT_SHA256, "Unexpected transcript hash")
    inputs, reports = [], []
    results = {}
    for line in data.decode("utf-8").splitlines():
        header = re.match(r"^d=(\d+), nrmA=(-\d+):", line)
        if header:
            equation = tuple(map(int, header.groups()))
            inputs.append(equation)
        result = re.fullmatch(r"Number of solutions=(\d+), allSolns=(\[.*\]), time\(ms\)=.*", line)
        if result:
            points = [tuple(pair) for pair in ast.literal_eval(result[2])]
            check(len(set(points)) == len(points) == int(result[1]), f"Point count: {equation}")
            d, n = equation
            check(all(x > 0 and y > 0 and x*x - d*y**4 == n for x, y in points),
                  f"Invalid quartic point: {equation}")
            check(results.setdefault(equation, points) == points, f"Repeated equation: {equation}")
            reports.append(equation)
    return inputs, reports, results


def covered(n):
    if isqrt(n)**2 == n:
        return True
    while n % 2 == 0:
        n //= 2
    if n == 1:
        return True
    p = next((q for q in range(3, isqrt(n) + 1, 2) if n % q == 0), n)
    while n % p == 0:
        n //= p
    return n == 1


def sequence_hits(params, points):
    a, b, d, t, u = params
    check(abs(t*t - d*u*u) == 4, f"Pell condition: {params}")
    trace = Fraction(t*t + d*u*u, 2)
    squares = {y*y for _, y in points}
    hits = {b*b: {0}} if b*b in squares else {}
    for sign in (-1, 1):
        previous = b*b
        current = Fraction(b*b*(t*t + d*u*u) + sign*2*a*t*u, 4)
        index = sign
        # Once current > previous and current > max(squares), trace > 2
        # makes every later term on this branch strictly larger.
        check(trace > 2, f"Non-growing trace: {params}")
        while current <= max(squares) or current <= previous:
            if current in squares:
                hits.setdefault(current, set()).add(index)
            previous, current = current, trace*current - previous
            index += sign
    return hits


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("transcript", type=Path)
    inputs, calls, results = solver_results(parser.parse_args().transcript)
    source = (PROJECT / "AnyBAnyNorm" / "PostJava.lean").read_text(encoding="utf-8")
    tuples = [tuple(map(int, m)) for m in re.findall(
        r"^  ⟨(\d+), (\d+), (\d+), (\d+), (\d+)⟩", source, re.MULTILINE)]
    keys = [(d, a*a - d*b**4) for a, b, d, _, _ in tuples]
    check(Counter(keys) == Counter(inputs), "Transcript inputs differ from post-Java tuples")
    check(Counter(calls) == Counter(k for k in keys if not covered(-k[1])), "Solver coverage")
    lean = (PROJECT / "AnyBAnyNorm" / "QuarticResults.lean").read_text(encoding="utf-8")
    encoded = [(int(d), int(n), ast.literal_eval(points)) for d, n, points in re.findall(
        r"^  \(\((\d+), (-\d+)\), (\[.*?\])\)", lean, re.MULTILINE)]
    check(encoded == [(d, n, points) for (d, n), points in sorted(results.items())],
          "Lean table differs from the transcript")
    sizes = Counter(map(len, results.values()))
    check(sizes == {2: 45, 3: 39, 4: 6, 5: 4}, f"Equation classes: {sizes}")
    four = {}
    for params, key in zip(tuples, keys):
        if key in results and len(results[key]) > 3:
            check(params[1] in (3, 4), f"Unexpected exceptional b: {params}")
            hits = sequence_hits(params, results[key])
            if len(hits) >= 4:
                four[params] = hits
    expected = {167**2: {-5}, 5**2: {-1}, 3**2: {0}, 31**2: {3}}
    check(four == {(1, 3, 2, 2, 2): expected, (2, 3, 8, 2, 1): expected},
          f"Exceptional sequence hits: {four}")
    print("Verified 94 equation records, the 84/6/4 classification and both four-square sequences.")


if __name__ == "__main__":
    main()
