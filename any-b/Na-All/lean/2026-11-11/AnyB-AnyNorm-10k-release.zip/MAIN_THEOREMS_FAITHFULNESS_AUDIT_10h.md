# Faithfulness audit of Theorems 1.7 and 1.8 in revision 10h

## Revision and verification of §5.6

The only TeX edit and the only change in extracted PDF text from 10g concern elapsed time in Table 1 on page 22. The printed 41m 17s agrees with the rounded 10 November run. The count audit records the revised inputs, results and extent of the computational verification. The further Lean proofs in this checkpoint concern the solver's change of variables and the closing classification of sequences in §5.6. [Count audit](SECTION56_TUPLE_AUDIT.md)

## Cross-reference awaiting the author

On p. 7, §2.2, TeX lines 652–654, the introduction to Lemma 2.1 says “as we saw in the last paragraph of the previous subsection”. It refers to the possible failure of $p_r,q_r$ to belong to $\mathbb Q(\sqrt{t'})$ for odd $r$. The relevant paragraph follows (2.4) on the same page, TeX lines 628–635. The final paragraph of §2.1, lines 642–643, points forward to the verification of $|\omega-1|<1$. The field-membership argument and the application of Lemma 2.1 use the paragraph following (2.4). Suggested replacement for the locator alone: “as we saw after (2.4)”. The author’s decision is pending.

## Approved change of variables in §5.6

On p. 23, TeX lines 1991–1995, the text says “Writing $-N_\alpha=qs^2$, with $q$ squarefree, we factor” and displays $(x+s\sqrt{-q})(x-s\sqrt{-q})=dy^4$. These are valid identities for the original $x,d,N_\alpha$. In the published solver the descent is applied after dividing out the largest square $c^2$ dividing $\gcd(d,-N_\alpha)$. Since $c^2\mid x^2$, one has $c\mid x$. The variables used in the program's factorisation are $X=x/c$, $d/c^2$, $N_\alpha/c^2$ and $s/c$, with the same $q$. Recovery multiplies $X$ by $c$.

The author approved recording this substitution in Lean and in the release audit, retaining the manuscript wording. Lean proves the maximality of the scale by divisibility, both directions of the coordinate correspondence, the equality of the squarefree parts and the formula for the reduced square factor. At $(d,N_\alpha)=(8,-644)$ it proves $q=161$, $s=c=2$ and the correspondence with $(2,-161)$. The program factors $X+\sqrt{-161}$ and restores $(2X,y)$. [Lean proofs](AnyBAnyNorm/QuarticReduction.lean) · [Solver reduction](release-evidence/hypgeom/general/pari/quartic-solver.gp#L187) · [Recovery](release-evidence/hypgeom/general/pari/quartic-solver.gp#L691)

Of the 94 input equations, 72 have $c=1$, 20 have $c=2$, one has $c=4$ and one has $c=7$. There are 73 distinct reduced equations. All 251 reported positive points passed substitution and recovery. Every pair of inputs with the same reduced equation gives the same reduced list. [Reproducible check](release-evidence/check_quartic_reduction.py) · [Results](release-evidence/10h-quartic-reduction.txt)

For comparison with Barros, Theorem 2.1 in §2.2 applies to his (2.2) with $D=-N_\alpha/c^2$, $C=d/c^2$, exponent $4$, and $y>0$. His squarefree integer $d$ and square factor $q$ correspond respectively to this paper’s $q$ and $s/c$. The solver enumerates the ideal exponents modulo four over primes dividing $2(d/c^2)(-N_\alpha/c^2)$, solves $[\mathfrak a]+4[C]=0$ in the class group, principalises $\mathfrak a C^4$, and uses a basis of $C^{-1}$. Lean checks the conjugate product and the coefficient of $\sqrt{-q}$ in $\kappa(b_1U+b_2V)^4$. The class-group enumeration, principalisation and exhaustive solution of the resulting forms remain external computations. The 234 distinct dehomogenised polynomials in the transcript all passed PARI’s irreducibility test. [Barros, pp. 11–13](https://samirsiksek.github.io/siksek.github.io/theses/carlosphd.pdf) · [Descent](release-evidence/hypgeom/general/pari/quartic-solver.gp#L87) · [Coefficient calculation](release-evidence/hypgeom/general/pari/quartic-solver.gp#L567)

At the end of §5.6, Lean checks that every retained tuple whose reported quartic has more than three positive solutions has $b=3$ or $b=4$. Under the stated completeness premise and standing hypotheses, it bounds the number of square values over all integer indices by three except for the two displayed tuples, for which the bound is four. The four displayed witnesses and equality of the two $y$-sequences were already proved. Theorem 1.8(a) uses the resulting bound on its two tails. [Classification](AnyBAnyNorm/QuarticMembership.lean) · [Four witnesses](AnyBAnyNorm/ExceptionalSequence.lean)

Lean proves that completeness of the 94 original positive solution lists is equivalent to exhaustiveness in the reduced coordinates, with the recovery factor applied to list membership. Theorem 1.8(a) still assumes this completeness. The numerical replay regenerated the descent for all 94 and checked the saved Thue solutions against the 336 corresponding forms. [Equivalence](AnyBAnyNorm/QuarticResults.lean) · [Assumption inventory](#hypotheses-of-the-lean-endpoints)

At TeX lines 1971–1974 the candidate supplies the least $f_{m_1}$. Lemma 3.2 bounds $f_{m_3}$ by $4b^2\sqrt{|\operatorname{sf}(N_\alpha)|}$, hence by $4b^2\sqrt{|N_\alpha|}$. Applying the larger bound to the last factor preserves the required implication in each of (4.17) and (4.22). The proof is in [Section56Bounds.lean](AnyBAnyNorm/Section56Bounds.lean) and its application in [Theorem18.lean](AnyBAnyNorm/Theorem18.lean). The computational premise has the same fixed factor as the manuscript. On the recorded inputs, the exact replay checks 205 least coefficients, 615 diagnostic identities, the 175 retained tuples and the 162 distinct equations. [Refined calculation](release-evidence/10h-refinement.txt)

## The approved correction at the use of [14]

Page 23, TeX lines 1980–1982, invokes [13] and [14]. Theorem 1.8(a) of [14], read with its standing remark in §1.2, assumes $x_k\ne0$ whenever $y_k$ is a square. The local source of [14] is sequence-version-any-b-nrmA-PP.tex, lines 218–229 and 381–388. On the author’s instruction, [PrimePowerTheorem18a](AnyBAnyNorm/Section56Norms.lean) now uses both standing hypotheses in [Normalized](AnyBAnyNorm/MainStatements.lean). The proof of [Theorem 1.8(a)](AnyBAnyNorm/Theorem18.lean) supplies that conjunction to the prime-power case. The square-norm case takes the least-square component required by the imported theorem of [13].

The inspected TeX of [14] has SHA-256 `acb54c99546c35bac0e85b82926246f0ed71ee9affe2e3bd0fb43d2d0d7268f9`.

## Lean verification

Lean 4.35.0 checked the 36 local modules and package entry point across the 10h builds in the separate 10h directory. The dependency sources restored from the locked archives matched those for the reused dependency builds. The [axiom check](release-evidence/10h-Audit.txt) traversed 614 local declarations and allowed only `propext`, `Classical.choice` and `Quot.sound`. The [proof-dependency check](release-evidence/10h-MainTheoremDependencies.txt) found Lemmas 2.1 and 3.6 in the proofs of Theorems 1.7, 1.8(a), 1.8(b) and the combined theorem. It also found the last-coefficient comparison in Theorem 1.8(a) and the combined theorem. The explicit external hypotheses of these declarations are listed below.

## Changes from 10c

* §1.1, p. 1. The quartic is $X^2-dY^4=N_\alpha$. Its rational point is $(a,b)$. If $N_\alpha=0$, then $d=(a/b^2)^2$, contrary to nonsquareness. [sequenceQuarticModel](AnyBAnyNorm/QuarticModel.lean) specialises the previously checked birational correspondence with a nonsingular Weierstrass equation. Its only premise on the parameters is admissibility.
* Corollary 1.10, p. 4. The reference is again printed as “Corollary 1.9(a)”. The other two edits there and the insertion of “let” in Lemma 3.5(b) have no mathematical effect.
* Lemma 3.6, p. 12. The statement, including the fixed sign of $u_2$ and the constant 16, agrees with p. 8, (3.5), in the supplied PDF of [13]. [lemma36](AnyBAnyNorm/SequenceLemmas.lean) now applies the release's fixed-sign declaration directly. Its use in §4 at $k=m_1$ no longer takes a separate sign hypothesis. The input lock identifies the newly supplied 07b ZIP and PDF.
* The 10d–10e TeX comparison has one change, the correction on p. 4. The statements of Lemma 2.1 and the two main theorems are the same in 10c and 10e.

## Review through §5.5

In §4.1 the five representations are fixed before the indices are selected. Strict ordering, the least-square condition and the definition of $K$ justify the index restriction on the chosen triple. The resulting pair for the comparison in §4.2 and each use of the least positive index are specified below. In §§4.3–4.4 the proof uses the two successive gaps, with the same three indices, to give exponent 9. In §§4.5–4.6 the bounds on $|g|\mathcal N_{d',4}$ come from the fixed-sign case. For the last case the proof excludes a base at most one before maximising at $r_0=2$. In §4.7 the smallest of the five squares is at most the smallest of the selected three. This transfers the four bounds to Proposition 4.1 and hence to Theorem 1.7.

For Theorem 1.8, Lemma 3.3(b) with $du^2\ge300$ gives (5.3) on both indicated tails. The power in its lower bound is at least two. Sections 5.1–5.4 compare this with the four bounds from §4, retaining the same cases for the cross-products. For larger indices the proof uses the positive exponent denominators and $|g|\mathcal N_{d',4}\ge2$. Section 5.5 combines the six sufficient conditions when $b\ge5$ and $|N_\alpha|\ge2$. For $N_\alpha=-1$, Akhtari's equation has $A=d$ and $B=1$ and a sequence square $y_k=z^2$ supplies $d z^4-x_k^2=1$. The review of §5.6 reaches the final sequence classification on page 23. The cross-reference in §2.2 remains open. The assumption inventory below is taken from the theorem declarations.

## Applications of Lemma 2.1 in the 10h argument


The [general lemma](AnyBAnyNorm/Diophantine.lean) is proved. The proof of [section42_apply](AnyBAnyNorm/Section42.lean#L116) supplies the two integral comparison elements, field membership of the approximants and the three products, the nonzero denominator, the numerical hypotheses, both approximation bounds at every nonnegative index, and the nonzero consecutive determinant. The large-index denominator estimate described below enters through the approximation bounds.

In §4.2, $t'=\operatorname{core}(N_\alpha)$, $u_1=2x_{m_1}$, and $u_2=2N_{\varepsilon^{m_1}}\sqrt{N_\alpha/t'}$. The comparison field is $\mathbb Q(\sqrt{t'})$, the target is the specified fourth root of $\omega_{m_1}$, and $c=3/4$. With $q=(r_{m_1}-s_{m_1}\sqrt{t'})(r_{m_3}+s_{m_3}\sqrt{t'})$ and the local $p=\bar q$, the numerator passed to Lemma 2.1 is **ηp**. The denominator passed is **q**. The least positive index $r_0$ is chosen for this same pair.

| 10h passage | Use of the result of §4.2 |
|---|---|
| §4.3 | At $r_0=1$ and unequal cross-products, part (b) supplies the strict lower bound for the approximation error. |
| §4.4 | At $r_0=1$ and equal cross-products, the proof uses the error for the explicit approximant. |
| §4.5 | At $r_0>1$ and unequal cross-products, the proof uses part (b) and failure of the strict cutoff at $r_0-1$ by minimality. |
| §4.6 | At $r_0>1$ and equal cross-products, the proof uses the explicit approximant error and the same minimality at $r_0-1$. |

The general lower bound in part (a) is proved and is dropped at the [four-case split](AnyBAnyNorm/FourCases.lean#L90). Section 5 reuses the resulting estimates. It makes no further direct application of the revised lemma.

## Hypotheses of the Lean endpoints

Both endpoints quantify over the paper's admissible parameters, negative norm, the cutoff $K$, and the two standing conditions in [Normalized](AnyBAnyNorm/MainStatements.lean#L11). These say that $b^2$ is the least square and that $x_k\ne0$ whenever $y_k$ is an integer square. The conclusions count distinct square **values**. Theorem 1.7 uses the strict printed threshold and $k\ge1$ or $k\le K$. Theorem 1.8 uses $k\ge3$ or $k\le K-2$, with its respective restrictions on $b,d$. The endpoints start with these normalised data. The full reduction from arbitrary initial data is outside them.

* [Theorem 1.7](AnyBAnyNorm/Consolidation.lean#L82) takes one external premise, `Hypergeometric.DenominatorEstimate4`. It is the strict maximum estimate in [DenominatorBounds.lean](.deps/AnyB-NormSquare/.dependencies/JNT-2024-faithful-20261106-f2-evidence1/JNT-2024/DenominatorBounds.lean#L174), for every nonzero integer denominator parameter and every integer index $r\ge139$. The finite range $0\le r\le138$ of the denominator inequalities used in the proof is checked in the imported development.
* [Theorem 1.8(b)](AnyBAnyNorm/Section55.lean#L198) takes that estimate and `AkhtariTheorem11`, the assertion that $AX^4-BY^2=1$ has at most two positive solution pairs for positive integral $A,B$. The direct proof uses Akhtari for $N_\alpha=-1$.
* [Theorem 1.8(a)](AnyBAnyNorm/Theorem18.lean) takes the denominator estimate, three §5.6 calculation premises, the square-norm Theorem 1.4(a), and the cited prime-power result. In [theorem18_paper](AnyBAnyNorm/Theorem18.lean#L107) the proof of the square-norm theorem is supplied using the same denominator estimate, Akhtari's theorem, and the four imported calculation premises listed below.

The three calculation premises for §5.6 of 10h are as follows.

1. [JavaSquareSearch](AnyBAnyNorm/FiniteRange.lean#L42) says that an admissible tuple with $d\le D_{b,u}$ and a square on the indicated tail at or below the threshold of Proposition 4.1 occurs among the 189 listed tuples.
2. [PostJavaSearch](AnyBAnyNorm/Theorem18.lean#L19) says that such a row is retained if a tail square satisfies the preliminary and refined bounds using its least admissible coefficient multiplied by $4b^2\sqrt{|N_\alpha|}$. The declaration specifies the quantifiers and inequalities.
3. [QuarticResultsComplete](AnyBAnyNorm/QuarticResults.lean#L127) says that every positive integral solution of each of the 94 listed quartic equations occurs in its result list. Membership implies that the pair solves the equation by a separate checked result. Completeness is the external direction.

The current [Lean premise for the prime-power result](AnyBAnyNorm/Section56Norms.lean#L29) supplies at most four distinct tail square values for $b\le7$, negative norm of absolute value $2^\ell p^m$ with odd prime $p$, both standing conditions (the initial square is least and $x_k\ne0$ at each square), and $k\ge2$ or $k\le K-1$.

The imported [SquareNormCalculations](AnyBAnyNorm/Theorem18.lean#L100) contains these four propositions.

1. [Section46Magma](.deps/AnyB-NormSquare/.dependencies/JNT-2024-faithful-20261106-f2-evidence1/JNT-2024/Section46Calculation.lean#L51) supplies the unrestricted height bound for the small quartics of the JNT paper. The bounded calculation through $y=109$ is checked.
2. [JavaEnumeration](.deps/AnyB-NormSquare/AnyBNormSquare/Section56Calculations.lean#L18) gives the exact counts of the candidate sets for the three table rows of the square-norm paper.
3. [JavaSquareSearch in the square-norm paper](.deps/AnyB-NormSquare/AnyBNormSquare/Section56Calculations.lean#L24) identifies exactly the tuples with a square below its strict search bound on its indicated tails.
4. [ExceptionalQuartics](.deps/AnyB-NormSquare/AnyBNormSquare/Section56Calculations.lean#L34) restricts the positive solutions corresponding to squares of each recorded exceptional sequence to its specified initial pair or recorded root.

Thus the combined endpoint has seven explicit inputs outside the theorem statement, or ten propositions on opening the four-field calculation record. Cohn's theorem enters Corollary 1.10 separately. Neither conjecture is an input. This inventory describes the declarations examined in the audit. It does not certify the external calculations or finish the remaining manuscript comparisons.
