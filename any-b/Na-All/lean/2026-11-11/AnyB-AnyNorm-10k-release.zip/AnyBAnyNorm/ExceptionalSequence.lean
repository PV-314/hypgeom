module
public import «JNT-2024».Sequence

@[expose] public section
namespace AnyBAnyNorm
open «JNT-2024»

/-- The final two tuples in §5.6, 07e TeX 1974–1980. -/
def exceptionalA : Parameters := ⟨1, 3, 2, 2, 2⟩
def exceptionalB : Parameters := ⟨2, 3, 8, 2, 1⟩

theorem exceptional_norms :
    exceptionalA.normAlpha = -161 ∧ exceptionalB.normAlpha = -644 := by decide

theorem pellA : exceptionalA.Pell := Or.inr (by decide)
theorem pellB : exceptionalB.Pell := Or.inr (by decide)

private theorem recA (k : ℤ) :
    exceptionalA.y pellA (k+1) = 6 * exceptionalA.y pellA k - exceptionalA.y pellA (k-1) := by
  convert exceptionalA.y_recurrence pellA k using 2
  norm_num [exceptionalA]

private theorem recB (k : ℤ) :
    exceptionalB.y pellB (k+1) = 6 * exceptionalB.y pellB k - exceptionalB.y pellB (k-1) := by
  convert exceptionalB.y_recurrence pellB k using 2
  norm_num [exceptionalB]

/-- Check the four displayed squares in the sequence defined by (1.1).
These are individual witnesses in the final calculation of §5.6. -/
theorem exceptional_four_squares :
    exceptionalA.y pellA (-5) = 167^2 ∧ exceptionalA.y pellA (-1) = 5^2 ∧
    exceptionalA.y pellA 0 = 3^2 ∧ exceptionalA.y pellA 3 = 31^2 := by
  have h₁ := exceptionalA.y_one pellA
  have hm₁ := exceptionalA.y_neg_one pellA
  have h₂ := recA 1
  have h₃ := recA 2
  have hm₂ := recA (-1)
  have hm₃ := recA (-2)
  have hm₄ := recA (-3)
  have hm₅ := recA (-4)
  norm_num [exceptionalA] at *
  exact ⟨by linarith only [hm₁, hm₂, hm₃, hm₄, hm₅], hm₁,
    by linarith only [h₁, h₂, h₃]⟩

/-- The same y-sequence at all integer indices. Both initial values and
the recurrence coefficient in (1.2)–(1.3) agree. -/
theorem exceptional_same_sequence : exceptionalA.y pellA = exceptionalB.y pellB := by
  let A := exceptionalA.y pellA
  let B := exceptionalB.y pellB
  have pair (k : ℤ) : A k = B k ∧ A (k+1) = B (k+1) := by
    induction k using Int.induction_on with
    | zero => norm_num [A, B, Parameters.y_one, exceptionalA, exceptionalB]
    | succ k ih =>
      refine ⟨ih.2, ?_⟩
      dsimp only [A, B] at ih ⊢
      rw [recA ((k : ℤ)+1), recB ((k : ℤ)+1), add_sub_cancel_right, ih.1, ih.2]
    | pred k ih =>
      dsimp only [A, B] at ih ⊢
      have hA := recA (-(k : ℤ))
      have hB := recB (-(k : ℤ))
      refine ⟨by linarith [ih.1, ih.2], by simpa using ih.1⟩
  exact funext (fun k => (pair k).1)

end AnyBAnyNorm
