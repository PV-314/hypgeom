module

public import AnyBAnyNorm.Section55
public import AnyBAnyNorm.Section56Size

@[expose] public section
namespace AnyBAnyNorm.Section56
open «JNT-2024» AnyBNormSquare

/-- Right hand side of (5.17). -/
noncomputable def finiteBound (b u : ℝ) : ℝ :=
  max (300/u^2) (max ((54/10)*b^(4/5 : ℝ)/u^(12/5 : ℝ))
    (max (10*b^(108/19 : ℝ)/u^(66/19 : ℝ)) (max (9*b^(32/5 : ℝ)/u^(18/5 : ℝ))
      (max (57*b^(52/9 : ℝ)/u^4) (2461*b^12/u^6)))))

theorem conditions_of_finiteBound (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (hh : finiteBound P.b P.u < P.d) : Section5Conditions P.b P.d |(P.normAlpha : ℝ)| P.u := by
  simp only [finiteBound,max_lt_iff] at hh
  obtain ⟨ha,hbnd,hc,he,hf,hg⟩ := hh
  have hb : (0 : ℝ) < P.b := by exact_mod_cast h.b_pos
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hu : (0 : ℝ) < P.u := by exact_mod_cast h.u_pos
  have hN : 0 < |(P.normAlpha : ℝ)| := abs_pos.mpr (by exact_mod_cast hn.ne)
  have hs : |(P.normAlpha : ℝ)| < (P.d : ℝ)*(P.b : ℝ)^4 := by
    rw [abs_of_neg (by exact_mod_cast hn)]
    exact_mod_cast (show -P.normAlpha < P.d*P.b^4 by
      unfold Parameters.normAlpha
      nlinarith only [sq_pos_of_pos h.a_pos])
  refine ⟨(div_le_iff₀ (by positivity)).mp ha.le,hbnd.le,
    section51_norm_free hb hd hN hu hs (lt_trans ?_ hc),
    section52_norm_free hb hd hN hu hs (lt_trans ?_ he),
    section53_norm_free hb hd hN hu hs hf,?_⟩
  · gcongr
    norm_num
  · gcongr
    norm_num
  · simpa using section54_norm_free hb hd hN hu hs hg

/-- Coverage direction of the finite Java computation, restricted to the
four values of b, the finite search region, and the squares required in §5.6.
The list itself and the check of (4.4) are in Section56Size. -/
def JavaSquareSearch : Prop :=
  ∀ (P : Parameters) (h : P.Admissible), P.normAlpha < 0 → P.b ≤ 4 →
    (P.d : ℝ) ≤ finiteBound P.b P.u → ∀ K, P.IsNegativeCutoff h.pell K →
    ∀ k, (3 ≤ k ∨ k ≤ K-2) → IsIntegerSquare (P.y h.pell k) →
    (P.y h.pell k : ℝ) ≤ preciseThreshold P → ∃ r ∈ javaRows, r.params = P

/-- The first filtering step uses Proposition 4.1 itself. -/
theorem outside_java (hp : Hypergeometric.DenominatorEstimate4) (hj : JavaSquareSearch)
    (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) (hm : Normalized P h.pell)
    (hb : P.b ≤ 4) (hd : (P.d : ℝ) ≤ finiteBound P.b P.u)
    (K : ℤ) (hK : P.IsNegativeCutoff h.pell K) (hout : ¬∃ r ∈ javaRows, r.params = P) :
    AtMostSquareValuesOn (P.y h.pell) (fun k => 3 ≤ k ∨ k ≤ K-2) 4 := by
  obtain ⟨S,hcard,hmem⟩ := proposition41 hp P h hn hm K hK
  refine ⟨S,hcard,?_⟩
  intro k hk hs
  exact hmem k ⟨by omega, lt_of_not_ge (fun hle => hout (hj P h hn hb hd K hK k hk hs hle))⟩ hs

end AnyBAnyNorm.Section56
