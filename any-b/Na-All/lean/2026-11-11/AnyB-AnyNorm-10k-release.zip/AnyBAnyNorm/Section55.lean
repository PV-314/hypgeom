module

public import AnyBAnyNorm.Consolidation
public import AnyBAnyNorm.Section5High
public import «JNT-2024».AkhtariInput

@[expose] public section
namespace AnyBAnyNorm
open «JNT-2024» AnyBNormSquare

/-- The six conditions collected in §5.5, before taking their maximum. -/
structure Section5Conditions (b d N u : ℝ) : Prop where
  large : 300 ≤ d*u^2
  size : (54/10 : ℝ)*b^(4/5 : ℝ)/u^(12/5 : ℝ) ≤ d
  first : (342/100 : ℝ)*b^(24/17 : ℝ)*N^(15/34 : ℝ)/u^(33/17 : ℝ) < d
  second : (314/100 : ℝ)*b^(28/19 : ℝ)*N^(9/19 : ℝ)/u^(36/19 : ℝ) < d
  third : (85/10 : ℝ)*b^(20/17 : ℝ)*N^(8/17 : ℝ)/u^(36/17 : ℝ) < d
  fourth : (135/10 : ℝ)*b^(4/3 : ℝ)*N^(2/3 : ℝ)/u^2 < d

/-- The numerical comparison yielding the second condition in §5.5. -/
private theorem section55_size {b d N u : ℝ} (hb : 0 < b) (hd : 0 < d)
    (hN : 0 < N) (hu : 0 < u) (hh : Section5Conditions b d N u) :
    16*N/Real.sqrt d ≤ (98/100 : ℝ)*N*d^2*u^6/(4*b^2) := by
  apply (Real.log_le_log_iff (by positivity) (by positivity)).mp
  have ht := Real.log_le_log (by positivity) hh.size
  have hc := Real.log_lt_log (by norm_num : (0 : ℝ) < (16*4/(98/100))^2)
    (by norm_num : ((16*4/(98/100))^2 : ℝ) < (54/10)^5)
  simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_rpow, Real.log_sqrt, Real.log_pow] at ht hc ⊢
  norm_num1 at ht hc ⊢
  linarith only [ht,hc]

set_option exponentiation.threshold 1000 in
/-- The inequalities immediately after the six-term maximum in §5.5.
The bounds 10.78, 5.3 and 17.64 are verified at b=5 and N=2. -/
theorem section55_conditions {b d N u : ℝ} (hb : 5 ≤ b) (hd : 0 < d)
    (hN : 2 ≤ N) (hu : 1 ≤ u)
    (h : 18*b^(28/19 : ℝ)*N^(2/3 : ℝ)/u^(36/19 : ℝ) ≤ d) :
    Section5Conditions b d N u := by
  have hbp : 0 < b := by linarith
  have hNp : 0 < N := by linarith
  have hup : 0 < u := by linarith
  have lb := Real.log_le_log (by norm_num : (0 : ℝ)<5) hb
  have lN := Real.log_le_log (by norm_num : (0 : ℝ)<2) hN
  have lb0 := Real.log_nonneg (by linarith : 1 ≤ b)
  have lN0 := Real.log_nonneg (by linarith : 1 ≤ N)
  have lu := Real.log_nonneg hu
  have hh := Real.log_le_log (by positivity) h
  have c₀ := Real.log_lt_log (by norm_num : (0 : ℝ)<300^57)
    (by norm_num : (300^57 : ℝ)<(1764/100)^57*5^84*2^38)
  have c₃ := Real.log_lt_log (by norm_num : (0 : ℝ)<(85/10)^323)
    (by norm_num : ((85/10)^323 : ℝ)<(53/10)^323*5^96)
  have c₄ := Real.log_lt_log (by norm_num : (0 : ℝ)<(135/10)^57)
    (by norm_num : ((135/10)^57 : ℝ)<(1078/100)^57*5^8)
  simp (disch := positivity) only [Real.log_mul,Real.log_div,Real.log_rpow,Real.log_pow] at hh c₀ c₃ c₄
  norm_num1 at hh c₀ c₃ c₄
  constructor
  · apply (Real.log_le_log_iff (by norm_num) (by positivity)).mp
    have hc := Real.log_lt_log (by norm_num : (0 : ℝ)<1764/100) (by norm_num : (1764/100 : ℝ)<18)
    simp (disch := positivity) only [Real.log_mul,Real.log_div,Real.log_pow] at hc ⊢
    norm_num1 at hc ⊢
    linarith only [hh,c₀,hc,lb,lN,lu]
  · apply (Real.log_le_log_iff (by positivity) hd).mp
    have hc := Real.log_lt_log (by norm_num : (0 : ℝ)<54/10) (by norm_num : (54/10 : ℝ)<6)
    have hr := Real.log_lt_log (by norm_num : (0 : ℝ)<6) (by norm_num : (6 : ℝ)<18)
    simp (disch := positivity) only [Real.log_mul,Real.log_div,Real.log_rpow] at hc ⊢
    norm_num1 at hc ⊢
    linarith only [hh,hc,hr,lb0,lN0,lu]
  · apply (Real.log_lt_log_iff (by positivity) hd).mp
    have hc := Real.log_lt_log (by norm_num : (0 : ℝ)<342/100) (by norm_num : (342/100 : ℝ)<4)
    have hr := Real.log_lt_log (by norm_num : (0 : ℝ)<4) (by norm_num : (4 : ℝ)<18)
    simp (disch := positivity) only [Real.log_mul,Real.log_div,Real.log_rpow] at hc ⊢
    norm_num1 at hc ⊢
    linarith only [hh,hc,hr,lb0,lN0,lu]
  · apply (Real.log_lt_log_iff (by positivity) hd).mp
    have hc := Real.log_lt_log (by norm_num : (0 : ℝ)<314/100) (by norm_num : (314/100 : ℝ)<4)
    have hr := Real.log_lt_log (by norm_num : (0 : ℝ)<4) (by norm_num : (4 : ℝ)<18)
    simp (disch := positivity) only [Real.log_mul,Real.log_div,Real.log_rpow] at hc ⊢
    norm_num1 at hc ⊢
    linarith only [hh,hc,hr,lb0,lN0,lu]
  · apply (Real.log_lt_log_iff (by positivity) hd).mp
    have hc := Real.log_lt_log (by norm_num : (0 : ℝ)<53/10) (by norm_num : (53/10 : ℝ)<18)
    simp (disch := positivity) only [Real.log_mul,Real.log_div,Real.log_rpow] at hc ⊢
    norm_num1 at hc ⊢
    linarith only [hh,hc,c₃,lb,lb0,lN0,lu]
  · apply (Real.log_lt_log_iff (by positivity) hd).mp
    have hc := Real.log_lt_log (by norm_num : (0 : ℝ)<1078/100) (by norm_num : (1078/100 : ℝ)<18)
    simp (disch := positivity) only [Real.log_mul,Real.log_div,Real.log_rpow,Real.log_pow] at hc ⊢
    norm_num1 at hc ⊢
    linarith only [hh,hc,c₄,lb,lb0,lN0,lu]

/-- Enumerate five distinct square values in increasing order as in §4.1. -/
theorem tail_count {P : Parameters} (h : P.Admissible) (K : ℤ)
    (noFive : ∀ k : Fin 5 → ℤ, (∀ i, 3 ≤ k i ∨ k i ≤ K-2) →
      (∀ i, IsIntegerSquare (P.y h.pell (k i))) → StrictMono (fun i => P.y h.pell (k i)) → False) :
    AtMostSquareValuesOn (P.y h.pell) (fun k => 3 ≤ k ∨ k ≤ K-2) 4 := by
  classical
  let V : Set ℚ := {v | ∃ k : ℤ, (3 ≤ k ∨ k ≤ K-2) ∧ IsIntegerSquare (P.y h.pell k) ∧ P.y h.pell k = v}
  have hno (s : Finset ℚ) (hs : (s : Set ℚ) ⊆ V) (hc : s.card = 5) : False := by
    have hmem (a : Fin 5) := hs (s.orderEmbOfFin_mem hc a)
    choose k hcut hsq he using hmem
    apply noFive k hcut hsq
    intro a b hab
    change P.y h.pell (k a) < P.y h.pell (k b)
    rw [he,he]
    exact (s.orderEmbOfFin hc).strictMono hab
  have hfin : V.Finite := by
    by_contra! hinf
    obtain ⟨s,hs,hc⟩ := hinf.exists_subset_card_eq 5
    exact hno s hs hc
  refine ⟨hfin.toFinset,?_,?_⟩
  · by_contra! hh
    obtain ⟨s,hs,hc⟩ := Finset.exists_subset_card_eq (by omega : 5 ≤ hfin.toFinset.card)
    exact hno s (fun _ ha => hfin.mem_toFinset.mp (hs ha)) hc
  · intro k hk hs
    exact hfin.mem_toFinset.mpr ⟨k,hk,hs,rfl⟩

/-- Exclusion of the four cases for five squares on the two tails. -/
theorem section55_four (hp : Hypergeometric.DenominatorEstimate4) (P : Parameters)
    (h : P.Admissible) (hn : P.normAlpha < 0) (hm : Normalized P h.pell)
    (K : ℤ) (hK : P.IsNegativeCutoff h.pell K)
    (hh : Section5Conditions P.b P.d |(P.normAlpha : ℝ)| P.u) :
    AtMostSquareValuesOn (P.y h.pell) (fun k => 3 ≤ k ∨ k ≤ K-2) 4 := by
  apply tail_count h K
  intro k hk hs ho
  have hb : (1 : ℝ) ≤ P.b := by exact_mod_cast h.b_pos
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hu : (1 : ℝ) ≤ P.u := by exact_mod_cast h.u_pos
  have hN : (1 : ℝ) ≤ |(P.normAlpha : ℝ)| := by
    rw [abs_of_neg (by exact_mod_cast hn)]
    exact_mod_cast (show (1 : ℤ) ≤ -P.normAlpha by omega)
  have hbp : (0 : ℝ) < P.b := by linarith
  have hup : (0 : ℝ) < P.u := by linarith
  have hNp : 0 < |(P.normAlpha : ℝ)| := by linarith
  have hyq := section5_tail_lower P h hn K hK (by exact_mod_cast hh.large) (hk 0)
  have hy : (98/100 : ℝ)*|(P.normAlpha : ℝ)| *(P.d : ℝ)^2*(P.u : ℝ)^6/(4*(P.b : ℝ)^2) ≤
      (P.y h.pell (k 0) : ℝ) := by
    have hc := (Rat.cast_le (K := ℝ)).mpr hyq
    push_cast at hc
    exact hc
  have hsize := (section55_size hbp hd hNp hup hh).trans hy
  obtain ⟨hall,ph,i,j,l,hij,hjl,hab,hbc,_,hl,η,hη,hfield,hmin⟩ :=
    section41_select h hn hm hK k hs ho (by have := hk 0; omega) hsize
  have h0i : (P.y h.pell (k 0) : ℝ) ≤ (P.y h.pell (k i) : ℝ) := by
    exact_mod_cast ho.monotone (Fin.zero_le i)
  have hi : k i ≠ 0 := by have := hall i; have := hK.1; omega
  have hc := (selected_case_bounds hp h hn hm (ph i) (ph j) (ph l) hi (hs i)
    (by exact_mod_cast ho hij) (by exact_mod_cast ho hjl) hl (hsize.trans h0i) hab hbc hη hfield hmin).2
  have hyi := hy.trans h0i
  rcases hc with ha | ha | ⟨n,M,hn',hM,ha⟩ | ⟨n,M,hn',hM,ha⟩
  · exact (not_lt_of_ge hyi) (ha.trans (section51_separation hbp hd hNp hup hh.first))
  · exact (not_lt_of_ge hyi) (ha.trans (section52_separation hbp hd hNp hup hh.second))
  · exact (not_lt_of_ge hyi) (ha.trans_lt (section53_separation hb hd hN hu hM (by exact_mod_cast hn') hh.third))
  · exact (not_lt_of_ge hyi) (ha.trans (section54_separation hb hd hN hu hM (by exact_mod_cast hn') (by simpa using hh.fourth)))

/-- The |Nα|=1 case of §5.5. Apply the cited theorem of Akhtari to
d z⁴ − X² = 1 at three distinct square values z². -/
private theorem section55_unit (hA : ExternalResults.AkhtariTheorem11) (P : Parameters)
    (h : P.Admissible) (hn : P.normAlpha = -1) (hm : Normalized P h.pell) (K : ℤ) :
    AtMostSquareValuesOn (P.y h.pell) (fun k => 3 ≤ k ∨ k ≤ K-2) 4 := by
  apply tail_count h K
  intro k _ hs ho
  have sol (i : Fin 5) : ∃ p : ℕ × ℕ, ExternalResults.AkhtariSolution P.d.toNat 1 p ∧
      P.y h.pell (k i) = (p.1 : ℚ)^2 := by
    obtain ⟨X,Y,hX,hY,he⟩ := P.section4_integer_coordinates h.pell (hs i)
    obtain ⟨z,hz⟩ := hs i
    have hYz : Y = z^2 := by exact_mod_cast (hY.symm.trans hz)
    have hX0 : X ≠ 0 := by
      intro heq
      exact hm.2 _ (hs i) (by simpa [heq] using hX)
    have hz0 : z ≠ 0 := by
      intro heq
      have hb := hm.1 _ (hs i)
      rw [hz,heq] at hb
      norm_num at hb
      exact h.b_pos.ne' hb
    refine ⟨(z.natAbs,X.natAbs),⟨Int.natAbs_pos.mpr hz0,Int.natAbs_pos.mpr hX0,?_⟩,?_⟩
    · change P.d.toNat*z.natAbs^4=1*X.natAbs^2+1
      apply Int.ofNat_inj.mp
      push_cast
      rw [Int.toNat_of_nonneg h.d_pos.le,
        show |z|^4=z^4 from Even.pow_abs (n := 4) (by decide) z,sq_abs]
      rw [hYz,hn] at he
      nlinarith only [he]
    · simpa [Int.natCast_natAbs,sq_abs] using hz
  choose p hp hy using sol
  have hne {i j : Fin 5} (hij : i < j) : p i ≠ p j := by
    intro heq
    have hh := ho hij
    change P.y h.pell (k i) < P.y h.pell (k j) at hh
    simp only [hy,heq,lt_self_iff_false] at hh
  rcases hA.no_three_distinct _ 1 (by have := h.d_pos; omega) (by decide)
    _ _ _ (hp 0) (hp 1) (hp 2) with ha | ha | ha
  · exact hne (by decide : (0 : Fin 5)<1) ha
  · exact hne (by decide : (0 : Fin 5)<2) ha
  · exact hne (by decide : (1 : Fin 5)<2) ha

/-- Theorem 1.8(b), with the cited inputs of JNT and Akhtari explicit. -/
theorem theorem18b (hp : Hypergeometric.DenominatorEstimate4) (hA : ExternalResults.AkhtariTheorem11)
    (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) (hm : Normalized P h.pell)
    (hb : 5 ≤ P.b) (hd : discriminantBound P ≤ (P.d : ℝ))
    (K : ℤ) (hK : P.IsNegativeCutoff h.pell K) :
    AtMostSquareValuesOn (P.y h.pell) (fun k => 3 ≤ k ∨ k ≤ K-2) 4 := by
  by_cases hu : P.normAlpha = -1
  · exact section55_unit hA P h hu hm K
  apply section55_four hp P h hn hm K hK
  apply section55_conditions (by exact_mod_cast hb) (by exact_mod_cast h.d_pos) _ (by exact_mod_cast h.u_pos) hd
  rw [abs_of_neg (by exact_mod_cast hn)]
  exact_mod_cast (show (2 : ℤ) ≤ -P.normAlpha by omega)

end AnyBAnyNorm
