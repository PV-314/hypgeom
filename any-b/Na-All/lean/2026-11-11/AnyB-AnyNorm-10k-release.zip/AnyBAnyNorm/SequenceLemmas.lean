module

public import AnyBNormSquare.Growth
public import AnyBNormSquare.Normalizer
public import AnyBNormSquare.Reused
public import «JNT-2024».GapCoefficientPublished

@[expose] public section
namespace AnyBAnyNorm
open «JNT-2024»

/-- Lemma 3.2, TeX 852–880. Specialise the cited Proposition 3.1(a) to a
unit. Both coefficient estimates concern the same witnesses as the two
equalities in FourthPowerRepresentation. The norm may have either sign. -/
theorem lemma32 (P : Parameters) [Fact (¬ IsSquare P.d)]
    [Fact (¬ IsSquare P.normAlpha)] (ha : P.a ≠ 0) (hb : 0 < P.b)
    (hp : P.Pell) (_ht : P.t ≠ 0) (hu : P.u ≠ 0)
    {x y : ℤ} (_hx : x ≠ 0) (hy : 0 < y) (hr : P.RepresentsSquare x y) :
    ∃ f r s : ℤ, f ≠ 0 ∧ P.FourthPowerRepresentation x y f r s ∧
      f ∣ 4 * P.b ^ 2 * squarefreePart P.normAlpha ∧
      0 < |(f : ℝ)| ∧
      |(f : ℝ)| ≤ 4 * (P.b : ℝ)^2 * Real.sqrt |(squarefreePart P.normAlpha : ℝ)| := by
  obtain ⟨ν, f, r, s, hν, hf, hrep, hediv, he, hsmall, hdiv⟩ :=
    P.proposition31a_published hr ha hb hy hu (P.epsilon_isIntegral hp)
  let e := P.publishedSmallFactor y
  have hfe : f ∣ 4 * P.b ^ 2 * (e : ℤ) :=
    hdiv.trans (mul_dvd_mul_left _ (P.sharpRadical_dvd_factor (P.integer_unit_norm hp hν) e))
  have hepos : (0 : ℤ) < e := by exact_mod_cast he
  have hprod : 0 < 4 * P.b ^ 2 * (e : ℤ) := by positivity
  have hfbound := Int.le_of_dvd hprod ((abs_dvd _ _).mpr hfe)
  have hroot : 1 ≤ Real.sqrt |(squarefreePart P.normAlpha : ℝ)| := by
    have hS := squarefreePart_ne_zero P.normAlpha
    have hS' : (1 : ℤ) ≤ |squarefreePart P.normAlpha| := by
      have := abs_pos.mpr hS
      omega
    exact (Real.le_sqrt (by norm_num) (abs_nonneg _)).mpr (by simpa using
      (show (1 : ℝ) ≤ |(squarefreePart P.normAlpha : ℝ)| by exact_mod_cast hS'))
  have heBound : (e : ℝ) ≤ Real.sqrt |(squarefreePart P.normAlpha : ℝ)| := by
    rcases lt_max_iff.mp hsmall with htwo | hs
    · have htwo' : e < 2 := by exact_mod_cast htwo
      have hone : e = 1 := by omega
      simpa [hone] using hroot
    · exact hs.le
  refine ⟨f, r, s, hf, hrep, hfe.trans (mul_dvd_mul_left _ hediv),
    abs_pos.mpr (by exact_mod_cast hf), ?_⟩
  calc
    |(f : ℝ)| ≤ 4 * (P.b : ℝ)^2 * e := by exact_mod_cast hfbound
    _ ≤ _ := mul_le_mul_of_nonneg_left heBound (by positivity)

/-- Lemma 3.3(a), including the cutoff defined before Theorem 1.7. -/
theorem lemma33a (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) :
    (∀ k : ℤ, ∃ n : ℤ, 0 < n ∧ 2 * P.y h.pell k = n) ∧
    StrictMono (fun n : ℕ => P.y h.pell n) ∧
    (∃! K : ℤ, P.IsNegativeCutoff h.pell K) ∧
    (∀ K : ℤ, P.IsNegativeCutoff h.pell K →
      StrictMono (fun n : ℕ => P.y h.pell (K + 1 - n))) :=
  AnyBNormSquare.lemma32a P h hn

/-- Lemma 3.3(b), TeX 898–912. LowerBoundsAtRate contains both branches of
(3.4), with seed |Nα|u²/(4b²) and negative-tail exponent max(0,K-k). -/
theorem lemma33b (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (K : ℤ) (hK : P.IsNegativeCutoff h.pell K) :
    ((P.epsilonNorm = 1 ∨ 300 ≤ P.d * P.u^2) →
      P.LowerBoundsAtRate h.pell K ((99/100 : ℚ) * P.d * (P.u : ℚ)^2)) ∧
    P.LowerBoundsAtRate h.pell K ((2/5 : ℚ) * P.d * (P.u : ℚ)^2) :=
  ⟨AnyBNormSquare.lemma32c P h hn K hK, AnyBNormSquare.lemma32c_uniform P h hn K hK⟩

/-- Lemma 3.5(a), TeX 982–1003. -/
theorem lemma35a (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) {k : ℤ}
    (hs : IsIntegerSquare (P.y h.pell k))
    (hlarge : 4 * Real.sqrt (|(P.normAlpha : ℝ)| / P.d) ≤ (P.y h.pell k : ℝ)) :
    |(P.sequenceOmega h.pell k).arg| <
        (229/100 : ℝ) * Real.sqrt |(P.normAlpha : ℝ)| / |(P.x h.pell k : ℝ)| ∧
    (229/100 : ℝ) * Real.sqrt |(P.normAlpha : ℝ)| / |(P.x h.pell k : ℝ)| < 3/5 :=
  AnyBNormSquare.lemma34 P h hn hs hlarge

/-- Lemma 3.6, with the sign of u₂ fixed by the norm of εᵏ as in [13, Lemma 3.5]. -/
theorem lemma36 (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    {k X Y : ℤ} (hk : k ≠ 0) (hx : P.x h.pell k = (X : ℚ))
    (hy : P.y h.pell k = (Y : ℚ)) :
    let S := squarefreePart P.normAlpha
    let u₁ := 2 * X
    let u₂ := 2 * AnyBNormSquare.unitPowerNorm P k * squareFactor P.normAlpha
    2 ≤ Approximation.normalizerProduct S u₁ u₂ ∧
      Approximation.normalizerProduct S u₁ u₂ ≤ 16 * Real.sqrt |(P.normAlpha : ℝ)| :=
  AnyBNormSquare.lemma35_normalizer P h hn hk hx hy

end AnyBAnyNorm
