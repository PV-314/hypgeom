module

public import AnyBAnyNorm.Section42
public import AnyBAnyNorm.ExactCase

@[expose] public section
namespace AnyBAnyNorm
open «JNT-2024» AnyBNormSquare.Case42

/-- The general nonzero-determinant upper bound from the proof of [12, (4.16)].
All factors in the norm of q, including b and the two f's, are retained. -/
theorem nonexact_upper {N d y z F M b Q c : ℝ} {p q θ : ℂ} {r : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hz : 0 < z) (hb : 0 < b)
    (hQ : 0 < Q) (hc : c < 1) (hr : 1 ≤ r) (hq : q ≠ 0)
    (hQub : Q < (2147/100 : ℝ)*Real.sqrt d*y/M)
    (hlo : (1-c)/(AnyBNormSquare.paperK0*Q^r) < ‖q*θ-p‖)
    (hup : (3959/1000 : ℝ)*‖θ-p/q‖ < 2*Real.sqrt N/(Real.sqrt d*z))
    (hfour : ‖q‖^4*b^4 = F^2*y*z) :
    z^3 < (N*F)^2*((636/1000 : ℝ)/((1-c)*b))^4*
      ((2147/100 : ℝ)/M)^(4*r)*d^(2*r-2)*y^(4*r+1) := by
  rw [error_factor hq] at hlo
  have hlo' := substitute_Q hQ hQub hc hlo
  exact expanded_bound hd hr (fourth_power hN hd hz hb hfour
    (before_fourth hN hd hz (norm_pos_iff.mpr hq) (lt_trans hQ hQub) hc hlo' hup))

/-- §4.3, (4.13)–(4.14): apply (3.6), cube the double gap, cancel y⁵,
and take the positive 22nd root, with c = 3/4. -/
theorem section43_bound {N d y z F M b : ℝ}
    (hN : 0 < N) (hd : 0 < d) (hy : 0 < y) (hb : 0 < b)
    (hF : 0 < F) (hM : 2 ≤ M) (hprod : F ≤ 16*b^4*N)
    (hupper : z^3 < (N*F)^2*((636/1000 : ℝ)/((1-3/4)*b))^4*
      ((2147/100 : ℝ)/M)^4*y^5)
    (hlower : ((1536/100 : ℝ)*(d/(16*b^2*N^2))^2)^4*y^9 < z) :
    y < (109/10 : ℝ)*b^(26/11 : ℝ)*N^(26/11 : ℝ)/d^(12/11 : ℝ) := by
  have hu := at_one hN hy hF hb hM (by norm_num : (3/4 : ℝ) < 1) hupper
  have hf := pow_le_pow_left₀ (mul_nonneg hN.le hF.le)
    (mul_le_mul_of_nonneg_left hprod hN.le) 2
  have h413 : z^3 < 560000/(1-(3/4 : ℝ))^4*N^4*b^4*y^5 := by
    apply hu.trans_le
    have hh := mul_le_mul_of_nonneg_left hf (by positivity : 0 ≤ 2180/(b*(1-(3/4 : ℝ)))^4)
    apply mul_le_mul_of_nonneg_right _ (pow_nonneg hy.le 5)
    refine hh.trans ?_
    field_simp
    nlinarith only [sq_nonneg (N^2*b^4)]
  have h22 := cancel_fifth (by positivity : 0 < (1536/100 : ℝ)*(d/(16*b^2*N^2))^2) hy hlower h413
  have hclear : (1536/100 : ℝ)^12*d^24*y^22 <
      560000*4^4*16^24*b^52*N^52 := by
    norm_num at h22
    field_simp at h22
    linarith only [h22]
  apply (pow_lt_pow_iff_left₀ hy.le (by positivity) (by decide : (22 : ℕ) ≠ 0)).mp
  rw [div_pow,mul_pow,mul_pow,← Real.rpow_mul_natCast hb.le,← Real.rpow_mul_natCast hN.le,
    ← Real.rpow_mul_natCast hd.le]
  norm_num
  apply (lt_div_iff₀ (pow_pos hd 24)).mpr
  have hround : (560000 : ℝ)*4^4*16^24 < (109/10 : ℝ)^22*(1536/100 : ℝ)^12 := by norm_num
  have hh := hclear.trans (mul_lt_mul_of_pos_right (mul_lt_mul_of_pos_right hround
    (pow_pos hb 52)) (pow_pos hN 52))
  linarith only [hh]

end AnyBAnyNorm
