module

public import AnyBAnyNorm.NonexactCase
public import AnyBNormSquare.Case44
public import AnyBNormSquare.Case45

@[expose] public section
namespace AnyBAnyNorm
open «JNT-2024»

/-- (4.17) before the target-specific estimate on f is applied. -/
theorem section45_initial {N d y z F M b : ℝ} {r : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hy : 0 < y) (hF : 0 < F) (hM : 0 < M)
    (hb : 0 < b) (hr : 1 ≤ r)
    (hl : ((8176/1000 : ℝ)*b/M)^4*(N/F)^2*(3/4 : ℝ)^4*
      ((1832/10000 : ℝ)*M/N)^(4*r)*d^(2*r)*y^(4*r-1) < z)
    (hu : z^3 < (N*F)^2*((636/1000 : ℝ)/((1-3/4)*b))^4*((2147/100 : ℝ)/M)^(4*r)*
      d^(2*r-2)*y^(4*r+1)) :
    (y^4*d^2*M^8/((592/10 : ℝ)^4*N^6))^(2*r-1) <
      F^8*(181/1000 : ℝ)*(N^2*M^4/(b^16*d^4)) := by
  have hh := AnyBNormSquare.Case44.normalized hN hd hy hF hM hb hr
    (AnyBNormSquare.Case44.combine hN hd hy hF hM hb (by norm_num) hr hl hu)
  have hpow := pow_le_pow_left₀ (by norm_num : (0 : ℝ) ≤ 12200000)
    AnyBNormSquare.Case44.rounding_constants.2.2.1.le (2*r-1)
  have hc := mul_le_mul_of_nonneg_left hpow
    (show 0 ≤ F^8*(181/1000 : ℝ)*(N^2*M^4/(b^16*d^4)) by positivity)
  rw [show y^4*d^2*M^8/((592/10 : ℝ)^4*N^6) = (y^4*d^2*M^8/N^6)/(592/10)^4 by ring,
    div_pow,div_lt_iff₀ (by positivity)]
  exact hh.trans_le hc

/-- §4.5: replace the coefficient by (4.18) and take the fourth and (2r−1)st roots,
retaining the variable-exponent expression (4.19) for the later use in §5. -/
theorem section45_root {N d y F M b : ℝ} {n : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hy : 0 < y) (hF : 0 < F) (hM : 0 < M) (hb : 0 < b)
    (hn : 0 < n) (hprod : F ≤ 16*b^4*N)
    (hh : (y^4*d^2*M^8/((592/10 : ℝ)^4*N^6))^n <
      F^8*(181/1000 : ℝ)*(N^2*M^4/(b^16*d^4))) :
    y ≤ (592/10 : ℝ)*N^(3/2 : ℝ)/(Real.sqrt d*M^2)*
      (167*b^4*N^(5/2 : ℝ)*M/d)^(1/(n : ℝ)) := by
  let B := (592/10 : ℝ)*N^(3/2 : ℝ)/(Real.sqrt d*M^2)
  let A := 167*b^4*N^(5/2 : ℝ)*M/d
  have hB : 0 < B := by dsimp [B]; positivity
  have hA : 0 < A := by dsimp [A]; positivity
  have hF8 := pow_le_pow_left₀ hF.le hprod 8
  have h418 : F^8*(181/1000 : ℝ)*(N^2*M^4/(b^16*d^4)) ≤
      b^16*(777400000*N^10*M^4/d^4) := by
    have h := mul_le_mul_of_nonneg_right hF8 (by positivity : 0 ≤ (181/1000 : ℝ)*(N^2*M^4/(b^16*d^4)))
    rw [mul_assoc]
    apply h.trans
    field_simp
    nlinarith only [show 0 ≤ b^32*N^10*M^4 by positivity]
  have hA4 : A^4 = 167^4*b^16*N^10*M^4/d^4 := by
    dsimp [A]; rw [div_pow,mul_pow,mul_pow,mul_pow,← Real.rpow_mul_natCast hN.le]
    norm_num [← pow_mul]
  have hB4 : B^4 = (592/10 : ℝ)^4*N^6/(d^2*M^8) := by
    dsimp [B]; simp only [div_pow,mul_pow,← Real.rpow_mul_natCast hN.le,← pow_mul]
    rw [show (4 : ℕ) = 2*2 by decide, pow_mul (Real.sqrt d),Real.sq_sqrt hd.le]
    norm_num
  have hu : b^16*(777400000*N^10*M^4/d^4) < A^4 := by
    rw [hA4]; field_simp
    nlinarith only [show 0 < b^16*N^10*M^4 by positivity]
  have he : (y/B)^4 = y^4*d^2*M^8/((592/10 : ℝ)^4*N^6) := by
    rw [div_pow,hB4]; field_simp
  have hh' := hh.trans (h418.trans_lt hu)
  rw [← he,← pow_mul,Nat.mul_comm, pow_mul] at hh'
  have hh'' := (pow_lt_pow_iff_left₀ (by positivity) hA.le (by decide : (4 : ℕ) ≠ 0)).mp hh'
  have hp : y/B < A^(1/(n : ℝ)) := by
    apply (pow_lt_pow_iff_left₀ (by positivity) (by positivity) hn.ne').mp
    simpa only [one_div,Real.rpow_inv_natCast_pow hA.le hn.ne'] using hh''
  exact (by simpa only [mul_comm B] using (div_lt_iff₀ hB).mp hp : y < B*A^(1/(n : ℝ))).le

/-- (4.19)–(4.21). Here n = 2r₀−1. Logarithms express the printed
multiplications, divisions and positive real powers in additive coordinates. -/
theorem section45_log_bound {N d y M b : ℝ} {n : ℕ}
    (hN : 1 ≤ N) (hd : 0 < d) (hb : 1 ≤ b) (hM : 2 ≤ M) (hy : b^2 ≤ y)
    (hn : 3 ≤ n)
    (hh : y ≤ (592/10 : ℝ)*N^(3/2 : ℝ)/(Real.sqrt d*M^2)*
      (167*b^4*N^(5/2 : ℝ)*M/d)^(1/(n : ℝ))) :
    2*(n : ℝ)*Real.log y + ((n : ℝ)+2)*Real.log d ≤
      2*n*Real.log (148/10 : ℝ)+2*Real.log 334+8*Real.log b+(3*n+5)*Real.log N := by
  have hpN : 0 < N := by linarith
  have hpb : 0 < b := by linarith
  have hpM : 0 < M := by linarith
  have hpy := (sq_pos_of_pos hpb).trans_le hy
  have hn' : (3 : ℝ) ≤ n := by exact_mod_cast hn
  have hpn : (0 : ℝ) < n := by linarith
  have h := Real.log_le_log hpy hh
  simp (disch := positivity) only [Real.log_mul,Real.log_div,Real.log_sqrt,Real.log_pow,Real.log_rpow] at h
  have hscaled := mul_le_mul_of_nonneg_left h hpn.le
  field_simp at hscaled
  have hm := Real.log_le_log (by norm_num : (0 : ℝ)<2) hM
  have hMneg := mul_le_mul_of_nonneg_left hm (show 0 ≤ 2*(n : ℝ)-1 by linarith)
  have h59 : Real.log (592/10 : ℝ) = Real.log (148/10 : ℝ)+2*Real.log 2 := by
    rw [show (592/10 : ℝ) = (148/10)*2^2 by norm_num,Real.log_mul (by norm_num) (by norm_num),
      Real.log_pow]; norm_num
  have h334 : Real.log (334 : ℝ) = Real.log 167+Real.log 2 := by
    rw [← Real.log_mul (by norm_num) (by norm_num)]; norm_num
  have h20 : 2*(n : ℝ)*Real.log y + ((n : ℝ)+2)*Real.log d ≤
      2*n*Real.log (148/10 : ℝ)+2*Real.log 334+8*Real.log b+(3*n+5)*Real.log N := by
    rw [← Real.log_div (by norm_num : (592 : ℝ) ≠ 0) (by norm_num : (10 : ℝ) ≠ 0),h59] at hscaled
    norm_num only [Nat.cast_ofNat] at hscaled
    rw [h334]
    nlinarith only [hscaled,hMneg]
  exact h20

theorem section45_bound {N d y M b : ℝ} {n : ℕ}
    (hN : 1 ≤ N) (hd : 0 < d) (hb : 1 ≤ b) (hM : 2 ≤ M) (hy : b^2 ≤ y)
    (hn : 3 ≤ n)
    (hh : y ≤ (592/10 : ℝ)*N^(3/2 : ℝ)/(Real.sqrt d*M^2)*
      (167*b^4*N^(5/2 : ℝ)*M/d)^(1/(n : ℝ))) :
    y < 260*b^(6/5 : ℝ)*N^3/d := by
  have hpN : 0 < N := by linarith
  have hpb : 0 < b := by linarith
  have hpM : 0 < M := by linarith
  have hpy := (sq_pos_of_pos hpb).trans_le hy
  have hn' : (3 : ℝ) ≤ n := by exact_mod_cast hn
  have hpn : (0 : ℝ) < n := by linarith
  have h20 := section45_log_bound hN hd hb hM hy hn hh
  have hylog := Real.log_le_log (sq_pos_of_pos hpb) hy
  rw [Real.log_pow] at hylog
  norm_num only [Nat.cast_ofNat] at hylog
  have hcancel := mul_le_mul_of_nonneg_left hylog (show 0 ≤ (n : ℝ)-2 by linarith)
  have hdy : ((n : ℝ)+2)*(Real.log d+Real.log y) ≤
      2*n*Real.log (148/10 : ℝ)+2*Real.log 334+(12-2*n)*Real.log b+(3*n+5)*Real.log N := by
    nlinarith only [h20,hcancel]
  have hbe := mul_le_mul_of_nonneg_right (show 12-2*(n : ℝ) ≤ (n+2)*(6/5) by linarith)
    (Real.log_nonneg hb)
  have hNe := mul_le_mul_of_nonneg_right (show 3*(n : ℝ)+5 ≤ (n+2)*3 by linarith)
    (Real.log_nonneg hN)
  have hc := Real.log_lt_log (by norm_num : (0 : ℝ)<(148/10)^2)
    (by norm_num : (148/10 : ℝ)^2 < 334)
  have hr := Real.log_lt_log (by norm_num : (0 : ℝ)<(148/10)^6*334^2)
    (by norm_num : (148/10 : ℝ)^6*334^2 < 260^5)
  rw [Real.log_mul (by norm_num) (by norm_num)] at hr
  simp only [Real.log_pow] at hc hr
  have hmono := mul_nonneg (show 0 ≤ (n : ℝ)-3 by linarith) (sub_nonneg.mpr hc.le)
  have hround := mul_lt_mul_of_pos_left hr (show 0 < (n : ℝ)+2 by linarith)
  have hfinal : ((n : ℝ)+2)*(Real.log d+Real.log y) <
      (n+2)*(Real.log 260+(6/5)*Real.log b+3*Real.log N) := by
    push_cast at *
    nlinarith only [hdy,hbe,hNe,hmono,hround]
  have hcanceled := (mul_lt_mul_iff_right₀ (show 0 < (n : ℝ)+2 by linarith)).mp hfinal
  apply (Real.log_lt_log_iff hpy (by positivity)).mp
  rw [Real.log_div (by positivity) hd.ne',Real.log_mul (by positivity) (by positivity),
    Real.log_mul (by norm_num) (by positivity),Real.log_rpow hpb,Real.log_pow]
  linarith only [hcanceled]

/-- Equation (4.23), before the maximum over r₀ used at the end of §4.6. -/
theorem section46_root {N d y F M b : ℝ} {n : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hb : 1 ≤ b) (hF : 0 < F) (hM : 2 ≤ M)
    (hy : b^2 ≤ y) (hn : 1 ≤ n) (hprod : F ≤ 16*b^4*N)
    (hh : (1911/10000 : ℝ)*b^4*d/(F^2*N)*
      ((2344/10000000 : ℝ)*M^4*d*y^2/N^3)^n < 1) :
    y < (6532/100 : ℝ)*N^(3/2 : ℝ)/(Real.sqrt d*M^2)*
        (1340*b^4*N^3/d)^(1/(2*(n : ℝ))) := by
  have hpb : 0 < b := by linarith
  have hpM : 0 < M := by linarith
  have hpy := (sq_pos_of_pos hpb).trans_le hy
  let A := 1340*b^4*N^3/d
  let B := (6532/100 : ℝ)*N^(3/2 : ℝ)/(Real.sqrt d*M^2)
  have hA : 0 < A := by dsimp [A]; positivity
  have hB : 0 < B := by dsimp [B]; positivity
  have hpow : ((2344/10000000 : ℝ)*M^4*d*y^2/N^3)^n < A := by
    have hden : 0 < (1911/10000 : ℝ)*b^4*d/(F^2*N) := by positivity
    have hc := (lt_div_iff₀' hden).mpr hh
    apply hc.trans_le
    have hs := pow_le_pow_left₀ hF.le hprod 2
    dsimp [A]; field_simp
    nlinarith only [hs,show 0 ≤ b^8*N^2 by positivity]
  have heB : B^2 = (6532/100 : ℝ)^2*N^3/(d*M^4) := by
    dsimp [B]; simp only [div_pow,mul_pow,← Real.rpow_mul_natCast hN.le,Real.sq_sqrt hd.le,← pow_mul]
    norm_num
  have hbase : (y/B)^2 ≤ (2344/10000000 : ℝ)*M^4*d*y^2/N^3 := by
    rw [div_pow,heB]; field_simp
    nlinarith only [show 0 ≤ y^2*M^4*d by positivity]
  have h23 : y < B*A^(1/(2*(n : ℝ))) := by
    have hh' := (pow_le_pow_left₀ (sq_nonneg _) hbase n).trans_lt hpow
    have hroot : (A^(1/(2*(n : ℝ))))^(2*n) = A := by
      rw [← Real.rpow_mul_natCast hA.le]; push_cast
      rw [one_div_mul_cancel (by positivity : (2 : ℝ)*n ≠ 0),Real.rpow_one]
    have he : y/B < A^(1/(2*(n : ℝ))) := by
      apply (pow_lt_pow_iff_left₀ (by positivity) (by positivity) (by omega : 2*n ≠ 0)).mp
      rwa [hroot,pow_mul]
    simpa only [mul_comm B] using (div_lt_iff₀ hB).mp he
  exact h23

/-- (4.22)–(4.24): apply (3.6), take the indicated roots, exclude the
base at most one, and then use r₀ = 2 for the largest remaining bound. -/
theorem section46_max {N d y M b : ℝ} {n : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hb : 1 ≤ b) (hM : 2 ≤ M)
    (hy : b^2 ≤ y) (hn : 1 ≤ n)
    (h23 : y < (6532/100 : ℝ)*N^(3/2 : ℝ)/(Real.sqrt d*M^2)*
        (1340*b^4*N^3/d)^(1/(2*(n : ℝ)))) :
    y < (1633/100 : ℝ)*N^(3/2 : ℝ)/Real.sqrt d*Real.sqrt (1340*b^4*N^3/d) := by
  have hpb : 0 < b := by linarith
  have hpM : 0 < M := by linarith
  have hpy := (sq_pos_of_pos hpb).trans_le hy
  let A := 1340*b^4*N^3/d
  let B := (6532/100 : ℝ)*N^(3/2 : ℝ)/(Real.sqrt d*M^2)
  have hA : 0 < A := by dsimp [A]; positivity
  have hB : 0 < B := by dsimp [B]; positivity
  have hBs : B ≤ (1633/100 : ℝ)*N^(3/2 : ℝ)/Real.sqrt d := by
    dsimp [B]
    rw [div_le_div_iff₀ (by positivity) (by positivity)]
    have hm : (4 : ℝ) ≤ M^2 := by nlinarith
    nlinarith only [mul_le_mul_of_nonneg_left hm (by positivity : 0 ≤ N^(3/2 : ℝ)*Real.sqrt d)]
  have hsqN : (N^(3/2 : ℝ))^2 = N^3 := by rw [← Real.rpow_mul_natCast hN.le]; norm_num
  have hAgt : 1 < A := by
    by_contra! hbad
    have hd' := (div_le_iff₀ hd).mp hbad
    have hsmall := Real.rpow_le_one hA.le hbad (by positivity : 0 ≤ 1/(2*(n : ℝ)))
    have hsmall' := (h23.trans_le ((mul_le_mul_of_nonneg_left hsmall hB.le).trans (by simpa using hBs)))
    have hs := (lt_div_iff₀ (Real.sqrt_pos.mpr hd)).mp hsmall'
    have hpow' := pow_lt_pow_left₀ hs (by positivity) (by decide : (2 : ℕ) ≠ 0)
    rw [mul_pow,Real.sq_sqrt hd.le,mul_pow,hsqN] at hpow'
    have hb2 : 1 ≤ b^2 := one_le_pow₀ hb
    have hbound : y ≤ (1633/100 : ℝ)/(Real.sqrt 1340*b^2) := by
      apply (le_div_iff₀ (by positivity)).mpr
      apply (sq_le_sq₀ (by positivity) (by norm_num)).mp
      rw [mul_pow,mul_pow,Real.sq_sqrt (by norm_num)]
      apply (mul_le_mul_iff_left₀ (pow_pos hN 3)).mp
      nlinarith only [hpow',mul_le_mul_of_nonneg_right hd' (sq_nonneg y)]
    have hsmallest : (1633/100 : ℝ)/(Real.sqrt 1340*b^2) < 1 := by
      apply (div_lt_one (by positivity)).mpr
      have hs : (1633/100 : ℝ) < Real.sqrt 1340 :=
        (Real.lt_sqrt (by norm_num)).mpr (by norm_num)
      exact hs.trans_le (le_mul_of_one_le_right (Real.sqrt_nonneg _) hb2)
    exact (not_lt_of_ge (hb2.trans hy)) (hbound.trans_lt hsmallest)
  have hn' : (1 : ℝ) ≤ n := by exact_mod_cast hn
  have hexp : 1/(2*(n : ℝ)) ≤ 1/2 := (div_le_iff₀ (by positivity)).mpr (by linarith)
  have hmax := Real.rpow_le_rpow_of_exponent_le hAgt.le hexp
  rw [← Real.sqrt_eq_rpow] at hmax
  have hmax' := h23.trans_le (mul_le_mul hBs hmax (by positivity) (by positivity))
  exact hmax'

theorem section46_bound {N d y F M b : ℝ} {n : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hb : 1 ≤ b) (hF : 0 < F) (hM : 2 ≤ M)
    (hy : b^2 ≤ y) (hn : 1 ≤ n) (hprod : F ≤ 16*b^4*N)
    (hh : (1911/10000 : ℝ)*b^4*d/(F^2*N)*
      ((2344/10000000 : ℝ)*M^4*d*y^2/N^3)^n < 1) :
    y < 598*b^2*N^3/d := by
  let A := 1340*b^4*N^3/d
  have h23 := section46_root hN hd hb hF hM hy hn hprod hh
  have hmax' := section46_max hN hd hb hM hy hn h23
  have hsqN : (N^(3/2 : ℝ))^2 = N^3 := by rw [← Real.rpow_mul_natCast hN.le]; norm_num
  have hround : (1633/100 : ℝ)*Real.sqrt 1340 < 598 := by
    apply (sq_lt_sq₀ (by positivity) (by positivity)).mp
    rw [mul_pow,Real.sq_sqrt (by norm_num)]; norm_num
  apply hmax'.trans_le
  have he : Real.sqrt A = Real.sqrt 1340*b^2*N^(3/2 : ℝ)/Real.sqrt d := by
    dsimp [A]
    rw [Real.sqrt_div (by positivity),Real.sqrt_mul (by positivity),Real.sqrt_mul (by norm_num),
      show b^4=(b^2)^2 by ring,Real.sqrt_sq (sq_nonneg _),← hsqN,Real.sqrt_sq (by positivity)]
  rw [he]
  have hround' := mul_le_mul_of_nonneg_right hround.le (by positivity : 0 ≤ b^2*N^3/d)
  convert hround' using 1
  · field_simp
    nlinarith only [hsqN,Real.sq_sqrt hd.le,
      show N^(3/2 : ℝ)*N^(3/2 : ℝ)=N^3 by rwa [← sq]]
  · ring

end AnyBAnyNorm
