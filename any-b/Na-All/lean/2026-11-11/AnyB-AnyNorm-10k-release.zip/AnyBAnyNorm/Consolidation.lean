module

public import AnyBAnyNorm.FourCases
public import Mathlib.Data.Finset.Sort

@[expose] public section
namespace AnyBAnyNorm
open «JNT-2024»

/-- §4.7: the last term of the maximum implies the auxiliary bound
256 N²/(b²d), and y ≥ b² supplies the second factor before taking square roots. -/
private theorem threshold_size {N b d y : ℝ} (hN : 1 ≤ N) (hb : 1 ≤ b) (hd : 0 < d)
    (hy : b^2 ≤ y) (hl : 598*b^2*N^3/d < y) : 16*N/Real.sqrt d ≤ y := by
  have hbp : 0 < b := by linarith
  have hNp : 0 < N := by linarith
  have hb2 : 1 ≤ b^2 := one_le_pow₀ hb
  have hypos := (sq_pos_of_pos hbp).trans_le hy
  have haux : 256*N^2/(b^2*d) ≤ y := by
    apply le_trans _ hl.le
    rw [div_le_div_iff₀ (by positivity) hd]
    have hprod := mul_le_mul (show 1 ≤ b^4 from one_le_pow₀ hb) hN (by norm_num) (by positivity)
    have hh := mul_le_mul_of_nonneg_right hprod (show 0 ≤ N^2*d by positivity)
    nlinarith only [hh,show 0 ≤ b^4*N^3*d by positivity]
  have hh := (div_le_iff₀ (mul_pos (sq_pos_of_pos hbp) hd)).mp haux
  have hmult := mul_le_mul_of_nonneg_right hy (show 0 ≤ y*d by positivity)
  apply (div_le_iff₀ (Real.sqrt_pos.mpr hd)).mpr
  apply (sq_le_sq₀ (by positivity) (by positivity)).mp
  rw [mul_pow,mul_pow,Real.sq_sqrt hd.le]
  nlinarith only [hh,hmult]

/-- The five ordered distinct values assumed at the start of §4.1 suffice
to contradict the precise threshold. -/
private theorem no_five (hPrior : Hypergeometric.DenominatorEstimate4) {P : Parameters}
    (h : P.Admissible) (hn : P.normAlpha < 0) (hm : Normalized P h.pell)
    {K : ℤ} (hK : P.IsNegativeCutoff h.pell K) (k : Fin 5 → ℤ)
    (hs : ∀ a, IsIntegerSquare (P.y h.pell (k a)))
    (ho : StrictMono (fun a => P.y h.pell (k a)))
    (hfirst : 1 ≤ k 0 ∨ k 0 ≤ K) (hbig : preciseThreshold P < (P.y h.pell (k 0) : ℝ)) : False := by
  have hN : (1 : ℝ) ≤ |(P.normAlpha : ℝ)| := by
    rw [abs_of_neg (by exact_mod_cast hn)]
    exact_mod_cast (show (1 : ℤ) ≤ -P.normAlpha by omega)
  have hsize := threshold_size hN (by exact_mod_cast h.b_pos : (1 : ℝ) ≤ P.b)
    (by exact_mod_cast h.d_pos : (0 : ℝ) < P.d)
    (show (P.b : ℝ)^2 ≤ (P.y h.pell (k 0) : ℝ) by exact_mod_cast hm.1 _ (hs 0))
    (((le_max_right _ _).trans (le_max_right _ _)).trans_lt hbig)
  obtain ⟨hall,ph,i,j,l,hij,hjl,hab,hbc,_,hl,η,hη,hfield,hmin⟩ :=
    section41_select h hn hm hK k hs ho hfirst hsize
  have h0i : (P.y h.pell (k 0) : ℝ) ≤ (P.y h.pell (k i) : ℝ) := by
    exact_mod_cast ho.monotone (Fin.zero_le i)
  have hi : k i ≠ 0 := by have := hall i; have := hK.1; omega
  have hup := selected_four_cases hPrior h hn hm (ph i) (ph j) (ph l) hi (hs i)
    (by exact_mod_cast ho hij) (by exact_mod_cast ho hjl) hl (hsize.trans h0i) hab hbc hη hfield hmin
  exact (not_lt_of_ge h0i) (hup.trans hbig)

/-- Proposition 4.1 of 07c, under the cited external arithmetic input. -/
theorem proposition41 (hPrior : Hypergeometric.DenominatorEstimate4) : Proposition41 := by
  classical
  intro P h hn hm K hK
  let V : Set ℚ := {v | ∃ k : ℤ, (1 ≤ k ∨ k ≤ K) ∧ preciseThreshold P < (P.y h.pell k : ℝ) ∧
    IsIntegerSquare (P.y h.pell k) ∧ P.y h.pell k = v}
  have hno (s : Finset ℚ) (hs : (s : Set ℚ) ⊆ V) (hc : s.card = 5) : False := by
    have hmem (a : Fin 5) := hs (s.orderEmbOfFin_mem hc a)
    choose k hcut hsize hsq he using hmem
    apply no_five hPrior h hn hm hK k hsq _ (hcut 0) (hsize 0)
    intro a b hab
    change P.y h.pell (k a) < P.y h.pell (k b)
    rw [he,he]
    exact (s.orderEmbOfFin hc).strictMono hab
  have hfin : V.Finite := by
    by_contra! hinf
    obtain ⟨s,hs,hc⟩ := hinf.exists_subset_card_eq 5
    exact hno s hs hc
  refine ⟨hfin.toFinset,?_,?_⟩
  · by_contra! hh
    obtain ⟨s,hs,hc⟩ := Finset.exists_subset_card_eq (by omega : 5 ≤ hfin.toFinset.card)
    exact hno s (fun _ ha => hfin.mem_toFinset.mp (hs ha)) hc
  · rintro k ⟨hcut,hsize⟩ hs
    exact hfin.mem_toFinset.mpr ⟨k,hcut,hsize,hs,rfl⟩

/-- The last paragraph of §4.7 compares each term of Proposition 4.1 with
the single cutoff in Theorem 1.7. -/
theorem theorem17 (hPrior : Hypergeometric.DenominatorEstimate4) : Theorem17 := by
  intro P h hn hm K hK
  obtain ⟨s,hcard,hcover⟩ := proposition41 hPrior P h hn hm K hK
  refine ⟨s,hcard,?_⟩
  rintro k ⟨hk,hl⟩ hs
  apply hcover k ⟨hk,lt_of_le_of_lt _ hl⟩ hs
  have hb : (1 : ℝ) ≤ P.b := by exact_mod_cast h.b_pos
  have hd : (1 : ℝ) ≤ P.d := by exact_mod_cast h.d_pos
  have hN : (1 : ℝ) ≤ |(P.normAlpha : ℝ)| := by
    rw [abs_of_neg (by exact_mod_cast hn)]
    exact_mod_cast (show (1 : ℤ) ≤ -P.normAlpha by omega)
  have hterm (C p q v : ℝ) (hC : 0 ≤ C) (hC' : C ≤ 598) (hp : p ≤ 8/3) (hq : q ≤ 3) (hv : 1 ≤ v) :
      C*(P.b : ℝ)^p*|(P.normAlpha : ℝ)|^q/(P.d : ℝ)^v ≤ largeThreshold P := by
    have hnum := mul_le_mul
      (mul_le_mul hC' (Real.rpow_le_rpow_of_exponent_le hb hp) (by positivity) (by norm_num))
      (Real.rpow_le_rpow_of_exponent_le hN hq) (by positivity) (by positivity)
    have hden := Real.rpow_le_rpow_of_exponent_le hd hv
    rw [Real.rpow_one] at hden
    unfold largeThreshold
    apply div_le_div₀ (by positivity) _ (by exact_mod_cast h.d_pos) hden
    norm_num at hnum ⊢
    exact hnum
  apply max_le (hterm _ _ _ _ (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num))
  apply max_le (hterm _ _ _ _ (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num))
  simpa using hterm 598 2 3 1 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)

end AnyBAnyNorm
