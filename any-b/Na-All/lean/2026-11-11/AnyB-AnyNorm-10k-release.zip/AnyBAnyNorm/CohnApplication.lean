module
public import AnyBAnyNorm.Cohn
public import «JNT-2024».SquarefreePart

@[expose] public section
namespace AnyBAnyNorm
open «JNT-2024»

/-- PDF page 9: equation (3.1) excludes the Cohn root 13, for either unit norm. -/
theorem cohn_root13_excluded (t ν : ℤ) (hν : ν = 1 ∨ ν = -1) :
    t^2 ≠ 2*13^2+2*ν := by
  rcases hν with rfl | rfl
  · intro h
    have hsplit : t ≤ -19 ∨ (-18 ≤ t ∧ t ≤ 18) ∨ 19 ≤ t := by omega
    rcases hsplit with ht | ⟨ht,ht'⟩ | ht
    · nlinarith [sq_nonneg (t+19)]
    · nlinarith [mul_nonneg (by omega : 0 ≤ t+18) (by omega : 0 ≤ 18-t)]
    · nlinarith [sq_nonneg (t-19)]
  · intro h
    have hsplit : t ≤ -19 ∨ (-18 ≤ t ∧ t ≤ 18) ∨ 19 ≤ t := by omega
    rcases hsplit with ht | ⟨ht,ht'⟩ | ht
    · nlinarith [sq_nonneg (t+19)]
    · nlinarith [mul_nonneg (by omega : 0 ≤ t+18) (by omega : 0 ≤ 18-t)]
    · nlinarith [sq_nonneg (t-19)]

/-- Page 9: the half-product t_k u_k / 2 is a positive integer, and the
two displayed quadratic identities give the quartic equation. -/
theorem cohn_quartic_from_coordinates (d z t u ν : ℤ)
    (ht : 0 < t) (hu : 0 < u) (hν : ν = 1 ∨ ν = -1)
    (hminus : t^2-d*u^2 = 4*ν) (hplus : t^2+d*u^2 = 4*z^2) :
    ∃ w : ℤ, 0 < w ∧ 2*w = t*u ∧ z^4-d*w^2 = 1 ∧
      t^2 = 2*z^2+2*ν := by
  have hid : t^2 = 2*z^2+2*ν := by linarith only [hminus, hplus]
  have heven : Even t := by
    have he : Even (t*t) := ⟨z^2+ν,by nlinarith [hid]⟩
    exact (Int.even_mul.mp he).elim id id
  obtain ⟨v,hv⟩ := heven
  have hvpos : 0 < v := by omega
  refine ⟨v*u,mul_pos hvpos hu,by rw [hv]; ring,?_,hid⟩
  have hdu : d*u^2 = 2*z^2-2*ν := by linarith only [hplus, hid]
  have hνsq : ν^2=1 := by rcases hν with rfl | rfl <;> norm_num
  -- TeX 786–798: multiply the two isolated identities, then use ν² = 1.
  have hprod : d*t^2*u^2 = 4*(z^4-1) := calc
    d*t^2*u^2 = t^2 * (d*u^2) := by ring
    _ = (2*z^2+2*ν) * (2*z^2-2*ν) := by rw [hid, hdu]
    _ = 4*z^4 - 4*ν^2 := by ring
    _ = 4*(z^4-1) := by rw [hνsq]; ring
  rw [hv] at hprod
  nlinarith only [hprod]

/-- The printed reduction from nonsquare d to its squarefree part. -/
theorem cohn_squarefree_reduction {d z w : ℤ} (hd : 0 < d)
    (hds : ¬ IsSquare d) (_hz : 0 < z) (hw : 0 < w)
    (he : z^4-d*w^2=1) :
    1 < squarefreePart d ∧
    0 < squareFactor d*w ∧
    z^4=squarefreePart d*(squareFactor d*w)^2+1 := by
  have hf := squareFactor_pos (ne_of_gt hd)
  have hid := squareFactor_sq_mul d
  have hs : 0 < squarefreePart d := by
    by_contra hh
    have := mul_nonpos_of_nonneg_of_nonpos (sq_nonneg (squareFactor d)) (by omega : squarefreePart d ≤ 0)
    omega
  have hs1 : squarefreePart d ≠ 1 := by
    intro h
    apply hds
    refine ⟨squareFactor d,?_⟩
    simpa [h,pow_two] using hid.symm
  refine ⟨by omega,mul_pos hf hw,?_⟩
  calc
    z^4 = d*w^2+1 := by omega
    _ = squarefreePart d*(squareFactor d*w)^2+1 := by nth_rw 1 [← hid]; ring

/-- Cohn's two cases, including elimination of z=13, give uniqueness of the
noninitial square root. The Cohn theorem is an explicit external input. -/
theorem cohn_noninitial_root_unique (hCohn : ExternalResults.CohnTheorem)
    {d z z' t t' w w' ν ν' : ℤ}
    (hd : 0 < d) (hds : ¬ IsSquare d) (hz : 1 < z) (hz' : 1 < z')
    (hw : 0 < w) (hw' : 0 < w')
    (he : z^4-d*w^2=1) (he' : z'^4-d*w'^2=1)
    (hν : ν=1 ∨ ν= -1) (hν' : ν'=1 ∨ ν'= -1)
    (ht : t^2=2*z^2+2*ν) (ht' : t'^2=2*z'^2+2*ν') : z=z' := by
  obtain ⟨hD,hW,hEq⟩ := cohn_squarefree_reduction hd hds (by omega) hw he
  obtain ⟨_,hW',hEq'⟩ := cohn_squarefree_reduction hd hds (by omega) hw' he'
  let D := (squarefreePart d).toNat
  have hDc : (D : ℤ)=squarefreePart d := Int.toNat_of_nonneg (by omega)
  have hDs : Squarefree D := Int.squarefree_natCast.mp (by rw [hDc]; exact squarefreePart_squarefree d)
  have hDn : 1 < D := by exact_mod_cast (show (1:ℤ)<(D:ℤ) by rw [hDc]; exact hD)
  have hzcast : (z.toNat : ℤ)=z := Int.toNat_of_nonneg (by omega)
  have hzcast' : (z'.toNat : ℤ)=z' := Int.toNat_of_nonneg (by omega)
  have hWcast : ((squareFactor d*w).toNat : ℤ)=squareFactor d*w := Int.toNat_of_nonneg hW.le
  have hWcast' : ((squareFactor d*w').toNat : ℤ)=squareFactor d*w' := Int.toNat_of_nonneg hW'.le
  have heN : z.toNat^4=D*(squareFactor d*w).toNat^2+1 := by
    exact_mod_cast (show (z.toNat:ℤ)^4=(D:ℤ)*((squareFactor d*w).toNat:ℤ)^2+1 by rwa [hzcast,hDc,hWcast])
  have heN' : z'.toNat^4=D*(squareFactor d*w').toNat^2+1 := by
    exact_mod_cast (show (z'.toNat:ℤ)^4=(D:ℤ)*((squareFactor d*w').toNat:ℤ)^2+1 by rwa [hzcast',hDc,hWcast'])
  by_cases hex : D=1785
  · have one_root : ∀ Z T W V : ℤ, 1<Z → 0<W →
        V=1 ∨ V= -1 → T^2=2*Z^2+2*V → Z^4=1785*W^2+1 → Z=239 := by
      intro Z T W V hZ hW hV hT hE
      have hZn : (Z.toNat : ℤ)=Z := Int.toNat_of_nonneg (by omega)
      have hWn : (W.toNat : ℤ)=W := Int.toNat_of_nonneg hW.le
      have hEn : Z.toNat^4=1785*W.toNat^2+1 := by exact_mod_cast (show (Z.toNat:ℤ)^4=1785*(W.toNat:ℤ)^2+1 by rwa [hZn,hWn])
      rcases hCohn.exceptional Z.toNat W.toNat (by omega) (by omega) hEn with hh | hh
      · have h13 : Z=13 := by omega
        exact False.elim (cohn_root13_excluded T V hV (by simpa [h13] using hT))
      · omega
    have hD1785 : squarefreePart d=1785 := by rw [← hDc,hex]; norm_num
    have ha := one_root z t (squareFactor d*w) ν hz hW hν ht (by simpa [hD1785] using hEq)
    have hb := one_root z' t' (squareFactor d*w') ν' hz' hW' hν' ht' (by simpa [hD1785] using hEq')
    omega
  · have hh := (hCohn.unique D hDs hDn hex z.toNat (squareFactor d*w).toNat
        z'.toNat (squareFactor d*w').toNat (by omega) (by omega) (by omega) (by omega) heN heN').1
    omega

end AnyBAnyNorm
