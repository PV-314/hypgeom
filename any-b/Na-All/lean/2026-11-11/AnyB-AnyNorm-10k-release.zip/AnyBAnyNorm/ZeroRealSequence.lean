module
public import AnyBAnyNorm.CohnApplication
public import «JNT-2024».SequenceRepresentations
public import «JNT-2024».Section46OrbitPublished
public import «JNT-2024».PaperBridge
public import AnyBNormSquare.Targets

@[expose] public section
namespace AnyBAnyNorm
open «JNT-2024» «JNT-2024».Parameters

/-- With a=0, multiplication by alpha leaves b² times the real part of ε^(2n). -/
theorem zero_y_nat (P : Parameters) (hp : P.Pell) (ha : P.a=0) (n : ℕ) :
    P.y hp (n : ℤ)=(P.b : ℚ)^2*(P.epsilon^(2*n)).re := by
  simp [y,P.term_nat,alpha,ha]

/-- PDF page 8: conjugating an even power proves the reflection y_(-n)=y_n. -/
theorem zero_y_neg_nat (P : Parameters) (hp : P.Pell) (ha : P.a=0) (n : ℕ) :
    P.y hp (-(n : ℤ))=P.y hp (n : ℤ) := by
  rw [zero_y_nat P hp ha]
  unfold y
  rw [P.term_neg_nat]
  simp only [QuadraticAlgebra.im_mul,alpha,ha,Int.cast_zero,zero_mul,zero_add]
  rw [← star_pow,QuadraticAlgebra.re_star,← pow_mul,Nat.mul_comm n 2]
  simp

/-- Positivity of the real unit in the paper. No positivity of a is assumed. -/
theorem zero_real_unit_gt_one (P : Parameters) (hd : 0<P.d)
    (hds : ¬ IsSquare P.d) (ht : 0<P.t) (hu : 0<P.u) : 1<P.realEpsilon := by
  have hd2 : 2≤P.d := by
    by_contra hh
    have he : P.d=1 := by omega
    exact hds (he ▸ IsSquare.one)
  have hroot : 1<P.root := by
    unfold root
    exact (Real.lt_sqrt (by norm_num)).mpr (by exact_mod_cast (show (1:ℤ)<P.d by omega))
  have htq : (1:ℝ)≤P.t := by exact_mod_cast ht
  have huq : (1:ℝ)≤P.u := by exact_mod_cast hu
  unfold realEpsilon
  nlinarith [mul_nonneg (sub_nonneg.mpr huq) (show 0≤P.root by linarith)]

/-- Evaluate a unit power at the two real embeddings. The sum and difference
give exactly the printed half-integer coordinates. -/
theorem zero_power_embeddings (P : Parameters) (hd : 0<P.d) (n : ℕ) :
    ((P.epsilon^n).re : ℝ)+(P.epsilon^n).im*P.root=P.realEpsilon^n ∧
    ((P.epsilon^n).re : ℝ)-(P.epsilon^n).im*P.root=P.realEpsilonConj^n := by
  have hr : P.root^2=(P.d : ℝ) := Real.sq_sqrt (by exact_mod_cast hd.le)
  have h := (P.evalAt P.root hr).map_pow P.epsilon n
  have h' := (P.evalAt (-P.root) (by simpa using hr)).map_pow P.epsilon n
  have he : (P.evalAt P.root hr) P.epsilon=P.realEpsilon := P.evalAt_epsilon P.root hr
  have he' : (P.evalAt (-P.root) (by simpa using hr)) P.epsilon=P.realEpsilonConj := by
    rw [P.evalAt_epsilon]
    simp [realEpsilonConj]
    ring
  rw [he] at h
  rw [he'] at h'
  constructor
  · exact h
  · change ((P.epsilon^n).re : ℝ)+(P.epsilon^n).im*(-P.root)=_ at h'
    simpa only [mul_neg,← sub_eq_add_neg] using h'

/-- The conjugate has absolute value ε^(-1), as used on PDF pages 8–9. -/
theorem zero_unit_conjugate_abs (P : Parameters) (hp : P.Pell)
    (hd : 0<P.d) (hds : ¬ IsSquare P.d) (ht : 0<P.t) (hu : 0<P.u) :
    |P.realEpsilonConj|=P.realEpsilon⁻¹ := by
  let Q : Parameters := { P with a:=1,b:=1 }
  have hQ : Q.Admissible := ⟨by norm_num [Q],by norm_num [Q],hd,ht,hu,hds,hp⟩
  have he : P.realEpsilon*P.realEpsilonConj=(P.epsilonNorm : ℝ) := Q.realEpsilon_mul_conj hQ
  have hnorm : |(P.epsilonNorm : ℝ)|=1 := by
    rcases P.pell_iff_epsilonNorm.mp hp with h | h <;> simp [h]
  have hpos := zero_real_unit_gt_one P hd hds ht hu
  have habs := congrArg abs he
  rw [abs_mul,abs_of_pos (by linarith : 0<P.realEpsilon),hnorm] at habs
  apply mul_left_cancel₀ (show P.realEpsilon≠0 by linarith)
  rw [mul_inv_cancel₀ (by linarith : P.realEpsilon≠0)]
  exact habs

/-- PDF page 8: y_n=b²(ε^(2n)+ε^(-2n))/2 and y_n>b² for n>0. -/
theorem zero_y_gt_initial (P : Parameters) (hp : P.Pell) (ha : P.a=0)
    (hb : 0<P.b) (hd : 0<P.d) (hds : ¬ IsSquare P.d)
    (ht : 0<P.t) (hu : 0<P.u) {n : ℕ} (hn : 0<n) :
    (P.b : ℚ)^2<P.y hp (n : ℤ) := by
  have hE := zero_real_unit_gt_one P hd hds ht hu
  have hEc := zero_unit_conjugate_abs P hp hd hds ht hu
  have hpE : 1<P.realEpsilon^(2*n) := one_lt_pow₀ hE (by omega)
  have hprod : P.realEpsilon^(2*n)*P.realEpsilonConj^(2*n)=1 := by
    have heven : P.realEpsilonConj^(2*n)=|P.realEpsilonConj|^(2*n) := by
      simp [pow_mul,sq_abs]
    rw [heven,hEc,inv_pow,mul_inv_cancel₀ (by positivity)]
  have hsum : 2<P.realEpsilon^(2*n)+P.realEpsilonConj^(2*n) := by
    by_contra hh
    have hm := mul_nonneg (le_of_lt (lt_trans (by norm_num : (0:ℝ)<1) hpE))
      (sub_nonneg.mpr (le_of_not_gt hh))
    nlinarith [sq_pos_of_ne_zero (by linarith : P.realEpsilon^(2*n)-1≠0)]
  obtain ⟨hplus,hminus⟩ := zero_power_embeddings P hd (2*n)
  have hre : 1<((P.epsilon^(2*n)).re : ℝ) := by linarith
  have hreq : (1:ℚ)<(P.epsilon^(2*n)).re := by exact_mod_cast hre
  rw [zero_y_nat P hp ha]
  nlinarith [mul_pos (sq_pos_of_pos (show (0:ℚ)<P.b by exact_mod_cast hb)) (sub_pos.mpr hreq)]

/-- The trace integrality and denominator argument on PDF page 8. -/
theorem zero_square_scaled_root (P : Parameters) [Fact (¬ IsSquare P.d)]
    (hp : P.Pell) (ha : P.a=0) (hb : 0<P.b) {n : ℕ}
    (hlarge : (P.b : ℚ)^2<P.y hp (n : ℤ))
    (hs : IsIntegerSquare (P.y hp (n : ℤ))) :
    ∃ z : ℤ, 1<z ∧ P.y hp (n : ℤ)=(P.b : ℚ)^2*(z : ℚ)^2 := by
  obtain ⟨v,hv⟩ := hs
  have hbq : (P.b : ℚ)≠0 := by exact_mod_cast (ne_of_gt hb)
  obtain ⟨T,hT⟩ := P.twice_re_integer ((P.epsilon_isIntegral hp).pow (2*n))
  have htrace : 2*((v : ℚ)/P.b)^2=(T : ℚ) := by
    have hy := zero_y_nat P hp ha n
    rw [hv] at hy
    field_simp
    nlinarith [hy,hT]
  obtain ⟨z,hz⟩ := integer_root_of_two_mul_sq ((v : ℚ)/P.b) ⟨T,htrace⟩
  have hy : P.y hp (n : ℤ)=(P.b : ℚ)^2*(z : ℚ)^2 := by
    rw [hv,← hz]
    field_simp
  refine ⟨|z|,?_,by simpa using hy⟩
  have hz2 : (1:ℚ)<(z : ℚ)^2 := by
    by_contra hh
    have := mul_le_mul_of_nonneg_left (le_of_not_gt hh) (sq_nonneg (P.b : ℚ))
    nlinarith [hy]
  have hzz : (1:ℤ)<z^2 := by exact_mod_cast hz2
  have hh := sq_abs z
  have hn := abs_nonneg z
  nlinarith

/-- Page 9: the half-integer coordinates of ε^n are positive for n>0.
Integrality is the reused two-step unit recurrence; positivity uses the two
real embeddings and |conjugate ε|=ε^(-1), exactly as printed. -/
theorem zero_positive_unit_coordinates (P : Parameters) (hp : P.Pell)
    (hd : 0<P.d) (hds : ¬ IsSquare P.d) (ht : 0<P.t) (hu : 0<P.u)
    {n : ℕ} (hn : 0<n) :
    ∃ T U : ℤ, 0<T ∧ 0<U ∧ 2*(P.epsilon^n).re=T ∧ 2*(P.epsilon^n).im=U := by
  obtain ⟨T,U,hT,hU⟩ := P.epsilon_power_half_integral hp n
  have hE := zero_real_unit_gt_one P hd hds ht hu
  have hEc := zero_unit_conjugate_abs P hp hd hds ht hu
  have hEp : 1<P.realEpsilon^n := one_lt_pow₀ hE (by omega)
  have hCp : |P.realEpsilonConj^n|<1 := by
    rw [abs_pow]
    exact pow_lt_one₀ (abs_nonneg _) (by rw [hEc]; exact inv_lt_one_of_one_lt₀ hE) (by omega)
  obtain ⟨hplus,hminus⟩ := zero_power_embeddings P hd n
  have hTr : 2*((P.epsilon^n).re : ℝ)=(T : ℝ) := by exact_mod_cast hT
  have hUr : 2*((P.epsilon^n).im : ℝ)=(U : ℝ) := by exact_mod_cast hU
  have hroot : 0<P.root := Real.sqrt_pos.mpr (by exact_mod_cast hd)
  have hTpos : (0:ℝ)<T := by linarith [(abs_lt.mp hCp).1]
  have hUpos : (0:ℝ)<U := by
    by_contra hh
    have him : ((P.epsilon^n).im : ℝ)≤0 := by linarith
    have hm := mul_nonpos_of_nonpos_of_nonneg him hroot.le
    linarith [(abs_lt.mp hCp).2]
  exact ⟨T,U,by exact_mod_cast hTpos,by exact_mod_cast hUpos,hT,hU⟩

/-- The norm and expansion identities on page 9, followed by the printed
parity and multiplication argument. No quartic classification is assumed here. -/
theorem zero_square_quartic (P : Parameters) [Fact (¬ IsSquare P.d)]
    (hp : P.Pell) (ha : P.a=0) (hb : 0<P.b) (hd : 0<P.d)
    (ht : 0<P.t) (hu : 0<P.u) {n : ℕ} (hn : 0<n)
    (hs : IsIntegerSquare (P.y hp (n : ℤ))) :
    ∃ z T w ν : ℤ, 1<z ∧ 0<w ∧ (ν=1 ∨ ν= -1) ∧
      P.y hp (n : ℤ)=(P.b : ℚ)^2*(z : ℚ)^2 ∧
      z^4-P.d*w^2=1 ∧ T^2=2*z^2+2*ν := by
  have hds : ¬ IsSquare P.d := Fact.out
  obtain ⟨z,hz,hy⟩ := zero_square_scaled_root P hp ha hb
    (zero_y_gt_initial P hp ha hb hd hds ht hu hn) hs
  obtain ⟨T,U,hTpos,hUpos,hT,hU⟩ := zero_positive_unit_coordinates P hp hd hds ht hu hn
  obtain ⟨ν₀,hν₀,hνcast⟩ : ∃ ν₀ : ℤ, (ν₀=1 ∨ ν₀= -1) ∧ (ν₀ : ℚ)=P.epsilonNorm := by
    rcases P.pell_iff_epsilonNorm.mp hp with he | he
    · exact ⟨1,Or.inl rfl,by simpa using he.symm⟩
    · exact ⟨-1,Or.inr rfl,by simpa using he.symm⟩
  let ν := ν₀^n
  have hνsq : ν^2=1 := by
    dsimp [ν]
    rw [← pow_mul,Nat.mul_comm n 2,pow_mul]
    have hh : ν₀^2=1 := by rcases hν₀ with rfl | rfl <;> norm_num
    simp [hh]
  have hν : ν=1 ∨ ν= -1 := sq_eq_one_iff.mp hνsq
  have hnorm : QuadraticAlgebra.norm (P.epsilon^n)=(ν : ℚ) := by
    rw [map_pow,P.norm_epsilon,← hνcast]
    simp [ν]
  have hminusQ : (T : ℚ)^2-P.d*(U : ℚ)^2=4*ν := by
    rw [← hT,← hU]
    have hh : (P.epsilon^n).re*(P.epsilon^n).re-P.d*(P.epsilon^n).im*(P.epsilon^n).im=(ν : ℚ) := by
      simpa [QuadraticAlgebra.norm] using hnorm
    nlinarith only [hh]
  have hre : (P.epsilon^(2*n)).re=(z : ℚ)^2 := by
    have hy' := zero_y_nat P hp ha n
    have hbq : (P.b : ℚ)^2≠0 := pow_ne_zero 2 (by exact_mod_cast (ne_of_gt hb))
    exact mul_left_cancel₀ hbq (hy'.symm.trans hy)
  have hplusQ : (T : ℚ)^2+P.d*(U : ℚ)^2=4*(z : ℚ)^2 := by
    rw [Nat.mul_comm 2 n,pow_mul,pow_two] at hre
    simp only [QuadraticAlgebra.re_mul] at hre
    rw [← hT,← hU]
    nlinarith only [hre]
  have hminus : T^2-P.d*U^2=4*ν := by exact_mod_cast hminusQ
  have hplus : T^2+P.d*U^2=4*z^2 := by exact_mod_cast hplusQ
  obtain ⟨w,hw,_,hquart,hid⟩ := cohn_quartic_from_coordinates P.d z T U ν hTpos hUpos hν hminus hplus
  exact ⟨z,T,w,ν,hz,hw,hν,hy,hquart,hid⟩

/-- There is at most one distinct positive-index square, following Cohn's
ordinary and exceptional cases in the printed proof of Lemma 3.1. -/
theorem zero_noninitial_square_unique (hCohn : ExternalResults.CohnTheorem)
    (P : Parameters) [Fact (¬ IsSquare P.d)] (hp : P.Pell)
    (ha : P.a=0) (hb : 0<P.b) (hd : 0<P.d) (ht : 0<P.t) (hu : 0<P.u)
    {n m : ℕ} (hn : 0<n) (hm : 0<m)
    (hs : IsIntegerSquare (P.y hp (n : ℤ))) (hs' : IsIntegerSquare (P.y hp (m : ℤ))) :
    P.y hp (n : ℤ)=P.y hp (m : ℤ) := by
  obtain ⟨z,T,w,ν,hz,hw,hν,hy,he,hT⟩ := zero_square_quartic P hp ha hb hd ht hu hn hs
  obtain ⟨z',T',w',ν',hz',hw',hν',hy',he',hT'⟩ := zero_square_quartic P hp ha hb hd ht hu hm hs'
  have hh := cohn_noninitial_root_unique hCohn hd Fact.out hz hz' hw hw' he he' hν hν' hT hT'
  rw [hy,hy',hh]

/-- Literal Lemma 3.1, PDF pages 8–9, with the cited Cohn result explicit.
The endpoint counts distinct integer square values over all integer indices. -/
theorem lemma31 (hCohn : ExternalResults.CohnTheorem) (P : Parameters)
    [Fact (¬ IsSquare P.d)] (hp : P.Pell) (ha : P.a=0)
    (hb : 0<P.b) (hd : 0<P.d) (ht : 0<P.t) (hu : 0<P.u) :
    AnyBNormSquare.AtMostSquareValuesOn (P.y hp) (fun _ => True) 2 := by
  classical
  have reflect (k : ℤ) : P.y hp k = P.y hp (k.natAbs : ℤ) := by
    rcases le_total 0 k with hk | hk
    · simp [abs_of_nonneg hk]
    · rw [Int.eq_neg_natAbs_of_nonpos hk]
      simpa using zero_y_neg_nat P hp ha k.natAbs
  by_cases hex : ∃ n : ℕ, 0 < n ∧ IsIntegerSquare (P.y hp (n : ℤ))
  · obtain ⟨n, hn, hs⟩ := hex
    refine ⟨{(P.b : ℚ)^2, P.y hp (n : ℤ)}, (Finset.card_insert_le _ _).trans (by simp), ?_⟩
    intro k _ hk
    rw [reflect k] at hk ⊢
    by_cases hzero : k.natAbs = 0
    · simp [hzero]
    · exact Finset.mem_insert_of_mem (Finset.mem_singleton.mpr
        (zero_noninitial_square_unique hCohn P hp ha hb hd ht hu
          (Nat.pos_of_ne_zero hzero) hn hk hs))
  · refine ⟨{(P.b : ℚ)^2}, by simp, ?_⟩
    intro k _ hk
    rw [reflect k] at hk ⊢
    have hzero : k.natAbs = 0 := by
      by_contra hne
      exact hex ⟨_, Nat.pos_of_ne_zero hne, hk⟩
    simp [hzero]

/-- The exact ring-of-integers unit and real defining equation from the PDF,
transported through the existing faithful number-field/sequence bridges. -/
theorem lemma31_paper (hCohn : ExternalResults.CohnTheorem) (P : Parameters)
    [Fact (¬ IsSquare P.d)] (ha : P.a=0) (hb : 0<P.b) (hd : 0<P.d)
    (ht : 0<P.t) (hu : 0<P.u) (hunit : P.IsRealIntegerUnit)
    (X Y : ℤ → ℚ)
    (hs : ∀ k : ℤ, (X k : ℝ)+Y k*P.root=P.realAlpha*P.realEpsilon^(2*k)) :
    AnyBNormSquare.AtMostSquareValuesOn Y (fun _ => True) 2 := by
  let hp := (P.pell_iff_realIntegerUnit hd).mpr hunit
  have hy : Y=P.y hp := funext (fun k => (P.coordinates_unique hd hp k (X k) (Y k) (hs k)).2)
  rw [hy]
  exact lemma31 hCohn P hp ha hb hd ht hu

end AnyBAnyNorm
