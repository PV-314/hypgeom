module

public import «JNT-2024».ImaginaryQuadraticApproximation

@[expose] public section

namespace AnyBAnyNorm
open «JNT-2024» «JNT-2024».Approximation

/-- The literal conclusion, including the least positive cutoff index and both
strict estimates. -/
def ApproximationConclusion (θ p q : ℂ) (pr qr : ℕ → ℂ)
    (k₀ ℓ₀ E Q c : ℝ) (hE : 1 < E) (hc : 0 < c) : Prop :=
  let r₀ := firstIndex (Q := Q) (ℓ := ℓ₀) hE hc q
  IsLeast {r : ℕ | 0 < r ∧ (Q - 1/E)*ℓ₀*‖q‖/(Q-1) < c*E^r} r₀ ∧
    (1-c/E)/(k₀*Q^(r₀+1)) < ‖q*θ-p‖ ∧
    (p*qr r₀ ≠ q*pr r₀ → (1-c)/(k₀*Q^r₀) < ‖q*θ-p‖)

/-- In an imaginary quadratic field the two embeddings are conjugate.
Their product is the field norm appearing in the proof of Lemma 2.1. -/
theorem imaginary_quadratic_norm {K : Type*} [Field K] [NumberField K]
    [NumberField.IsTotallyComplex K] (hdegree : Module.finrank ℚ K = 2)
    (f : K →+* ℂ) (a : K) : (Algebra.norm ℚ a : ℝ) = ‖f a‖^2 := by
  classical
  let g := NumberField.ComplexEmbedding.conjugate f
  have hfg : f ≠ g := fun he => NumberField.IsTotallyComplex.complexEmbedding_not_isReal f
    (NumberField.ComplexEmbedding.isReal_iff.mpr he.symm)
  have hall : ({f, g} : Finset (K →+* ℂ)) = Finset.univ := by
    apply Finset.eq_of_subset_of_card_le (Finset.subset_univ _)
    simp [Finset.card_univ, NumberField.Embeddings.card, hdegree, hfg]
  have hprod := Algebra.norm_eq_prod_embeddings ℚ ℂ a
  rw [← Fintype.prod_equiv (RingHom.equivRatAlgHom K ℂ)
    (fun φ => φ a) (fun φ => φ a) (fun _ => rfl), ← hall] at hprod
  simp only [Finset.prod_insert (by simpa using hfg : f ∉ ({g} : Finset _)),
    Finset.prod_singleton] at hprod
  rw [show g a = _ from NumberField.ComplexEmbedding.conjugate_coe_eq f a,
    Complex.mul_conj'] at hprod
  change ((Algebra.norm ℚ a : ℚ) : ℂ) = _ at hprod
  rw [← Complex.ofReal_pow, ← Complex.ofReal_ratCast] at hprod
  exact congrArg Complex.re hprod

/-- For a nonzero determinant z whose square descends to a, the integer
norm of a equals |z|⁴. Its positivity gives the lower bound one. -/
theorem descended_square_norm {K L : Type*} [Field K] [NumberField K]
    [NumberField.IsTotallyComplex K] [Field L] [Algebra K L]
    (hdegree : Module.finrank ℚ K = 2) (f : L →+* ℂ) (z : L)
    (hz : IsIntegral ℤ z) (hne : z ≠ 0)
    (hbase : ∃ a : K, algebraMap K L a = z^2) : 1 ≤ ‖f z‖ := by
  obtain ⟨a, ha⟩ := hbase
  have hi : IsIntegral ℤ a := (isIntegral_algebraMap_iff (R := ℤ) (B := L)).mp
    (by rw [ha]; exact hz.pow 2)
  let A : NumberField.RingOfIntegers K := ⟨a, hi⟩
  have hn := imaginary_quadratic_norm hdegree (f.comp (algebraMap K L)) a
  rw [RingHom.comp_apply, ha, map_pow, norm_pow, ← pow_mul] at hn
  have hnInt : ((Algebra.norm ℤ A : ℤ) : ℝ) = ‖f z‖^4 := by
    rw [← Rat.cast_intCast, Algebra.coe_norm_int]
    exact hn
  have hpos := pow_pos (norm_pos_iff.mpr ((map_ne_zero f).mpr hne)) 4
  have hposInt : 0 < Algebra.norm ℤ A := by exact_mod_cast hnInt.trans_gt hpos
  have hone : (1 : ℝ) ≤ (Algebra.norm ℤ A : ℤ) := by
    exact_mod_cast (show 1 ≤ Algebra.norm ℤ A by omega)
  rw [hnInt] at hone
  by_contra! h
  exact (not_lt_of_ge hone) (pow_lt_one₀ (norm_nonneg _) h (by decide))

/-- Reuse the original published determinant/successor proof once the new
discreteness premise is established. This is not the alternative proof. -/
theorem approximation_of_discrete (θ p q : ℂ) (pr qr : ℕ → ℂ)
    (hpq : ¬ (p=0 ∧ q=0))
    {k₀ ℓ₀ E Q c : ℝ} (hk : 0 < k₀) (hℓ : 0 < ℓ₀)
    (hE : 1 < E) (hQ : 1 < Q) (hc : 0 < c) (hc1 : c < 1)
    (hqb : ∀ r, ‖qr r‖ < k₀*Q^r)
    (herr : ∀ r, ‖qr r*θ-pr r‖ ≤ ℓ₀*E^(-(r : ℤ)))
    (hind : ∀ r, pr r*qr (r+1) ≠ pr (r+1)*qr r)
    (hdiscrete : ∀ r, pr r*q-qr r*p ≠ 0 → 1 ≤ ‖pr r*q-qr r*p‖) :
    ApproximationConclusion θ p q pr qr k₀ ℓ₀ E Q c hE hc := by
  have he : ∀ r, ‖qr r*θ-pr r‖ ≤ ℓ₀/E^r := by
    intro r; simpa only [zpow_neg,zpow_natCast,div_eq_mul_inv] using herr r
  have hh := lemma21_complex_published hk hℓ hE hQ hc hc1 hpq hqb he
    (fun r => sub_ne_zero.mpr (hind r)) hdiscrete (firstIndex_spec (Q := Q) (ℓ := ℓ₀) hE hc q).2
  refine ⟨⟨firstIndex_spec hE hc q, fun _ hr => firstIndex_le hE hc q hr.1 hr.2⟩,hh.1,?_⟩
  intro hne
  apply hh.2
  apply sub_ne_zero.mpr
  simpa only [mul_comm] using hne.symm

/-- The expansion of the squared determinant in the proof of Lemma 2.1. -/
theorem determinant_norm {K L : Type*} [Field K] [NumberField K]
    [NumberField.IsTotallyComplex K] [Field L] [Algebra K L]
    (hdegree : Module.finrank ℚ K = 2) (f : L →+* ℂ)
    (p q : K) (hp : IsIntegral ℤ p) (hq : IsIntegral ℤ q)
    (pr qr : L) (hpr : IsIntegral ℤ pr) (hqr : IsIntegral ℤ qr)
    (hpp : ∃ a : K, algebraMap K L a = pr^2)
    (hpq : ∃ b : K, algebraMap K L b = pr*qr)
    (hqq : ∃ c : K, algebraMap K L c = qr^2)
    (hne : pr*algebraMap K L q-qr*algebraMap K L p ≠ 0) :
    1 ≤ ‖f (pr*algebraMap K L q-qr*algebraMap K L p)‖ := by
  have hpi : IsIntegral ℤ (algebraMap K L p) :=
    (isIntegral_algebraMap_iff (R := ℤ) (B := L)).mpr hp
  have hqi : IsIntegral ℤ (algebraMap K L q) :=
    (isIntegral_algebraMap_iff (R := ℤ) (B := L)).mpr hq
  apply descended_square_norm hdegree f _ ((hpr.mul hqi).sub (hqr.mul hpi)) hne
  obtain ⟨a, ha⟩ := hpp
  obtain ⟨b, hb⟩ := hpq
  obtain ⟨c, hc⟩ := hqq
  refine ⟨a*q^2 - 2*p*q*b + p^2*c, ?_⟩
  simp only [map_add, map_sub, map_mul, map_pow, map_ofNat, ha, hb, hc]
  ring

/-- Lemma 2.1 of 10c. The embedding identifies the ambient field with
a subfield of ℂ. Taking L = ℂ allows arbitrary complex approximants. -/
theorem lemma21 {K L : Type*} [Field K] [NumberField K]
    [NumberField.IsTotallyComplex K] [Field L] [Algebra K L]
    (hdegree : Module.finrank ℚ K = 2) (f : L →+* ℂ)
    (θ : ℂ) (p q : K) (pr qr : ℕ → L)
    (hp : IsIntegral ℤ p) (hq : IsIntegral ℤ q)
    (hpr : ∀ r, IsIntegral ℤ (pr r)) (hqr : ∀ r, IsIntegral ℤ (qr r))
    (hpp : ∀ r, ∃ a : K, algebraMap K L a = (pr r)^2)
    (hmix : ∀ r, ∃ b : K, algebraMap K L b = pr r * qr r)
    (hqq : ∀ r, ∃ c : K, algebraMap K L c = (qr r)^2)
    (hpq : ¬ (p=0 ∧ q=0))
    {k₀ ℓ₀ E Q c : ℝ} (hk : 0 < k₀) (hℓ : 0 < ℓ₀)
    (hE : 1 < E) (hQ : 1 < Q) (hc : 0 < c) (hc1 : c < 1)
    (hqb : ∀ r, ‖f (qr r)‖ < k₀*Q^r)
    (herr : ∀ r, ‖f (qr r)*θ-f (pr r)‖ ≤ ℓ₀*E^(-(r : ℤ)))
    (hind : ∀ r, pr r*qr (r+1) ≠ pr (r+1)*qr r) :
    ApproximationConclusion θ (f (algebraMap K L p)) (f (algebraMap K L q))
      (fun r => f (pr r)) (fun r => f (qr r)) k₀ ℓ₀ E Q c hE hc := by
  apply approximation_of_discrete θ _ _ _ _ ?_ hk hℓ hE hQ hc hc1 hqb herr ?_ ?_
  · intro hh
    apply hpq
    exact ⟨(map_eq_zero (f.comp (algebraMap K L))).mp hh.1,
      (map_eq_zero (f.comp (algebraMap K L))).mp hh.2⟩
  · intro r he
    exact hind r (f.injective (by simpa only [map_mul] using he))
  · intro r hn
    rw [← map_mul,← map_mul,← map_sub] at hn ⊢
    apply determinant_norm hdegree f p q hp hq (pr r) (qr r)
      (hpr r) (hqr r) (hpp r) (hmix r) (hqq r)
    exact fun h => hn (by rw [h,map_zero])

end AnyBAnyNorm
