module
public import Mathlib.Data.Nat.Squarefree

@[expose] public section
namespace AnyBAnyNorm.ExternalResults

/-- J. H. E. Cohn, The Diophantine equation x⁴ − Dy² = 1, II,
Acta Arith. 78 (1997), 401–403, cited as [5] on PDF page 9.
Explicit input for the application in Lemma 3.1, TeX lines 798–841.
Natural-number equations use addition to avoid truncated subtraction. -/
structure CohnTheorem : Prop where
  unique : ∀ D : ℕ, Squarefree D → 1 < D → D ≠ 1785 →
    ∀ X Y X' Y' : ℕ, 0 < X → 0 < Y → 0 < X' → 0 < Y' →
      X^4 = D*Y^2+1 → X'^4 = D*Y'^2+1 → X = X' ∧ Y = Y'
  exceptional : ∀ X Y : ℕ, 0 < X → 0 < Y →
    X^4 = 1785*Y^2+1 → X = 13 ∨ X = 239

end AnyBAnyNorm.ExternalResults
