module

public import AnyBNormSquare.Targets

@[expose] public section
namespace AnyBAnyNorm
open «JNT-2024» AnyBNormSquare

/-- The two choices of α in §1.2 which supplement positive admissible
parameters and negative norm. The a=0 case is treated in Lemma 3.1. -/
def Normalized (P : Parameters) (hp : P.Pell) : Prop :=
  SmallestInitialSquare P hp ∧ ∀ k, IsIntegerSquare (P.y hp k) → P.x hp k ≠ 0

noncomputable def largeThreshold (P : Parameters) : ℝ :=
  598 * (P.b : ℝ)^(8/3 : ℝ) * |(P.normAlpha : ℝ)|^3 / P.d

noncomputable def preciseThreshold (P : Parameters) : ℝ :=
  let b : ℝ := P.b
  let d : ℝ := P.d
  let N := |(P.normAlpha : ℝ)|
  max ((109/10) * b^(26/11 : ℝ) * N^(26/11 : ℝ) / d^(12/11 : ℝ))
    (max ((91/10) * b^(8/3 : ℝ) * N^(5/2 : ℝ) / d^(7/6 : ℝ))
      (598 * b^2 * N^3 / d))

noncomputable def discriminantBound (P : Parameters) : ℝ :=
  18 * (P.b : ℝ)^(28/19 : ℝ) * |(P.normAlpha : ℝ)|^(2/3 : ℝ) /
    (P.u : ℝ)^(36/19 : ℝ)

/-- Theorem 1.7 and Proposition 4.1 share their quantifiers and differ in
the strict size cutoff, TeX 369–377 and 1504–1517. -/
def FourAbove (threshold : Parameters → ℝ) : Prop :=
  ∀ (P : Parameters) (h : P.Admissible), P.normAlpha < 0 → Normalized P h.pell →
    ∀ K, P.IsNegativeCutoff h.pell K →
      AtMostSquareValuesOn (P.y h.pell)
        (fun k => (1 ≤ k ∨ k ≤ K) ∧ threshold P < (P.y h.pell k : ℝ)) 4

def Theorem17 : Prop := FourAbove largeThreshold
def Proposition41 : Prop := FourAbove preciseThreshold

/-- The common alternatives in Theorem 1.8(a,b) and Corollary 1.9(a,b).
Positivity of b belongs to Admissible. -/
def InRange (P : Parameters) : Prop :=
  P.b ≤ 4 ∨ (5 ≤ P.b ∧ discriminantBound P ≤ (P.d : ℝ))

def Theorem18 : Prop :=
  ∀ (P : Parameters) (h : P.Admissible), P.normAlpha < 0 → Normalized P h.pell →
    InRange P → ∀ K, P.IsNegativeCutoff h.pell K →
      AtMostSquareValuesOn (P.y h.pell) (fun k => 3 ≤ k ∨ k ≤ K-2) 4

def Corollary19 : Prop :=
  ∀ (P : Parameters) (h : P.Admissible), P.normAlpha < 0 → Normalized P h.pell →
    InRange P → AtMostSquareValues (P.y h.pell) 9

/-- TeX lines 398–414. The five possible additional values occur at
K-1, K, 0, 1 and 2. Every square strictly between K and 0 equals b². -/
theorem corollary19_of_theorem18 (tail : Theorem18) : Corollary19 := by
  intro P h hn hm hb
  classical
  obtain ⟨K, hK⟩ := P.exists_negative_cutoff h hn
  obtain ⟨S, hS, hcover⟩ := tail P h hn hm hb K hK
  let y := P.y h.pell
  let middle : Finset ℚ := {y (K-1), y K, (P.b : ℚ)^2, y 1, y 2}
  refine ⟨S ∪ middle, ?_, ?_⟩
  · have hcard : middle.card ≤ 5 := Finset.card_le_five
    exact (Finset.card_union_le ..).trans (by omega)
  · intro k hs
    apply Finset.mem_union.mpr
    by_cases ht : 3 ≤ k ∨ k ≤ K-2
    · exact Or.inl (hcover k ht hs)
    right
    change y k ∈ middle
    by_cases hk : k = K-1 ∨ k = K ∨ k = 1 ∨ k = 2
    · rcases hk with rfl | rfl | rfl | rfl <;> simp [middle]
    have hval : y k = (P.b : ℚ)^2 := by
      by_cases hzero : k = 0
      · simp [y, hzero]
      exact le_antisymm (hK.2.2 k (by omega) (by omega)) (hm.1 k hs)
    simp [middle, hval]

end AnyBAnyNorm
