module

public import AnyBAnyNorm.HigherCases

@[expose] public section
namespace AnyBAnyNorm
open «JNT-2024» Section2

/-- The bounds from (4.14), (4.16), (4.19) and (4.23) used separately in §5. -/
def CaseBounds (b d N y : ℝ) : Prop :=
  y < (109/10 : ℝ)*b^(26/11 : ℝ)*N^(26/11 : ℝ)/d^(12/11 : ℝ) ∨
  y < (91/10 : ℝ)*b^(8/3 : ℝ)*N^(5/2 : ℝ)/d^(7/6 : ℝ) ∨
  (∃ (n : ℕ) (M : ℝ), 3 ≤ n ∧ 2 ≤ M ∧
    y ≤ (592/10 : ℝ)*N^(3/2 : ℝ)/(Real.sqrt d*M^2)*(167*b^4*N^(5/2 : ℝ)*M/d)^(1/(n : ℝ))) ∨
  (∃ (n : ℕ) (M : ℝ), 1 ≤ n ∧ 2 ≤ M ∧
    y < (6532/100 : ℝ)*N^(3/2 : ℝ)/(Real.sqrt d*M^2)*(1340*b^4*N^3/d)^(1/(2*(n : ℝ))))

/-- Conditions (4.14), (4.16), (4.17), (4.22) with the actual coefficient product F. -/
def BeforeCoefficientBound (b d N y F : ℝ) : Prop :=
  y < (109/10 : ℝ)*b^(26/11 : ℝ)*N^(26/11 : ℝ)/d^(12/11 : ℝ) ∨
  y < (91/10 : ℝ)*b^(8/3 : ℝ)*N^(5/2 : ℝ)/d^(7/6 : ℝ) ∨
  (∃ (n : ℕ) (M : ℝ), 3 ≤ n ∧ 2 ≤ M ∧
    (y^4*d^2*M^8/((592/10 : ℝ)^4*N^6))^n < F^8*(181/1000 : ℝ)*(N^2*M^4/(b^16*d^4))) ∨
  (∃ (n : ℕ) (M : ℝ), 1 ≤ n ∧ 2 ≤ M ∧
    (1911/10000 : ℝ)*b^4*d/(F^2*N)*((2344/10000000 : ℝ)*M^4*d*y^2/N^3)^n < 1)

/-- The four cases of §§4.3–4.6 for one fixed ordered triple. -/
theorem selected_coefficient_bounds (hPrior : Hypergeometric.DenominatorEstimate4)
    {P : Parameters} (h : P.Admissible) (hn : P.normAlpha < 0) (hm : Normalized P h.pell)
    {i j k : ℤ} (a : SquarePhase P h.pell i) (b : SquarePhase P h.pell j)
    (c : SquarePhase P h.pell k) (hi : i ≠ 0) (hs : IsIntegerSquare (P.y h.pell i))
    (hij : (P.y h.pell i : ℝ) < (P.y h.pell j : ℝ)) (hjk : (P.y h.pell j : ℝ) < (P.y h.pell k : ℝ))
    (hl : 4*Real.sqrt (|(P.normAlpha : ℝ)|/P.d) ≤ (P.y h.pell i : ℝ))
    (hl16 : 16*|(P.normAlpha : ℝ)|/Real.sqrt P.d ≤ (P.y h.pell i : ℝ))
    (hab : SamePhaseClass a.ζ b.ζ) (hbc : SamePhaseClass b.ζ c.ζ) {η : ℂ}
    (hη : FourthPhase η) (hK : η ∈ Construction.baseField (squarefreePart P.normAlpha))
    (hmin : ∀ θ : ℂ, FourthPhase θ →
      let z := star a.datum.point*c.datum.point
      let w := principalFourthRoot (P.sequenceOmega h.pell i)
      ‖w - η*(star z/z)‖ ≤ ‖w - θ*(star z/z)‖) :
    (P.y h.pell i : ℝ) < preciseThreshold P ∧
      CaseBounds P.b P.d |(P.normAlpha : ℝ)| (P.y h.pell i : ℝ) ∧
      BeforeCoefficientBound P.b P.d |(P.normAlpha : ℝ)| (P.y h.pell i : ℝ) (a.datum.f*c.datum.f) := by
  let z := star a.datum.point*c.datum.point
  let F := a.datum.f*c.datum.f
  let y := (P.y h.pell i : ℝ)
  let t := (P.y h.pell k : ℝ)
  let N := |(P.normAlpha : ℝ)|
  let S := squarefreePart P.normAlpha
  have hN : 0 < N := abs_pos.mpr (by exact_mod_cast hn.ne)
  have hNone : 1 ≤ N := by
    dsimp [N]; rw [abs_of_neg (by exact_mod_cast hn)]
    exact_mod_cast (show (1 : ℤ) ≤ -P.normAlpha by omega)
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hb : (0 : ℝ) < P.b := by exact_mod_cast h.b_pos
  have hb1 : (1 : ℝ) ≤ P.b := by exact_mod_cast h.b_pos
  have hby : (P.b : ℝ)^2 ≤ y := by dsimp [y]; exact_mod_cast hm.1 i hs
  have hy : 0 < y := by simpa only [y,← a.cert.1] using a.datum.y_pos
  have ht : 0 < t := by simpa only [t,← c.cert.1] using c.datum.y_pos
  have hF : 0 < F := mul_pos a.datum.f_pos c.datum.f_pos
  have hFub := coefficient_product hn a c
  obtain ⟨X,Y,hx,hY,hE,happ⟩ := section42_cutoff hPrior h hn a c hi hs hl16 hη hK
  let u := 2*X
  let v := 2*(AnyBNormSquare.unitPowerNorm P i*squareFactor P.normAlpha)
  let M := Approximation.normalizerProduct S u v
  let r := Approximation.firstIndex (Q := Q S u v) (ℓ := ell S u v) hE (by norm_num : (0 : ℝ)<3/4) z
  have hyY : (Y : ℝ) = y := by simp [y,hY]
  have hsize := hl16
  change _ ≤ y at hsize
  rw [← hyY] at hsize
  obtain ⟨hcoord,_,_,hEL,_,hq₁,hq₂,hq₃,hQU,hell,hnear⟩ :=
    section42_parameters h hn hi hs hx hY hsize
  rw [hyY] at hcoord hEL hq₁ hq₂ hq₃ hQU
  have hM2 : 2 ≤ M := by
    simpa only [S,u,v,M,mul_assoc] using (section41_normalizer h hn hi hx hY hsize).1
  have hM : 0 < M := by linarith
  have hQ : (2112/100 : ℝ) < Q S u v := lt_of_le_of_lt hq₃ (hq₂.trans_le hq₁)
  obtain ⟨hv,_,_,hw⟩ := section42_coordinates h hn hx hY
  have hv' : v ≠ 0 := mul_ne_zero (by decide) hv
  have hz : z ≠ 0 := mul_ne_zero (star_ne_zero.mpr a.datum.point_ne) c.datum.point_ne
  have hfour : ‖z‖^4*(P.b : ℝ)^4 = F^2*y*t := by
    simpa only [z,y,t,F,norm_mul,norm_star,a.cert.1,c.cert.1] using a.datum.cross_denominator_four c.datum
  have hcsize := hl.trans (hij.trans hjk).le
  rw [← c.cert.1] at hcsize
  obtain ⟨hidentity,hcomparison⟩ := section42_comparison h hn a c hcsize hmin
  rw [hidentity,c.cert.1] at hcomparison
  let θ := P.sequenceOmega h.pell i ^ (1/4 : ℂ)
  have hcomp : (3959/1000 : ℝ)*‖θ-(η*star z)/z‖ < 2*Real.sqrt N/(Real.sqrt P.d*t) := by
    simpa only [θ,mul_div_assoc] using hcomparison
  obtain ⟨hrmin,_,hrne⟩ := happ
  have hr : 1 ≤ r := hrmin.1.1
  let det := η*star z * rawQ S u v r = rawP S u v r * z
  have hdiff (he : ¬det) := nonexact_upper hN hd ht hb (lt_trans (by norm_num) hQ)
    (by norm_num : (3/4 : ℝ)<1) hr hz (by simpa only [mul_assoc] using hQU)
    (hrne (by
      change η*star z*rawQ S u v r ≠ z*rawP S u v r
      rw [mul_comm z (rawP S u v r)]
      exact he)) hcomp hfour
  have hexact (he : det) : t < (1734/1000 : ℝ)*Real.sqrt r*(4*P.d/N)^r*y^(2*r+1) := by
    apply section44_equation415 (squarefreePart_neg hn) hv' hr hz he hnear hN hd hy ht
    · simpa only [hyY] using section44_chord h hn hx hY (hyY ▸ hy)
    · rw [hw]
      have h := (lt_div_iff₀' (by norm_num : (0 : ℝ)<3959/1000)).mpr hcomp
      convert h using 1; ring
  have hgap := (section44_two_gaps h hn a b c hij hjk hl hab hbc).2.2
  by_cases h1 : r = 1
  · by_cases he : ¬det
    · have hh := hdiff he
      rw [h1] at hh
      have hbound := section43_bound hN hd hy hb hF hM2 hFub (by simpa using hh) hgap
      exact ⟨hbound.trans_le (le_max_left _ _), Or.inl hbound,Or.inl hbound⟩
    · have hh := hexact (not_not.mp he)
      rw [h1] at hh
      have h694 := Section4.exact_equation415_index_one (z := t) hN hd hy
        (by simpa only [Nat.cast_one,Real.sqrt_one,mul_one,pow_one] using hh)
      have hbound := section44_bound hd hb hN hy hgap h694
      exact ⟨hbound.trans_le ((le_max_left _ _).trans (le_max_right _ _)), Or.inr (Or.inl hbound),Or.inr (Or.inl hbound)⟩
  have hr' : 1 < r := by omega
  have hcut := AnyBNormSquare.HigherIndex.cutoff_chain hE hQ (ell_pos (squarefreePart_neg hn) hv')
    (by norm_num : (0 : ℝ)<3/4) z hr'
  have hco : (15/16 : ℝ)*(Real.sqrt P.d*y)^2 ≤ (X : ℝ)^2 := by
    simpa only [mul_pow,Real.sq_sqrt hd.le,mul_assoc] using hcoord
  have hdL := AnyBNormSquare.HigherIndex.coordinate_lower (lt_trans (by norm_num) hE)
    (ell_pos (squarefreePart_neg hn) hv') (by norm_num : (0 : ℝ)<3/4) hN
    (mul_pos (Real.sqrt_pos.mpr hd) hy) hco hell
    (by positivity : 0 < (1832/10000 : ℝ)*M*(Real.sqrt P.d*y)/N) hEL (hcut.2.trans_le hcut.1)
  have hhigh := AnyBNormSquare.HigherIndex.fourth_power hN hd hy hF hM hb
    (by norm_num : (0 : ℝ)<3/4) hr hfour (by simpa only [mul_assoc] using hdL)
  by_cases he : ¬det
  · have hh := section45_initial hN hd hy hF hM hb hr hhigh (hdiff he)
    have hub := section45_root hN hd hy hF hM hb (by omega : 0 < 2*r-1) hFub hh
    have hbnd := section45_bound hNone hd hb1 hM2 hby (by omega : 3 ≤ 2*r-1) hub
    have hbpow := Real.rpow_le_rpow_of_exponent_le hb1 (by norm_num : (6/5 : ℝ) ≤ 2)
    rw [Real.rpow_two] at hbpow
    refine ⟨?_, Or.inr (Or.inr (Or.inl ⟨2*r-1, M, by omega, hM2, hub⟩)),Or.inr (Or.inr (Or.inl ⟨2*r-1,M,by omega,hM2,hh⟩))⟩
    apply hbnd.trans_le
    apply le_trans _ ((le_max_right _ _).trans (le_max_right _ _))
    apply div_le_div_of_nonneg_right _ hd.le
    apply mul_le_mul_of_nonneg_right _ (pow_nonneg hN.le 3)
    exact mul_le_mul (by norm_num) hbpow (by positivity) (by norm_num)
  · have hh := AnyBNormSquare.Case45.normalized hN hd hy hF hM hb hr
      (AnyBNormSquare.Case45.remove_sqrt hN hd hy hF hM hb hr hhigh (hexact (not_not.mp he)))
    refine ⟨?_, Or.inr (Or.inr (Or.inr ⟨r-1, M, by omega, hM2,
      section46_root hN hd hb1 hF hM2 hby (by omega) hFub hh⟩)),Or.inr (Or.inr (Or.inr ⟨r-1,M,by omega,hM2,hh⟩))⟩
    exact (section46_bound hN hd hb1 hF hM2 hby (by omega : 1 ≤ r-1) hFub hh).trans_le
      ((le_max_right _ _).trans (le_max_right _ _))

/-- The four cases of §§4.3–4.6 for one fixed ordered triple. -/
theorem selected_case_bounds (hPrior : Hypergeometric.DenominatorEstimate4)
    {P : Parameters} (h : P.Admissible) (hn : P.normAlpha < 0) (hm : Normalized P h.pell)
    {i j k : ℤ} (a : SquarePhase P h.pell i) (b : SquarePhase P h.pell j)
    (c : SquarePhase P h.pell k) (hi : i ≠ 0) (hs : IsIntegerSquare (P.y h.pell i))
    (hij : (P.y h.pell i : ℝ) < (P.y h.pell j : ℝ)) (hjk : (P.y h.pell j : ℝ) < (P.y h.pell k : ℝ))
    (hl : 4*Real.sqrt (|(P.normAlpha : ℝ)|/P.d) ≤ (P.y h.pell i : ℝ))
    (hl16 : 16*|(P.normAlpha : ℝ)|/Real.sqrt P.d ≤ (P.y h.pell i : ℝ))
    (hab : SamePhaseClass a.ζ b.ζ) (hbc : SamePhaseClass b.ζ c.ζ) {η : ℂ}
    (hη : FourthPhase η) (hK : η ∈ Construction.baseField (squarefreePart P.normAlpha))
    (hmin : ∀ θ : ℂ, FourthPhase θ →
      let z := star a.datum.point*c.datum.point
      let w := principalFourthRoot (P.sequenceOmega h.pell i)
      ‖w - η*(star z/z)‖ ≤ ‖w - θ*(star z/z)‖) :
    (P.y h.pell i : ℝ) < preciseThreshold P ∧
      CaseBounds P.b P.d |(P.normAlpha : ℝ)| (P.y h.pell i : ℝ) := by
  have hh := selected_coefficient_bounds hPrior h hn hm a b c hi hs hij hjk hl hl16 hab hbc hη hK hmin
  exact ⟨hh.1,hh.2.1⟩

/-- The four cases of §§4.3–4.6 for one fixed ordered triple. -/
theorem selected_four_cases (hPrior : Hypergeometric.DenominatorEstimate4)
    {P : Parameters} (h : P.Admissible) (hn : P.normAlpha < 0) (hm : Normalized P h.pell)
    {i j k : ℤ} (a : SquarePhase P h.pell i) (b : SquarePhase P h.pell j)
    (c : SquarePhase P h.pell k) (hi : i ≠ 0) (hs : IsIntegerSquare (P.y h.pell i))
    (hij : (P.y h.pell i : ℝ) < (P.y h.pell j : ℝ)) (hjk : (P.y h.pell j : ℝ) < (P.y h.pell k : ℝ))
    (hl : 4*Real.sqrt (|(P.normAlpha : ℝ)|/P.d) ≤ (P.y h.pell i : ℝ))
    (hl16 : 16*|(P.normAlpha : ℝ)|/Real.sqrt P.d ≤ (P.y h.pell i : ℝ))
    (hab : SamePhaseClass a.ζ b.ζ) (hbc : SamePhaseClass b.ζ c.ζ) {η : ℂ}
    (hη : FourthPhase η) (hK : η ∈ Construction.baseField (squarefreePart P.normAlpha))
    (hmin : ∀ θ : ℂ, FourthPhase θ →
      let z := star a.datum.point*c.datum.point
      let w := principalFourthRoot (P.sequenceOmega h.pell i)
      ‖w - η*(star z/z)‖ ≤ ‖w - θ*(star z/z)‖) :
    (P.y h.pell i : ℝ) < preciseThreshold P :=
  (selected_case_bounds hPrior h hn hm a b c hi hs hij hjk hl hl16 hab hbc hη hK hmin).1

end AnyBAnyNorm
