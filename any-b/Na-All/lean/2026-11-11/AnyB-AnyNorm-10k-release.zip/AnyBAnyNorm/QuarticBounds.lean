module

public import Mathlib.Data.Set.Card
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.Linarith

/-! The cited sharp bound for c = −2 in §1.1. The upper bound from the
literature is an explicit theorem parameter, as in the development for c = −1. -/
@[expose] public section
namespace AnyBAnyNorm.QuarticBounds

def positiveSolutions (a b c : ℤ) : Set (ℤ × ℤ) :=
  {p | 0 < p.1 ∧ 0 < p.2 ∧ a * p.1^2 - b * p.2^4 = c}

/-- The positive-coefficient case of Theorem 1 in Akhtari, Togbé and Walsh
(Acta Arith. 137, 199–202) and Voutier (ibid., 203–206). The first coordinate
is the variable raised to the fourth power in the cited papers. -/
def FourthPowerEquationTwo : Prop :=
  ∀ A B : ℤ, 0 < A → 0 < B →
    ({p : ℤ × ℤ | 0 < p.1 ∧ 0 < p.2 ∧ A * p.1^4 - B * p.2^2 = 2} :
      Set (ℤ × ℤ)).encard ≤ 2

theorem negativeTwo (bound : FourthPowerEquationTwo) (a b : ℤ) (ha : 0 < a) (hb : 0 < b) :
    (positiveSolutions a b (-2)).encard ≤ 2 := by
  apply le_trans _ (bound b a hb ha)
  apply Set.encard_le_encard_of_injOn (f := Prod.swap)
  · intro p hp
    obtain ⟨hx,hy,he⟩ := hp
    exact ⟨hy,hx,by change b * p.2^4 - a * p.1^2 = 2; linarith⟩
  · exact Prod.swap_injective.injOn

/-- The m = 1 instance of the first family following Theorem 1 in the addendum. -/
theorem negativeTwo_sharp (bound : FourthPowerEquationTwo) :
    (positiveSolutions 4 6 (-2)).encard = 2 := by
  apply le_antisymm (negativeTwo bound 4 6 (by decide) (by decide))
  have h : ({(1,1), (11,3)} : Set (ℤ × ℤ)) ⊆ positiveSolutions 4 6 (-2) := by
    intro p hp
    rcases hp with rfl | hp
    · norm_num [positiveSolutions]
    · obtain rfl : p = (11,3) := hp
      norm_num [positiveSolutions]
  have lower := Set.encard_le_encard h
  norm_num [Set.encard_insert_of_notMem, show ((1,1) : ℤ × ℤ) ≠ (11,3) by decide] at lower
  exact lower

end AnyBAnyNorm.QuarticBounds
