module

public import AnyBAnyNorm.Gap
public import AnyBAnyNorm.Construction
public import AnyBAnyNorm.MainStatements
public import AnyBNormSquare.Prerequisites
public import Mathlib.Data.Finset.Sort

@[expose] public section
namespace AnyBAnyNorm
open «JNT-2024»

private def realPhase (z : ℂ) : Prop := z = 1 ∨ z = -1

private theorem same_class {z w : ℂ} (hz : FourthPhase z) (hw : FourthPhase w)
    (hc : realPhase z ↔ realPhase w) : SamePhaseClass z w := by
  rcases hz with rfl | rfl | rfl | rfl <;> rcases hw with rfl | rfl | rfl | rfl <;>
    norm_num [realPhase, SamePhaseClass, Complex.ext_iff] at *

private theorem three_of_five :
    ∀ color : Fin 5 → Bool, ∃ i j k : Fin 5, i < j ∧ j < k ∧
      color i = color j ∧ color j = color k := by
  intro color
  let group (c : Bool) := Finset.univ.filter fun i : Fin 5 => color i = c
  have hsum : (group true).card + (group false).card = 5 := by
    simpa [group] using Finset.card_filter_add_card_filter_not (s := Finset.univ)
      (fun i : Fin 5 => color i = true)
  obtain ⟨c,hc⟩ : ∃ c, 3 ≤ (group c).card := by
    by_cases h : 3 ≤ (group true).card
    · exact ⟨true,h⟩
    · exact ⟨false,by omega⟩
  obtain ⟨s,hs,hcard⟩ := Finset.exists_subset_card_eq hc
  let e := s.orderEmbOfFin hcard
  have hc' (a : Fin 3) : color (e a) = c := (Finset.mem_filter.mp (hs (s.orderEmbOfFin_mem hcard a))).2
  exact ⟨e 0,e 1,e 2,e.strictMono (by decide),e.strictMono (by decide),
    (hc' 0).trans (hc' 1).symm,(hc' 1).trans (hc' 2).symm⟩

/-- §4.1, lines 1100–1105. The ordering of positions retains the ordering of
the square values. All three chosen pairs have phases equal up to sign. -/
theorem select_three_indices {P : Parameters} {hp : P.Pell} (k : Fin 5 → ℤ)
    (p : ∀ n, SquarePhase P hp (k n)) :
    ∃ i j l : Fin 5, i < j ∧ j < l ∧ SamePhaseClass (p i).ζ (p j).ζ ∧
      SamePhaseClass (p j).ζ (p l).ζ ∧ SamePhaseClass (p i).ζ (p l).ζ := by
  classical
  obtain ⟨i, j, l, hij, hjl, hc, hc'⟩ := three_of_five (fun n => decide (realPhase (p n).ζ))
  have same (a b : Fin 5) (hab : decide (realPhase (p a).ζ) = decide (realPhase (p b).ζ)) :
      SamePhaseClass (p a).ζ (p b).ζ :=
    same_class (p a).phase (p b).phase (by simpa only [decide_eq_decide] using hab)
  exact ⟨i, j, l, hij, hjl, same i j hc, same j l hc', same i l (hc.trans hc')⟩

/-- §4.1, lines 1112–1131. Choose the minimizing comparison phase.
In the square case all four choices belong to ℚ(i). In the nonsquare
case Lemma 3.5(b) locates the minimum at one of the two signs. -/
theorem comparison_phase {P : Parameters} (h : P.Admissible) (hn : P.normAlpha < 0)
    {i j : ℤ} (p : SquarePhase P h.pell i) (q : SquarePhase P h.pell j)
    (hy : (P.y h.pell i : ℝ) < (P.y h.pell j : ℝ))
    (hl : 4 * Real.sqrt (|(P.normAlpha : ℝ)| / P.d) ≤ (P.y h.pell i : ℝ))
    (hc : SamePhaseClass p.ζ q.ζ) :
    let w := principalFourthRoot (P.sequenceOmega h.pell i)
    let z := star p.datum.point * q.datum.point
    ∃ η : ℂ, FourthPhase η ∧ η ∈ Construction.baseField (squarefreePart P.normAlpha) ∧
      ∀ θ : ℂ, FourthPhase θ → ‖w - η * (star z / z)‖ ≤ ‖w - θ * (star z / z)‖ := by
  dsimp only
  by_cases hs : IsSquare (-P.normAlpha)
  · have hz : ‖star (star p.datum.point * q.datum.point) / (star p.datum.point * q.datum.point)‖ = 1 := by
      rw [← p.datum.ratio_quotient_cross q.datum, norm_div, p.datum.ratio_norm, q.datum.ratio_norm, div_one]
    obtain ⟨η, hη, _, hmin⟩ := exists_minimizing_fourth_phase
      (principalFourthRoot_norm (P.sequenceOmega h.pell i)) hz
    refine ⟨η, hη, ?_, hmin⟩
    rw [squarefreePart_eq_neg_one hn.ne hs]
    have hI : Complex.I ∈ Construction.baseField (-1) := by
      have hr : Section2.root (-1) ∈ Construction.baseField (-1) :=
        Subfield.subset_closure (Set.mem_singleton _)
      simpa [Section2.root] using hr
    rcases hη with rfl | rfl | rfl | rfl
    · exact one_mem _
    · exact neg_mem (one_mem _)
    · exact hI
    · exact neg_mem hI
  · obtain ⟨η, hη, hmin⟩ := lemma35b h hn p q hy hl hc
    refine ⟨η, ?_, ?_, ?_⟩
    · rcases hη with rfl | rfl <;> simp [FourthPhase]
    · rcases hη with rfl | rfl
      · exact one_mem _
      · exact neg_mem (one_mem _)
    · intro θ hθ
      by_cases he : θ = η
      · simp only [he, le_refl]
      · exact (hmin θ hθ he).le

/-- The bound (4.4) implies both terms in the maximum in (4.3). -/
theorem section41_size {P : Parameters} (hn : P.normAlpha < 0)
    {y : ℝ} (hl : 16 * |(P.normAlpha : ℝ)| / Real.sqrt P.d ≤ y) :
    max (4 * |(P.normAlpha : ℝ)| / Real.sqrt P.d)
      (16 * Real.sqrt (|(P.normAlpha : ℝ)| / P.d)) ≤ y := by
  have hN : 1 ≤ |(P.normAlpha : ℝ)| := by
    rw [abs_of_neg (by exact_mod_cast hn)]
    exact_mod_cast (show (1 : ℤ) ≤ -P.normAlpha by omega)
  rw [Real.sqrt_div (abs_nonneg _), ← mul_div_assoc]
  apply le_trans _ hl
  apply max_le <;> apply div_le_div_of_nonneg_right _ (Real.sqrt_nonneg _)
  · linarith
  · linarith [Real.sqrt_le_self_iff.mpr (Or.inr hN)]

/-- The data supplied by (4.1) and (4.4), with the phases attached to the
five original representations before the ordered triple is selected. -/
theorem section41_select {P : Parameters} (h : P.Admissible) (hn : P.normAlpha < 0)
    (hm : Normalized P h.pell) {K : ℤ} (hK : P.IsNegativeCutoff h.pell K)
    (k : Fin 5 → ℤ) (hs : ∀ a, IsIntegerSquare (P.y h.pell (k a)))
    (hord : StrictMono (fun a => P.y h.pell (k a)))
    (hfirst : 1 ≤ k 0 ∨ k 0 ≤ K)
    (hsize : 16 * |(P.normAlpha : ℝ)| / Real.sqrt P.d ≤ (P.y h.pell (k 0) : ℝ)) :
    (∀ a, 1 ≤ k a ∨ k a ≤ K) ∧
    ∃ (ph : ∀ a, SquarePhase P h.pell (k a)) (i j l : Fin 5),
      i < j ∧ j < l ∧ SamePhaseClass (ph i).ζ (ph j).ζ ∧
      SamePhaseClass (ph j).ζ (ph l).ζ ∧ SamePhaseClass (ph i).ζ (ph l).ζ ∧
      4 * Real.sqrt (|(P.normAlpha : ℝ)| / P.d) ≤ (P.y h.pell (k i) : ℝ) ∧
      let z := star (ph i).datum.point * (ph l).datum.point
      let w := principalFourthRoot (P.sequenceOmega h.pell (k i))
      ∃ η : ℂ, FourthPhase η ∧ η ∈ Construction.baseField (squarefreePart P.normAlpha) ∧
        ∀ θ : ℂ, FourthPhase θ → ‖w - η * (star z / z)‖ ≤ ‖w - θ * (star z / z)‖ := by
  have hall (a : Fin 5) : 1 ≤ k a ∨ k a ≤ K := by
    by_cases he : a = 0
    · simpa [he] using hfirst
    have hgt := (hm.1 _ (hs 0)).trans_lt (hord (lt_of_le_of_ne (Fin.zero_le a) (Ne.symm he)))
    by_contra! hbad
    by_cases hz : k a = 0
    · simp [hz] at hgt
    exact (not_lt_of_ge (hK.2.2 _ hbad.2 (by omega))) hgt
  have reps (a : Fin 5) := least_phase (paperPhase_exists h hn
    (show k a ≠ 0 by have := hall a; have := hK.1; omega) (hs a)
    (lt_of_lt_of_le (by exact_mod_cast sq_pos_of_pos h.b_pos) (hm.1 _ (hs a))) (hm.2 _ (hs a)))
  choose ph _hpaper _hleast using reps
  obtain ⟨i, j, l, hij, hjl, h₁, h₂, h₃⟩ := select_three_indices k ph
  have hbase := AnyBNormSquare.Prerequisites.threshold_implies_coordinate_size P h hn
    ((le_max_left _ _).trans (section41_size hn hsize))
  have hi := hbase.trans (show (P.y h.pell (k 0) : ℝ) ≤ (P.y h.pell (k i) : ℝ) by
    exact_mod_cast hord.monotone (Fin.zero_le i))
  exact ⟨hall, ph, i, j, l, hij, hjl, h₁, h₂, h₃, hi,
    comparison_phase h hn (ph i) (ph l) (by exact_mod_cast hord (hij.trans hjl)) hi h₃⟩

end AnyBAnyNorm
