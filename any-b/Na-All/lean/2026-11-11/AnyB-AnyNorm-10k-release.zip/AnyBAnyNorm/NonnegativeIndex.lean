module

public import «JNT-2024».RealBounds
public import Mathlib.RingTheory.IntegralClosure.IsIntegralClosure.Basic

@[expose] public section
namespace AnyBAnyNorm
open «JNT-2024»

/-- §1.8(3), 08a. At a nonnegative index, the element in (1.1) is an
algebraic integer for every algebraic integer ε, including nonunits. -/
theorem nonnegative_index_integral (P : Parameters) (hd : 0 < P.d)
    (hε : IsIntegral ℤ P.realEpsilon) {k : ℤ} (hk : 0 ≤ k) (x y : ℚ)
    (he : (x : ℝ) + y * P.root = P.realAlpha * P.realEpsilon ^ (2*k)) :
    IsIntegral ℤ ((x : ℝ) + y * P.root) := by
  have hr : IsIntegral ℤ P.root := by
    apply IsIntegral.of_pow (by decide : 0 < 2)
    rw [Parameters.root, Real.sq_sqrt (by exact_mod_cast hd.le)]
    exact isIntegral_intCast _
  have hα : IsIntegral ℤ P.realAlpha :=
    (isIntegral_intCast P.a).add (((isIntegral_intCast P.b).pow 2).mul hr)
  rw [he, ← Int.toNat_of_nonneg (show 0 ≤ 2*k by omega), zpow_natCast]
  exact hα.mul (hε.pow _)

end AnyBAnyNorm
