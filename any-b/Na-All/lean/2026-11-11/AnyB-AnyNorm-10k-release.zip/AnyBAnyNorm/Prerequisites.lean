module

public import AnyBAnyNorm.IndexSelection

@[expose] public section
namespace AnyBAnyNorm
open «JNT-2024»

/-- The normalizer term in (4.3), using (4.4) on the smallest square.
The normalizer may be evaluated at any of the selected square indices. -/
theorem section41_normalizer {P : Parameters} (h : P.Admissible) (hn : P.normAlpha < 0)
    {k X Y : ℤ} (hk : k ≠ 0) (hx : P.x h.pell k = (X : ℚ))
    (hy : P.y h.pell k = (Y : ℚ)) {y : ℝ}
    (hl : 16 * |(P.normAlpha : ℝ)| / Real.sqrt P.d ≤ y) :
    let M := Approximation.normalizerProduct (squarefreePart P.normAlpha) (2*X)
      (2*AnyBNormSquare.unitPowerNorm P k*squareFactor P.normAlpha)
    2 ≤ M ∧ max (4*|(P.normAlpha : ℝ)| / Real.sqrt P.d) (M / Real.sqrt P.d) ≤ y := by
  have hM := lemma36 P h hn hk hx hy
  have hN : (1 : ℝ) ≤ |(P.normAlpha : ℝ)| := by
    rw [abs_of_neg (by exact_mod_cast hn)]
    exact_mod_cast (show (1 : ℤ) ≤ -P.normAlpha by omega)
  have hs := Real.sqrt_le_self_iff.mpr (Or.inr hN)
  refine ⟨hM.1, max_le ?_ ?_⟩ <;> apply le_trans _ hl <;>
    apply div_le_div_of_nonneg_right _ (Real.sqrt_nonneg _)
  · linarith
  · exact hM.2.trans (mul_le_mul_of_nonneg_left hs (by norm_num))

private theorem fourthRoot_eq_cpow {w : ℂ} (hw : ‖w‖ = 1) :
    principalFourthRoot w = w ^ (1/4 : ℂ) := by
  have hn : w ≠ 0 := by intro he; simp [he] at hw
  rw [Complex.cpow_def_of_ne_zero hn, principalFourthRoot]
  unfold Complex.log
  rw [hw, Real.log_one]
  push_cast
  congr 1
  ring

/-- Both parts of (4.5) for the very same minimizing phase as in §4.1. -/
theorem section42_comparison {P : Parameters} (h : P.Admissible) (hn : P.normAlpha < 0)
    {i j : ℤ} (p : SquarePhase P h.pell i) (q : SquarePhase P h.pell j)
    (hl : 4*Real.sqrt (|(P.normAlpha : ℝ)|/P.d) ≤ q.datum.y) {η : ℂ}
    (hm : ∀ θ : ℂ, FourthPhase θ →
      let z := star p.datum.point*q.datum.point
      let w := principalFourthRoot (P.sequenceOmega h.pell i)
      ‖w - η*(star z/z)‖ ≤ ‖w - θ*(star z/z)‖) :
    let z := star p.datum.point*q.datum.point
    let w := P.sequenceOmega h.pell i
    ‖w - (star z/z)^4‖ = 2*Real.sqrt |(P.normAlpha : ℝ)|/(Real.sqrt P.d*q.datum.y) ∧
      (3959/1000 : ℝ)*‖w^(1/4 : ℂ) - η*(star z/z)‖ < ‖w - (star z/z)^4‖ := by
  let z := star p.datum.point*q.datum.point
  have hz : z ≠ 0 := mul_ne_zero (star_ne_zero.mpr p.datum.point_ne) q.datum.point_ne
  have hv : ‖star z/z‖ = 1 := by rw [norm_div,norm_star,div_self (norm_ne_zero_iff.mpr hz)]
  have hw := P.sequenceOmega_norm h.pell hn i
  have hr : ‖P.sequenceOmega h.pell i - (star z/z)^4‖ = 2*P.gapScale/q.datum.y :=
    (eq_div_iff q.datum.y_pos.ne').mpr (P.sequence_cross_residual_published h hn _ _ p.cert q.cert)
  have hp : 0 < ‖P.sequenceOmega h.pell i - (star z/z)^4‖ := by
    rw [hr]; exact div_pos (mul_pos (by norm_num) (P.gapScale_pos h.b_pos hn)) q.datum.y_pos
  have hsmall : ‖P.sequenceOmega h.pell i - (star z/z)^4‖ ≤ 1/2 := by
    rw [hr,div_le_iff₀ q.datum.y_pos]
    linarith only [P.gapScale_eq_sqrt h.b_pos hn,hl]
  obtain ⟨θ,hθ,_,_,hb⟩ := Section4.comparison_phase_3959 hw hv hp hsmall
  have hmin := hm θ hθ
  dsimp only at hmin
  rw [fourthRoot_eq_cpow hw] at hmin
  exact ⟨AnyBNormSquare.Prerequisites.comparison_identity P h hn _ _ p.cert q.cert,
    (mul_le_mul_of_nonneg_left hmin (by norm_num : (0 : ℝ) ≤ 3959/1000)).trans_lt hb⟩

/-- The analytic inputs of Lemma 2.1 use JNT Lemma 2.3(a) for all r,
including zero, through the release's bounds on the raw approximants. -/
theorem section42_approximant_bounds (hPrior : Hypergeometric.DenominatorEstimate4)
    {S u₁ u₂ : ℤ} (hS : S < 0) (hu : u₂ ≠ 0) (hw : ‖Section2.omega S u₁ u₂ - 1‖ < 1)
    (r : ℕ) :
    ‖Section2.rawQ S u₁ u₂ r‖ < AnyBNormSquare.paperK0 * Section2.Q S u₁ u₂ ^ r ∧
    ‖Section2.rawQ S u₁ u₂ r * Section2.omega S u₁ u₂ ^ (1/4 : ℂ) -
        Section2.rawP S u₁ u₂ r‖ ≤ Section2.ell S u₁ u₂ / Section2.E S u₁ u₂ ^ r := by
  refine ⟨(Section2.rawQ_bound hPrior hS hu hw r).trans_le ?_, ?_⟩
  · exact mul_le_mul_of_nonneg_right AnyBNormSquare.paperK0_justified.le
      (pow_nonneg (Section2.Q_pos hS hu).le r)
  · rw [Section2.raw_error_identity hw r]
    exact Section2.rawR_bound hPrior hS hu hw r

/-- The substitution at 07c lines 1174–1179, with the sign of the unit norm. -/
theorem section42_coordinates {P : Parameters} (h : P.Admissible) (hn : P.normAlpha < 0)
    {k X Y : ℤ} (hx : P.x h.pell k = (X : ℚ)) (hy : P.y h.pell k = (Y : ℚ)) :
    let S := squarefreePart P.normAlpha
    let Z := AnyBNormSquare.unitPowerNorm P k * squareFactor P.normAlpha
    let N := |(P.normAlpha : ℝ)|
    Z ≠ 0 ∧ (Z : ℝ)^2 * |(S : ℝ)| = N ∧
    (X : ℝ)^2 + N = (Real.sqrt P.d*(Y : ℝ))^2 ∧
    Section2.omega S (2*X) (2*Z) = P.sequenceOmega h.pell k := by
  dsimp only
  have hν := AnyBNormSquare.unitPowerNorm_sign P h.pell k
  have hC := (squareFactor_pos hn.ne).ne'
  have hS : (squarefreePart P.normAlpha : ℝ) < 0 := by exact_mod_cast squarefreePart_neg hn
  have hN : (P.normAlpha : ℝ) < 0 := by exact_mod_cast hn
  refine ⟨mul_ne_zero (by rcases hν with he|he <;> rw [he] <;> decide) hC, ?_, ?_, ?_⟩
  · have hf : (squareFactor P.normAlpha : ℝ)^2 * (squarefreePart P.normAlpha : ℝ) = P.normAlpha :=
      by exact_mod_cast squareFactor_sq_mul P.normAlpha
    rw [abs_of_neg hS,abs_of_neg hN]
    rcases hν with he|he <;> simp [he,hf]
  · have hh := P.norm_identity h.pell k
    rw [hx,hy] at hh
    have he : (X : ℝ)^2 - P.d*(Y : ℝ)^2 = P.normAlpha := by exact_mod_cast hh
    rw [mul_pow,Real.sq_sqrt (by exact_mod_cast h.d_pos.le),abs_of_neg hN]
    linarith
  · unfold Parameters.sequenceOmega conjugateRatio Section2.omega
    congr 2
    all_goals
      apply Complex.ext
      · simp [Section2.U_re,hx]
      · have hν' : (AnyBNormSquare.unitPowerNorm P k : ℝ) = ((P.epsilonNorm^k : ℚ) : ℝ) := by
          exact_mod_cast AnyBNormSquare.unitPowerNorm_cast P h.pell k
        simp [Section2.U_im, Parameters.negativeNormRoot,hν',mul_assoc]

/-- Equations (4.6)–(4.11), using the same selected index for every parameter. -/
theorem section42_parameters {P : Parameters} (h : P.Admissible) (hn : P.normAlpha < 0)
    {k X Y : ℤ} (hk : k ≠ 0) (hs : IsIntegerSquare (P.y h.pell k))
    (hx : P.x h.pell k = (X : ℚ)) (hy : P.y h.pell k = (Y : ℚ))
    (hsize : 16*|(P.normAlpha : ℝ)|/Real.sqrt P.d ≤ (Y : ℝ)) :
    let S := squarefreePart P.normAlpha
    let u := 2*X
    let v := 2*(AnyBNormSquare.unitPowerNorm P k*squareFactor P.normAlpha)
    let M := Approximation.normalizerProduct S u v
    let L := Real.sqrt P.d*(Y : ℝ)
    let N := |(P.normAlpha : ℝ)|
    (15/16 : ℝ)*P.d*(Y : ℝ)^2 ≤ (X : ℝ)^2 ∧ Real.sqrt ((X : ℝ)^2+N) = L ∧
    L < (104/100 : ℝ)*|(X : ℝ)| ∧
    (1832/10000 : ℝ)*M*L/N < Section2.E S u v ∧ 5.86 < Section2.E S u v ∧
    2*Real.exp (168/100)*(1+Real.sqrt (9375/10000))*L/M ≤ Section2.Q S u v ∧
    (2112/100 : ℝ)*L/M < 2*Real.exp (168/100)*(1+Real.sqrt (9375/10000))*L/M ∧
    (2112/100 : ℝ) ≤ (2112/100 : ℝ)*L/M ∧ Section2.Q S u v < (2147/100 : ℝ)*L/M ∧
    Section2.ell S u v < (615/1000 : ℝ)*Real.sqrt N/|(X : ℝ)| ∧ ‖Section2.omega S u v-1‖ < 1 := by
  let S := squarefreePart P.normAlpha
  let Z := AnyBNormSquare.unitPowerNorm P k*squareFactor P.normAlpha
  let M := Approximation.normalizerProduct S (2*X) (2*Z)
  let L := Real.sqrt P.d*(Y : ℝ)
  let N := |(P.normAlpha : ℝ)|
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hN : 0 < N := abs_pos.mpr (by exact_mod_cast hn.ne)
  have hS : (S : ℝ) < 0 := by exact_mod_cast squarefreePart_neg hn
  obtain ⟨_,hscale,hcoord,hw⟩ := section42_coordinates h hn hx hy
  have hZ : (Z : ℝ)^2 * |(S : ℝ)| = N := hscale
  have hc : (X : ℝ)^2 + N = L^2 := hcoord
  have hml := section41_normalizer h hn hk hx hy hsize
  have hM2 : 2 ≤ M := by simpa only [M,S,Z,mul_assoc] using hml.1
  have hM : 0 < M := by linarith
  have hML : M ≤ L := by
    have hh := (div_le_iff₀ (Real.sqrt_pos.mpr hd)).mp ((le_max_right _ _).trans hml.2)
    simpa only [L,M,S,Z,mul_assoc,mul_comm (Y : ℝ)] using hh
  have hL16 : 16*N ≤ L := by
    simpa only [L,mul_comm (Y : ℝ)] using (div_le_iff₀ (Real.sqrt_pos.mpr hd)).mp hsize
  have hL : 0 < L := by linarith
  have hy0 : 4*Real.sqrt (N/P.d) ≤ (Y : ℝ) :=
    AnyBNormSquare.Prerequisites.threshold_implies_coordinate_size P h hn ((le_max_left _ _).trans hml.2)
  have hLsq : L^2 = P.d*(Y : ℝ)^2 := by rw [show L= _ from rfl,mul_pow,Real.sq_sqrt hd.le]
  obtain ⟨ha,hb,hc'⟩ := AnyBNormSquare.Prerequisites.coordinate_bounds hN hd hy0
    (show (X : ℝ)^2 = P.d*(Y : ℝ)^2-N by linarith only [hc,hLsq])
  have hlow : (15/16 : ℝ)*L^2 ≤ (X : ℝ)^2 := by rwa [hLsq,← mul_assoc]
  have hhigh : |(X : ℝ)| < L := by nlinarith [sq_abs (X : ℝ),abs_nonneg (X : ℝ)]
  have hroot : Real.sqrt (Section2.H S (2*X) (2*Z)) = 2*L := by
    have he : Section2.H S (2*X) (2*Z) = (2*L)^2 := by
      unfold Section2.H
      push_cast
      rw [abs_of_neg hS] at hZ
      nlinarith only [hZ,hc]
    rw [he,Real.sqrt_sq (by positivity)]
  have hQform : Section2.Q S (2*X) (2*Z) = 2*Real.exp (42/25)*(|(X : ℝ)|+L)/M := by
    unfold Section2.Q
    rw [hroot]; push_cast; rw [abs_mul]; norm_num; ring
  have hEform : Section2.E S (2*X) (2*Z) = M*(|(X : ℝ)|+L)/(2*Real.exp (42/25)*N) := by
    unfold Section2.E
    rw [hroot,← hZ]; push_cast; rw [abs_mul]; norm_num; dsimp only [M]; ring
  have hbounds := AnyBNormSquare.Prerequisites.parameter_bounds hN hM hL hlow hhigh
  rw [← hEform,← hQform] at hbounds
  have hE : (5.86 : ℝ) < Section2.E S (2*X) (2*Z) := by
    apply lt_trans _ hbounds.1
    apply (lt_div_iff₀ hN).mpr
    have hh := mul_le_mul hM2 hL16 (by positivity : 0 ≤ 16*N) hM.le
    linarith
  have hchain := AnyBNormSquare.Revision06f.Q_lower_chain hM hL hlow hML
  have hstrong : 4*Real.sqrt (N/P.d) ≤ (P.y h.pell k : ℝ) := by simpa only [hy,Rat.cast_intCast] using hy0
  have hang := (lemma35a P h hn hs hstrong).1
  rw [hx] at hang
  push_cast at hang
  have hangle := mul_lt_mul_of_pos_left hang (by norm_num : (0 : ℝ) < 537/2000)
  refine ⟨ha,hb,hc',hbounds.1,hE,?_,hchain.2.1,hchain.2.2,hbounds.2,?_,?_⟩
  · rw [hQform,show (42/25 : ℝ) = 168/100 by norm_num]; exact hchain.1
  · rw [Section2.ell,hw]
    apply hangle.trans_le
    rw [← mul_div_assoc, ← mul_assoc]
    apply div_le_div_of_nonneg_right _ (abs_nonneg _)
    apply mul_le_mul_of_nonneg_right _ (Real.sqrt_nonneg _)
    norm_num
  · rw [hw]; exact AnyBNormSquare.section41_near_one P h hn hs hstrong

end AnyBAnyNorm
