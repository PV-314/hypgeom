module

public import AnyBAnyNorm.Construction

@[expose] public section
namespace AnyBAnyNorm.Construction
open «JNT-2024» «JNT-2024».Hypergeometric Polynomial

/-- Numerators allowed in the opening paragraph of §2.1. -/
def numerators (n : ℕ) : Finset ℕ :=
  (Finset.range n).filter fun m => 0 < m ∧ 2*m < n ∧ m.Coprime n

def commonDenominator (n r : ℕ) : ℕ :=
  (numerators n).lcm fun m => (Finset.range (r+1)).lcm fun j => (coefficient ((m:ℚ)/n) r j).den

theorem commonDenominator_spec (n r D : ℕ) :
    commonDenominator n r ∣ D ↔ ∀ m ∈ numerators n, ∀ j,
      ∃ z : ℤ, (z : ℚ) = (D : ℚ)*coefficient ((m:ℚ)/n) r j := by
  simp only [commonDenominator,Finset.lcm_dvd_iff,rat_den_dvd_iff_integer_mul]
  constructor
  · intro h m hm j
    by_cases hj : j < r+1
    · exact h m hm j (Finset.mem_range.mpr hj)
    · rw [coefficient_vanishes _ (by omega : r < j)]; exact ⟨0,by simp⟩
  · exact fun h m hm j _ => h m hm j

theorem commonDenominator_pos (n r : ℕ) : 0 < commonDenominator n r := by
  apply Nat.pos_of_ne_zero; simp [commonDenominator]

theorem commonDenominator_least (n r : ℕ) :
    IsLeast {D : ℕ | 0 < D ∧ ∀ m ∈ numerators n, ∀ j,
      ∃ z : ℤ, (z : ℚ) = (D : ℚ)*coefficient ((m:ℚ)/n) r j} (commonDenominator n r) :=
  ⟨⟨commonDenominator_pos n r,(commonDenominator_spec ..).1 dvd_rfl⟩,
   fun _ h => Nat.le_of_dvd h.1 ((commonDenominator_spec ..).2 h.2)⟩

noncomputable def cleared (m n r : ℕ) : Polynomial ℤ :=
  ∑ j ∈ Finset.range (r+1), monomial j (((commonDenominator n r : ℚ)*coefficient ((m:ℚ)/n) r j).num)

private theorem cleared_coeff (m n r j : ℕ) (hm : m ∈ numerators n) :
    ((cleared m n r).coeff j : ℚ) = (commonDenominator n r : ℚ)*coefficient ((m:ℚ)/n) r j := by
  by_cases hj : j < r+1
  · obtain ⟨a,ha⟩ := (commonDenominator_spec n r _).1 dvd_rfl m hm j
    simp [cleared,coeff_monomial,hj,← ha]
  · simp [cleared,coeff_monomial,hj,coefficient_vanishes _ (by omega : r < j)]

theorem cleared_map (m n r : ℕ) (hm : m ∈ numerators n) :
    (cleared m n r).map (Int.castRingHom ℚ) = (commonDenominator n r : Polynomial ℚ)*Xpoly ((m:ℚ)/n) r := by
  ext j
  simp only [coeff_map,Int.coe_castRingHom,coeff_natCast_mul,Xpoly_coeff,cleared_coeff _ _ _ _ hm]

noncomputable def shifted (m n r : ℕ) := (cleared m n r).comp (1-Polynomial.X)

/-- Coefficient of 1 for even j or of √sf(d) for odd j after x ↦ √d x
in the shifted polynomial. This is JNT's integral-coordinate convention. -/
noncomputable def scaledCoefficient (d : ℤ) (m n r j : ℕ) : ℤ :=
  (shifted m n r).coeff j * d^(j/2) * squareFactor d^(j%2)

noncomputable def commonContent (d : ℤ) (n r : ℕ) : ℕ :=
  (numerators n).gcd fun m => (shifted m n r).support.gcd fun j => (scaledCoefficient d m n r j).natAbs

theorem commonContent_spec (d : ℤ) (n r c : ℕ) :
    c ∣ commonContent d n r ↔ ∀ m ∈ numerators n, ∀ j, (c : ℤ) ∣ scaledCoefficient d m n r j := by
  simp only [commonContent,Finset.dvd_gcd_iff]
  constructor
  · intro h m hm j
    by_cases hj : j ∈ (shifted m n r).support
    · exact Int.natCast_dvd.mpr (h m hm j hj)
    · simp [scaledCoefficient,Polynomial.notMem_support_iff.mp hj]
  · exact fun h m hm j _ => Int.natCast_dvd.mp (h m hm j)

theorem commonContent_pos {d : ℤ} (hd : d ≠ 0) {n r m : ℕ} (hm : m ∈ numerators n) :
    0 < commonContent d n r := by
  have hpoly : shifted m n r ≠ 0 := by
    intro hh
    have he := congrArg (fun p : Polynomial ℤ => p.eval 1) hh
    have hz : (cleared m n r).coeff 0 = 0 := by simpa [shifted,coeff_zero_eq_eval_zero] using he
    have h := cleared_coeff m n r 0 hm
    rw [hz,coefficient_zero] at h
    have hp : (0 : ℚ) < commonDenominator n r := by exact_mod_cast commonDenominator_pos n r
    exact hp.ne' (by simpa only [Int.cast_zero,mul_one] using h.symm)
  obtain ⟨j,hj⟩ := (Polynomial.support_nonempty.mpr hpoly)
  apply Nat.pos_of_ne_zero
  rw [commonContent,Finset.gcd_ne_zero_iff]
  refine ⟨m,hm,Finset.gcd_ne_zero_iff.mpr ⟨j,hj,?_⟩⟩
  exact Int.natAbs_ne_zero.mpr (mul_ne_zero (mul_ne_zero (Polynomial.mem_support_iff.mp hj) (pow_ne_zero _ hd))
    (pow_ne_zero _ (squareFactor_pos hd).ne'))

theorem commonContent_greatest {d : ℤ} (hd : d ≠ 0) {n r m : ℕ} (hm : m ∈ numerators n) :
    IsGreatest {c : ℕ | 0 < c ∧ ∀ i ∈ numerators n, ∀ j, (c : ℤ) ∣ scaledCoefficient d i n r j}
      (commonContent d n r) :=
  ⟨⟨commonContent_pos hd hm,(commonContent_spec ..).1 dvd_rfl⟩,
    fun _ h => Nat.le_of_dvd (commonContent_pos hd hm) ((commonContent_spec ..).2 h.2)⟩

theorem commonDenominator_four (r : ℕ) : commonDenominator 4 r = denominator4 r := by
  simp [commonDenominator,show numerators 4={1} by decide,denominator4]

theorem commonContent_four (d : ℤ) (r : ℕ) : commonContent d 4 r = numeratorContent4 d r := by
  have he : cleared 1 4 r=integralPolynomial4 r := by
    simp [cleared,integralPolynomial4,integralCoefficient4,commonDenominator_four]
  have hsf (j : ℕ) : scaledCoefficient d 1 4 r j=scaledIntegralCoefficient4 d r j := by
    simp [scaledCoefficient,shifted,he,scaledIntegralCoefficient4,shiftedIntegralPolynomial4]
  apply Nat.dvd_antisymm
  · apply (numeratorContent4_dvd_iff ..).2
    intro j; rw [← hsf]; exact (commonContent_spec ..).1 dvd_rfl 1 (by decide) j
  · apply (commonContent_spec ..).2
    intro m hm j
    rw [show numerators 4={1} by decide,Finset.mem_singleton] at hm
    subst m; rw [hsf]; exact (numeratorContent4_dvd_iff ..).1 dvd_rfl j

/-- The prime product in (2.1), including its rational-valuation convention. -/
noncomputable def primeProduct (q : ℚ) (n : ℕ) : ℝ :=
  ∏ p ∈ n.primeFactors, (p : ℝ)^min ((padicValRat p q : ℝ)/2)
    ((padicValNat p n : ℝ)+1/((p : ℝ)-1))

theorem primeProduct_four (q : ℚ) : primeProduct q 4 = «JNT-2024».Approximation.N4 q := by
  rw [AnyBNormSquare.Lemma35Proof.N4_eq_paper]
  have hpr : (4 : ℕ).primeFactors = {2} := by
    rw [show (4 : ℕ)=2^(1+1) by decide,Nat.primeFactors_pow_succ,Nat.prime_two.primeFactors]
  have hv : padicValNat 2 4=2 := by
    rw [show (4 : ℕ)=2^2 by decide,padicValNat.prime_pow]
  norm_num [primeProduct,hpr,hv]

end AnyBAnyNorm.Construction
