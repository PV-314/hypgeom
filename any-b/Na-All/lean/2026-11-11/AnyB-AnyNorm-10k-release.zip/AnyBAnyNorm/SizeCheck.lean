module

public import AnyBAnyNorm.PostJava
public import AnyBAnyNorm.SequenceLemmas
public import Mathlib.Data.Nat.Sqrt

@[expose] public section
namespace AnyBAnyNorm.Section56
open «JNT-2024»

/-- A row from the Java output, with witnesses for K and for the finite
range sufficient to check the strict size comparison in 07g, §5.6. -/
structure SizeRow where
  params : Parameters
  K : ℤ
  radius : ℕ

def SizeRow.indices (r : SizeRow) : List ℤ :=
  (List.range (2*r.radius+1)).map fun (i : ℕ) => (i : ℤ) - r.radius

theorem mem_indices (r : SizeRow) (k : ℤ) :
    k ∈ r.indices ↔ -(r.radius : ℤ) ≤ k ∧ k ≤ r.radius := by
  unfold SizeRow.indices
  rw [List.mem_map]
  constructor
  · rintro ⟨i,hi,rfl⟩
    have hbound := List.mem_range.mp hi
    omega
  · rintro ⟨hl,hr⟩
    exact ⟨(k+r.radius).toNat,List.mem_range.mpr (by omega),by omega⟩

/-- Use the imported JNT sequence at its actual (possibly negative) index. -/
def SizeRow.value (r : SizeRow) (k : ℤ) : ℚ :=
  if h : r.params.t^2-r.params.d*r.params.u^2=4 ∨ r.params.t^2-r.params.d*r.params.u^2= -4 then
    r.params.y h k else 0

theorem value_eq (r : SizeRow) (h : r.params.Pell) (k : ℤ) :
    r.value k = r.params.y h k := by simp [SizeRow.value,show r.params.t^2-r.params.d*r.params.u^2=4 ∨ r.params.t^2-r.params.d*r.params.u^2= -4 from h]

def below (P : Parameters) (y : ℚ) : Prop := (P.d : ℚ)*y^2 < 256*(P.normAlpha : ℚ)^2
instance (P : Parameters) (y : ℚ) : Decidable (below P y) := inferInstanceAs (Decidable (_ < _))

private theorem below_iff {P : Parameters} (hd : 0 < P.d) {y : ℚ} (hy : 0 ≤ y) :
    below P y ↔ (y : ℝ) < 16*|(P.normAlpha : ℝ)|/Real.sqrt P.d := by
  have hd' : (0 : ℝ) < P.d := by exact_mod_cast hd
  have hy' : (0 : ℝ) ≤ y := by exact_mod_cast hy
  rw [lt_div_iff₀ (Real.sqrt_pos.mpr hd'), ← sq_lt_sq₀ (by positivity) (by positivity)]
  rw [mul_pow, Real.sq_sqrt hd'.le, mul_pow, sq_abs]
  unfold below
  norm_num
  rw [mul_comm ((y : ℝ)^2)]
  exact_mod_cast Iff.rfl

def integerSquareTest (y : ℚ) : Bool := decide (y = (y.num.natAbs.sqrt : ℚ)^2)

private theorem square_test {y : ℚ} : integerSquareTest y = true ↔ IsIntegerSquare y := by
  simp only [integerSquareTest, decide_eq_true_eq]
  constructor
  · intro h
    exact ⟨(y.num.natAbs.sqrt : ℤ),by simpa using h⟩
  · rintro ⟨z,rfl⟩
    rw [← Int.cast_pow, Rat.num_intCast, Int.natAbs_pow, Nat.sqrt_eq']
    simp

def SizeRow.small (r : SizeRow) : Bool := r.indices.any fun k =>
  decide (3 ≤ k ∨ k ≤ r.K-2) && integerSquareTest (r.value k) && decide (below r.params (r.value k))

/-- Check both ends of the interval and the manuscript definition of K. -/
def SizeRow.valid (r : SizeRow) : Bool :=
  decide (r.K < 0 ∧ -(r.radius : ℤ) ≤ r.K ∧ (r.params.b : ℚ)^2 < r.value r.K) &&
  r.indices.all (fun k => decide (r.K < k → k < 0 → r.value k ≤ (r.params.b : ℚ)^2)) &&
  decide (¬below r.params (r.value r.radius) ∧ ¬below r.params (r.value (-(r.radius : ℤ))))

/-- The finite test is equivalent to the existence assertion in the new paragraph. -/
theorem small_iff (r : SizeRow) (h : r.params.Admissible) (hn : r.params.normAlpha < 0)
    (hv : r.valid = true) (K : ℤ) (hK : r.params.IsNegativeCutoff h.pell K) :
    r.small = true ↔ ∃ k : ℤ, (3 ≤ k ∨ k ≤ K-2) ∧ IsIntegerSquare (r.params.y h.pell k) ∧
      (r.params.y h.pell k : ℝ) < 16*|(r.params.normAlpha : ℝ)|/Real.sqrt r.params.d := by
  simp only [SizeRow.valid,Bool.and_eq_true,decide_eq_true_eq,List.all_eq_true,value_eq r h.pell] at hv
  obtain ⟨⟨⟨hneg,hlo,hbase⟩,hmiddle⟩,hplus,hminus⟩ := hv
  have hc : r.params.IsNegativeCutoff h.pell r.K :=
    ⟨hneg,hbase,fun j hj hj' => hmiddle j ((mem_indices r j).2 ⟨by omega,by omega⟩) hj hj'⟩
  obtain ⟨hp,hpos,huni,hback⟩ := lemma33a r.params h hn
  have heq := huni.unique hc hK
  subst K
  have hy (k : ℤ) : 0 ≤ r.params.y h.pell k := by
    obtain ⟨v,hv,he⟩ := hp k
    have : (0 : ℚ) < v := by exact_mod_cast hv
    linarith
  have cmp (k : ℤ) := below_iff (P := r.params) h.d_pos (hy k)
  simp only [SizeRow.small,List.any_eq_true,Bool.and_eq_true,decide_eq_true_eq,square_test,value_eq r h.pell,cmp]
  constructor
  · rintro ⟨k,_,⟨hk,hs⟩,hl⟩
    exact ⟨k,hk,hs,hl⟩
  · rintro ⟨k,hk,hs,hl⟩
    refine ⟨k,(mem_indices r k).2 ⟨?_,?_⟩,⟨hk,hs⟩,hl⟩
    · by_contra! hout
      have hmono := (hback r.K hc).monotone
        (show (r.K+1+r.radius).toNat ≤ (r.K+1-k).toNat by omega)
      rw [show r.K+1-↑(r.K+1+r.radius).toNat = -(r.radius : ℤ) by omega,
          show r.K+1-↑(r.K+1-k).toNat = k by omega] at hmono
      exact hminus ((cmp _).2 ((show (r.params.y h.pell (-(r.radius : ℤ)) : ℝ) ≤ (r.params.y h.pell k : ℝ) by exact_mod_cast hmono).trans_lt hl))
    · by_contra! hout
      have hmono := hpos.monotone (show r.radius ≤ k.toNat by omega)
      rw [Int.toNat_of_nonneg (by omega)] at hmono
      exact hplus ((cmp _).2 ((show (r.params.y h.pell r.radius : ℝ) ≤ (r.params.y h.pell k : ℝ) by exact_mod_cast hmono).trans_lt hl))

end AnyBAnyNorm.Section56
