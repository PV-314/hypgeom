module

public import «JNT-2024».NumberFieldBridge

public import Mathlib.AlgebraicGeometry.EllipticCurve.Affine.Basic
public import Mathlib.Algebra.Polynomial.Roots
public import Mathlib.Tactic.LinearCombination

/-! The quartic in §1.1. Write its equation as X² = A Y⁴ + k and
choose the given rational point (q,h). The formulas below are over the
coefficient field and therefore also apply after extension of scalars. -/

@[expose] public section
namespace AnyBAnyNorm.QuarticModel

variable {F : Type*} [Field F]

theorem normalize (a b c X Y : F) (ha : a ≠ 0) :
    a * X^2 - b * Y^4 = c ↔ X^2 = (b/a) * Y^4 + c/a := by
  field_simp
  constructor <;> intro e <;> linear_combination e

/-- For a translated quartic with coefficients A, B, C, D, q²,
the coefficients of the corresponding Weierstrass equation. -/
def weierstrass (A B C D q : F) : WeierstrassCurve F :=
  ⟨0, C, 0, B*D - 4*A*q^2, q^2*B^2 + A*D^2 - 4*A*C*q^2⟩

theorem isElliptic [CharZero F] (A k h q : F) (hA : A ≠ 0) (hk : k ≠ 0)
    (point : q^2 = A*h^4 + k) :
    (weierstrass A (4*A*h) (6*A*h^2) (4*A*h^3) q).IsElliptic := by
  have disc : (weierstrass A (4*A*h) (6*A*h^2) (4*A*h^3) q).Δ =
      4096 * A^3 * k^3 := by
    simp only [WeierstrassCurve.Δ, WeierstrassCurve.b₂, WeierstrassCurve.b₄,
      WeierstrassCurve.b₆, WeierstrassCurve.b₈, weierstrass, point]
    ring
  constructor
  rw [disc, isUnit_iff_ne_zero]
  exact mul_ne_zero (mul_ne_zero (by norm_num) (pow_ne_zero _ hA)) (pow_ne_zero _ hk)

/-- s = Y − h and X = s z − q. The shifted equation has a factor s
after introducing z; the birational change is used on s ≠ 0. -/
theorem translate (A k h q s z : F) (point : q^2 = A*h^4 + k) (hs : s ≠ 0) :
    (s*z-q)^2 = A*(s+h)^4 + k ↔
      s*z^2 = A*s^3 + (4*A*h)*s^2 + (6*A*h^2)*s + 4*A*h^3 + 2*q*z := by
  constructor
  · intro e
    apply mul_left_cancel₀ hs
    linear_combination e - point
  · intro e
    linear_combination s*e + point

/-- The relation between the two pairs of affine coordinates is linear
in (s,z) when the Weierstrass coordinates (x,y) are given. -/
def Coordinates (A B D q s z x y : F) : Prop :=
  x*s = 2*q*z+D ∧ y = x*z-2*A*q*s-B*q

theorem forwardCoordinates (A B D q s z : F) (hs : s ≠ 0) :
    let x := (2*q*z+D)/s
    Coordinates A B D q s z x (x*z-2*A*q*s-B*q) := by
  exact ⟨div_mul_cancel₀ _ hs, rfl⟩

theorem inverseCoordinates (A B D q x y : F) (hd : x^2-4*A*q^2 ≠ 0) :
    Coordinates A B D q ((D*x+2*q*(y+B*q))/(x^2-4*A*q^2))
      ((2*A*q*D+x*(y+B*q))/(x^2-4*A*q^2)) x y := by
  generalize ht : x^2-4*A*q^2 = t at hd ⊢
  constructor <;> field_simp [hd] <;> rw [← ht] <;> ring

theorem recoverQuartic (A B D q s z x y : F) (e : Coordinates A B D q s z x y)
    (hd : x^2-4*A*q^2 ≠ 0) :
    s = (D*x+2*q*(y+B*q))/(x^2-4*A*q^2) ∧
    z = (2*A*q*D+x*(y+B*q))/(x^2-4*A*q^2) := by
  obtain ⟨e₁,e₂⟩ := e
  constructor <;> apply (eq_div_iff hd).2
  · linear_combination x*e₁ - 2*q*e₂
  · linear_combination 2*A*q*e₁ - x*e₂

theorem recoverWeierstrass (A B D q s z x y : F) (e : Coordinates A B D q s z x y)
    (hs : s ≠ 0) : x = (2*q*z+D)/s ∧ y = x*z-2*A*q*s-B*q :=
  ⟨(eq_div_iff hs).2 e.1, e.2⟩

theorem equations (A B C D q s z x y : F) (e : Coordinates A B D q s z x y)
    (hs : s ≠ 0) (hd : x^2-4*A*q^2 ≠ 0) :
    s*z^2 = A*s^3 + B*s^2 + C*s + D + 2*q*z ↔
      (weierstrass A B C D q).toAffine.Equation x y := by
  obtain ⟨e₁,e₂⟩ := e
  have d : D = x*s-2*q*z := by linear_combination -e₁
  subst D
  subst y
  rw [WeierstrassCurve.Affine.equation_iff']
  change _ ↔ _^2 + 0*x*_ + 0*_ -
    (x^3+C*x^2+(B*(x*s-2*q*z)-4*A*q^2)*x+
     (q^2*B^2+A*(x*s-2*q*z)^2-4*A*C*q^2)) = 0
  have fact : (x*z-2*A*q*s-B*q)^2 + 0*x*(x*z-2*A*q*s-B*q) +
      0*(x*z-2*A*q*s-B*q) - (x^3+C*x^2+(B*(x*s-2*q*z)-4*A*q^2)*x+
      (q^2*B^2+A*(x*s-2*q*z)^2-4*A*C*q^2)) =
      (x^2-4*A*q^2)*(z^2-A*s^2-B*s-C-x) := by ring
  rw [fact, mul_eq_zero, or_iff_right hd]
  constructor
  · intro h
    apply (mul_eq_zero.mp (show s*(z^2-A*s^2-B*s-C-x) = 0 by
      linear_combination h)).resolve_left hs
  · intro h
    linear_combination s*h

/-- Eliminating x when x² = 4Aq² gives this polynomial in s. -/
def exceptional {R : Type*} [CommRing R] (A B C D q s : R) : R :=
  (D^2-4*q^2*C-4*q^2*B*s)^2 - 4*A*q^2*(2*D*s+4*q^2)^2

theorem exceptional_eq_zero (A B C D q s z x : F)
    (e : x*s = 2*q*z+D) (h : z^2 = A*s^2+B*s+C+x) (hd : x^2 = 4*A*q^2) :
    exceptional A B C D q s = 0 := by
  have eqD : D = x*s-2*q*z := by linear_combination -e
  have m : D^2-4*q^2*C-4*q^2*B*s = x*(2*D*s+4*q^2) := by
    rw [eqD]
    linear_combination 4*q^2*h - s^2*hd
  rw [exceptional, m, mul_pow, hd]
  ring

/-- For all but finitely many translated quartic abscissae the two
denominators in the coordinate changes are nonzero. -/
theorem quartic_denominators [CharZero F] (A k h q : F) (hA : A ≠ 0) (hk : k ≠ 0)
    (point : q^2 = A*h^4+k) :
    ∀ᶠ s in Filter.cofinite, s ≠ 0 ∧ ∀ z x : F,
      x*s = 2*q*z+4*A*h^3 → z^2 = A*s^2+(4*A*h)*s+6*A*h^2+x →
      x^2-4*A*q^2 ≠ 0 := by
  let p := exceptional (Polynomial.C A) (Polynomial.C (4*A*h))
    (Polynomial.C (6*A*h^2)) (Polynomial.C (4*A*h^3)) (Polynomial.C q) Polynomial.X
  have ev (s : F) : p.eval s = exceptional A (4*A*h) (6*A*h^2) (4*A*h^3) q s := by
    simp [p, exceptional]
  have hp : p ≠ 0 := by
    intro zero
    have ez (s : F) : exceptional A (4*A*h) (6*A*h^2) (4*A*h^3) q s = 0 := by
      rw [← ev, zero, Polynomial.eval_zero]
    by_cases hq : q = 0
    · subst q
      have hh : h ≠ 0 := by rintro rfl; simp_all
      have := ez 0
      simp [exceptional, hA, hh] at this
    by_cases hh : h = 0
    · subst h
      have := ez 0
      simp [exceptional, hA, hq] at this
    have nonzero : 512*q^2*A^2*h^2*(q^2-A*h^4) ≠ 0 := by
      rw [point, add_sub_cancel_left]
      exact mul_ne_zero (mul_ne_zero (mul_ne_zero (mul_ne_zero (by norm_num)
        (by rw [← point]; exact pow_ne_zero _ hq)) (pow_ne_zero _ hA)) (pow_ne_zero _ hh)) hk
    apply nonzero
    have e₁ := ez 1
    have e₂ := ez (-1)
    have e₀ := ez 0
    unfold exceptional at e₁ e₂ e₀
    linear_combination e₁ + e₂ - 2*e₀
  filter_upwards [Polynomial.eventually_eval_ne_zero_cofinite hp,
    Polynomial.eventually_eval_ne_zero_cofinite (Polynomial.X_ne_zero (R := F))] with s he hs
  refine ⟨by simpa using hs, ?_⟩
  intro z x e h' zero
  exact he ((ev s).trans (exceptional_eq_zero _ _ _ _ _ _ _ _ e h' (sub_eq_zero.mp zero)))

/-- On the cubic, the inverse change only needs to exclude finitely many
x-coordinates, including the values for which the recovered s could vanish. -/
theorem weierstrass_denominators [CharZero F] (A k h q : F) (hA : A ≠ 0) (hk : k ≠ 0)
    (point : q^2 = A*h^4+k) :
    ∀ᶠ x in Filter.cofinite, x^2-4*A*q^2 ≠ 0 ∧ ∀ y : F,
      (weierstrass A (4*A*h) (6*A*h^2) (4*A*h^3) q).toAffine.Equation x y →
      (4*A*h^3)*x+2*q*(y+(4*A*h)*q) ≠ 0 := by
  let p : Polynomial F := Polynomial.X^2 - Polynomial.C (4*A*q^2)
  let r : Polynomial F := Polynomial.C ((4*A*h^3)^2) -
    Polynomial.C (4*q^2) * (Polynomial.X + Polynomial.C (6*A*h^2))
  have hp : p ≠ 0 := by
    intro e
    have u := congrArg (fun f : Polynomial F => f.coeff 2) e
    simp only [p, Polynomial.coeff_sub, Polynomial.coeff_X_pow_self,
      Polynomial.coeff_C_of_ne_zero (by decide : (2:ℕ) ≠ 0),
      sub_zero, Polynomial.coeff_zero, one_ne_zero] at u
  have hr : r ≠ 0 := by
    intro e
    have u := congrArg (Polynomial.eval (1:F)) e
    have v := congrArg (Polynomial.eval (0:F)) e
    simp [r] at u v
    have qq : 4*q^2 = 0 := by linear_combination v - u
    have hq : q = 0 := by simpa using qq
    subst q
    have hh : h ≠ 0 := by rintro rfl; simp_all
    simp [hA, hh] at v
  filter_upwards [Polynomial.eventually_eval_ne_zero_cofinite hp,
    Polynomial.eventually_eval_ne_zero_cofinite hr] with x hd hn
  simp [p] at hd
  simp [r] at hn
  refine ⟨hd, ?_⟩
  intro y he hy
  rw [WeierstrassCurve.Affine.equation_iff'] at he
  simp only [weierstrass, zero_mul, add_zero] at he
  apply (mul_ne_zero hd hn)
  linear_combination ((4*A*h^3)*x-2*q*(y-(4*A*h)*q))*hy + 4*q^2*he

/-- The nonsingular Weierstrass equation and rational changes of variables at (q,h). -/
abbrev QuarticModelAt (a b c q h : F) : Prop :=
    let A := b/a
    let B := 4*A*h
    let C := 6*A*h^2
    let D := 4*A*h^3
    let W := weierstrass A B C D q
    W.IsElliptic ∧
    (∀ᶠ s in Filter.cofinite, ∀ X : F, a*X^2-b*(s+h)^4 = c →
      let z := (X+q)/s
      let x := (2*q*z+D)/s
      let y := x*z-2*A*q*s-B*q
      s ≠ 0 ∧ x^2-4*A*q^2 ≠ 0 ∧ W.toAffine.Equation x y ∧
      Coordinates A B D q s z x y) ∧
    (∀ᶠ x in Filter.cofinite, ∀ y : F, W.toAffine.Equation x y →
      let s := (D*x+2*q*(y+B*q))/(x^2-4*A*q^2)
      let z := (2*A*q*D+x*(y+B*q))/(x^2-4*A*q^2)
      s ≠ 0 ∧ x^2-4*A*q^2 ≠ 0 ∧ a*(s*z-q)^2-b*(s+h)^4 = c ∧
      Coordinates A B D q s z x y)

/-- §1.1, lines 145–147. The given rational solution (q,h) specifies the
coordinate change. Each direction is rational on a dense open subset:
only finitely many abscissae are excluded, over every characteristic-zero
field. The two recovery lemmas give the inverses on their common domain. -/
theorem quarticModel [CharZero F] (a b c q h : F) (habc : a*b*c ≠ 0)
    (point : a*q^2-b*h^4 = c) :
    QuarticModelAt a b c q h := by
  have ha : a ≠ 0 := by rintro rfl; simp at habc
  have hb : b ≠ 0 := by rintro rfl; simp at habc
  have hc : c ≠ 0 := by rintro rfl; simp at habc
  have hA := div_ne_zero hb ha
  have hk := div_ne_zero hc ha
  have hp := (normalize a b c q h ha).mp point
  refine ⟨isElliptic _ _ _ _ hA hk hp, ?_, ?_⟩
  · filter_upwards [quartic_denominators _ _ _ _ hA hk hp] with s den
    intro X he
    let A := b/a
    let B := 4*A*h
    let C := 6*A*h^2
    let D := 4*A*h^3
    let z := (X+q)/s
    let x := (2*q*z+D)/s
    have hz : s*z-q = X := by dsimp [z]; field_simp [den.1]; ring
    have hquartic := (translate _ _ _ _ s z hp den.1).mp
      (hz ▸ (normalize _ _ _ _ _ ha).mp he)
    have coord := forwardCoordinates A B D q s z den.1
    have hz₂ : z^2 = A*s^2+B*s+C+x := by
      apply mul_left_cancel₀ den.1
      linear_combination hquartic - coord.1
    have hd := den.2 z x coord.1 hz₂
    exact ⟨den.1, hd, (equations A B C D q s z x _ coord den.1 hd).mp hquartic, coord⟩
  · filter_upwards [weierstrass_denominators _ _ _ _ hA hk hp] with x den
    intro y he
    have hs := div_ne_zero (den.2 y he) den.1
    have coord := inverseCoordinates (b/a) (4*(b/a)*h) (4*(b/a)*h^3) q x y den.1
    have hquartic := (equations _ _ (6*(b/a)*h^2) _ _ _ _ _ _ coord hs den.1).mpr he
    exact ⟨hs, den.1, (normalize _ _ _ _ _ ha).mpr
      ((translate _ _ _ _ _ _ hp hs).mpr hquartic), coord⟩

/-- The sequence of §1.2 supplies the rational point (a,b) of the §1.1 quartic. -/
theorem sequenceQuarticModel (P : «JNT-2024».Parameters) (h : P.Admissible) :
    QuarticModelAt (1 : ℚ) P.d P.normAlpha P.a P.b := by
  have hb : (P.b : ℚ) ≠ 0 := by exact_mod_cast h.b_pos.ne'
  have hd : (P.d : ℚ) ≠ 0 := by exact_mod_cast h.d_pos.ne'
  have point : 1*(P.a : ℚ)^2 - (P.d : ℚ)*(P.b : ℚ)^4 = P.normAlpha := by
    simp only [«JNT-2024».Parameters.normAlpha, Int.cast_sub, Int.cast_mul, Int.cast_pow]
    ring
  have hn : (P.normAlpha : ℚ) ≠ 0 := by
    intro hz
    apply h.d_not_square
    apply Rat.isSquare_intCast_iff.mp
    refine ⟨(P.a : ℚ)/(P.b : ℚ)^2, ?_⟩
    field_simp [hb]
    rw [hz] at point
    linear_combination -point
  exact quarticModel _ _ _ _ _ (mul_ne_zero (mul_ne_zero one_ne_zero hd) hn) point

end AnyBAnyNorm.QuarticModel
