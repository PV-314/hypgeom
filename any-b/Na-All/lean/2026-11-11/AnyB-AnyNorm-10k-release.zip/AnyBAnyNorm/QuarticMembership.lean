module

public import «JNT-2024».Section4Sequence
public import AnyBAnyNorm.QuarticResults
public import AnyBAnyNorm.SizeCheck
public import AnyBAnyNorm.MainStatements

@[expose] public section
namespace AnyBAnyNorm.Section56
open «JNT-2024» AnyBNormSquare

private def points (P : Parameters) := (quarticResults.lookup (P.d,P.normAlpha)).getD []
private def squares (P : Parameters) : List ℚ := (points P).map fun xy => (xy.2 : ℚ)^2
private def interval (P : Parameters) : SizeRow := ⟨P,0,6⟩
private def inSequence (P : Parameters) : List ℚ :=
  (squares P).filter fun y => ((interval P).indices.map (interval P).value).contains y

/-- The ten exceptional equations on p. 23. The two end values exceed
every candidate square, and on the negative side also exceed the initial square. -/
private def classified (P : Parameters) : Prop :=
  ((P.d,P.normAlpha),points P) ∈ quarticResults ∧
  ((points P).length ≤ 3 ∨
    ((P.b : ℚ)^2 < (interval P).value (-6) ∧
     (∀ v ∈ squares P, v < (interval P).value 6 ∧ v < (interval P).value (-6)) ∧
     (inSequence P).length ≤ 4 ∧
     ((inSequence P).length = 4 ↔ P = ⟨1,3,2,2,2⟩ ∨ P = ⟨2,3,8,2,1⟩)))
private instance (P : Parameters) : Decidable (classified P) := by unfold classified; infer_instance

set_option maxRecDepth 32768 in
set_option maxHeartbeats 30000000 in
private theorem classified_all :
    ∀ P ∈ postJavaTuples, coveredNorm P.normAlpha.natAbs = true ∨ classified P := by decide +kernel

set_option maxRecDepth 32768 in
set_option maxHeartbeats 3000000 in
/-- The retained tuples with more than three reported positive solutions have b = 3 or 4. -/
theorem exceptional_quartic_b :
    ∀ P ∈ postJavaTuples, 3 < ((quarticResults.lookup (P.d,P.normAlpha)).getD []).length →
      P.b = 3 ∨ P.b = 4 := by
  decide +kernel

/-- The classification at the end of §5.6 counts square values over all
indices. The two displayed tuples attain the upper bound by the four
explicit occurrences proved in ExceptionalSequence. -/
theorem solver_sequence_classification (hc : QuarticResultsComplete) {P : Parameters}
    (hP : P ∈ postJavaTuples) (h : P.Admissible) (hn : P.normAlpha < 0)
    (hm : Normalized P h.pell) (hskip : coveredNorm P.normAlpha.natAbs ≠ true)
    (K : ℤ) (hK : P.IsNegativeCutoff h.pell K) :
    AtMostSquareValues (P.y h.pell)
      (if P = ⟨1,3,2,2,2⟩ ∨ P = ⟨2,3,8,2,1⟩ then 4 else 3) := by
  obtain ⟨hrow,hclass⟩ := (classified_all P hP).resolve_left hskip
  have member (k : ℤ) (hs : IsIntegerSquare (P.y h.pell k)) : P.y h.pell k ∈ squares P := by
    obtain ⟨X,Y,hX,hY,he⟩ := P.section4_integer_coordinates h.pell hs
    obtain ⟨z,hz⟩ := hs
    have hs : IsIntegerSquare (P.y h.pell k) := ⟨z,hz⟩
    have hYz : Y=z^2 := by exact_mod_cast hY.symm.trans hz
    have hX0 : X ≠ 0 := by intro hh; exact hm.2 k hs (by simpa [hh] using hX)
    have hz0 : z ≠ 0 := by
      intro hh
      have hb := hm.1 k hs
      rw [hz,hh] at hb
      have hb0 : (0 : ℚ) < (P.b : ℚ)^2 := sq_pos_of_pos (by exact_mod_cast h.b_pos)
      norm_num only [Int.cast_zero, zero_pow, Nat.succ_ne_zero] at hb
      exact (not_lt_of_ge hb) hb0
    have hxy : |X|^2-P.d*|z|^4=P.normAlpha := by
      rw [sq_abs, Even.pow_abs (n := 4) (by decide) z]
      rw [hYz] at he
      nlinarith only [he]
    have hp := hc _ hrow |X| |z| (abs_pos.mpr hX0) (abs_pos.mpr hz0) hxy
    apply List.mem_map.mpr
    exact ⟨(|X|,|z|),hp,by simp [hz,Int.cast_abs,sq_abs]⟩
  rcases hclass with hthree | ⟨hstart,hl,hlen,hfour⟩
  · refine ⟨(squares P).toFinset,?_,fun k hs => List.mem_toFinset.mpr (member k hs)⟩
    apply (List.toFinset_card_le _).trans
    simp only [squares, List.length_map]
    split <;> omega
  refine ⟨(inSequence P).toFinset,(List.toFinset_card_le _).trans ?_,?_⟩
  · split
    · exact hlen
    · rename_i hother
      have := mt hfour.mp hother
      omega
  intro k hs
  have hv := member k hs
  obtain ⟨hi,hmn⟩ := hl _ hv
  simp only [value_eq (interval P) h.pell] at hi hmn hstart
  obtain ⟨_,hpos,_,hneg⟩ := lemma33a P h hn
  have hK6 : -6 ≤ K := by
    by_contra! hh
    exact (not_lt_of_ge (hK.2.2 (-6) hh (by decide))) hstart
  have hk : -(6 : ℤ) ≤ k ∧ k ≤ 6 := by
    constructor
    · by_contra! hh
      have H := (hneg K hK).monotone (show (K+1+6).toNat ≤ (K+1-k).toNat by omega)
      rw [show K+1-↑(K+1+6).toNat = -6 by omega,show K+1-↑(K+1-k).toNat=k by omega] at H
      exact (not_lt_of_ge H) hmn
    · by_contra! hh
      have H := hpos.monotone (show (6:ℕ) ≤ k.toNat by omega)
      rw [Int.toNat_of_nonneg (by omega)] at H
      exact (not_lt_of_ge H) hi
  apply List.mem_toFinset.mpr
  apply List.mem_filter.mpr
  refine ⟨hv,?_⟩
  simpa using (List.mem_map.mpr ⟨k,(mem_indices (interval P) k).2 hk,value_eq (interval P) h.pell _⟩ :
    P.y h.pell k ∈ (interval P).indices.map (interval P).value)

theorem solver_sequence_bound (hc : QuarticResultsComplete) {P : Parameters}
    (hP : P ∈ postJavaTuples) (h : P.Admissible) (hn : P.normAlpha < 0)
    (hm : Normalized P h.pell) (hskip : coveredNorm P.normAlpha.natAbs ≠ true)
    (K : ℤ) (hK : P.IsNegativeCutoff h.pell K) :
    AtMostSquareValuesOn (P.y h.pell) (fun k => 3 ≤ k ∨ k ≤ K-2) 4 := by
  obtain ⟨S,hS,hs⟩ := solver_sequence_classification hc hP h hn hm hskip K hK
  exact ⟨S,hS.trans (by split <;> decide),fun k _ => hs k⟩

end AnyBAnyNorm.Section56
