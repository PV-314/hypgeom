module

public import AnyBAnyNorm.SequenceLemmas
public import «JNT-2024».PhaseSelection

@[expose] public section
namespace AnyBAnyNorm
open «JNT-2024»

/-- The fixed representation and minimizing fourth root at lines 921–933.
The same integer coordinates in the certificate give the ratio and the phase. -/
structure SquarePhase (P : Parameters) (hp : P.Pell) (k : ℤ) where
  datum : P.SequenceDatum
  cert : P.SequenceGapCertificate hp k datum
  f_bound : datum.f ≤ 4 * (P.b : ℝ)^2 * Real.sqrt |(squarefreePart P.normAlpha : ℝ)|
  ζ : ℂ
  phase : FourthPhase ζ
  minimizes : ∀ θ : ℂ, FourthPhase θ →
    ‖principalFourthRoot P.gapOmega - ζ * datum.ratio‖ ≤
    ‖principalFourthRoot P.gapOmega - θ * datum.ratio‖

/-- Any triple f,r,s satisfying Lemma 3.2 can be fixed before choosing ζ. -/
theorem phase_of_representation {P : Parameters} (h : P.Admissible) (hn : P.normAlpha < 0)
    {k T U x v f r s : ℤ} (hU : U ≠ 0) (hv : 0 < v) (hp : (P.withUnit T U).Pell)
    (hr : (P.withUnit T U).RepresentsSquare x v) (hy : P.y h.pell k = (v : ℚ)^2)
    (hx : P.x h.pell k = (x : ℚ)) (hν : (P.withUnit T U).epsilonNorm = P.epsilonNorm ^ k)
    (hf : f ≠ 0) (hF : (P.withUnit T U).FourthPowerRepresentation x v f r s)
    (hb : |(f : ℝ)| ≤ 4 * (P.b : ℝ)^2 * Real.sqrt |(squarefreePart P.normAlpha : ℝ)|) :
    ∃ p : SquarePhase P h.pell k, p.datum.f = (f : ℝ) ∧ p.datum.r = r ∧ p.datum.s = s := by
  obtain ⟨d, hdy, hdf, hdr, hds⟩ :=
    (P.withUnit T U).signed_representation_datum h.b_pos hn hp hv hf (Or.inl rfl) hF.signed
  have hc : P.SequenceGapCertificate h.pell k d := by
    refine ⟨?_, T, U, x, v, f, 1, hU, hv, hp, hr, hdf, Or.inl rfl, ?_, hx, hν⟩
    · rw [hdy, hy]; norm_cast
    · simpa only [hdr, hds] using hF.signed
  obtain ⟨ζ, hζ, _, hmin⟩ :=
    exists_minimizing_fourth_phase (principalFourthRoot_norm P.gapOmega) d.ratio_norm
  exact ⟨⟨d, hc, hdf ▸ le_trans (le_abs_self _) hb, ζ, hζ, hmin⟩, hdf, hdr, hds⟩

/-- The unsigned representation in (3.3), with its actual coefficient
and coordinates. This distinguishes the representations used by §5.6. -/
def PaperPhase {P : Parameters} {hp : P.Pell} {k : ℤ} (p : SquarePhase P hp k) : Prop :=
  ∃ T U x v f : ℤ, U ≠ 0 ∧ 0 < v ∧ (P.withUnit T U).Pell ∧
    (P.withUnit T U).RepresentsSquare x v ∧ P.y hp k = (v : ℚ)^2 ∧
    P.x hp k = (x : ℚ) ∧ (P.withUnit T U).epsilonNorm = P.epsilonNorm^k ∧
    p.datum.f = (f : ℝ) ∧ f ∣ 4*P.b^2*squarefreePart P.normAlpha ∧
    (P.withUnit T U).FourthPowerRepresentation x v f p.datum.r p.datum.s

theorem paperPhase_exists {P : Parameters} (h : P.Admissible) (hn : P.normAlpha < 0)
    {k : ℤ} (hk : k ≠ 0) (hs : IsIntegerSquare (P.y h.pell k))
    (hy : 0 < P.y h.pell k) (hx : P.x h.pell k ≠ 0) : ∃ p : SquarePhase P h.pell k, PaperPhase p := by
  obtain ⟨T, U, x, v, hU, hv, hp, hr, hyv, hxy, hν⟩ :=
    P.sequence_square_representation_input_indexed h hk
      ((P.rational_square_iff_integer_square h.pell k).mpr hs) hy
  let Q := P.withUnit T U
  let : Fact (¬ IsSquare Q.d) := ⟨h.d_not_square⟩
  let : Fact (¬ IsSquare Q.normAlpha) := ⟨by
    rintro ⟨m, hm⟩; change P.normAlpha = m * m at hm; nlinarith [sq_nonneg m]⟩
  have hT : T ≠ 0 := by
    rintro rfl
    change 0 ^ 2 - P.d * U ^ 2 = 4 ∨ 0 ^ 2 - P.d * U ^ 2 = -4 at hp
    have hdU : P.d * U ^ 2 = 4 := by rcases hp with hp | hp <;> nlinarith [mul_nonneg h.d_pos.le (sq_nonneg U)]
    apply h.d_not_square
    apply Rat.isSquare_intCast_iff.mp
    refine ⟨2 / (U : ℚ), ?_⟩
    have hUq : (U : ℚ) ≠ 0 := by exact_mod_cast hU
    have he : (P.d : ℚ) * (U : ℚ)^2 = 4 := by exact_mod_cast hdU
    field_simp
    nlinarith only [he]
  have hx' : x ≠ 0 := by rintro rfl; exact hx (by simpa using hxy)
  obtain ⟨f, r, s, hf, hF, hdiv, _, hb⟩ := lemma32 Q h.a_pos.ne' h.b_pos hp hT hU hx' hv hr
  obtain ⟨p, hfval, hrval, hsval⟩ := phase_of_representation h hn hU hv hp hr hyv hxy hν hf hF hb
  exact ⟨p,T,U,x,v,f,hU,hv,hp,hr,hyv,hxy,hν,hfval,hdiv,by simpa only [hrval,hsval] using hF⟩

theorem squarePhase_exists {P : Parameters} (h : P.Admissible) (hn : P.normAlpha < 0)
    {k : ℤ} (hk : k ≠ 0) (hs : IsIntegerSquare (P.y h.pell k))
    (hy : 0 < P.y h.pell k) (hx : P.x h.pell k ≠ 0) : Nonempty (SquarePhase P h.pell k) :=
  ⟨(paperPhase_exists h hn hk hs hy hx).choose⟩

/-- Choose the smallest positive integral coefficient f before selecting phases. -/
theorem least_phase {P : Parameters} {hp : P.Pell} {k : ℤ}
    (hex : ∃ p : SquarePhase P hp k, PaperPhase p) :
    ∃ p : SquarePhase P hp k, PaperPhase p ∧
      ∀ q : SquarePhase P hp k, PaperPhase q → p.datum.f ≤ q.datum.f := by
  classical
  let occurs (n : ℕ) := ∃ p : SquarePhase P hp k, PaperPhase p ∧ p.datum.f = n
  have natCoeff (p : SquarePhase P hp k) (hh : PaperPhase p) : ∃ n : ℕ, p.datum.f = n := by
    obtain ⟨_,_,_,_,f,_,_,_,_,_,_,_,hf,_⟩ := hh
    have hfpos := p.datum.f_pos
    rw [hf] at hfpos
    have hf0 : 0 < f := by exact_mod_cast hfpos
    refine ⟨f.toNat,hf.trans ?_⟩
    exact_mod_cast (Int.toNat_of_nonneg hf0.le).symm
  obtain ⟨p,hp'⟩ := hex
  obtain ⟨n,hn⟩ := natCoeff p hp'
  have H : ∃ n, occurs n := ⟨n,p,hp',hn⟩
  obtain ⟨q,hq,he⟩ := Nat.find_spec H
  refine ⟨q,hq,fun v hv => ?_⟩
  obtain ⟨m,hm⟩ := natCoeff v hv
  rw [he,hm]
  exact_mod_cast Nat.find_min' H (show occurs m from ⟨v,hv,hm⟩)

/-- The product estimate at line 973 for the two fixed coefficients. -/
theorem coefficient_product {P : Parameters} {hp : P.Pell} {i j : ℤ}
    (hn : P.normAlpha < 0) (p : SquarePhase P hp i) (q : SquarePhase P hp j) :
    p.datum.f * q.datum.f ≤ 16 * (P.b : ℝ)^4 * |(P.normAlpha : ℝ)| := by
  have hS : |(squarefreePart P.normAlpha : ℝ)| ≤ |(P.normAlpha : ℝ)| := by
    have hd := Int.natAbs_le_of_dvd_ne_zero (squarefreePart_dvd P.normAlpha) hn.ne
    have hi : |squarefreePart P.normAlpha| ≤ |P.normAlpha| := by
      simpa using (show ((squarefreePart P.normAlpha).natAbs : ℤ) ≤ (P.normAlpha.natAbs : ℤ) by
        exact_mod_cast hd)
    exact_mod_cast hi
  calc
    _ ≤ (4 * (P.b : ℝ)^2 * Real.sqrt |(squarefreePart P.normAlpha : ℝ)|)^2 := by
      rw [sq]; exact mul_le_mul p.f_bound q.f_bound q.datum.f_pos.le (by positivity)
    _ = 16 * (P.b : ℝ)^4 * |(squarefreePart P.normAlpha : ℝ)| := by
      rw [mul_pow, Real.sq_sqrt (abs_nonneg _)]; ring
    _ ≤ _ := mul_le_mul_of_nonneg_left hS (by positivity)

def CubicGap (P : Parameters) (y z : ℝ) : Prop :=
  (1536 / 100 : ℝ) * ((P.d : ℝ) / (16 * (P.b : ℝ)^2 * |(P.normAlpha : ℝ)|^2))^2 * y^3 < z

private theorem minimizing_phase_bound {P : Parameters} {h : P.Admissible} {k : ℤ}
    (hn : P.normAlpha < 0) (p : SquarePhase P h.pell k) (hl : 4 * P.gapScale ≤ p.datum.y) :
    ‖principalFourthRoot P.gapOmega - p.ζ * p.datum.ratio‖ * p.datum.y <
      (5051 / 10000 : ℝ) * P.gapScale := by
  obtain ⟨θ, hθ, hb⟩ := p.datum.phase_approximation (P.gapScale_pos h.b_pos hn)
    (principalFourthRoot_pow_four (P.gapOmega_norm hn)) (principalFourthRoot_norm _) hl
  exact lt_of_le_of_lt (mul_le_mul_of_nonneg_right (p.minimizes θ hθ) p.datum.y_pos.le) hb

/-- Lemma 3.4, the “moreover” clause. JNT's parallel-phase argument first
gives the gap with fᵢfⱼ, then line 973 gives the paper's uniform bound. -/
theorem lemma34_pair {P : Parameters} (h : P.Admissible) (hn : P.normAlpha < 0)
    {i j : ℤ} (p : SquarePhase P h.pell i) (q : SquarePhase P h.pell j)
    (hij : (P.y h.pell i : ℝ) < (P.y h.pell j : ℝ))
    (hl : 4 * Real.sqrt (|(P.normAlpha : ℝ)| / P.d) ≤ (P.y h.pell i : ℝ))
    (hc : SamePhaseClass p.ζ q.ζ) : CubicGap P (P.y h.pell i) (P.y h.pell j) := by
  have hy : p.datum.y < q.datum.y := by rwa [p.cert.1, q.cert.1]
  have hlarge : 4 * P.gapScale ≤ p.datum.y := by rwa [p.cert.1, P.gapScale_eq_sqrt h.b_pos hn]
  have hb : (0 : ℝ) < P.b := by exact_mod_cast h.b_pos
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hN : 0 < |(P.normAlpha : ℝ)| := abs_pos.mpr (by exact_mod_cast hn.ne)
  have ht := P.gapScale_pos h.b_pos hn
  have hg := p.datum.parallel_gap q.datum (neg_pos.mpr (squarefreePart_neg hn)) hb ht hy
    p.phase q.phase hc (minimizing_phase_bound (h := h) hn p hlarge)
    (minimizing_phase_bound (h := h) hn q (hlarge.trans hy.le))
  have gap := (p.datum.cubicGap_of_gap q.datum hb ht hy hg).1
  rw [P.paper_gap_coefficient h hn p.datum.f_pos q.datum.f_pos] at gap
  have hf := coefficient_product hn p q
  have hfg := mul_pos p.datum.f_pos q.datum.f_pos
  have hratio : (P.d : ℝ) / (16 * (P.b : ℝ)^2 * |(P.normAlpha : ℝ)|^2) ≤
      (P.b : ℝ)^2 * P.d / (p.datum.f * q.datum.f * |(P.normAlpha : ℝ)|) := by
    apply (div_le_div_iff₀ (by positivity) (mul_pos hfg hN)).mpr
    calc
      _ = ((P.d : ℝ) * |(P.normAlpha : ℝ)|) * (p.datum.f * q.datum.f) := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_left hf (mul_pos hd hN).le
      _ = _ := by ring
  unfold CubicGap
  rw [← p.cert.1, ← q.cert.1]
  exact lt_of_le_of_lt (mul_le_mul_of_nonneg_right
    (mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (by positivity) hratio 2) (by norm_num))
    (pow_nonneg p.datum.y_pos.le _)) gap

/-- Lemma 3.4, lines 940–951. Positions 0,1,2 denote the three given
indices in increasing order of their square values. -/
theorem lemma34 {P : Parameters} (h : P.Admissible) (hn : P.normAlpha < 0)
    (k : Fin 3 → ℤ) (p : ∀ i, SquarePhase P h.pell (k i))
    (hord : StrictMono (fun i => (P.y h.pell (k i) : ℝ)))
    (hl : 4 * Real.sqrt (|(P.normAlpha : ℝ)| / P.d) ≤ (P.y h.pell (k 0) : ℝ)) :
    ∃ i j : Fin 3, i < j ∧ SamePhaseClass (p i).ζ (p j).ζ ∧
      CubicGap P (P.y h.pell (k i)) (P.y h.pell (k j)) := by
  have pair (i j : Fin 3) (hij : i < j) (hc : SamePhaseClass (p i).ζ (p j).ζ) :=
    lemma34_pair h hn (p i) (p j) (hord hij)
      (hl.trans (hord.monotone (Fin.zero_le i))) hc
  rcases three_phases _ _ _ (p 0).phase (p 1).phase (p 2).phase with hc | hc | hc
  · exact ⟨0, 1, by decide, hc, pair 0 1 (by decide) hc⟩
  · exact ⟨0, 2, by decide, hc, pair 0 2 (by decide) hc⟩
  · exact ⟨1, 2, by decide, hc, pair 1 2 (by decide) hc⟩

/-- Choose the representations from the sequence assumptions in the statement
of Lemma 3.4, including the exclusion of the closed interval [K+1,0]. -/
theorem lemma34_paper {P : Parameters} (h : P.Admissible) (hn : P.normAlpha < 0)
    {K : ℤ} (hK : P.IsNegativeCutoff h.pell K)
    (hx : ∀ k, IsIntegerSquare (P.y h.pell k) → P.x h.pell k ≠ 0)
    (k : Fin 3 → ℤ) (hidx : ∀ i, k i ∉ Set.Icc (K + 1) 0)
    (hs : ∀ i, IsIntegerSquare (P.y h.pell (k i)))
    (hord : StrictMono (fun i => (P.y h.pell (k i) : ℝ)))
    (hl : 4 * Real.sqrt (|(P.normAlpha : ℝ)| / P.d) ≤ (P.y h.pell (k 0) : ℝ)) :
    ∃ i j : Fin 3, i < j ∧ CubicGap P (P.y h.pell (k i)) (P.y h.pell (k j)) := by
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hN : 0 < |(P.normAlpha : ℝ)| := abs_pos.mpr (by exact_mod_cast hn.ne)
  have pos : (0 : ℝ) < 4 * Real.sqrt (|(P.normAlpha : ℝ)| / P.d) := by positivity
  have data (i : Fin 3) : Nonempty (SquarePhase P h.pell (k i)) := by
    have hk : k i ≠ 0 := by
      intro he; apply hidx i; rw [he]; exact ⟨by have := hK.1; omega, le_rfl⟩
    have hy := (pos.trans_le hl).trans_le (hord.monotone (Fin.zero_le i))
    exact squarePhase_exists h hn hk (hs i) (by exact_mod_cast hy) (hx _ (hs i))
  obtain ⟨i, j, hij, _, hg⟩ := lemma34 h hn k (fun i => (data i).some) hord hl
  exact ⟨i, j, hij, hg⟩

/-- Lemma 3.5(b). Apply JNT 3.9(b) with the two phases already fixed at
line 933. The attaining phase is 1 or −1. -/
theorem lemma35b {P : Parameters} (h : P.Admissible) (hn : P.normAlpha < 0)
    {k l : ℤ} (p : SquarePhase P h.pell k) (q : SquarePhase P h.pell l)
    (hy : (P.y h.pell k : ℝ) < (P.y h.pell l : ℝ))
    (hl : 4 * Real.sqrt (|(P.normAlpha : ℝ)| / P.d) ≤ (P.y h.pell k : ℝ))
    (hc : SamePhaseClass p.ζ q.ζ) :
    ∃ σ : ℂ, (σ = 1 ∨ σ = -1) ∧ ∀ θ : ℂ, FourthPhase θ → θ ≠ σ →
      let z := star p.datum.point * q.datum.point
      ‖principalFourthRoot (P.sequenceOmega h.pell k) - σ * (star z / z)‖ <
        ‖principalFourthRoot (P.sequenceOmega h.pell k) - θ * (star z / z)‖ :=
  P.lemma39b_of_minimizers h hn _ _ p.cert q.cert hy hl
    (principalFourthRoot_pow_four (P.gapOmega_norm hn)) p.phase q.phase hc p.minimizes q.minimizes

end AnyBAnyNorm
