module

public import «JNT-2024».SquarefreePart
public import Mathlib.Algebra.QuadraticAlgebra.Basic
public import Mathlib.Tactic.LinearCombination

@[expose] public section
namespace AnyBAnyNorm.Section56
open «JNT-2024»

/-- The positive scale returned by the solver's qt_square_normalise for d > 0. -/
noncomputable def quarticScale (d N : ℤ) : ℤ := squareFactor (Int.gcd d (-N) : ℤ)

/-- Multiplying a nonzero integer by a positive square preserves its squarefree
part and multiplies its square factor by the positive square root. -/
theorem quartic_square_parts {c m : ℤ} (hc : 0 < c) (hm : m ≠ 0) :
    squarefreePart (c^2*m) = squarefreePart m ∧
    squareFactor (c^2*m) = c*squareFactor m := by
  have he : (c*squareFactor m)^2 * squarefreePart m = c^2*m := by
    rw [mul_pow, mul_assoc, squareFactor_sq_mul]
  have hq := squarefreePart_eq_of_factorization (mul_ne_zero (pow_ne_zero _ hc.ne') hm)
    (squarefreePart_squarefree m) he
  refine ⟨hq, ?_⟩
  have h := squareFactor_sq_mul (c^2*m)
  rw [hq] at h
  have hs := mul_right_cancel₀ (squarefreePart_ne_zero m) (h.trans he.symm)
  have h₁ := squareFactor_nonneg (c^2*m)
  have h₂ := mul_nonneg hc.le (squareFactor_nonneg m)
  exact (sq_eq_sq₀ h₁ h₂).mp hs

theorem quarticScale_spec {d N : ℤ} (hd : 0 < d) :
    0 < quarticScale d N ∧ (quarticScale d N)^2 ∣ d ∧
    (quarticScale d N)^2 ∣ N ∧
    ∀ k : ℤ, 0 < k → k^2 ∣ d → k^2 ∣ N → k ∣ quarticScale d N := by
  let g : ℤ := Int.gcd d (-N)
  have hg : 0 < g := by dsimp [g]; exact_mod_cast Int.gcd_pos_of_ne_zero_left (-N) hd.ne'
  have hs : (squareFactor g)^2 ∣ g := ⟨_, (squareFactor_sq_mul g).symm⟩
  refine ⟨squareFactor_pos hg.ne', hs.trans (Int.gcd_dvd_left ..),
    dvd_neg.mp (hs.trans (Int.gcd_dvd_right ..)), ?_⟩
  intro k hk hkd hkN
  have hn : ((k^2).toNat : ℤ) = k^2 := Int.toNat_of_nonneg (sq_nonneg _)
  have h₁ : ((k^2).toNat : ℤ) ∣ d := by rwa [hn]
  have h₂ : ((k^2).toNat : ℤ) ∣ -N := by rwa [hn, dvd_neg]
  have hkg : k^2 ∣ g := by
    rw [← hn]
    dsimp [g]
    exact_mod_cast Int.dvd_gcd h₁ h₂
  obtain ⟨m, hm⟩ := hkg
  have hm0 : m ≠ 0 := by rintro rfl; simp at hm; exact hg.ne' hm
  change k ∣ squareFactor g
  rw [hm, (quartic_square_parts hk hm0).2]
  exact dvd_mul_right _ _

/-- The inverse coordinate is integral for every original solution, including
solutions of either sign. Restoring the coordinate leaves y fixed. -/
theorem quartic_reduction_iff {c : ℤ} (hc : 0 < c) (D n x y : ℤ) :
    x^2 - (c^2*D)*y^4 = c^2*n ↔
      ∃ X : ℤ, x = c*X ∧ X^2 - D*y^4 = n := by
  constructor
  · intro h
    have hdiv : c^2 ∣ x^2 := ⟨D*y^4+n, by linear_combination h⟩
    obtain ⟨X, hx⟩ := (Int.pow_dvd_pow_iff (by decide : (2:ℕ) ≠ 0)).mp hdiv
    refine ⟨X, hx, mul_left_cancel₀ (pow_ne_zero 2 hc.ne') ?_⟩
    rw [hx] at h
    linear_combination h
  · rintro ⟨X, rfl, h⟩
    linear_combination c^2*h

/-- The equation with the actual integer quotients passed to the descent. -/
theorem quartic_solver_coordinates {d N : ℤ} (hd : 0 < d) (x y : ℤ) :
    let c := quarticScale d N
    x^2 - d*y^4 = N ↔
      x = c*(x/c) ∧ (x/c)^2 - (d/c^2)*y^4 = N/c^2 := by
  dsimp only
  let c := quarticScale d N
  obtain ⟨hc, hcd, hcN, _⟩ := quarticScale_spec (N := N) hd
  have hd' : c^2*(d/c^2) = d := by rw [mul_comm, Int.ediv_mul_cancel hcd]
  have hN' : c^2*(N/c^2) = N := by rw [mul_comm, Int.ediv_mul_cancel hcN]
  have h := quartic_reduction_iff hc (d/c^2) (N/c^2) x y
  rw [hd', hN'] at h
  constructor
  · intro he
    obtain ⟨X, hx, hX⟩ := h.mp he
    have hx' : x/c = X := by rw [hx, Int.mul_ediv_cancel_left _ hc.ne']
    exact ⟨hx' ▸ hx, hx' ▸ hX⟩
  · rintro ⟨hx, hX⟩
    exact h.mpr ⟨_, hx, hX⟩

theorem quartic_8_644 (x y : ℤ) :
    x^2 - 8*y^4 = -644 ↔ ∃ X : ℤ, x = 2*X ∧ X^2 - 2*y^4 = -161 := by
  exact quartic_reduction_iff (by decide : (0:ℤ) < 2) 2 (-161) x y

/-- The field and the coefficient of its square root in the reduced equation. -/
theorem quartic_solver_square_parts {d N : ℤ} (hd : 0 < d) (hN : N < 0) :
    let c := quarticScale d N
    let m := -(N/c^2)
    squarefreePart m = squarefreePart (-N) ∧ squareFactor m = squareFactor (-N)/c := by
  let c := quarticScale d N
  let m := -(N/c^2)
  obtain ⟨hc, _, hcN, _⟩ := quarticScale_spec (N := N) hd
  have h : c^2*m = -N := by
    dsimp only [m]
    rw [mul_neg, mul_comm, Int.ediv_mul_cancel hcN]
  have hm : m ≠ 0 := by intro hz; rw [hz, mul_zero] at h; omega
  obtain ⟨hq, hs⟩ := quartic_square_parts hc hm
  rw [h] at hq hs
  exact ⟨hq.symm, by rw [hs, Int.mul_ediv_cancel_left _ hc.ne']⟩

theorem quartic_8_644_parameters :
    quarticScale 8 (-644) = 2 ∧ squarefreePart 644 = 161 ∧ squareFactor 644 = 2 := by
  have h161 : Squarefree (161:ℤ) := by
    exact Int.squarefree_natCast.mpr (by decide +kernel : Squarefree (161:ℕ))
  have hq := squarefreePart_eq_of_factorization (c := 2) (by decide : (644:ℤ) ≠ 0)
    h161 (by decide)
  have hg := squarefreePart_eq_one (by decide : (4:ℤ) ≠ 0) (show IsSquare (4:ℤ) from ⟨2, rfl⟩)
  have h4 := squareFactor_sq_mul 4
  have h644 := squareFactor_sq_mul 644
  rw [hq] at h644
  rw [hg, mul_one] at h4
  change squareFactor 4 = 2 ∧ _
  refine ⟨(sq_eq_sq₀ (squareFactor_nonneg 4) (by decide : (0:ℤ) ≤ 2)).mp h4, hq, ?_⟩
  apply (sq_eq_sq₀ (squareFactor_nonneg 644) (by decide : (0:ℤ) ≤ 2)).mp
  linarith only [h644]

/-- The conjugate factorisation on p. 23, in coordinates in Q(sqrt(-q)). -/
theorem quartic_conjugate_product (q s x d y : ℚ) (h : x^2 + q*s^2 = d*y^4) :
    (⟨x,s⟩ : QuadraticAlgebra ℚ (-q) 0) * ⟨x,-s⟩ = ⟨d*y^4,0⟩ := by
  ext <;> simp <;> linarith only [h]

/-- Coefficient of sqrt(-q) equated to the reduced s in qt_make_form.
A and B are the coordinates of b₁ U + b₂ V. -/
theorem quartic_thue_coefficient (q A B : ℚ) (κ : QuadraticAlgebra ℚ (-q) 0) :
    (κ * (⟨A,B⟩ : QuadraticAlgebra ℚ (-q) 0)^4).im =
      κ.im*(A^4 - 6*q*A^2*B^2 + q^2*B^4) + κ.re*(4*A*B*(A^2-q*B^2)) := by
  simp [pow_succ, QuadraticAlgebra.im_mul]
  ring

end AnyBAnyNorm.Section56
