module

public import AnyBAnyNorm.SequenceLemmas

@[expose] public section
namespace AnyBAnyNorm
open «JNT-2024»

/-- (5.1)–(5.3). On either tail the exponent in Lemma 3.3(b) is at least two. -/
theorem section5_tail_lower (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (K : ℤ) (hK : P.IsNegativeCutoff h.pell K) (hd : 300 ≤ P.d * P.u^2)
    {k : ℤ} (hk : 3 ≤ k ∨ k ≤ K-2) :
    (98/100 : ℚ) * |(P.normAlpha : ℚ)| * (P.d : ℚ)^2*(P.u : ℚ)^6 /
      (4*(P.b : ℚ)^2) ≤ P.y h.pell k := by
  let R : ℚ := (99/100)*P.d*(P.u : ℚ)^2
  have hR : 1 ≤ R := by
    have hh : (300 : ℚ) ≤ P.d*(P.u : ℚ)^2 := by exact_mod_cast hd
    dsimp [R]
    linarith
  have hseed : 0 ≤ P.lowerSeed := by unfold Parameters.lowerSeed; positivity
  have hg := (lemma33b P h hn K hK).1 (Or.inr hd)
  have finish (n : ℕ) (he : 2 ≤ n) (hy : P.lowerSeed*R^n ≤ P.y h.pell k) :
      P.lowerSeed*R^2 ≤ P.y h.pell k :=
    (mul_le_mul_of_nonneg_left (pow_le_pow_right₀ hR he) hseed).trans hy
  have hh : P.lowerSeed*R^2 ≤ P.y h.pell k := by
    rcases hk with hk | hk
    · exact finish (k-1).toNat (by omega) (hg.1 k (by omega))
    · exact finish (K-k).toNat (by omega) (hg.2 k (by have := hK.1; omega))
  apply le_trans _ hh
  dsimp [Parameters.lowerSeed, R]
  apply_rules [le_of_sub_nonneg]
  ring_nf
  positivity

private theorem log_round {x y : ℝ} (hx : 0 < x) (m n : ℕ) (h : x^m < y^n) :
    (m : ℝ)*Real.log x < n*Real.log y := by
  simpa only [Real.log_pow] using Real.log_lt_log (pow_pos hx m) h

/-- §5.1. The first discriminant condition separates the two bounds on y. -/
theorem section51_separation {b d N u : ℝ} (hb : 0 < b) (hd : 0 < d)
    (hN : 0 < N) (hu : 0 < u)
    (h : (342/100 : ℝ)*b^(24/17 : ℝ)*N^(15/34 : ℝ)/u^(33/17 : ℝ) < d) :
    (109/10 : ℝ)*b^(26/11 : ℝ)*N^(26/11 : ℝ)/d^(12/11 : ℝ) <
      (98/100 : ℝ)*N*d^2*u^6/(4*b^2) := by
  apply (Real.log_lt_log_iff (by positivity) (by positivity)).mp
  have ht := Real.log_lt_log (by positivity) h
  have hr := log_round (x := (109/10 : ℝ)*4/(98/100)) (y := (342/100 : ℝ))
    (by norm_num) 11 34 (by norm_num)
  simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_rpow, Real.log_pow] at ht hr ⊢
  norm_num1 at ht hr ⊢
  linarith only [ht, hr]

/-- The second condition in §5.1 implies the first by |Nα| < db⁴. -/
theorem section51_norm_free {b d N u : ℝ} (hb : 0 < b) (hd : 0 < d)
    (hN : 0 < N) (hu : 0 < u) (hs : N < d*b^4)
    (h : (91/10 : ℝ)*b^(108/19 : ℝ)/u^(66/19 : ℝ) < d) :
    (342/100 : ℝ)*b^(24/17 : ℝ)*N^(15/34 : ℝ)/u^(33/17 : ℝ) < d := by
  apply (Real.log_lt_log_iff (by positivity) hd).mp
  have ht := Real.log_lt_log (by positivity) h
  have hn := Real.log_lt_log hN hs
  have hr := log_round (x := (342/100 : ℝ)) (y := (91/10 : ℝ)) (by norm_num) 34 19 (by norm_num)
  simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_rpow, Real.log_pow] at ht hn hr ⊢
  norm_num1 at ht hn hr ⊢
  linarith only [ht, hn, hr]

/-- §5.2. The first discriminant condition separates the two bounds on y. -/
theorem section52_separation {b d N u : ℝ} (hb : 0 < b) (hd : 0 < d)
    (hN : 0 < N) (hu : 0 < u)
    (h : (314/100 : ℝ)*b^(28/19 : ℝ)*N^(9/19 : ℝ)/u^(36/19 : ℝ) < d) :
    (91/10 : ℝ)*b^(8/3 : ℝ)*N^(5/2 : ℝ)/d^(7/6 : ℝ) <
      (98/100 : ℝ)*N*d^2*u^6/(4*b^2) := by
  apply (Real.log_lt_log_iff (by positivity) (by positivity)).mp
  have ht := Real.log_lt_log (by positivity) h
  have hr := log_round (x := (91/10 : ℝ)*4/(98/100)) (y := (314/100 : ℝ))
    (by norm_num) 6 19 (by norm_num)
  simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_rpow, Real.log_pow] at ht hr ⊢
  norm_num1 at ht hr ⊢
  linarith only [ht, hr]

/-- The second condition in §5.2 implies the first by |Nα| < db⁴. -/
theorem section52_norm_free {b d N u : ℝ} (hb : 0 < b) (hd : 0 < d)
    (hN : 0 < N) (hu : 0 < u) (hs : N < d*b^4)
    (h : (88/10 : ℝ)*b^(32/5 : ℝ)/u^(18/5 : ℝ) < d) :
    (314/100 : ℝ)*b^(28/19 : ℝ)*N^(9/19 : ℝ)/u^(36/19 : ℝ) < d := by
  apply (Real.log_lt_log_iff (by positivity) hd).mp
  have ht := Real.log_lt_log (by positivity) h
  have hn := Real.log_lt_log hN hs
  have hr := log_round (x := (314/100 : ℝ)) (y := (88/10 : ℝ)) (by norm_num) 19 10 (by norm_num)
  simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_rpow, Real.log_pow] at ht hn hr ⊢
  norm_num1 at ht hn hr ⊢
  linarith only [ht, hn, hr]

end AnyBAnyNorm
