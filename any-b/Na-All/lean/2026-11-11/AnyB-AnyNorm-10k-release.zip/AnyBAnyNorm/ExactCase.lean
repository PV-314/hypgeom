module

public import AnyBAnyNorm.Gap
public import AnyBAnyNorm.Prerequisites
public import AnyBNormSquare.Case42
public import «JNT-2024».Section4ExactPublished

@[expose] public section
namespace AnyBAnyNorm
open «JNT-2024»

/-- First equality of JNT (4.13), with the author's correction at line 3148.
Here p is the comparison numerator including its phase η. -/
theorem jnt413_modulus {θ p q pr qr : ℂ} (hq : q ≠ 0) (hqr : qr ≠ 0)
    (he : p * qr = pr * q) :
    ‖θ - p / q‖ = ‖qr * θ - pr‖ / ‖qr‖ := by
  rw [(div_eq_div_iff hq hqr).mpr he, ← norm_div]
  congr 1
  field_simp

/-- JNT (4.13)–(4.15) for the raw approximants of target §2.1.
The chord identity and the upper comparison (target §4.2) are explicit inputs. -/
theorem section44_equation415 {t u₁ u₂ : ℤ} (ht : t < 0) (hu : u₂ ≠ 0)
    {r : ℕ} (hr : 1 ≤ r) {p q η : ℂ} (hq : q ≠ 0)
    (he : η * p * Section2.rawQ t u₁ u₂ r = Section2.rawP t u₁ u₂ r * q)
    (hnear : ‖Section2.omega t u₁ u₂ - 1‖ < 1)
    {N d y z : ℝ} (hN : 0 < N) (hd : 0 < d) (hy : 0 < y) (hz : 0 < z)
    (hchord : ‖Section2.omega t u₁ u₂ - 1‖ / 2 = Real.sqrt N / (Real.sqrt d * y))
    (hcomp : ‖Section2.omega t u₁ u₂ ^ (1/4 : ℂ) - η * p / q‖ <
      2 * Real.sqrt N / ((3959/1000 : ℝ) * Real.sqrt d * z)) :
    z < (1734/1000 : ℝ) * Real.sqrt r * (4*d/N)^r * y^(2*r+1) := by
  let w := Section2.omega t u₁ u₂
  let X := Hypergeometric.X (1/4) r w
  let Y := Hypergeometric.Y (1/4) r w
  have hqr : Section2.rawQ t u₁ u₂ r ≠ 0 := by
    intro hzero
    have hp : Section2.rawP t u₁ u₂ r = 0 := by
      rw [hzero, mul_zero] at he
      exact (mul_eq_zero.mp he.symm).resolve_right hq
    simpa [hp, hzero] using Section2.raw_determinant_ne (u₁ := u₁) ht hu r
  have hY : Y ≠ 0 := fun h => hqr (by change Section2.rawScale t u₁ u₂ r * Y = 0; rw [h, mul_zero])
  have herr : ‖w ^ (1/4 : ℂ) - η * p / q‖ = ‖w ^ (1/4 : ℂ) - X / Y‖ := by
    rw [jnt413_modulus hq hqr he, jnt413_modulus hY hY rfl]
    change ‖Section2.rawScale t u₁ u₂ r * Y * _ - Section2.rawScale t u₁ u₂ r * X‖ /
      ‖Section2.rawScale t u₁ u₂ r * Y‖ = _
    rw [mul_assoc, ← mul_sub, norm_mul, norm_mul, mul_div_mul_left]
    exact norm_ne_zero_iff.mpr (Section2.rawScale_ne_zero ht hu r)
  apply Section4.exact_equation415 hN hd hy hz hr _ hcomp
  rw [← hchord, herr]
  exact Section4.exact_error_printed (Section2.omega_norm ht hu) hnear
    (Section2.omega_ne_one ht hu) hr hY

/-- The chord calculation after JNT (4.14) for the doubled coordinates at
the chosen index, retaining the squarefree part for an arbitrary negative norm. -/
theorem section44_chord {P : Parameters} (h : P.Admissible) (hn : P.normAlpha < 0)
    {k X Y : ℤ} (hx : P.x h.pell k = (X : ℚ)) (hy : P.y h.pell k = (Y : ℚ))
    (hY : (0 : ℝ) < Y) :
    let S := squarefreePart P.normAlpha
    let Z := AnyBNormSquare.unitPowerNorm P k*squareFactor P.normAlpha
    ‖Section2.omega S (2*X) (2*Z)-1‖/2 =
      Real.sqrt |(P.normAlpha : ℝ)|/(Real.sqrt P.d*Y) := by
  let S := squarefreePart P.normAlpha
  let Z := AnyBNormSquare.unitPowerNorm P k*squareFactor P.normAlpha
  let U := Section2.U S (2*X) (2*Z)
  let N := |(P.normAlpha : ℝ)|
  let L := Real.sqrt P.d*(Y : ℝ)
  have hS := squarefreePart_neg hn
  have hs : (S : ℝ) < 0 := by exact_mod_cast hS
  have hL : 0 < L := mul_pos (Real.sqrt_pos.mpr (by exact_mod_cast h.d_pos)) hY
  obtain ⟨hZ,hscale,hxy,_⟩ := section42_coordinates h hn hx hy
  have hz : (Z : ℝ)^2 * |(S : ℝ)| = N := hscale
  rw [abs_of_neg hs] at hz
  have hU : U ≠ 0 := Section2.U_ne_zero hS (mul_ne_zero (by decide) hZ)
  have hnorm : ‖U‖ = L := by
    have hh := Section2.U_norm_sq hS.le (2*X) (2*Z)
    change ‖U‖^2 = _ at hh
    unfold Section2.H at hh
    push_cast at hh
    have he : (X : ℝ)^2 + N = L^2 := hxy
    nlinarith only [hh,hz,he,norm_nonneg U,hL]
  have hnum : ‖U - star U‖ = 2*Real.sqrt N := by
    rw [Section2.U_sub_star,norm_mul,Section2.root,norm_mul,Complex.norm_I,mul_one,
      Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg (Real.sqrt_nonneg _)]
    push_cast
    rw [norm_mul,Complex.norm_intCast]
    norm_num
    have hh : |(Z : ℝ)| * Real.sqrt (-(S : ℝ)) = Real.sqrt N := by
      apply (sq_eq_sq₀ (by positivity) (Real.sqrt_nonneg _)).mp
      rw [mul_pow,sq_abs,Real.sq_sqrt (neg_nonneg.mpr hs.le),Real.sq_sqrt (abs_nonneg _)]
      exact hz
    rw [← hh,mul_assoc]
  change ‖U/star U-1‖/2 = Real.sqrt N/L
  rw [show U/star U-1 = (U-star U)/star U by rw [sub_div,div_self (star_ne_zero.mpr hU)],
    norm_div,norm_star,hnorm,hnum]
  ring

/-- §4.4, footnote 2. Apply Lemma 3.4 directly to the first and last
selected indices. Comparing the two bounds cancels the positive cube. -/
theorem section44_one_gap {P : Parameters} (h : P.Admissible) (hn : P.normAlpha < 0)
    {i j : ℤ} (p : SquarePhase P h.pell i) (q : SquarePhase P h.pell j)
    (hij : (P.y h.pell i : ℝ) < (P.y h.pell j : ℝ))
    (hl : 4 * Real.sqrt (|(P.normAlpha : ℝ)| / P.d) ≤ (P.y h.pell i : ℝ))
    (hc : SamePhaseClass p.ζ q.ζ)
    (h415 : (P.y h.pell j : ℝ) < (1734 / 1000 : ℝ) *
      (4 * P.d / |(P.normAlpha : ℝ)|) * (P.y h.pell i : ℝ)^3) :
    let A := (1536 / 100 : ℝ) * ((P.d : ℝ) / (16 * (P.b : ℝ)^2 * |(P.normAlpha : ℝ)|^2))^2
    let B := (694 / 100 : ℝ) * P.d / |(P.normAlpha : ℝ)|
    A * (P.y h.pell i : ℝ)^3 < (P.y h.pell j : ℝ) ∧
      (P.y h.pell j : ℝ) < B * (P.y h.pell i : ℝ)^3 ∧
      (A * (P.y h.pell i : ℝ)^3 < B * (P.y h.pell i : ℝ)^3 ↔ A < B) := by
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hN : 0 < |(P.normAlpha : ℝ)| := abs_pos.mpr (by exact_mod_cast hn.ne)
  have hy : 0 < (P.y h.pell i : ℝ) := p.cert.1 ▸ p.datum.y_pos
  have hu := Section4.exact_equation415_index_one (z := (P.y h.pell j : ℝ)) hN hd hy
    (by simpa only [Real.sqrt_one, mul_one, pow_one] using h415)
  exact ⟨lemma34_pair h hn p q hij hl hc, hu, mul_lt_mul_iff_left₀ (pow_pos hy 3)⟩

/-- The two consecutive applications of Lemma 3.4 in §§4.3–4.4 use the
same three phases chosen in §4.1. -/
theorem section44_two_gaps {P : Parameters} (h : P.Admissible) (hn : P.normAlpha < 0)
    {i j k : ℤ} (p : SquarePhase P h.pell i) (q : SquarePhase P h.pell j)
    (s : SquarePhase P h.pell k)
    (hij : (P.y h.pell i : ℝ) < (P.y h.pell j : ℝ))
    (hjk : (P.y h.pell j : ℝ) < (P.y h.pell k : ℝ))
    (hl : 4 * Real.sqrt (|(P.normAlpha : ℝ)| / P.d) ≤ (P.y h.pell i : ℝ))
    (hpq : SamePhaseClass p.ζ q.ζ) (hqs : SamePhaseClass q.ζ s.ζ) :
    let G := (1536 / 100 : ℝ) * ((P.d : ℝ) / (16 * (P.b : ℝ)^2 * |(P.normAlpha : ℝ)|^2))^2
    G * (P.y h.pell i : ℝ)^3 < (P.y h.pell j : ℝ) ∧
      G * (P.y h.pell j : ℝ)^3 < (P.y h.pell k : ℝ) ∧
      G^4 * (P.y h.pell i : ℝ)^9 < (P.y h.pell k : ℝ) := by
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hb : (0 : ℝ) < P.b := by exact_mod_cast h.b_pos
  have hN : 0 < |(P.normAlpha : ℝ)| := abs_pos.mpr (by exact_mod_cast hn.ne)
  exact AnyBNormSquare.Case42.gap_twice (by positivity) (p.cert.1 ▸ p.datum.y_pos)
    (lemma34_pair h hn p q hij hl hpq) (lemma34_pair h hn q s hjk (hl.trans hij.le) hqs)

/-- Rearranging the two sides of the displayed chain before (4.16),
cancel the positive cube, take sixth roots and round the coefficient up. -/
theorem section44_bound {d b N y z : ℝ} (hd : 0 < d) (hb : 0 < b)
    (hN : 0 < N) (hy : 0 < y)
    (hl : ((1536 / 100 : ℝ) * (d / (16 * b^2 * N^2))^2)^4 * y^9 < z)
    (hu : z < (694 / 100 : ℝ) * d / N * y^3) :
    y < (91 / 10 : ℝ) * b^(8/3 : ℝ) * N^(5/2 : ℝ) / d^(7/6 : ℝ) := by
  have h := hl.trans hu
  have h6 : (1536 / 100 : ℝ)^4 * d^7 * y^6 <
      (694 / 100 : ℝ) * 16^8 * b^16 * N^15 := by
    field_simp at h
    linarith only [h]
  apply (pow_lt_pow_iff_left₀ hy.le (by positivity) (by decide : (6 : ℕ) ≠ 0)).mp
  rw [div_pow, mul_pow, mul_pow, ← Real.rpow_mul_natCast hb.le,
    ← Real.rpow_mul_natCast hN.le, ← Real.rpow_mul_natCast hd.le]
  norm_num
  apply (lt_div_iff₀ (pow_pos hd 7)).mpr
  have hround : (694 / 100 : ℝ) * 16^8 < (1536 / 100 : ℝ)^4 * (91 / 10 : ℝ)^6 := by
    norm_num
  have hh := h6.trans (mul_lt_mul_of_pos_right (mul_lt_mul_of_pos_right hround
    (pow_pos hb 16)) (pow_pos hN 15))
  linarith only [hh]

end AnyBAnyNorm
