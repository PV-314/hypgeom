module

public import AnyBNormSquare.Corollary16
public import «JNT-2024».Section5AssemblyRevised

@[expose] public section
namespace AnyBAnyNorm.QuotedResults
open «JNT-2024» AnyBNormSquare

/-- The §1.2 least-square hypothesis refers to the even-power sequence in both conjectures. -/
def conjecture11 : Prop :=
  ∀ (P : Parameters) (h : P.Admissible), SmallestInitialSquare P h.pell →
    AtMostSquareValues (P.y h.pell) 4 ∧
    ((∃ p : ℕ, p.Prime ∧ Odd p ∧ squarefreePart |P.normAlpha| ∣ 2*(p:ℤ)) →
      AtMostSquareValues (P.y h.pell) 3) ∧
    (IsSquare |P.normAlpha| → AtMostSquareValues (P.y h.pell) 2)

def conjecture12 : Prop :=
  ∀ (P : Parameters) (h : P.Admissible), SmallestInitialSquare P h.pell → AtMostSquareValues (P.generalY h.pell) 4 ∧
    ((IsPrimePow P.normAlpha.natAbs ∨ IsSquare |P.normAlpha|) →
      AtMostSquareValues (P.generalY h.pell) 3)

/-- By (1.1) and (1.5), restricting to even powers preserves any upper
bound on the number of distinct integer squares. -/
theorem atMostSquareValues_even (P : Parameters) (hp : P.Pell) {n : ℕ}
    (h : AtMostSquareValues (P.generalY hp) n) : AtMostSquareValues (P.y hp) n := by
  obtain ⟨S, hcard, cover⟩ := h
  refine ⟨S, hcard, ?_⟩
  intro k hk
  rw [← P.generalY_even hp k] at hk ⊢
  exact cover (2*k) hk

/-- The bounds obtained by restricting the two clauses of Conjecture 1.2
to the even-indexed elements. -/
theorem even_bounds_of_conjecture12 (hc : conjecture12) (P : Parameters) (h : P.Admissible)
    (hm : SmallestInitialSquare P h.pell) :
    AtMostSquareValues (P.y h.pell) 4 ∧
    ((IsPrimePow P.normAlpha.natAbs ∨ IsSquare |P.normAlpha|) →
      AtMostSquareValues (P.y h.pell) 3) := by
  obtain ⟨four, three⟩ := hc P h hm
  exact ⟨atMostSquareValues_even P h.pell four,
    fun hn => atMostSquareValues_even P h.pell (three hn)⟩

/-- Theorem 1.3, including the four exceptional cases of corrected Theorem 1.4 in [11]. -/
abbrev theorem13 := @«JNT-2024».theorem14_paper_revised

/-- Theorem 1.4, quoted from Theorem 1.2 in [12]. -/
def Theorem14 : Prop :=
  ∀ (P : Parameters) (h : P.Admissible), P.b=1 →
    (∃ (p m s : ℕ), p.Prime ∧ s ≤ 4 ∧ -P.normAlpha = ((2^s*p^m : ℕ) : ℤ)) →
    AtMostSquareValues (P.y h.pell) 4 ∧
    ((∃ p : ℕ, p.Prime ∧ Odd p ∧ squarefreePart |P.normAlpha| ∣ 2*(p : ℤ)) →
      AtMostSquareValues (P.y h.pell) 3) ∧
    (IsSquare |P.normAlpha| → AtMostSquareValues (P.y h.pell) 2)

/-- The b in Theorem 1.2 of [12] is −Nα here. Its two conclusions are the
bound three, and the bound two if that b is a square. -/
theorem theorem14_of_cited_theorem12
    (cited : ∀ (P : Parameters) (h : P.Admissible), P.b = 1 →
      ∀ B : ℤ, 0 < B → P.d = P.a ^ 2 + B →
      (∃ p m s : ℕ, p.Prime ∧ s ≤ 4 ∧ B = ((2^s*p^m : ℕ) : ℤ)) →
      AtMostSquareValues (P.y h.pell) 3 ∧
      (IsSquare B → AtMostSquareValues (P.y h.pell) 2)) : Theorem14 := by
  intro P h hb hform
  have hpos : 0 < -P.normAlpha := by
    obtain ⟨p, m, s, hprime, _, heq⟩ := hform
    rw [heq]
    exact_mod_cast Nat.mul_pos (by positivity : 0 < 2^s) (pow_pos hprime.pos m)
  have hd : P.d = P.a ^ 2 + -P.normAlpha := by
    simp [Parameters.normAlpha, hb]
  obtain ⟨three, two⟩ := cited P h hb (-P.normAlpha) hpos hd hform
  obtain ⟨S, hcard, cover⟩ := three
  refine ⟨⟨S, by omega, cover⟩, fun _ => ⟨S, hcard, cover⟩, ?_⟩
  simpa only [abs_of_neg (by omega : P.normAlpha < 0)] using two

/-- Theorem 1.5(a) and (b), from Corollary 1.5 of [13]. -/
abbrev theorem15a := @AnyBNormSquare.CorollaryProof.corollary15a_conditional
abbrev theorem15b := @AnyBNormSquare.CorollaryProof.corollary15b_conditional

/-- Theorem 1.6, quoted from Corollary 1.9 of [14]. Its cited sequence bound for the
indices used in §5.6 is separately identified in Section56Norms. -/
def Theorem16 : Prop :=
  ∀ (P : Parameters) (h : P.Admissible), P.normAlpha < 0 →
    (∃ (p m l : ℕ), p.Prime ∧ p ≠ 2 ∧ -P.normAlpha = ((2^l*p^m : ℕ) : ℤ)) →
    SmallestInitialSquare P h.pell →
    (P.b ≤ 7 ∨ (8 ≤ P.b ∧ 37*(P.b : ℝ)^(28/13 : ℝ)*|(P.normAlpha : ℝ)|^(1/2 : ℝ)/
       (P.u : ℝ)^(24/13 : ℝ) ≤ P.d)) → AtMostSquareValues (P.y h.pell) 7

end AnyBAnyNorm.QuotedResults
