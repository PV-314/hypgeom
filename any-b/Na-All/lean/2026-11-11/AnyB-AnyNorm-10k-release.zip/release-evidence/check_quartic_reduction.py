"""Check the solver's scale and both coordinates on the recorded §5.6 points."""
import argparse
from collections import Counter
from math import gcd, isqrt
from pathlib import Path
import re
import subprocess
import sys

project = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(project))
from check_section56 import solver_results

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("gp", type=Path)
args = parser.parse_args()
transcript = project / "evidence/b1-4-nAAll-solve-output-2026-10-28a.txt"
_, _, rows = solver_results(transcript)
program = ['read("quartic-solver.gp");']
expected = []
scales = Counter()
reduced = {}
for (d, n), points in sorted(rows.items()):
    g = gcd(d, -n)
    c = max(k for k in range(1, isqrt(g) + 1) if g % (k*k) == 0)
    D, N = d//(c*c), n//(c*c)
    scales[c] += 1
    program.append(f'print(qt_square_normalise({d},{n})==[{D},{N},{c}]);')
    program.append(f'print(core({-n},1)==[core({-N}),{c}*core({-N},1)[2]]);')
    expected.extend(["1", "1"])
    restored = set()
    for x, y in points:
        X, r = divmod(x, c)
        assert r == 0 and X > 0 and X**2 - D*y**4 == N
        restored.add((X,y))
    assert {(c*X,y) for X,y in restored} == set(points)
    assert reduced.setdefault((D,N), restored) == restored
forms = set(re.findall(r"^starting a Thue equation: form=([^,]+), RHS=", transcript.read_text(), re.M))
assert forms
for form in sorted(forms):
    assert re.fullmatch(r"[0-9qtU*^ +\-]+", form)
    program.append(f'print(polisirreducible({form}));')
run = subprocess.run([args.gp, "-fq"], cwd=project/"release-evidence/hypgeom/general/pari",
                     input="\n".join([*program,'print("END")',"quit"])+"\n",
                     capture_output=True, text=True, check=True)
lines = run.stdout.strip().splitlines()
assert not run.stderr and lines[-1] == "END", (run.stderr, lines[-1:])
assert lines[:len(expected)] == expected
flags = lines[len(expected):-1]
assert len(flags) == len(forms) and set(flags) <= {"0","1"}
print("Scales by number of original equations:", dict(sorted(scales.items())))
print("Original equations:", len(rows), "distinct reduced equations:", len(reduced))
print("Positive points checked in both directions:", sum(map(len,rows.values())))
print("Distinct transcript polynomials:", len(forms), "irreducible:", flags.count("1"))
for form, flag in zip(sorted(forms),flags):
    if flag == "0":
        print("Reducible polynomial:", form)
