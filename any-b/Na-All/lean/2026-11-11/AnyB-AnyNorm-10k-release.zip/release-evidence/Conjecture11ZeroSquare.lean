import AnyBAnyNorm.QuotedResults
import Mathlib.RingTheory.Int.Basic

open «JNT-2024»

namespace AnyBAnyNorm.Conjecture11ZeroSquare

private def P : Parameters := ⟨3, 1, 5, 1, 1⟩

private theorem admissible : P.Admissible := by
  refine ⟨by decide, by decide, by decide, by decide, by decide, ?_, Or.inr (by decide)⟩
  exact (Int.prime_iff_natAbs_prime.mpr (by decide : Nat.Prime (5 : ℤ).natAbs)).not_isSquare

private theorem values :
    P.y admissible.pell (-1) = 0 ∧ P.y admissible.pell 0 = 1 ∧ P.y admissible.pell 5 = 144 := by
  have prev := P.y_neg_one admissible.pell
  have step (k : ℤ) : P.y admissible.pell (k+1) =
      3 * P.y admissible.pell k - P.y admissible.pell (k-1) := by
    convert P.y_recurrence admissible.pell k using 1
    norm_num [P]
  have r₀ := step 0
  have r₁ := step 1
  have r₂ := step 2
  have r₃ := step 3
  have r₄ := step 4
  norm_num [P] at prev r₀ r₁ r₂ r₃ r₄
  refine ⟨prev, by norm_num [P], ?_⟩
  dsimp only [P]
  linarith only [r₀, r₁, r₂, r₃, r₄, prev]

/-- The example fails the standing least-square hypothesis in §1.2. -/
theorem not_smallest : ¬ AnyBNormSquare.SmallestInitialSquare P admissible.pell := by
  intro hm
  have hzero := values.1
  have bound := hm (-1) ⟨0, by simpa using hzero⟩
  rw [hzero] at bound
  norm_num [P] at bound

/-- Removing the least-square hypothesis gives a false unrestricted statement. -/
theorem not_unrestricted_conjecture11 : ¬AnyBNormSquare.Conjecture11 := by
  intro conjecture
  have squareNorm : IsSquare |P.normAlpha| := ⟨2, by decide⟩
  obtain ⟨S, hcard, cover⟩ := (conjecture P admissible).2.2 squareNorm
  obtain ⟨hm, h₀, h₅⟩ := values
  have hmem (k z : ℤ) (hy : P.y admissible.pell k = (z : ℚ)^2) : (z : ℚ)^2 ∈ S :=
    hy ▸ cover k ⟨z, hy⟩
  have m := hmem (-1) 0 (by simpa using hm)
  have u := hmem 0 1 (by simpa using h₀)
  have v := hmem 5 12 (by norm_num; exact h₅)
  norm_num at m u v
  have sub : ({0, 1, 144} : Finset ℚ) ⊆ S := by
    simpa only [Finset.insert_subset_iff, Finset.singleton_subset_iff] using And.intro m ⟨u, v⟩
  have hthree : ({0, 1, 144} : Finset ℚ).card = 3 := by decide
  have hle := Finset.card_le_card sub
  omega

end AnyBAnyNorm.Conjecture11ZeroSquare

#print axioms AnyBAnyNorm.Conjecture11ZeroSquare.not_unrestricted_conjecture11
