import AnyBNormSquare.Targets
import Mathlib.RingTheory.Int.Basic

open «JNT-2024» AnyBNormSquare

private def P : Parameters := ⟨6, 2, 2, 2, 2⟩

private theorem admissible : P.Admissible := by
  refine ⟨by decide, by decide, by decide, by decide, by decide, ?_, Or.inr (by decide)⟩
  exact (Int.prime_iff_natAbs_prime.mpr (by decide : Nat.Prime (2 : ℤ).natAbs)).not_isSquare

example : P.normAlpha = 4 := by decide

private theorem zero_at_neg_one : P.y admissible.pell (-1) = 0 := by
  rw [P.y_neg_one]
  norm_num [P]

example : ¬SmallestInitialSquare P admissible.pell := by
  intro minimum
  have sq : IsIntegerSquare (P.y admissible.pell (-1)) :=
    ⟨0, by rw [zero_at_neg_one]; norm_num⟩
  have le := minimum (-1) sq
  rw [zero_at_neg_one] at le
  norm_num [P] at le
