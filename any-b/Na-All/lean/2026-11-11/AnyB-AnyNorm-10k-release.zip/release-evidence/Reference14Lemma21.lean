import AnyBAnyNorm.Diophantine

namespace AnyBAnyNorm.Reference14

/-- The scaled approximants in [14, Lemma 2.1] satisfy the three
field-membership hypotheses of 10i, Lemma 2.1, at the same index. -/
theorem products_mem (K : IntermediateField ℚ ℂ) {g' p q : ℂ} (r : ℕ)
    (hg : g'^2 ≠ 0) (hgK : g'^2 ∈ K)
    (hp : g'^r*p ∈ K) (hq : g'^r*q ∈ K) :
    p^2 ∈ K ∧ p*q ∈ K ∧ q^2 ∈ K := by
  have product {a b : ℂ} (ha : g'^r*a ∈ K) (hb : g'^r*b ∈ K) : a*b ∈ K := by
    have h := div_mem (mul_mem ha hb) (pow_mem hgK r)
    have he : (g'^r*a)*(g'^r*b) / (g'^2)^r = a*b := by
      apply (div_eq_iff (pow_ne_zero r hg)).mpr
      rw [← pow_mul, Nat.mul_comm 2 r, pow_mul]
      ring
    rwa [he] at h
  simpa only [pow_two] using And.intro (product hp hp) ⟨product hp hq, product hq hq⟩

/-- Apply 10i with the same comparison elements, constants and least
positive index as in [14]. The embedding of its ambient field in ℂ
lets us view its approximants as complex numbers. -/
theorem lemma21_of_scaled (K : IntermediateField ℚ ℂ) [NumberField K]
    [NumberField.IsTotallyComplex K] (hdegree : Module.finrank ℚ K = 2)
    (θ : ℂ) (pr qr : ℕ → ℂ) {g' : ℂ} (hg : g'^2 ≠ 0) (hgK : g'^2 ∈ K)
    (hpr : ∀ r, IsIntegral ℤ (pr r)) (hqr : ∀ r, IsIntegral ℤ (qr r))
    (hpK : ∀ r, g'^r*pr r ∈ K) (hqK : ∀ r, g'^r*qr r ∈ K)
    {c k₀ ℓ₀ E Q : ℝ} (hk : 0 < k₀) (hℓ : 0 < ℓ₀) (hE : 1 < E)
    (hQ : 1 < Q) (hc : 0 < c) (hc1 : c < 1)
    (hqb : ∀ r, ‖qr r‖ < k₀*Q^r)
    (herr : ∀ r, ‖qr r*θ-pr r‖ ≤ ℓ₀*E^(-(r : ℤ)))
    (hind : ∀ r, pr r*qr (r+1) ≠ pr (r+1)*qr r)
    (p q : K) (hp : IsIntegral ℤ p) (hq : IsIntegral ℤ q) (hpq : ¬ (p=0 ∧ q=0)) :
    ApproximationConclusion θ p q pr qr k₀ ℓ₀ E Q c hE hc := by
  have h r := products_mem K r hg hgK (hpK r) (hqK r)
  exact lemma21 hdegree (RingHom.id ℂ) θ p q pr qr hp hq hpr hqr
    (fun r => ⟨⟨_, (h r).1⟩, rfl⟩) (fun r => ⟨⟨_, (h r).2.1⟩, rfl⟩)
    (fun r => ⟨⟨_, (h r).2.2⟩, rfl⟩) hpq hk hℓ hE hQ hc hc1 hqb herr hind

#print axioms lemma21_of_scaled

end AnyBAnyNorm.Reference14
