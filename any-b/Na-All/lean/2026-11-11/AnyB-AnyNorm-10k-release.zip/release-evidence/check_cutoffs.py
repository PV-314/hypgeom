"""Recheck the three cutoff comparisons on the Java tuples and the current Lean records."""

import argparse
import re
from collections import Counter
from fractions import Fraction
from math import isqrt
from pathlib import Path
import hashlib
import json


def square_hits(params, uniform_norm, java_third_term):
    a, b, d, t, u = params
    norm = d*b**4 - (1 if uniform_norm else a**2)
    first = Fraction(109, 10)**11 * b**26 * norm**26
    second = Fraction(91, 10)**6 * b**16 * norm**15
    trace = Fraction(t*t + d*u*u, 2)
    assert trace > 2
    hits = []
    for sign in (1, -1):
        previous = b*b
        y = Fraction(b*b*(t*t + d*u*u) + sign*2*a*t*u, 4)
        cutoff_index = None
        j = 1
        while True:
            assert y > 0
            third = (y*y*d <= (423*b*b*norm**3)**2 if java_third_term
                     else y*d <= 598*b*b*norm**3)
            within = y**11*d**12 <= first or y**6*d**7 <= second or third
            # Once y > previous > 0, recurrence (1.3) gives strict increase
            # at every later step. The three cutoff terms are constant here.
            if y > previous and not within:
                break
            if cutoff_index is None and y > b*b:
                cutoff_index = j
            eligible = (j >= 3 if sign == 1 else
                        cutoff_index is not None and j >= cutoff_index + 2)
            if within and eligible and y.denominator == 1 and isqrt(y.numerator)**2 == y:
                hits.append((sign*j, y.numerator))
            previous, y = y, trace*y - previous
            j += 1
    return hits


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("java_transcript", type=Path)
    raw = parser.parse_args().java_transcript.read_bytes()
    if hashlib.sha256(raw).hexdigest() != "6a67e8ffd3080d1b465b567e7bc5409c72bddf05e4b06f027382fdc280351a6c":
        raise ValueError("Unexpected Java transcript")
    java = {(a,b,d,t,u) for d,a,b,t,u in (map(int, hit) for hit in re.findall(
        r"^adding d=\s*(\d+), a=\s*(\d+), b=\s*(\d+), t=\s*(\d+), u=\s*(\d+),", raw.decode("utf8"), re.M))}
    sources = Path(__file__).resolve().parents[1] / "AnyBAnyNorm"
    def tuples(filename, opening):
        source = (sources/filename).read_text(encoding="utf8")
        pattern = "^  " + opening + r"(\d+), (\d+), (\d+), (\d+), (\d+)⟩"
        return [tuple(map(int,m)) for m in re.findall(pattern,source,re.M)]
    rows = tuples("Section56Size.lean","⟨⟨")
    retained = set(tuples("PostJava.lean","⟨"))
    eligible = {p for p in java if square_hits(p, False, False)}
    assert set(rows) == eligible and len(rows) == len(eligible) == 189
    assert len(retained) == 175 and retained <= eligible
    for b in (1, 2, 3):
        fresh = (sources.parent / "release-evidence" / f"10h-java-b{b}.txt").read_text(encoding="utf8")
        hits = {(a, bb, d, t, u) for d, a, bb, t, u in (map(int, m) for m in re.findall(
            r"^adding d=\s*(\d+), a=\s*(\d+), b=\s*(\d+), t=\s*(\d+), u=\s*(\d+),", fresh, re.M))}
        assert hits == {p for p in eligible if p[1] == b}
        print("Reproduced Java and Lean tuples for b =", b, ":", len(hits))
    november = (sources.parent / "release-evidence" / "BAllNaAllSearch-b-1-4-2026-11-10a.txt").read_bytes()
    assert hashlib.sha256(november).hexdigest() == "6d30cc415841fefc6fca4d289336c615b84786bb5a55113ec29cd14858b29653"
    transcript = november.decode("utf8")
    reported = set()
    for line in transcript.splitlines():
        if line.startswith("adding d="):
            d, a, b, t, u = map(int, re.findall(r"(?:d|a|b|t|u)=\s*(\d+)", line))
            k, four_y = map(int, re.search(r"k=\s*(-?\d+), 4\*yCurr=\s*(\d+)", line).groups())
            params = (a, b, d, t, u)
            assert params not in reported and four_y % 4 == 0
            assert (k, four_y // 4) in square_hits(params, False, False)
            reported.add(params)
    assert reported == set(rows)
    root = sources.parent
    entry = json.loads((root / "inputs.lock.json").read_text())["tex"]
    tex = Path(entry["path"])
    bundled = root / "inputs" / tex.name
    manuscript = (bundled if bundled.is_file() else tex).read_bytes()
    assert hashlib.sha256(manuscript).hexdigest() == entry["sha256"]
    table = manuscript.decode("utf8").split(r"\caption{Data for $b$}", 1)[0].rsplit(r"\begin{tabular}", 1)[1]
    for b, u, c1, c2 in [(1,12,2489,6), (2,13,40959738,27), (3,29,11961962029,80), (4,52,671349959367,76)]:
        assert f"done b={b}, u={u}: total examined tuples {c1} total retained tuples, c2={c2}." in transcript
        assert sum(p[1] == b for p in reported) == c2
        ms = re.search(rf"^for b={b}, total time=(\d+)\(ms\)\.", transcript, re.M).group(1)
        seconds = (int(ms) + 500) // 1000
        minutes, seconds = divmod(seconds, 60)
        timing = "$<1$s" if int(ms) < 1000 else (f"{minutes}m " if minutes else "") + f"{seconds}s"
        fields = next(line.split("&") for line in table.splitlines() if re.match(rf"^\s*{b}\s*&", line))
        assert [int(x.strip().strip("$").replace(",", "")) for x in fields[3:5]] == [c1, c2]
        assert fields[5].split("\\\\")[0].strip() == timing
        print(f"10 November transcript: b={b}, c1={c1}, c2={c2}, elapsed {ms} ms; every tuple and square witness checked.")
    for name, uniform, historical_third in (("Proposition 4.1", False, False),
                                ("Only replace |N| by db^4-1", True, False),
                                ("Both Java enlargements", True, True)):
        counts = Counter()
        for p in sorted(java):
            if square_hits(p, uniform, historical_third):
                counts[p[1]] += 1
            elif not uniform:
                print(p, "Java square occurrences", square_hits(p, True, True),
                      "retained among 175:", p in retained)
        print(name, [counts[b] for b in range(1, 5)])


if __name__ == "__main__":
    main()
