import AnyBAnyNorm.Section56Norms

open AnyBAnyNorm.Section56

set_option maxRecDepth 16384 in
set_option maxHeartbeats 6000000 in
/-- The square-norm equations in the retained list also satisfy the norm
condition of [14, Theorem 1.8(a)]. -/
theorem squareNormsInPostJavaEquations :
    let squares := postJavaEquations.filter fun e => e.2.natAbs.sqrt ^ 2 = e.2.natAbs
    squares.card = 11 ∧
      squares.filter (fun e => let m := e.2.natAbs.divMaxPow 2
        ¬ (m = 1 ∨ IsPrimePow m)) = ∅ := by
  decide +kernel
