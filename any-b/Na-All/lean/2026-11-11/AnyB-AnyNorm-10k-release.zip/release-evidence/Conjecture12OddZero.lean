import AnyBAnyNorm.QuotedResults
import Mathlib.RingTheory.Int.Basic

open «JNT-2024»

namespace AnyBAnyNorm.Conjecture12OddZero

private def P : Parameters := ⟨1, 1, 2, 2, 2⟩

private theorem admissible : P.Admissible := by
  refine ⟨by decide, by decide, by decide, by decide, by decide, ?_, Or.inr (by decide)⟩
  exact (Int.prime_iff_natAbs_prime.mpr (by decide : Nat.Prime (2 : ℤ).natAbs)).not_isSquare

/-- The unprimed sequence meets both standing square conditions of §1.2.
The primed sequence of (1.5) has a zero term at index −1. -/
theorem standing_conditions_and_primed_zero :
    AnyBNormSquare.SmallestInitialSquare P admissible.pell ∧
    (∀ k, IsIntegerSquare (P.y admissible.pell k) → P.x admissible.pell k ≠ 0) ∧
    P.generalY admissible.pell (-1) = 0 := by
  have least : AnyBNormSquare.SmallestInitialSquare P admissible.pell := by
    intro k ⟨n, hn⟩
    have hpos := P.y_pos admissible (by decide) k
    rw [hn] at hpos ⊢
    change (1 : ℚ) ^ 2 ≤ (n : ℚ) ^ 2
    have hp : (0 : ℤ) < n ^ 2 := by exact_mod_cast hpos
    have hle : (1 : ℤ) ^ 2 ≤ n ^ 2 := by omega
    exact_mod_cast hle
  refine ⟨least, ?_, ?_⟩
  · intro k hs hx
    have hm := least k hs
    change (1 : ℚ) ^ 2 ≤ P.y admissible.pell k at hm
    have he := P.norm_identity admissible.pell k
    rw [hx] at he
    change (0 : ℚ) ^ 2 - 2 * P.y admissible.pell k ^ 2 = -1 at he
    nlinarith [sq_nonneg (P.y admissible.pell k - 1)]
  · rw [← Section6.evalGeneral_eq P admissible.pell]
    change (P.alpha * (if (-1 : ℤ) < 0 then P.epsilonBack else P.epsilon) ^ 1).im = 0
    rw [ite_eq_left (by decide), pow_one]
    norm_num [Parameters.alpha, Parameters.epsilonBack, Parameters.epsilonNorm, P,
      QuadraticAlgebra.im_one]

end AnyBAnyNorm.Conjecture12OddZero

#print axioms AnyBAnyNorm.Conjecture12OddZero.standing_conditions_and_primed_zero
