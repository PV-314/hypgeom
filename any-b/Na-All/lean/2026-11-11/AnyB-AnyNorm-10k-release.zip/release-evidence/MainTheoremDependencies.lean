module

import all AnyBAnyNorm.Theorem18
import all AnyBAnyNorm.Section56Bounds
import all AnyBAnyNorm.FiniteRange
import all AnyBAnyNorm.Section55
import all AnyBAnyNorm.Consolidation
import all AnyBAnyNorm.FourCases
import all AnyBAnyNorm.Section42
import all AnyBAnyNorm.Prerequisites
import all AnyBAnyNorm.SequenceLemmas
import all AnyBAnyNorm.IndexSelection
import all AnyBAnyNorm.Diophantine
import Lean

open Lean Elab Command

/-- Follow the constants in the project's proof terms. The two main theorems
must actually use the revised Lemma 2.1 at the comparison pair in §4.2. -/
private partial def visitProof (env : Environment) (n : Name) (seen : NameSet) : NameSet := Id.run do
  if seen.contains n then return seen
  let some idx := env.getModuleIdxFor? n | return seen
  unless env.header.moduleNames[idx.toNat]!.getRoot == `AnyBAnyNorm do return seen
  let seen := seen.insert n
  let some info := env.find? n | return seen
  let some proof := info.value? (allowOpaque := true) | return seen
  return proof.getUsedConstants.foldl (fun acc dep => visitProof env dep acc) seen

run_cmd do
  let env ← getEnv
  for endpoint in [`AnyBAnyNorm.theorem17, `AnyBAnyNorm.theorem18a,
      `AnyBAnyNorm.theorem18b, `AnyBAnyNorm.theorem18_paper] do
    let deps := visitProof env endpoint {}
    if endpoint == `AnyBAnyNorm.theorem18_paper then
      unless deps.contains `AnyBAnyNorm.squareNormBound_of_theorem14a &&
          deps.contains `AnyBAnyNorm.Section56.covered_tail do
        throwError "Missing the application of the cited tail bounds in §5.6."
      if deps.contains `AnyBAnyNorm.squareNormBoundForSmallB then
        throwError "Theorem 1.8 unexpectedly expands the proof from [13]."
      logInfo "Theorem 1.8 applies the cited hypotheses from [13] and [14] in §5.6."
    for needed in [`AnyBAnyNorm.section42_cutoff, `AnyBAnyNorm.section42_apply,
        `AnyBAnyNorm.Construction.approximant_products_mem, `AnyBAnyNorm.lemma21,
        `AnyBAnyNorm.determinant_norm, `AnyBAnyNorm.imaginary_quadratic_norm,
        `AnyBAnyNorm.least_phase, `AnyBAnyNorm.lemma36] do
      unless deps.contains needed do throwError "{endpoint}: missing proof dependency {needed}"
    if endpoint == `AnyBAnyNorm.theorem18a || endpoint == `AnyBAnyNorm.theorem18_paper then
      unless deps.contains `AnyBAnyNorm.Section56.beforeCoefficientBound_of_last_coefficient_bound do
        throwError "{endpoint}: missing the bound at the last selected index"
      logInfo m!"{endpoint} uses the bound on the last coefficient in §5.6."
    logInfo m!"{endpoint} uses Lemmas 2.1 and 3.6, the §2.1 products, and the least coefficient."
