"""Reconcile the November Java transcript, the published PARI programs and the Lean records."""
import argparse
import csv
import re
import subprocess
import sys
from ast import literal_eval
from collections import Counter, defaultdict
from fractions import Fraction
from math import isqrt
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from check_section56 import covered, solver_results
from check_section56_refinement import bound_terms, floor_root, candidates
from check_cutoffs import square_hits

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("github", type=Path)
parser.add_argument("gp", type=Path)
parser.add_argument("archived_pari_dir", type=Path)
parser.add_argument("csv", type=Path)
args = parser.parse_args()
pari = args.github.resolve() / "any-b/Na-All/pari"
transcript = (ROOT/"release-evidence/BAllNaAllSearch-b-1-4-2026-11-10a.txt").read_text().splitlines()

def norm(p):
    a,b,d,t,u = p
    return a*a-d*b**4

def values(pattern, line):
    return tuple(map(int, re.fullmatch(pattern, line.strip()).groups()))

def execute(lines):
    proc = subprocess.run([args.gp, "-fq", "-s", "128M"], cwd=pari, input="\n".join(lines + ['print("END_OF_AUDIT")'])+"\n",
                          capture_output=True, text=True)
    if proc.returncode or proc.stderr.strip() or proc.stdout.splitlines()[-1] != "END_OF_AUDIT":
        raise RuntimeError(proc.stderr + proc.stdout[-1000:])
    return proc.stdout.splitlines()

java, printed = {}, Counter()
for i,line in enumerate(transcript):
    if line.startswith("adding "):
        d,a,b,t,u = map(int, re.findall(r"(?:d|a|b|t|u)=\s*(\d+)",line))
        p = a,b,d,t,u
        k,z = map(int,re.search(r"k=\s*(-?\d+), 4\*yCurr=\s*(\d+)$",line).groups())
        assert abs(t*t-d*u*u)==4 and norm(p)<0 and p not in java
        assert z%4==0 and (k,z//4) in square_hits(p,False,False)
        if k<0:
            K = int(re.search(r"K=\s*(-?\d+)",line)[1])
            prev=b*b
            trace=Fraction(t*t+d*u*u,2)
            y=Fraction(b*b*(t*t+d*u*u)-2*a*t*u,4)
            for j in range(1,1-K):
                if j < -K: assert y<=b*b
                else: assert y>b*b and k<=K-2
                prev,y=y,trace*y-prev
        else: assert k>=3
        java[p]=i+1,k,z//4
        D,N,U=values(r"d=\s*(\d+);nrmA=\s*(-\d+);u=\s*(\d+);check_b_d_n_u\(b,d,nrmA,u,dbg\);",transcript[i+1])
        assert (D,N,U)==(d,norm(p),u)
        printed[(b,d,N,u)]+=1
assert sum(line.startswith("d=") for line in transcript)==len(java)==189
# Check the cumulative counts both within each t loop and at the end of every u.
progress = {}
completed = {}
for line in transcript:
    if m:=re.match(r"b=\s*(\d+), t=\s*(\d+) \(u=\s*(\d+) is .*?c1=\s*(\d+), c2=\s*(\d+),",line):
        b,t,u,c1,c2=map(int,m.groups())
        progress[b,u,t]=(c1,c2)
    if m:=re.match(r"done b=(\d+), u=(\d+): total examined tuples (\d+) total retained tuples, c2=(\d+)\.",line):
        b,u,c1,c2=map(int,m.groups())
        completed[b,u]=(c1,c2)
witness_counts=Counter((b,u,t) for a,b,d,t,u in java)
progress_count=len(progress)
completed_count=len(completed)
for b,U in enumerate([13,14,30,53],1):
    c1=c2=0
    for u in range(1,U):
        D=max(floor_root(*v) for v in bound_terms(b,u))
        last=max([isqrt(D*u*u+4)]+[t for bb,uu,t in progress if (bb,uu)==(b,u)])
        for t in range(1,last+1):
            for num in [t*t+4,t*t-4]:
                if num>0 and num%(u*u)==0 and num//(u*u)<=D:
                    c1+=isqrt(num//(u*u)*b**4-1)
            c2+=witness_counts[b,u,t]
            if (b,u,t) in progress: assert progress.pop((b,u,t))==(c1,c2)
        assert completed.pop((b,u))==(c1,c2)
assert not progress and not completed
print("Verified cumulative c1 and c2 at",progress_count,"intermediate t values and",completed_count,"completed u values.")


inputs = defaultdict(list)
keys = Counter()
for i,line in enumerate((pari/"b1-4-nAAll-post-java-checks.gp").read_text().splitlines(),1):
    line=line.strip()
    if m:=re.fullmatch(r"check_b([1-4])\(\)=\{",line): b=int(m[1])
    if line.startswith("d="):
        d,N,u = values(r"d=\s*(\d+);nrmA=\s*(-\d+);u=\s*(\d+);check_b_d_n_u\(b,d,nrmA,u,dbg\);",line)
        keys[(b,d,N,u)]+=1
        a=isqrt(d*b**4+N)
        assert a*a==d*b**4+N
        for t2 in [d*u*u+4,d*u*u-4]:
            if t2>0 and isqrt(t2)**2==t2:
                inputs[(a,b,d,isqrt(t2),u)].append(i)

direct = [f"check_b_d_n_t_u({b},{d},{norm(p)},{t},{u},0);" for p in java for a,b,d,t,u in [p]]
entry = [f"check_b{b}();" for b in range(1,5)]
def output_tuples(lines):
    tuples=[]
    for line in lines:
        if not line.strip().startswith("a=") or "check_d_n(" not in line: continue
        a,b,d,t,u,N=values(r"a=\s*(\d+);b=\s*(\d+);d=\s*(\d+);t=\s*(\d+);u=\s*(\d+);nrmA=\s*(-\d+);check_d_n\(d,nrmA,dbg\);",line)
        p=a,b,d,t,u
        assert norm(p)==N
        tuples.append(p)
    return tuples
read_post=['read("b1-4-nAAll-post-java-checks.gp");']
published = output_tuples(execute(read_post+entry))
november = output_tuples(execute(read_post+direct))
historical = output_tuples((args.archived_pari_dir/"b1-4-nAAll-post-java-checks-output-2026-10-28a.txt").read_text().splitlines())
assert published==historical
assert Counter(published)==Counter(november)
assert set(java)<=inputs.keys()
assert all(not square_hits(p,False,False) for p in inputs.keys()-java.keys())
assert not (set(inputs)-set(java)) & set(published)

solver_lines={}
for i,line in enumerate((pari/"b1-4-nAAll-solve.gp").read_text().splitlines(),1):
    rows=output_tuples([line])
    if rows:
        p=rows[0]
        assert p not in solver_lines
        solver_lines[p]=i
assert set(solver_lines)==set(november)
lean = (ROOT/"AnyBAnyNorm/PostJava.lean").read_text(encoding="utf8")
assert set(solver_lines)=={tuple(map(int,m)) for m in re.findall(r"^  ⟨(\d+), (\d+), (\d+), (\d+), (\d+)⟩",lean,re.M)}
eq=lambda p:(p[2],norm(p))
eq_rows,calls,results=solver_results(args.archived_pari_dir/"b1-4-nAAll-solve-output-2026-10-28a.txt")
assert eq_rows==list(map(eq,solver_lines))
# Observe which equations the published driver dispatches. The point lists are checked separately.
spy=['read("b1-4-nAAll-solve.gp");','quartic_thue_solve(d,n,dbg=0)={print("DISPATCH ",d," ",n);[]};',
     'qt_test_brute(d,n,dbg=0)=[];']
dispatch=[values(r"DISPATCH (\d+) (-\d+)",line) for line in execute(spy+entry) if line.startswith("DISPATCH ")]
assert dispatch==calls==[e for e in eq_rows if not covered(-e[1])]
assert set(dispatch)==set(results)
# Regenerate the descent, then recover the quartic points from the saved Thue solutions.
def coefficients(form):
    compact = form.replace(" ", "")
    terms = re.findall(r"[+-]?[^+-]+", compact)
    assert "".join(terms) == compact
    result = [0]*5
    for term in terms:
        m = re.fullmatch(r"([+-]?)(?:(\d+)(?:\*)?)?(qtU)?(?:\^([1-4]))?",term)
        sign, number, variable, exponent = m.groups()
        assert number or variable
        power=int(exponent or 1) if variable else 0
        result[4-power] += (-1 if sign=="-" else 1)*int(number or 1)
    return result

blocks={}
for line in (args.archived_pari_dir/"b1-4-nAAll-solve-output-2026-10-28a.txt").read_text().splitlines():
    if header:=re.match(r"d=(\d+), nrmA=(-\d+):",line):
        equation=tuple(map(int,header.groups()))
        forms=[]
    if line.startswith("done a Thue equation:"):
        m=re.fullmatch(r"done a Thue equation: solns=(\[.*\])\. form=(.*), RHS=(-?\d+) time taken.*",line)
        pts=literal_eval(m[1])
        coeff=coefficients(m[2])
        rhs=int(m[3])
        for x,y in pts:
            assert sum(c*x**(4-i)*y**i for i,c in enumerate(coeff))==rhs
        forms.append([coeff,rhs,pts])
    if line.startswith("Number of solutions="):
        assert forms and blocks.setdefault(equation,forms)==forms
assert set(blocks)==set(results)
commands=['read("../../../general/pari/quartic-solver.gp");',
          'verify(d,n,L,pts)={my(R=quartic_to_thue(d,n),E=R[2],S=vector(#E),matches);if(#E!=#L,error("form count",d,n));'
          'for(i=1,#E,matches=select(v->Pol(v[1],qtU)==E[i][1]&&v[2]==E[i][2],L);'
          'if(#matches==1,S[i]=matches[1][3],print("FRESH_THUE ",d," ",n," ",i);S[i]=thue(thueinit(E[i][1],1),E[i][2])));'
          'my(points=select(v->v[1]>0&&v[2]>0,qt_recover(R,S)));if(Set(points)!=Set(pts),error("point recovery",d,n));'
          'print("RECOVERED ",d," ",n);};']
for (d,n), forms in blocks.items():
    points = [list(pair) for pair in results[d,n]]
    commands.append(f"verify({d},{n},{forms},{points});")
replay=execute(commands)
print("Fresh Thue solves for forms absent from transcript:",[line for line in replay if line.startswith("FRESH_THUE ")])
recovered=[values(r"RECOVERED (\d+) (-\d+)",line) for line in replay if line.startswith("RECOVERED ")]
assert recovered==list(blocks)
print("Regenerated descent and recovered identical quartic points:",len(blocks),"equations,",sum(map(len,blocks.values())),"Thue forms counting each distinct (d,N) separately.")

output_count=Counter(published)
nov_count=Counter(november)
def key(p): return p[1],p[2],norm(p),p[4]
def tally(items): return [sum(p[1]==b for p in items) for b in range(1,5)]
extra_keys=sorted(keys.keys()-printed.keys())
print("Extra literal keys (b,d,N,u):",extra_keys,"missing:",sorted(printed.keys()-keys.keys()))
print("Literal GP calls:",sum(keys.values()),"distinct keys:",len(keys),"Java emitted:",sum(printed.values()),"distinct keys:",len(printed))
print("Expanded GP input calls:",sum(map(len,inputs.values())),"distinct tuples:",len(inputs),"by b:",tally(inputs))
print("Java by b:",tally(java),"retained by b:",tally(solver_lines))
small_hits={p:[(k,y) for k,y,*tests in candidates(p) if any(tests) and p[2]*y*y < 256*norm(p)**2] for p in java}
small={p for p,hits in small_hits.items() if hits}
assert len(small)==43 and sum(map(len,small_hits.values()))==48 and small<=set(solver_lines)
print("Tuples below (4.4) by b:",tally(small))
print("Post-filter output occurrences: published",len(published),"November",len(november),"same multiplicities:",nov_count==output_count)
print("Extra expanded tuples:", sorted(set(inputs)-set(java)))
print("Omitted from solve file by refinement:",len(set(java)-set(solver_lines)))
print("Solver rows/distinct equations:",len(eq_rows),len(set(eq_rows)),"dispatched:",len(dispatch),len(results))
print("Maxima:",max(p[2] for p in solver_lines),max(-norm(p) for p in solver_lines))
assert {p for p in solver_lines if p[2]==max(q[2] for q in solver_lines) or norm(p)==min(norm(q) for q in solver_lines)}=={(12316,3,4941733,2223,1)}
assert (36594,4,9734404,3120,1) in java and norm((36594,4,9734404,3120,1))==-1152886588
with args.csv.open("w",newline="",encoding="utf8") as out:
    w=csv.writer(out)
    w.writerow(["a","b","d","t","u","N_alpha","November_Java_line","Java_k","Java_y_k","post_java_gp_lines","input_relation","square_indices_below_4_4","published_GP_output_occurrences","November_GP_output_occurrences","solve_gp_line","distinct_positive_solutions_in_transcript"])
    for p, lines in sorted(inputs.items(),key=lambda item:(item[0][1],item[0][2],item[0][0],item[0][4],item[0][3])):
        relation="Java tuple" if p in java else ("extra literal GP input" if key(p) in extra_keys else "other Pell root")
        w.writerow([*p,norm(p),*java.get(p,("","",""))," ".join(map(str,lines)),relation," ".join(str(k) for k,y in small_hits.get(p,[])),output_count[p],nov_count[p],solver_lines.get(p,""),len(results[eq(p)]) if p in solver_lines and eq(p) in results else ""])

