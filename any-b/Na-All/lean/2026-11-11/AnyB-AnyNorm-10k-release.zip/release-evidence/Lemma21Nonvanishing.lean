import AnyBAnyNorm.Diophantine

namespace AnyBAnyNorm

/-- The nonvanishing paragraph of the revised [11], Lemma 2.1, using the
determinant bound proved in 10k for approximants whose products belong to K. -/
theorem lemma21_error_ne_zero (K : IntermediateField ℚ ℂ) [NumberField K]
    [NumberField.IsTotallyComplex K] (hdegree : Module.finrank ℚ K = 2)
    (θ : ℂ) (p q : K) (pr qr : ℕ → ℂ)
    (hp : IsIntegral ℤ p) (hq : IsIntegral ℤ q) (hpq : ¬ (p = 0 ∧ q = 0))
    (hpr : ∀ r, IsIntegral ℤ (pr r)) (hqr : ∀ r, IsIntegral ℤ (qr r))
    (hpp : ∀ r, pr r ^ 2 ∈ K) (hmix : ∀ r, pr r * qr r ∈ K)
    (hqq : ∀ r, qr r ^ 2 ∈ K)
    {E ℓ : ℝ} (hE : 1 < E)
    (herr : ∀ r, ‖qr r * θ - pr r‖ ≤ ℓ / E ^ r)
    (hind : ∀ r, pr r * qr (r+1) ≠ pr (r+1) * qr r) :
    (q : ℂ) * θ - (p : ℂ) ≠ 0 := by
  intro hR
  have heq := sub_eq_zero.mp hR
  have hq0 : (q : ℂ) ≠ 0 := by
    intro hz
    rw [hz, zero_mul] at heq
    exact hpq ⟨Subtype.ext heq.symm, Subtype.ext hz⟩
  obtain ⟨n, hn⟩ := pow_unbounded_of_one_lt (‖(q : ℂ)‖ * ℓ) hE
  have vanishes (r : ℕ) (hr : n ≤ r) : pr r * (q : ℂ) - qr r * (p : ℂ) = 0 := by
    by_contra hne
    have hone := determinant_norm (K := K) hdegree (RingHom.id ℂ) p q hp hq
      (pr r) (qr r) (hpr r) (hqr r) ⟨⟨_, hpp r⟩, rfl⟩
      ⟨⟨_, hmix r⟩, rfl⟩ ⟨⟨_, hqq r⟩, rfl⟩ hne
    change 1 ≤ ‖pr r * (q : ℂ) - qr r * (p : ℂ)‖ at hone
    have hid : pr r * (q : ℂ) - qr r * (p : ℂ) =
        -((q : ℂ) * (qr r * θ - pr r)) := by rw [← heq]; ring
    rw [hid, norm_neg, norm_mul] at hone
    have hsmall : ‖(q : ℂ)‖ * (ℓ / E ^ r) < 1 := by
      rw [← mul_div_assoc, div_lt_one (pow_pos (zero_lt_one.trans hE) r)]
      exact hn.trans_le (pow_le_pow_right₀ hE.le hr)
    exact (not_lt_of_ge (hone.trans (mul_le_mul_of_nonneg_left (herr r) (norm_nonneg _)))) hsmall
  have proportional (r : ℕ) (hr : n ≤ r) : pr r = (p : ℂ) / q * qr r := by
    have hd := sub_eq_zero.mp (vanishes r hr)
    field_simp [hq0]
    linear_combination hd
  apply hind n
  rw [proportional n le_rfl, proportional (n+1) (by omega)]
  ring

end AnyBAnyNorm

#print axioms AnyBAnyNorm.lemma21_error_ne_zero
