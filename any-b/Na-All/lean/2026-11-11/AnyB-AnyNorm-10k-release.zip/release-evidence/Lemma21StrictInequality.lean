import «JNT-2024».ApproximationProofDetails

open «JNT-2024».Approximation

namespace AnyBAnyNorm.Lemma21StrictInequality

/-- At a single index take θ = p = 0, q = pᵣ = qᵣ = 1, k₀ = 2,
ℓ₀ = 1 and r = 0. The determinant and the two local estimates hold
with equality in the resulting weak estimate. -/
example :
    1 ≤ ‖(1 : ℂ) * 1 - 1 * 0‖ ∧ ‖(1 : ℂ)‖ < 2 ∧
    ‖(1 : ℂ) * 0 - 1‖ ≤ 1 ∧
    2 * ‖(1 : ℂ) * 0 - 0‖ = 1 - 1 * ‖(1 : ℂ)‖ := by
  norm_num

/-- The defining inequality for r₀ supplies the missing strict inequality
at both indices used in the cited proof. -/
theorem at_cutoff_and_successor {E Q ℓ c : ℝ} {q : ℂ} {r : ℕ}
    (hE : 1 < E) (hQ : 1 < Q) (hc : 0 < c) (hc1 : c < 1)
    (hcut : Cutoff E Q ℓ c q r) :
    ℓ / E^r * ‖q‖ < 1 ∧ ℓ / E^(r+1) * ‖q‖ < 1 := by
  have ratio := (cutoff_ratio_bounds hE hQ).2
  have at_r := cutoff_error_bound hE hQ hcut
  have at_next := lemma21_successor_cutoff_bound hE hQ hcut
  have first : ℓ / E^r * ‖q‖ < 1 := by nlinarith only [at_r, ratio, hc, hc1]
  refine ⟨first, ?_⟩
  have hpos : 0 < E := lt_trans zero_lt_one hE
  have heq : c * ((Q - 1) / (E * (Q - 1 / E))) =
      (c / E) * ((Q - 1) / (Q - 1 / E)) := by
    simp only [div_eq_mul_inv, mul_inv_rev]
    ring
  rw [heq] at at_next
  exact at_next.trans ((mul_lt_of_lt_one_right (div_pos hc hpos) ratio).trans
    ((div_lt_one hpos).mpr (hc1.trans hE)))

end AnyBAnyNorm.Lemma21StrictInequality
