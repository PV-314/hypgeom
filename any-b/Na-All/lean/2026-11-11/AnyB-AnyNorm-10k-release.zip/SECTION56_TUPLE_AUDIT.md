# The calculation in §5.6 of 10h

The 10h manuscript reports 41m 17s for the last row of Table 1. The final line of the 10 November Java transcript gives 2,476,628 ms, or 41m 16.628s. The [transcript check](release-evidence/check_cutoffs.py) compares all four reported times at the printed precision with the locked TeX. The extracted PDF text differs from 10g only at this entry.

The GitHub revision is pinned in [github-sources.json](release-evidence/github-sources.json). The published Java source uses the individually computed norm for all three comparisons in Proposition 4.1. Its preliminary loop bound now computes the norm bound in double precision. The exact boundary audit checked that this stopping limit covers every permitted integral value of $4y_k$ for every $(b,d,t,u)$ in the four rows. I compiled the published source and reran $b=1,2,3$. For $b=4$ I used the full author transcript and checked every reported square by exact recurrence. All 189 tuples match the Lean list. [Java range audit](release-evidence/10h-table1-exact.txt) · [Transcript and cutoff checks](release-evidence/10h-square-cutoffs.txt)

In the preliminary limit calculation the Java call has $a_{\rm LB}=1$. The four table rows have $db^4\le 41{,}288{,}728{,}576\cdot256<2^{53}$. All intermediate integer products in the new double-precision calculation of $db^4-1$ are therefore exact on this range. The individual comparisons for a reported square use integer arithmetic.

| $b$ | $D_b$ | $U_b$ | $c_{1,b}$ | $c_{2,b}$ | Distinct tuples tried by published post-Java GP | Tuples below (4.4) | Distinct tuples retained |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | 2,461 | 13 | 2,489 | 6 | 6 | 0 | 4 |
| 2 | 10,080,256 | 14 | 40,959,738 | 27 | 29 | 5 | 24 |
| 3 | 1,307,876,301 | 30 | 11,961,962,029 | 80 | 84 | 20 | 75 |
| 4 | 41,288,728,576 | 53 | 671,349,959,367 | 76 | 84 | 18 | 72 |
| **Total** | | | | **189** | **203** | **43** | **175** |

The GitHub post-Java file now has exactly the 183 distinct $(b,d,N_\alpha,u)$ inputs emitted for the 189 Java tuples. Trying both possible Pell signs for $t$ tests 203 distinct five-tuples. The additional 14 all have $(d,t,u)=(5,3,1)$ and all are discarded. Every Java tuple, its two source line references, the original square witness and its disposition can be checked in the [comparison CSV](release-evidence/section56-tuples.csv).

## Filter output and quartic equations

I ran the published GP entry points and separately passed exactly the 189 transcript tuples to the same filter with their original $t$. Both runs emitted 190 tuple occurrences with identical multiplicities, giving 175 distinct tuples. The published entry points also reproduced the saved October post-Java output in order. The subsequent solve file contains precisely those 175 tuples, once each, with all five parameters and $N_\alpha$ checked. The 43 tuples below (4.4) have 48 square occurrences and all survive. The largest retained $d$ and $|N_\alpha|$ occur at $(12316,3,4941733,2223,1)$ with $N_\alpha=-248596517$, as printed. The earlier example $(36594,4,9734404,3120,1)$ also has the printed norm $-1152886588$. [Published solve file](https://github.com/PV-314/hypgeom/blob/b438d89c375253fdc763577dbe40085f191db4cf/any-b/Na-All/pari/b1-4-nAAll-solve.gp)

The 175 tuples give 162 distinct pairs $(d,N_\alpha)$. The published driver skips 68 equations under the cited norm conditions. Its 103 calls on the remaining 94 distinct equations agree with the solver transcript in order. I regenerated the descent on the 94 equations, matched all 336 quartic Thue forms and their right-hand sides by equation, checked every recorded Thue solution by substitution, and recovered the same positive quartic points with the published GP code. This replay uses the saved outputs of PARI's Thue solver for exhaustiveness. [Quartic solver](https://github.com/PV-314/hypgeom/blob/b438d89c375253fdc763577dbe40085f191db4cf/general/pari/quartic-solver.gp)

Among the 94 equations, 45 have two reported positive solutions, 39 have three, six have four and four have five. Thus 84 have at most three and 10 are exceptional. All 10 occur among tuples with $b=3,4$. The only two of these equations giving four square values in the relevant sequences are $(d,N_\alpha)=(2,-161),(8,-644)$. Both give the same $y$-sequence and the four displayed squares at $k=-5,-1,0,3$. [Sequence checks](check_section56.py) · [Equality of the two sequences](AnyBAnyNorm/ExceptionalSequence.lean)

The [comparison script](release-evidence/check_section56_alignment.py) takes the directory containing the pinned GitHub tree, a GP executable, the directory containing the two October PARI transcripts, and an output CSV path, in that order. The exact Table 1 and refinement replay is in [check_section56_refinement.py](check_section56_refinement.py). The [comparison output](release-evidence/section56-alignment.txt) records the tuple differences and counts.
