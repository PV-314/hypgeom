import AnyBAnyNorm
import Lean

open Lean Elab Command

/- Check the full axiom closure of each declaration defined by this package,
including the auxiliaries produced by tactics. Cited hypotheses remain
visible in theorem types and require separate mathematical review. -/
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    let some idx := env.getModuleIdxFor? name | continue
    let mod := env.header.moduleNames[idx.toNat]!
    unless mod.getRoot == `AnyBAnyNorm do continue
    let axioms ← collectAxioms name
    for ax in axioms do
      unless [`propext, `Classical.choice, `Quot.sound].contains ax do
        throwError "{name} depends on {ax}"
    count := count + 1
  if count == 0 then throwError "No local declarations were audited"
  logInfo m!"Checked axiom closures of {count} local declarations."

#check AnyBAnyNorm.QuarticModel.sequenceQuarticModel
#check AnyBAnyNorm.QuarticModel.quarticModel
#check AnyBAnyNorm.QuarticBounds.negativeTwo
#check AnyBAnyNorm.QuarticBounds.negativeTwo_sharp
#check AnyBAnyNorm.QuotedResults.even_bounds_of_conjecture12
#check AnyBAnyNorm.QuotedResults.theorem14_of_cited_theorem12
#check AnyBAnyNorm.square_with_zero_rational_part_lt
#check AnyBAnyNorm.QuarticModel.recoverQuartic
#check AnyBAnyNorm.QuarticModel.recoverWeierstrass
#check AnyBAnyNorm.Construction.gPrime_sq
#check AnyBAnyNorm.Construction.scaled_approximants_mem
#check AnyBAnyNorm.Construction.approximant_fields
#check AnyBAnyNorm.Construction.approximant_products_mem
#check AnyBAnyNorm.imaginary_quadratic_norm
#check AnyBAnyNorm.determinant_norm
#check AnyBAnyNorm.section41_size
#check AnyBNormSquare.section21_error_identity
#check AnyBAnyNorm.Construction.error_eq_scaled_gauss
#check AnyBNormSquare.section41_near_one
#check AnyBAnyNorm.lemma21

-- Check the statement with complex approximants as in §2.2.
example (K : IntermediateField ℚ ℂ) [NumberField K] [NumberField.IsTotallyComplex K]
    (hdegree : Module.finrank ℚ K = 2) (θ : ℂ) {c k₀ ℓ₀ E Q : ℝ}
    (hc : 0 < c) (hc1 : c < 1) (hk : 0 < k₀) (hℓ : 0 < ℓ₀) (hE : 1 < E) (hQ : 1 < Q)
    (pr qr : ℕ → ℂ) (hpr : ∀ r, IsIntegral ℤ (pr r)) (hqr : ∀ r, IsIntegral ℤ (qr r))
    (hpp : ∀ r, pr r ^ 2 ∈ K) (hmix : ∀ r, pr r * qr r ∈ K) (hqq : ∀ r, qr r ^ 2 ∈ K)
    (hqb : ∀ r, ‖qr r‖ < k₀ * Q ^ r)
    (herr : ∀ r, ‖qr r * θ - pr r‖ ≤ ℓ₀ * E ^ (-(r : ℤ)))
    (hind : ∀ r, pr r * qr (r+1) ≠ pr (r+1) * qr r)
    (p q : K) (hp : IsIntegral ℤ p) (hq : IsIntegral ℤ q) (hpq : ¬ (p=0 ∧ q=0)) :
    AnyBAnyNorm.ApproximationConclusion θ p q pr qr k₀ ℓ₀ E Q c hE hc :=
  AnyBAnyNorm.lemma21 hdegree (RingHom.id ℂ) θ p q pr qr hp hq hpr hqr
    (fun r => ⟨⟨_, hpp r⟩, rfl⟩) (fun r => ⟨⟨_, hmix r⟩, rfl⟩)
    (fun r => ⟨⟨_, hqq r⟩, rfl⟩) hpq hk hℓ hE hQ hc hc1 hqb herr hind
#check AnyBAnyNorm.lemma31_paper
#check AnyBAnyNorm.lemma32
#check AnyBAnyNorm.lemma33a
#check AnyBAnyNorm.lemma33b
#check AnyBAnyNorm.phase_of_representation
#check AnyBAnyNorm.lemma34_paper
#check AnyBAnyNorm.lemma34_pair
#check AnyBAnyNorm.lemma35b
#check AnyBAnyNorm.select_three_indices
#check AnyBAnyNorm.comparison_phase
#check AnyBAnyNorm.section41_select
#check AnyBAnyNorm.section41_normalizer
#check AnyBAnyNorm.section42_comparison
#check «JNT-2024».Hypergeometric.lemma23a_of_denominatorEstimate4
#check AnyBAnyNorm.section42_approximant_bounds
section
  open «JNT-2024».Hypergeometric
  variable (hPrior : DenominatorEstimate4) (d' : ℤ) (hd' : d' ≠ 0)
  #check lemma23a_of_denominatorEstimate4 hPrior d' hd' 0
end
#check AnyBAnyNorm.section42_coordinates
#check AnyBAnyNorm.section42_parameters
#check AnyBAnyNorm.section42_pair
#check AnyBAnyNorm.section42_cutoff
#check AnyBAnyNorm.jnt413_modulus
#check AnyBAnyNorm.section44_equation415
#check AnyBAnyNorm.section44_one_gap
#check AnyBAnyNorm.section44_two_gaps
#check AnyBAnyNorm.section44_bound
#check AnyBAnyNorm.section43_bound
#check AnyBAnyNorm.section45_root
#check AnyBAnyNorm.section45_bound
#check AnyBAnyNorm.section46_bound
#check AnyBAnyNorm.selected_four_cases
#check (AnyBAnyNorm.proposition41 :
  «JNT-2024».Hypergeometric.DenominatorEstimate4 → AnyBAnyNorm.Proposition41)
#check (AnyBAnyNorm.theorem17 :
  «JNT-2024».Hypergeometric.DenominatorEstimate4 → AnyBAnyNorm.Theorem17)
#check AnyBAnyNorm.lemma35a
#check AnyBAnyNorm.lemma36
#check AnyBAnyNorm.corollary19_of_theorem18
#check AnyBAnyNorm.exceptional_four_squares
#check AnyBAnyNorm.exceptional_same_sequence
#check AnyBAnyNorm.section5_tail_lower
#check AnyBAnyNorm.section51_separation
#check AnyBAnyNorm.section51_norm_free
#check AnyBAnyNorm.section52_separation
#check AnyBAnyNorm.section52_norm_free
#check AnyBAnyNorm.Section56.postJava_counts
#check AnyBAnyNorm.Section56.postJava_maxima
#check AnyBAnyNorm.Section56.postJava_partition
#check AnyBAnyNorm.Section56.covered_tail
#check AnyBAnyNorm.Section56.quarticScale_spec
#check AnyBAnyNorm.Section56.quartic_solver_coordinates
#check AnyBAnyNorm.Section56.quartic_solver_square_parts
#check AnyBAnyNorm.Section56.quartic_8_644_parameters
#check AnyBAnyNorm.Section56.quartic_8_644
#check AnyBAnyNorm.Section56.quarticResultsComplete_iff_reduced
#check AnyBAnyNorm.Section56.quartic_conjugate_product
#check AnyBAnyNorm.Section56.quartic_thue_coefficient
#check AnyBAnyNorm.Section56.exceptional_quartic_b
#check AnyBAnyNorm.Section56.solver_sequence_classification
#check AnyBAnyNorm.Section56.quartic_records_valid
#check AnyBAnyNorm.Section56.quartic_reported_counts
#check AnyBAnyNorm.Section56.positive_solution_iff_mem
#check AnyBAnyNorm.section53_separation
#check AnyBAnyNorm.section53_norm_free
#check AnyBAnyNorm.section54_separation
#check AnyBAnyNorm.section54_norm_free
#check AnyBAnyNorm.selected_case_bounds
#check AnyBAnyNorm.section55_conditions
#check AnyBAnyNorm.section55_four
#check AnyBAnyNorm.theorem18b
#check AnyBAnyNorm.Section56.small_iff
#check AnyBAnyNorm.Section56.java_size_records
#check AnyBAnyNorm.Section56.belowSizeTuples_spec
#check AnyBAnyNorm.Section56.equation44_of_five

#check AnyBAnyNorm.least_phase
#check AnyBAnyNorm.selected_coefficient_bounds
#check AnyBAnyNorm.Section56.conditions_of_finiteBound
#check AnyBAnyNorm.Section56.JavaSquareSearch

-- At equality in (5.17), the §5.6 Java coverage premise applies.
section
  open «JNT-2024» AnyBNormSquare AnyBAnyNorm AnyBAnyNorm.Section56
  example (search : AnyBAnyNorm.Section56.JavaSquareSearch)
      (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) (hb : P.b ≤ 4)
      (boundary : (P.d : ℝ) = finiteBound P.b P.u)
      (K : ℤ) (hK : P.IsNegativeCutoff h.pell K) (k : ℤ) (hk : 3 ≤ k ∨ k ≤ K-2)
      (hs : IsIntegerSquare (P.y h.pell k)) (hy : (P.y h.pell k : ℝ) ≤ preciseThreshold P) :
      ∃ r ∈ javaRows, r.params = P :=
    search P h hn hb boundary.le K hK k hk hs hy
end
#check AnyBAnyNorm.Section56.preliminary_of_cases
#check AnyBAnyNorm.Section56.PostJavaSearch
#check AnyBAnyNorm.Section56.QuarticResultsComplete
#check AnyBAnyNorm.Section56.solver_sequence_bound
#check AnyBAnyNorm.theorem18a
#check AnyBAnyNorm.theorem18_paper
#check AnyBAnyNorm.corollaries19_110

#check AnyBAnyNorm.Construction.commonDenominator_least
#check AnyBAnyNorm.Construction.commonContent_greatest
#check AnyBAnyNorm.Construction.primeProduct_four

#check AnyBAnyNorm.nonnegative_index_integral
