# Faithfulness audit of Theorems 1.7 and 1.8 in revision 10i

## Revision compared with 10h

The complete TeX comparison has two changes. Lines 230–231 join a source line in Conjecture 1.1. Lines 651–653 change the locator in the explanation before Lemma 2.1. Across the 24 PDF pages only the text on p. 7 changed. The printed reference “after (2.4)” points to the paragraph starting at line 627. That paragraph gives field membership for even and odd indices and deduces membership of the three products. The formulas and both theorem proofs are identical across revisions.

In Lean, `approximant_fields` proves integrality, membership in the base field at even indices, and membership in the stated extension together with the two scaled membership statements at odd indices. Then `approximant_products_mem` gives the three hypotheses used by `section42_apply`. [Field membership](AnyBAnyNorm/Construction.lean) · [Application](AnyBAnyNorm/Section42.lean)

The assertion that odd-index approximants can actually lie outside the base field also has an elementary check in the notation of (2.2)–(2.4). Take $t'=-1$, $u_1=10$, $u_2=2$, $r=1$. Then $U=5+i$, $g_1=2$, $g_2=1$, $g_3=2$, and $g=\sqrt2$. The polynomials are $X(z)=1+5z/3$ and $Y(z)=z+5/3$. After multiplication by $\bar U$ they give $(40+2i)/3$ and $(40-2i)/3$, respectively. The remaining factor is the same nonzero rational $D_{4,1}/N_{d',4,1}$ divided by $\sqrt2$. Both real parts are irrational, so neither approximant belongs to $\mathbb Q(i)$. This witness is an independent arithmetic check recorded in the audit. The Lean theorem used in the proof is the general field-membership statement above.

## Approved reading of reference [12]

The sentence at the end of the first paragraph of §2.2 on p. 7 says “The results in [12, 14] are not affected by using this lemma rather than Lemma 2.1 in [11].” In the published [12], p. 14, last paragraph of §3.2, the expression immediately before “must be in an imaginary quadratic field” is

$$\zeta_4\frac{x-y\sqrt{\operatorname{sf}(b)}}{x+y\sqrt{\operatorname{sf}(b)}}.$$

The defining display earlier on the same page and (3.2) below both use $\sqrt{-\operatorname{sf}(b)}$. With that negative sign, the numerator and denominator of the fraction before multiplication by $\zeta_4$ are conjugates in $\mathbb Q(\sqrt{-\operatorname{sf}(b)})$. The positive radicand does not generally give the required pair. This is a separate issue from the field of the hypergeometric approximants. The widened hypotheses of 10i Lemma 2.1 still require the comparison elements $p,q$ to be in the imaginary quadratic field.

The author approved using the post-publication TeX of [12], `nrmAlpha-primepower-RNT-after-publication.tex`, lines 1227–1234, and retaining 10i as written. For the comparison in [12] the audit therefore uses $q=x+y\sqrt{-\operatorname{sf}(b)}$ and numerator $\eta\bar q$. These are the roles in the application, with the fourth root of unity denoted by $\eta$ in the corrected text. The corrected TeX has SHA-256 `a0ee0e6ac40864caf03ca44b06225dad2b3aedd8bec0ce8bf901330b444fc752`. The published PDF inspected was `bPP-paper-RNT-2026.pdf` (SHA-256 `f6577ac46cf72829db40ea299daafa32f9d8d4f1f0f51f4db87a734bb9b35c6d`). The 10i application already supplies $\eta\bar q,q$ with the required field membership. [Published article](https://doi.org/10.1007/s40993-026-00712-7) · [arXiv copy, §3.2](https://arxiv.org/pdf/1807.04116#page=17)

## Author decision on the wording in [14]

In [14], §2.1, `sequence-version-any-b-nrmA-PP.tex`, lines 461–471, the introduction to Lemma 2.1 says “which we quote here”. Its reference is to paper (III). With 10i as the comparison text, [14] states an earlier form. It assumes a common $g'$ with $0\ne(g')^2\in K$ and $(g')^r p_r,(g')^r q_r\in K$ for every $r$. Lemma 2.1 of 10i, lines 657–666, assumes $p_r^2,p_rq_r,q_r^2\in K$ directly.

The implication needed by [14] holds for each $r$, including zero. The products of the two scaled approximants, taken in any of the three ways, belong to $K$. Dividing each by $((g')^2)^r\in K^\times$ gives the required unscaled products. Thus 10i gives both bounds of [14] with the same comparison elements, constants and least positive index. This verifies the replacement of the lemma at this step. It does not audit all the other estimates in [14]. The comparison text for [14] has SHA-256 `acb54c99546c35bac0e85b82926246f0ed71ee9affe2e3bd0fb43d2d0d7268f9`. The author will resolve the introductory wording in a future revision of [14] and has confirmed that 10i stands as written. This closes the comparison for the audit of 10i. [Lean verification](release-evidence/Reference14Lemma21.lean) · [Lean output](release-evidence/10i-Reference14Lemma21.txt)

## Verification and extent

The 10i input lock identifies the supplied manuscript pair and all five earlier reference inputs. The restored dependency sources and all local Lean module sources were checked against the sources used for the previously compiled modules. The compiled modules were reused. Lean 4.35.0 freshly ran the public declaration and axiom check, the proof-dependency check, and the least-square example from the 10i directory. The axiom check covers 614 declarations. The proofs of Theorems 1.7, 1.8(a), 1.8(b), and the combined theorem use Lemmas 2.1 and 3.6. [Axiom check](release-evidence/10i-Audit.txt) · [Dependencies](release-evidence/10i-MainTheoremDependencies.txt) · [Least-square example](release-evidence/10i-Conjecture11ZeroSquare.txt)

The §5.6 numerical inputs, programs and Lean proof of the change of variables are byte-identical to those in the 10h checkpoint. The detailed account of the calculation and its limits is retained with its original revision and TeX line references. [§5.6 and the earlier audit](MAIN_THEOREMS_FAITHFULNESS_AUDIT_10h.md) · [Tuple audit](SECTION56_TUPLE_AUDIT.md)

## Applications of Lemma 2.1 in the 10i argument


The [general lemma](AnyBAnyNorm/Diophantine.lean) is proved. The proof of [section42_apply](AnyBAnyNorm/Section42.lean#L116) supplies the two integral comparison elements, field membership of the approximants and the three products, the nonzero denominator, the numerical hypotheses, both approximation bounds at every nonnegative index, and the nonzero consecutive determinant. The large-index denominator estimate described below enters through the approximation bounds.

In §4.2, $t'=\operatorname{core}(N_\alpha)$, $u_1=2x_{m_1}$, and $u_2=2N_{\varepsilon^{m_1}}\sqrt{N_\alpha/t'}$. The comparison field is $\mathbb Q(\sqrt{t'})$, the target is the specified fourth root of $\omega_{m_1}$, and $c=3/4$. With $q=(r_{m_1}-s_{m_1}\sqrt{t'})(r_{m_3}+s_{m_3}\sqrt{t'})$ and the local $p=\bar q$, the numerator passed to Lemma 2.1 is **ηp**. The denominator passed is **q**. The least positive index $r_0$ is chosen for this same pair.

| 10i passage | Use of the result of §4.2 |
|---|---|
| §4.3 | At $r_0=1$ and unequal cross-products, part (b) supplies the strict lower bound for the approximation error. |
| §4.4 | At $r_0=1$ and equal cross-products, the proof uses the error for the explicit approximant. |
| §4.5 | At $r_0>1$ and unequal cross-products, the proof uses part (b) and failure of the strict cutoff at $r_0-1$ by minimality. |
| §4.6 | At $r_0>1$ and equal cross-products, the proof uses the explicit approximant error and the same minimality at $r_0-1$. |

The general lower bound in part (a) is proved and is dropped at the [four-case split](AnyBAnyNorm/FourCases.lean#L90). Section 5 reuses the resulting estimates. It makes no further direct application of the revised lemma.

## Hypotheses of the Lean endpoints

Both endpoints quantify over the paper's admissible parameters, negative norm, the cutoff $K$, and the two standing conditions in [Normalized](AnyBAnyNorm/MainStatements.lean#L11). These say that $b^2$ is the least square and that $x_k\ne0$ whenever $y_k$ is an integer square. The conclusions count distinct square **values**. Theorem 1.7 uses the strict printed threshold and $k\ge1$ or $k\le K$. Theorem 1.8 uses $k\ge3$ or $k\le K-2$, with its respective restrictions on $b,d$. The endpoints start with these normalised data. The full reduction from arbitrary initial data is outside them.

* [Theorem 1.7](AnyBAnyNorm/Consolidation.lean#L82) takes one external premise, `Hypergeometric.DenominatorEstimate4`. It is the strict maximum estimate in [DenominatorBounds.lean](.deps/AnyB-NormSquare/.dependencies/JNT-2024-faithful-20261106-f2-evidence1/JNT-2024/DenominatorBounds.lean#L174), for every nonzero integer denominator parameter and every integer index $r\ge139$. The finite range $0\le r\le138$ of the denominator inequalities used in the proof is checked in the imported development.
* [Theorem 1.8(b)](AnyBAnyNorm/Section55.lean#L198) takes that estimate and `AkhtariTheorem11`, the assertion that $AX^4-BY^2=1$ has at most two positive solution pairs for positive integral $A,B$. The direct proof uses Akhtari for $N_\alpha=-1$.
* [Theorem 1.8(a)](AnyBAnyNorm/Theorem18.lean) takes the denominator estimate, three §5.6 calculation premises, the square-norm Theorem 1.4(a), and the cited prime-power result. In [theorem18_paper](AnyBAnyNorm/Theorem18.lean#L107) the proof of the square-norm theorem is supplied using the same denominator estimate, Akhtari's theorem, and the four imported calculation premises listed below.

The three calculation premises for §5.6 of 10i are as follows.

1. [JavaSquareSearch](AnyBAnyNorm/FiniteRange.lean#L42) says that an admissible tuple with $d\le D_{b,u}$ and a square on the indicated tail at or below the threshold of Proposition 4.1 occurs among the 189 listed tuples.
2. [PostJavaSearch](AnyBAnyNorm/Theorem18.lean#L19) says that such a row is retained if a tail square satisfies the preliminary and refined bounds using its least admissible coefficient multiplied by $4b^2\sqrt{|N_\alpha|}$. The declaration specifies the quantifiers and inequalities.
3. [QuarticResultsComplete](AnyBAnyNorm/QuarticResults.lean#L127) says that every positive integral solution of each of the 94 listed quartic equations occurs in its result list. Membership implies that the pair solves the equation by a separate checked result. Completeness is the external direction.

The current [Lean premise for the prime-power result](AnyBAnyNorm/Section56Norms.lean#L29) supplies at most four distinct tail square values for $b\le7$, negative norm of absolute value $2^\ell p^m$ with odd prime $p$, both standing conditions (the initial square is least and $x_k\ne0$ at each square), and $k\ge2$ or $k\le K-1$.

The imported [SquareNormCalculations](AnyBAnyNorm/Theorem18.lean#L100) contains these four propositions.

1. [Section46Magma](.deps/AnyB-NormSquare/.dependencies/JNT-2024-faithful-20261106-f2-evidence1/JNT-2024/Section46Calculation.lean#L51) supplies the unrestricted height bound for the small quartics of the JNT paper. The bounded calculation through $y=109$ is checked.
2. [JavaEnumeration](.deps/AnyB-NormSquare/AnyBNormSquare/Section56Calculations.lean#L18) gives the exact counts of the candidate sets for the three table rows of the square-norm paper.
3. [JavaSquareSearch in the square-norm paper](.deps/AnyB-NormSquare/AnyBNormSquare/Section56Calculations.lean#L24) identifies exactly the tuples with a square below its strict search bound on its indicated tails.
4. [ExceptionalQuartics](.deps/AnyB-NormSquare/AnyBNormSquare/Section56Calculations.lean#L34) restricts the positive solutions corresponding to squares of each recorded exceptional sequence to its specified initial pair or recorded root.

Thus the combined endpoint has seven explicit inputs outside the theorem statement, or ten propositions on opening the four-field calculation record. Cohn's theorem enters Corollary 1.10 separately. Neither conjecture is an input. This inventory describes the declarations examined in the audit. It does not certify the external calculations or finish the remaining manuscript comparisons.
