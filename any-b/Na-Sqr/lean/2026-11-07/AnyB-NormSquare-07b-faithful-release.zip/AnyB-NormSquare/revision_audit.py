"""Verify the authorised 06c-to-06e migration and preserve historical evidence."""
import difflib
import re
import zipfile
from dependency_guard import ROOT, SOURCE_STEM, SOURCE_HASHES, SOURCE_DIR, sha, read_json, write_json, require, verify_sources


def audit_revision():
    verify_sources(ROOT)
    baseline = read_json(ROOT / "audit/revision06e-baseline.json")
    for name, digest in baseline["files"].items():
        if name not in baseline["authorised_existing_lean_edits"]:
            require(sha(ROOT / name) == digest, "Changed historical proof/source/pin: " + name)
    arc = ROOT.parent / "output" / baseline["previous_checkpoint"]
    # Packaged checkpoints are portable: compare preserved import/audit bytes
    # with the source ZIP when available, otherwise use the pinned prefix hashes.
    if arc.exists():
        require(sha(arc) == baseline["previous_checkpoint_sha256"], "Changed previous ZIP")
        with zipfile.ZipFile(arc) as z:
            old_import = z.read("AnyB-NormSquare/AnyBNormSquare.lean").decode().replace("\r\n", "\n")
            old_audit = z.read("AnyB-NormSquare/Audit.lean").decode().replace("\r\n", "\n")
        require((ROOT / "AnyBNormSquare.lean").read_text(encoding="utf-8") ==
                old_import + "\npublic import AnyBNormSquare.Revision06e\n\npublic import AnyBNormSquare.Construction\n\npublic import AnyBNormSquare.Revision06f\n\npublic import AnyBNormSquare.Prerequisites\n\npublic import AnyBNormSquare.Case42\n\npublic import AnyBNormSquare.Case43\n\npublic import AnyBNormSquare.HigherIndex\n\npublic import AnyBNormSquare.Case44\n\npublic import AnyBNormSquare.Case45\n\npublic import AnyBNormSquare.Section4\n\npublic import AnyBNormSquare.Revision06g\n\npublic import AnyBNormSquare.Section5Work\n\npublic import AnyBNormSquare.Remarks\n", "Unexpected import edit")
        require((ROOT / "Audit.lean").read_text(encoding="utf-8").startswith(old_audit), "Old audit changed")
    old = ROOT / "source/sequence-version-any-b-nrmA-sqr-with-y-result-2026-11-06c.tex"
    new = ROOT / "source/sequence-version-any-b-nrmA-sqr-with-y-result-2026-11-06e.tex"
    a, b = old.read_text(encoding="utf-8"), new.read_text(encoding="utf-8")
    pattern = r"\\begin\{(theorem|lemma|proposition|corollary|conjecture)\}.*?\\end\{\1\}"
    before = [m.group() for m in re.finditer(pattern, a, re.S)]
    after = [m.group() for m in re.finditer(pattern, b, re.S)]
    require(len(before) == 14 and before == after, "Numbered statement changed")
    marker = r"\section{Lemmas about"
    require(a[a.index(marker):] == b[b.index(marker):], "Section 3 or later changed")
    expected = a.replace("We have the relationship\n", "If $|\\omega-1|<1$, then Lemma~\\lemHypg{}(a) of \\cite{V5} gives\n", 1)
    expected = expected.replace("q_{r}\\omega^{1/4} - p_{r}=R_{r}.\n\\]\n",
        "q_{r}\\omega^{1/4} - p_{r}=R_{r}.\n\\]\n\nWe will see in Subsection~\\ref{subsect:preq} that the condition $|\\omega-1|<1$\nis satisfied for our applications.\n", 1)
    expected = expected.replace("k_{0} &<1.257", "k_{0} &=1.257", 1)
    expected = expected.replace("\\cD_{4} &= e^{1.68}.\n\\end{align}",
        "\\cD_{4} &= e^{1.68}.\n\\end{align}\nOur choice of $k_{0}$ is justified by $1.072\\cC_{4,1}<1.257$.", 1)
    require(b == expected, "Unreviewed manuscript edit")
    for ext, digest in SOURCE_HASHES.items():
        original = SOURCE_DIR / (SOURCE_STEM + ext)
        if original.exists():
            require(sha(original) == digest, "Changed original attachment")
    # Current source-map verification is performed by revision06f_audit.
    (ROOT / "audit/revision06e.diff").write_text("".join(difflib.unified_diff(
        a.splitlines(True), b.splitlines(True), fromfile=old.name, tofile=new.name)), encoding="utf-8")
    report = dict(status="passed", scope="source migration and changed passages; whole paper remains incomplete",
        source_sha256=sha(new), pdf_sha256=sha(new.with_suffix(".pdf")), numbered_statements_unchanged=14,
        section3_through_end_unchanged=True, prior_proof_modules_unchanged=True,
        dependency_pins_unchanged=True, silent_mathematical_repairs=[],
        changes=[dict(original="Error identity without explicit near-one condition", revised="Explicit |omega-1|<1", consequence="Restricted domain; Section 4.1 derives it from Lemma 3.4", lean=["section21_error_identity", "section21_corrected_error_identity", "section41_near_one"]),
                 dict(original="k0 < 1.257", revised="k0 = 1.257 with justification", consequence="Author-approved fixed choice; strict q bound preserved conditionally on DenominatorEstimate4", lean=["paperK0", "paperK0_justified", "section21_q_bound_conditional"])],
        old_correspondence_reports="Historical 06c reports remain intact; numbered statement hashes match; Section 3 onward line numbers increase by 4 in 06e; current lines in SOURCE_MAP",
        denominator_estimate="unproved; explicit premise only of section21_q_bound_conditional",
        proof_scope="JNT definitions reused directly; raw and phase-corrected identities, constant justification, conditional q bound and printed argument-to-domain step. Full Section 2 construction/Section 4 assembly remain pending.")
    write_json(ROOT / "audit/revision06e-faithfulness.json", report)
    return report


if __name__ == "__main__":
    print(audit_revision())
