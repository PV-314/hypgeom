"""Audit the author-supplied 07b revision against the verified 06g checkpoint."""
import difflib

from dependency_guard import ROOT, SOURCE_STEM, SOURCE_HASHES, read_json, require, sha, verify_sources, write_json


def audit_revision07b():
    verify_sources(ROOT)
    baseline = read_json(ROOT / 'audit/revision07b-baseline.json')
    prefix = SOURCE_STEM.removesuffix('07b')
    for name, digest in baseline['prior_sha256'].items():
        require(sha(ROOT / name) == digest, 'Prior proof or dependency changed: ' + name)
    for suffix, digest in baseline['old_sources'].items():
        require(sha(ROOT / 'source' / (prefix + suffix)) == digest, 'Historical source changed: ' + suffix)
    for previous, revision in [('06g', '07a'), ('07a', '07b')]:
        def lines(tag):
            return (ROOT / 'source' / (prefix + tag + '.tex')).read_text(encoding='utf8').splitlines(keepends=True)
        changes = [list(op[1:]) for op in difflib.SequenceMatcher(None, lines(previous), lines(revision), autojunk=False).get_opcodes() if op[0] != 'equal']
        require(changes == baseline['reviewed_diff_blocks'][revision], 'Unexpected manuscript edit')
    current = read_json(ROOT / 'SOURCE_MAP.json')
    require(current['sha256'] == SOURCE_HASHES['.tex'], 'Source map out of date')
    def statements(inventory):
        return [(r['label'], r['statement_sha256']) for r in inventory['statements']]
    require(len(current['statements']) == 14 and statements(current) == statements(read_json(ROOT/'audit/source-map06g.json')), 'Numbered statement changed')
    write_json(ROOT / 'audit/revision07b-faithfulness.json', dict(source_hashes=SOURCE_HASHES,
        checked_numbered_statements=14, dependencies_and_prior_proofs_preserved=True,
        pdf_comparison='Both revised passages verified in the supplied PDF text; (4.18), (4.20), (4.25), (4.28) and strict search bound retained.',
        corrected_claim='The search uses four intermediate bounds in the proof. The quartic statement includes the initial solution and the single square value found by the search.',
        section5_complete=False, manuscript_complete=False))
