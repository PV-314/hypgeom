"""Source, preservation and compiled proof-route audit for Section 4 completion."""
from dependency_guard import ROOT,SOURCE_STEM,SOURCE_HASHES,sha,require,read_json,write_json,verify_sources

A="AnyBNormSquare."
J="«JNT-2024»."
MODULES=["Case43","HigherIndex","Case44","Case45","Section4"]
ROUTES={
 "Case43.imaginary_ne":[A+"Prerequisites.sequence_coordinates"],
 "Case43.chord_half":[A+"Prerequisites.sequence_coordinates",J+"Section4.gaussian_chord"],
 "Case43.general_bound":[A+"Case43.chord_half",A+"Case43.comparison_upper",J+"Section4.exact_comparison_error_printed",J+"Section4.exact_equation415"],
 "Case43.at_one":[A+"Case43.general_bound",J+"Section4.exact_equation415_index_one"],
 "Case43.second_case":[A+"Case43.at_one",A+"Case43.sixth_power",A+"Case43.root_bound",A+"Case42.sequence_gaps"],
 "HigherIndex.cutoff_chain":[J+"Approximation.firstIndex_le"],
 "HigherIndex.fourth_power":[A+"HigherIndex.factor_lower"],
 "HigherIndex.sequence_lower":[A+"HigherIndex.cutoff_chain",A+"HigherIndex.coordinate_lower",A+"HigherIndex.fourth_power",A+"Case42.norm_fourth",A+"Prerequisites.coordinate_bounds",A+"Prerequisites.application_parameters"],
 "Case44.cutoff_choice":[J+"Section4.cutoff_choice_monotone",J+"Section4.cutoff_choice_value"],
 "Case44.normalized":[J+"Section4.case44_division_identity",A+"Case44.cutoff_choice",A+"Case44.rounding_constants"],
 "Case44.normalized_with_b":[A+"Case44.rounding_constants"],
 "Case44.root_bound":["Real.rpow_mul_natCast"],
 "Case44.simplify_bound":["Real.rpow_le_rpow_of_exponent_le"],
 "Case45.remove_sqrt":[J+"Section4.section45_exponential_bound_printed"],
 "Case45.normalized":[J+"Section4.case45_division_identity",A+"Case45.rounding_constants"],
 "Case45.eliminate_f":[A+"Case45.rounding_constants"],
 "Case45.root_bound":["Real.rpow_mul_natCast"],
 "Case45.simplify_bound":[A+"Case45.rounding_constants","Real.rpow_le_rpow_of_exponent_le"],
 "Section4Proof.third_case":[A+"Case42.general_bound",A+"HigherIndex.sequence_lower",A+"Case44.combine",A+"Case44.normalized",A+"Case44.normalized_with_b",A+"Case44.root_bound",A+"Case44.simplify_bound"],
 "Section4Proof.fourth_case":[A+"Case43.general_bound",A+"HigherIndex.sequence_lower",A+"Case45.remove_sqrt",A+"Case45.normalized",A+"Case45.eliminate_f",A+"Case45.root_bound",A+"Case45.simplify_bound"],
 "Section4Proof.no_three":[A+"Prerequisites.prepare",A+"Prerequisites.apply_prepared",A+"Case42.first_case",A+"Case43.second_case",A+"Section4Proof.third_case",A+"Section4Proof.fourth_case",J+"Approximation.firstIndex_spec"],
 "Section4Proof.count_from_no_three":[J+"Section5.card_pair_le"],
 "Section4Proof.proposition41_conditional":[A+"Section4Proof.no_three",A+"Section4Proof.count_from_no_three",A+"Proposition41"],
 "Section4Proof.precise_le_large":[A+"Section4Proof.monomial_le_large",A+"Section4Proof.integer_bounds"],
 "Section4Proof.theorem13_conditional":[A+"Section4Proof.proposition41_conditional",A+"Section4Proof.precise_le_large",A+"Theorem13"],
}
CONDITIONAL={"Section4Proof.no_three","Section4Proof.proposition41_conditional","Section4Proof.theorem13_conditional"}
FORBIDDEN={J+"Section4."+n for n in ["four_cases_published","cutoff_printed_chain","cutoff_coordinate_lower","cutoff_equation417_application","case45_remove_square_root","nonexact_equation419_normalized"]}

def audit_section4(rows=None):
    verify_sources(ROOT)
    baseline=read_json(ROOT/"audit/section4-baseline.json")
    for name,digest in baseline["files"].items():
        if name not in baseline["authorised_existing_edits"]:
            require(sha(ROOT/("source/provenance06f.json" if name=="source/provenance.json" else name))==digest,"Changed previous mathematical/source/pin file: "+name)
    extra="".join("\npublic import AnyBNormSquare."+m+"\n" for m in MODULES+["Revision06g","Section5Work","Remarks"])
    require((ROOT/"AnyBNormSquare.lean").read_text(encoding="utf-8")==baseline["old_import"]+extra,"Unexpected import changes")
    require((ROOT/"Audit.lean").read_text(encoding="utf-8").startswith(baseline["old_audit"]),"Prior audit commands changed")
    arc=ROOT.parent/"output"/baseline["previous_checkpoint"]
    if arc.exists():require(sha(arc)==baseline["previous_checkpoint_sha256"],"Previous checkpoint archive changed")
    if rows is not None:
        by_name={r["name"]:r for r in rows}
        for name,deps in ROUTES.items():
            row=by_name[A+name]
            require(row["theorem"],"Expected proved theorem: "+name)
            for dep in deps:require(dep in row["deps"],"Missing Section 4 route: "+name+" -> "+dep)
            require((J+"Hypergeometric.DenominatorEstimate4" in row["deps"])==(name in CONDITIONAL),"Unexpected denominator premise: "+name)
        for row in rows:
            if row["module"] in {A+m for m in MODULES}:
                require(not set(row["deps"]) & FORBIDDEN,"Used incompatible fixed-constant JNT wrapper: "+row["name"])
                require(not any("AkhtariTheorem" in d or "Section46Magma" in d or "proposition41_published" in d for d in row["deps"]),"Unexpected external main-theorem premise: "+row["name"])
    steps=[
      (1087,1121,"Section 4.3: cite JNT's general exact bound, specialize r=1, use two cubic gaps, cancel and take sixth roots",["Case43.general_bound","Case43.at_one","Case43.sixth_power","Case43.root_bound","Case43.second_case"]),
      (1123,1165,"Shared r>1 lower bound: cutoff minimality at r-1, 0.952, ell/E substitutions, 0.9375 coordinate bound, 1.498 and 8.176, fourth powers with b-scaled norm",["HigherIndex.cutoff_chain","HigherIndex.coordinate_lower","HigherIndex.factor_lower","HigherIndex.fourth_power","HigherIndex.sequence_lower"]),
      (1167,1228,"Section 4.4: cube lower bound, combine upper bound, c-monotonicity and c=0.75, 0.181 and 1.22e7 roundings, F<=b^4 and positive roots",["Case44.combine","Case44.cutoff_choice","Case44.normalized","Case44.normalized_with_b","Case44.root_bound"]),
      (1230,1249,"Simplify using M>=2,d>=2,r>=2,b>=1,abs(N)>=1; retain 14.8 and the printed exponents",["Case44.simplify_bound","Section4Proof.third_case"]),
      (1251,1311,"Section 4.5: combine exact upper and shared lower bounds, reuse the cited exponential estimate, retain all five printed roundings and take positive roots",["Case45.remove_sqrt","Case45.normalized","Case45.eliminate_f","Case45.root_bound","Case45.simplify_bound","Section4Proof.fourth_case"]),
      (1313,1363,"Section 4.6: four cases on one actual firstIndex and approximant pair, six-way maximum, distinct-value count, comparison of constants and exponents",["Section4Proof.no_three","Section4Proof.count_from_no_three","Section4Proof.proposition41_conditional","Section4Proof.precise_le_large","Section4Proof.theorem13_conditional"]),
    ]
    report=dict(status="passed" if rows is not None else "source preservation passed; compiled audit pending",
      scope="Completion of Section 4 of 06f, including conditional Proposition 4.1 and Theorem 1.3",
      source="source/"+SOURCE_STEM+".tex",source_sha256=SOURCE_HASHES[".tex"],pdf_sha256=SOURCE_HASHES[".pdf"],
      manuscript_complete=False,section4_complete_conditionally=rows is not None,
      denominator_estimate_proved=False,explicit_unproved_premise=J+"Hypergeometric.DenominatorEstimate4",
      conditional_endpoints=[A+n for n in sorted(CONDITIONAL)],
      earlier_proof_modules_unchanged=True,dependency_pins_unchanged=True,manuscript_files_unchanged=True,
      new_mathematical_corrections=[],silent_repairs=[],alternative_arguments=[],
      data_construction="The four branches share one Prepared comparison, actual JNT PaperApproximants and actual least positive firstIndex, constructed in no_three from manuscript hypotheses and the explicit denominator premise.",
      normalization="The standing smallest-initial-square convention is retained explicitly in the unchanged Proposition41 and Theorem13 target definitions. Its global normalization proof remains a later checkpoint, not a hidden result of Section 4.",
      statement_bridges="Squared absolute/signed norms agree. r is natural with its actual firstIndex meaning. n=2r-1 or n=r-1 only abbreviates the displayed exponents. Positive roots and real fractional powers are retained; all decimal certificates are exact rational Lean proofs. Counting is of distinct rational coordinate values satisfying IsIntegerSquare, on the stated integer index set.",
      jnt_reuse="Actual Section 2 approximants; exact comparison error and equation415; symbolic case44/case45 division identities; cutoff monotonicity; minimum-at-three exponential estimate; cardinality of a pair. Fixed b=1 or Q>190 wrappers and their numerical constants are not substituted.",
      remaining="DenominatorEstimate4 stays unproved. Section 5 and later results, computational completeness, and global normalization remain pending.",
      lean_sha256={m:sha(ROOT/"AnyBNormSquare"/(m+".lean")) for m in MODULES},
      steps=[dict(first_line=a,last_line=b,argument=c,lean=[A+n for n in ns]) for a,b,c,ns in steps],
      proof_routes_checked=ROUTES if rows is not None else {})
    write_json(ROOT/"audit/section4-faithfulness.json",report)
    return report
