"""Check new proof dependencies and transcribe the October rows independently."""
import re
from dependency_guard import ROOT, read_json, require, sha
from math import isqrt


def audit_section5_checkpoint(rows):
    audit_dir = ROOT / 'audit'
    record = read_json(audit_dir / 'revision07b-quartic-provenance.json')
    expected = []
    for b in (5, 13, 17):
        name = f'BAllNaSqrSearch-b-{b}-2026-10-01a.txt'
        log = audit_dir / 'table1-evidence' / name
        digest, = [v for k,v in record['sources'].items() if k.endswith(name)]
        require(sha(log) == digest, 'Historical log changed: '+name)
        for line in log.read_text().splitlines():
            if not line.startswith('adding '):
                continue
            v = {k:int(n) for k,n in re.findall(r'(\w+)=\s*(-?\d+)',line)}
            a,d,t,u,k = (v[key] for key in ('a','d','t','u','k'))
            root = isqrt(v['yCurr'])//2
            require((2*root)**2 == v['yCurr'], 'Non-square recorded as a hit')
            x = isqrt(d*root**4+a*a-d*b**4)
            expected.append((a,b,d,t,u,k,root,x))
    lean = (ROOT/'AnyBNormSquare/Section56Records.lean').read_text(encoding='utf8')
    pattern = r'⟨⟨(\d+), (\d+), (\d+), (\d+), (\d+)⟩, \((-?\d+)\), (\d+), (\d+)⟩'
    actual = [tuple(map(int,m)) for m in re.findall(pattern, lean)]
    require(len(expected)==24 and actual==expected, 'Exceptional rows differ from run logs')
    by_name = {r['name']:r for r in rows}
    A = 'AnyBNormSquare.'
    J = '«JNT-2024».'
    for name,deps in {
        'Section5Opening.small_b_one':[J+'theorem14_revised',J+'Hypergeometric.DenominatorEstimate4',J+'ExternalResults.AkhtariTheorem11',J+'Calculations.Section46Magma'],
        'Section5Opening.two_step_lower':[A+'lemma32c'],
        'Section5Opening.normalized_b_one_or_five':[A+'lemma36'],
        'SquareScaling.normalized_parameters':[A+'SquareScaling.divide_square_part'],
        'SquareScaling.scaled_square_iff':[J+'Parameters.rational_square_iff_integer_square'],
        'Section5Low.case_one_norm_free':[A+'Section5Low.case_one'],
        'Section5Low.case_two_norm_free':[A+'Section5Low.case_two'],
        'Section56Records.recorded_counts':[], 'Section56Records.recorded_points':[]}.items():
        row = by_name[A+name]
        require(row['theorem'] and set(deps).issubset(row['deps']), 'Section 5 route: '+name)
