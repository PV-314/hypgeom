"""Extract a release into an empty location, rebuild it and compare its audit."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
from zipfile import ZipFile


def verify(ok, message):
    if not ok:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--lean-bin", type=Path)
    parser.add_argument("--cache-root", type=Path)
    parser.add_argument("--jnt-cache", type=Path)
    args = parser.parse_args()
    archive = args.archive.resolve()
    destination = args.destination.resolve()
    sidecar = json.loads(archive.with_suffix(".json").read_text(encoding="utf8"))
    archive_hash = hashlib.sha256(archive.read_bytes()).hexdigest()
    verify(sidecar["sha256"] == archive_hash, "Release SHA-256 mismatch")
    root = destination / "AnyB-NormSquare"
    destination.mkdir(parents=True, exist_ok=False)
    with ZipFile(archive) as z:
        verify(z.testzip() is None, "ZIP CRC failure")
        prefix = root.name + "/"
        manifest = json.loads(z.read(prefix + "PACKAGE-MANIFEST.json"))
        names = z.namelist()
        expected = {prefix + name for name in manifest} | {prefix + "PACKAGE-MANIFEST.json"}
        verify(len(names) == len(expected) and set(names) == expected, "Unexpected ZIP member inventory")
        for name, digest in manifest.items():
            parts = PurePosixPath(name).parts
            target = (root / name).resolve()
            verify(target.is_relative_to(root) and target != root and
                   not any(p in {".lake", ".."} for p in parts), "Unexpected packaged path")
            data = z.read(prefix + name)
            verify(hashlib.sha256(data).hexdigest() == digest, "Content mismatch: " + name)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        (root/"PACKAGE-MANIFEST.json").write_bytes(z.read(prefix+"PACKAGE-MANIFEST.json"))
    def read(name):
        return json.loads((root/name).read_text(encoding="utf8"))
    def environment():
        return {r["name"]: (r["module"], r["theorem"], sorted(r["deps"]), sorted(r["axioms"]))
                for r in read("audit/environment.json")}
    saved = read("verification.json")
    declarations = environment()
    verify(saved["status"] == "passed" and saved["manuscript_complete"], "Release status is incomplete")
    verify(not (root/".lake").exists(), "Expected fresh build directory")
    runtime = ["--lean-bin", str(args.lean_bin.resolve())] if args.lean_bin else []
    setup = []
    for flag, path in [("--cache-root", args.cache_root), ("--jnt-cache", args.jnt_cache)]:
        if path:
            setup += [flag, str(path.resolve())]
    def run(script, options):
        subprocess.run([sys.executable, "-X", "utf8", script, *options], cwd=root, check=True)
    run("bootstrap.py", setup)
    if not args.cache_root:
        lake = str(args.lean_bin.resolve() / "lake") if args.lean_bin else "lake"
        subprocess.run([lake, "exe", "cache", "get"], cwd=root, check=True)
    run("source_map.py", [])
    run("test_dependencies.py", runtime)
    run("check.py", runtime)
    checked = read("verification.json")
    verify(checked["status"] == "passed" and checked["manuscript_complete"], "Rebuild audit failed")
    verify(saved["release_scope"] == checked["release_scope"], "Mathematical scope changed")
    verify(environment() == declarations, "Declaration, proof dependency or transitive axiom changed")
    tests = read("audit/dependency-tests.json")
    verify(tests["status"] == "passed" and tests["tests_run"] == 25, "Regression test count changed")
    report = dict(archive=archive.name, sha256=archive_hash, verified_payload_files=len(manifest),
                  local_build_cache_supplied=False, source_checked_jnt_cache=bool(args.jnt_cache),
                  exact_git_package_cache=bool(args.cache_root), verified_declarations=len(declarations),
                  verified_theorems=checked["local_theorems"], dependency_tests=tests,
                  build=checked["build"], proof_audit=checked["audit"], status="passed")
    report_file = archive.with_name(archive.stem + "-restore.json")
    report_file.write_text(json.dumps(report, indent=2) + "\n", encoding="utf8")
    print(report_file, flush=True)


if __name__ == "__main__":
    main()
