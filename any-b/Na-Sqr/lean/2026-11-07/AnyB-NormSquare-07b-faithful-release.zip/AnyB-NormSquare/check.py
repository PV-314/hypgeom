"""Build and audit this project's faithful 07b formalisation under the documented premises."""
from pathlib import Path
import argparse
import json
import re
import subprocess
import time
from dependency_guard import ROOT, SOURCE_STEM, sha, write_json, runtime, verify_dependencies, require


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean-bin", type=Path)
    args = parser.parse_args()
    rt = runtime(args.lean_bin)
    env, lake, version = rt["env"], str(rt["lake"]), rt["version"]
    require(__debug__, "Run the mathematical audit without Python -O")
    before = verify_dependencies(ROOT, rt)
    write_json(ROOT / "audit/dependencies-before.json", before)
    sources = [ROOT / "AnyBNormSquare.lean", ROOT / "Audit.lean",
               *sorted((ROOT / "AnyBNormSquare").glob("*.lean"))]
    for path in sources:
        # Conservative lint; the environment audit below is the trust check.
        assert not re.search(r"\b(sorry|admit|axiom|native_decide)\b", path.read_text(encoding="utf-8")), path
    source_before = {p: sha(p) for p in sources}
    audit = ROOT / "audit"
    audit.mkdir(exist_ok=True)

    def run(name, command):
        start = time.monotonic()
        print("Running " + name, flush=True)
        with (audit / (name + ".log")).open("w", encoding="utf-8") as log:
            process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
            while process.poll() is None:
                try:
                    process.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    print(name + " is still running; log: audit/" + name + ".log", flush=True)
        result = dict(exit=process.returncode, command=command,
                      seconds=round(time.monotonic() - start, 2))
        write_json(audit / (name + ".result.json"), result)
        output = (audit / (name + ".log")).read_text(encoding="utf-8")
        print(output[-6500:], flush=True)
        assert process.returncode == 0, name
        return result

    build = run("build", [lake, "build"])
    result = run("axioms-and-statements", [lake, "env", "lean", "--root=.", "Audit.lean"])
    rows = json.loads((audit / "environment.json").read_text(encoding="utf-8"))
    assert all(sha(p) == digest for p, digest in source_before.items()), "Sources changed during verification"
    assert rows
    assert all(set(r["axioms"]) <= {"propext", "Classical.choice", "Quot.sound"} for r in rows)
    by_name = {r["name"]: r for r in rows}
    routes = {
        "lemma21": "«JNT-2024».Approximation.lemma21_imaginaryQuadratic",
        "lemma31": "«JNT-2024».Parameters.proposition31b_published",
        "lemma32a": "«JNT-2024».Parameters.lemma35b",
        "lemma32b": "«JNT-2024».Parameters.lowerBoundsAtRate",
        "lemma32c": "«JNT-2024».Parameters.lowerBoundsAtRate",
        "lemma32c_uniform": "«JNT-2024».Parameters.lemma35c",
        "lemma33": "«JNT-2024».Parameters.lemma38a",
        "lemma34": "«JNT-2024».Parameters.lemma39a",
        "lemma35": "AnyBNormSquare.lemma35_normalizer",
        "lemma36": "AnyBNormSquare.lemma36_of_solution",
    }
    for name, upstream in routes.items():
        assert upstream in by_name["AnyBNormSquare." + name]["deps"], (name, upstream)
    assert "AnyBNormSquare.lemma32b" in by_name["AnyBNormSquare.lemma32c"]["deps"]
    lemma35_routes = {
        "lemma35": ["Lemma35Proof.N4_eq_paper"],
        "lemma35_normalizer": ["Lemma35Proof.lower_bound", "Lemma35Proof.upper_bound"],
        "Lemma35Proof.lower_bound": ["Lemma35Proof.productSquareRat_two_uncapped",
            "Lemma35Proof.productSquareRat_odd_nonneg", "Lemma35Proof.integer_of_nonnegative_valuations",
            "Lemma35Proof.one_le_g"],
        "Lemma35Proof.upper_bound": ["Lemma35Proof.g_upper_bound", "Lemma35Proof.scale_le_eight"],
    }
    for name, dependencies in lemma35_routes.items():
        for dependency in dependencies:
            require("AnyBNormSquare." + dependency in by_name["AnyBNormSquare." + name]["deps"],
                    "Missing printed Lemma 3.5 proof step: " + name + " -> " + dependency)
    jnt35_routes = {
        "Lemma35Proof.productSquareRat_odd_nonneg": ["Approximation.gSquared_valuation_published",
            "Approximation.g3_valuation_odd_published"],
        "Lemma35Proof.scale_square_integer": ["Approximation.dPrimeInteger_cast"],
        "Lemma35Proof.integer_of_nonnegative_valuations": ["int_dvd_of_valuation_le"],
        "Lemma35Proof.g_upper_bound": ["Approximation.g1_unit"],
        "unitPowerNorm_sign": ["Parameters.epsilonNorm_zpow_sign"],
    }
    for name, dependencies in jnt35_routes.items():
        for dependency in dependencies:
            require("«JNT-2024»." + dependency in by_name["AnyBNormSquare." + name]["deps"],
                    "Missing JNT reuse in Lemma 3.5: " + dependency)
    for row in rows:
        if row["module"] == "AnyBNormSquare.Normalizer":
            require(not set(row["deps"]) & {"«JNT-2024».Hypergeometric.DenominatorEstimate4",
                "«JNT-2024».Parameters.lemma312", "«JNT-2024».Parameters.lemma312_eq",
                "«JNT-2024».Parameters.lemma311_published"},
                "Unexpected premise or coprime normalizer theorem in Lemma 3.5")
    lemma36_routes = {
        "lemma36_of_solution": ["Lemma36Proof.exclude_three_mod_four",
            "Lemma36Proof.two_small_case", "Lemma36Proof.two_large_case"],
        "Lemma36Proof.exclude_three_mod_four": ["Lemma36Proof.sum_prime_factorization",
            "Lemma36Proof.fourth_power_dvd_sum", "Lemma36Proof.no_prime_square_gcd"],
        "Lemma36Proof.sum_prime_factorization": ["Lemma36Proof.prime_power_divides_both"],
        "Lemma36Proof.prime_power_divides_both": ["Lemma36Proof.prime_divides_both"],
        "Lemma36Proof.two_small_case": ["Lemma36Proof.fourth_power_dvd_sum"],
        "Lemma36Proof.two_large_case": ["Lemma36Proof.four_dvd_coordinates_of_sum16",
            "Lemma36Proof.no_prime_square_gcd"],
        "Lemma36Proof.four_dvd_coordinates_of_sum16": ["Lemma36Proof.sum_square_residues16",
            "Lemma36Proof.four_dvd_of_square_zero16"],
        "Lemma36Proof.sum_square_residues16": ["Lemma36Proof.square_residues16"],
    }
    for name, dependencies in lemma36_routes.items():
        for dependency in dependencies:
            require("AnyBNormSquare." + dependency in by_name["AnyBNormSquare." + name]["deps"],
                    "Missing printed Lemma 3.6 proof step: " + name + " -> " + dependency)
    jnt36_routes = {
        "Lemma36Proof.four_dvd_of_square_zero16": ["Section5.lemma54_square_residues",
            "Section5.int_mod_four_of_zmod_val"],
        "Lemma36Proof.two_small_case": ["prime_dvd_iff_valuation_pos", "valuation_int_pow"],
    }
    for name, dependencies in jnt36_routes.items():
        for dependency in dependencies:
            require("«JNT-2024»." + dependency in by_name["AnyBNormSquare." + name]["deps"],
                    "Missing JNT reuse in Lemma 3.6: " + dependency)
    mathlib36_routes = {
        "Lemma36Proof.sum_prime_factorization": ["Nat.eq_sq_add_sq_iff", "Nat.prod_factorization_pow_eq_self"],
        "Lemma36Proof.prime_divides_both": ["ZMod.mod_four_ne_three_of_sq_eq_neg_sq'"],
    }
    for name, dependencies in mathlib36_routes.items():
        for dependency in dependencies:
            require(dependency in by_name["AnyBNormSquare." + name]["deps"],
                    "Missing pinned mathlib reuse in Lemma 3.6: " + dependency)
    for row in rows:
        if row["module"] == "AnyBNormSquare.AdmissiblePrimes":
            require("«JNT-2024».Hypergeometric.DenominatorEstimate4" not in row["deps"],
                    "Unexpected denominator-estimate use in Lemma 3.6")
    for name in ["Theorem13", "Proposition41", "Theorem14a", "Theorem14b",
                 "Corollary15a", "Corollary15b"]:
        assert not by_name["AnyBNormSquare." + name]["theorem"]
    revision_routes = {
        "section21_error_identity": ["«JNT-2024».Section2.raw_error_identity"],
        "section21_corrected_error_identity": ["«JNT-2024».Section2.corrected_error_identity"],
        "paperK0_justified": ["«JNT-2024».Section2.paper_constants"],
        "section21_q_bound_conditional": ["«JNT-2024».Section2.corrected_q_bound_fixed",
            "«JNT-2024».Hypergeometric.DenominatorEstimate4"],
        "section41_near_one": ["AnyBNormSquare.lemma34",
            "«JNT-2024».Section4.unit_circle_chord_le_arg", "«JNT-2024».Parameters.sequenceOmega_norm"],
    }
    for name, dependencies in revision_routes.items():
        for dependency in dependencies:
            require(dependency in by_name["AnyBNormSquare." + name]["deps"],
                    "Missing revision proof dependency: " + name + " -> " + dependency)
    from revision_audit import audit_revision
    audit_revision()
    for name in ["section21_error_identity", "section21_corrected_error_identity",
                 "paperK0_justified", "section41_near_one"]:
        require("«JNT-2024».Hypergeometric.DenominatorEstimate4" not in
                by_name["AnyBNormSquare." + name]["deps"], "Unexpected denominator premise")
    from construction_audit import audit_construction
    construction_report = audit_construction(rows)
    from revision06f_audit import audit_revision06f
    revision06f_report = audit_revision06f(rows)
    from prerequisites_audit import audit_prerequisites
    prerequisites_report = audit_prerequisites(rows)
    from section42_audit import audit_section42
    section42_report = audit_section42(rows)
    from section4_audit import audit_section4
    section4_report = audit_section4(rows)
    from revision06g_audit import audit_revision06g
    revision06g_report = audit_revision06g(rows)
    from revision07b_audit import audit_revision07b
    audit_revision07b()
    from section5_checkpoint_audit import audit_section5_checkpoint
    audit_section5_checkpoint(rows)
    from section5_completion_audit import audit_section5
    section5_report = audit_section5(rows)
    from release_audit import audit_release
    release = audit_release(rows)
    after = verify_dependencies(ROOT, rt)
    require(after == before, "Effective dependencies changed during the build/audit")
    write_json(ROOT / "audit/dependencies-after.json", after)
    inputs = sources + [ROOT / n for n in ["lakefile.toml", "lake-manifest.json", "lean-toolchain",
        "dependencies.lock.json", "bootstrap.py", "dependency_guard.py", "test_dependencies.py",
        "check.py", "package.py", "source_map.py", "SOURCE_MAP.json",
        "audit/lemma35-correspondence.json", "audit/lemma36-correspondence.json",
        "construction_audit.py", "audit/construction-baseline.json", "audit/construction-faithfulness.json",
        "prerequisites_audit.py", "audit/prerequisites-faithfulness.json",
        "section42_audit.py", "audit/section42-baseline.json", "audit/section42-faithfulness.json",
        "section4_audit.py", "audit/section4-baseline.json", "audit/section4-faithfulness.json",
        "revision06f_audit.py", "audit/revision06f-baseline.json", "audit/revision06f-faithfulness.json", "audit/revision06f-pdf.json",
        "revision_audit.py", "audit/revision06e-baseline.json", "audit/revision06e-faithfulness.json",
        "source/provenance.json", "source/provenance06f.json", "source/provenance06g.json", "audit/source-map06g.json", "revision07b_audit.py", "audit/revision07b-baseline.json", "section5_checkpoint_audit.py", "section5_completion_audit.py", "audit/section5-completion.json", "audit/section56-published-pari.json", "audit/revision07b-quartic-provenance.json", "audit/revision07b-faithfulness.json", "audit/revision06e-pdf.json",
        "revision06g_audit.py", "audit/revision06g-baseline.json", "audit/revision06g-faithfulness.json", "audit/revision06g-pdf.json",
        "AGENTS.md", "README.md", "CORRECTIONS.md", "EXTERNAL_INPUTS.md", "PROOF_LEDGER.md"]]
    inputs += [ROOT / n for n in ["release_audit.py", "SOURCE_MAP.md", "audit/release-scope.json", "audit/environment.json", "audit/dependency-tests.json", "audit/build.log", "audit/axioms-and-statements.log"]]
    inputs += [ROOT / "audit/github-proof-baseline.json", ROOT / "audit/provenance-migration.json", ROOT / "verify_release_zip.py"]
    inputs += sorted(p for p in (ROOT / "computation").rglob("*") if p.is_file())
    inputs += sorted((ROOT / "audit/table1-evidence").glob("*"))
    inputs += [ROOT / "source" / (SOURCE_STEM + ext) for ext in [".tex", ".pdf"]]
    write_json(ROOT / "verification.json", dict(status="passed", manuscript_complete=release["complete_with_agreed_premises"], release_scope=release,
        toolchain=version.strip(), compiled_local_declarations=len(rows),
        local_theorems=sum(r["theorem"] for r in rows), standard_axioms_only=True,
        proof_routes_checked=routes, build=build, audit=result,
        revision06e_proof_routes_checked=revision_routes,
        construction_proof_routes_checked=construction_report["proof_routes_checked"],
        revision06f_proof_routes_checked=revision06f_report["proof_routes_checked"],
        prerequisites_proof_routes_checked=prerequisites_report["proof_routes_checked"],
        section42_proof_routes_checked=section42_report["proof_routes_checked"],
        section4_proof_routes_checked=section4_report["proof_routes_checked"],
        section4_complete_conditionally=True,
        section5_complete_conditionally=section5_report["section5_complete_conditionally"],
        manuscript_revision="2026-11-07b", revision06g=revision06g_report,
        lemma35_printed_proof_routes_checked=lemma35_routes,
        lemma35_jnt_reuse_checked=jnt35_routes,
        lemma36_printed_proof_routes_checked=lemma36_routes,
        lemma36_jnt_reuse_checked=jnt36_routes,
        lemma36_mathlib_reuse_checked=mathlib36_routes,
        effective_dependencies_checked_before_and_after=True,
        inputs={p.relative_to(ROOT).as_posix(): sha(p) for p in inputs}))
    print("Build, exact dependency pins, all local axioms and cited proof routes passed.", flush=True)


if __name__ == "__main__":
    main()
