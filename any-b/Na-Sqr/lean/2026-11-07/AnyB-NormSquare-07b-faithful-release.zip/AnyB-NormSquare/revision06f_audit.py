"""Audit the exact author-approved 06e-to-06f correction and its Lean proof."""
import difflib
import re
from dependency_guard import ROOT, SOURCE_STEM, SOURCE_HASHES, SOURCE_DIR, sha, read_json, write_json, require, verify_sources

SOURCE_STEM = "sequence-version-any-b-nrmA-sqr-with-y-result-2026-11-06f"
SOURCE_HASHES = {".tex": "82eff8993df2763db46e1c59e8e2933a5cecb77c7c1b46d44a5b9eadf98bfc02", ".pdf": "5623041510758d0369be3c87c4bc732b49d4fbf327f60e4e0398e11cc717b03e"}

LOCAL = "AnyBNormSquare.Revision06f."
ROUTES = {
    "Q_lower_chain": ["«JNT-2024».Section4.exp_168_bounds"],
    "gaussian_Q_lower_chain": [LOCAL + "Q_lower_chain", "«JNT-2024».Section4.gaussian_parameters"],
    "gaussian_Q_gt": [LOCAL + "gaussian_Q_lower_chain"],
}

def audit_revision06f(rows=None):
    verify_sources(ROOT)
    baseline = read_json(ROOT / "audit/revision06f-baseline.json")
    for name, digest in baseline["files"].items():
        if name not in baseline["authorised_existing_edits"]:
            require(sha(ROOT / name) == digest, "Changed prior proof/source/pin: " + name)
    require(sha(ROOT / "source/provenance06e.json") == baseline["files"]["source/provenance.json"], "Old source provenance changed")
    require((ROOT / "AnyBNormSquare.lean").read_text(encoding="utf-8") == baseline["old_import"] + "\npublic import AnyBNormSquare.Revision06f\n\npublic import AnyBNormSquare.Prerequisites\n\npublic import AnyBNormSquare.Case42\n\npublic import AnyBNormSquare.Case43\n\npublic import AnyBNormSquare.HigherIndex\n\npublic import AnyBNormSquare.Case44\n\npublic import AnyBNormSquare.Case45\n\npublic import AnyBNormSquare.Section4\n\npublic import AnyBNormSquare.Revision06g\n\npublic import AnyBNormSquare.Section5Work\n\npublic import AnyBNormSquare.Remarks\n", "Unexpected root import change")
    require((ROOT / "Audit.lean").read_text(encoding="utf-8").startswith(baseline["old_audit"]), "Prior audit commands changed")
    arc = ROOT.parent / "output" / baseline["previous_checkpoint"]
    if arc.exists():
        require(sha(arc) == baseline["previous_checkpoint_sha256"], "Previous archive changed")
    old = ROOT / "source/sequence-version-any-b-nrmA-sqr-with-y-result-2026-11-06e.tex"
    new = ROOT / "source" / (SOURCE_STEM + ".tex")
    a, b = old.read_text(encoding="utf-8"), new.read_text(encoding="utf-8")
    before = r"Q > \frac{2e^{1.68}\left( 1+\sqrt{0.9375} \right)"
    after = r"Q \geq \frac{2e^{1.68}\left( 1+\sqrt{0.9375} \right)"
    require(a.count(before) == 1 and b == a.replace(before, after, 1), "Unreviewed 06f source change")
    pattern = r"\\begin\{(theorem|lemma|proposition|corollary|conjecture)\}.*?\\end\{\1\}"
    numbered = [m.group() for m in re.finditer(pattern, a, re.S)]
    require(len(numbered) == 14 and numbered == [m.group() for m in re.finditer(pattern, b, re.S)], "Numbered statement changed")
    require(sha(new) == SOURCE_HASHES[".tex"], "Changed historical 06f source")
    for ext, digest in SOURCE_HASHES.items():
        original = SOURCE_DIR / (SOURCE_STEM + ext)
        if original.exists(): require(sha(original) == digest, "Changed original 06f attachment")
    pdf = read_json(ROOT / "audit/revision06f-pdf.json")
    require(pdf["status"] == "passed" and pdf["pdf_sha256"] == SOURCE_HASHES[".pdf"], "PDF review mismatch")
    for name, digest in pdf["images"].items(): require(sha(ROOT / "audit/pdf06f" / name) == digest, "Changed reviewed image")
    if rows is not None:
        by_name = {r["name"]: r for r in rows}
        for name, deps in ROUTES.items():
            row = by_name[LOCAL + name]
            require(row["theorem"], "Expected proved theorem: " + name)
            for dep in deps: require(dep in row["deps"], "Missing proof route: " + name + " -> " + dep)
            require("«JNT-2024».Hypergeometric.DenominatorEstimate4" not in row["deps"], "Unexpected denominator premise")
    (ROOT / "audit/revision06f.diff").write_text("".join(difflib.unified_diff(a.splitlines(True), b.splitlines(True), fromfile=old.name, tofile=new.name)), encoding="utf-8")
    report = dict(status="passed" if rows is not None else "source checks passed; compiled audit pending",
        scope="06f source migration and the corrected (4.9) chain; separate prerequisites audit covers Section 4.1 assembly",
        source_sha256=SOURCE_HASHES[".tex"], pdf_sha256=SOURCE_HASHES[".pdf"],
        numbered_statements_unchanged=14, prior_proof_modules_unchanged=True, dependency_pins_unchanged=True,
        correction=dict(line=955, equation="4.9", original="First comparison Q > expression", corrected="Q >= expression", consequence="The next comparison stays strict; Q>21.12>1 is unchanged", author_approved=True),
        silent_mathematical_repairs=[], alternative_arguments=[], equality_exclusion_argument_used=False,
        denominator_estimate_proved=False, proof_routes_checked=ROUTES if rows is not None else {},
        manuscript_complete=False)
    write_json(ROOT / "audit/revision06f-faithfulness.json", report)
    return report

if __name__ == "__main__":
    print(audit_revision06f())
