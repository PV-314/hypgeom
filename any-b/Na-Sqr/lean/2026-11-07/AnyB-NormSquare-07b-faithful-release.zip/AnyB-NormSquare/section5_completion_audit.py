"""Check the conditional Section 5 proof against the numbered 07b statement."""
import re
from dependency_guard import ROOT, read_json, require, write_json


def audit_section5(rows):
    prefix = 'AnyBNormSquare.'
    jnt = '«JNT-2024».'
    by_name = {r['name']: r for r in rows}

    def dependencies(name):
        seen = set()
        pending = [prefix + name]
        while pending:
            current = pending.pop()
            if current in seen:
                continue
            seen.add(current)
            if current in by_name:
                pending.extend(by_name[current]['deps'])
        return seen

    analytic = [
        'SquareScaling.normalized_parameters', 'SquareScaling.count_transport',
        'Section5Opening.two_step_lower', 'Section5Opening.small_b_one',
        'Section5Cases.four_bounds', 'Prerequisites.prepare', 'Prerequisites.apply_prepared',
        'Case42.first_case', 'Case43.second_case', 'Case44.root_bound', 'Case45.root_bound',
        'Section5Low.case_one', 'Section5Low.case_two', 'Section5High.third_rearrange',
        'Section5Fourth.fourth_rearrange', 'Section5Size.large_y', 'Section5Discriminant.exclude'
    ]
    routes = {
        'Section5Proof.theorem14a_conditional': analytic + [
            'Theorem14a', 'Section5Reduction.small_normalized', 'Section5Proof.finite_count',
            'Section56Calculations.least_lt_searchBound', 'Section56Calculations.exceptional_values',
            'Section56Cutoff.bound_of_cases', 'Section56Cutoff.size_le', 'Section56Table.thresholds',
            'Section5Low.case_one_norm_free', 'Section5Low.case_two_norm_free',
            'Section5High.third_norm_free', 'Section5Fourth.fourth_norm_free'],
        'Section5Proof.theorem14b_conditional': analytic + [
            'Theorem14b', 'Section5Reduction.normalized_threshold', 'Section5Reduction.rounded_bound',
            'Section5Opening.normalized_b_one_or_five', 'Section5High.third_simplify',
            'Section5Fourth.fourth_simplify']
    }
    external = [jnt + name for name in ('Hypergeometric.DenominatorEstimate4',
                'ExternalResults.AkhtariTheorem11', 'Calculations.Section46Magma')]
    calculations = [prefix + 'Section56Calculations.' + name for name in
                    ('JavaEnumeration', 'JavaSquareSearch', 'ExceptionalQuartics')]
    for name, expected in routes.items():
        require(by_name[prefix + name]['theorem'], 'Missing Section 5 theorem: ' + name)
        used = dependencies(name)
        for dep in [prefix + d for d in expected] + external + [jnt + 'theorem14_revised']:
            require(dep in used, 'Missing Section 5 proof step: ' + name + ' -> ' + dep)
        for dep in calculations:
            require((dep in used) == ('14a_' in name), 'Incorrect calculation dependency: ' + name)
    for n in calculations:
        require(not by_name[n]['theorem'], 'Computational premise asserted as theorem: ' + n)
    for r in ('Section5Checks.recorded_indices', 'Section56Table.thresholds',
              'Section56Records.recorded_counts', 'Section56Records.recorded_points'):
        require(by_name[prefix+r]['theorem'] and dependencies(r).isdisjoint(external+calculations),
                'Finite certificate depends on external input: '+r)
    row = next(r for r in read_json(ROOT/'SOURCE_MAP.json')['statements'] if r['number']=='1.4')
    require(row['lean'] == [prefix+n for n in routes], 'Theorem 1.4 source map mismatch')
    log_totals = {}
    for b, last_u, c1 in [(5,73,242598),(13,498,18110693),(17,851,58466661)]:
        path = ROOT/'audit/table1-evidence'/f'BAllNaSqrSearch-b-{b}-2026-10-01a.txt'
        counts = re.findall(r'^done b=(\d+), u=(\d+): total found (\d+) equations', path.read_text(), re.M)
        require(counts and tuple(map(int,counts[-1])) == (b,last_u,c1), 'Table 1 run totals: '+str(b))
        log_totals[b] = c1
    report = dict(verified_log_totals=log_totals, manuscript='07b', section5_complete_conditionally=True,
                  statement_sha256=row['statement_sha256'], proof_routes=routes,
                  upstream_premises=external, part_a_additional_premises=calculations,
                  mathematical_repairs_in_this_checkpoint=[], denominator_estimate_proved=False)
    write_json(ROOT/'audit/section5-completion.json',report)
    return report
