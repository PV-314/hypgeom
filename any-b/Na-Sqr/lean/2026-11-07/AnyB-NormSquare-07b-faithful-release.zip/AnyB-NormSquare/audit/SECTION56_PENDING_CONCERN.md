# Section 5.6: search-range clarification required

Historical 06g finding. The author clarified the search range and incorporated
it in 07b. The separate quartic solver provenance question is recorded in
`revision07b-quartic-provenance.json`.

Status: paused for the author's response, 2026-11-07. No correction to the
manuscript or replacement proof has been integrated.

The authoritative 06g TeX, lines 1761–1768, says the computation checks the
tail terms that fail the lower bound of Proposition 4.1. That proposition's
six-term maximum is displayed at lines 1349–1359.

The current public program referenced by the paper is:
https://raw.githubusercontent.com/PV-314/hypgeom/main/any-b/Na-Sqr/java/BAllNaSqrSearch.java

The published BAllNaSqrSearch.java passes aLB=1 to getYM1UpperBound. The four intermediate bounds and the strict positive and negative loop cutoffs are present in the exact source under computation/any-b/Na-Sqr/java. The internal recurrence stores four times the paper's y. The original diagnostic used a web extraction. computation/github.json identifies the release source by commit and Git blob.

## Concrete range difference

Take (a,b,d,t,u)=(659,5,10205,101,1). Then
t²−du²=−4, db⁴−a²=2438², gcd(a,b²)=1, and 101²<d<102².
The recurrence gives y₁=160817, y₂=1640815826, y₃=16741243711861.
All three of these terms are nonsquares.

Evaluating the current program's cutoff formulas gives approximately
3,722,840,829,782. Exact rational bounds, independently checked in
`section56-code-review/check_cutoff.py`, put each of those four mathematical
formulas below 4,000,000,000,000, which is less than y₃.

In contrast, the fourth term in the printed Proposition 4.1 maximum is
26.43 b² |Nα|² / sqrt(d). Since sqrt(d)<102, this term is strictly greater
than 3890637124784002/17, or approximately 228,861,007,340,235, which exceeds y₃.
Thus the printed search range includes y₃, whereas the current program's
cutoff formulas exclude it. The diagnostic compares formulas exactly; it is
not a certificate of execution of Java's floating-point operations.

## Consequences and decision needed

This is a discrepancy in the description and scope of the computation, not
a counterexample to the theorem, Table 1, or the claimed square counts.
In particular, the example does not exhibit a missed square. The sharper
cutoff may be justified by the intermediate bounds, but identifying that
argument with the printed Proposition 4.1 argument requires an explicit bridge
or an author-approved clarification; it must not happen silently in Lean.

Which program revision and cutoff were intended for the calculation described
in Section 5.6? If the current sharper cutoff is intended, should the account
be revised to state and justify that cutoff, rather than the Proposition 4.1
search range? If another version checked the printed range, identify that
version so it can be pinned as computational evidence.

All previously approved unproved premises remain approved: DenominatorEstimate4,
AkhtariTheorem11, JNT Section46Magma, and this paper's Java/Magma mathematical
claims with explicit completeness obligations. This question does not request
approval of those premises again. It concerns how to specify the calculation
faithfully and avoid claiming that an inspected program performs a different
search from the one actually implemented.

## Saved work

The verified 06g migration checkpoint is
`../output/AnyB-NormSquare-20261107-revision06g.zip`, SHA-256
`691507e990cd1cc2e0e6545843c51a8c25a11b9d147ce40f2a5382fed48a9f3e`.
It contains the earlier conditional results through Section 4 and the proved
06g power correction. Full checks passed: 25 dependency tests, 332 compiled
local declarations, 296 local theorems, and only standard Lean axioms.
The archive is a partial verified checkpoint, not a completed manuscript release.

The Section 5 opening and square-scaling drafts compiled in isolation but
remain outside the integrated project and full faithfulness audit. They are
preserved separately in the paused-drafts backup. Further proof implementation
and final release assembly await the author's response to this concern.
