import AnyBNormSquare
import «JNT-2024».Section5AssemblyRevised
import Lean

/- Read-only inspection of existing compiled declarations. No mathematical
premise is supplied and no new mathematical theorem is declared. -/
open Lean Elab Command

#check «JNT-2024».theorem14_revised
#check «JNT-2024».theorem14_paper_revised
#print «JNT-2024».Theorem14
#print «JNT-2024».ExternalResults.AkhtariSolution
#print «JNT-2024».ExternalResults.AkhtariTheorem11
#print «JNT-2024».Calculations.Section46Magma
#print «JNT-2024».Section4.SmallQuarticHeightBound
#print «JNT-2024».Section4.smallPairs
#check «JNT-2024».Section4.smallPairs_card
#check «JNT-2024».Section4.smallQuartic_complete_bounded
#check «JNT-2024».Section4.smallQuartic_completeness_iff_height
#check AnyBNormSquare.lemma36
#check «JNT-2024».Parameters.y_zero
#check «JNT-2024».Parameters.y_strictMono_nonnegative
#check «JNT-2024».Parameters.y_strictMono_negative_tail

run_cmd do
  let env ← getEnv
  let roots := [``«JNT-2024».theorem14_revised,
    ``«JNT-2024».theorem14_paper_revised, ``AnyBNormSquare.lemma36,
    ``AnyBNormSquare.Section4Proof.theorem13_conditional,
    ``«JNT-2024».Section4.smallQuartic_complete_bounded,
    ``«JNT-2024».Section4.smallQuartic_completeness_iff_height]
  let mut rows : Array Json := #[]
  for n in roots do
    let ci := env.find? n |>.get!
    let axs ← collectAxioms n
    let typeFormat ← liftTermElabM do PrettyPrinter.ppExpr ci.type
    rows := rows.push <| Json.mkObj [
      ("name", toJson n.toString),
      ("type", toJson typeFormat.pretty),
      ("deps", toJson (ci.getUsedConstantsAsSet.toList.map Name.toString)),
      ("axioms", toJson (axs.toList.map Name.toString))]
  liftIO <| IO.FS.writeFile "audit/small-b-premises-declarations.json"
    (Json.pretty (toJson rows))
  logInfo m!"Inspected {rows.size} existing declarations; no premises assumed"
