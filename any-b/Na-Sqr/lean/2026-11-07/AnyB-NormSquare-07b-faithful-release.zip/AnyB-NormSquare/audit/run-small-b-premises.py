"""Inspect the pinned small-b inputs without adding any mathematical premise."""
from pathlib import Path
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from dependency_guard import runtime, verify_dependencies, sha, write_json

rt = runtime(ROOT.parent / "JNT-2024_lean/lean-4.35.0-windows/bin")
proofs = [ROOT / "AnyBNormSquare.lean", ROOT / "Audit.lean",
          *sorted((ROOT / "AnyBNormSquare").glob("*.lean"))]
before_proofs = {str(p.relative_to(ROOT)): sha(p) for p in proofs}
print("Verifying pinned dependencies and original attachments", flush=True)
before = verify_dependencies(ROOT, rt)
provenance = json.loads((ROOT / "source/provenance.json").read_text(encoding="utf-8"))
for item in provenance.values():
    assert sha(Path(item["original_path"])) == item["sha256"]
command = [str(rt["lake"]), "env", "lean", "--root=.", "audit/small-b-premises.lean"]
print("Inspecting existing compiled Lean declarations", flush=True)
with (ROOT / "audit/small-b-premises.log").open("w", encoding="utf-8") as log:
    result = subprocess.run(command, cwd=ROOT, env=rt["env"], stdout=log, stderr=subprocess.STDOUT)
assert result.returncode == 0, "See audit/small-b-premises.log"
rows = json.loads((ROOT / "audit/small-b-premises-declarations.json").read_text(encoding="utf-8"))
assert len(rows) == 6
for row in rows:
    assert set(row["axioms"]) <= {"propext", "Classical.choice", "Quot.sound"}
    if row["name"].endswith((".theorem14_revised", ".theorem14_paper_revised")):
        for premise in ["DenominatorEstimate4", "AkhtariTheorem11", "Section46Magma"]:
            assert premise in row["type"]
    else:
        assert "AkhtariTheorem11" not in row["type"]
        assert "Section46Magma" not in row["type"]
print("Rechecking dependency and proof-source preservation", flush=True)
after = verify_dependencies(ROOT, rt)
assert before == after
assert before_proofs == {str(p.relative_to(ROOT)): sha(p) for p in proofs}
write_json(ROOT / "audit/small-b-premises-verification.json", {
    "scope": "Inspection only; no additional mathematical premises accepted or supplied",
    "dependencies": before,
    "original_06f_attachments_verified": provenance,
    "existing_proof_sources_unchanged": before_proofs,
    "lean_command": command,
    "lean_exit": result.returncode,
    "inspected_declarations": len(rows),
    "allowed_axioms_only": True,
    "evidence_hashes": {name: sha(ROOT / "audit" / name) for name in [
        "small-b-premises.lean", "run-small-b-premises.py", "small-b-premises.log",
        "small-b-premises-declarations.json"]}
})
print("PASS: pinned dependencies and original 06f attachments verified; six compiled declarations inspected; existing proof sources unchanged; no additional premises assumed.")
