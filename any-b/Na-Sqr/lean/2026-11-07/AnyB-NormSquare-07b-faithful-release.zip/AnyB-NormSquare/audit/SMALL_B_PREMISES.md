# Small-b dependency audit for the exact 06f manuscript

Date: 2026-11-07. Scope: inspect and report; do not accept or supply any new
mathematical premise. No Section 5 proof has been added. The user has accepted
only `Hypergeometric.DenominatorEstimate4` as an explicit unproved dependency.

## Conclusion and decision awaiting the user

The printed reduction can reuse the pinned JNT Theorem 1.4, but that theorem
has two additional explicit inputs: `ExternalResults.AkhtariTheorem11` and
`Calculations.Section46Magma`. Neither has a proof supplied by the imported
theorem, and neither is currently approved as an assumption in this project.
No manuscript correction was identified in this small-b inference. The issue
is the proof status of the cited result's inputs.

Before implementing this invocation, the user must decide whether both inputs
may be retained as explicit, unproved premises of the conditional small-b
result and any endpoint that uses it, or whether their proofs must first be
supplied. Earlier approvals recorded inside the upstream archive do not apply
to this project. No axiom or default instance should be introduced in either
case. These are requirements of the existing pinned invocation, not a claim
that the desired conclusion logically implies either external input.

## Exact source and proof route

The authority is the attached `sequence-version-any-b-nrmA-sqr-with-y-result-2026-11-06f.tex`,
SHA256 `82eff8993df2763db46e1c59e8e2933a5cecb77c7c1b46d44a5b9eadf98bfc02`.
Section 5 lines 1364--1369 first remove the square part of `gcd(a,b^2)`;
lines 1404--1410 cite JNT Theorem 1.4 and Lemma 3.6 to reduce to `b >= 5`.
The current paper's target is Theorem 1.4, label `thm:1.3-seq-new` at line 283.

The JNT dependency remains the supplied f2-evidence1 archive, SHA256
`158fc598a641828d30b5e543608a66c5e6e61d64104eb8881ce2cf522b726990`.
All JNT source references below are relative to
`.dependencies/JNT-2024-faithful-20261106-f2-evidence1/JNT-2024/`.

1. After the printed square-factor reduction, the parameters must satisfy
   `Squarefree (Int.gcd a (b^2))`. The already proved local `lemma36` then says
   every prime divisor of `b` is 1 modulo 4. The positive square root required
   by that lemma comes from `N_alpha < 0` and `IsSquare (-N_alpha)`.
2. Consequently the normalized cases `b=2,3,4` are impossible: 2 divides 2
   and 4, and 3 divides 3, contradicting the conclusion of Lemma 3.6. These
   cases do not independently invoke JNT Theorem 1.4 or an external input.
3. The remaining normalized small case is `b=1`. Use
   `theorem14_revised` (`Section5AssemblyRevised.lean:164`), whose conclusion
   `Theorem14` is defined in `Targets.lean:51`. It supplies at most three
   distinct integer-square values in the whole sequence, and at most two
   in the nonexceptional case. The general three-value bound suffices here;
   no exclusion of JNT's exceptional cases is required.
4. When `b=1`, the initial square value is `y_0=1`. On `k >= 2`, strict
   monotonicity gives `y_k > 1`. On `k <= K-1`, the negative-tail monotonicity
   and the cutoff condition give `y_k > y_K > 1`.
   The reusable results are `Parameters.y_zero`,
   `Parameters.y_strictMono_nonnegative`, `Parameters.IsNegativeCutoff`, and
   `Parameters.y_strictMono_negative_tail`. Removing 1 from a finite set
   containing at most three square values leaves at most two values covering
   these tails. Counts concern distinct values, not indices or square roots.

This explains the stated reduction without adding `d >= 300/u^2`, a norm
restriction, or a nonexceptional hypothesis to the small-b branch. The
commented-out Akhtari paragraph at 06f lines 1413--1418 is not an active proof
step. The Akhtari dependency instead enters through the cited JNT theorem.

## The additional inputs, precisely

### `ExternalResults.AkhtariTheorem11`

`AkhtariInput.lean:51--63` defines positive natural-number solutions of
`A*X^4 = B*Y^2 + 1` and the assertion that any three positive solution pairs
contain an equal pair, for all positive natural numbers A and B. Thus it is
the bound of at most two distinct positive solution pairs for
`A*X^4 - B*Y^2 = 1`. The file attributes this to Akhtari's Theorem 1.1,
J. reine angew. Math. 630 (2009).

In JNT's norm -1 branch, `norm_minus_one_noninitial_unique`
(`AkhtariInput.lean:70`) specializes to `A=a^2+1`, `B=1`. The known solution
`(1,a)` leaves at most one other positive solution. The sequence/integrality
bridge is proved in `Parameters.section46_norm_minus_one` (line 90).
This is a genuine input to the pinned proof, not merely an unused import.
The full public JNT theorem takes the full `AkhtariTheorem11` structure.

Status: named external mathematical premise, not a theorem proved in the
pinned Lean development. This audit checks the exact formal interface and its
use; it is not a new proof of Akhtari's published theorem or an independent
bibliographic audit of that publication.

### `Calculations.Section46Magma`

`Section46Calculation.lean:51--52` defines this structure with one field,
`height : Section4.SmallQuarticHeightBound`. Its exact content is
(`SmallQuarticCertificates.lean:99`): for every `(a,n)` in `smallPairs` and
positive natural numbers x,y,

    x^2 + n^2 = (a^2+n^2)*y^4  implies  y <= 109.

Here `smallPairs` is precisely the 63 pairs with `a>0`, `n>=2`,
`a^2+n^2 <= 111`, and `a^2+n^2` nonsquare
(`Section4SmallPairs.lean:45--65`). Here y is the quartic variable, the square
root of the corresponding square sequence value, not the sequence value.

The archive proves the 63-pair enumeration, verifies the listed solutions,
and checks completeness for `1 <= y <= 109`. It also proves equivalence
between the unrestricted solution-list assertion and this height assertion.
Those finite proofs do not prove the unrestricted assertion. The latter
remains precisely the named Magma completeness premise.

The actual route is `section46_lists_complete` to
`section46_noninitial_unique`, then `Parameters.section46_pair_square_unique`
and `section46_small_square_unique`; `section46_small_published` combines this
with the separate Akhtari norm -1 branch. JNT's final assembly uses these
results directly and through `proposition41_published` and the Section 5
lemmas. The public Theorem 1.4 therefore requires this premise as well.

Status: explicit unproved global computational-completeness input. It is
specific to JNT Section 4.6, not an approval or certificate for the current
paper's separate Section 5.6 calculations for b=5,13,17.

## Bridges still to implement, not new external assumptions

The opening square-factor normalization and its sequence/square-value
transport remain to be formalised. This must include integer-square
preservation in both directions, the scaled norm, squarefree gcd, preservation
of admissibility, and the unchanged index cutoff under positive square
scaling. It must also preserve any standing smallest-square convention needed
by downstream local theorems. This audit has not certified that normalization
proof or the remainder of Section 5.

Once authorized, the small-b wrapper can reuse local Lemma 3.6 and the pinned
JNT theorem plus the elementary finite-set counting bridge above. The
normalized b=2,3,4 contradictions and the three-to-two tail bridge have been
checked mathematically here, but no new Lean proofs of these bridges were
added during this inspection-only checkpoint.

## Verification and limits

`run-small-b-premises.py` verifies the exact original 06f TeX/PDF hashes,
the pinned dependency archive and extracted/native Lake copies, lockfiles,
dependency revisions, and effective Lean/Lake search paths before and after
the inspection. It runs `small-b-premises.lean` against the existing compiled
development, recording the actual theorem types, direct dependencies and
axiom sets in `small-b-premises-declarations.json` and the full printed inputs
in `small-b-premises.log`. The six inspected declarations have only the
standard `propext`, `Classical.choice`, and `Quot.sound` axioms (or subsets).
This does not discharge their explicit mathematical parameters.

`small-b-premises-verification.json` records the check result and hashes.
All existing proof sources, target statements and dependency pins remain
unchanged. No new external premise is assumed, no manuscript is edited, and
no full Section 5 proof or new full-project rebuild is claimed.
