RESOLVED: the author supplied 06g with the proposed power wording.
The original pending report below is retained as history.

# Section 5.4: pending root-versus-power wording correction

Status: awaiting the user's response; no mathematical correction integrated.
Date: 2026-11-07.

The exact 06f TeX is the authority, SHA256
`82eff8993df2763db46e1c59e8e2933a5cecb77c7c1b46d44a5b9eadf98bfc02`.
The location is Section 5.4, TeX lines 1604--1605, between the display at
1599--1601 and the display at 1607--1608 (before `eq:dLB3-step-iv`).

## Original wording

> Moving the factor of $d$ to the left-hand side and taking the
> $\left( 3r_{0}-2 \right)/ \left( 2 \left( r_{0}-1 \right) \right)$-th
> root of both sides, this becomes

## Algebraic check

Write r for r_0 and M for |g| N_(d',4). The preceding display has the form

    d > C * d^(r/(3r-2)),

where

    C = (264^2/M^4)^((r-1)/(3r-2))
        * b^(8r/(3r-2)) * 5.233^(1/(3r-2))
        / u^(8(r-1)/(3r-2)).

All bases are positive and r >= 2. Dividing by the indicated power of d gives

    d^(2(r-1)/(3r-2)) > C.

To obtain a first power of d, raise both sides to
`p=(3r-2)/(2(r-1))`. The resulting right side is exactly

    264 * b^(4+4/(r-1)) * 5.233^(1/(2(r-1))) / (u^4 * M^2),

which agrees with the manuscript's following display at lines 1607--1608.
The exponent identities are:

    [2(r-1)/(3r-2)] * p = 1,
    [(r-1)/(3r-2)] * p = 1/2,
    [8r/(3r-2)] * p = 4 + 4/(r-1),
    [1/(3r-2)] * p = 1/(2(r-1)),
    [8(r-1)/(3r-2)] * p = 4.

Taking a p-th root instead multiplies exponents by 1/p. For example, at
r=2 the intermediate inequality is `sqrt(d) > C`; obtaining `d > C^2`
requires squaring, whereas taking a square root gives `d^(1/4) > sqrt(C)`.

## Proposed correction and consequences

Replace "taking the ...-th root of both sides" by "raising both sides to
the power ..." with the same displayed fraction.

Equivalently, retain the word "root" and invert the fraction, to
`2(r_0-1)/(3r_0-2)`. The first phrasing is clearer.

No change to the following displayed bound is needed for this local step.
This correction would preserve the intended algebraic argument, rather
than substitute a new proof. It does not by itself certify all later
comparisons or the whole section.

The user has authorised the unproved external and computational premises,
but separately requires a stop on mathematical concerns. Accordingly the
proposed wording correction has not been incorporated in a Lean proof or
in either manuscript attachment. Existing mathematical proof modules and
the verified Section 4 checkpoint remain unchanged. Section 5 and the
complete release are still pending.
