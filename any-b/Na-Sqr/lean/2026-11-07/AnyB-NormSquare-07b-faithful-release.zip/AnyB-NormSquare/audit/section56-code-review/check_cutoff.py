"""Diagnostic only: compare current public Java formulas with the printed range.

This does not certify Java execution, Table 1, or the absence of square terms.
"""
from fractions import Fraction as F
from math import isqrt, sqrt, gcd
from pathlib import Path
import hashlib
import json

a, b, d, t, u = 659, 5, 10205, 101, 1
N = d*b**4-a*a
assert t*t-d*u*u == -4
assert N == 2438**2 and gcd(a,b*b) == 1
assert 101**2 < d < 102**2
y0 = b*b
assert (b*b*(t*t+d*u*u)+2*a*t*u) % 4 == 0
y1 = (b*b*(t*t+d*u*u)+2*a*t*u)//4
trace = (t*t+d*u*u)//2
y2, y3 = trace*y1-y0, trace*(trace*y1-y0)-y1
assert (y1,y2,y3) == (160817,1640815826,16741243711861)
assert all(isqrt(y)**2 != y for y in (y1,y2,y3))

# The public program uses aLB=1 for its common (b,d,t,u) cutoff.
M = d*b**4-1
assert M < 6400000 and M < 2530**2 and b < F(9,4)**2
rem3 = F(653,1000)*2530*b**4*2/d
rem4 = F(5233,1000)*6400000*b**4/d
assert rem3 < 6**3 and rem4 < 1433**2
upper = [F(21,100)*b*b*F(9,4)*6400000*2530/d,
         F(b**3*6400000*2530,10*d),
         F(592,10)*6400000*2530/(4*101)*6,
         F(6532,100)*6400000*2530/(4*101)*1433]
assert max(upper) < 4*10**12 < y3

# One of Proposition 4.1's six terms alone exceeds y3.
# sqrt(d)<102 makes this a strict rational LOWER bound for that term.
paper_lower = F(2643,100)*b*b*N*N/102
assert y3 < paper_lower
approx = [0.21*b*b*sqrt(b)*M*sqrt(M)/d,
          b**3*M*sqrt(M)/(10*d),
          59.2*M*sqrt(M)/(4*sqrt(d))*max(1,(.653*sqrt(M)*b**4*2/d)**(1/3)),
          65.32*M*sqrt(M)/(4*sqrt(d))*max(1,sqrt(5.233*M*b**4/d))]
source = Path(__file__).resolve().parents[2] / 'computation/any-b/Na-Sqr/java/BAllNaSqrSearch.java'
result = {
    'status':'diagnostic passed; clarification required',
    'tuple':dict(a=a,b=b,d=d,t=t,u=u), 'negative_norm_square_root':2438,
    'y1':y1,'y2':y2,'y3':y3,'y3_is_square':False,
    'java_formula_cutoff_approx':max(approx),
    'java_formula_exact_upper_bounds':[str(x) for x in upper],
    'paper_fourth_term_strict_lower_bound':str(paper_lower),
    'paper_fourth_term_lower_bound_approx':float(paper_lower),
    'source_url':'https://raw.githubusercontent.com/PV-314/hypgeom/2dbf585df104582e6fcb7dd1a7357996cf460bd2/any-b/Na-Sqr/java/BAllNaSqrSearch.java',
    'source_access_date':'2026-11-08',
    'source_snapshot_kind':'exact source bytes pinned in computation/github.json',
    'source_snapshot_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
    'scope':'Exact rational comparison of mathematical formulas; not an execution certificate for Java floating-point operations, not a counterexample to square counts.'
}
Path(__file__).with_name('diagnostic.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
