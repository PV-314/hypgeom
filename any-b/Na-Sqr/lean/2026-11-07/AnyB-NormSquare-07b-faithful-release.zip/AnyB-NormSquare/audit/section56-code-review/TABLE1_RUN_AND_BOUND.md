# Table 1 search bound in revision 06g

This historical note describes the 1 October logs. The distributed program is the GitHub file `computation/any-b/Na-Sqr/java/BAllNaSqrSearch.java`. The last c1 and c2 records, and the elapsed times in milliseconds, are:

| b | c1 | c2 | elapsed (ms) |
|---|---:|---:|---:|
| 5 | 242598 | 8 | 633 |
| 13 | 18110693 | 6 | 98535 |
| 17 | 58466661 | 10 | 345608 |

The recorded program used aLB=1 and stopped both searches at the strict cutoff. The Java file now distributed is identified by its Git blob in computation/github.json. The October logs retain their original bytes.

## Mathematical bound used to interpret the search

Write n=|Nα|, M=db⁴−1≥n≥1, G=|g|𝒩_{d′,4}≥2. Let B be the exact real maximum of these four terms, transcribed from the named class.

1. 0.21 b^(5/2) M^(3/2)/d
2. b³ M^(3/2)/(10d)
3. 14.8 M^(3/2)/√d × max(1,(1.306 √M b⁴/d)^(1/3))
4. 16.33 M^(3/2)/√d × max(1,(5.233 M b⁴/d)^(1/2))

On the assumptions of Proposition 4.1, its proof gives at most two distinct squares with the indicated indices and y≥B. Here is the argument in exact real arithmetic.

The third term is at least 14.8 M^(3/2)/√d. This dominates 4n/√d and b²n/d: M≥b⁴ since d≥2, so √(Md)≥b². Thus if the smallest of three distinct squares is ≥B, the prerequisites at 06g line 869 hold.

The bounds at lines 1082 and 1118 are dominated by terms 1 and 2 by comparison of exponents, since b,d,n≥1 and M≥n.

For line 1224 put e=1/(2r₀−1), so 0<e≤1/3. The dependence on G is G^(−2+e), decreasing for G≥2. Substituting G=2 and increasing n to M bounds that expression by 14.8 M^(3/2)/√d times (1.306 √M b⁴/d)^e. For x>0, x^e≤max(1,x^(1/3)). This gives term 3.

For line 1290 put e=1/(2(r₀−1)), so 0<e≤1/2. Substituting G=2 and increasing n to M gives 16.33 M^(3/2)/√d times (5.233 M b⁴/d)^e. Bounding this last power by max(1,(5.233 M b⁴/d)^(1/2)) gives term 4.

Each case forces the smallest square strictly below its case bound. Equality at the exact real B therefore belongs to the analytic range. The mathematical search premise concerns eligible terms with y<B. The class uses floating-point comparisons. As previously agreed, completeness for that exact mathematical range must be explicit in the computational premise. No rounding certificate or new Lean theorem is claimed here.

## Manuscript decision

06g lines 1761–1768 attribute the search to the displayed bound of Proposition 4.1, and line 1784 repeats this reference. A faithful correction would state B and its derivation from the proof, specify the search as y<B and identify each exceptional square by the same search condition. Proposition 4.1 itself can stand. The archived 06g and its Lean checkpoint remain as published in the workspace. This note records the proposed correction for author review.
