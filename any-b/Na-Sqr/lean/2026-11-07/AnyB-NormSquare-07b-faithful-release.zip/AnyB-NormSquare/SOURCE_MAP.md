# Statement correspondence

Generated only from the pinned 2026-11-07b TeX. Numbering includes the two conjectures.
Implementation status is meaningful only with a passing verification.json for the current source hashes.

| Statement | TeX label and lines | Status | Lean declaration(s) |
|---|---|---|---|
| Conjecture 1.1 | `conj:1-seq`, 202–211 | statement only (conjecture) | `AnyBNormSquare.Conjecture11` |
| Conjecture 1.2 | `conj:2-seq`, 223–229 | statement only (conjecture) | `AnyBNormSquare.Conjecture12` |
| Theorem 1.3 | `thm:1.2-seq-new`, 247–255 | implemented; see verification.json for build/audit | `AnyBNormSquare.Section4Proof.theorem13_conditional` |
| Theorem 1.4 | `thm:1.3-seq-new`, 282–296 | implemented; see verification.json for build/audit | `AnyBNormSquare.Section5Proof.theorem14a_conditional`, `AnyBNormSquare.Section5Proof.theorem14b_conditional` |
| Corollary 1.5 | `cor:1.3-seq-new`, 300–314 | implemented; see verification.json for build/audit | `AnyBNormSquare.CorollaryProof.corollary15a_conditional`, `AnyBNormSquare.CorollaryProof.corollary15b_conditional` |
| Corollary 1.6 | `cor:1.4-seq-new`, 320–331 | implemented; see verification.json for build/audit | `AnyBNormSquare.CorollaryProof.corollary16_conditional` |
| Lemma 2.1 | `lem:2.1`, 423–449 | implemented; see verification.json for build/audit | `AnyBNormSquare.lemma21` |
| Lemma 3.1 | `lem:quad-rep`, 572–594 | implemented; see verification.json for build/audit | `AnyBNormSquare.lemma31` |
| Lemma 3.2 | `lem:Y-LB1`, 599–640 | implemented; see verification.json for build/audit | `AnyBNormSquare.lemma32a`, `AnyBNormSquare.lemma32b`, `AnyBNormSquare.lemma32c`, `AnyBNormSquare.lemma32c_uniform` |
| Lemma 3.3 | `lem:gap`, 674–684 | implemented; see verification.json for build/audit | `AnyBNormSquare.lemma33` |
| Lemma 3.4 | `lem:zeta`, 703–720 | implemented; see verification.json for build/audit | `AnyBNormSquare.lemma34` |
| Lemma 3.5 | `lem:gNd4`, 736–751 | implemented; see verification.json for build/audit | `AnyBNormSquare.lemma35`, `AnyBNormSquare.lemma35_normalizer` |
| Lemma 3.6 | `lem:admissible-b`, 789–794 | implemented; see verification.json for build/audit | `AnyBNormSquare.lemma36`, `AnyBNormSquare.lemma36_of_solution` |
| Proposition 4.1 | `prop:1.2-seq-new`, 1342–1357 | implemented; see verification.json for build/audit | `AnyBNormSquare.Section4Proof.proposition41_conditional` |
