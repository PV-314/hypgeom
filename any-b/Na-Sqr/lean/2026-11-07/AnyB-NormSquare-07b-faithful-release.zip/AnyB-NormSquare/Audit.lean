import AnyBNormSquare
import Lean

open Lean Elab Command

-- Audit generated declarations as well as the public lemmas.
run_cmd do
  let env ← getEnv
  let mut rows : Array Json := #[]
  for (n, ci) in env.constants.toList do
    let some idx := env.getModuleIdxFor? n | continue
    let mod := env.header.moduleNames[idx.toNat]!
    unless mod.toString.startsWith "AnyBNormSquare" do continue
    let axs ← collectAxioms n
    rows := rows.push <| Json.mkObj [
      ("name", toJson n.toString), ("module", toJson mod.toString),
      ("theorem", toJson ci.isTheorem),
      ("deps", toJson (ci.getUsedConstantsAsSet.toList.map Name.toString)),
      ("axioms", toJson (axs.toList.map Name.toString))]
  liftIO <| IO.FS.writeFile "audit/environment.json" (Json.pretty (toJson rows))
  logInfo m!"Audited {rows.size} local compiled declarations"

#print axioms AnyBNormSquare.lemma21
#print axioms AnyBNormSquare.lemma31
#print axioms AnyBNormSquare.lemma32a
#print axioms AnyBNormSquare.sharp_rate_le_trace
#print axioms AnyBNormSquare.lemma32b
#print axioms AnyBNormSquare.lemma32c
#print axioms AnyBNormSquare.lemma32c_uniform
#print axioms AnyBNormSquare.integerSquare_isSquare
#print axioms AnyBNormSquare.lemma33
#print axioms AnyBNormSquare.lemma34

#check AnyBNormSquare.lemma21
#check AnyBNormSquare.lemma31
#check AnyBNormSquare.lemma32a
#check AnyBNormSquare.lemma32b
#check AnyBNormSquare.lemma32c
#check AnyBNormSquare.lemma32c_uniform
#check AnyBNormSquare.lemma33
#check AnyBNormSquare.lemma34
#print AnyBNormSquare.Theorem13
#print AnyBNormSquare.Proposition41
#print AnyBNormSquare.Theorem14a
#print AnyBNormSquare.Theorem14b
#print AnyBNormSquare.Corollary15a
#print AnyBNormSquare.Corollary15b

-- Lemma 3.5 and the explicit bridges to the paper's definitions.
#print axioms AnyBNormSquare.lemma35
#print axioms AnyBNormSquare.lemma35_normalizer
#print axioms AnyBNormSquare.lemma35_u2_eq_paper
#print axioms AnyBNormSquare.Lemma35Proof.N4_eq_paper
#check AnyBNormSquare.lemma35
#check AnyBNormSquare.lemma35_normalizer
#check AnyBNormSquare.lemma35_u2_eq_paper
#check AnyBNormSquare.Lemma35Proof.N4_eq_paper
#print AnyBNormSquare.unitPowerNorm

-- Lemma 3.6: factorisation, both cases for 2, and the kernel-checked residue table.
#print axioms AnyBNormSquare.lemma36
#print axioms AnyBNormSquare.lemma36_of_solution
#print axioms AnyBNormSquare.Lemma36Proof.square_residues16
#print axioms AnyBNormSquare.Lemma36Proof.sum_square_residues16
#check AnyBNormSquare.lemma36
#check AnyBNormSquare.lemma36_of_solution
#check AnyBNormSquare.Lemma36Proof.sum_prime_factorization
#check AnyBNormSquare.Lemma36Proof.two_small_case
#check AnyBNormSquare.Lemma36Proof.four_dvd_coordinates_of_sum16

-- Author-approved 06e revision: inspect explicit domain and unresolved premise.
#check AnyBNormSquare.section21_error_identity
#check AnyBNormSquare.section21_corrected_error_identity
#print AnyBNormSquare.paperK0
#check AnyBNormSquare.paperK0_justified
#check AnyBNormSquare.section21_q_bound_conditional
#check AnyBNormSquare.section41_near_one
#print axioms AnyBNormSquare.section21_error_identity
#print axioms AnyBNormSquare.section21_corrected_error_identity
#print axioms AnyBNormSquare.section21_q_bound_conditional
#print axioms AnyBNormSquare.section41_near_one

-- Section 2.1 construction checkpoint.
#check AnyBNormSquare.Construction.X_formula
#check AnyBNormSquare.Construction.Y_formula
#check AnyBNormSquare.Construction.remainder_formula
#check AnyBNormSquare.Construction.denominator_least
#check AnyBNormSquare.Construction.content_greatest
#check AnyBNormSquare.Construction.conjugate_U
#check AnyBNormSquare.Construction.A_formula
#check AnyBNormSquare.Construction.raw_formulas
#check AnyBNormSquare.Construction.dPrime_formula
#check AnyBNormSquare.Construction.scale_formula
#check AnyBNormSquare.Construction.QE_formulas
#check AnyBNormSquare.Construction.ell_formula
#check AnyBNormSquare.Construction.principal_branch
#check AnyBNormSquare.Construction.gaussian_cases
#check AnyBNormSquare.Construction.phase_formula
#check AnyBNormSquare.Construction.corrected_formulas
#check AnyBNormSquare.Construction.norms_preserved
#check AnyBNormSquare.Construction.integral_pair
#check AnyBNormSquare.Construction.independent
#check AnyBNormSquare.Construction.error_bound_conditional
#check AnyBNormSquare.Construction.approximants_conditional
#check AnyBNormSquare.Construction.apply_lemma21
#check AnyBNormSquare.Construction.lemma21_conditional
#print «JNT-2024».Section2.PaperApproximants
#print axioms AnyBNormSquare.Construction.integral_pair
#print axioms AnyBNormSquare.Construction.independent
#print axioms AnyBNormSquare.Construction.approximants_conditional
#print axioms AnyBNormSquare.Construction.lemma21_conditional

-- Author-approved 06f correction: weak first step, strict final consequence.
#check AnyBNormSquare.Revision06f.Q_lower_chain
#check AnyBNormSquare.Revision06f.gaussian_Q_lower_chain
#check AnyBNormSquare.Revision06f.gaussian_Q_gt
#print axioms AnyBNormSquare.Revision06f.gaussian_Q_gt

-- Section 4.1: inspect derived estimates, actual comparison pair and conditional endpoint.
#check AnyBNormSquare.Prerequisites.scale_le_sqrt_abs
#check AnyBNormSquare.Prerequisites.gaussian_g_upper
#check AnyBNormSquare.Prerequisites.gaussian_scale_upper
#check AnyBNormSquare.Prerequisites.gaussian_normalizer_bounds
#check AnyBNormSquare.Prerequisites.coordinate_bounds
#check AnyBNormSquare.Prerequisites.parameter_bounds
#check AnyBNormSquare.Prerequisites.sequence_coordinates
#check AnyBNormSquare.Prerequisites.sequence_Q_chain
#check AnyBNormSquare.Prerequisites.sequence_certificate
#check AnyBNormSquare.Prerequisites.comparison_identity
#check AnyBNormSquare.Prerequisites.comparison_pair
#check AnyBNormSquare.Prerequisites.threshold_implies_coordinate_size
#check AnyBNormSquare.Prerequisites.application_parameters
#check AnyBNormSquare.Prerequisites.prepare
#check AnyBNormSquare.Prerequisites.apply_prepared
#print axioms AnyBNormSquare.Prerequisites.sequence_certificate
#print axioms AnyBNormSquare.Prerequisites.comparison_identity
#print axioms AnyBNormSquare.Prerequisites.comparison_pair
#print axioms AnyBNormSquare.Prerequisites.application_parameters
#print axioms AnyBNormSquare.Prerequisites.prepare
#print axioms AnyBNormSquare.Prerequisites.apply_prepared

#check AnyBNormSquare.Prerequisites.prepare_and_apply
#print axioms AnyBNormSquare.Prerequisites.prepare_and_apply

#print AnyBNormSquare.Prerequisites.Prepared

-- Section 4.2: exact constants, printed proof order and explicit unproved denominator premise.
#print AnyBNormSquare.Case42.index
#check AnyBNormSquare.Case42.numerical_constants
#check AnyBNormSquare.Case42.error_factor
#check AnyBNormSquare.Case42.substitute_Q
#check AnyBNormSquare.Case42.before_fourth
#check AnyBNormSquare.Case42.fourth_power
#check AnyBNormSquare.Case42.expanded_bound
#check AnyBNormSquare.Case42.at_one
#check AnyBNormSquare.Case42.eliminate_f
#check AnyBNormSquare.Case42.gap_twice
#check AnyBNormSquare.Case42.cancel_fifth
#check AnyBNormSquare.Case42.root_bound
#check AnyBNormSquare.Case42.norm_fourth
#check AnyBNormSquare.Case42.error_chain
#check AnyBNormSquare.Case42.general_bound
#check AnyBNormSquare.Case42.first_case_upper
#check AnyBNormSquare.Case42.sequence_gaps
#check AnyBNormSquare.Case42.first_case
#check AnyBNormSquare.Case42.first_case_conditional
#print axioms AnyBNormSquare.Case42.general_bound
#print axioms AnyBNormSquare.Case42.sequence_gaps
#print axioms AnyBNormSquare.Case42.first_case
#print axioms AnyBNormSquare.Case42.first_case_conditional

-- Sections 4.3--4.6: printed bounds, four cases, value counting and conditional endpoints.
#check AnyBNormSquare.Case43.imaginary_ne
#check AnyBNormSquare.Case43.comparison_upper
#check AnyBNormSquare.Case43.chord_half
#check AnyBNormSquare.Case43.general_bound
#check AnyBNormSquare.Case43.at_one
#check AnyBNormSquare.Case43.sixth_power
#check AnyBNormSquare.Case43.root_bound
#check AnyBNormSquare.Case43.second_case
#check AnyBNormSquare.HigherIndex.cutoff_chain
#check AnyBNormSquare.HigherIndex.coordinate_lower
#check AnyBNormSquare.HigherIndex.factor_lower
#check AnyBNormSquare.HigherIndex.fourth_power
#check AnyBNormSquare.HigherIndex.sequence_lower
#check AnyBNormSquare.Case44.cutoff_choice
#check AnyBNormSquare.Case44.rounding_constants
#check AnyBNormSquare.Case44.combine
#check AnyBNormSquare.Case44.normalized
#check AnyBNormSquare.Case44.normalized_with_b
#check AnyBNormSquare.Case44.root_bound
#check AnyBNormSquare.Case44.simplify_bound
#check AnyBNormSquare.Case45.rounding_constants
#check AnyBNormSquare.Case45.remove_sqrt
#check AnyBNormSquare.Case45.normalized
#check AnyBNormSquare.Case45.eliminate_f
#check AnyBNormSquare.Case45.root_bound
#check AnyBNormSquare.Case45.simplify_bound
#check AnyBNormSquare.Section4Proof.integer_bounds
#check AnyBNormSquare.Section4Proof.third_case
#check AnyBNormSquare.Section4Proof.fourth_case
#check AnyBNormSquare.Section4Proof.no_three
#check AnyBNormSquare.Section4Proof.count_from_no_three
#check AnyBNormSquare.Section4Proof.proposition41_conditional
#check AnyBNormSquare.Section4Proof.monomial_le_large
#check AnyBNormSquare.Section4Proof.precise_le_large
#check AnyBNormSquare.Section4Proof.theorem13_conditional
#print axioms AnyBNormSquare.Case43.general_bound
#print axioms AnyBNormSquare.HigherIndex.sequence_lower
#print axioms AnyBNormSquare.Section4Proof.third_case
#print axioms AnyBNormSquare.Section4Proof.fourth_case
#print axioms AnyBNormSquare.Section4Proof.no_three
#print axioms AnyBNormSquare.Section4Proof.proposition41_conditional
#print axioms AnyBNormSquare.Section4Proof.theorem13_conditional

-- Author-corrected 06g power step.
#check AnyBNormSquare.Revision06g.power_step
#check AnyBNormSquare.Revision06g.exponent_identities
#print axioms AnyBNormSquare.Revision06g.power_step

#check AnyBNormSquare.SquareScaling.normalized_parameters
#print axioms AnyBNormSquare.SquareScaling.normalized_parameters

#check AnyBNormSquare.SquareScaling.norm_hypotheses
#print axioms AnyBNormSquare.SquareScaling.norm_hypotheses

#check AnyBNormSquare.SquareScaling.count_transport
#print axioms AnyBNormSquare.SquareScaling.count_transport

#check AnyBNormSquare.Section5Opening.small_b_one
#print axioms AnyBNormSquare.Section5Opening.small_b_one

#check AnyBNormSquare.Section5Opening.two_step_lower
#print axioms AnyBNormSquare.Section5Opening.two_step_lower

#check AnyBNormSquare.Section5Low.case_one
#print axioms AnyBNormSquare.Section5Low.case_one

#check AnyBNormSquare.Section5Low.case_two
#print axioms AnyBNormSquare.Section5Low.case_two

#check AnyBNormSquare.Section5Low.case_one_norm_free
#print axioms AnyBNormSquare.Section5Low.case_one_norm_free

#check AnyBNormSquare.Section5Low.case_two_norm_free
#print axioms AnyBNormSquare.Section5Low.case_two_norm_free

#check AnyBNormSquare.Section56Records.recorded_counts
#print axioms AnyBNormSquare.Section56Records.recorded_counts

#check AnyBNormSquare.Section56Records.recorded_points
#print axioms AnyBNormSquare.Section56Records.recorded_points

#check AnyBNormSquare.Section5Cases.four_bounds
#print axioms AnyBNormSquare.Section5Cases.four_bounds

#check AnyBNormSquare.Section5High.third_rearrange
#print axioms AnyBNormSquare.Section5High.third_rearrange

#check AnyBNormSquare.Section5High.third_simplify
#print axioms AnyBNormSquare.Section5High.third_simplify

#check AnyBNormSquare.Section5High.third_norm_free
#print axioms AnyBNormSquare.Section5High.third_norm_free

#check AnyBNormSquare.Section5Fourth.fourth_rearrange
#print axioms AnyBNormSquare.Section5Fourth.fourth_rearrange

#check AnyBNormSquare.Section5Fourth.fourth_simplify
#print axioms AnyBNormSquare.Section5Fourth.fourth_simplify

#check AnyBNormSquare.Section5Fourth.fourth_norm_free
#print axioms AnyBNormSquare.Section5Fourth.fourth_norm_free

#check AnyBNormSquare.Section5Checks.fourth_from_simplified
#print axioms AnyBNormSquare.Section5Checks.fourth_from_simplified

#check AnyBNormSquare.Section5Discriminant.count
#print axioms AnyBNormSquare.Section5Discriminant.count

#check AnyBNormSquare.Section56Table.thresholds
#print axioms AnyBNormSquare.Section56Table.thresholds

#check AnyBNormSquare.Section5Checks.recorded_indices
#print axioms AnyBNormSquare.Section5Checks.recorded_indices

#check AnyBNormSquare.Section56Calculations.JavaEnumeration
#print axioms AnyBNormSquare.Section56Calculations.JavaEnumeration

#check AnyBNormSquare.Section56Calculations.JavaSquareSearch
#print axioms AnyBNormSquare.Section56Calculations.JavaSquareSearch

#check AnyBNormSquare.Section56Calculations.ExceptionalQuartics
#print axioms AnyBNormSquare.Section56Calculations.ExceptionalQuartics

#check AnyBNormSquare.Section56Calculations.least_lt_searchBound
#print axioms AnyBNormSquare.Section56Calculations.least_lt_searchBound

#check AnyBNormSquare.Section5Proof.finite_count
#print axioms AnyBNormSquare.Section5Proof.finite_count

#check AnyBNormSquare.Section5Proof.theorem14a_conditional
#print axioms AnyBNormSquare.Section5Proof.theorem14a_conditional

#check AnyBNormSquare.Section5Proof.theorem14b_conditional
#print axioms AnyBNormSquare.Section5Proof.theorem14b_conditional
#print AnyBNormSquare.Section56Calculations.JavaEnumeration
#print AnyBNormSquare.Section56Calculations.JavaSquareSearch
#print AnyBNormSquare.Section56Calculations.ExceptionalQuartics

open AnyBNormSquare «JNT-2024»
#print AnyBNormSquare.Conjecture11
#print AnyBNormSquare.Conjecture12
#print AnyBNormSquare.Corollary16
#print AnyBNormSquare.LeastAdmissibleSquare
#check CorollaryProof.normalized_at_least_square
#print axioms CorollaryProof.normalized_at_least_square
#print axioms CorollaryProof.corollary15a_conditional
#print axioms CorollaryProof.corollary15b_conditional
#print axioms CorollaryProof.corollary16_conditional
example : Hypergeometric.DenominatorEstimate4 → ExternalResults.AkhtariTheorem11 →
    Calculations.Section46Magma → Section56Calculations.JavaEnumeration →
    Section56Calculations.JavaSquareSearch → Section56Calculations.ExceptionalQuartics →
    Corollary15a := CorollaryProof.corollary15a_conditional
example : Hypergeometric.DenominatorEstimate4 → ExternalResults.AkhtariTheorem11 →
    Calculations.Section46Magma → Corollary15b := CorollaryProof.corollary15b_conditional
example : Hypergeometric.DenominatorEstimate4 → ExternalResults.AkhtariTheorem11 →
    Calculations.Section46Magma → Section56Calculations.JavaEnumeration →
    Section56Calculations.JavaSquareSearch → Section56Calculations.ExceptionalQuartics →
    Corollary16 := CorollaryProof.corollary16_conditional

#check AnyBNormSquare.Remarks.three_squares
#print axioms AnyBNormSquare.Remarks.three_squares
#check AnyBNormSquare.Remarks.admissible_b_lt_25
#check «JNT-2024».Examples.repeated_reflection
#check «JNT-2024».Parameters.paper_repeated_value_unit
