# Faithful Lean formalisation of the 07b square-norm manuscript

The source is the supplied `sequence-version-any-b-nrmA-sqr-with-y-result-2026-11-07b.tex` and its matching PDF in `source/`. Import `AnyBNormSquare` to use the results. `SOURCE_MAP.md` gives the source lines and declarations for all 14 numbered statements. The 12 numbered lemmas, theorems, corollaries and proposition have proofs. Conjectures 1.1 and 1.2 are proposition definitions. The two parts of Theorem 1.4 and of Corollary 1.5 have separate proofs.

## Mathematical scope

| Result | Explicit external premises |
|---|---|
| Lemma 2.1 and Lemmas 3.1–3.6 | None |
| Theorem 1.3, Proposition 4.1 and the concrete three-square remark | JNT `DenominatorEstimate4` |
| Theorem 1.4(b) and Corollary 1.5(b) | `DenominatorEstimate4`, `AkhtariTheorem11`, `Section46Magma` |
| Theorem 1.4(a), Corollary 1.5(a) and Corollary 1.6 | The preceding three and `JavaEnumeration`, `JavaSquareSearch`, `ExceptionalQuartics` |

`EXTERNAL_INPUTS.md` describes the exact external propositions. `AnyBNormSquare/Section56Calculations.lean` defines the three specific to Section 5.6. The attached JNT release is a pinned Lake path dependency. The finite certificates check the table bounds, the 24 recorded occurrences, their quartic points and the 18 distinct equations. Exhaustiveness of the searches remains an explicit premise.

`AnyBNormSquare/Reindex.lean` and `AnyBNormSquare/Corollary16.lean` justify the positive starting coordinate and the choice of a least square under negative square norm. The conjectures retain the broader printed hypotheses. In the remark following Theorem 1.3, `Remarks.three_squares` proves the concrete 0.78 estimate. The author identifies lines 278–279 as a suggestion for future work. No formal result or premise uses this suggestion. `CORRECTIONS.md` records the earlier author corrections. The private stylistic edit is outside the pinned sources.

## Reproduce the checks

Use Python 3.9 or newer, Git, and the Lean 4.35.0 toolchain specified in `lean-toolchain`. From the extracted project directory run:

```text
python bootstrap.py
lake exe cache get
python source_map.py
python test_dependencies.py
python check.py
```

The ZIP supplies the exact JNT archive. Lake materialises transitive packages at the git revisions in `lake-manifest.json`; a first build without a local cache requires network access. The optional offline setup accepts source-verified caches:

```text
python bootstrap.py --cache-root <directory-containing-the-pinned-git-packages> --jnt-cache <built-project-with-the-exact-JNT-sources>
python test_dependencies.py --lean-bin <pinned-lean-bin>
python check.py --lean-bin <pinned-lean-bin>
```

The audit verifies both JNT copies against the distributed archive, the effective Lake paths, the compiler, registered proof declarations, their dependencies and their transitive axioms. It checks the dependency state again after building. Run the proof audit with standard Python execution. `verification.json`, `audit/environment.json`, `audit/release-scope.json` and `audit/axioms-and-statements.log` contain the results. Earlier checkpoint reports under `audit/` describe their own dates and scope.

`python package.py --output <new-zip-path>` checks the recorded input hashes, packages the sources and evidence, and verifies the ZIP CRCs and member hashes. The JSON next to the ZIP gives its SHA-256. The internal `PACKAGE-MANIFEST.json` covers each payload file.


To repeat the clean extraction test, run `python verify_release_zip.py <release.zip> <new-directory>` with the adjacent JSON checksum. Its optional cache and toolchain flags match those above. It checks the archive inventory, builds all local modules from their sources, and compares every audited declaration, proof dependency and transitive axiom with the packaged evidence.

The root-level `Construction.lean` is the historical file checked by the preservation test. The imported proof module is `AnyBNormSquare/Construction.lean`.

## Published computational sources

The files under `computation/` are exact Git blobs from PV-314/hypgeom at commit `2dbf585df104582e6fcb7dd1a7357996cf460bd2`. Their original directory layout preserves the PARI/GP relative include. `BAllNaSqrSearch.java` uses the default Java package. `computation/github.json` records the paths and hashes. From its Java directory, compile with `javac BAllNaSqrSearch.java` and run `java BAllNaSqrSearch 5`, substituting 13 or 17 for the other rows.

The October calculation logs retain their original bytes. The August transcript preserves its recorded commands and output with a machine-specific path removed. Older diagnostics describe historical programs. The release audit compares the Lean sources, supplied manuscripts, dependency pins and the entire compiled declaration inventory with the preceding GitHub release. The provenance records use package-relative locations. The rebuild can optionally check external manuscript copies by setting `ANYB_MANUSCRIPT_DIR` to the directory containing them.
