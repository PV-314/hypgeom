"""Source preservation and proof correspondence for the Section 2.1 checkpoint."""
from dependency_guard import ROOT, sha, read_json, write_json, require, verify_sources

SOURCE_STEM = "sequence-version-any-b-nrmA-sqr-with-y-result-2026-11-06e"
SOURCE_HASHES = {".tex": "96dea13429b37116825af1a4679192fb0eca8a89ed1f1afcaa734011685cdb21"}

JNT = "«JNT-2024»."
LOCAL = "AnyBNormSquare.Construction."
ROUTES = {
    "X_formula": [JNT + "Hypergeometric.X_eq_hypergeometric"],
    "Y_formula": [JNT + "Hypergeometric.Y_eq_reciprocal"],
    "remainder_formula": [JNT + "Hypergeometric.remainder_eq_hypergeometric"],
    "denominator_least": [JNT + "Hypergeometric.denominator4_le", JNT + "Hypergeometric.denominator4_dvd_iff"],
    "content_greatest": [JNT + "Hypergeometric.numeratorContent4_dvd_iff"],
    "conjugate_U": [JNT + "Section2.U_add_star", JNT + "Section2.U_sub_star"],
    "A_formula": [LOCAL + "conjugate_U"],
    "raw_formulas": [LOCAL + "A_formula"],
    "dPrime_formula": [JNT + "Section2.delta_sq", JNT + "Section2.dPrimeInteger_complex"],
    "scale_formula": ["AnyBNormSquare.Lemma35Proof.N4_eq_paper"],
    "QE_formulas": [JNT + "Section2.Q", JNT + "Section2.E", JNT + "Approximation.g",
                    JNT + "Approximation.N4", JNT + "Approximation.dPrime"],
    "ell_formula": [JNT + "Section2.ell"],
    "principal_branch": [JNT + "Section2.fourth_root_branch"],
    "gaussian_cases": [JNT + "Section2.g2_gaussian", JNT + "Section2.g3_gaussian"],
    "phase_formula": [JNT + "Section2.correction"],
    "corrected_formulas": [JNT + "Section2.p", JNT + "Section2.q", JNT + "Section2.R"],
    "norms_preserved": [JNT + "Section2.corrected_norms"],
    "integral_pair": [JNT + "Section2.corrected_gaussian_integers"],
    "independent": [JNT + "Section2.corrected_determinant_ne"],
    "error_bound_conditional": [JNT + "Section2.corrected_error_bound"],
    "approximants_conditional": [JNT + "Section2.section2_constructions"],
    "apply_lemma21": [JNT + "Section2.PaperApproximants.apply_lemma21"],
    "lemma21_conditional": [LOCAL + "approximants_conditional", LOCAL + "apply_lemma21"],
}
CONDITIONAL = {"error_bound_conditional", "approximants_conditional", "lemma21_conditional"}


def audit_construction(rows=None):
    verify_sources(ROOT)
    baseline = read_json(ROOT / "audit/construction-baseline.json")
    for name, digest in baseline["files"].items():
        if name not in baseline["authorised_existing_lean_edits"]:
            require(sha(ROOT / ("source/provenance06e.json" if name == "source/provenance.json" else name)) == digest, "Changed preserved input: " + name)
    require((ROOT / "AnyBNormSquare.lean").read_text(encoding="utf-8") ==
            baseline["old_import"] + "\npublic import AnyBNormSquare.Construction\n\npublic import AnyBNormSquare.Revision06f\n\npublic import AnyBNormSquare.Prerequisites\n\npublic import AnyBNormSquare.Case42\n\npublic import AnyBNormSquare.Case43\n\npublic import AnyBNormSquare.HigherIndex\n\npublic import AnyBNormSquare.Case44\n\npublic import AnyBNormSquare.Case45\n\npublic import AnyBNormSquare.Section4\n\npublic import AnyBNormSquare.Revision06g\n\npublic import AnyBNormSquare.Section5Work\n\npublic import AnyBNormSquare.Remarks\n", "Unexpected import edit")
    require((ROOT / "Audit.lean").read_text(encoding="utf-8").startswith(baseline["old_audit"]), "Earlier audit commands changed")
    arc = ROOT.parent / "output" / baseline["previous_checkpoint"]
    if arc.exists():
        require(sha(arc) == baseline["previous_checkpoint_sha256"], "Previous ZIP changed")
    if rows is not None:
        by_name = {r["name"]: r for r in rows}
        for name, deps in ROUTES.items():
            row = by_name[LOCAL + name]
            require(row["theorem"], "Expected proved theorem: " + name)
            for dep in deps:
                require(dep in row["deps"], "Missing construction dependency: " + name + " -> " + dep)
            has_prior = JNT + "Hypergeometric.DenominatorEstimate4" in row["deps"]
            require(has_prior == (name in CONDITIONAL), "Unexpected denominator premise status: " + name)
    steps = [
        (454, 460, "U, conjugation and principal fourth-root branch", ["conjugate_U", "principal_branch"]),
        (462, 476, "Terminating X, reciprocal Y and hypergeometric remainder on the stated domain", ["X_formula", "Y_formula", "remainder_formula"]),
        (478, 489, "Least denominator, greatest integral-coordinate content and n=4 real-power scale", ["denominator_least", "content_greatest", "scale_formula"]),
        (491, 504, "g1,g2,g3,g imported unchanged from ApproximationGcd; Gaussian cases", ["gaussian_cases"]),
        (506, 524, "Common scalar, raw approximants and d-prime; existing 06e error identity reused", ["A_formula", "raw_formulas", "dPrime_formula"]),
        (529, 542, "Exact odd-index Gaussian factor, integrality in Q(i), preserved norms and determinant", ["phase_formula", "corrected_formulas", "integral_pair", "norms_preserved", "independent"]),
        (544, 559, "Literal Q,E,ell formulas and k0=1.257; analytic bounds conditional", ["QE_formulas", "ell_formula", "error_bound_conditional", "approximants_conditional"]),
        (423, 449, "Apply both parts of Lemma 2.1, retaining E,Q>1, integral comparison pair not both zero and exact/nonexact distinction", ["apply_lemma21", "lemma21_conditional"]),
    ]
    report = dict(status="passed" if rows is not None else "source checks passed; compiled audit pending",
        source="source/" + SOURCE_STEM + ".tex", source_sha256=SOURCE_HASHES[".tex"],
        lean_sha256=sha(ROOT / "AnyBNormSquare/Construction.lean"),
        scope="m=1,n=4 construction and Gaussian t'=-1 assembly, conditionally connected to Lemma 2.1",
        manuscript_complete=False, mathematical_corrections=[], alternative_arguments=[],
        manuscript_unchanged=True, prior_proof_modules_unchanged=True, dependency_pins_unchanged=True,
        denominator_estimate="Unproved; explicit premise of analytic bounds and end-to-end assembly",
        conditional_declarations=sorted(CONDITIONAL),
        data_interface="apply_lemma21 takes PaperApproximants, which includes bounds. lemma21_conditional constructs those data from the explicit denominator premise; no independent existence premise is assumed.",
        remaining="Section 4.1 sequence-specific substitutions and remaining inequalities, E,Q>1 derivations, four cases and main theorems",
        steps=[dict(first_line=a,last_line=b,argument=c,lean=[LOCAL+n for n in ns]) for a,b,c,ns in steps],
        proof_routes_checked=ROUTES if rows is not None else {})
    write_json(ROOT / "audit/construction-faithfulness.json", report)
    return report


if __name__ == "__main__":
    print(audit_construction())
