"""Verify the 07b statement inventory, public results and agreed proof boundaries."""
from dependency_guard import ROOT, SOURCE_STEM, sha, read_json, require, write_json


def audit_release(rows):
    by_name = {row["name"]: row for row in rows}
    local = "AnyBNormSquare."
    source = ROOT / "source" / (SOURCE_STEM + ".tex")
    source_lines = source.read_text(encoding="utf-8").splitlines()
    inventory = read_json(ROOT / "SOURCE_MAP.json")
    require(inventory["sha256"] == sha(source), "Source map names a different manuscript")
    from hashlib import sha256
    statements = inventory["statements"]
    require(len(statements) == 14, "Wrong statement inventory")
    conjectures = {local + "Conjecture11", local + "Conjecture12"}
    found = set()
    for statement in statements:
        text = "\n".join(source_lines[statement["first_line"]-1:statement["last_line"]])
        require(sha256(text.encode()).hexdigest() == statement["statement_sha256"],
                "Incorrect source span: " + statement["number"])
        require(statement["lean"], "Unmapped statement: " + statement["number"])
        for name in statement["lean"]:
            is_conjecture = statement["kind"] == "conjecture"
            require(name in by_name and by_name[name]["theorem"] != is_conjecture,
                    "Incorrect declaration kind: " + name)
            if is_conjecture:
                found.add(name)
    require(found == conjectures, "Conjecture inventory changed")
    for row in rows:
        if row["theorem"]:
            require(conjectures.isdisjoint(row["deps"]), "Theorem depends on a conjecture")
    routes = {
        "CorollaryProof.corollary15a_conditional": ["CorollaryProof.five_of_tail",
                                                    "Section5Proof.theorem14a_conditional"],
        "CorollaryProof.corollary15b_conditional": ["CorollaryProof.five_of_tail",
                                                    "Section5Proof.theorem14b_conditional"],
        "CorollaryProof.corollary16_conditional": ["CorollaryProof.corollary15a_conditional",
                "CorollaryProof.corollary16_of_corollary15a", "Reindex.restart",
                "Reindex.negative_conjugate", "Reindex.general_orbit", "Reindex.general_norm"],
        "CorollaryProof.normalized_at_least_square": ["Reindex.restart", "Reindex.least_square",
                                                    "Reindex.negative_conjugate", "Reindex.translated"],
        "Remarks.three_squares": ["Section4Proof.theorem13_conditional", "lemma33"],
        "Remarks.admissible_b_lt_25": ["AdmissibleB"]
    }
    external = ["«JNT-2024»." + n for n in ("Hypergeometric.DenominatorEstimate4",
            "ExternalResults.AkhtariTheorem11", "Calculations.Section46Magma")]
    external += [local+"Section56Calculations."+n for n in
                 ("JavaEnumeration", "JavaSquareSearch", "ExceptionalQuartics")]
    expected_counts = [6, 3, 6, 0, 1, 0]
    for (name, expected), count in zip(routes.items(), expected_counts):
        seen = set()
        pending = [local + name]
        while pending:
            n = pending.pop()
            if n in seen:
                continue
            seen.add(n)
            if n in by_name:
                pending.extend(by_name[n]["deps"])
        require({local + n for n in expected} <= seen, "Missing printed proof step: " + name)
        require(set(external) & seen == set(external[:count]), "Unexpected premise: " + name)
    report = dict(source=source.name, numbered_statements=len(statements),
        proved_numbered_results=12, unasserted_conjectures=sorted(found),
        proof_routes=routes, agreed_external_propositions=external,
        introduction_normalization="Restart at a least square under negative square norm; the conjectures use their original broader domains.",
        remark_lines_269_276="The concrete three-square estimate with coefficient 0.78 is proved, including both size hypotheses of Lemma 3.3.",
        remark_lines_278_279="Suggested future improvement. Author retains the printed big-O wording. No quantitative assertion or premise.",
        corrections="CORRECTIONS.md", complete_with_agreed_premises=True)
    write_json(ROOT / "audit/release-scope.json", report)
    return report
