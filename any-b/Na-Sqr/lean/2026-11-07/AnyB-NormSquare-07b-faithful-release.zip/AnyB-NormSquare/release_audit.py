"""Verify the 07b statement inventory, public results and agreed proof boundaries."""
from dependency_guard import ROOT, SOURCE_STEM, sha, read_json, require, write_json


def audit_published_inputs(rows):
    import hashlib
    import json
    import re

    baseline_path = ROOT / "audit/github-proof-baseline.json"
    require(sha(baseline_path) == "9a1855c43118e8590ad588a102c4ad62fe310887c8047b9937944a8952437fed",
            "Changed published proof baseline")
    baseline = read_json(baseline_path)
    for name, digest in baseline["unchanged_files"].items():
        require(sha(ROOT/name) == digest, "Published mathematical input differs: " + name)
    canonical = sorted((r["name"], r["module"], r["theorem"], sorted(r["deps"]), sorted(r["axioms"]))
                       for r in rows)
    digest = hashlib.sha256(json.dumps(canonical, separators=(",", ":")).encode()).hexdigest()
    require(digest == baseline["canonical_environment_sha256"], "Published proof environment differs")

    directory = ROOT / "computation"
    pinfile = directory / "github.json"
    require(sha(pinfile) == "f22dce396170f291c14950fa5f24b9bfff4b93ed728133924c8c1fcab27b744c", "Changed computational source pins")
    pins = read_json(pinfile)
    require({p.relative_to(directory).as_posix() for p in directory.rglob("*") if p.is_file()}
            == set(pins["files"]) | {"github.json"}, "Unexpected computational file inventory")
    for name, pin in pins["files"].items():
        path = directory / name
        data = path.read_bytes()
        blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        require(blob == pin["git_blob"] and sha(path) == pin["sha256"], "Changed GitHub file: " + name)
        if path.suffix == ".java":
            require(not re.search(rb"^\s*package\s+", data, re.M), "Expected default Java package")
    require(not any((ROOT/"audit").rglob("*.java")) and not any((ROOT/"audit").rglob("*.gp")),
            "Unexpected duplicate computational source in audit evidence")


def audit_release(rows):
    audit_published_inputs(rows)
    by_name = {row["name"]: row for row in rows}
    local = "AnyBNormSquare."
    source = ROOT / "source" / (SOURCE_STEM + ".tex")
    source_lines = source.read_text(encoding="utf-8").splitlines()
    inventory = read_json(ROOT / "SOURCE_MAP.json")
    require(inventory["sha256"] == sha(source), "Source map names a different manuscript")
    from hashlib import sha256
    statements = inventory["statements"]
    require(len(statements) == 14, "Wrong statement inventory")
    conjectures = {local + "Conjecture11", local + "Conjecture12"}
    found = set()
    for statement in statements:
        text = "\n".join(source_lines[statement["first_line"]-1:statement["last_line"]])
        require(sha256(text.encode()).hexdigest() == statement["statement_sha256"],
                "Incorrect source span: " + statement["number"])
        require(statement["lean"], "Unmapped statement: " + statement["number"])
        for name in statement["lean"]:
            is_conjecture = statement["kind"] == "conjecture"
            require(name in by_name and by_name[name]["theorem"] != is_conjecture,
                    "Incorrect declaration kind: " + name)
            if is_conjecture:
                found.add(name)
    require(found == conjectures, "Conjecture inventory changed")
    for row in rows:
        if row["theorem"]:
            require(conjectures.isdisjoint(row["deps"]), "Theorem depends on a conjecture")
    routes = {
        "CorollaryProof.corollary15a_conditional": ["CorollaryProof.five_of_tail",
                                                    "Section5Proof.theorem14a_conditional"],
        "CorollaryProof.corollary15b_conditional": ["CorollaryProof.five_of_tail",
                                                    "Section5Proof.theorem14b_conditional"],
        "CorollaryProof.corollary16_conditional": ["CorollaryProof.corollary15a_conditional",
                "CorollaryProof.corollary16_of_corollary15a", "Reindex.restart",
                "Reindex.negative_conjugate", "Reindex.general_orbit", "Reindex.general_norm"],
        "CorollaryProof.normalized_at_least_square": ["Reindex.restart", "Reindex.least_square",
                                                    "Reindex.negative_conjugate", "Reindex.translated"],
        "Remarks.three_squares": ["Section4Proof.theorem13_conditional", "lemma33"],
        "Remarks.admissible_b_lt_25": ["AdmissibleB"]
    }
    external = ["«JNT-2024»." + n for n in ("Hypergeometric.DenominatorEstimate4",
            "ExternalResults.AkhtariTheorem11", "Calculations.Section46Magma")]
    external += [local+"Section56Calculations."+n for n in
                 ("JavaEnumeration", "JavaSquareSearch", "ExceptionalQuartics")]
    expected_counts = [6, 3, 6, 0, 1, 0]
    for (name, expected), count in zip(routes.items(), expected_counts):
        seen = set()
        pending = [local + name]
        while pending:
            n = pending.pop()
            if n in seen:
                continue
            seen.add(n)
            if n in by_name:
                pending.extend(by_name[n]["deps"])
        require({local + n for n in expected} <= seen, "Missing printed proof step: " + name)
        require(set(external) & seen == set(external[:count]), "Unexpected premise: " + name)
    report = dict(source=source.name, numbered_statements=len(statements),
        proved_numbered_results=12, unasserted_conjectures=sorted(found),
        proof_routes=routes, agreed_external_propositions=external,
        introduction_normalization="Restart at a least square under negative square norm; the conjectures use their original broader domains.",
        remark_lines_269_276="The concrete three-square estimate with coefficient 0.78 is proved, including both size hypotheses of Lemma 3.3.",
        remark_lines_278_279="Suggested future improvement. Author retains the printed big-O wording. No quantitative assertion or premise.",
        corrections="CORRECTIONS.md", complete_with_agreed_premises=True)
    write_json(ROOT / "audit/release-scope.json", report)
    return report
