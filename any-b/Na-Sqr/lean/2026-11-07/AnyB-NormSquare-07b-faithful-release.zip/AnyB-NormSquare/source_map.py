"""Inventory labelled statements from the exact supplied TeX, with source hashes."""
import hashlib
import re
from bootstrap import ROOT, SOURCE_HASHES, SOURCE_STEM, sha, write_json

IMPLEMENTED = {
    "cor:1.3-seq-new": ["CorollaryProof.corollary15a_conditional", "CorollaryProof.corollary15b_conditional"],
    "cor:1.4-seq-new": ["CorollaryProof.corollary16_conditional"],
    "lem:2.1": ["lemma21"],
    "lem:quad-rep": ["lemma31"],
    "lem:Y-LB1": ["lemma32a", "lemma32b", "lemma32c", "lemma32c_uniform"],
    "lem:gap": ["lemma33"],
    "lem:zeta": ["lemma34"],
    "lem:gNd4": ["lemma35", "lemma35_normalizer"],
    "lem:admissible-b": ["lemma36", "lemma36_of_solution"],
}
IMPLEMENTED.update({
    "thm:1.2-seq-new": ["Section4Proof.theorem13_conditional"],
    "prop:1.2-seq-new": ["Section4Proof.proposition41_conditional"],
    "thm:1.3-seq-new": ["Section5Proof.theorem14a_conditional", "Section5Proof.theorem14b_conditional"],
})

TARGETS = {
    "thm:1.2-seq-new": ["Theorem13"],
    "thm:1.3-seq-new": ["Theorem14a", "Theorem14b"],
    "cor:1.3-seq-new": ["Corollary15a", "Corollary15b"],
    "prop:1.2-seq-new": ["Proposition41"],
}


def main():
    path = ROOT / "source" / (SOURCE_STEM + ".tex")
    assert sha(path) == SOURCE_HASHES[".tex"]
    # Strip TeX comments while preserving the original line numbers.
    source = path.read_text(encoding="utf-8").splitlines()
    lines = [re.split(r"(?<!\\)%", line, maxsplit=1)[0] for line in source]
    section = count = 0
    active = None
    rows = []
    for number, line in enumerate(lines, 1):
        if re.search(r"\\section\{", line):
            section += 1
            count = 0
        match = re.search(r"\\begin\{(theorem|lemma|proposition|corollary|conjecture)\}", line)
        if match:
            assert active is None
            count += 1
            active = dict(kind=match[1], number=f"{section}.{count}", first_line=number)
        if active:
            label = re.search(r"\\label\{([^}]+)\}", line)
            if label:
                if "label" not in active:
                    active["label"] = label[1]
                else:
                    active.setdefault("equation_labels", []).append(label[1])
            if "\\end{" + active["kind"] + "}" in line:
                active["last_line"] = number
                body = "\n".join(source[active["first_line"] - 1:number])
                active["statement_sha256"] = hashlib.sha256(body.encode()).hexdigest()
                key = active["label"]
                if key in IMPLEMENTED:
                    active["status"] = "implemented; see verification.json for build/audit"
                    names = IMPLEMENTED[key]
                elif active["kind"] == "conjecture":
                    active["status"] = "statement only (conjecture)"
                    names = [{"conj:1-seq": "Conjecture11", "conj:2-seq": "Conjecture12"}[key]]
                elif key in TARGETS:
                    active["status"] = "pending proof; Prop target only"
                    names = TARGETS[key]
                else:
                    active["status"] = "conjecture (not asserted)" if active["kind"] == "conjecture" else "pending"
                    names = []
                active["lean"] = ["AnyBNormSquare." + n for n in names]
                rows.append(active)
                active = None
    assert len(rows) == 14, len(rows)
    write_json(ROOT / "SOURCE_MAP.json", dict(source=path.relative_to(ROOT).as_posix(),
        sha256=sha(path), statements=rows))
    text = ["# Statement correspondence", "",
        "Generated only from the pinned 2026-11-07b TeX. Numbering includes the two conjectures.",
        "Implementation status is meaningful only with a passing verification.json for the current source hashes.", "",
        "| Statement | TeX label and lines | Status | Lean declaration(s) |",
        "|---|---|---|---|"]
    for r in rows:
        names = ", ".join("`" + n + "`" for n in r["lean"]) or "—"
        text.append(f"| {r['kind'].title()} {r['number']} | `{r['label']}`, {r['first_line']}–{r['last_line']} | {r['status']} | {names} |")
    (ROOT / "SOURCE_MAP.md").write_text("\n".join(text) + "\n", encoding="utf-8")
    print(f"Mapped {len(rows)} numbered statements from the exact attachment.")


if __name__ == "__main__":
    main()
