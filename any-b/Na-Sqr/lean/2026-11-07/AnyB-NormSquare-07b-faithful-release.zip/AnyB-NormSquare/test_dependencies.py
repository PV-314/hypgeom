"""Regression tests for approved pin enforcement; never mutate live dependencies."""
from pathlib import Path
from contextlib import contextmanager
import argparse
import copy
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import unittest
import dependency_guard as d

LEAN_BIN = None


@contextmanager
def changed_file(path, data):
    previous = path.read_bytes() if path.exists() else None
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    try:
        yield
    finally:
        if previous is None:
            path.unlink()
        else:
            path.write_bytes(previous)


class DependencyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rt = d.runtime(LEAN_BIN)
        cls.live = d.verify_dependencies(d.ROOT, cls.rt)
        cls.members = d.archive_members(d.ROOT / ".dependencies" / (d.RELEASE + ".zip"))
        cls.manifest, cls.lock, cls.packages = d.expected_contract(cls.members)
        cls.overrides = dict(version="1.3.0", packages=[
            d.override_entry(pin, cls.live["effective_package_paths"][name])
            for name, pin in cls.packages.items()])
        cls.allowed_tmp = (d.ROOT / "tmp").resolve()
        cls.allowed_tmp.mkdir(exist_ok=True)
        cls.scratch = Path(tempfile.mkdtemp(prefix="pin-tests-", dir=cls.allowed_tmp)).resolve()
        cls.project = cls.scratch / "project"
        cls.project.mkdir()
        for name in ["bootstrap.py", "dependency_guard.py", "lakefile.toml", "lean-toolchain",
                     "lake-manifest.json", "dependencies.lock.json", "source/provenance.json"]:
            target = cls.project / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes((d.ROOT / name).read_bytes())
        for suffix in d.SOURCE_HASHES:
            name = "source/" + d.SOURCE_STEM + suffix
            (cls.project / name).write_bytes((d.ROOT / name).read_bytes())
        (cls.project / ".dependencies").mkdir()
        name = ".dependencies/" + d.RELEASE + ".zip"
        (cls.project / name).write_bytes((d.ROOT / name).read_bytes())
        cls.run_bootstrap()
        cls.repo = cls.scratch / "git-fixture"
        subprocess.run(["git", "init", "--quiet", str(cls.repo)], check=True)
        subprocess.run(["git", "-C", str(cls.repo), "config", "core.autocrlf", "false"], check=True)
        (cls.repo / "tracked.txt").write_text("original\n")
        subprocess.run(["git", "-C", str(cls.repo), "add", "tracked.txt"], check=True)
        subprocess.run(["git", "-C", str(cls.repo), "-c", "user.name=Dependency Test",
            "-c", "user.email=dependency-test@example.invalid", "commit", "-qm", "fixture"], check=True)
        cls.rev = subprocess.check_output(["git", "-C", str(cls.repo), "rev-parse", "HEAD"], text=True).strip()

    @classmethod
    def tearDownClass(cls):
        # Verify the absolute recursive-delete target remains inside the test workspace.
        target = cls.scratch.resolve()
        d.require(target.is_relative_to(cls.allowed_tmp) and target != cls.allowed_tmp,
                  "Unsafe test cleanup path")
        def remove_readonly(function, filename, error):
            # Git object files can be read-only on Windows; touch only this fixture.
            path = Path(filename).resolve()
            d.require(path.is_relative_to(target), "Unsafe read-only cleanup path")
            if not isinstance(error[1], PermissionError):
                raise error[1]
            path.chmod(path.stat().st_mode | stat.S_IWRITE)
            function(filename)
        shutil.rmtree(target, onerror=remove_readonly)

    @classmethod
    def run_bootstrap(cls, success=True, optimized=False, extra=()):
        command = [sys.executable, "-B", "-X", "utf8"]
        if optimized:
            command.append("-O")
        result = subprocess.run(command + [str(cls.project / "bootstrap.py"), *extra],
            cwd=cls.project, text=True, encoding="utf-8", capture_output=True)
        if success and result.returncode != 0:
            raise AssertionError(result.stdout + result.stderr)
        if not success and result.returncode == 0:
            raise AssertionError("Invalid setup was accepted")
        return result

    def reject_override(self, data):
        with self.assertRaises(d.DependencyError):
            d.validate_overrides(data, self.packages, self.project)

    def reject_pin_in_bootstrap(self, name, value, optimized=False):
        path = self.project / name
        altered = d.json_bytes(value)
        with changed_file(path, altered):
            result = self.run_bootstrap(success=False, optimized=optimized)
            self.assertIn("Changed pin:", result.stderr)
            self.assertEqual(path.read_bytes(), altered, "Bootstrap silently rewrote the pin")

    def test_current_effective_paths(self):
        self.assertEqual(len(self.live["effective_package_paths"]), 10)
        self.assertEqual(self.live["release_files"], 285)

    def test_bootstrap_is_idempotent(self):
        paths = [self.project / n for n in ["lake-manifest.json", "dependencies.lock.json",
                                           "source/provenance.json"]]
        before = {p: (p.read_bytes(), p.stat().st_mtime_ns) for p in paths}
        self.run_bootstrap()
        self.assertEqual(before, {p: (p.read_bytes(), p.stat().st_mtime_ns) for p in paths})

    def test_changed_manifest_is_rejected_without_rewrite(self):
        value = copy.deepcopy(self.manifest)
        value["packages"][1]["rev"] = "0" * 40
        self.reject_pin_in_bootstrap("lake-manifest.json", value)

    def test_changed_lock_is_rejected_without_rewrite(self):
        value = copy.deepcopy(self.lock)
        value["git_revisions"]["mathlib"] = "0" * 40
        self.reject_pin_in_bootstrap("dependencies.lock.json", value)

    def test_rejection_survives_python_optimization(self):
        value = copy.deepcopy(self.lock)
        value["archive_sha256"] = "0" * 64
        self.reject_pin_in_bootstrap("dependencies.lock.json", value, optimized=True)

    def test_coordinated_manifest_and_lock_edit_is_rejected(self):
        manifest, lock = copy.deepcopy(self.manifest), copy.deepcopy(self.lock)
        manifest["packages"][1]["rev"] = "0" * 40
        lock["git_revisions"]["mathlib"] = "0" * 40
        with changed_file(self.project / "lake-manifest.json", d.json_bytes(manifest)):
            self.reject_pin_in_bootstrap("dependencies.lock.json", lock)

    def test_pin_format_drift_is_rejected(self):
        path = self.project / "lake-manifest.json"
        with changed_file(path, json.dumps(self.manifest).encode()):
            self.run_bootstrap(success=False)

    def test_missing_pins_can_be_restored_exactly(self):
        paths = [self.project / n for n in ["lake-manifest.json", "dependencies.lock.json"]]
        expected = [p.read_bytes() for p in paths]
        for p in paths:
            p.unlink()
        self.run_bootstrap()
        self.assertEqual([p.read_bytes() for p in paths], expected)

    def test_jnt_override_is_rejected(self):
        data = copy.deepcopy(self.overrides)
        data["packages"].append(dict(data["packages"][0], name=d.JNT_NAME))
        self.reject_override(data)

    def test_root_override_is_rejected(self):
        data = copy.deepcopy(self.overrides)
        data["packages"].append(dict(data["packages"][0], name="AnyBNormSquare"))
        self.reject_override(data)

    def test_unknown_override_is_rejected(self):
        data = copy.deepcopy(self.overrides)
        data["packages"].append(dict(data["packages"][0], name="unapproved"))
        self.reject_override(data)

    def test_duplicate_override_is_rejected(self):
        data = copy.deepcopy(self.overrides)
        data["packages"].append(copy.deepcopy(data["packages"][0]))
        self.reject_override(data)

    def test_changed_override_config_is_rejected(self):
        data = copy.deepcopy(self.overrides)
        data["packages"][0]["configFile"] = "different.lean"
        self.reject_override(data)

    def test_existing_bad_override_is_not_overwritten_by_cache_option(self):
        data = copy.deepcopy(self.overrides)
        data["packages"].append(dict(data["packages"][0], name=d.JNT_NAME))
        path = self.project / ".lake/package-overrides.json"
        altered = d.json_bytes(data)
        cache_root = str(Path(self.overrides["packages"][0]["dir"]).parent)
        with changed_file(path, altered):
            result = self.run_bootstrap(success=False, extra=["--cache-root", cache_root])
            self.assertIn("Unexpected override", result.stderr)
            self.assertEqual(path.read_bytes(), altered)

    def test_duplicate_json_key_is_rejected(self):
        path = self.scratch / "duplicate.json"
        path.write_text('{"packages": [], "packages": []}')
        with self.assertRaises(d.DependencyError):
            d.read_json(path)

    def test_release_copy_config_change_is_rejected(self):
        path = self.project / ".lake/packages/JNT-2024/lakefile.toml"
        with changed_file(path, path.read_bytes() + b"\n# changed fixture\n"):
            with self.assertRaises(d.DependencyError):
                d.verify_release(path.parent, self.members)

    def test_archive_change_is_rejected(self):
        path = self.scratch / "wrong.zip"
        path.write_bytes(b"not the supplied archive")
        with self.assertRaises(d.DependencyError):
            d.archive_members(path)

    def test_wrong_git_revision_is_rejected(self):
        with self.assertRaises(d.DependencyError):
            d.verify_git(self.repo, dict(name="fixture", rev="0" * 40))

    def test_dirty_tracked_source_is_rejected(self):
        with changed_file(self.repo / "tracked.txt", b"changed\n"):
            with self.assertRaises(d.DependencyError):
                d.verify_git(self.repo, dict(name="fixture", rev=self.rev))

    def test_clean_git_revision_is_accepted(self):
        d.verify_git(self.repo, dict(name="fixture", rev=self.rev))

    def reject_runtime(self, data):
        paths = {n: Path(p) for n, p in self.live["effective_package_paths"].items()}
        with self.assertRaises(d.DependencyError):
            d.validate_lake_paths(data, d.ROOT, paths, self.rt)

    def test_unexpected_effective_binary_root_is_rejected(self):
        data = dict(self.live["lake_environment"])
        data["LEAN_PATH"] += os.pathsep + str(self.scratch / "rogue")
        self.reject_runtime(data)

    def test_redirected_effective_jnt_root_is_rejected(self):
        data = dict(self.live["lake_environment"])
        jnt = Path(self.live["effective_package_paths"][d.JNT_NAME])
        data["LEAN_PATH"] = os.pathsep.join(str(self.scratch / "rogue")
            if d.path_key(p) == d.path_key(jnt / ".lake/build/lib/lean") else p
            for p in data["LEAN_PATH"].split(os.pathsep))
        self.reject_runtime(data)

    def test_unexpected_effective_source_root_is_rejected(self):
        data = dict(self.live["lake_environment"])
        data["LEAN_SRC_PATH"] += os.pathsep + str(self.scratch / "rogue")
        self.reject_runtime(data)

    def test_wrong_effective_compiler_is_rejected(self):
        data = dict(self.live["lake_environment"])
        data["LEAN"] = str(self.scratch / "lean.exe")
        self.reject_runtime(data)

    def test_prior_proofs_manuscript_and_original_pins_unchanged(self):
        baseline = d.read_json(d.ROOT / "audit/section4-baseline.json")
        # This checkpoint adds an import and audit commands. Preserve every
        # earlier proof module and dependency pin; source migration is explicit.
        additions_allowed = set(baseline["authorised_existing_edits"])
        for name, digest in baseline["files"].items():
            if name not in additions_allowed:
                self.assertEqual(d.sha(d.ROOT / ("source/provenance06f.json" if name == "source/provenance.json" else name)), digest, name)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean-bin", type=Path)
    args = parser.parse_args()
    LEAN_BIN = args.lean_bin
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(DependencyTests))
    d.write_json(d.ROOT / "audit/dependency-tests.json", dict(status="passed" if result.wasSuccessful() else "failed",
        tests_run=result.testsRun, failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped)))
    sys.exit(0 if result.wasSuccessful() else 1)
