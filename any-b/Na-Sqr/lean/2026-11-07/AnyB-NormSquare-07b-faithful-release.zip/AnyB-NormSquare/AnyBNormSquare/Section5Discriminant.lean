module

public import AnyBNormSquare.Section5Cases
public import AnyBNormSquare.Section5Size

@[expose] public section
namespace AnyBNormSquare.Section5Discriminant
open «JNT-2024» Section5Size Section5Cases

theorem exclude {b d N u y : ℝ} (hb : 1 ≤ b) (hd : 0 < d) (hN : 1 ≤ N) (hu : 1 ≤ u)
    (hs : N < d*b^4) (hl : (99/400:ℝ)*N*d*u^4/b^2 ≤ y)
    (hh : FourBounds b d N y) (h : normBound b u N < d ∨ finiteBound b u < d) : False := by
  have hb' : 0 < b := by linarith
  have hu' : 0 < u := by linarith
  have hN' : 0 < N := by linarith
  simp only [normBound,finiteBound,max_lt_iff] at h
  rcases hh with h₁ | h₂ | ⟨n,G,hn,hG,h₃⟩ | ⟨n,G,hn,hG,h₄⟩
  · rcases h with h | h
    · exact Section5Low.case_one hb' hd hN' hu' hl h₁ h.1
    · exact Section5Low.case_one_norm_free hb' hd hN' hu' hs hl h₁ h.2.1
  · rcases h with h | h
    · exact Section5Low.case_two hb' hd hN' hu' hl h₂ h.2.1
    · exact Section5Low.case_two_norm_free hb' hd hN' hu' hs hl h₂ h.2.2.1
  · have upper := Section5High.third_rearrange hb' hd hu' hN' hG hn hl h₃
    rcases h with h | h
    · exact (upper.trans (Section5High.third_simplify hn hb hu hN)).asymm h.2.2.1
    · exact (Section5High.third_norm_free hd hn hb hu hN' hs upper).asymm h.2.2.2.1
  · have upper := Section5Fourth.fourth_rearrange hb' hd hu' hN' (by linarith) hn hl h₄
    rcases h with h | h
    · exact (upper.trans (Section5Fourth.fourth_simplify hn hb hu hN hG)).asymm h.2.2.2
    · exact (Section5Fourth.fourth_norm_free hd hn hb hu' hN' hG hs upper).asymm h.2.2.2.2

theorem count (hPrior : Hypergeometric.DenominatorEstimate4)
    (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha))
    (hmin : SmallestInitialSquare P h.pell) (K : ℤ) (hK : P.IsNegativeCutoff h.pell K)
    (hb : 5 ≤ P.b)
    (hbound : normBound P.b P.u |(P.normAlpha : ℝ)| < P.d ∨ finiteBound P.b P.u < P.d) :
    AtMostSquareValuesOn (P.y h.pell) (fun k => 2 ≤ k ∨ k ≤ K-1) 2 := by
  have hi := Section4Proof.integer_bounds P h hn
  have hb' : (0:ℝ) < P.b := by exact_mod_cast h.b_pos
  have hu' : (0:ℝ) < P.u := by exact_mod_cast h.u_pos
  have hd' : (0:ℝ) < P.d := by exact_mod_cast h.d_pos
  have hu : (1:ℝ) ≤ P.u := by exact_mod_cast h.u_pos
  have hN : 0 < |(P.normAlpha : ℝ)| := by linarith [hi.2.1]
  have hcommon : 12*(P.b:ℝ)^2/(P.u:ℝ)^2 < P.d := by
    rcases hbound with h₁ | h₂
    · exact common_of_norm hi.2.1 h₁
    · exact (le_max_left _ _).trans_lt h₂
  obtain ⟨h300,h₁,h₂⟩ := preliminary (by exact_mod_cast hb) hu hcommon
  have hs : |(P.normAlpha:ℝ)| < (P.d:ℝ)*(P.b:ℝ)^4 := by
    rw [abs_of_neg (by exact_mod_cast hn)]
    exact_mod_cast (show -P.normAlpha < P.d*P.b^4 by
      unfold Parameters.normAlpha; nlinarith [sq_pos_of_pos h.a_pos])
  apply Section4Proof.count_from_no_three
  intro i j k hindex _ _ hsi hsj hsk hij hjk
  have lower := Section5Opening.two_step_lower P h hn K hK (by exact_mod_cast h300) hindex
  have hl : (99/400:ℝ)*|(P.normAlpha:ℝ)| * P.d*(P.u:ℝ)^4/(P.b:ℝ)^2 ≤ (P.y h.pell i:ℝ) := by
    have lower' : (99/100:ℝ)*|(P.normAlpha:ℝ)| * P.d*(P.u:ℝ)^4/(4*(P.b:ℝ)^2) ≤ (P.y h.pell i:ℝ) := by
      have hh := Rat.cast_le (K:=ℝ) |>.mpr lower
      push_cast at hh
      exact hh
    convert lower' using 1; ring
  have hh := four_bounds hPrior P h hn hNs hmin K hK (by rcases hindex with h | h <;> omega)
    hsi hsj hsk (by exact_mod_cast hij) (by exact_mod_cast hjk) (large_y hb' hu' hd' hN h₁ h₂ hl)
  exact exclude hi.1 hd' hi.2.1 hu hs hl hh hbound

end AnyBNormSquare.Section5Discriminant
