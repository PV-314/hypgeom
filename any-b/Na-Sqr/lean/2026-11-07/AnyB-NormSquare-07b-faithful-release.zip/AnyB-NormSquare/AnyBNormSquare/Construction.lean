module

public import AnyBNormSquare.Revision06e
public import AnyBNormSquare.Normalizer

@[expose] public section
namespace AnyBNormSquare
open «JNT-2024»
namespace Construction
open Section2 Hypergeometric

/-! Section 2.1 of 06e, at m=1, n=4 and in its Gaussian application.
JNT supplies the actual approximants. Only analytic bounds and their assembly
use DenominatorEstimate4. Every formula bridge retains the printed constants.
-/

theorem X_formula (r : ℕ) (z : ℂ) :
    X (1 / 4) r z = ₂F₁ (-(r : ℂ) - 1 / 4) (-(r : ℂ)) (1 - 1 / 4) z := by
  simpa using X_eq_hypergeometric (1 / 4) r z

theorem Y_formula (r : ℕ) {z : ℂ} (hz : z ≠ 0) :
    Y (1 / 4) r z = z ^ r * X (1 / 4) r z⁻¹ := Y_eq_reciprocal (1 / 4) r hz

theorem remainder_formula (r : ℕ) {z : ℂ} (hz : ‖z - 1‖ < 1) :
    remainder (1 / 4) r z = (z - 1) ^ (2 * r + 1) *
      (remainderPrefactor (1 / 4) r : ℂ) *
      ₂F₁ (r + 1 - (1 / 4 : ℂ)) (r + 1) (2 * r + 2) (1 - z) := by
  simpa using remainder_eq_hypergeometric (1 / 4) r hz

/-- The least positive denominator, coefficientwise. -/
theorem denominator_least (r : ℕ) : 0 < denominator4 r ∧
    (∀ j : ℕ, ∃ a : ℤ, (a : ℚ) = (denominator4 r : ℚ) * coefficient (1 / 4) r j) ∧
    ∀ D : ℕ, 0 < D →
      (∀ j : ℕ, ∃ a : ℤ, (a : ℚ) = (D : ℚ) * coefficient (1 / 4) r j) → denominator4 r ≤ D :=
  ⟨denominator4_pos r, (denominator4_dvd_iff r _).mp dvd_rfl, denominator4_le r⟩

/-- Maximal common content in JNT's coordinates for Z[sqrt(sf(d))]. -/
theorem content_greatest (d : ℤ) (r : ℕ) : 0 < numeratorContent4 d r ∧
    (∀ j : ℕ, (numeratorContent4 d r : ℤ) ∣ scaledIntegralCoefficient4 d r j) ∧
    ∀ n : ℕ, (∀ j : ℕ, (n : ℤ) ∣ scaledIntegralCoefficient4 d r j) → n ≤ numeratorContent4 d r := by
  refine ⟨numeratorContent4_pos d r, (numeratorContent4_dvd_iff d r _).mp dvd_rfl, ?_⟩
  intro n hn
  exact Nat.le_of_dvd (numeratorContent4_pos d r) ((numeratorContent4_dvd_iff d r n).mpr hn)

theorem conjugate_U (S u₁ u₂ : ℤ) :
    star (U S u₁ u₂) = ((u₁ : ℂ) - u₂ * root S) / 2 := by
  have h := U_add_star S u₁ u₂
  have h' := U_sub_star S u₁ u₂
  linear_combination (1 / 2 : ℂ) * h - (1 / 2 : ℂ) * h'

theorem A_formula (S u₁ u₂ : ℤ) :
    A S u₁ u₂ = ((u₁ : ℂ) - u₂ * root S) / (2 * (Approximation.g S u₁ u₂ : ℂ)) := by
  rw [A, conjugate_U, div_div]

/-- The three expressions in (2.3) use the printed common scalar. -/
theorem raw_formulas (S u₁ u₂ : ℤ) (r : ℕ) :
    let c : ℂ := (denominator4 r : ℂ) / numeratorContent4 (Approximation.dPrimeInteger S u₁ u₂) r *
      (((u₁ : ℂ) - u₂ * root S) / (2 * (Approximation.g S u₁ u₂ : ℂ))) ^ r
    rawP S u₁ u₂ r = c * X (1 / 4) r (omega S u₁ u₂) ∧
    rawQ S u₁ u₂ r = c * Y (1 / 4) r (omega S u₁ u₂) ∧
    rawR S u₁ u₂ r = c * remainder (1 / 4) r (omega S u₁ u₂) := by
  simp only [rawP, rawQ, rawR, rawScale, A_formula, and_self]

theorem dPrime_formula {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) :
    (Approximation.dPrimeInteger S u₁ u₂ : ℂ) =
        (U S u₁ u₂ - star (U S u₁ u₂)) ^ 2 / (Approximation.g S u₁ u₂ : ℂ) ^ 2 ∧
    (Approximation.dPrimeInteger S u₁ u₂ : ℂ) =
        (u₂ : ℂ) ^ 2 * S / (Approximation.g S u₁ u₂ : ℂ) ^ 2 := by
  constructor
  · simpa only [delta, div_pow] using (delta_sq hS hu₂).symm
  · exact dPrimeInteger_complex hS hu₂

theorem scale_formula (q : ℚ) :
    Approximation.N4 q = (2 : ℝ) ^ min ((padicValRat 2 q : ℝ) / 2) 3 :=
  Lemma35Proof.N4_eq_paper q

/-- (2.5) and (2.7), with the outer absolute value as printed. -/
theorem QE_formulas (S u₁ u₂ : ℤ) :
    Q S u₁ u₂ = Real.exp (168 / 100) *
      |(|(u₁ : ℝ)| + Real.sqrt ((u₁ : ℝ) ^ 2 - S * (u₂ : ℝ) ^ 2))| /
      (|Approximation.g S u₁ u₂| * Approximation.N4 (Approximation.dPrime S u₁ u₂)) ∧
    E S u₁ u₂ = (|Approximation.g S u₁ u₂| * Approximation.N4 (Approximation.dPrime S u₁ u₂)) *
      |(|(u₁ : ℝ)| + Real.sqrt ((u₁ : ℝ) ^ 2 - S * (u₂ : ℝ) ^ 2))| /
      (Real.exp (168 / 100) * (u₂ : ℝ) ^ 2 * |(S : ℝ)|) := by
  simp only [Q, E, H, Approximation.normalizerProduct,
    abs_of_nonneg (add_nonneg (abs_nonneg _) (Real.sqrt_nonneg _))]
  norm_num

theorem ell_formula (S u₁ u₂ : ℤ) :
    ell S u₁ u₂ = (2685 / 10000 : ℝ) * |(omega S u₁ u₂).arg| := by
  unfold ell
  norm_num

theorem principal_branch {S u₁ u₂ : ℤ} (hS : S < 0) (hu₂ : u₂ ≠ 0) :
    omega S u₁ u₂ ^ (1 / 4 : ℂ) = Complex.exp (Complex.I * ((omega S u₁ u₂).arg : ℂ) / 4) :=
  fourth_root_branch hS hu₂

theorem gaussian_cases (u₁ u₂ : ℤ) :
    Approximation.g2 (-1) u₁ u₂ = 1 ∧
      (Approximation.g3 (-1) u₁ u₂ = 2 ∨ Approximation.g3 (-1) u₁ u₂ = 4) :=
  ⟨g2_gaussian u₁ u₂, g3_gaussian u₁ u₂⟩

theorem phase_formula (u₁ u₂ : ℤ) (r : ℕ) :
    correction u₁ u₂ r = if r % 2 = 1 ∧ Approximation.g3 (-1) u₁ u₂ = 2
      then (1 + Complex.I) / (Real.sqrt 2 : ℂ) else 1 := rfl

theorem corrected_formulas (u₁ u₂ : ℤ) (r : ℕ) :
    p u₁ u₂ r = correction u₁ u₂ r * rawP (-1) u₁ u₂ r ∧
    q u₁ u₂ r = correction u₁ u₂ r * rawQ (-1) u₁ u₂ r ∧
    R u₁ u₂ r = correction u₁ u₂ r * rawR (-1) u₁ u₂ r := ⟨rfl, rfl, rfl⟩

theorem norms_preserved (u₁ u₂ : ℤ) (r : ℕ) :
    ‖p u₁ u₂ r‖ = ‖rawP (-1) u₁ u₂ r‖ ∧ ‖q u₁ u₂ r‖ = ‖rawQ (-1) u₁ u₂ r‖ ∧
      ‖R u₁ u₂ r‖ = ‖rawR (-1) u₁ u₂ r‖ := corrected_norms u₁ u₂ r

/-- Algebraic integrality in the specified field, without a denominator premise. -/
theorem integral_pair {u₁ u₂ : ℤ} (_hU : IsIntegral ℤ (U (-1) u₁ u₂))
    (hu₂ : u₂ ≠ 0) (r : ℕ) :
    ∃ pr qr : GaussianField, IsIntegral ℤ pr ∧ IsIntegral ℤ qr ∧
      gaussianEmbedding pr = p u₁ u₂ r ∧ gaussianEmbedding qr = q u₁ u₂ r :=
  corrected_gaussian_integers hu₂ r

theorem independent {u₁ u₂ : ℤ} (hu₂ : u₂ ≠ 0) (r : ℕ) :
    p u₁ u₂ r * q u₁ u₂ (r + 1) ≠ p u₁ u₂ (r + 1) * q u₁ u₂ r :=
  corrected_determinant_ne hu₂ r

theorem error_bound_conditional (hPrior : DenominatorEstimate4)
    {u₁ u₂ : ℤ} (hu₂ : u₂ ≠ 0) (hnear : ‖omega (-1) u₁ u₂ - 1‖ < 1) (r : ℕ) :
    ‖q u₁ u₂ r * omega (-1) u₁ u₂ ^ (1 / 4 : ℂ) - p u₁ u₂ r‖ ≤
      ell (-1) u₁ u₂ / E (-1) u₁ u₂ ^ r := corrected_error_bound hPrior hu₂ hnear r

/-- Actual approximants with their identities, integrality, bounds and independence. -/
theorem approximants_conditional (hPrior : DenominatorEstimate4)
    {u₁ u₂ : ℤ} (hU : IsIntegral ℤ (U (-1) u₁ u₂)) (hu₂ : u₂ ≠ 0)
    (hnear : ‖omega (-1) u₁ u₂ - 1‖ < 1) : Nonempty (PaperApproximants u₁ u₂) :=
  section2_constructions hPrior hU hu₂ hnear

/-- Lemma 2.1 for the actual construction, with E,Q>1 still explicit. -/
theorem apply_lemma21 {u₁ u₂ : ℤ} (data : PaperApproximants u₁ u₂)
    (hu₂ : u₂ ≠ 0) (p₀ q₀ : GaussianField)
    (hp : IsIntegral ℤ p₀) (hq : IsIntegral ℤ q₀) (hpq : ¬ (p₀ = 0 ∧ q₀ = 0))
    (hE : 1 < E (-1) u₁ u₂) (hQ : 1 < Q (-1) u₁ u₂)
    {c : ℝ} (hc : 0 < c) (hc1 : c < 1) :
    let r := Approximation.firstIndex (Q := Q (-1) u₁ u₂) (ℓ := ell (-1) u₁ u₂)
      hE hc (gaussianEmbedding q₀)
    (1 - c / E (-1) u₁ u₂) / (paperK0 * Q (-1) u₁ u₂ ^ (r + 1)) <
      ‖gaussianEmbedding q₀ * omega (-1) u₁ u₂ ^ (1 / 4 : ℂ) - gaussianEmbedding p₀‖ ∧
    (data.pr r * q₀ - data.qr r * p₀ ≠ 0 →
      (1 - c) / (paperK0 * Q (-1) u₁ u₂ ^ r) <
        ‖gaussianEmbedding q₀ * omega (-1) u₁ u₂ ^ (1 / 4 : ℂ) - gaussianEmbedding p₀‖) := by
  simpa only [data.k₀_eq_1257, paperK0] using
    data.apply_lemma21 hu₂ p₀ q₀ hp hq hpq hE hQ hc hc1

/-- End-to-end conditional assembly: the approximation data are constructed
from JNT, not supplied as an additional external mathematical premise. -/
theorem lemma21_conditional (hPrior : DenominatorEstimate4)
    {u₁ u₂ : ℤ} (hU : IsIntegral ℤ (U (-1) u₁ u₂)) (hu₂ : u₂ ≠ 0)
    (hnear : ‖omega (-1) u₁ u₂ - 1‖ < 1) (p₀ q₀ : GaussianField)
    (hp : IsIntegral ℤ p₀) (hq : IsIntegral ℤ q₀) (hpq : ¬ (p₀ = 0 ∧ q₀ = 0))
    (hE : 1 < E (-1) u₁ u₂) (hQ : 1 < Q (-1) u₁ u₂)
    {c : ℝ} (hc : 0 < c) (hc1 : c < 1) :
    ∃ data : PaperApproximants u₁ u₂,
    let r := Approximation.firstIndex (Q := Q (-1) u₁ u₂) (ℓ := ell (-1) u₁ u₂)
      hE hc (gaussianEmbedding q₀)
    (1 - c / E (-1) u₁ u₂) / (paperK0 * Q (-1) u₁ u₂ ^ (r + 1)) <
      ‖gaussianEmbedding q₀ * omega (-1) u₁ u₂ ^ (1 / 4 : ℂ) - gaussianEmbedding p₀‖ ∧
    (data.pr r * q₀ - data.qr r * p₀ ≠ 0 →
      (1 - c) / (paperK0 * Q (-1) u₁ u₂ ^ r) <
        ‖gaussianEmbedding q₀ * omega (-1) u₁ u₂ ^ (1 / 4 : ℂ) - gaussianEmbedding p₀‖) := by
  obtain ⟨data⟩ := approximants_conditional hPrior hU hu₂ hnear
  exact ⟨data, apply_lemma21 data hu₂ p₀ q₀ hp hq hpq hE hQ hc hc1⟩

end Construction
end AnyBNormSquare
