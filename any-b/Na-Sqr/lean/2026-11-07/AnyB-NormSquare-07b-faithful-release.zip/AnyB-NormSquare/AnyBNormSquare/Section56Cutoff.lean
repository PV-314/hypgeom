module

public import AnyBNormSquare.Section5Cases

@[expose] public section
namespace AnyBNormSquare.Section56Cutoff
open «JNT-2024» Section5Cases

/-- The strict search bound in Section 5.6, using M = d b⁴ - 1,
as in BAllNaSqrSearch.java, getYM1UpperBound. -/
noncomputable def searchBound (b d : ℝ) : ℝ :=
  let M := d*b^4-1
  max ((21/100:ℝ)*b^(5/2:ℝ)*M^(3/2:ℝ)/d)
    (max (b^3*M^(3/2:ℝ)/(10*d))
      (max ((148/10:ℝ)*M^(3/2:ℝ)/Real.sqrt d *
        max 1 ((2*(653/1000:ℝ)*Real.sqrt M*b^4/d)^(1/3:ℝ)))
        ((1633/100:ℝ)*M^(3/2:ℝ)/Real.sqrt d *
          max 1 (((5233/1000:ℝ)*M*b^4/d)^(1/2:ℝ)))))

private theorem power_max {x s t : ℝ} (hx : 0 < x) (hs : 0 ≤ s) (hst : s ≤ t) :
    x^s ≤ max 1 (x^t) := by
  by_cases h : 1 ≤ x
  · exact (Real.rpow_le_rpow_of_exponent_le h hst).trans (le_max_right _ _)
  · exact (Real.rpow_le_one hx.le (le_of_not_ge h) hs).trans (le_max_left _ _)

/-- Extract the r-dependent powers from (4.25) and (4.28). -/
theorem bound_of_cases {b d N y : ℝ} (hb : 1 ≤ b) (hd : 2 ≤ d) (hN : 1 ≤ N)
    (hNM : N ≤ d*b^4-1) (h : FourBounds b d N y) : y < searchBound b d := by
  let M := d*b^4-1
  change N ≤ M at hNM
  have hb0 : 0 < b := by linarith
  have hd0 : 0 < d := by linarith
  have hn0 : 0 < N := by linarith
  have hm0 : 0 < M := by linarith
  have hdm : 1 ≤ d := by linarith
  change y < max _ (max _ (max _ _))
  rcases h with h | h | ⟨n,G,hn,hG,h⟩ | ⟨n,G,hn,hG,h⟩
  · apply h.trans_le
    apply le_trans _ (le_max_left _ _)
    change _ ≤ (21/100:ℝ)*b^(5/2:ℝ)*M^(3/2:ℝ)/d
    have hp : d ≤ d^(12/11:ℝ) := by
      simpa using Real.rpow_le_rpow_of_exponent_le hdm (show (1:ℝ) ≤ 12/11 by norm_num)
    have hnb : N^(13/11:ℝ) ≤ M^(3/2:ℝ) :=
      (Real.rpow_le_rpow_of_exponent_le hN (by norm_num)).trans
        (Real.rpow_le_rpow hn0.le hNM (by norm_num))
    have hbp := Real.rpow_le_rpow_of_exponent_le hb (show (26/11:ℝ) ≤ 5/2 by norm_num)
    have top := mul_le_mul (mul_le_mul_of_nonneg_left hbp (show 0 ≤ (21/100:ℝ) by norm_num)) hnb (by positivity) (by positivity)
    exact (div_le_div_of_nonneg_right top (Real.rpow_nonneg hd0.le _)).trans
      (div_le_div_of_nonneg_left (by positivity) hd0 hp)
  · apply h.trans_le
    apply le_trans _ (le_trans (le_max_left _ _) (le_max_right _ _))
    change _ ≤ b^3*M^(3/2:ℝ)/(10*d)
    have hp : d ≤ d^(7/6:ℝ) := by
      simpa using Real.rpow_le_rpow_of_exponent_le hdm (show (1:ℝ) ≤ 7/6 by norm_num)
    have hnb : N^(7/6:ℝ) ≤ M^(3/2:ℝ) :=
      (Real.rpow_le_rpow_of_exponent_le hN (by norm_num)).trans
        (Real.rpow_le_rpow hn0.le hNM (by norm_num))
    rw [← Real.rpow_natCast b 3]
    gcongr; norm_num
  · apply h.trans_le
    apply le_trans _ ((le_max_left _ _).trans ((le_max_right _ _).trans (le_max_right _ _)))
    have hn0' : 0 < n := by linarith
    have hg0 : 0 < G := by linarith
    have hc := power_max (x:=2*(653/1000:ℝ)*Real.sqrt M*b^4/d)
      (by positivity) (show 0 ≤ 1/n by positivity)
      (show 1/n ≤ 1/3 by apply (div_le_iff₀ hn0').mpr; linarith)
    apply le_trans _ (mul_le_mul_of_nonneg_left hc (show 0 ≤ (148/10:ℝ)*M^(3/2:ℝ)/Real.sqrt d by positivity))
    apply (Real.log_le_log_iff (by positivity) (by positivity)).mp
    have hg := Real.log_le_log (by norm_num : (0:ℝ)<2) hG
    have hm := Real.log_le_log hn0 hNM
    rw [show (592/10:ℝ)=(148/10)*2^2 by norm_num]
    simp (disch := positivity) only [Real.log_mul,Real.log_div,Real.log_pow,Real.log_rpow,Real.log_sqrt] 
    norm_num1
    field_simp (disch := positivity)
    have hgm := mul_le_mul_of_nonneg_left hg (show 0 ≤ 2*n-1 by linarith)
    have hnm := mul_le_mul_of_nonneg_left hm (show 0 ≤ 3*n+1 by linarith)
    linarith only [hgm,hnm]
  · apply h.trans_le
    apply le_trans _ ((le_max_right _ _).trans ((le_max_right _ _).trans (le_max_right _ _)))
    have hn0' : 0 < n := by linarith
    have hg0 : 0 < G := by linarith
    have hc := power_max (x:=(5233/1000:ℝ)*M*b^4/d)
      (by positivity) (show 0 ≤ 1/(2*n) by positivity)
      (show 1/(2*n) ≤ 1/2 by apply (div_le_iff₀ (by positivity)).mpr; linarith)
    apply le_trans _ (mul_le_mul_of_nonneg_left hc (show 0 ≤ (1633/100:ℝ)*M^(3/2:ℝ)/Real.sqrt d by positivity))
    apply (Real.log_le_log_iff (by positivity) (by positivity)).mp
    have hg := Real.log_le_log (by norm_num : (0:ℝ)<2) hG
    have hm := Real.log_le_log hn0 hNM
    rw [show (6532/100:ℝ)=(1633/100)*2^2 by norm_num]
    simp (disch := positivity) only [Real.log_mul,Real.log_div,Real.log_pow,Real.log_rpow,Real.log_sqrt]
    norm_num1
    field_simp (disch := positivity)
    have hgm := mul_le_mul_of_nonneg_left hg (show 0 ≤ 4*n by linarith)
    have hnm := mul_le_mul_of_nonneg_left hm (show 0 ≤ 3*n+1 by linarith)
    linarith only [hgm,hnm]

/-- If the Section 4 size hypotheses fail, the least value is already below
the search bound. This uses the fourth term at M = d b⁴ - 1. -/
theorem size_le {b d N : ℝ} (hb : 1 ≤ b) (hd : 2 ≤ d) (hN : 1 ≤ N)
    (hNM : N ≤ d*b^4-1) : max (4*N/Real.sqrt d) (b^2*N/d) ≤ searchBound b d := by
  let M := d*b^4-1
  change N ≤ M at hNM
  have hb0 : 0 < b := by linarith
  have hd0 : 0 < d := by linarith
  have hM : 1 ≤ M := hN.trans hNM
  have hpow : 1 ≤ b^4 := one_le_pow₀ hb
  have hbm : b^4 ≤ M := by
    dsimp [M]; nlinarith only [mul_nonneg (sub_nonneg.mpr hd) (pow_nonneg hb0.le 4),hpow]
  have hs : b^2 ≤ Real.sqrt M := (Real.le_sqrt (sq_nonneg _) (by linarith)).mpr (by convert hbm using 1; ring)
  have hsd : 1 ≤ Real.sqrt d := by rw [← Real.sqrt_one]; exact Real.sqrt_le_sqrt (by linarith)
  have hs0 : 0 < Real.sqrt d := by positivity
  have hdq := Real.sq_sqrt hd0.le
  have hsdle : Real.sqrt d ≤ d := by nlinarith only [hdq,mul_nonneg hs0.le (sub_nonneg.mpr hsd)]
  have hm : M^(3/2:ℝ) = M*Real.sqrt M := by
    rw [show (3/2:ℝ)=1+(1/2:ℝ) by norm_num,Real.rpow_add (by linarith),Real.rpow_one,Real.sqrt_eq_rpow]
  have hn0 : 0 ≤ N := by linarith
  have hs1 : 1 ≤ Real.sqrt M := by rw [← Real.sqrt_one]; exact Real.sqrt_le_sqrt hM
  have htop : N ≤ M^(3/2:ℝ) := by rw [hm]; exact hNM.trans (le_mul_of_one_le_right (by linarith) hs1)
  have htop' : b^2*N ≤ M^(3/2:ℝ) := by rw [hm,mul_comm M]; exact mul_le_mul hs hNM hn0 (by positivity)
  unfold searchBound
  apply le_trans _ ((le_max_right _ _).trans ((le_max_right _ _).trans (le_max_right _ _)))
  apply le_trans _ (le_mul_of_one_le_right (by positivity : 0 ≤ (1633/100:ℝ)*M^(3/2:ℝ)/Real.sqrt d) (le_max_left 1 _))
  apply max_le
  · apply div_le_div_of_nonneg_right _ hs0.le
    exact mul_le_mul (by norm_num) htop hn0 (by norm_num)
  · apply le_trans (div_le_div_of_nonneg_left (by positivity) hs0 hsdle)
    apply div_le_div_of_nonneg_right _ hs0.le
    exact htop'.trans (le_mul_of_one_le_left (by positivity : 0 ≤ M^(3/2:ℝ)) (by norm_num))

end AnyBNormSquare.Section56Cutoff
