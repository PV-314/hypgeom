module

public import AnyBNormSquare.Corollary15
public import AnyBNormSquare.Reindex

@[expose] public section
namespace AnyBNormSquare
open «JNT-2024»

/-- Both conjectures are propositions quoted from Section 1.2. -/
def Conjecture11 : Prop :=
  ∀ (P : Parameters) (h : P.Admissible),
    AtMostSquareValues (P.y h.pell) 4 ∧
    ((∃ p : ℕ, p.Prime ∧ Odd p ∧ squarefreePart |P.normAlpha| ∣ 2*(p:ℤ)) →
      AtMostSquareValues (P.y h.pell) 3) ∧
    (IsSquare |P.normAlpha| → AtMostSquareValues (P.y h.pell) 2)

def Conjecture12 : Prop :=
  ∀ (P : Parameters) (h : P.Admissible), AtMostSquareValues (P.generalY h.pell) 4 ∧
    ((IsPrimePow P.normAlpha.natAbs ∨ IsSquare |P.normAlpha|) →
      AtMostSquareValues (P.generalY h.pell) 3)

/-- A least square of the specified form occurs in this subsequence. -/
def LeastAdmissibleSquare (y : ℤ → ℚ) : Prop :=
  ∃ (i b : ℤ), 0 < b ∧ AdmissibleB b ∧ y i = (b:ℚ)^2 ∧
    ∀ j, IsIntegerSquare (y j) → (b:ℚ)^2 ≤ y j

def Corollary16 : Prop :=
  ∀ (P : Parameters) (h : P.Admissible), P.normAlpha < 0 → IsSquare (-P.normAlpha) →
    P.epsilonNorm=1 → LeastAdmissibleSquare (fun j => P.generalY h.pell (2*j)) →
    LeastAdmissibleSquare (fun j => P.generalY h.pell (2*j+1)) →
    AtMostSquareValues (P.generalY h.pell) 10

namespace CorollaryProof
open Reindex

/-- Section 1.1. Orient the translated sequence at its least square. -/
theorem normalized_at_least_square (P : Parameters) (h : P.Admissible) (hn : P.normAlpha<0)
    (hs : IsSquare (-P.normAlpha)) :
    ∃ (Q : Parameters) (hq : Q.Admissible) (i : ℤ), Q.normAlpha=P.normAlpha ∧
      SmallestInitialSquare Q hq.pell ∧
      ((∀ j, Q.y hq.pell j=P.y h.pell (i+j)) ∨ (∀ j, Q.y hq.pell j=P.y h.pell (i-j))) := by
  obtain ⟨i,b,hb,hi,hm⟩ := least_square P h hn
  obtain ⟨Q,hq,hbQ,hnQ,he⟩ := restart P h hs (P.term h.pell i) hb hi (P.norm_term h.pell i)
  have ht (k : ℤ) : orbitY P h.pell (P.term h.pell i) k=P.y h.pell (i+k) :=
    translated P h.pell P.alpha i k
  simp only [ht, ← sub_eq_add_neg] at he
  refine ⟨Q,hq,i,hnQ,?_,he⟩
  intro j hj
  rw [hbQ,← hi]
  rcases he with he | he <;> rw [he] at hj ⊢ <;> exact hm _ hj

private theorem parity_count (hc : Corollary15a) (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hs : IsSquare (-P.normAlpha))
    (r : ℤ) (hmin : LeastAdmissibleSquare (fun j => P.generalY h.pell (2*j+r)))
    (hnorm : ∀ i : ℤ, QuadraticAlgebra.norm
      (P.alpha * ((P.epsilonUnit h.pell ^ (2*i+r) : P.Algebraˣ) : P.Algebra)) = (P.normAlpha:ℚ)) :
    AtMostSquareValues (fun j => P.generalY h.pell (2*j+r)) 5 := by
  obtain ⟨i,b,hb,had,hi,hm⟩ := hmin
  let w : P.Algebra := P.alpha * ((P.epsilonUnit h.pell ^ (2*i+r) : P.Algebraˣ) : P.Algebra)
  obtain ⟨Q,hq,hbQ,hnQ,hrel⟩ := restart P h hs w hb hi (hnorm i)
  let y (k : ℤ) := P.generalY h.pell (2*k+r)
  have hshift (j : ℤ) : orbitY P h.pell w j=y (i+j) := by
    unfold w y
    rw [general_orbit]; congr 1; ring
  simp only [hshift] at hrel
  have transfer (e : ℤ → ℤ) (onto : Function.Surjective e)
      (he : ∀ j, Q.y hq.pell j=y (e j)) : AtMostSquareValues y 5 := by
    have hqm : SmallestInitialSquare Q hq.pell := by
      intro j hj
      rw [hbQ,he]
      rw [he] at hj
      exact hm (e j) hj
    obtain ⟨S,hS,hcov⟩ := hc Q hq (by rwa [hnQ]) (by rwa [hnQ]) hqm (hbQ ▸ had)
    refine ⟨S,hS,?_⟩
    intro k hk
    obtain ⟨j,rfl⟩ := onto k
    rw [← he] at hk ⊢
    exact hcov j hk
  rcases hrel with he | he
  · exact transfer (fun j => i+j) (fun k => ⟨k-i,by dsimp; omega⟩) he
  · exact transfer (fun j => i+ -j) (fun k => ⟨i-k,by dsimp; omega⟩) he

theorem corollary16_of_corollary15a (hc : Corollary15a) : Corollary16 := by
  classical
  intro P h hn hs hε hEven hOdd
  have he (i : ℤ) : QuadraticAlgebra.norm
      (P.alpha * ((P.epsilonUnit h.pell ^ (2*i+0) : P.Algebraˣ) : P.Algebra)) = (P.normAlpha:ℚ) := by
    rw [add_zero,zpow_mul,zpow_ofNat,P.epsilonUnit_sq]; exact P.norm_term h.pell i
  obtain ⟨E,hE,coverE⟩ := parity_count hc P h hn hs 0 (by simpa only [add_zero] using hEven) he
  obtain ⟨O,hO,coverO⟩ := parity_count hc P h hn hs 1 hOdd (fun i => general_norm P h.pell hε _)
  refine ⟨E ∪ O,(Finset.card_union_le E O).trans (by omega),?_⟩
  intro k hk
  by_cases hpar : k%2=0
  · have hki : 2*(k/2)+0=k := by omega
    exact Finset.mem_union_left _ (hki ▸ coverE (k/2) (by simpa only [hki] using hk))
  · have hki : 2*(k/2)+1=k := by omega
    exact Finset.mem_union_right _ (hki ▸ coverO (k/2) (by simpa only [hki] using hk))

theorem corollary16_conditional (hPrior : Hypergeometric.DenominatorEstimate4)
    (hAkhtari : ExternalResults.AkhtariTheorem11) (hMagma : Calculations.Section46Magma)
    (hE : Section56Calculations.JavaEnumeration) (hJ : Section56Calculations.JavaSquareSearch)
    (hQ : Section56Calculations.ExceptionalQuartics) : Corollary16 :=
  corollary16_of_corollary15a (corollary15a_conditional hPrior hAkhtari hMagma hE hJ hQ)

end CorollaryProof
end AnyBNormSquare
