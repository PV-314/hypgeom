module

public import AnyBNormSquare.Targets

@[expose] public section
namespace AnyBNormSquare.Section56Records
open «JNT-2024»

/-- Each exceptional Java row supplies a tuple, the index detected, and a
positive square root. The last column is the absolute quartic x-coordinate. -/
structure Hit where
  params : Parameters
  index : ℤ
  root : ℤ
  absX : ℤ
  deriving DecidableEq

def hits : List Hit := [
  ⟨⟨41, 5, 5, 1, 1⟩, (-7), 53, 6281⟩,
  ⟨⟨50, 5, 8, 2, 1⟩, (3), 65, 11950⟩,
  ⟨⟨50, 5, 13, 3, 1⟩, (-3), 85, 26050⟩,
  ⟨⟨100, 5, 32, 6, 1⟩, (-2), 65, 23900⟩,
  ⟨⟨430, 5, 533, 23, 1⟩, (-3), 21845, 11017110430⟩,
  ⟨⟨25, 5, 2, 2, 2⟩, (3), 65, 5975⟩,
  ⟨⟨50, 5, 8, 6, 2⟩, (-2), 65, 11950⟩,
  ⟨⟨25, 5, 2, 6, 4⟩, (-2), 65, 5975⟩,
  ⟨⟨338, 13, 8, 2, 1⟩, (3), 169, 80782⟩,
  ⟨⟨338, 13, 13, 3, 1⟩, (-3), 221, 176098⟩,
  ⟨⟨676, 13, 32, 6, 1⟩, (-2), 169, 161564⟩,
  ⟨⟨169, 13, 2, 2, 2⟩, (3), 169, 40391⟩,
  ⟨⟨338, 13, 8, 6, 2⟩, (-2), 169, 80782⟩,
  ⟨⟨169, 13, 2, 6, 4⟩, (-2), 169, 40391⟩,
  ⟨⟨578, 17, 8, 2, 1⟩, (3), 221, 138142⟩,
  ⟨⟨782, 17, 8, 2, 1⟩, (-4), 85, 20434⟩,
  ⟨⟨578, 17, 13, 3, 1⟩, (-3), 289, 301138⟩,
  ⟨⟨1156, 17, 32, 6, 1⟩, (-2), 221, 276284⟩,
  ⟨⟨6738, 17, 580, 24, 1⟩, (-2), 1241, 37090062⟩,
  ⟨⟨289, 17, 2, 2, 2⟩, (3), 221, 69071⟩,
  ⟨⟨391, 17, 2, 2, 2⟩, (-4), 85, 10217⟩,
  ⟨⟨578, 17, 8, 6, 2⟩, (-2), 221, 138142⟩,
  ⟨⟨3369, 17, 145, 24, 2⟩, (-2), 1241, 18545031⟩,
  ⟨⟨289, 17, 2, 6, 4⟩, (-2), 221, 69071⟩]

def quarticKey (h : Hit) : ℤ × ℤ := (h.params.d, h.params.normAlpha)

def forB (b : ℤ) := hits.filter (fun h => h.params.b == b)

/-- The counts in the two final paragraphs of Section 5.6, on the recorded list. -/
theorem recorded_counts :
    ((forB 5).length, (forB 13).length, (forB 17).length) = (8, 6, 10) ∧
    (((forB 5).map quarticKey).dedup.length, ((forB 13).map quarticKey).dedup.length,
      ((forB 17).map quarticKey).dedup.length) = (6, 4, 8) ∧
    (hits.map quarticKey).dedup.length = 18 := by decide +kernel

/-- For each recorded hit both the seed point and the returned square give
points on the very same quartic. Global completeness is a separate premise. -/
theorem recorded_points : ∀ h ∈ hits,
    h.params.a^2 = h.params.d*h.params.b^4 + h.params.normAlpha ∧
    h.absX^2 = h.params.d*h.root^4 + h.params.normAlpha ∧
    0 < h.root ∧ h.params.b < h.root := by decide +kernel

end AnyBNormSquare.Section56Records
