module

public import AnyBNormSquare.Section56Records
public import AnyBNormSquare.Section5Low

@[expose] public section
namespace AnyBNormSquare.Section5Checks
open «JNT-2024» Section56Records

private def verifyIndex (r : Hit) : Bool :=
  let P := r.params
  if h : P.t^2-P.d*P.u^2=4 ∨ P.t^2-P.d*P.u^2= -4 then
    decide (P.y h r.index=(r.root:ℚ)^2 ∧ |P.x h r.index|=(r.absX:ℚ))
  else false

/-- Each recorded Java index gives the claimed point in that very sequence. -/
theorem recorded_indices : ∀ r ∈ hits, ∀ h : r.params.Pell,
    r.params.y h r.index=(r.root:ℚ)^2 ∧ |r.params.x h r.index|=(r.absX:ℚ) := by
  have allRows : ∀ r ∈ hits, verifyIndex r=true := by decide +kernel
  intro r hr h
  simpa [verifyIndex, show r.params.t^2-r.params.d*r.params.u^2=4 ∨
    r.params.t^2-r.params.d*r.params.u^2= -4 from h] using allRows r hr

/-- The final observation of Section 5.4: applying N < db⁴ after the
simplification gives the weaker sufficient constant 290. -/
theorem fourth_from_simplified {b u d N : ℝ} (hb : 0 < b) (hu : 0 < u) (hd : 0 < d)
    (hN : 0 < N) (hs : N < d*b^4)
    (h : d < (1634/100:ℝ)*b^2*N^(1/2:ℝ)/u^2) : d < 290*b^8/u^4 := by
  have hh := Real.log_lt_log hd h
  have hx := Real.log_lt_log hN hs
  have hc := Real.log_lt_log (by norm_num : 0 < (1634/100:ℝ)^2) (by norm_num : (1634/100:ℝ)^2 < 290)
  apply (Real.log_lt_log_iff hd (by positivity)).mp
  simp (disch := positivity) only [Real.log_mul,Real.log_div,Real.log_pow,Real.log_rpow] at hh hx hc ⊢
  norm_num1 at hh hx hc ⊢
  linarith only [hh,hx,hc]

end AnyBNormSquare.Section5Checks
