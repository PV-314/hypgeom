module

public import AnyBNormSquare.Case44
public import AnyBNormSquare.Case45
public import «JNT-2024».Section5Counting

@[expose] public section
namespace AnyBNormSquare.Section4Proof
open «JNT-2024» Approximation Prerequisites

/-- The integer lower bounds used in the printed exponent comparisons. -/
theorem integer_bounds (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) :
    (1 : ℝ) ≤ P.b ∧ (1 : ℝ) ≤ |(P.normAlpha : ℝ)| ∧ (2 : ℝ) ≤ P.d := by
  have hd : 2 ≤ P.d := by
    have hdpos := h.d_pos
    by_contra hh
    have he : P.d=1 := by omega
    exact h.d_not_square (he ▸ (by norm_num : IsSquare (1 : ℤ)))
  refine ⟨by exact_mod_cast h.b_pos,?_,by exact_mod_cast hd⟩
  rw [abs_of_neg (by exact_mod_cast hn)]
  exact_mod_cast (show (1 : ℤ) ≤ -P.normAlpha by omega)

/-- Section 4.4 for the actual firstIndex and nonexact determinant. -/
theorem third_case (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha)) {i k : ℤ}
    (a : Prepared P h i k)
    (hlarge : 4*|(P.normAlpha : ℝ)|/Real.sqrt P.d ≤ (P.y h.pell i : ℝ))
    (data : Section2.PaperApproximants (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha))
    (hr : 1 < Case42.index a (by norm_num : (0 : ℝ) < 3/4))
    (hne : data.pr (Case42.index a (by norm_num : (0 : ℝ) < 3/4))*a.denominator-
      data.qr (Case42.index a (by norm_num : (0 : ℝ) < 3/4))*a.numerator ≠ 0) :
    (P.y h.pell i : ℝ) < (148/10 : ℝ)*(P.b : ℝ)^(4/3 : ℝ)*
      |(P.normAlpha : ℝ)|^(5/3 : ℝ)/Real.sqrt P.d := by
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hb : (0 : ℝ) < P.b := by exact_mod_cast h.b_pos
  have hN : 0 < |(P.normAlpha : ℝ)| := abs_pos.mpr (by exact_mod_cast ne_of_lt hn)
  have hY : 4*|(P.normAlpha : ℝ)|/Real.sqrt P.d ≤ (a.Y : ℝ) := by
    simpa only [a.hy,Rat.cast_intCast] using hlarge
  have hM2 := (application_parameters P h hn hNs a.hx a.hy hY).2.1
  have hM : 0 < normalizerProduct (-1) (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha) := by linarith
  have hF := mul_pos a.left.f_pos a.right.f_pos
  have hl := HigherIndex.sequence_lower P h hn hNs a hlarge (by norm_num : (0 : ℝ) < 3/4) hr
  have hu := Case42.general_bound P h hn hNs a hlarge data (by norm_num : (0 : ℝ) < 3/4) (by norm_num) hne
  have hc := Case44.combine hN hd a.left.y_pos hF hM hb (by norm_num) (by omega) hl hu
  have hnrm := Case44.normalized hN hd a.left.y_pos hF hM hb (by omega) hc
  have hwith := Case44.normalized_with_b hN hd hF hM hb a.f_product hnrm
  have hroot := Case44.root_bound hN hd a.left.y_pos hM hb (by omega) hwith
  have hbound := integer_bounds P h hn
  have hs := Case44.simplify_bound
    (n := 2*Case42.index a (by norm_num : (0 : ℝ) < 3/4)-1)
    hbound.2.1 hbound.2.2 hM2 hbound.1 (by omega)
  rw [← a.left_certificate.1]
  exact (hroot.trans_le hs.1).trans hs.2

/-- Section 4.5 for the actual firstIndex and exact determinant. -/
theorem fourth_case (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha)) {i k : ℤ}
    (a : Prepared P h i k)
    (hlarge : 4*|(P.normAlpha : ℝ)|/Real.sqrt P.d ≤ (P.y h.pell i : ℝ))
    (data : Section2.PaperApproximants (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha))
    (hr : 1 < Case42.index a (by norm_num : (0 : ℝ) < 3/4))
    (he : data.pr (Case42.index a (by norm_num : (0 : ℝ) < 3/4))*a.denominator-
      data.qr (Case42.index a (by norm_num : (0 : ℝ) < 3/4))*a.numerator = 0) :
    (P.y h.pell i : ℝ) < (2643/100 : ℝ)*(P.b : ℝ)^2*|(P.normAlpha : ℝ)|^2/Real.sqrt P.d := by
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hb : (0 : ℝ) < P.b := by exact_mod_cast h.b_pos
  have hN : 0 < |(P.normAlpha : ℝ)| := abs_pos.mpr (by exact_mod_cast ne_of_lt hn)
  have hY : 4*|(P.normAlpha : ℝ)|/Real.sqrt P.d ≤ (a.Y : ℝ) := by
    simpa only [a.hy,Rat.cast_intCast] using hlarge
  have hM2 := (application_parameters P h hn hNs a.hx a.hy hY).2.1
  have hM : 0 < normalizerProduct (-1) (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha) := by linarith
  have hF := mul_pos a.left.f_pos a.right.f_pos
  have hl := HigherIndex.sequence_lower P h hn hNs a hlarge (by norm_num : (0 : ℝ) < 3/4) hr
  have hu := Case43.general_bound P h hn hNs a data (by omega) he
  have hc := Case45.remove_sqrt hN hd a.left.y_pos hF hM hb (by omega) hl hu
  have hnrm := Case45.normalized hN hd a.left.y_pos hF hM hb (by omega) hc
  have hwith := Case45.eliminate_f hN hd hF hb a.f_product hnrm
  have hroot := Case45.root_bound hN hd a.left.y_pos hM hb (by omega) hwith
  have hbound := integer_bounds P h hn
  have hs := Case45.simplify_bound
    (n := Case42.index a (by norm_num : (0 : ℝ) < 3/4)-1)
    hbound.2.1 hbound.2.2 hM2 hbound.1 (by omega)
  rw [← a.left_certificate.1]
  exact (hroot.trans_le hs.1).trans hs.2

/-- The four printed cases exclude three ordered large square values.
All representations and actual JNT approximants are constructed once, so the
four branches use the same data and least approximation index. -/
theorem no_three (hPrior : Hypergeometric.DenominatorEstimate4)
    (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha))
    (hmin : SmallestInitialSquare P h.pell) (K : ℤ) (hK : P.IsNegativeCutoff h.pell K)
    {i j k : ℤ} (hi : 1 ≤ i ∨ i ≤ K)
    (hsi : IsIntegerSquare (P.y h.pell i)) (hsj : IsIntegerSquare (P.y h.pell j))
    (hsk : IsIntegerSquare (P.y h.pell k))
    (hij : (P.y h.pell i : ℝ) < (P.y h.pell j : ℝ))
    (hjk : (P.y h.pell j : ℝ) < (P.y h.pell k : ℝ))
    (hlarge : preciseSquareThreshold P < (P.y h.pell i : ℝ)) : False := by
  simp only [preciseSquareThreshold,max_lt_iff] at hlarge
  have hsize : max (4*|(P.normAlpha : ℝ)|/Real.sqrt P.d)
      ((P.b : ℝ)^2*|(P.normAlpha : ℝ)|/P.d) ≤ (P.y h.pell i : ℝ) :=
    (max_lt_iff.mpr hlarge.2.2.2.2).le
  obtain ⟨a⟩ := prepare P h hn hNs hmin K hK hi hsi hsk (hij.trans hjk) hsize
  obtain ⟨data,_⟩ := apply_prepared hPrior P h hn hNs a
  let r := Case42.index a (by norm_num : (0 : ℝ) < 3/4)
  have hrpos : 1 ≤ r := (firstIndex_spec a.E_gt_one (by norm_num : (0 : ℝ) < 3/4) _).1
  by_cases hr : r=1
  · by_cases he : data.pr r*a.denominator-data.qr r*a.numerator=0
    · have he1 : data.pr 1*a.denominator-data.qr 1*a.numerator=0 := by rwa [hr] at he
      have hh := Case43.second_case P h hn hNs hmin K hK hi hsi hsj hsk hij hjk hsize a data he1
      exact (not_lt_of_gt hlarge.2.1) hh
    · have hh := Case42.first_case P h hn hNs hmin K hK hi hsi hsj hsk hij hjk hsize a data hr he
      exact (not_lt_of_gt hlarge.1) hh
  · have hr' : 1 < r := by omega
    by_cases he : data.pr r*a.denominator-data.qr r*a.numerator=0
    · have hh := fourth_case P h hn hNs a hlarge.2.2.2.2.1.le data hr' he
      exact (not_lt_of_gt hlarge.2.2.2.1) hh
    · have hh := third_case P h hn hNs a hlarge.2.2.2.2.1.le data hr' he
      exact (not_lt_of_gt hlarge.2.2.1) hh

/-- Convert the paper's ordered-three contradiction to its value-count statement.
This counts distinct rational values, with the integer-square predicate unchanged. -/
theorem count_from_no_three (y : ℤ → ℚ) (indices : ℤ → Prop)
    (hno : ∀ i j k, indices i → indices j → indices k →
      IsIntegerSquare (y i) → IsIntegerSquare (y j) → IsIntegerSquare (y k) →
      y i < y j → y j < y k → False) : AtMostSquareValuesOn y indices 2 := by
  classical
  by_cases hex : ∃ i, indices i ∧ IsIntegerSquare (y i)
  · obtain ⟨i,hi,hsi⟩ := hex
    by_cases hex2 : ∃ j, indices j ∧ IsIntegerSquare (y j) ∧ y j ≠ y i
    · obtain ⟨j,hj,hsj,hji⟩ := hex2
      refine ⟨{y i,y j},Section5.card_pair_le _ _,?_⟩
      intro k hk hsk
      have he : y k=y i ∨ y k=y j := by
        by_contra hn
        push Not at hn
        rcases lt_trichotomy (y i) (y j) with hij | hij | hji'
        · rcases lt_trichotomy (y k) (y i) with hki | hki | hik
          · exact hno k i j hk hi hj hsk hsi hsj hki hij
          · exact hn.1 hki
          · rcases lt_trichotomy (y k) (y j) with hkj | hkj | hjk
            · exact hno i k j hi hk hj hsi hsk hsj hik hkj
            · exact hn.2 hkj
            · exact hno i j k hi hj hk hsi hsj hsk hij hjk
        · exact hji hij.symm
        · rcases lt_trichotomy (y k) (y j) with hkj | hkj | hjk
          · exact hno k j i hk hj hi hsk hsj hsi hkj hji'
          · exact hn.2 hkj
          · rcases lt_trichotomy (y k) (y i) with hki | hki | hik
            · exact hno j k i hj hk hi hsj hsk hsi hjk hki
            · exact hn.1 hki
            · exact hno j i k hj hi hk hsj hsi hsk hji' hik
      simpa only [Finset.mem_insert,Finset.mem_singleton] using he
    · refine ⟨{y i},by simp,?_⟩
      intro k hk hsk
      have he : y k=y i := by by_contra hn; exact hex2 ⟨k,hk,hsk,hn⟩
      simp only [Finset.mem_singleton,he]
  · refine ⟨∅,by simp,?_⟩
    intro k hk hsk
    exact (hex ⟨k,hk,hsk⟩).elim

/-- Proposition 4.1, conditional on the explicit unproved denominator estimate. -/
theorem proposition41_conditional (hPrior : Hypergeometric.DenominatorEstimate4) : Proposition41 := by
  intro P h hn hNs hmin K hK
  apply count_from_no_three
  intro i j k hi _ _ hsi hsj hsk hij hjk
  exact no_three hPrior P h hn hNs hmin K hK hi.1 hsi hsj hsk
    (by exact_mod_cast hij) (by exact_mod_cast hjk) hi.2

/-- Comparing coefficient and exponents, exactly as in the final paragraph. -/
theorem monomial_le_large {b N d C α β γ : ℝ}
    (hb : 1 ≤ b) (hN : 1 ≤ N) (hd : 2 ≤ d)
    (_hC : 0 ≤ C) (hC' : C ≤ 2643/100) (hα : α ≤ 8/3) (hβ : β ≤ 2) (hγ : 1/2 ≤ γ) :
    C*b^α*N^β/d^γ ≤ (2643/100 : ℝ)*b^(8/3 : ℝ)*N^2/Real.sqrt d := by
  have hbp : 0 < b := by linarith
  have hNp : 0 < N := by linarith
  have hdp : 0 < d := by linarith
  have ha := Real.rpow_le_rpow_of_exponent_le hb hα
  have hb' := Real.rpow_le_rpow_of_exponent_le hN hβ
  norm_num only [Real.rpow_two] at hb'
  have hnum := mul_le_mul (mul_le_mul hC' ha (by positivity) (by norm_num)) hb' (by positivity) (by positivity)
  have hden := Real.rpow_le_rpow_of_exponent_le (by linarith : 1 ≤ d) hγ
  rw [← Real.sqrt_eq_rpow] at hden
  exact (div_le_div_of_nonneg_right hnum (by positivity)).trans
    (div_le_div_of_nonneg_left (by positivity) (Real.sqrt_pos.mpr hdp) hden)

/-- The six-term maximum is bounded by the manuscript's coarser threshold. -/
theorem precise_le_large (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) :
    preciseSquareThreshold P ≤ largeSquareThreshold P := by
  have hp := integer_bounds P h hn
  have bound {C α β γ : ℝ} (hC : 0 ≤ C) (hC' : C ≤ 2643/100)
      (hα : α ≤ 8/3) (hβ : β ≤ 2) (hγ : 1/2 ≤ γ) :=
    monomial_le_large hp.1 hp.2.1 hp.2.2 hC hC' hα hβ hγ
  unfold preciseSquareThreshold largeSquareThreshold
  refine max_le ?_ (max_le ?_ (max_le ?_ (max_le ?_ (max_le ?_ ?_))))
  · exact bound (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  · have hh := bound (C := 1/10) (α := 8/3) (β := 7/6) (γ := 7/6)
      (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
    convert hh using 1; ring
  · simpa only [← Real.sqrt_eq_rpow] using bound (C := 148/10) (α := 4/3) (β := 5/3) (γ := 1/2)
      (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  · simpa only [Real.rpow_two,← Real.sqrt_eq_rpow] using bound (C := 2643/100) (α := 2) (β := 2) (γ := 1/2)
      (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  · simpa only [Real.rpow_zero,Real.rpow_one,mul_one,← Real.sqrt_eq_rpow] using bound (C := 4) (α := 0) (β := 1) (γ := 1/2)
      (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  · simpa only [Real.rpow_one,Real.rpow_two,one_mul] using bound (C := 1) (α := 2) (β := 1) (γ := 1)
      (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)

/-- Theorem 1.3, with the standing normalization and denominator premise explicit. -/
theorem theorem13_conditional (hPrior : Hypergeometric.DenominatorEstimate4) : Theorem13 := by
  intro P h hn hNs hmin K hK
  obtain ⟨S,hcard,hcover⟩ := proposition41_conditional hPrior P h hn hNs hmin K hK
  refine ⟨S,hcard,?_⟩
  intro k hk hs
  exact hcover k ⟨hk.1,(precise_le_large P h hn).trans_lt hk.2⟩ hs

end AnyBNormSquare.Section4Proof
