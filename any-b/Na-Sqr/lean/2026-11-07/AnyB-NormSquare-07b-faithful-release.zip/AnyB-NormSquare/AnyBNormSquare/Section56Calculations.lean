module

public import AnyBNormSquare.Section56Cutoff
public import AnyBNormSquare.Section56Table
public import AnyBNormSquare.Section56Records

@[expose] public section
namespace AnyBNormSquare.Section56Calculations
open «JNT-2024» Section5Size Section5Cases Section56Cutoff Section56Table Section56Records

/-- Exactly the arithmetic range and square-norm test for a row of Table 1. -/
def Candidate (P : Parameters) (b U : ℕ) : Prop :=
  P.b=b ∧ P.Admissible ∧ P.u < U ∧
  (P.d:ℝ) ≤ finiteBound P.b P.u ∧ P.normAlpha < 0 ∧ IsSquare (-P.normAlpha)

/-- The three large c₁ enumerations. No candidate enumeration is postulated
outside the displayed rows. -/
def JavaEnumeration : Prop :=
  ∀ b U D c₁ : ℕ, TableRow b U D c₁ →
    ∃ S : Finset Parameters, S.card=c₁ ∧ ∀ P, P ∈ S ↔ Candidate P b U

/-- The Java square filter, including its strict numerical cutoff, both tails
and the precise list of exceptional tuples. -/
def JavaSquareSearch : Prop :=
  ∀ (b U D c₁ : ℕ), TableRow b U D c₁ → ∀ S : Finset Parameters,
    (∀ P, P ∈ S ↔ Candidate P b U) →
    ∀ (P : Parameters), P ∈ S → ∀ (h : P.Admissible) (K : ℤ), P.IsNegativeCutoff h.pell K →
    ((∃ k : ℤ, (2 ≤ k ∨ k ≤ K-1) ∧ IsIntegerSquare (P.y h.pell k) ∧
        (P.y h.pell k : ℝ) < searchBound P.b P.d) ↔
      ∃ hit ∈ hits, hit.params=P)

/-- The reported quartic calculation (Magma and PARI/GP). The input covers
only positive solutions corresponding to a square in this recorded sequence. -/
def ExceptionalQuartics : Prop :=
  ∀ hit ∈ hits, ∀ (h : hit.params.Admissible) (x z : ℤ), 0 < x → 0 < z →
    x^2-hit.params.d*z^4=hit.params.normAlpha →
    (∃ k : ℤ, hit.params.y h.pell k=(z:ℚ)^2 ∧ |hit.params.x h.pell k|=(x:ℚ)) →
    (x=hit.params.a ∧ z=hit.params.b) ∨ z=hit.root

/-- The printed strict inequality for the least of the three squares. -/
theorem least_lt_searchBound (hPrior : Hypergeometric.DenominatorEstimate4)
    (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha))
    (hmin : SmallestInitialSquare P h.pell) (K : ℤ) (hK : P.IsNegativeCutoff h.pell K)
    {i j k : ℤ} (hi : 1 ≤ i ∨ i ≤ K)
    (hsi : IsIntegerSquare (P.y h.pell i)) (hsj : IsIntegerSquare (P.y h.pell j))
    (hsk : IsIntegerSquare (P.y h.pell k))
    (hij : (P.y h.pell i : ℝ) < (P.y h.pell j : ℝ))
    (hjk : (P.y h.pell j : ℝ) < (P.y h.pell k : ℝ)) :
    (P.y h.pell i : ℝ) < searchBound P.b P.d := by
  obtain ⟨hb,hN,hd⟩ := Section4Proof.integer_bounds P h hn
  have hNM : |(P.normAlpha:ℝ)| ≤ (P.d:ℝ)*(P.b:ℝ)^4-1 := by
    rw [abs_of_neg (by exact_mod_cast hn)]
    exact_mod_cast (show -P.normAlpha ≤ P.d*P.b^4-1 by
      unfold Parameters.normAlpha
      nlinarith only [sq_nonneg (P.a-1), h.a_pos])
  by_contra! hbig
  have hsize := (size_le hb hd hN hNM).trans hbig
  exact (not_lt_of_ge hbig) (bound_of_cases hb hd hN hNM
    (four_bounds hPrior P h hn hNs hmin K hK hi hsi hsj hsk hij hjk hsize))

/-- Convert a square on the specified tails to its positive quartic point
using the pinned integer-coordinate theorem and the norm identity. -/
theorem exceptional_values (hQ : ExceptionalQuartics) {hit : Hit} (hr : hit ∈ hits)
    (h : hit.params.Admissible) (hn : hit.params.normAlpha < 0)
    (K : ℤ) (hK : hit.params.IsNegativeCutoff h.pell K) {k : ℤ}
    (hk : 2 ≤ k ∨ k ≤ K-1) (hs : IsIntegerSquare (hit.params.y h.pell k)) :
    hit.params.y h.pell k = (hit.root:ℚ)^2 := by
  let P := hit.params
  obtain ⟨X,Y,hX,hY,hxy⟩ := P.section4_integer_coordinates h.pell hs
  obtain ⟨v,hv⟩ := hs
  have hYv : Y=v^2 := by exact_mod_cast (hY.symm.trans hv)
  have htail := Section5Opening.tail_gt_initial P h hn K hK hk
  have hbY : P.b^2 < Y := by exact_mod_cast (htail.trans_eq hY)
  have hY0 : 0 < Y := by linarith [sq_nonneg P.b]
  have hv0 : v ≠ 0 := by rintro rfl; simp_all
  have hX0 : X ≠ 0 := by
    intro he
    have hsq : (P.b^2)^2 < Y^2 := pow_lt_pow_left₀ hbY (sq_nonneg _) (by decide)
    have hprod := mul_lt_mul_of_pos_left hsq h.d_pos
    change X^2-P.d*Y^2=P.a^2-P.b^4*P.d at hxy
    nlinarith only [he,hxy,hprod,sq_nonneg P.a]
  have hv' : P.y h.pell k=((|v|:ℤ):ℚ)^2 := by simpa only [Int.cast_abs,sq_abs] using hv
  have hquart : |X|^2-P.d*|v|^4=P.normAlpha := by
    rw [sq_abs,show |v|^4=(|v|^2)^2 by ring,sq_abs,← hYv]; exact hxy
  have hx' : |P.x h.pell k| = ((|X|:ℤ):ℚ) := by rw [hX,Int.cast_abs]
  rcases hQ hit hr h |X| |v| (abs_pos.mpr hX0) (abs_pos.mpr hv0) hquart ⟨k,hv',hx'⟩ with hseed | he
  · have hy : P.y h.pell k=(P.b:ℚ)^2 := by
      simpa only [hseed.2] using hv'
    exact (htail.ne hy.symm).elim
  · simpa only [← he,Int.cast_abs,sq_abs] using hv

end AnyBNormSquare.Section56Calculations
