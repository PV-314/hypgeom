module

public import «JNT-2024».Section2Parameters
public import «JNT-2024».ArgumentBounds

@[expose] public section

/-!
# Lemma 3.5 of the supplied 2026-11-06c manuscript

Source: `lem:gNd4`, TeX lines 732--783. The lower bound follows the printed
two-case valuation argument; the upper bound uses the printed gcd bounds.
All normalizer definitions are those of the pinned JNT release. Its older
coprime normalizer theorem is not used here.
-/

namespace AnyBNormSquare
open «JNT-2024» Approximation

namespace Lemma35Proof

/-- The rational quantity to which the paper applies prime valuations. -/
def productSquareRat (S u₁ u₂ : ℤ) : ℚ :=
  gSquared S u₁ u₂ * (2 : ℚ) ^ min (padicValRat 2 (dPrime S u₁ u₂)) 6

theorem productSquareRat_cast (S u₁ u₂ : ℤ) :
    (productSquareRat S u₁ u₂ : ℝ) = normalizerProduct S u₁ u₂ ^ 2 := by
  rw [normalizerProduct_sq, productSquareRat]
  push_cast
  rfl

theorem gSquared_pos {S u₁ u₂ : ℤ} (hS : S ≠ 0) (hu₂ : u₂ ≠ 0) :
    0 < gSquared S u₁ u₂ := by
  unfold gSquared
  exact div_pos (mul_pos (sq_pos_of_pos (by exact_mod_cast g1_pos hu₂))
    (by exact_mod_cast g2_pos hS u₁ u₂)) (by exact_mod_cast g3_pos S u₁ u₂)

theorem productSquareRat_pos {S u₁ u₂ : ℤ} (hS : S ≠ 0) (hu₂ : u₂ ≠ 0) :
    0 < productSquareRat S u₁ u₂ :=
  mul_pos (gSquared_pos hS hu₂) (by positivity)

/-- The printed observation that the square of the 4-normalizer is a positive
integer. JNT proves that the defined rational `d′` is an integer. -/
theorem scale_square_integer {S u₁ u₂ : ℤ} (hS : S ≠ 0) (hu₂ : u₂ ≠ 0) :
    ∃ m : ℕ, 0 < m ∧
      (2 : ℚ) ^ min (padicValRat 2 (dPrime S u₁ u₂)) 6 = m := by
  rw [← dPrimeInteger_cast hS hu₂, padicValRat.of_int]
  refine ⟨2 ^ min (padicValInt 2 (dPrimeInteger S u₁ u₂)) 6, by positivity, ?_⟩
  rw [show min (padicValInt 2 (dPrimeInteger S u₁ u₂) : ℤ) 6 =
    ((min (padicValInt 2 (dPrimeInteger S u₁ u₂)) 6 : ℕ) : ℤ) by omega,
    zpow_natCast]
  norm_cast

/-- TeX 759--762: no odd prime occurs in the denominator of the squared
product. This uses the existing JNT valuation formula and `g₃ ∈ {1,2,4}`. -/
theorem productSquareRat_odd_nonneg {S u₁ u₂ : ℤ} (hS : S ≠ 0) (hu₂ : u₂ ≠ 0)
    (p : ℕ) [Fact p.Prime] (hp : p ≠ 2) :
    0 ≤ padicValRat p (productSquareRat S u₁ u₂) := by
  obtain ⟨m, hm, he⟩ := scale_square_integer hS hu₂
  rw [productSquareRat, he,
    padicValRat.mul (ne_of_gt (gSquared_pos hS hu₂)) (by exact_mod_cast ne_of_gt hm),
    padicValRat.of_nat, gSquared_valuation_published p hS hu₂,
    g3_valuation_odd_published p hp]
  omega

/-- The elementary integrality implication used in TeX 762--763, expanded
using JNT's prime-by-prime divisibility result. -/
theorem integer_of_nonnegative_valuations {q : ℚ} (hq : q ≠ 0)
    (hv : ∀ p : ℕ, p.Prime → 0 ≤ padicValRat p q) :
    ∃ n : ℤ, q = n := by
  have hn : q.num ≠ 0 := Rat.num_ne_zero.mpr hq
  have hd : (q.den : ℤ) ≠ 0 := by exact_mod_cast q.den_nz
  have hdiv : (q.den : ℤ) ∣ q.num := by
    apply int_dvd_of_valuation_le hd hn
    intro p hp
    have hh := hv p hp
    rw [padicValRat_def] at hh
    rw [padicValInt.of_nat]
    omega
  refine ⟨q.num / q.den, ?_⟩
  rw [Int.cast_div hdiv (by exact_mod_cast hd)]
  exact (Rat.num_div_den q).symm

/-- TeX 751--757: in the uncapped case the two valuations cancel exactly. -/
theorem productSquareRat_two_uncapped {S u₁ u₂ : ℤ} (hS : S ≠ 0) (hu₂ : u₂ ≠ 0)
    (hc : padicValRat 2 (dPrime S u₁ u₂) ≤ 6) :
    padicValRat 2 (productSquareRat S u₁ u₂) =
      2 * (padicValInt 2 u₂ : ℤ) + padicValInt 2 S := by
  have hu : (u₂ : ℚ) ≠ 0 := by exact_mod_cast hu₂
  have hs : (S : ℚ) ≠ 0 := by exact_mod_cast hS
  have htwo : padicValRat 2 (2 : ℚ) = 1 := padicValRat.self (by decide : 1 < 2)
  rw [productSquareRat, min_eq_left hc,
    padicValRat.mul (ne_of_gt (gSquared_pos hS hu₂)) (by positivity),
    padicValRat.zpow, htwo, mul_one,
    dPrime, padicValRat.div (mul_ne_zero (pow_ne_zero _ hu) hs)
      (ne_of_gt (gSquared_pos hS hu₂)),
    padicValRat.mul (pow_ne_zero _ hu) hs, padicValRat.pow,
    padicValRat.of_int, padicValRat.of_int]
  ring

/-- The second case uses exactly the printed bounds `g₁ ≥ 2`, `g₂ ≥ 1`,
and `g₃ ≤ 4`. -/
theorem one_le_g {S X C ν : ℤ} (hS : S ≠ 0) (hC : C ≠ 0)
    (hν : ν = 1 ∨ ν = -1) : 1 ≤ g S (2 * X) (2 * ν * C) := by
  have hu : 2 * ν * C ≠ 0 := by rcases hν with rfl | rfl <;> simpa using hC
  have h₁ : (2 : ℚ) ≤ g1 (2 * X) (2 * ν * C) := by
    rw [g1_unit X C ν hν]
    have hh := Int.gcd_pos_of_ne_zero_right X hC
    exact_mod_cast (show 2 ≤ 2 * Int.gcd X C by omega)
  have h₂ : (1 : ℚ) ≤ g2 S (2 * X) (2 * ν * C) := by
    exact_mod_cast (g2_pos hS (2 * X) (2 * ν * C))
  have hsq : (1 : ℚ) ≤ gSquared S (2 * X) (2 * ν * C) := by
    unfold gSquared
    rcases g3_cases S (2 * X) (2 * ν * C) with h₃ | h₃ | h₃ <;>
      rw [h₃] <;> norm_num <;> nlinarith [sq_nonneg (g1 (2 * X) (2 * ν * C) : ℚ)]
  have hsqr : (1 : ℝ) ≤ g S (2 * X) (2 * ν * C) ^ 2 := by
    rw [g_sq]
    exact_mod_cast hsq
  have hp := g_pos hS hu (u₁ := 2 * X)
  nlinarith

/-- The lower bound in Lemma 3.5, in the two cases used in its proof. -/
theorem lower_bound {S X C ν : ℤ} (hS : S ≠ 0) (hC : C ≠ 0)
    (hν : ν = 1 ∨ ν = -1) :
    2 ≤ normalizerProduct S (2 * X) (2 * ν * C) := by
  have hu : 2 * ν * C ≠ 0 := by rcases hν with rfl | rfl <;> simpa using hC
  by_cases hc : padicValRat 2 (dPrime S (2 * X) (2 * ν * C)) ≤ 6
  · have hvu : 1 ≤ padicValInt 2 (2 * ν * C) := by
      have hh := (prime_dvd_iff_valuation_pos 2 hu).mp
        (show (2 : ℤ) ∣ 2 * ν * C from ⟨ν * C, by ring⟩)
      omega
    have hv₂ : 2 ≤ padicValRat 2 (productSquareRat S (2 * X) (2 * ν * C)) := by
      rw [productSquareRat_two_uncapped hS hu hc]
      omega
    have hpos := productSquareRat_pos hS hu (u₁ := 2 * X)
    obtain ⟨n, hn⟩ := integer_of_nonnegative_valuations (ne_of_gt hpos) (by
      intro p hp
      let : Fact p.Prime := ⟨hp⟩
      by_cases he : p = 2
      · subst p; omega
      · exact productSquareRat_odd_nonneg hS hu p he)
    have hnp : (0 : ℤ) < n := by rw [hn] at hpos; exact_mod_cast hpos
    have hd : (4 : ℤ) ∣ n := by
      rw [hn, padicValRat.of_int] at hv₂
      exact (padicValInt_dvd_iff 2 n).mpr (Or.inr (by exact_mod_cast hv₂))
    have hn4 : (4 : ℤ) ≤ n := Int.le_of_dvd hnp hd
    have he : normalizerProduct S (2 * X) (2 * ν * C) ^ 2 = (n : ℝ) := by
      rw [← productSquareRat_cast, hn]
      norm_cast
    have hp := normalizerProduct_nonneg S (2 * X) (2 * ν * C)
    have hn4r : (4 : ℝ) ≤ n := by exact_mod_cast hn4
    nlinarith
  · have he : N4 (dPrime S (2 * X) (2 * ν * C)) = 8 := by
      rw [N4, min_eq_right (by omega)]
      rw [show (2 : ℝ) ^ (6 : ℤ) = (8 : ℝ) ^ 2 by norm_num,
        Real.sqrt_sq (by norm_num)]
    have hg := one_le_g hS hC hν (X := X)
    rw [normalizerProduct, he, abs_of_nonneg (by linarith)]
    nlinarith

/-- The final displayed inequality for the scale, TeX 781--782. -/
theorem scale_le_eight (q : ℚ) : N4 q ≤ 8 := by
  have he : (2 : ℝ) ^ min (padicValRat 2 q) 6 ≤ 64 := by
    convert zpow_le_zpow_right₀ (show (1 : ℝ) ≤ 2 by norm_num)
      (min_le_right (padicValRat 2 q) (6 : ℤ)) using 1
    norm_num
  have hs := N4_sq q
  nlinarith [Real.sqrt_nonneg ((2 : ℝ) ^ min (padicValRat 2 q) 6)]

/-- TeX 770--779: the two gcd upper bounds, with no coprimality premise. -/
theorem g_upper_bound {S X C ν : ℤ} (hS : S ≠ 0) (hC : 0 < C)
    (hν : ν = 1 ∨ ν = -1) :
    g S (2 * X) (2 * ν * C) ≤ 2 * (C : ℝ) * Real.sqrt |(S : ℝ)| := by
  have h₁ : (g1 (2 * X) (2 * ν * C) : ℝ) ≤ 2 * (C : ℝ) := by
    rw [g1_unit X C ν hν]
    have hh : (Int.gcd X C : ℝ) ≤ C := by exact_mod_cast Int.gcd_le_right X hC
    push_cast
    linarith
  have h₂ : (g2 S (2 * X) (2 * ν * C) : ℝ) ≤ |(S : ℝ)| := by
    have hh := Nat.le_of_dvd (Int.natAbs_pos.mpr hS)
      (Int.gcd_dvd_natAbs_right ((2 * X) / (g1 (2 * X) (2 * ν * C) : ℤ)) S)
    have hhZ : (g2 S (2 * X) (2 * ν * C) : ℤ) ≤ (S.natAbs : ℤ) := by exact_mod_cast hh
    rw [Int.natCast_natAbs] at hhZ
    exact_mod_cast hhZ
  have h₃ : (1 : ℝ) ≤ g3 S (2 * X) (2 * ν * C) := by
    exact_mod_cast g3_pos S (2 * X) (2 * ν * C)
  have hd : (g2 S (2 * X) (2 * ν * C) : ℝ) / g3 S (2 * X) (2 * ν * C) ≤ |(S : ℝ)| := by
    apply (div_le_iff₀ (by linarith)).mpr
    nlinarith [abs_nonneg (S : ℝ)]
  exact mul_le_mul h₁ (Real.sqrt_le_sqrt hd) (Real.sqrt_nonneg _)
    (by exact_mod_cast (show (0 : ℤ) ≤ 2 * C by omega))

/-- The normalizer upper bound is the product of the two printed bounds. -/
theorem upper_bound {S X C ν : ℤ} (hS : S ≠ 0) (hC : 0 < C)
    (hν : ν = 1 ∨ ν = -1) :
    normalizerProduct S (2 * X) (2 * ν * C) ≤
      16 * (C : ℝ) * Real.sqrt |(S : ℝ)| := by
  have hu : 2 * ν * C ≠ 0 := by
    rcases hν with rfl | rfl <;> simpa using ne_of_gt hC
  have hg := g_upper_bound hS hC hν (X := X)
  have hs := scale_le_eight (dPrime S (2 * X) (2 * ν * C))
  have hp := g_pos hS hu (u₁ := 2 * X)
  rw [normalizerProduct, abs_of_pos hp]
  calc
    _ ≤ (2 * (C : ℝ) * Real.sqrt |(S : ℝ)|) * 8 :=
      mul_le_mul hg hs (Real.sqrt_nonneg _) (by positivity)
    _ = _ := by ring

/-- Explicit equivalence between JNT's square-root definition and (2.1)
specialised to `n = 4`, using the real fractional exponent from the paper. -/
theorem N4_eq_paper (q : ℚ) :
    N4 q = (2 : ℝ) ^ min ((padicValRat 2 q : ℝ) / 2) 3 := by
  rw [N4, Real.sqrt_eq_rpow, ← Real.rpow_intCast, ← Real.rpow_mul (by norm_num)]
  congr 1
  by_cases hv : padicValRat 2 q ≤ 6
  · have hv' : (padicValRat 2 q : ℝ) ≤ 6 := by exact_mod_cast hv
    rw [min_eq_left hv, min_eq_left (show (padicValRat 2 q : ℝ) / 2 ≤ 3 by linarith)]
    ring
  · have hv' : (6 : ℝ) ≤ padicValRat 2 q := by exact_mod_cast (show (6 : ℤ) ≤ padicValRat 2 q by omega)
    rw [min_eq_right (show (6 : ℤ) ≤ padicValRat 2 q by omega),
      min_eq_right (show (3 : ℝ) ≤ (padicValRat 2 q : ℝ) / 2 by linarith)]
    norm_num

end Lemma35Proof

/-- The integer value of the signed norm `N_{ε^k}`. -/
def unitPowerNorm (P : Parameters) (k : ℤ) : ℤ := (P.epsilonNorm ^ k).num

theorem unitPowerNorm_cast (P : Parameters) (hp : P.Pell) (k : ℤ) :
    (unitPowerNorm P k : ℚ) = P.epsilonNorm ^ k := by
  rcases P.epsilonNorm_zpow_sign hp k with he | he <;> simp [unitPowerNorm, he]

theorem unitPowerNorm_sign (P : Parameters) (hp : P.Pell) (k : ℤ) :
    unitPowerNorm P k = 1 ∨ unitPowerNorm P k = -1 := by
  rcases P.epsilonNorm_zpow_sign hp k with he | he <;> simp [unitPowerNorm, he]

/-- The positive square factor in JNT is exactly the radical in Lemma 3.5. -/
theorem squareFactor_eq_paper_root (N : ℤ) :
    (squareFactor N : ℝ) = Real.sqrt ((N : ℝ) / squarefreePart N) := by
  have hs : (squarefreePart N : ℝ) ≠ 0 := by exact_mod_cast squarefreePart_ne_zero N
  have he : (squareFactor N : ℝ) ^ 2 * squarefreePart N = N := by
    exact_mod_cast squareFactor_sq_mul N
  rw [(div_eq_iff hs).mpr he.symm, Real.sqrt_sq (by exact_mod_cast squareFactor_nonneg N)]

/-- The integer used as `u₂` agrees with the paper's signed real expression. -/
theorem lemma35_u2_eq_paper (P : Parameters) (hp : P.Pell) (k : ℤ) :
    ((2 * unitPowerNorm P k * squareFactor P.normAlpha : ℤ) : ℝ) =
      2 * (P.epsilonNorm ^ k : ℚ) *
        Real.sqrt ((P.normAlpha : ℝ) / squarefreePart P.normAlpha) := by
  have he : (unitPowerNorm P k : ℝ) = ((P.epsilonNorm ^ k : ℚ) : ℝ) := by
    exact_mod_cast unitPowerNorm_cast P hp k
  push_cast
  rw [he, squareFactor_eq_paper_root]
  push_cast
  rfl

/-- Lemma 3.5 (`lem:gNd4`), with all printed sequence and integrality
hypotheses retained. The unused sequence hypotheses are not replaced by an
extra coprimality or square-norm hypothesis. -/
theorem lemma35_normalizer (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    {k X Y : ℤ} (_hk : k ≠ 0)
    (_hx : P.x h.pell k = (X : ℚ)) (_hy : P.y h.pell k = (Y : ℚ)) :
    let S := squarefreePart P.normAlpha
    let u₁ := 2 * X
    let u₂ := 2 * unitPowerNorm P k * squareFactor P.normAlpha
    2 ≤ normalizerProduct S u₁ u₂ ∧
      normalizerProduct S u₁ u₂ ≤ 16 * Real.sqrt |(P.normAlpha : ℝ)| := by
  have hC := squareFactor_pos (ne_of_lt hn)
  have hS := squarefreePart_ne_zero P.normAlpha
  have hν := unitPowerNorm_sign P h.pell k
  refine ⟨Lemma35Proof.lower_bound hS (ne_of_gt hC) hν, ?_⟩
  have hh := Lemma35Proof.upper_bound hS hC hν (X := X)
  have hs : (squarefreePart P.normAlpha : ℝ) < 0 := by exact_mod_cast squarefreePart_neg hn
  have hn' : (P.normAlpha : ℝ) < 0 := by exact_mod_cast hn
  have he : (squareFactor P.normAlpha : ℝ) * Real.sqrt |(squarefreePart P.normAlpha : ℝ)| =
      Real.sqrt |(P.normAlpha : ℝ)| := by
    rw [abs_of_neg hs, abs_of_neg hn', ← P.negativeNormRoot_sq hn,
      Real.sqrt_sq (P.negativeNormRoot_pos hn).le]
    rfl
  simpa only [mul_assoc, he] using hh

/-- Lemma 3.5 in the paper's real fractional-power notation for `𝒩_{d′,4}`.
The equality `lemma35_u2_eq_paper` identifies the integer `u₂` with its printed
radical expression; `lemma35_normalizer` exposes the same result in JNT's API. -/
theorem lemma35 (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    {k X Y : ℤ} (hk : k ≠ 0)
    (hx : P.x h.pell k = (X : ℚ)) (hy : P.y h.pell k = (Y : ℚ)) :
    let S := squarefreePart P.normAlpha
    let u₁ := 2 * X
    let u₂ := 2 * unitPowerNorm P k * squareFactor P.normAlpha
    let d' := dPrime S u₁ u₂
    let M := |g S u₁ u₂| * (2 : ℝ) ^ min ((padicValRat 2 d' : ℝ) / 2) 3
    2 ≤ M ∧ M ≤ 16 * Real.sqrt |(P.normAlpha : ℝ)| := by
  simpa only [normalizerProduct, Lemma35Proof.N4_eq_paper] using
    lemma35_normalizer P h hn hk hx hy

end AnyBNormSquare
