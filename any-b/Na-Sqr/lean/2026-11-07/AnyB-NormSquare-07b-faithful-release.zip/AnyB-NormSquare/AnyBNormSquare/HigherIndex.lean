module

public import AnyBNormSquare.Case43

@[expose] public section
namespace AnyBNormSquare.HigherIndex
open «JNT-2024» Approximation Prerequisites

/-- The first displayed chain of Section 4.4, with this paper's Q>21.12.
Minimality is applied at r-1, so the r>1 hypothesis is essential. -/
theorem cutoff_chain {E Q ℓ c : ℝ} (hE : 1 < E) (hQ : (2112/100 : ℝ) < Q)
    (hℓ : 0 < ℓ) (hc : 0 < c) (z : ℂ)
    (hr : 1 < firstIndex (Q := Q) (ℓ := ℓ) hE hc z) :
    let r := firstIndex (Q := Q) (ℓ := ℓ) hE hc z
    c*(Q-1)/(ℓ*(Q-1/E))*E^(r-1) ≤ ‖z‖ ∧
    (952/1000 : ℝ)*c*E^(r-1)/ℓ < c*(Q-1)/(ℓ*(Q-1/E))*E^(r-1) := by
  let r := firstIndex (Q := Q) (ℓ := ℓ) hE hc z
  have hEp : 0 < E := by linarith
  have hQp : 0 < Q := by linarith
  have hi : 0 < 1/E := one_div_pos.mpr hEp
  have hi1 : 1/E < 1 := (div_lt_one hEp).mpr hE
  have hden : 0 < Q-1/E := by linarith
  have hqm : 0 < Q-1 := by linarith
  have hnot : ¬ Cutoff E Q ℓ c z (r-1) := by
    intro hh
    have hm := firstIndex_le hE hc z (show 0 < r-1 by dsimp [r]; omega) hh
    change r ≤ r-1 at hm
    dsimp [r] at hm
    omega
  have hb : c*E^(r-1) ≤ (Q-1/E)*ℓ*‖z‖/(Q-1) := le_of_not_gt hnot
  have hb' := (le_div_iff₀ hqm).mp hb
  constructor
  · rw [show c*(Q-1)/(ℓ*(Q-1/E))*E^(r-1) = c*(Q-1)*E^(r-1)/(ℓ*(Q-1/E)) by ring]
    apply (div_le_iff₀ (mul_pos hℓ hden)).mpr
    nlinarith only [hb']
  · have hround : (952/1000 : ℝ)*(Q-1/E) < Q-1 := by linarith
    have hh := mul_lt_mul_of_pos_right hround (show 0 < c*E^(r-1) by positivity)
    rw [show c*(Q-1)/(ℓ*(Q-1/E))*E^(firstIndex hE hc z-1) =
      c*(Q-1)*E^(firstIndex hE hc z-1)/(ℓ*(Q-1/E)) by ring]
    apply (div_lt_div_iff₀ hℓ (mul_pos hℓ hden)).mpr
    have hm := mul_lt_mul_of_pos_right hh hℓ
    nlinarith only [hm]

/-- Substitute ell and E, then the printed 0.9375 coordinate estimate.
The strict numerical rounding gives 1.498. -/
theorem coordinate_lower {E ℓ c N L X A t : ℝ} {r : ℕ}
    (_hE : 0 < E) (hℓ : 0 < ℓ) (hc : 0 < c) (hN : 0 < N) (hL : 0 < L)
    (hX : (15/16 : ℝ)*L^2 ≤ X^2)
    (hell : ℓ < (615/1000 : ℝ)*Real.sqrt N/|X|)
    (hA : 0 < A) (hAE : A < E)
    (hl : (952/1000 : ℝ)*c*E^(r-1)/ℓ < t) :
    (1498/1000 : ℝ)*c*L/Real.sqrt N*A^(r-1) < t := by
  have hs := Real.sqrt_pos.mpr hN
  have hXp : 0 < |X| := by nlinarith [sq_abs X,abs_nonneg X]
  have hx : (9682/10000 : ℝ)*L < |X| := by nlinarith [sq_abs X]
  have he := (lt_div_iff₀ hXp).mp hell
  have hm := mul_lt_mul_of_pos_left hx hℓ
  have hnum : (1498/1000 : ℝ)*L*ℓ < (952/1000 : ℝ)*Real.sqrt N := by
    nlinarith only [he,hm,hs]
  have hconst : (1498/1000 : ℝ)*c*L/Real.sqrt N < (952/1000 : ℝ)*c/ℓ := by
    apply (div_lt_div_iff₀ hs hℓ).mpr
    have hh := mul_lt_mul_of_pos_right hnum hc
    nlinarith only [hh]
  have hp := pow_le_pow_left₀ hA.le hAE.le (r-1)
  have hh := mul_lt_mul_of_pos_right hconst (pow_pos hA (r-1))
  have hm := mul_le_mul_of_nonneg_left hp (show 0 ≤ (952/1000 : ℝ)*c/ℓ by positivity)
  exact (hh.trans_le hm).trans (by simpa only [div_mul_eq_mul_div,mul_assoc] using hl)

/-- Reindex the bound, using exactly 8.176*0.1832<1.498. -/
theorem factor_lower {N d y M c : ℝ} {r : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hy : 0 < y) (hM : 0 < M) (hc : 0 < c) (hr : 1 ≤ r) :
    let A := (1832/10000 : ℝ)*M*Real.sqrt d*y/N
    (8176/1000 : ℝ)*c*Real.sqrt N/M*A^r <
      (1498/1000 : ℝ)*c*Real.sqrt d*y/Real.sqrt N*A^(r-1) := by
  let A := (1832/10000 : ℝ)*M*Real.sqrt d*y/N
  have hAp : 0 < A := by dsimp [A]; positivity
  have he : (8176/1000 : ℝ)*c*Real.sqrt N/M*A =
      ((8176/1000 : ℝ)*(1832/10000))*c*Real.sqrt d*y/Real.sqrt N := by
    dsimp [A]; field_simp; exact Real.sq_sqrt hN.le
  have hrw : r=(r-1)+1 := by omega
  change (8176/1000 : ℝ)*c*Real.sqrt N/M*A^r < _
  conv_lhs => rw [hrw,pow_succ]
  have hh := mul_lt_mul_of_pos_right (by norm_num : (8176/1000 : ℝ)*(1832/10000)<1498/1000)
    (show 0 < c*Real.sqrt d*y/Real.sqrt N by positivity)
  have hh' := mul_lt_mul_of_pos_right hh (pow_pos hAp (r-1))
  calc
    _ = ((8176/1000 : ℝ)*c*Real.sqrt N/M*A)*A^(r-1) := by ring
    _ = _ := by rw [he]
    _ < _ := by convert hh' using 1 <;> ring

/-- Fourth powers and the b-scaled denominator norm give the shared lower bound.
Its factorization is algebraically the printed (8.176*b*c/M*sqrt(N/F))^4. -/
theorem fourth_power {N d y z F M c t b : ℝ} {r : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hy : 0 < y) (hF : 0 < F) (hM : 0 < M)
    (hb : 0 < b) (hc : 0 < c) (hr : 1 ≤ r) (hnorm : t^4*b^4=F^2*y*z)
    (hl : (1498/1000 : ℝ)*c*Real.sqrt d*y/Real.sqrt N*
      ((1832/10000 : ℝ)*M*Real.sqrt d*y/N)^(r-1) < t) :
    ((8176/1000 : ℝ)*b/M)^4*(N/F)^2*c^4*((1832/10000 : ℝ)*M/N)^(4*r)*
      d^(2*r)*y^(4*r-1) < z := by
  have hp := pow_lt_pow_left₀ ((factor_lower hN hd hy hM hc hr).trans hl)
    (by positivity) (by decide : (4 : ℕ) ≠ 0)
  have hm := mul_lt_mul_of_pos_right hp (pow_pos hb 4)
  rw [hnorm] at hm
  have hsN : Real.sqrt N^4=N^2 := by rw [show (4 : ℕ)=2*2 from rfl,pow_mul,Real.sq_sqrt hN.le]
  have hsd : Real.sqrt d^(4*r)=d^(2*r) := by rw [show 4*r=2*(2*r) by omega,pow_mul,Real.sq_sqrt hd.le]
  apply (mul_lt_mul_iff_right₀ (mul_pos (sq_pos_of_pos hF) hy)).mp
  convert hm using 1
  · rw [pow_sub₀ y (ne_of_gt hy) (by omega : 1 ≤ 4*r)]
    simp only [mul_pow,div_pow,← pow_mul,pow_one,hsN]
    rw [Nat.mul_comm r 4,hsd]
    field_simp

/-- Shared sequence lower bound for Sections 4.4 and 4.5, from the actual cutoff. -/
theorem sequence_lower (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha)) {i j : ℤ}
    (a : Prepared P h i j)
    (hlarge : 4*|(P.normAlpha : ℝ)|/Real.sqrt P.d ≤ (P.y h.pell i : ℝ))
    {c : ℝ} (hc : 0 < c) (hr : 1 < Case42.index a hc) :
    let r := Case42.index a hc
    let M := normalizerProduct (-1) (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha)
    ((8176/1000 : ℝ)*P.b/M)^4*(|(P.normAlpha : ℝ)|/(a.left.f*a.right.f))^2*c^4*
      ((1832/10000 : ℝ)*M/|(P.normAlpha : ℝ)|)^(4*r)*(P.d : ℝ)^(2*r)*a.left.y^(4*r-1) < a.right.y := by
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hb : (0 : ℝ) < P.b := by exact_mod_cast h.b_pos
  have hN : 0 < |(P.normAlpha : ℝ)| := abs_pos.mpr (by exact_mod_cast ne_of_lt hn)
  have hY : 4*|(P.normAlpha : ℝ)|/Real.sqrt P.d ≤ (a.Y : ℝ) := by
    simpa only [a.hy,Rat.cast_intCast] using hlarge
  have hpars := application_parameters P h hn hNs a.hx a.hy hY
  have hy : (a.Y : ℝ) = a.left.y := by rw [a.left_certificate.1,a.hy,Rat.cast_intCast]
  rw [hy] at hpars
  have hM : 0 < normalizerProduct (-1) (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha) := by linarith [hpars.2.1]
  have hell := Section2.ell_pos (u₁ := 2*a.X) (by decide : (-1 : ℤ) < 0) (Case43.imaginary_ne P h hn hNs a)
  have hcut := cutoff_chain a.E_gt_one hpars.2.2.2.2.1 hell hc (Section2.gaussianEmbedding a.denominator) hr
  have hco := sequence_coordinates P h hn hNs a.hx a.hy
  have he := hco.2.2.1
  rw [hy,mul_pow,Real.sq_sqrt hd.le] at he
  have hsize := threshold_implies_coordinate_size P h hn hlarge
  rw [← a.left_certificate.1] at hsize
  have hx := (coordinate_bounds (x := (a.X : ℝ)) hN hd hsize (by linarith only [he])).1
  have hx' : (15/16 : ℝ)*(Real.sqrt P.d*a.left.y)^2 ≤ (a.X : ℝ)^2 := by
    simpa only [mul_pow,Real.sq_sqrt hd.le,mul_assoc] using hx
  have hlo := coordinate_lower
    (A := (1832/10000 : ℝ)*normalizerProduct (-1) (2*a.X)
      (2*unitPowerNorm P i*squareFactor P.normAlpha)*(Real.sqrt P.d*a.left.y)/|(P.normAlpha : ℝ)|)
    (lt_trans (by norm_num : (0 : ℝ) < 1) a.E_gt_one) hell hc hN
    (mul_pos (Real.sqrt_pos.mpr hd) a.left.y_pos) hx' hpars.2.2.2.2.2.2.1
    (div_pos (mul_pos (mul_pos (by norm_num) hM)
      (mul_pos (Real.sqrt_pos.mpr hd) a.left.y_pos)) hN) hpars.2.2.1 (hcut.2.trans_le hcut.1)
  apply fourth_power hN hd a.left.y_pos (mul_pos a.left.f_pos a.right.f_pos)
    hM hb hc (by omega) (Case42.norm_fourth P h a)
  simpa only [mul_assoc,Case42.index] using hlo

end AnyBNormSquare.HigherIndex
