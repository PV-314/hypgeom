module

public import AnyBNormSquare.Revision06g

@[expose] public section
namespace AnyBNormSquare.Section5High

/-- The explicit bound (5.9), in the variable n = 2 r₀ - 1. -/
noncomputable def thirdDBound (n b u N : ℝ) : ℝ :=
  (2392/10:ℝ)^(2*n/(3*n+2))*(653/1000:ℝ)^(2/(3*n+2))*
  N^((n+1)/(3*n+2))*b^(4*(n+2)/(3*n+2))/
  (u^(8*n/(3*n+2))*(2:ℝ)^((4*n-2)/(3*n+2)))

/-- Comparison of (5.3) and (4.25) before bounding the individual exponents. -/
theorem third_rearrange {b d N u y G n : ℝ}
    (hb : 0 < b) (hd : 0 < d) (hu : 0 < u) (hN : 0 < N)
    (hG : 2 ≤ G) (hn : 3 ≤ n)
    (hl : (99/400:ℝ)*N*d*u^4/b^2 ≤ y)
    (hh : y < (592/10:ℝ)*(653/1000:ℝ)^(1/n)*b^(4/n)*
       N^((3/2:ℝ)+1/(2*n))/(d^((1/2:ℝ)+1/n)*G^(2-1/n))) :
    d < thirdDBound n b u N := by
  have hg : 0 < G := by linarith
  have hn0 : 0 < n := by linarith
  have hn' : 0 < 3*n+2 := by linarith
  have hc := Real.log_lt_log (by positivity) (hl.trans_lt hh)
  have hg' := Real.log_le_log (by norm_num : (0:ℝ)<2) hG
  have hround := Real.log_lt_log (by norm_num : (0:ℝ)<(592/10)/(99/400))
    (by norm_num : (592/10:ℝ)/(99/400)<2392/10)
  unfold thirdDBound
  apply (Real.log_lt_log_iff hd (by positivity)).mp
  simp (disch := positivity) only [Real.log_mul,Real.log_div,Real.log_rpow,Real.log_pow] at hc hround ⊢
  norm_num1 at hc hround ⊢
  field_simp (disch := positivity) at hc ⊢
  have hgm := mul_le_mul_of_nonneg_left hg' (show 0 ≤ 4*n-2 by linarith)
  have hcm := mul_lt_mul_of_pos_left hround (show 0 < 2*n by positivity)
  linarith only [hc,hgm,hcm]

/-- The coefficient in (5.9) is bounded by its limiting value, and the
remaining exponents attain their requisite extrema at n=3. -/
theorem third_simplify {n b u N : ℝ} (hn : 3 ≤ n) (hb : 1 ≤ b) (hu : 1 ≤ u)
    (hN : 1 ≤ N) : thirdDBound n b u N <
        (153/10:ℝ)*b^(20/11:ℝ)*N^(4/11:ℝ)/u^(24/11:ℝ) := by
  have hb' : 0 < b := by linarith
  have hu' : 0 < u := by linarith
  have hN' : 0 < N := by linarith
  have hz : 0 < 3*n+2 := by linarith
  have hc := Real.log_lt_log (by norm_num : 0 < (2392/10:ℝ)^2/2^4)
    (by norm_num : (2392/10:ℝ)^2/2^4 < (153/10:ℝ)^3)
  have hr := Real.log_lt_log (by norm_num : 0 < (653/1000:ℝ)^6*2^14/(2392/10)^4)
    (by norm_num : (653/1000:ℝ)^6*2^14/(2392/10)^4 < 1)
  unfold thirdDBound
  apply (Real.log_lt_log_iff (by positivity) (by positivity)).mp
  simp (disch := positivity) only [Real.log_mul,Real.log_div,Real.log_pow,Real.log_rpow,Real.log_one] at hc hr ⊢
  norm_num1 at hc hr ⊢
  field_simp (disch := positivity)
  have hbcmp := mul_nonneg (sub_nonneg.mpr hn) (Real.log_nonneg hb)
  have hucmp := mul_nonneg (sub_nonneg.mpr hn) (Real.log_nonneg hu)
  have hNcmp := mul_nonneg (sub_nonneg.mpr hn) (Real.log_nonneg hN)
  have hbase := mul_lt_mul_of_pos_left hc hz
  linarith only [hbcmp,hucmp,hNcmp,hbase,hr]

/-- Substitute N < d b⁴ into (5.9) before simplifying the exponents,
as in the derivation of (5.11). -/
theorem third_norm_free {d n b u N : ℝ} (hd : 0 < d) (hn : 3 ≤ n)
    (hb : 1 ≤ b) (hu : 1 ≤ u) (hN : 0 < N) (hs : N < d*b^4)
    (hh : d < thirdDBound n b u N) : d < 60*b^(36/7:ℝ)/u^(24/7:ℝ) := by
  have hb' : 0 < b := by linarith
  have hu' : 0 < u := by linarith
  have hz : 0 < 3*n+2 := by linarith
  have hc := Real.log_lt_log (by norm_num : 0 < (2392/10:ℝ)/4)
    (by norm_num : (2392/10:ℝ)/4 < 60)
  have hr := Real.log_lt_log (by norm_num : 0 < (653/1000:ℝ)^2*2^4/(2392/10))
    (by norm_num : (653/1000:ℝ)^2*2^4/(2392/10) < 1)
  rw [show (4:ℝ) = 2^2 by norm_num] at hc
  unfold thirdDBound at hh
  have hineq := Real.log_lt_log hd hh
  have hsub := Real.log_lt_log hN hs
  apply (Real.log_lt_log_iff hd (by positivity)).mp
  simp (disch := positivity) only [Real.log_mul,Real.log_div,Real.log_pow,Real.log_rpow,Real.log_one] at hc hr hineq hsub ⊢
  norm_num1 at hc hr hineq hsub ⊢
  field_simp (disch := positivity) at hineq
  have hbase := mul_lt_mul_of_pos_left hc (show 0 < 2*n+1 by linarith)
  have hsub' := mul_lt_mul_of_pos_left hsub (show 0 < n+1 by linarith)
  have hbcmp := mul_nonneg (sub_nonneg.mpr hn) (Real.log_nonneg hb)
  have hucmp := mul_nonneg (sub_nonneg.mpr hn) (Real.log_nonneg hu)
  apply (mul_lt_mul_iff_right₀ (show 0 < 2*n+1 by linarith)).mp
  linarith only [hbase,hr,hineq,hsub',hbcmp,hucmp]

end AnyBNormSquare.Section5High
