module

public import AnyBNormSquare.Section5Main
public import «JNT-2024».Section6Sequence

@[expose] public section
namespace AnyBNormSquare.Reindex
open «JNT-2024»

def orbitY (P : Parameters) (hp : P.Pell) (w : P.Algebra) (k : ℤ) : ℚ :=
  (w * (P.stepUnit hp ^ k : P.Algebraˣ)).im

private theorem star_step (P : Parameters) : star P.step=P.backStep := by
  ext <;> simp [Parameters.step,Parameters.backStep]

private theorem star_back (P : Parameters) : star P.backStep=P.step := by
  rw [← star_step,star_star]

private theorem star_power (P : Parameters) (hp : P.Pell) (k : ℤ) :
    star ((P.stepUnit hp ^ k : P.Algebraˣ) : P.Algebra) =
      ((P.stepUnit hp ^ (-k) : P.Algebraˣ) : P.Algebra) := by
  cases k with
  | ofNat n =>
    simp [zpow_natCast,zpow_neg,star_pow,Parameters.stepUnit,star_step]
  | negSucc n =>
    rw [show Int.negSucc n = -((n+1:ℕ):ℤ) by omega,neg_neg,zpow_neg,zpow_natCast]
    simp [star_pow,Parameters.stepUnit,star_back]

theorem negative_conjugate (P : Parameters) (hp : P.Pell) (w : P.Algebra) (k : ℤ) :
    orbitY P hp (-star w) k = orbitY P hp w (-k) := by
  have he := congrArg (fun z : P.Algebra => z.im) (star_mul w ((P.stepUnit hp ^ (-k) : P.Algebraˣ) : P.Algebra))
  simp only [star_power,neg_neg,QuadraticAlgebra.im_star] at he
  simpa [orbitY,neg_mul,mul_comm] using congrArg Neg.neg he.symm

/-- If the radical coordinate is a nonzero integer square, the rational
coordinate is an integer and cannot vanish under the square-norm condition. -/
theorem restart (P : Parameters) (h : P.Admissible)
    (hs : IsSquare (-P.normAlpha)) (w : P.Algebra) {b : ℤ} (hb : 0 < b)
    (hy : w.im = (b:ℚ)^2) (hn : QuadraticAlgebra.norm w = (P.normAlpha:ℚ)) :
    ∃ (Q : Parameters) (hq : Q.Admissible), Q.b=b ∧ Q.normAlpha=P.normAlpha ∧
      ((∀ j, Q.y hq.pell j = orbitY P h.pell w j) ∨
       (∀ j, Q.y hq.pell j = orbitY P h.pell w (-j))) := by
  have hnorm : w.re^2-(P.d:ℚ)*(b:ℚ)^4=P.normAlpha := by
    simp [QuadraticAlgebra.norm,hy] at hn
    linear_combination hn
  obtain ⟨X,hX⟩ := integer_root_of_two_mul_sq w.re ⟨2*(P.normAlpha+P.d*b^4),by push_cast; linarith only [hnorm]⟩
  have hXi : X^2-P.d*b^4=P.normAlpha := by
    rw [hX] at hnorm
    exact_mod_cast hnorm
  have hX0 : X ≠ 0 := by
    intro hx
    obtain ⟨v,hv⟩ := hs
    have he : v^2=P.d*b^4 := by rw [hx] at hXi; nlinarith only [hv,hXi]
    apply h.d_not_square
    apply Rat.isSquare_intCast_iff.mp
    refine ⟨(v:ℚ)/(b:ℚ)^2,?_⟩
    have hb0 : (b:ℚ) ≠ 0 := by exact_mod_cast hb.ne'
    have hh : (v:ℚ)^2=P.d*(b:ℚ)^4 := by exact_mod_cast he
    field_simp
    nlinarith only [hh]
  let Q : Parameters := {P with a:=|X|, b:=b}
  have hq : Q.Admissible := ⟨abs_pos.mpr hX0,hb,h.d_pos,h.t_pos,h.u_pos,h.d_not_square,h.pell⟩
  refine ⟨Q,hq,rfl,?_,?_⟩
  · dsimp [Q,Parameters.normAlpha] at *
    rw [sq_abs]; linarith only [hXi]
  by_cases hx : 0 ≤ X
  · left
    have hw : Q.alpha = w := by
      ext <;> simp [Q,Parameters.alpha,abs_of_nonneg hx,hX,hy]
    intro j
    change (Q.alpha * (P.stepUnit h.pell ^ j : P.Algebraˣ)).im=_
    rw [hw]; rfl
  · right
    have hw : Q.alpha = -star w := by
      ext <;> simp [Q,Parameters.alpha,abs_of_neg (lt_of_not_ge hx),hX,hy]
    intro j
    change (Q.alpha * (P.stepUnit h.pell ^ j : P.Algebraˣ)).im=_
    rw [hw]; exact negative_conjugate P h.pell w j

theorem translated (P : Parameters) (hp : P.Pell) (w : P.Algebra) (i k : ℤ) :
    orbitY P hp (w * (P.stepUnit hp ^ i : P.Algebraˣ)) k = orbitY P hp w (i+k) := by
  simp [orbitY,zpow_add,mul_assoc]

theorem even_orbit (P : Parameters) (hp : P.Pell) (k : ℤ) :
    orbitY P hp P.alpha k=P.y hp k := rfl

theorem general_orbit (P : Parameters) (hp : P.Pell) (i k : ℤ) :
    orbitY P hp (P.alpha * (P.epsilonUnit hp ^ i : P.Algebraˣ)) k=P.generalY hp (i+2*k) := by
  unfold orbitY Parameters.generalY
  rw [zpow_add,zpow_mul,← P.epsilonUnit_sq hp]
  simp [mul_assoc]

theorem general_norm (P : Parameters) (hp : P.Pell) (hε : P.epsilonNorm=1) (i : ℤ) :
    QuadraticAlgebra.norm (P.alpha * ((P.epsilonUnit hp ^ i : P.Algebraˣ) : P.Algebra)) = (P.normAlpha:ℚ) := by
  have ha : QuadraticAlgebra.norm P.alpha=(P.normAlpha:ℚ) := by
    simpa only [P.term_zero] using P.norm_term hp 0
  rw [map_mul,ha]
  suffices (QuadraticAlgebra.norm ((P.epsilonUnit hp ^ i : P.Algebraˣ):P.Algebra)) = 1 by rw [this,mul_one]
  cases i with
  | ofNat n => simp [Parameters.epsilonUnit, P.norm_epsilon, hε]
  | negSucc n =>
    rw [show Int.negSucc n = -((n+1:ℕ):ℤ) by omega, zpow_neg,zpow_natCast]
    have hinv : QuadraticAlgebra.norm P.epsilonBack=1 := by
      have hmul := congrArg QuadraticAlgebra.norm (P.epsilon_mul_back hp)
      simpa only [map_mul,map_one,P.norm_epsilon,hε,one_mul] using hmul
    simp [Parameters.epsilonUnit,hinv]

/-- Section 1.1: the least integer square exists in the given even-power sequence. -/
theorem least_square (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) :
    ∃ (i b : ℤ), 0 < b ∧ P.y h.pell i=(b:ℚ)^2 ∧
      ∀ k, IsIntegerSquare (P.y h.pell k) → P.y h.pell i ≤ P.y h.pell k := by
  classical
  let occurs (n : ℕ) := ∃ k : ℤ, P.y h.pell k=(n:ℚ)^2
  have hex : ∃ n, occurs n := by
    exact ⟨P.b.natAbs,0,by simp [abs_of_nonneg h.b_pos.le]⟩
  obtain ⟨i,hi⟩ := Nat.find_spec hex
  have hpos := P.y_pos h hn i
  have hnn : 0 < Nat.find hex := by
    by_contra! hh
    have he : Nat.find hex=0 := by omega
    rw [hi,he] at hpos
    norm_num at hpos
  refine ⟨i,Nat.find hex,by exact_mod_cast hnn,by simpa using hi,?_⟩
  intro k hs
  obtain ⟨z,hz⟩ := hs
  have hz' : occurs z.natAbs := ⟨k,by simpa [Int.natCast_natAbs,sq_abs] using hz⟩
  have hzle : (Nat.find hex:ℚ) ≤ (z.natAbs:ℚ) := by exact_mod_cast Nat.find_min' hex hz'
  rw [hi,hz]
  simpa [Int.natCast_natAbs,sq_abs] using pow_le_pow_left₀ (by positivity) hzle 2

end AnyBNormSquare.Reindex
