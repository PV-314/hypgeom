module

public import «JNT-2024».GrowthBounds

@[expose] public section

/-!
# Lemma 3.2 of the supplied 2026-11-06c manuscript

Source: `lem:Y-LB1`, lines 595--665. The proof follows the printed argument:
reuse JNT Lemma 3.5(b), its square-completion seed and recurrence induction;
then specialise the rate to `du²-3`, `0.99du²`, and `0.4du²`.
No new sequence representation or alternative growth argument is introduced.
-/

namespace AnyBNormSquare

open «JNT-2024»

/-- Lemma 3.2(a), including existence and uniqueness of the defined cutoff. -/
theorem lemma32a (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) :
    (∀ k : ℤ, ∃ n : ℤ, 0 < n ∧ 2 * P.y h.pell k = n) ∧
    StrictMono (fun n : ℕ => P.y h.pell n) ∧
    (∃! K : ℤ, P.IsNegativeCutoff h.pell K) ∧
    (∀ K : ℤ, P.IsNegativeCutoff h.pell K →
      StrictMono (fun n : ℕ => P.y h.pell (K + 1 - n))) :=
  P.lemma35b h hn

/-- The recurrence factor used in the proof of Lemma 3.2(b). -/
theorem sharp_rate_le_trace (P : Parameters) (h : P.Admissible) :
    P.d * (P.u : ℚ) ^ 2 - 3 ≤ P.traceCoeff - 1 := by
  unfold Parameters.traceCoeff
  rcases h.pell with hp | hp
  · have hq : (P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2 = 4 := by exact_mod_cast hp
    linarith
  · have hq : (P.t : ℚ) ^ 2 - P.d * (P.u : ℚ) ^ 2 = -4 := by exact_mod_cast hp
    linarith

/-- Lemma 3.2(b): both branches of (3.3), with the printed maximum exponent. -/
theorem lemma32b (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (K : ℤ) (hK : P.IsNegativeCutoff h.pell K) :
    P.LowerBoundsAtRate h.pell K (P.d * (P.u : ℚ) ^ 2 - 3) := by
  apply P.lowerBoundsAtRate h hn K hK _ ?_ (sharp_rate_le_trace P h)
  have hd : (5 : ℚ) ≤ P.d * (P.u : ℚ) ^ 2 := by exact_mod_cast P.five_le_du_sq h
  linarith

/-- Lemma 3.2(c), first assertion: exact decimal `0.99 = 99/100`. -/
theorem lemma32c (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (K : ℤ) (hK : P.IsNegativeCutoff h.pell K)
    (hc : P.epsilonNorm = 1 ∨ 300 ≤ P.d * P.u ^ 2) :
    P.LowerBoundsAtRate h.pell K ((99 / 100 : ℚ) * P.d * (P.u : ℚ) ^ 2) := by
  have hd : (0 : ℚ) ≤ P.d := by exact_mod_cast le_of_lt h.d_pos
  have hdu : (0 : ℚ) ≤ P.d * (P.u : ℚ) ^ 2 := mul_nonneg hd (sq_nonneg _)
  have hr : (0 : ℚ) ≤ (99 / 100 : ℚ) * P.d * (P.u : ℚ) ^ 2 := by nlinarith
  rcases hc with hc | hc
  · apply P.lowerBoundsAtRate h hn K hK _ hr
    rw [P.traceCoeff_eq_du_sq_add_norm, hc]
    linarith
  · have h300 : (300 : ℚ) ≤ P.d * (P.u : ℚ) ^ 2 := by exact_mod_cast hc
    have hrate : (99 / 100 : ℚ) * P.d * (P.u : ℚ) ^ 2 ≤
        P.d * (P.u : ℚ) ^ 2 - 3 := by linarith
    have hseed : 0 ≤ P.lowerSeed := by
      unfold Parameters.lowerSeed
      exact div_nonneg (mul_nonneg (abs_nonneg _) (sq_nonneg _))
        (mul_nonneg (by norm_num) (sq_nonneg _))
    have hb := lemma32b P h hn K hK
    constructor
    · intro k hk
      exact le_trans (mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hr hrate _) hseed) (hb.1 k hk)
    · intro k hk
      exact le_trans (mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hr hrate _) hseed) (hb.2 k hk)

/-- Lemma 3.2(c), last assertion, exactly the cited JNT result. -/
theorem lemma32c_uniform (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (K : ℤ) (hK : P.IsNegativeCutoff h.pell K) :
    P.LowerBoundsAtRate h.pell K ((2 / 5 : ℚ) * P.d * (P.u : ℚ) ^ 2) := by
  convert P.lemma35c h hn K hK using 1
  ring

end AnyBNormSquare
