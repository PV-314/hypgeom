module

public import AnyBNormSquare.Corollary16
public import «JNT-2024».RepeatedValues
public import «JNT-2024».IntroductionAudit

@[expose] public section
namespace AnyBNormSquare.Remarks
open «JNT-2024»

/-- The explicit three-square example in the remark after Theorem 1.3. -/
noncomputable def threshold (b N d : ℝ) : ℝ :=
  (78/100)*b^(20/9:ℝ)*N^(4/3:ℝ)/d^(5/6:ℝ)

private theorem cube_threshold {b N d : ℝ} (hb : 0<b) (hN : 0<N) (hd : 0<d) :
    (5732/100)*d^2/(b^4*N^2)*(threshold b N d)^3 =
    (2720132064/100000000)*b^(8/3:ℝ)*N^2/Real.sqrt d := by
  unfold threshold
  apply Real.log_injOn_pos (by apply Set.mem_Ioi.mpr; positivity) (by apply Set.mem_Ioi.mpr; positivity)
  simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_rpow, Real.log_pow, Real.log_sqrt]
  have h : Real.log (2720132064/100000000:ℝ) =
      Real.log (5732/100:ℝ) + 3*Real.log (78/100:ℝ) := by
    rw [show (2720132064/100000000:ℝ)=(5732/100)*(78/100)^3 by norm_num,
      Real.log_mul (by norm_num) (by norm_num),Real.log_pow]; norm_num
  simp (disch := positivity) only [Real.log_div] at h
  push_cast
  linarith only [h]

private theorem second_size {b N d : ℝ} (hb : 1≤b) (hd : 2≤d) (hNd : d≤N) :
    b^2*N/d ≤ threshold b N d := by
  have hb0 : 0<b := by linarith
  have hd0 : 0<d := by linarith
  have hN0 : 0<N := by linarith
  have hmult : threshold b N d = b^2*N/d *
      ((78/100)*b^(2/9:ℝ)*N^(1/3:ℝ)*d^(1/6:ℝ)) := by
    unfold threshold
    apply Real.log_injOn_pos (by apply Set.mem_Ioi.mpr; positivity) (by apply Set.mem_Ioi.mpr; positivity)
    simp (disch := positivity) only [Real.log_mul,Real.log_div,Real.log_rpow,Real.log_pow]
    ring
  rw [hmult]
  apply le_mul_of_one_le_right (by positivity)
  have hh : Real.sqrt d = d^(1/3:ℝ)*d^(1/6:ℝ) := by
    rw [← Real.rpow_add hd0,Real.sqrt_eq_rpow]; norm_num
  have hs := Real.sq_sqrt hd0.le
  have hs0 := Real.sqrt_nonneg d
  have hconst : 1 ≤ (78/100)*Real.sqrt d := by nlinarith
  rw [hh] at hconst
  have hp := Real.one_le_rpow hb (by norm_num : (0:ℝ) ≤ 2/9)
  have hcomp := Real.rpow_le_rpow hd0.le hNd (by norm_num : (0:ℝ) ≤ 1/3)
  calc
    1 ≤ (78/100)*1*d^(1/3:ℝ)*d^(1/6:ℝ) := by linarith only [hconst]
    _ ≤ _ := by gcongr

private theorem eligible_size (P : Parameters) (h : P.Admissible) (hn : P.normAlpha<0)
    {k : ℤ} (hs : IsIntegerSquare (P.y h.pell k)) (ht : (P.b:ℚ)^2 < P.y h.pell k)
    (hy : threshold P.b |(P.normAlpha:ℝ)| P.d < (P.y h.pell k:ℝ)) :
    max (4*Real.sqrt (|(P.normAlpha:ℝ)|/P.d)) ((P.b:ℝ)^2*|(P.normAlpha:ℝ)|/P.d)
      ≤ (P.y h.pell k:ℝ) := by
  obtain ⟨hb,hN,hd⟩ := Section4Proof.integer_bounds P h hn
  have hd0 : (0:ℝ)<P.d := by linarith
  have htR : (P.b:ℝ)^2 < (P.y h.pell k:ℝ) := by exact_mod_cast ht
  have hfour : (4:ℝ) ≤ (P.y h.pell k:ℝ) := by
    obtain ⟨z,hz⟩ := hs
    rw [hz] at ht ⊢
    have hz2 : P.b^2 < z^2 := by exact_mod_cast ht
    have h' : 4 ≤ z^2 := by
      have h0 := h.b_pos
      by_cases z ≤ -2 <;> by_cases 2 ≤ z <;> nlinarith
    exact_mod_cast h'
  by_cases hNd : |(P.normAlpha:ℝ)| ≤ P.d
  · have hx : |(P.normAlpha:ℝ)|/P.d ≤ 1 := (div_le_one hd0).mpr hNd
    refine max_le ?_ ?_
    · have := Real.sqrt_le_sqrt hx
      rw [Real.sqrt_one] at this
      linarith
    · rw [mul_div_assoc]
      exact (mul_le_of_le_one_right (sq_nonneg _) hx).trans htR.le
  · have hsize := (second_size hb hd (le_of_not_ge hNd)).trans hy.le
    have hb2 : 2 ≤ P.b := by
      by_contra! hh
      have he : P.b=1 := by have := h.b_pos; omega
      have habs : |(P.normAlpha:ℝ)| ≤ P.d := by
        rw [abs_of_neg (by exact_mod_cast hn)]
        exact_mod_cast (show -P.normAlpha ≤ P.d by
          simp [Parameters.normAlpha,he]; nlinarith [sq_nonneg P.a])
      contradiction
    have hb2R : (2:ℝ) ≤ P.b := by exact_mod_cast hb2
    have hx : 1 ≤ |(P.normAlpha:ℝ)|/P.d := (one_le_div hd0).mpr (le_of_not_ge hNd)
    have hroot : Real.sqrt (|(P.normAlpha:ℝ)|/P.d) ≤ |(P.normAlpha:ℝ)|/P.d := by
      have ha := Real.sq_sqrt (show 0 ≤ |(P.normAlpha:ℝ)|/P.d by positivity)
      have hh := Real.sqrt_nonneg (|(P.normAlpha:ℝ)|/P.d)
      nlinarith
    refine max_le (le_trans ?_ hsize) hsize
    rw [mul_div_assoc]
    exact mul_le_mul (by nlinarith) hroot (Real.sqrt_nonneg _) (sq_nonneg _)

theorem three_squares (hPrior : Hypergeometric.DenominatorEstimate4)
    (P : Parameters) (h : P.Admissible) (hn : P.normAlpha<0) (hNs : IsSquare (-P.normAlpha))
    (hm : SmallestInitialSquare P h.pell) (K : ℤ) (hK : P.IsNegativeCutoff h.pell K) :
    AtMostSquareValuesOn (P.y h.pell) (fun k => (1≤k ∨ k≤K) ∧
      threshold P.b |(P.normAlpha:ℝ)| P.d < (P.y h.pell k:ℝ)) 3 := by
  classical
  obtain ⟨S,hS,hcover⟩ := Section4Proof.theorem13_conditional hPrior P h hn hNs hm K hK
  let eligible (k : ℤ) := (1≤k ∨ k≤K) ∧ threshold P.b |(P.normAlpha:ℝ)| P.d < (P.y h.pell k:ℝ)
  have high {i j : ℤ} (hi : eligible i) (hj : eligible j) (hsi : IsIntegerSquare (P.y h.pell i))
      (hsj : IsIntegerSquare (P.y h.pell j)) (hij : P.y h.pell i < P.y h.pell j) :
      largeSquareThreshold P < (P.y h.pell j:ℝ) := by
    have hnz {k : ℤ} (hk : eligible k) : k ≠ 0 := by have := hK.1; rcases hk.1 with hh|hh <;> omega
    have hin : (P.b:ℚ)^2 < P.y h.pell i := by
      by_cases he : i=K
      · simpa only [he] using hK.2.1
      by_cases hp : i=1
      · simpa only [hp,P.y_zero] using P.y_zero_lt_y_one h
      exact Section5Opening.tail_gt_initial P h hn K hK (by rcases hi.1 with hh|hh <;> omega)
    have hgap := lemma33 P h hn hNs (hnz hi) (hnz hj) hsi hsj (by exact_mod_cast hij)
      (eligible_size P h hn hsi hin hi.2)
    obtain ⟨hb,hN,hd⟩ := Section4Proof.integer_bounds P h hn
    have hb0 : (0:ℝ)<P.b := by linarith
    have hd0 : (0:ℝ)<P.d := by linarith
    have hN0 : 0 < |(P.normAlpha:ℝ)| := by linarith
    have hB : 0≤threshold P.b |(P.normAlpha:ℝ)| P.d := by unfold threshold; positivity
    have hc := mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hB hi.2.le 3)
      (show 0 ≤ (5732/100:ℝ)*(P.d:ℝ)^2/((P.b:ℝ)^4*|(P.normAlpha:ℝ)|^2) by positivity)
    rw [cube_threshold hb0 hN0 hd0] at hc
    apply lt_of_le_of_lt (le_trans ?_ hc) hgap
    unfold largeSquareThreshold
    exact div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_right (by norm_num : (2643/100:ℝ) ≤ 2720132064/100000000)
        (by positivity)) (sq_nonneg _)) (Real.sqrt_nonneg _)
  by_cases hex : ∃ i, eligible i ∧ IsIntegerSquare (P.y h.pell i) ∧ (P.y h.pell i:ℝ) ≤ largeSquareThreshold P
  · obtain ⟨i,hi,hsi,hl⟩ := hex
    refine ⟨insert (P.y h.pell i) S,(Finset.card_insert_le _ _).trans (by omega),?_⟩
    intro j hj hsj
    rcases lt_trichotomy (P.y h.pell i) (P.y h.pell j) with hlt | he | hgt
    · exact Finset.mem_insert_of_mem (hcover j ⟨hj.1,high hi hj hsi hsj hlt⟩ hsj)
    · simp [he]
    · exact (not_lt_of_ge hl (high hj hi hsj hsi hgt)).elim
  · refine ⟨S,by omega,?_⟩
    intro k hk hs
    apply hcover k ⟨hk.1,?_⟩ hs
    exact lt_of_not_ge (fun hh => hex ⟨k,hk,hs,hh⟩)

/-- The remark after Corollary 1.6, for all positive b less than 25. -/
theorem admissible_b_lt_25 {b : ℤ} (hb : 0 < b) (h25 : b < 25) : AdmissibleB b := by
  let n : Fin 25 := ⟨b.toNat, by omega⟩
  let f (i : ℕ) := if 5 ∣ i then 5 else if 13 ∣ i then 13 else if 17 ∣ i then 17 else 1
  have cert : ∀ i : Fin 25, i.val ≠ 0 →
      i.val = f i * (i.val / f i) ∧ 0 < i.val / f i ∧
      (f i = 1 ∨ f i = 5 ∨ f i = 13 ∨ f i = 17) ∧
      ∀ p : Fin 25, p.val.Prime → p.val ∣ i.val / f i → p.val % 4 ≠ 1 := by decide
  have he : (n.val : ℤ) = b := Int.toNat_of_nonneg hb.le
  obtain ⟨hprod, hpos, hfac, hpr⟩ := cert n (by dsimp [n]; omega)
  refine ⟨f n, n.val / f n, he.symm.trans (congrArg (fun m : ℕ => (m:ℤ)) hprod),
    hpos, hfac, ?_⟩
  intro p hp hdvd
  have hle := (Nat.le_of_dvd hpos hdvd).trans (Nat.div_le_self n.val (f n))
  exact hpr ⟨p, lt_of_le_of_lt hle n.isLt⟩ hp hdvd

end AnyBNormSquare.Remarks
