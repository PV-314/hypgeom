module

public import AnyBNormSquare.Revision06g

@[expose] public section
namespace AnyBNormSquare.Section5Low

/-- Sections 5.1 and 5.2. Logarithms here check exactly the rearrangements of
positive powers in the printed argument. -/
private theorem log_round {x y : ℝ} (hx : 0 < x) (_hy : 0 < y) (m n : ℕ)
    (h : x ^ m < y ^ n) : (m : ℝ)*Real.log x < n*Real.log y := by
  simpa only [Real.log_pow] using Real.log_lt_log (pow_pos hx m) h

theorem case_one {b d N u y : ℝ} (hb : 0 < b) (hd : 0 < d)
    (hN : 0 < N) (hu : 0 < u)
    (hl : (99/400:ℝ)*N*d*u^4/b^2 ≤ y)
    (hh : y < (21/100:ℝ)*b^(26/11:ℝ)*N^(13/11:ℝ)/d^(12/11:ℝ))
    (h : (925/1000:ℝ)*b^(48/23:ℝ)*N^(2/23:ℝ)/u^(44/23:ℝ) < d) : False := by
  have hcmp := hl.trans_lt hh
  have hr := log_round (x := (21/100:ℝ)/(99/400)) (y := (925/1000:ℝ))
    (by norm_num) (by norm_num) 11 23 (by norm_num)
  have hc := Real.log_lt_log (by positivity) hcmp
  have ht := Real.log_lt_log (by positivity) h
  simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_rpow, Real.log_pow] at hr hc ht
  norm_num1 at hr hc ht
  linarith only [hr, hc, ht]

theorem case_two {b d N u y : ℝ} (hb : 0 < b) (hd : 0 < d)
    (hN : 0 < N) (hu : 0 < u)
    (hl : (99/400:ℝ)*N*d*u^4/b^2 ≤ y)
    (hh : y < b^(8/3:ℝ)*N^(7/6:ℝ)/(10*d^(7/6:ℝ)))
    (h : (66/100:ℝ)*b^(28/13:ℝ)*N^(1/13:ℝ)/u^(24/13:ℝ) < d) : False := by
  have hcmp := hl.trans_lt hh
  have hr := log_round (x := 1/(10*(99/400:ℝ))) (y := (66/100:ℝ))
    (by norm_num) (by norm_num) 6 13 (by norm_num)
  have hc := Real.log_lt_log (by positivity) hcmp
  have ht := Real.log_lt_log (by positivity) h
  simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_rpow, Real.log_pow, Real.log_one] at hr hc ht
  norm_num1 at hr hc ht
  linarith only [hr, hc, ht]


/-- (5.6), from (5.5) by the printed substitution N < d b^4. -/
theorem case_one_norm_free {b d N u y : ℝ} (hb : 0 < b) (hd : 0 < d)
    (hN : 0 < N) (hu : 0 < u) (hsub : N < d*b^4)
    (hl : (99/400:ℝ)*N*d*u^4/b^2 ≤ y)
    (hh : y < (21/100:ℝ)*b^(26/11:ℝ)*N^(13/11:ℝ)/d^(12/11:ℝ))
    (h : (92/100:ℝ)*b^(8/3:ℝ)/u^(44/21:ℝ) < d) : False := by
  apply case_one hb hd hN hu hl hh
  apply (Real.log_lt_log_iff (by positivity) hd).mp
  have hn := Real.log_lt_log hN hsub
  have ht := Real.log_lt_log (by positivity) h
  have hr := log_round (x := (925/1000:ℝ)) (y := (92/100:ℝ))
    (by norm_num) (by norm_num) 23 21 (by norm_num)
  simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_rpow, Real.log_pow] at hn ht hr ⊢
  norm_num1 at hn ht hr ⊢
  linarith only [hn, ht, hr]

/-- (5.8), from (5.7) by the same substitution. -/
theorem case_two_norm_free {b d N u y : ℝ} (hb : 0 < b) (hd : 0 < d)
    (hN : 0 < N) (hu : 0 < u) (hsub : N < d*b^4)
    (hl : (99/400:ℝ)*N*d*u^4/b^2 ≤ y)
    (hh : y < b^(8/3:ℝ)*N^(7/6:ℝ)/(10*d^(7/6:ℝ)))
    (h : (64/100:ℝ)*b^(8/3:ℝ)/u^2 < d) : False := by
  apply case_two hb hd hN hu hl hh
  apply (Real.log_lt_log_iff (by positivity) hd).mp
  have hn := Real.log_lt_log hN hsub
  have ht := Real.log_lt_log (by positivity) h
  have hr := log_round (x := (66/100:ℝ)) (y := (64/100:ℝ))
    (by norm_num) (by norm_num) 13 12 (by norm_num)
  simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_rpow, Real.log_pow] at hn ht hr ⊢
  norm_num1 at hn ht hr ⊢
  linarith only [hn, ht, hr]

end AnyBNormSquare.Section5Low
