module

public import AnyBNormSquare.Prerequisites

@[expose] public section
namespace AnyBNormSquare.Case42
open «JNT-2024»

/-- Exact checks of the three rounded constants used in Section 4.2. -/
theorem numerical_constants :
    2*(1257/1000 : ℝ) < (636/1000)*(3959/1000) ∧
    ((636/1000 : ℝ)*(2147/200))^4 < 2180 ∧
    (2180 : ℝ)*4^4 < (21/100)^22*(5732/100)^12 := by norm_num

/-- The norm factorization used when applying Lemma 2.1(b) to p/q. -/
theorem error_factor {p q θ : ℂ} (hq : q ≠ 0) :
    ‖q*θ-p‖ = ‖q‖*‖θ-p/q‖ := by
  rw [← norm_mul]
  congr 1
  rw [mul_sub,mul_div_cancel₀ _ hq]

/-- Substitution of the printed strict Q upper bound, before taking fourth powers. -/
theorem substitute_Q {Q U c t δ : ℝ} {r : ℕ}
    (hQ : 0 < Q) (hQU : Q < U) (hc : c < 1)
    (hl : (1-c)/((1257/1000 : ℝ)*Q^r) < t*δ) :
    (1-c)/((1257/1000 : ℝ)*U^r) < t*δ := by
  have hp := pow_le_pow_left₀ hQ.le hQU.le r
  have hh := div_le_div_of_nonneg_left (show 0 ≤ 1-c by linarith)
    (show 0 < (1257/1000 : ℝ)*Q^r by positivity)
    (mul_le_mul_of_nonneg_left hp (by norm_num : (0 : ℝ) ≤ 1257/1000))
  exact hh.trans_lt hl

/-- Rearrange the two strict comparisons and use exactly the printed 0.636. -/
theorem before_fourth {N d z t Q c δ : ℝ} {r : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hz : 0 < z) (ht : 0 < t)
    (hQ : 0 < Q) (hc : c < 1)
    (hl : (1-c)/((1257/1000 : ℝ)*Q^r) < t*δ)
    (hu : (3959/1000 : ℝ)*δ < 2*Real.sqrt N/(Real.sqrt d*z)) :
    z < ((636/1000 : ℝ)*Real.sqrt N/((1-c)*Real.sqrt d))*Q^r*t := by
  have hcp : 0 < 1-c := by linarith
  have hsd := Real.sqrt_pos.mpr hd
  have hl' := (div_lt_iff₀ (show 0 < (1257/1000 : ℝ)*Q^r by positivity)).mp hl
  have hu' := (lt_div_iff₀ (mul_pos hsd hz)).mp hu
  have h1 := mul_lt_mul_of_pos_right hl'
    (show 0 < (3959/1000 : ℝ)*Real.sqrt d*z by positivity)
  have h2 := mul_lt_mul_of_pos_right hu' (show 0 < t*(1257/1000 : ℝ)*Q^r by positivity)
  have hround := mul_lt_mul_of_pos_right numerical_constants.1
    (show 0 < Real.sqrt N*Q^r*t by positivity)
  have hh : z*((1-c)*Real.sqrt d) < (636/1000 : ℝ)*Real.sqrt N*Q^r*t := by
    nlinarith only [h1,h2,hround]
  have he : ((636/1000 : ℝ)*Real.sqrt N/((1-c)*Real.sqrt d))*Q^r*t =
    ((636/1000 : ℝ)*Real.sqrt N*Q^r*t)/((1-c)*Real.sqrt d) := by ring
  rw [he]
  exact (lt_div_iff₀ (mul_pos hcp hsd)).mpr hh

/-- The fourth-power step with the actual b-scaled comparison norm. -/
theorem fourth_power {N d y z t F Q c b : ℝ} {r : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hz : 0 < z) (hb : 0 < b)
    (hnorm : t^4*b^4=F^2*y*z)
    (hu : z < ((636/1000 : ℝ)*Real.sqrt N/((1-c)*Real.sqrt d))*Q^r*t) :
    z^3 < (N*F)^2*((636/1000 : ℝ)/((1-c)*b))^4/d^2*Q^(4*r)*y := by
  have hp := pow_lt_pow_left₀ hu hz.le (by decide : (4 : ℕ) ≠ 0)
  have ht4 : t^4=F^2*y*z/b^4 := (eq_div_iff (pow_ne_zero 4 (ne_of_gt hb))).mpr hnorm
  have hN4 : Real.sqrt N^4=N^2 := by rw [show (4 : ℕ)=2*2 from rfl,pow_mul,Real.sq_sqrt hN.le]
  have hd4 : Real.sqrt d^4=d^2 := by rw [show (4 : ℕ)=2*2 from rfl,pow_mul,Real.sq_sqrt hd.le]
  have he : (((636/1000 : ℝ)*Real.sqrt N/((1-c)*Real.sqrt d))*Q^r*t)^4 =
      ((N*F)^2*((636/1000 : ℝ)/((1-c)*b))^4/d^2*Q^(4*r)*y)*z := by
    simp only [mul_pow,div_pow,hN4,hd4,ht4,← pow_mul]
    rw [Nat.mul_comm r 4]
    simp only [div_eq_mul_inv, mul_inv_rev]
    ring
  rw [he] at hp
  apply (mul_lt_mul_iff_right₀ hz).mp
  convert hp using 1 <;> ring

/-- Expand the substituted Q bound to the powers printed in (4.15). -/
theorem expanded_bound {N d y z F M c b : ℝ} {r : ℕ}
    (hd : 0 < d) (hr : 1 ≤ r)
    (hu : z^3 < (N*F)^2*((636/1000 : ℝ)/((1-c)*b))^4/d^2*
      ((2147/100 : ℝ)*Real.sqrt d*y/M)^(4*r)*y) :
    z^3 < (N*F)^2*((636/1000 : ℝ)/((1-c)*b))^4*
      ((2147/100 : ℝ)/M)^(4*r)*d^(2*r-2)*y^(4*r+1) := by
  have hroot : Real.sqrt d^(4*r)=d^(2*r) := by
    rw [show 4*r=2*(2*r) by omega,pow_mul,Real.sq_sqrt hd.le]
  rw [pow_sub₀ d (ne_of_gt hd) (by omega : 2 ≤ 2*r),pow_add,pow_one]
  convert hu using 1
  simp only [mul_pow,div_pow,hroot]
  ring

/-- Specialise r=1 and M>=2, keeping the factors f_i*f_k and b. -/
theorem at_one {N y z F M c b : ℝ}
    (hN : 0 < N) (hy : 0 < y) (hF : 0 < F) (hb : 0 < b) (hM : 2 ≤ M) (hc : c < 1)
    (hu : z^3 < (N*F)^2*((636/1000 : ℝ)/((1-c)*b))^4*((2147/100 : ℝ)/M)^4*y^5) :
    z^3 < 2180/(b*(1-c))^4*(N*F)^2*y^5 := by
  have hMp : 0 < M := by linarith
  have hcp : 0 < 1-c := by linarith
  have hfrac : (2147/100 : ℝ)/M ≤ 2147/200 := by
    apply (div_le_iff₀ hMp).mpr
    nlinarith only [hM]
  have hp := pow_le_pow_left₀ (by positivity : 0 ≤ (2147/100 : ℝ)/M) hfrac 4
  have hh := mul_le_mul_of_nonneg_left hp
    (show 0 ≤ (N*F)^2*((636/1000 : ℝ)/((1-c)*b))^4*y^5 by positivity)
  have hr := mul_lt_mul_of_pos_right numerical_constants.2.1
    (show 0 < (N*F)^2*y^5/(b*(1-c))^4 by positivity)
  apply hu.trans_le
  calc
    _ ≤ (N*F)^2*((636/1000 : ℝ)/((1-c)*b))^4*(2147/200)^4*y^5 := by nlinarith only [hh]
    _ ≤ _ := le_of_lt (by convert hr using 1 <;> simp only [mul_pow,div_pow] <;> ring)

/-- Apply f_i*f_k<=b^4, exactly as in (4.17). -/
theorem eliminate_f {N y z F c b : ℝ} (hy : 0 < y) (hb : 0 < b)
    (hF : 0 ≤ F) (hFb : F ≤ b^4)
    (hu : z^3 < 2180/(b*(1-c))^4*(N*F)^2*y^5) :
    z^3 < 2180/(1-c)^4*N^2*b^4*y^5 := by
  have hsq := pow_le_pow_left₀ hF hFb 2
  have hh := mul_le_mul_of_nonneg_left hsq (show 0 ≤ 2180/(b*(1-c))^4*N^2*y^5 by positivity)
  apply hu.trans_le
  convert hh using 1 <;> simp only [mul_pow] <;> field_simp

/-- Two applications of the cubic gap principle, in the printed order. -/
theorem gap_twice {G x y z : ℝ} (hG : 0 < G) (hx : 0 < x)
    (hxy : G*x^3 < y) (hyz : G*y^3 < z) :
    G*x^3 < y ∧ G*y^3 < z ∧ G^4*x^9 < z := by
  have hp := pow_lt_pow_left₀ hxy (by positivity) (by decide : (3 : ℕ) ≠ 0)
  have hm := mul_lt_mul_of_pos_left hp hG
  refine ⟨hxy,hyz,lt_trans ?_ hyz⟩
  convert hm using 1; ring

/-- Cube the iterated gap bound and cancel the common y_i^5 factor. -/
theorem cancel_fifth {G A x z : ℝ} (hG : 0 < G) (hx : 0 < x)
    (hl : G^4*x^9 < z) (hu : z^3 < A*x^5) : G^12*x^22 < A := by
  have hp := pow_lt_pow_left₀ hl (by positivity) (by decide : (3 : ℕ) ≠ 0)
  have hh := hp.trans hu
  apply (mul_lt_mul_iff_right₀ (pow_pos hx 5)).mp
  convert hh using 1 <;> ring

/-- The printed 22nd-root rearrangement at c=3/4, with exact real powers. -/
theorem root_bound {b N d y : ℝ} (hb : 0 < b) (hN : 0 < N) (hd : 0 < d) (hy : 0 < y)
    (hu : ((5732/100 : ℝ)*d^2/(b^4*N^2))^12*y^22 < 2180/(1-(3/4 : ℝ))^4*N^2*b^4) :
    y < (21/100 : ℝ)*b^(26/11 : ℝ)*N^(13/11 : ℝ)/d^(12/11 : ℝ) := by
  have hden : 0 < b^48*N^24 := by positivity
  have hpow : y^22 < (2180*4^4 : ℝ)*b^52*N^26/((5732/100 : ℝ)^12*d^24) := by
    have hh := mul_lt_mul_of_pos_right hu hden
    apply (lt_div_iff₀ (by positivity : 0 < (5732/100 : ℝ)^12*d^24)).mpr
    convert hh using 1 <;> norm_num <;> field_simp; ring
  have hr := mul_lt_mul_of_pos_right numerical_constants.2.2
    (show 0 < b^52*N^26/((5732/100 : ℝ)^12*d^24) by positivity)
  have hround : (2180*4^4 : ℝ)*b^52*N^26/((5732/100 : ℝ)^12*d^24) <
      (21/100 : ℝ)^22*b^52*N^26/d^24 := by
    convert hr using 1 <;> field_simp
  have hexp : ((21/100 : ℝ)*b^(26/11 : ℝ)*N^(13/11 : ℝ)/d^(12/11 : ℝ))^22 =
      (21/100 : ℝ)^22*b^52*N^26/d^24 := by
    rw [div_pow,mul_pow,mul_pow,← Real.rpow_mul_natCast hb.le,
      ← Real.rpow_mul_natCast hN.le,← Real.rpow_mul_natCast hd.le]
    norm_num
  apply (pow_lt_pow_iff_left₀ hy.le (by positivity) (by decide : (22 : ℕ) ≠ 0)).mp
  rw [hexp]
  exact hpow.trans hround

open Approximation Prerequisites

/-- The same least positive approximation index as Lemma 2.1. -/
noncomputable def index {P : Parameters} {h : P.Admissible} {i j : ℤ}
    (a : Prepared P h i j) {c : ℝ} (hc : 0 < c) : ℕ :=
  firstIndex (Q := Section2.Q (-1) (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha))
    (ℓ := Section2.ell (-1) (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha))
    a.E_gt_one hc (Section2.gaussianEmbedding a.denominator)

/-- The fourth power of the actual comparison denominator, retaining b. -/
theorem norm_fourth (P : Parameters) (h : P.Admissible) {i j : ℤ}
    (a : Prepared P h i j) :
    ‖Section2.gaussianEmbedding a.denominator‖^4*(P.b : ℝ)^4 =
      (a.left.f*a.right.f)^2*a.left.y*a.right.y := by
  have hb : (P.b : ℝ) ≠ 0 := by exact_mod_cast ne_of_gt h.b_pos
  have hroot : ((a.left.y*a.right.y)^(1/4 : ℝ))^4 = a.left.y*a.right.y := by
    rw [← Real.rpow_mul_natCast (mul_pos a.left.y_pos a.right.y_pos).le]
    norm_num
  rw [a.denominator_norm,div_pow,mul_pow,hroot]
  rw [show (4 : ℕ)=2*2 from rfl,pow_mul,Real.sq_sqrt (mul_pos a.left.f_pos a.right.f_pos).le]
  field_simp

/-- Equation (4.14): both strict comparisons, using the actual JNT approximants.
The numerator here already includes the manuscript's phase eta. -/
theorem error_chain (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha)) {i j : ℤ}
    (a : Prepared P h i j)
    (data : Section2.PaperApproximants (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha))
    {c : ℝ} (hc : 0 < c) (hc1 : c < 1)
    (hne : data.pr (index a hc)*a.denominator-data.qr (index a hc)*a.numerator ≠ 0) :
    let δ := ‖Section2.omega (-1) (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha)^(1/4 : ℂ)-
      Section2.gaussianEmbedding a.numerator/Section2.gaussianEmbedding a.denominator‖
    (3959/1000 : ℝ)*δ < 2*Real.sqrt |(P.normAlpha : ℝ)|/(Real.sqrt P.d*a.right.y) ∧
    (3959/1000 : ℝ)*(1-c)*P.b /
      (paperK0*Section2.Q (-1) (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha)^(index a hc)*
        Real.sqrt (a.left.f*a.right.f)*(a.left.y*a.right.y)^(1/4 : ℝ)) < (3959/1000 : ℝ)*δ := by
  dsimp only
  have hco := sequence_coordinates P h hn hNs a.hx a.hy
  have hu₂ : 2*unitPowerNorm P i*squareFactor P.normAlpha ≠ 0 := by
    simpa only [mul_assoc] using mul_ne_zero (by decide : (2 : ℤ) ≠ 0) hco.2.1
  have hq : Section2.gaussianEmbedding a.denominator ≠ 0 :=
    (map_ne_zero Section2.gaussianEmbedding).mpr a.denominator_ne
  have hl := (Construction.apply_lemma21 data hu₂ a.numerator a.denominator
    a.numerator_integral a.denominator_integral
    (by rintro ⟨_,hq⟩; exact a.denominator_ne hq) a.E_gt_one a.Q_gt_one hc hc1).2 hne
  rw [error_factor hq] at hl
  have he : Section2.omega (-1) (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha) =
      P.sequenceOmega h.pell i := by simpa only [mul_assoc] using hco.2.2.2
  constructor
  · simpa only [he,a.numerator_embedding,a.denominator_embedding,mul_div_assoc] using a.comparison_bound
  · have ht : 0 < ‖Section2.gaussianEmbedding a.denominator‖ := norm_pos_iff.mpr hq
    rw [mul_comm ‖Section2.gaussianEmbedding a.denominator‖] at hl
    have hh := (div_lt_iff₀ ht).mpr hl
    have hh' := mul_lt_mul_of_pos_left hh (by norm_num : (0 : ℝ) < 3959/1000)
    rw [a.denominator_norm] at hh'
    convert hh' using 1; dsimp [index]; field_simp

/-- The general r>=1 bound (4.15), also retained for Section 4.4.
Q is substituted before fourth powers, exactly as in the manuscript. -/
theorem general_bound (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha)) {i j : ℤ}
    (a : Prepared P h i j)
    (hlarge : 4*|(P.normAlpha : ℝ)|/Real.sqrt P.d ≤ (P.y h.pell i : ℝ))
    (data : Section2.PaperApproximants (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha))
    {c : ℝ} (hc : 0 < c) (hc1 : c < 1)
    (hne : data.pr (index a hc)*a.denominator-data.qr (index a hc)*a.numerator ≠ 0) :
    let r := index a hc
    let M := normalizerProduct (-1) (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha)
    a.right.y^3 < (|(P.normAlpha : ℝ)| *(a.left.f*a.right.f))^2*
      ((636/1000 : ℝ)/((1-c)*P.b))^4*((2147/100 : ℝ)/M)^(4*r)*
      (P.d : ℝ)^(2*r-2)*a.left.y^(4*r+1) := by
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hb : (0 : ℝ) < P.b := by exact_mod_cast h.b_pos
  have hN : 0 < |(P.normAlpha : ℝ)| := abs_pos.mpr (by exact_mod_cast ne_of_lt hn)
  have hco := sequence_coordinates P h hn hNs a.hx a.hy
  have hu₂ : 2*unitPowerNorm P i*squareFactor P.normAlpha ≠ 0 := by
    simpa only [mul_assoc] using mul_ne_zero (by decide : (2 : ℤ) ≠ 0) hco.2.1
  have hq : Section2.gaussianEmbedding a.denominator ≠ 0 := (map_ne_zero Section2.gaussianEmbedding).mpr a.denominator_ne
  have hl := (Construction.apply_lemma21 data hu₂ a.numerator a.denominator
    a.numerator_integral a.denominator_integral
    (by rintro ⟨_,hq⟩; exact a.denominator_ne hq) a.E_gt_one a.Q_gt_one hc hc1).2 hne
  rw [error_factor hq] at hl
  have hY : 4*|(P.normAlpha : ℝ)|/Real.sqrt P.d ≤ (a.Y : ℝ) := by
    simpa only [a.hy,Rat.cast_intCast] using hlarge
  have hpars := application_parameters P h hn hNs a.hx a.hy hY
  have hy : (a.Y : ℝ) = a.left.y := by rw [a.left_certificate.1,a.hy,Rat.cast_intCast]
  have hQU := hpars.2.2.2.2.2.1
  rw [hy] at hQU
  have hQ := lt_trans (by norm_num : (0 : ℝ) < 1) a.Q_gt_one
  have hl' := substitute_Q hQ hQU hc1 hl
  have hu := before_fourth hN hd a.right.y_pos (norm_pos_iff.mpr hq)
    (hQ.trans hQU) hc1 hl' (error_chain P h hn hNs a data hc hc1 hne).1
  have hfour := fourth_power hN hd a.right.y_pos hb (norm_fourth P h a) hu
  exact expanded_bound hd (firstIndex_spec a.E_gt_one hc _).1
    (by simpa only [mul_assoc,index] using hfour)

/-- Equations (4.16) and (4.17): r=1, M>=2, then f_i*f_k<=b^4. -/
theorem first_case_upper (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha)) {i j : ℤ}
    (a : Prepared P h i j)
    (hlarge : 4*|(P.normAlpha : ℝ)|/Real.sqrt P.d ≤ (P.y h.pell i : ℝ))
    (data : Section2.PaperApproximants (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha))
    {c : ℝ} (hc : 0 < c) (hc1 : c < 1) (hr : index a hc = 1)
    (hne : data.pr (index a hc)*a.denominator-data.qr (index a hc)*a.numerator ≠ 0) :
    a.right.y^3 < 2180/((P.b : ℝ)*(1-c))^4*
      (|(P.normAlpha : ℝ)| *(a.left.f*a.right.f))^2*a.left.y^5 ∧
    a.right.y^3 < 2180/(1-c)^4*(P.normAlpha : ℝ)^2*(P.b : ℝ)^4*a.left.y^5 := by
  have hb : (0 : ℝ) < P.b := by exact_mod_cast h.b_pos
  have hN : 0 < |(P.normAlpha : ℝ)| := abs_pos.mpr (by exact_mod_cast ne_of_lt hn)
  have hu := general_bound P h hn hNs a hlarge data hc hc1 hne
  dsimp only at hu
  rw [hr] at hu
  simp only [Nat.sub_self,pow_zero,mul_one] at hu
  have hY : 4*|(P.normAlpha : ℝ)|/Real.sqrt P.d ≤ (a.Y : ℝ) := by
    simpa only [a.hy,Rat.cast_intCast] using hlarge
  have hM := (application_parameters P h hn hNs a.hx a.hy hY).2.1
  have hone := at_one hN a.left.y_pos (mul_pos a.left.f_pos a.right.f_pos) hb hM hc1 hu
  refine ⟨hone,?_⟩
  simpa only [sq_abs] using eliminate_f a.left.y_pos hb
    (mul_pos a.left.f_pos a.right.f_pos).le a.f_product hone

/-- Both applications of Lemma 3.3, including the intermediate nonzero index
and the propagation of the size hypothesis from the first square to the second. -/
theorem sequence_gaps (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha))
    (hmin : SmallestInitialSquare P h.pell) (K : ℤ) (hK : P.IsNegativeCutoff h.pell K)
    {i j k : ℤ} (hi : 1 ≤ i ∨ i ≤ K)
    (hsi : IsIntegerSquare (P.y h.pell i)) (hsj : IsIntegerSquare (P.y h.pell j))
    (hsk : IsIntegerSquare (P.y h.pell k))
    (hij : (P.y h.pell i : ℝ) < (P.y h.pell j : ℝ))
    (hjk : (P.y h.pell j : ℝ) < (P.y h.pell k : ℝ))
    (hsize : max (4*|(P.normAlpha : ℝ)|/Real.sqrt P.d)
      ((P.b : ℝ)^2*|(P.normAlpha : ℝ)|/P.d) ≤ (P.y h.pell i : ℝ)) :
    let G := (5732/100 : ℝ)*(P.d : ℝ)^2/((P.b : ℝ)^4*|(P.normAlpha : ℝ)|^2)
    G*(P.y h.pell i : ℝ)^3 < (P.y h.pell j : ℝ) ∧
    G*(P.y h.pell j : ℝ)^3 < (P.y h.pell k : ℝ) ∧
    G^4*(P.y h.pell i : ℝ)^9 < (P.y h.pell k : ℝ) := by
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hb : (0 : ℝ) < P.b := by exact_mod_cast h.b_pos
  have hN : 0 < |(P.normAlpha : ℝ)| := abs_pos.mpr (by exact_mod_cast ne_of_lt hn)
  have hi0 : i ≠ 0 := by have hh := hK.1; omega
  have hbase : (P.b : ℝ)^2 ≤ (P.y h.pell i : ℝ) := by exact_mod_cast hmin i hsi
  have nonzero {m : ℤ} (hm : (P.y h.pell i : ℝ) < (P.y h.pell m : ℝ)) : m ≠ 0 := by
    intro he
    rw [he,P.y_zero] at hm
    push_cast at hm
    linarith
  have hj0 := nonzero hij
  have hk0 := nonzero (hij.trans hjk)
  have hcoord := threshold_implies_coordinate_size P h hn ((le_max_left _ _).trans hsize)
  have hlarge : max (4*Real.sqrt (|(P.normAlpha : ℝ)|/P.d))
      ((P.b : ℝ)^2*|(P.normAlpha : ℝ)|/P.d) ≤ (P.y h.pell i : ℝ) :=
    max_le hcoord ((le_max_right _ _).trans hsize)
  exact gap_twice (by positivity) (lt_of_lt_of_le (by positivity) hcoord)
    (lemma33 P h hn hNs hi0 hj0 hsi hsj hij hlarge)
    (lemma33 P h hn hNs hj0 hk0 hsj hsk hjk (hlarge.trans hij.le))

/-- The conclusion (4.18) for the actual prepared comparison and actual
approximants. All size, square and normalization assumptions are retained. -/
theorem first_case (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha))
    (hmin : SmallestInitialSquare P h.pell) (K : ℤ) (hK : P.IsNegativeCutoff h.pell K)
    {i j k : ℤ} (hi : 1 ≤ i ∨ i ≤ K)
    (hsi : IsIntegerSquare (P.y h.pell i)) (hsj : IsIntegerSquare (P.y h.pell j))
    (hsk : IsIntegerSquare (P.y h.pell k))
    (hij : (P.y h.pell i : ℝ) < (P.y h.pell j : ℝ))
    (hjk : (P.y h.pell j : ℝ) < (P.y h.pell k : ℝ))
    (hsize : max (4*|(P.normAlpha : ℝ)|/Real.sqrt P.d)
      ((P.b : ℝ)^2*|(P.normAlpha : ℝ)|/P.d) ≤ (P.y h.pell i : ℝ))
    (a : Prepared P h i k)
    (data : Section2.PaperApproximants (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha))
    (hr : index a (by norm_num : (0 : ℝ) < 3/4) = 1)
    (hne : data.pr (index a (by norm_num : (0 : ℝ) < 3/4))*a.denominator-
      data.qr (index a (by norm_num : (0 : ℝ) < 3/4))*a.numerator ≠ 0) :
    (P.y h.pell i : ℝ) < (21/100 : ℝ)*(P.b : ℝ)^(26/11 : ℝ)*
      |(P.normAlpha : ℝ)|^(13/11 : ℝ)/(P.d : ℝ)^(12/11 : ℝ) := by
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hb : (0 : ℝ) < P.b := by exact_mod_cast h.b_pos
  have hN : 0 < |(P.normAlpha : ℝ)| := abs_pos.mpr (by exact_mod_cast ne_of_lt hn)
  have hy : 0 < (P.y h.pell i : ℝ) := by rw [← a.left_certificate.1]; exact a.left.y_pos
  have hu := (first_case_upper P h hn hNs a ((le_max_left _ _).trans hsize)
    data (by norm_num : (0 : ℝ) < 3/4) (by norm_num) hr hne).2
  rw [a.left_certificate.1,a.right_certificate.1] at hu
  have hg := (sequence_gaps P h hn hNs hmin K hK hi hsi hsj hsk hij hjk hsize).2.2
  have hc := cancel_fifth (by positivity) hy hg hu
  apply root_bound hb hN hd hy
  simpa only [sq_abs] using hc

/-- End-to-end Section 4.2 checkpoint. Construct the representations and JNT
approximants from the manuscript hypotheses. DenominatorEstimate4 is an
explicit unproved premise; the r=1 and nonexact case conditions remain explicit. -/
theorem first_case_conditional (hPrior : Hypergeometric.DenominatorEstimate4)
    (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha))
    (hmin : SmallestInitialSquare P h.pell) (K : ℤ) (hK : P.IsNegativeCutoff h.pell K)
    {i j k : ℤ} (hi : 1 ≤ i ∨ i ≤ K)
    (hsi : IsIntegerSquare (P.y h.pell i)) (hsj : IsIntegerSquare (P.y h.pell j))
    (hsk : IsIntegerSquare (P.y h.pell k))
    (hij : (P.y h.pell i : ℝ) < (P.y h.pell j : ℝ))
    (hjk : (P.y h.pell j : ℝ) < (P.y h.pell k : ℝ))
    (hsize : max (4*|(P.normAlpha : ℝ)|/Real.sqrt P.d)
      ((P.b : ℝ)^2*|(P.normAlpha : ℝ)|/P.d) ≤ (P.y h.pell i : ℝ)) :
    ∃ a : Prepared P h i k,
    ∃ data : Section2.PaperApproximants (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha),
    let r := index a (by norm_num : (0 : ℝ) < 3/4)
    r = 1 → data.pr r*a.denominator-data.qr r*a.numerator ≠ 0 →
    (P.y h.pell i : ℝ) < (21/100 : ℝ)*(P.b : ℝ)^(26/11 : ℝ)*
      |(P.normAlpha : ℝ)|^(13/11 : ℝ)/(P.d : ℝ)^(12/11 : ℝ) := by
  obtain ⟨a⟩ := prepare P h hn hNs hmin K hK hi hsi hsk (hij.trans hjk) hsize
  obtain ⟨data,_⟩ := apply_prepared hPrior P h hn hNs a
  exact ⟨a,data,first_case P h hn hNs hmin K hK hi hsi hsj hsk hij hjk hsize a data⟩

end AnyBNormSquare.Case42
