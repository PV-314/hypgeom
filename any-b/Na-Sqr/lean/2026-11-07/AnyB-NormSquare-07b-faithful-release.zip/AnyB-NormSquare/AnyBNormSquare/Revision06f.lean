module

public import AnyBNormSquare.Construction
public import «JNT-2024».Section4Parameters
public import «JNT-2024».Section4Prerequisites

@[expose] public section
namespace AnyBNormSquare.Revision06f
open «JNT-2024»

/-- The printed (4.9) chain in 06f. The first comparison is non-strict,
exactly as authorised by the author. No equality-exclusion argument is used. -/
theorem Q_lower_chain {M L x : ℝ} (hM : 0 < M) (hL : 0 < L)
    (hx : (15 / 16 : ℝ) * L ^ 2 ≤ x ^ 2) (hML : M ≤ L) :
    2 * Real.exp (168 / 100) * (1 + Real.sqrt (9375 / 10000)) * L / M ≤
        2 * Real.exp (168 / 100) * (|x| + L) / M ∧
    (2112 / 100 : ℝ) * L / M <
        2 * Real.exp (168 / 100) * (1 + Real.sqrt (9375 / 10000)) * L / M ∧
    (2112 / 100 : ℝ) ≤ (2112 / 100 : ℝ) * L / M := by
  have hs : 0 ≤ Real.sqrt (9375 / 10000 : ℝ) := Real.sqrt_nonneg _
  have hs2 : Real.sqrt (9375 / 10000 : ℝ) ^ 2 = 15 / 16 := by
    rw [Real.sq_sqrt (by norm_num)]; norm_num
  have hsl : (9682 / 10000 : ℝ) < Real.sqrt (9375 / 10000) := by nlinarith
  have hxl : Real.sqrt (9375 / 10000 : ℝ) * L ≤ |x| := by
    apply (sq_le_sq₀ (mul_nonneg hs hL.le) (abs_nonneg x)).mp
    rw [mul_pow, hs2, sq_abs]
    exact hx
  have he : 0 < Real.exp (168 / 100 : ℝ) := Real.exp_pos _
  have heb : (107311 / 20000 : ℝ) < Real.exp (168 / 100) := by
    convert Section4.exp_168_bounds.1 using 1; norm_num
  have hnum : (2112 / 100 : ℝ) <
      2 * Real.exp (168 / 100) * (1 + Real.sqrt (9375 / 10000)) := by
    have hm := mul_lt_mul_of_pos_left hsl he
    nlinarith only [hm, heb]
  refine ⟨?_, ?_, ?_⟩
  · apply (div_le_div_iff_of_pos_right hM).mpr
    have hm := mul_le_mul_of_nonneg_left hxl (show 0 ≤ 2 * Real.exp (168 / 100 : ℝ) by positivity)
    nlinarith only [hm]
  · exact (div_lt_div_iff_of_pos_right hM).mpr (mul_lt_mul_of_pos_right hnum hL)
  · apply (le_div_iff₀ hM).mpr
    exact mul_le_mul_of_nonneg_left hML (by norm_num)

/-- (4.9) for the actual pinned Gaussian Q, retaining the paper's weak
coordinate estimate and all three comparisons. -/
theorem gaussian_Q_lower_chain {X Z : ℤ} {N L : ℝ}
    (hL : 0 < L) (hZ : (Z : ℝ) ^ 2 = N)
    (hcoord : (X : ℝ) ^ 2 + N = L ^ 2)
    (hx : (15 / 16 : ℝ) * L ^ 2 ≤ (X : ℝ) ^ 2)
    (hM : 0 < Approximation.normalizerProduct (-1) (2 * X) (2 * Z))
    (hML : Approximation.normalizerProduct (-1) (2 * X) (2 * Z) ≤ L) :
    let M := Approximation.normalizerProduct (-1) (2 * X) (2 * Z)
    2 * Real.exp (168 / 100) * (1 + Real.sqrt (9375 / 10000)) * L / M ≤
        Section2.Q (-1) (2 * X) (2 * Z) ∧
    (2112 / 100 : ℝ) * L / M <
        2 * Real.exp (168 / 100) * (1 + Real.sqrt (9375 / 10000)) * L / M ∧
    (2112 / 100 : ℝ) ≤ (2112 / 100 : ℝ) * L / M := by
  rw [(Section4.gaussian_parameters hL hZ hcoord).2]
  convert Q_lower_chain hM hL hx hML using 1; norm_num

/-- The unchanged consequence: Q>21.12>1. -/
theorem gaussian_Q_gt {X Z : ℤ} {N L : ℝ}
    (hL : 0 < L) (hZ : (Z : ℝ) ^ 2 = N)
    (hcoord : (X : ℝ) ^ 2 + N = L ^ 2)
    (hx : (15 / 16 : ℝ) * L ^ 2 ≤ (X : ℝ) ^ 2)
    (hM : 0 < Approximation.normalizerProduct (-1) (2 * X) (2 * Z))
    (hML : Approximation.normalizerProduct (-1) (2 * X) (2 * Z) ≤ L) :
    (2112 / 100 : ℝ) < Section2.Q (-1) (2 * X) (2 * Z) ∧
      1 < Section2.Q (-1) (2 * X) (2 * Z) := by
  have h := gaussian_Q_lower_chain hL hZ hcoord hx hM hML
  have hq := lt_of_le_of_lt h.2.2 (lt_of_lt_of_le h.2.1 h.1)
  exact ⟨hq, lt_trans (by norm_num) hq⟩

end AnyBNormSquare.Revision06f
