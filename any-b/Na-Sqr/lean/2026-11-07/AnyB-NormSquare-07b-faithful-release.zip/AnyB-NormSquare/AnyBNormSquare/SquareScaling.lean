module

public import AnyBNormSquare.Targets
public import «JNT-2024».SquarefreePart
public import «JNT-2024».Integrality

@[expose] public section
namespace AnyBNormSquare.SquareScaling
open «JNT-2024»

/-- Inverse of the manuscript's simultaneous division of a and b. -/
def scaled (P : Parameters) (c : ℤ) : Parameters :=
  {P with a := c^2*P.a, b := c*P.b}

theorem scaled_pell (P : Parameters) (c : ℤ) (hp : P.Pell) : (scaled P c).Pell := hp

theorem scaled_y (P : Parameters) (c : ℤ) (hp : P.Pell) (k : ℤ) :
    (scaled P c).y hp k = (c : ℚ)^2 * P.y hp k := by
  let z : P.Algebra := (P.stepUnit hp ^ k : P.Algebraˣ)
  change ((show P.Algebra from (scaled P c).alpha) * z).im = (c : ℚ)^2*(P.alpha * z).im
  simp only [QuadraticAlgebra.im_mul,Parameters.alpha,scaled]
  push_cast
  ring

theorem scaled_norm (P : Parameters) (c : ℤ) :
    (scaled P c).normAlpha = c^4*P.normAlpha := by
  dsimp [Parameters.normAlpha,scaled]
  ring

/-- Reuse JNT integrality to preserve integer squares, not only rational squares. -/
theorem scaled_square_iff (P : Parameters) (c : ℤ) (hc : c ≠ 0) (hp : P.Pell) (k : ℤ) :
    IsIntegerSquare ((scaled P c).y hp k) ↔ IsIntegerSquare (P.y hp k) := by
  rw [← (scaled P c).rational_square_iff_integer_square hp k,
    ← P.rational_square_iff_integer_square hp k,scaled_y]
  constructor
  · rintro ⟨v,hv⟩
    refine ⟨v/c,?_⟩
    have hcz : (c : ℚ) ≠ 0 := by exact_mod_cast hc
    field_simp
    nlinarith only [hv]
  · rintro ⟨v,hv⟩
    refine ⟨c*v,?_⟩
    rw [hv]
    ring

theorem scaled_cutoff_iff (P : Parameters) (c : ℤ) (hc : c ≠ 0) (hp : P.Pell) (K : ℤ) :
    (scaled P c).IsNegativeCutoff hp K ↔ P.IsNegativeCutoff hp K := by
  have hp2 : (0 : ℚ) < (c : ℚ)^2 := sq_pos_of_ne_zero (by exact_mod_cast hc)
  simp only [Parameters.IsNegativeCutoff,scaled_y P c hp,
    show (scaled P c).b = c*P.b from rfl,Int.cast_mul,mul_pow,
    mul_lt_mul_iff_right₀ hp2,mul_le_mul_iff_right₀ hp2]

theorem scaled_smallest_iff (P : Parameters) (c : ℤ) (hc : c ≠ 0) (hp : P.Pell) :
    SmallestInitialSquare (scaled P c) hp ↔ SmallestInitialSquare P hp := by
  have hp2 : (0 : ℚ) < (c : ℚ)^2 := sq_pos_of_ne_zero (by exact_mod_cast hc)
  unfold SmallestInitialSquare
  simp only [scaled_square_iff P c hc hp]
  simp only [scaled_y P c hp,show (scaled P c).b = c*P.b from rfl,
    Int.cast_mul,mul_pow,mul_le_mul_iff_right₀ hp2]

/-- Choose exactly the square factor of gcd(a,b²), using the pinned JNT definition. -/
theorem divide_square_part (a b : ℤ) (ha : 0 < a) (hb : 0 < b) :
    ∃ c A B : ℤ, 0 < c ∧ 0 < A ∧ 0 < B ∧ a=c^2*A ∧ b=c*B ∧
      Squarefree (Int.gcd A (B^2)) := by
  let g : ℤ := Int.gcd a (b^2)
  let c : ℤ := squareFactor g
  have hg : 0 < g := by
    dsimp [g]
    exact_mod_cast (Int.gcd_pos_of_ne_zero_left (b^(2 : ℕ)) (ne_of_gt ha))
  have hc : 0 < c := squareFactor_pos (ne_of_gt hg)
  have hfactor : c^2*squarefreePart g=g := squareFactor_sq_mul g
  have hcg : c^2 ∣ g := ⟨squarefreePart g,hfactor.symm⟩
  have hca : c^2 ∣ a := hcg.trans (Int.gcd_dvd_left a (b^2))
  have hcb2 : c^2 ∣ b^2 := hcg.trans (Int.gcd_dvd_right a (b^2))
  have hcb : c ∣ b := (Int.pow_dvd_pow_iff (by norm_num : (2 : ℕ) ≠ 0)).mp hcb2
  obtain ⟨A,hA⟩ := hca
  obtain ⟨B,hB⟩ := hcb
  have hAp : 0 < A := by nlinarith [sq_pos_of_pos hc]
  have hBp : 0 < B := by nlinarith
  have he : g=c^2*(Int.gcd A (B^2) : ℤ) := by
    dsimp [g]
    rw [hA,hB,mul_pow,Int.gcd_mul_left]
    simp only [Int.natCast_mul,Int.natCast_natAbs,abs_of_nonneg (sq_nonneg c)]
  have hpart : squarefreePart g=(Int.gcd A (B^2) : ℤ) := by
    apply (mul_left_cancel₀ (ne_of_gt (sq_pos_of_pos hc)))
    exact hfactor.trans he
  have hs : Squarefree (Int.gcd A (B^2) : ℤ) := hpart ▸ squarefreePart_squarefree g
  exact ⟨c,A,B,hc,hAp,hBp,hA,hB,by simpa only [Int.squarefree_natCast] using hs⟩

/-- The normalized parameters satisfy the same standing arithmetic assumptions. -/
theorem normalized_parameters (P : Parameters) (h : P.Admissible) :
    ∃ c : ℤ, ∃ Q : Parameters, 0 < c ∧ P=scaled Q c ∧ Q.Admissible ∧
      Squarefree (Int.gcd Q.a (Q.b^2)) := by
  obtain ⟨c,A,B,hc,hA,hB,ha,hb,hg⟩ := divide_square_part P.a P.b h.a_pos h.b_pos
  let Q : Parameters := {P with a:=A,b:=B}
  have he : P=scaled Q c := by
    cases P
    simp only [scaled,Q] at *
    congr
  exact ⟨c,Q,hc,he,⟨hA,hB,h.d_pos,h.t_pos,h.u_pos,h.d_not_square,h.pell⟩,hg⟩

theorem norm_hypotheses (Q : Parameters) (c : ℤ) (hc : c ≠ 0)
    (hn : (scaled Q c).normAlpha < 0)
    (hNs : IsSquare (-(scaled Q c).normAlpha)) :
    Q.normAlpha < 0 ∧ IsSquare (-Q.normAlpha) := by
  rw [scaled_norm] at hn hNs
  have hc4 : 0 < c^4 := by simpa only [← pow_mul] using pow_pos (sq_pos_of_ne_zero hc) 2
  have hnQ : Q.normAlpha < 0 := by nlinarith
  refine ⟨hnQ,?_⟩
  obtain ⟨n,he⟩ := hNs
  apply Rat.isSquare_intCast_iff.mp
  refine ⟨(n : ℚ)/(c : ℚ)^2,?_⟩
  have hcz : (c : ℚ) ≠ 0 := by exact_mod_cast hc
  have hq : -((c : ℚ)^4*Q.normAlpha)=(n : ℚ)*(n : ℚ) := by exact_mod_cast he
  push_cast
  field_simp
  nlinarith only [hq]

/-- Multiplication by c² transports the finite set of distinct square values. -/
theorem count_transport (Q : Parameters) (c : ℤ) (hc : c ≠ 0) (hp : Q.Pell)
    (indices : ℤ → Prop) (n : ℕ) (hh : AtMostSquareValuesOn (Q.y hp) indices n) :
    AtMostSquareValuesOn ((scaled Q c).y hp) indices n := by
  classical
  obtain ⟨S,hS,hcover⟩ := hh
  refine ⟨S.image (fun y => (c : ℚ)^2*y),Finset.card_image_le.trans hS,?_⟩
  intro k hk hs
  rw [scaled_y]
  exact Finset.mem_image.mpr ⟨Q.y hp k,hcover k hk ((scaled_square_iff Q c hc hp k).mp hs),rfl⟩

end AnyBNormSquare.SquareScaling
