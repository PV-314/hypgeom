module

public import AnyBNormSquare.HigherIndex
public import «JNT-2024».Section4Case45Algebra

@[expose] public section
namespace AnyBNormSquare.Case45
open «JNT-2024»

/-- The four roundings printed before the last simplification in Section 4.5. -/
theorem rounding_constants :
    (1911/10000 : ℝ) < (8176/1000)^4*(3/4)^4*(175/1000)^4/(4*(1734/1000)) ∧
    (2344/10000000 : ℝ) < (175/1000)^4/4 ∧
    (1 : ℝ)/(1911/10000) < 5233/1000 ∧
    (1 : ℝ) < (6532/100)^2*(2344/10000000) ∧
    (5233/1000 : ℝ)/2 < (1618/1000)^2 ∧
    (1633/100 : ℝ)*(1618/1000) < 2643/100 := by norm_num

/-- Reuse the cited minimum-at-three estimate to remove sqrt(r). -/
theorem remove_sqrt {N d y z F M b : ℝ} {r : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hy : 0 < y) (hF : 0 < F) (hM : 0 < M)
    (hb : 0 < b) (hr : 1 ≤ r)
    (hl : ((8176/1000 : ℝ)*b/M)^4*(N/F)^2*(3/4 : ℝ)^4*
      ((1832/10000 : ℝ)*M/N)^(4*r)*d^(2*r)*y^(4*r-1) < z)
    (hu : z < (1734/1000 : ℝ)*Real.sqrt r*(4*d/N)^r*y^(2*r+1)) :
    ((8176/1000 : ℝ)*b/M)^4*(N/F)^2*(3/4 : ℝ)^4*
      ((175/1000 : ℝ)*M/N)^(4*r)*d^(2*r)*y^(4*r-1) <
      (1734/1000 : ℝ)*(4*d/N)^r*y^(2*r+1) := by
  have hs : 0 < Real.sqrt (r : ℝ) := Real.sqrt_pos.mpr (by exact_mod_cast (by omega : 0 < r))
  have hfac : 0 < ((8176/1000 : ℝ)*b/M)^4*(N/F)^2*(3/4 : ℝ)^4*(M/N)^(4*r)*d^(2*r)*y^(4*r-1) := by positivity
  have hh := mul_lt_mul_of_pos_left (Section4.section45_exponential_bound_printed hr) hfac
  apply (mul_lt_mul_iff_right₀ hs).mp
  have hfirst : (((8176/1000 : ℝ)*b/M)^4*(N/F)^2*(3/4 : ℝ)^4*
      ((175/1000 : ℝ)*M/N)^(4*r)*d^(2*r)*y^(4*r-1))*Real.sqrt r <
      ((8176/1000 : ℝ)*b/M)^4*(N/F)^2*(3/4 : ℝ)^4*
      ((1832/10000 : ℝ)*M/N)^(4*r)*d^(2*r)*y^(4*r-1) := by
    convert hh using 1 <;> simp only [mul_pow,div_pow] <;> ring
  convert hfirst.trans (hl.trans hu) using 1 <;> ring

/-- Collect the r-1 powers using JNT's symbolic division identity. -/
theorem normalized {N d y F M b : ℝ} {r : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hy : 0 < y) (hF : 0 < F) (hM : 0 < M)
    (hb : 0 < b) (hr : 1 ≤ r)
    (hh : ((8176/1000 : ℝ)*b/M)^4*(N/F)^2*(3/4 : ℝ)^4*
      ((175/1000 : ℝ)*M/N)^(4*r)*d^(2*r)*y^(4*r-1) <
      (1734/1000 : ℝ)*(4*d/N)^r*y^(2*r+1)) :
    (1911/10000 : ℝ)*b^4*d/(F^2*N)*
      ((2344/10000000 : ℝ)*M^4*d*y^2/N^3)^(r-1) < 1 := by
  have hratio := (div_lt_one (show 0 < (1734/1000 : ℝ)*(4*d/N)^r*y^(2*r+1) by positivity)).mpr hh
  rw [Section4.case45_division_identity (ne_of_gt hN) (ne_of_gt hd) (ne_of_gt hy)
    (ne_of_gt hF) (ne_of_gt hM) (by norm_num) (by norm_num) hr] at hratio
  have hc := mul_le_mul_of_nonneg_right rounding_constants.1.le (show 0 ≤ b^4*d/(F^2*N) by positivity)
  have hbase := mul_le_mul_of_nonneg_right rounding_constants.2.1.le (show 0 ≤ M^4*d*y^2/N^3 by positivity)
  have hp := pow_le_pow_left₀ (by positivity) hbase (r-1)
  have hm := mul_le_mul hc hp (by positivity) (by positivity)
  apply lt_of_le_of_lt _ hratio
  convert hm using 1 <;> simp only [mul_pow] <;> ring

/-- Apply F<=b^4 and the printed reciprocal rounding 1/0.1911<5.233. -/
theorem eliminate_f {N d y F M b : ℝ} {n : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hF : 0 < F) (hb : 0 < b) (hFb : F ≤ b^4)
    (hh : (1911/10000 : ℝ)*b^4*d/(F^2*N)*((2344/10000000 : ℝ)*M^4*d*y^2/N^3)^n < 1) :
    ((2344/10000000 : ℝ)*M^4*d*y^2/N^3)^n < (5233/1000 : ℝ)*b^4*N/d := by
  have hcoeff : 0 < (1911/10000 : ℝ)*b^4*d/(F^2*N) := by positivity
  have hu : ((2344/10000000 : ℝ)*M^4*d*y^2/N^3)^n < 1/((1911/10000 : ℝ)*b^4*d/(F^2*N)) :=
    (lt_div_iff₀ hcoeff).mpr (by nlinarith only [hh])
  have hsq := pow_le_pow_left₀ hF.le hFb 2
  have hm := mul_le_mul_of_nonneg_right hsq (show 0 ≤ N/((1911/10000 : ℝ)*b^4*d) by positivity)
  have hr := mul_lt_mul_of_pos_right rounding_constants.2.2.1 (show 0 < b^4*N/d by positivity)
  apply hu.trans_le
  apply le_trans _ (by convert hr.le using 1; ring)
  convert hm using 1 <;> field_simp

/-- Positive 2n-th roots and the printed 65.32 rounding, where n=r-1. -/
theorem root_bound {N d y M b : ℝ} {n : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hy : 0 < y) (hM : 0 < M) (hb : 0 < b) (hn : 0 < n)
    (hh : ((2344/10000000 : ℝ)*M^4*d*y^2/N^3)^n < (5233/1000 : ℝ)*b^4*N/d) :
    y < (6532/100 : ℝ)*(5233/1000 : ℝ)^(1/(2*(n : ℝ)))*b^(2/(n : ℝ))*
      N^((3/2 : ℝ)+1/(2*n))/(M^2*d^((1/2 : ℝ)+1/(2*n))) := by
  have hnR : (0 : ℝ) < n := by exact_mod_cast hn
  let B := (6532/100 : ℝ)*N^(3/2 : ℝ)/(M^2*Real.sqrt d)
  let A := (5233/1000 : ℝ)*b^4*N/d
  have hB : 0 < B := by dsimp [B]; positivity
  have hA : 0 < A := by dsimp [A]; positivity
  have hB2 : B^2=(6532/100 : ℝ)^2*N^3/(M^4*d) := by
    dsimp [B]
    rw [div_pow,mul_pow,mul_pow,← Real.rpow_mul_natCast hN.le,Real.sq_sqrt hd.le]
    norm_num [← pow_mul]
  have hbase : (y/B)^2 ≤ (2344/10000000 : ℝ)*M^4*d*y^2/N^3 := by
    rw [div_pow,hB2]
    have hc : (1 : ℝ)/(6532/100)^2 ≤ 2344/10000000 := by norm_num
    have hm := mul_le_mul_of_nonneg_right hc (show 0 ≤ M^4*d*y^2/N^3 by positivity)
    convert hm using 1 <;> field_simp
  have hp := (pow_le_pow_left₀ (by positivity) hbase n).trans_lt hh
  have he : (A^(1/(2*(n : ℝ))))^(2*n)=A := by
    rw [← Real.rpow_mul_natCast hA.le]
    push_cast
    rw [one_div_mul_cancel (by positivity : (2 : ℝ)*n ≠ 0),Real.rpow_one]
  have hx : y/B < A^(1/(2*(n : ℝ))) := by
    apply (pow_lt_pow_iff_left₀ (by positivity) (by positivity) (by omega : 2*n ≠ 0)).mp
    rw [he,pow_mul]
    exact hp
  have hroot := (div_lt_iff₀ hB).mp hx
  have heA : A^(1/(2*(n : ℝ))) = (5233/1000 : ℝ)^(1/(2*(n : ℝ)))*
      b^(2/(n : ℝ))*N^(1/(2*(n : ℝ)))/d^(1/(2*(n : ℝ))) := by
    dsimp [A]
    rw [Real.div_rpow (by positivity) hd.le,Real.mul_rpow (by positivity) hN.le,
      Real.mul_rpow (by norm_num) (by positivity),← Real.rpow_natCast_mul hb.le]
    congr 3; ring_nf
  convert hroot using 1
  rw [heA]
  dsimp [B]
  rw [Real.rpow_add hN,Real.rpow_add hd,← Real.sqrt_eq_rpow]
  field_simp

/-- The last displayed simplification, retaining its 16.33 and 1.618 steps. -/
theorem simplify_bound {N d M b : ℝ} {n : ℕ}
    (hN : 1 ≤ N) (hd : 2 ≤ d) (hM : 2 ≤ M) (hb : 1 ≤ b) (hn : 1 ≤ n) :
    (6532/100 : ℝ)*(5233/1000 : ℝ)^(1/(2*(n : ℝ)))*b^(2/(n : ℝ))*
      N^((3/2 : ℝ)+1/(2*n))/(M^2*d^((1/2 : ℝ)+1/(2*n))) ≤
      (1633/100 : ℝ)*(5233/1000 : ℝ)^(1/(2*(n : ℝ)))*b^(2/(n : ℝ))*
        N^((3/2 : ℝ)+1/(2*n))/d^((1/2 : ℝ)+1/(2*n)) ∧
    (1633/100 : ℝ)*(5233/1000 : ℝ)^(1/(2*(n : ℝ)))*b^(2/(n : ℝ))*
        N^((3/2 : ℝ)+1/(2*n))/d^((1/2 : ℝ)+1/(2*n)) <
      (2643/100 : ℝ)*b^2*N^2/Real.sqrt d := by
  have hnR : (1 : ℝ) ≤ n := by exact_mod_cast hn
  have hnp : (0 : ℝ) < n := by linarith
  have hdp : 0 < d := by linarith
  have hbp : 0 < b := by linarith
  have hNp : 0 < N := by linarith
  have hs : 0 < 1/(2*(n : ℝ)) := by positivity
  have hsle : 1/(2*(n : ℝ)) ≤ 1/2 := (div_le_iff₀ (by positivity)).mpr (by linarith)
  constructor
  · have hM2 : (4 : ℝ) ≤ M^2 := by nlinarith
    have hm := mul_le_mul_of_nonneg_right hM2 (show 0 ≤ d^((1/2 : ℝ)+1/(2*n)) by positivity)
    have hh := div_le_div_of_nonneg_left
      (show 0 ≤ (6532/100 : ℝ)*(5233/1000 : ℝ)^(1/(2*(n : ℝ)))*b^(2/(n : ℝ))*N^((3/2 : ℝ)+1/(2*n)) by positivity)
      (show 0 < 4*d^((1/2 : ℝ)+1/(2*n)) by positivity) hm
    convert hh using 1; ring
  · have hbase : (5233/1000 : ℝ)/d ≤ (5233/1000)/2 :=
      div_le_div_of_nonneg_left (by norm_num) (by norm_num) hd
    have hp := Real.rpow_le_rpow (by positivity : 0 ≤ (5233/1000 : ℝ)/d) hbase hs.le
    have he := Real.rpow_le_rpow_of_exponent_le (by norm_num : (1 : ℝ) ≤ (5233/1000)/2) hsle
    have hsq : ((5233/1000 : ℝ)/2)^(1/2 : ℝ) < 1618/1000 := by
      rw [← Real.sqrt_eq_rpow]
      apply (Real.sqrt_lt (by norm_num) (by norm_num)).mpr
      exact rounding_constants.2.2.2.2.1
    have hratio := (hp.trans he).trans_lt hsq
    have hbexp := Real.rpow_le_rpow_of_exponent_le hb
      ((div_le_iff₀ hnp).mpr (by linarith) : (2 : ℝ)/n ≤ 2)
    have hNexp := Real.rpow_le_rpow_of_exponent_le hN
      (by linarith : (3/2 : ℝ)+1/(2*n) ≤ 2)
    norm_num only [Real.rpow_two] at hbexp hNexp
    have hprod := mul_le_mul hbexp hNexp (by positivity) (by positivity)
    have hmul := mul_lt_mul hratio hprod (by positivity) (by norm_num : (0 : ℝ) ≤ 1618/1000)
    have hscaled := mul_lt_mul_of_pos_left hmul (show 0 < (1633/100 : ℝ)/Real.sqrt d by positivity)
    have hround := mul_lt_mul_of_pos_right rounding_constants.2.2.2.2.2 (show 0 < b^2*N^2/Real.sqrt d by positivity)
    apply lt_trans _ (by convert hround using 1; ring)
    rw [Real.rpow_add hdp,← Real.sqrt_eq_rpow]
    rw [Real.div_rpow (by norm_num : (0 : ℝ) ≤ 5233/1000) hdp.le] at hscaled
    convert hscaled using 1 <;> ring

end AnyBNormSquare.Case45
