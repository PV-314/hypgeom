module

public import AnyBNormSquare.Section5Main

@[expose] public section
namespace AnyBNormSquare.CorollaryProof
open «JNT-2024» Section5Proof Section56Calculations

/-- The remaining indices contribute only the values at 1, K and 0. -/
theorem five_of_tail (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (hmin : SmallestInitialSquare P h.pell)
    (ht : ∀ K, P.IsNegativeCutoff h.pell K →
      AtMostSquareValuesOn (P.y h.pell) (fun k => 2 ≤ k ∨ k ≤ K-1) 2) :
    AtMostSquareValues (P.y h.pell) 5 := by
  classical
  obtain ⟨K,hK⟩ := P.exists_negative_cutoff h hn
  obtain ⟨S,hS,hcover⟩ := ht K hK
  let S₁ := insert (P.y h.pell 1) S
  let S₂ := insert (P.y h.pell K) S₁
  refine ⟨insert ((P.b:ℚ)^2) S₂,?_,?_⟩
  · have h₁ : S₁.card ≤ S.card+1 := Finset.card_insert_le _ _
    have h₂ : S₂.card ≤ S₁.card+1 := Finset.card_insert_le _ _
    have h₃ := Finset.card_insert_le ((P.b:ℚ)^2) S₂
    omega
  · intro k hs
    simp only [S₂,S₁,Finset.mem_insert]
    by_cases ht : 2 ≤ k ∨ k ≤ K-1
    · exact Or.inr (Or.inr (Or.inr (hcover k ht hs)))
    by_cases hk1 : k=1
    · exact Or.inr (Or.inr (Or.inl (congrArg _ hk1)))
    by_cases hkK : k=K
    · exact Or.inr (Or.inl (congrArg _ hkK))
    left
    by_cases hk0 : k=0
    · simp [hk0]
    exact le_antisymm (hK.2.2 k (by omega) (by omega)) (hmin k hs)

theorem corollary15a_conditional (hPrior : Hypergeometric.DenominatorEstimate4)
    (hAkhtari : ExternalResults.AkhtariTheorem11) (hMagma : Calculations.Section46Magma)
    (hE : JavaEnumeration) (hJ : JavaSquareSearch) (hQ : ExceptionalQuartics) : Corollary15a := by
  intro P h hn hs hm hb
  exact five_of_tail P h hn hm (theorem14a_conditional hPrior hAkhtari hMagma hE hJ hQ P h hn hs hm hb)

theorem corollary15b_conditional (hPrior : Hypergeometric.DenominatorEstimate4)
    (hAkhtari : ExternalResults.AkhtariTheorem11) (hMagma : Calculations.Section46Magma) : Corollary15b := by
  intro P h hn hs hm hb hd
  exact five_of_tail P h hn hm (theorem14b_conditional hPrior hAkhtari hMagma P h hn hs hm hb hd)

end AnyBNormSquare.CorollaryProof
