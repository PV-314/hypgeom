module

public import AnyBNormSquare.Reused
public import «JNT-2024».Section4Gaussian

@[expose] public section

namespace AnyBNormSquare
open «JNT-2024»

/-! The author-approved changes in the exact 2026-11-06e manuscript.
The error identity is restricted to the printed near-one domain. The chosen
constant is exactly 1.257. Only the approximation bound below is conditional
on the unproved denominator estimate; no proof of that estimate is supplied.
-/

/-- Section 2.1, lines 521--524: the raw identity with the explicit domain. -/
theorem section21_error_identity {S u₁ u₂ : ℤ} (_hS : S < 0) (_hu₂ : u₂ ≠ 0)
    (_hU : IsIntegral ℤ (Section2.U S u₁ u₂))
    (hnear : ‖Section2.omega S u₁ u₂ - 1‖ < 1) (r : ℕ) :
    Section2.rawQ S u₁ u₂ r * Section2.omega S u₁ u₂ ^ (1 / 4 : ℂ) -
      Section2.rawP S u₁ u₂ r = Section2.rawR S u₁ u₂ r :=
  Section2.raw_error_identity hnear r

/-- The same identity after the manuscript's already printed Gaussian correction. -/
theorem section21_corrected_error_identity {u₁ u₂ : ℤ} (_hu₂ : u₂ ≠ 0)
    (_hU : IsIntegral ℤ (Section2.U (-1) u₁ u₂))
    (hnear : ‖Section2.omega (-1) u₁ u₂ - 1‖ < 1) (r : ℕ) :
    Section2.q u₁ u₂ r * Section2.omega (-1) u₁ u₂ ^ (1 / 4 : ℂ) -
      Section2.p u₁ u₂ r = Section2.R u₁ u₂ r :=
  Section2.corrected_error_identity hnear r

/-- Equation (2.6): the author's exact choice, not a strict upper bound for k₀. -/
noncomputable def paperK0 : ℝ := 1257 / 1000

/-- The new explanatory sentence: 1.072 C₄,₁ < 1.257. -/
theorem paperK0_justified :
    Section2.paperFactor * Section2.paperC1 < paperK0 :=
  Section2.paper_constants

/-- Conditional bound at the chosen k₀. The unresolved arithmetic premise
is visible in the theorem type and remains unproved. -/
theorem section21_q_bound_conditional (hPrior : Hypergeometric.DenominatorEstimate4)
    {u₁ u₂ : ℤ} (hu₂ : u₂ ≠ 0) (_hU : IsIntegral ℤ (Section2.U (-1) u₁ u₂))
    (hnear : ‖Section2.omega (-1) u₁ u₂ - 1‖ < 1) (r : ℕ) :
    ‖Section2.q u₁ u₂ r‖ < paperK0 * Section2.Q (-1) u₁ u₂ ^ r :=
  Section2.corrected_q_bound_fixed hPrior hu₂ hnear r

/-- Section 4.1 verifies the new domain condition via Lemma 3.4 and the
unit-circle chord bound, exactly as the manuscript explains. -/
theorem section41_near_one (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) {k : ℤ} (hs : IsIntegerSquare (P.y h.pell k))
    (hlarge : 4 * Real.sqrt (|(P.normAlpha : ℝ)| / P.d) ≤ (P.y h.pell k : ℝ)) :
    ‖P.sequenceOmega h.pell k - 1‖ < 1 := by
  have ha := lemma34 P h hn hs hlarge
  have hc := Section4.unit_circle_chord_le_arg (P.sequenceOmega_norm h.pell hn k)
  linarith [ha.1, ha.2]

end AnyBNormSquare
