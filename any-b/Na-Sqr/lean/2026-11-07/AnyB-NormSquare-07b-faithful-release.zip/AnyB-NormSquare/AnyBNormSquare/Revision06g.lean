module

public import Mathlib.Analysis.SpecialFunctions.Pow.Real
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Linarith
public import Mathlib.Tactic.Ring

@[expose] public section
namespace AnyBNormSquare.Revision06g

/-- The positive reciprocal exponent in the corrected Section 5.4 sentence. -/
theorem exponent_positive {r : ℝ} (hr : 2 ≤ r) :
    0 < (3*r-2)/(2*(r-1)) := div_pos (by linarith) (by linarith)

/-- All exponent cancellations in the display following the corrected sentence. -/
theorem exponent_identities {r : ℝ} (hr : 2 ≤ r) :
    (1-r/(3*r-2)) = 2*(r-1)/(3*r-2) ∧
    (2*(r-1)/(3*r-2))*((3*r-2)/(2*(r-1))) = 1 ∧
    ((r-1)/(3*r-2))*((3*r-2)/(2*(r-1))) = 1/2 ∧
    (8*r/(3*r-2))*((3*r-2)/(2*(r-1))) = 4+4/(r-1) ∧
    (1/(3*r-2))*((3*r-2)/(2*(r-1))) = 1/(2*(r-1)) ∧
    (8*(r-1)/(3*r-2))*((3*r-2)/(2*(r-1))) = 4 := by
  refine ⟨?_,?_,?_,?_,?_,?_⟩ <;> field_simp (disch := linarith) <;> ring

/-- Divide by the positive power of d, then raise to its positive reciprocal.
This is the author's 06g correction; the 06f word "root" is not followed. -/
theorem power_step {d C r : ℝ} (hd : 0 < d) (hC : 0 < C) (hr : 2 ≤ r)
    (h : C*d^(r/(3*r-2)) < d) :
    C^((3*r-2)/(2*(r-1))) < d := by
  have hdiv := (lt_div_iff₀ (Real.rpow_pos_of_pos hd (r/(3*r-2)))).mpr h
  have he := exponent_identities hr
  have hbase : C < d^(2*(r-1)/(3*r-2)) := by
    calc
      C < d/d^(r/(3*r-2)) := hdiv
      _ = d^(1-r/(3*r-2)) := by rw [Real.rpow_sub hd,Real.rpow_one]
      _ = d^(2*(r-1)/(3*r-2)) := by rw [he.1]
  have hp := Real.rpow_lt_rpow hC.le hbase (exponent_positive hr)
  simpa only [← Real.rpow_mul hd.le,he.2.1,Real.rpow_one] using hp

end AnyBNormSquare.Revision06g
