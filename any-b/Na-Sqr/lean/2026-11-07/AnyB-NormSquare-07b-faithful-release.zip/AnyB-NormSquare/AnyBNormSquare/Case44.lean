module

public import AnyBNormSquare.HigherIndex
public import «JNT-2024».Section4Case44Algebra

@[expose] public section
namespace AnyBNormSquare.Case44
open «JNT-2024»

/-- The cited monotonicity argument and the printed choice c=0.75. -/
theorem cutoff_choice :
    MonotoneOn (fun c : ℝ => c^12*(1-c)^4) (Set.Icc 0 (3/4)) ∧
    (1237/10000000 : ℝ) < (3/4 : ℝ)^12*(1-3/4)^4 :=
  ⟨Section4.cutoff_choice_monotone,Section4.cutoff_choice_value⟩

/-- Exact rational certificates for the roundings in Section 4.4. -/
theorem rounding_constants :
    (2147/100 : ℝ)^2/(1832/10000)^6 < 12200000 ∧
    (636/1000 : ℝ)^4*(2147/100)^2/
      ((1832/10000)^6*(1237/10000000)*(8176/1000)^12) < 181/1000 ∧
    (12200000 : ℝ) < (592/10)^4 ∧ (181/1000 : ℝ) < (653/1000)^4 := by norm_num

/-- Cube the shared lower bound and combine it with the nonexact upper bound. -/
theorem combine {N d y z F M b c : ℝ} {r : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hy : 0 < y) (hF : 0 < F) (hM : 0 < M)
    (hb : 0 < b) (hc : 0 < c) (hr : 1 ≤ r)
    (hl : ((8176/1000 : ℝ)*b/M)^4*(N/F)^2*c^4*((1832/10000 : ℝ)*M/N)^(4*r)*d^(2*r)*y^(4*r-1) < z)
    (hu : z^3 < (N*F)^2*((636/1000 : ℝ)/((1-c)*b))^4*((2147/100 : ℝ)/M)^(4*r)*d^(2*r-2)*y^(4*r+1)) :
    ((8176/1000 : ℝ)*b/M)^12*(N/F)^6*c^12*((1832/10000 : ℝ)*M/N)^(12*r)*d^(6*r)*y^(12*r-3) <
      (N*F)^2*((636/1000 : ℝ)/((1-c)*b))^4*((2147/100 : ℝ)/M)^(4*r)*d^(2*r-2)*y^(4*r+1) := by
  have hp := pow_lt_pow_left₀ hl (by positivity) (by decide : (3 : ℕ) ≠ 0)
  apply lt_trans _ hu
  convert hp using 1
  simp only [mul_pow,← pow_mul,show (4*r)*3=12*r by omega,
    show (2*r)*3=6*r by omega,show (4*r-1)*3=12*r-3 by omega]

/-- The printed 0.181 and 1.22*10^7 estimate, obtained using JNT's general
division identity with the actual b factors in its parameters. -/
theorem normalized {N d y F M b : ℝ} {r : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hy : 0 < y) (hF : 0 < F) (hM : 0 < M)
    (hb : 0 < b) (hr : 1 ≤ r)
    (hh : ((8176/1000 : ℝ)*b/M)^12*(N/F)^6*(3/4 : ℝ)^12*
      ((1832/10000 : ℝ)*M/N)^(12*r)*d^(6*r)*y^(12*r-3) <
      (N*F)^2*((636/1000 : ℝ)/((1-3/4)*b))^4*((2147/100 : ℝ)/M)^(4*r)*d^(2*r-2)*y^(4*r+1)) :
    (y^4*d^2*M^8/N^6)^(2*r-1) <
      F^8*(181/1000 : ℝ)*(N^2*M^4/(b^16*d^4))*(12200000 : ℝ)^(2*r-1) := by
  have hlow : 0 < ((8176/1000 : ℝ)*b/M)^12*(N/F)^6*(3/4 : ℝ)^12*
      ((1832/10000 : ℝ)*M/N)^(12*r)*d^(6*r)*y^(12*r-3) := by positivity
  have hh' : ((8176/1000 : ℝ)*b/M)^12*(N/F)^6*(3/4 : ℝ)^12*
      ((1832/10000 : ℝ)*M/N)^(12*r)*d^(6*r)*y^(12*r-3) <
      (N*F)^2*(((636/1000 : ℝ)/b)/(1-3/4))^4*((2147/100 : ℝ)/M)^(4*r)*d^(2*r-2)*y^(4*r+1) := by
    convert hh using 1; congr 3; ring
  have hratio := (one_lt_div hlow).mpr hh'
  rw [Section4.case44_division_identity (ne_of_gt hN) (ne_of_gt hd) (ne_of_gt hy)
    (ne_of_gt hF) (ne_of_gt hM) (by norm_num) (by norm_num) (by norm_num)
    (by positivity) (by norm_num) hr] at hratio
  have hpbase : 0 < (y^4*d^2*M^8/N^6)^(2*r-1) := by positivity
  have hcross := (one_lt_div hpbase).mp hratio
  have hcf : (636/1000 : ℝ)^4*(2147/100)^2/
      ((1832/10000)^6*(3/4)^12*(1-3/4)^4*(8176/1000)^12) < 181/1000 := by
    have hden : (1832/10000 : ℝ)^6*(1237/10000000)*(8176/1000)^12 <
        (1832/10000 : ℝ)^6*(3/4)^12*(1-3/4)^4*(8176/1000)^12 := by
      have hmul := mul_lt_mul_of_pos_left cutoff_choice.2
        (by norm_num : 0 < (1832/10000 : ℝ)^6*(8176/1000)^12)
      convert hmul using 1 <;> ring
    exact (div_lt_div_of_pos_left (by norm_num) (by norm_num) hden).trans rounding_constants.2.1
  have hc := mul_lt_mul_of_pos_right hcf (show 0 < F^8*N^2*M^4/(b^16*d^4) by positivity)
  have hp := pow_le_pow_left₀ (by norm_num : 0 ≤ (2147/100 : ℝ)^2/(1832/10000)^6)
    rounding_constants.1.le (2*r-1)
  have hm := mul_lt_mul hc hp (by positivity) (by positivity)
  apply hcross.trans
  convert hm using 1 <;> (try simp only [div_pow,mul_pow]) <;> field_simp

/-- Place 59.2 in the denominator and then apply the f-product bound. -/
theorem normalized_with_b {N d y F M b : ℝ} {r : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hF : 0 < F) (hM : 0 < M) (hb : 0 < b)
    (hFb : F ≤ b^4)
    (hh : (y^4*d^2*M^8/N^6)^(2*r-1) <
      F^8*(181/1000 : ℝ)*(N^2*M^4/(b^16*d^4))*(12200000 : ℝ)^(2*r-1)) :
    (y^4*d^2*M^8/((592/10 : ℝ)^4*N^6))^(2*r-1) <
      (653/1000 : ℝ)^4*b^16*N^2*M^4/d^4 := by
  have hpow := pow_le_pow_left₀ (by norm_num : (0 : ℝ) ≤ 12200000) rounding_constants.2.2.1.le (2*r-1)
  have hc := mul_le_mul_of_nonneg_left hpow (show 0 ≤ F^8*(181/1000 : ℝ)*(N^2*M^4/(b^16*d^4)) by positivity)
  have hdiv := (div_lt_iff₀ (show 0 < ((592/10 : ℝ)^4)^(2*r-1) by positivity)).mpr (hh.trans_le hc)
  have hFpow := pow_le_pow_left₀ hF.le hFb 8
  have hFm := mul_le_mul_of_nonneg_right hFpow (show 0 ≤ (181/1000 : ℝ)*N^2*M^4/(b^16*d^4) by positivity)
  have hround := mul_lt_mul_of_pos_right rounding_constants.2.2.2 (show 0 < b^16*N^2*M^4/d^4 by positivity)
  have hscaled : F^8*(181/1000 : ℝ)*(N^2*M^4/(b^16*d^4)) < (653/1000 : ℝ)^4*b^16*N^2*M^4/d^4 := by
    apply lt_of_le_of_lt _ (by convert hround using 1; ring)
    convert hFm using 1 <;> field_simp
  apply lt_trans _ hscaled
  convert hdiv using 1; simp only [div_pow,mul_pow]; field_simp

/-- The printed variable-exponent upper bound, obtained by positive roots.
Here n=2*r-1; no estimate on n is used until the next simplification. -/
theorem root_bound {N d y M b : ℝ} {n : ℕ}
    (hN : 0 < N) (hd : 0 < d) (hy : 0 < y) (hM : 0 < M) (hb : 0 < b) (hn : 0 < n)
    (hh : (y^4*d^2*M^8/((592/10 : ℝ)^4*N^6))^n < (653/1000 : ℝ)^4*b^16*N^2*M^4/d^4) :
    y < (592/10 : ℝ)*(653/1000 : ℝ)^(1/(n : ℝ))*b^(4/(n : ℝ))*
      N^((3/2 : ℝ)+1/(2*n))/(d^((1/2 : ℝ)+1/n)*M^(2-1/(n : ℝ))) := by
  have hnR : (0 : ℝ) < n := by exact_mod_cast hn
  let B := (592/10 : ℝ)*N^(3/2 : ℝ)/(Real.sqrt d*M^2)
  let A := (653/1000 : ℝ)*b^4*Real.sqrt N*M/d
  have hB : 0 < B := by dsimp [B]; positivity
  have hA : 0 < A := by dsimp [A]; positivity
  have hB4 : B^4=(592/10 : ℝ)^4*N^6/(d^2*M^8) := by
    dsimp [B]
    rw [div_pow,mul_pow,mul_pow,← Real.rpow_mul_natCast hN.le]
    have hs : Real.sqrt d^4=d^2 := by rw [show (4 : ℕ)=2*2 from rfl,pow_mul,Real.sq_sqrt hd.le]
    norm_num [hs,← pow_mul]
  have hA4 : A^4=(653/1000 : ℝ)^4*b^16*N^2*M^4/d^4 := by
    dsimp [A]
    have hs : Real.sqrt N^4=N^2 := by rw [show (4 : ℕ)=2*2 from rfl,pow_mul,Real.sq_sqrt hN.le]
    simp only [div_pow,mul_pow,hs,← pow_mul]
  have he : ((y/B)^n)^4=(y^4*d^2*M^8/((592/10 : ℝ)^4*N^6))^n := by
    rw [← pow_mul,Nat.mul_comm n 4,pow_mul,div_pow,hB4]
    congr 1
    field_simp
  have hp : (y/B)^n < A :=
    (pow_lt_pow_iff_left₀ (by positivity) hA.le (by decide : (4 : ℕ) ≠ 0)).mp (by rwa [he,hA4])
  have hrpow : (A^(1/(n : ℝ)))^n=A := by
    rw [← Real.rpow_mul_natCast hA.le]
    simp [ne_of_gt hnR]
  have hroot : y < B*A^(1/(n : ℝ)) := by
    have hx : y/B < A^(1/(n : ℝ)) :=
      (pow_lt_pow_iff_left₀ (by positivity) (by positivity) (by omega : n ≠ 0)).mp (by rwa [hrpow])
    have hx' := (div_lt_iff₀ hB).mp hx
    simpa only [mul_comm] using hx'
  have heA : A^(1/(n : ℝ)) = (653/1000 : ℝ)^(1/(n : ℝ))*b^(4/(n : ℝ))*
      N^((1/2 : ℝ)*(1/n))*M^(1/(n : ℝ))/d^(1/(n : ℝ)) := by
    dsimp [A]
    rw [Real.div_rpow (by positivity) hd.le,Real.mul_rpow (by positivity) hM.le,
      Real.mul_rpow (by positivity) (Real.sqrt_nonneg _),Real.mul_rpow (by norm_num) (by positivity),
      ← Real.rpow_natCast_mul hb.le,Real.sqrt_eq_rpow,← Real.rpow_mul hN.le]
    congr 3; ring_nf
  convert hroot using 1
  rw [heA]
  dsimp [B]
  rw [show (1 : ℝ)/(2*n)=(1/2)*(1/(n : ℝ)) by ring,
    Real.rpow_add hN,Real.rpow_add hd,Real.rpow_sub hM]
  norm_num only [Real.rpow_two]
  rw [← Real.sqrt_eq_rpow]
  field_simp

/-- The two printed simplification steps, using M>=2,d>=2,n>=3 and b,N>=1. -/
theorem simplify_bound {N d M b : ℝ} {n : ℕ}
    (hN : 1 ≤ N) (hd : 2 ≤ d) (hM : 2 ≤ M) (hb : 1 ≤ b) (hn : 3 ≤ n) :
    (592/10 : ℝ)*(653/1000 : ℝ)^(1/(n : ℝ))*b^(4/(n : ℝ))*
      N^((3/2 : ℝ)+1/(2*n))/(d^((1/2 : ℝ)+1/n)*M^(2-1/(n : ℝ))) ≤
      (592/10 : ℝ)*(653/1000 : ℝ)^(1/(n : ℝ))*b^(4/(n : ℝ))*
        N^((3/2 : ℝ)+1/(2*n))/(4*Real.sqrt d) ∧
    (592/10 : ℝ)*(653/1000 : ℝ)^(1/(n : ℝ))*b^(4/(n : ℝ))*
        N^((3/2 : ℝ)+1/(2*n))/(4*Real.sqrt d) <
      (148/10 : ℝ)*b^(4/3 : ℝ)*N^(5/3 : ℝ)/Real.sqrt d := by
  have hnR : (3 : ℝ) ≤ n := by exact_mod_cast hn
  have hnp : (0 : ℝ) < n := by linarith
  have hdp : 0 < d := by linarith
  have hMp : 0 < M := by linarith
  have hbp : 0 < b := by linarith
  have hNp : 0 < N := by linarith
  have hs : 0 < 1/(n : ℝ) := one_div_pos.mpr hnp
  have hsle : 1/(n : ℝ) ≤ 1/3 := (div_le_iff₀ hnp).mpr (by linarith)
  have hdsmall := Real.rpow_le_rpow (by norm_num : (0 : ℝ) ≤ 2) hd hs.le
  have hMsmall := Real.rpow_le_rpow (by norm_num : (0 : ℝ) ≤ 2) hM (by linarith : 0 ≤ 2-1/(n : ℝ))
  have hprod := mul_le_mul hdsmall hMsmall (by positivity) (by positivity)
  have he2 : (2 : ℝ)^(1/(n : ℝ))*2^(2-1/(n : ℝ))=4 := by
    rw [← Real.rpow_add (by norm_num : (0 : ℝ) < 2)]
    norm_num
  rw [he2] at hprod
  have hden : 4*Real.sqrt d ≤ d^((1/2 : ℝ)+1/n)*M^(2-1/(n : ℝ)) := by
    rw [Real.rpow_add hdp,← Real.sqrt_eq_rpow]
    have hm := mul_le_mul_of_nonneg_left hprod (Real.sqrt_nonneg d)
    nlinarith only [hm]
  constructor
  · exact div_le_div_of_nonneg_left (by positivity) (by positivity) hden
  · have ha : (653/1000 : ℝ)^(1/(n : ℝ)) < 1 := Real.rpow_lt_one (by norm_num) (by norm_num) hs
    have hbex : (4 : ℝ)/n ≤ 4/3 := (div_le_iff₀ hnp).mpr (by linarith)
    have hsmall : (1 : ℝ)/(2*n) ≤ 1/6 := (div_le_iff₀ (by positivity)).mpr (by linarith)
    have hbpw := Real.rpow_le_rpow_of_exponent_le hb hbex
    have hNpw := Real.rpow_le_rpow_of_exponent_le hN
      (by linarith : (3/2 : ℝ)+1/(2*n) ≤ 5/3)
    have hm := mul_le_mul hbpw hNpw (by positivity) (by positivity)
    have hs' := mul_lt_mul_of_pos_right ha (show 0 < b^(4/(n : ℝ))*N^((3/2 : ℝ)+1/(2*n)) by positivity)
    simp only [one_mul] at hs'
    have hfinal := hs'.trans_le hm
    have hscale := mul_lt_mul_of_pos_left hfinal (show 0 < (148/10 : ℝ)/Real.sqrt d by positivity)
    convert hscale using 1 <;> ring

end AnyBNormSquare.Case44
