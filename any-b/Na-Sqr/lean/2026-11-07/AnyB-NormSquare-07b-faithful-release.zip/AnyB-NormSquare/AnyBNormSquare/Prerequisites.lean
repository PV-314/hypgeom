module

public import AnyBNormSquare.Revision06f
public import AnyBNormSquare.Targets
public import «JNT-2024».Section4Inputs
public import «JNT-2024».Lemma39PublishedAlgebra
public import «JNT-2024».Section4ParameterChainsPublished

@[expose] public section
namespace AnyBNormSquare.Prerequisites
open «JNT-2024» Approximation

/-- The elementary divisibility step behind the printed bound for N4. -/
theorem scale_le_sqrt_abs {n : ℤ} (hn : n ≠ 0) :
    N4 (n : ℚ) ≤ Real.sqrt |(n : ℝ)| := by
  have hd : (2 : ℤ) ^ min (padicValInt 2 n) 6 ∣ n :=
    dvd_trans (pow_dvd_pow 2 (min_le_left _ _)) (padicValInt_dvd n)
  have hl : (2 : ℤ) ^ min (padicValInt 2 n) 6 ≤ |n| :=
    Int.le_of_dvd (abs_pos.mpr hn) (by
      by_cases hs : 0 ≤ n
      · rwa [abs_of_nonneg hs]
      · rw [abs_of_neg (lt_of_not_ge hs)]
        obtain ⟨m,hm⟩ := hd
        refine ⟨-m, ?_⟩
        calc
          -n = -((2 : ℤ)^min (padicValInt 2 n) 6*m) := congrArg Neg.neg hm
          _ = _ := by ring)
  have hlR : (2 : ℝ) ^ min (padicValInt 2 n) 6 ≤ |(n : ℝ)| := by exact_mod_cast hl
  rw [N4, padicValRat.of_int,
    show min (padicValInt 2 n : ℤ) 6 = (min (padicValInt 2 n) 6 : ℕ) by omega,
    zpow_natCast]
  exact Real.sqrt_le_sqrt hlR

/-- Section 4.1 follows g1<=2C, g2=1, g3>=2 to obtain g<=sqrt(2) C. -/
theorem gaussian_g_upper {X C ν : ℤ} (hC : 0 < C) (hν : ν = 1 ∨ ν = -1) :
    g (-1) (2 * X) (2 * ν * C) ≤ Real.sqrt 2 * C := by
  have hgcd : (Int.gcd X C : ℝ) ≤ C := by
    exact_mod_cast (Int.gcd_le_right X hC)
  have hCr : (0 : ℝ) < C := by exact_mod_cast hC
  have hg0 : 0 ≤ g (-1) (2 * X) (2 * ν * C) := by unfold g; positivity
  have hg2 := g_sq (-1) (2 * X) (2 * ν * C)
  rw [gSquared, Section2.g2_gaussian, g1_unit X C ν hν] at hg2
  rcases Section2.g3_gaussian (2 * X) (2 * ν * C) with he | he <;>
    rw [he] at hg2 <;> push_cast at hg2
  all_goals
    have hs := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
    have hc0 : (0 : ℝ) ≤ Int.gcd X C := by positivity
    have hsq : (Int.gcd X C : ℝ) ^ 2 ≤ (C : ℝ) ^ 2 := by nlinarith
    apply (sq_le_sq₀ hg0 (by positivity)).mp
    rw [mul_pow, hs]
    nlinarith

/-- The printed chain g>=1, |d'|<=4C² and N4<=2C. -/
theorem gaussian_scale_upper {X C ν : ℤ} (hC : 0 < C) (hν : ν = 1 ∨ ν = -1) :
    1 ≤ g (-1) (2 * X) (2 * ν * C) ∧
    N4 (dPrime (-1) (2 * X) (2 * ν * C)) ≤ 2 * C := by
  have hu : 2 * ν * C ≠ 0 := by rcases hν with rfl | rfl <;> omega
  have hg := Lemma35Proof.one_le_g (by decide : (-1 : ℤ) ≠ 0) (ne_of_gt hC) hν (X := X)
  let n := dPrimeInteger (-1) (2 * X) (2 * ν * C)
  have hn : n < 0 := dPrimeInteger_neg (by decide) hu
  have hnc := dPrimeInteger_cast (by decide : (-1 : ℤ) ≠ 0) hu (u₁ := 2 * X)
  have hgr : gSquared (-1) (2 * X) (2 * ν * C) ≠ 0 :=
    ne_of_gt (Lemma35Proof.gSquared_pos (by decide) hu)
  have heQ : (n : ℚ) * gSquared (-1) (2 * X) (2 * ν * C) = -(2 * ν * C : ℚ) ^ 2 := by
    dsimp [n]
    rw [hnc, dPrime]
    field_simp
    push_cast
    ring
  have he : (n : ℝ) * g (-1) (2 * X) (2 * ν * C) ^ 2 = -4 * (C : ℝ) ^ 2 := by
    rw [g_sq]
    have hh := congrArg (fun q : ℚ => (q : ℝ)) heQ
    push_cast at hh
    rcases hν with rfl | rfl <;> norm_num at hh ⊢ <;> nlinarith only [hh]
  have hnR : (n : ℝ) < 0 := by exact_mod_cast hn
  have hnle : |(n : ℝ)| ≤ (2 * (C : ℝ)) ^ 2 := by
    rw [abs_of_neg hnR]
    have hm := mul_le_mul_of_nonneg_left (show (1 : ℝ) ≤ g (-1) (2 * X) (2 * ν * C) ^ 2 by nlinarith) (neg_nonneg.mpr hnR.le)
    nlinarith only [hm, he]
  refine ⟨hg, ?_⟩
  rw [← hnc]
  have hscale := scale_le_sqrt_abs (ne_of_lt hn)
  have hh := hscale.trans (Real.sqrt_le_sqrt hnle)
  simpa only [Real.sqrt_sq (show 0 ≤ 2 * (C : ℝ) by positivity)] using hh

/-- The exact Section 4.1 normalizer upper-bound chain, with Lemma 3.5's lower bound. -/
theorem gaussian_normalizer_bounds {X C ν : ℤ} (hC : 0 < C) (hν : ν = 1 ∨ ν = -1) :
    let M := normalizerProduct (-1) (2 * X) (2 * ν * C)
    2 ≤ M ∧ M ≤ 2 * Real.sqrt 2 * (C : ℝ) ^ 2 ∧
      2 * Real.sqrt 2 * (C : ℝ) ^ 2 < 4 * (C : ℝ) ^ 2 := by
  have hg := gaussian_scale_upper (X := X) hC hν
  have hu := gaussian_g_upper (X := X) hC hν
  have hN := Real.sqrt_nonneg ((2 : ℝ) ^ min (padicValRat 2 (dPrime (-1) (2*X) (2*ν*C))) 6)
  have hg0 : 0 ≤ g (-1) (2*X) (2*ν*C) := le_trans (by norm_num) hg.1
  refine ⟨Lemma35Proof.lower_bound (by decide) (ne_of_gt hC) hν, ?_, ?_⟩
  · dsimp only [normalizerProduct]
    rw [abs_of_nonneg hg0]
    have hh := mul_le_mul hu hg.2 hN (show 0 ≤ Real.sqrt 2 * (C : ℝ) by positivity)
    nlinarith only [hh]
  · have hs := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
    have hsr : Real.sqrt 2 < 2 := by nlinarith [Real.sqrt_nonneg (2 : ℝ)]
    have hc : (0 : ℝ) < (C : ℝ)^2 := by positivity
    nlinarith only [mul_lt_mul_of_pos_right hsr hc]

/-- (4.6) and (4.7), following the norm identity and the printed size assumption. -/
theorem coordinate_bounds {N d x y : ℝ} (hN : 0 < N) (hd : 0 < d)
    (hy : 4 * Real.sqrt (N / d) ≤ y) (he : x^2 = d*y^2-N) :
    (15/16 : ℝ)*d*y^2 ≤ x^2 ∧ Real.sqrt (x^2+N) = Real.sqrt d*y ∧
      Real.sqrt d*y < (104/100 : ℝ)*|x| := by
  have hs := Real.sq_sqrt (div_nonneg hN.le hd.le)
  have hroot := Real.sq_sqrt hd.le
  have hy0 : 0 < y := lt_of_lt_of_le (by positivity) hy
  have hh := pow_le_pow_left₀ (show 0 ≤ 4 * Real.sqrt (N/d) by positivity) hy 2
  have hm := mul_le_mul_of_nonneg_left hh hd.le
  rw [mul_pow, hs] at hm
  have hmul : d * (N/d) = N := mul_div_cancel₀ N (ne_of_gt hd)
  have hlow : (15/16 : ℝ)*d*y^2 ≤ x^2 := by nlinarith only [he,hm,hs,hmul]
  refine ⟨hlow, ?_, ?_⟩
  · rw [show x^2+N = (Real.sqrt d*y)^2 by nlinarith only [he,hroot]]
    exact Real.sqrt_sq (by positivity)
  · apply (sq_lt_sq₀ (by positivity) (by positivity)).mp
    rw [mul_pow,mul_pow,hroot,sq_abs]
    nlinarith [mul_pos hd (sq_pos_of_pos hy0)]

/-- The printed E and Q estimates after the doubled Gaussian substitution.
The coordinate lower bound is weak, as in 06f. -/
theorem parameter_bounds {N M L x : ℝ} (hN : 0 < N) (hM : 0 < M)
    (hL : 0 < L) (hx : (15/16 : ℝ)*L^2 ≤ x^2) (hxl : |x| < L) :
    (1832/10000 : ℝ)*M*L/N < M*(|x|+L)/(2*Real.exp (42/25)*N) ∧
      2*Real.exp (42/25)*(|x|+L)/M < (2147/100 : ℝ)*L/M := by
  have hs0 := Real.sqrt_nonneg (15/16 : ℝ)
  have hs2 := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 15/16)
  have hs : (9682/10000 : ℝ) < Real.sqrt (15/16) := by nlinarith
  have hxl' : Real.sqrt (15/16 : ℝ)*L ≤ |x| := by
    apply (sq_le_sq₀ (by positivity) (abs_nonneg x)).mp
    rw [mul_pow,hs2,sq_abs]
    exact hx
  have heb := Section4.exp_168_bounds
  have he := Real.exp_pos (42/25 : ℝ)
  have hden : 0 < 2*Real.exp (42/25 : ℝ)*N := by positivity
  constructor
  · apply (div_lt_div_iff₀ hN hden).mpr
    have hnum : (1832/10000 : ℝ)*2*Real.exp (42/25) < 1+Real.sqrt (15/16) := by linarith [heb.2]
    have hh := mul_lt_mul_of_pos_right hnum (show 0 < M*L*N by positivity)
    have hh' := mul_le_mul_of_nonneg_left hxl' (show 0 ≤ M*N by positivity)
    nlinarith only [hh,hh']
  · apply (div_lt_div_iff_of_pos_right hM).mpr
    have hh := mul_lt_mul_of_pos_left hxl (show 0 < 2*Real.exp (42/25 : ℝ) by positivity)
    have hh' := mul_lt_mul_of_pos_right heb.2 hL
    nlinarith only [hh,hh']

/-- The sequence supplies the exact Gaussian coordinates without restricting b. -/
theorem sequence_coordinates (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha)) {k X Y : ℤ}
    (hx : P.x h.pell k = (X : ℚ)) (hy : P.y h.pell k = (Y : ℚ)) :
    let Z := unitPowerNorm P k * squareFactor P.normAlpha
    (Z : ℝ)^2 = |(P.normAlpha : ℝ)| ∧ Z ≠ 0 ∧
    (X : ℝ)^2 + |(P.normAlpha : ℝ)| = (Real.sqrt P.d * (Y : ℝ))^2 ∧
    Section2.omega (-1) (2*X) (2*Z) = P.sequenceOmega h.pell k := by
  let Z := unitPowerNorm P k * squareFactor P.normAlpha
  have hS := squarefreePart_eq_neg_one (ne_of_lt hn) hNs
  have hC := squareFactor_pos (ne_of_lt hn)
  have hsign := unitPowerNorm_sign P h.pell k
  have hsq : (squareFactor P.normAlpha : ℝ)^2 = |(P.normAlpha : ℝ)| := by
    have hh := squareFactor_sq_mul P.normAlpha
    rw [hS] at hh
    rw [abs_of_neg (by exact_mod_cast hn)]
    exact_mod_cast (by linarith only [hh] : (squareFactor P.normAlpha)^2 = -P.normAlpha)
  have hzsq : (Z : ℝ)^2 = |(P.normAlpha : ℝ)| := by
    rcases hsign with he | he <;> simp [Z,he,hsq]
  have hz : Z ≠ 0 := by rcases hsign with he | he <;> simp [Z,he,ne_of_gt hC]
  refine ⟨hzsq,hz,?_,?_⟩
  · have hh := P.norm_identity h.pell k
    rw [hx,hy] at hh
    have hhR : (X : ℝ)^2 - P.d*(Y : ℝ)^2 = P.normAlpha := by exact_mod_cast hh
    rw [mul_pow,Real.sq_sqrt (by exact_mod_cast h.d_pos.le),abs_of_neg (by exact_mod_cast hn)]
    linarith
  · rw [Section4.gaussian_omega]
    have hnr : P.negativeNormRoot = (squareFactor P.normAlpha : ℝ) := by
      simp [Parameters.negativeNormRoot,hS]
    have hnu : (unitPowerNorm P k : ℝ) = ((P.epsilonNorm^k : ℚ) : ℝ) := by
      exact_mod_cast unitPowerNorm_cast P h.pell k
    simp only [Parameters.sequenceOmega,hx,hnr,Int.cast_mul,hnu,Rat.cast_intCast]

/-- The sequence-specific application of corrected (4.9), from the actual
printed size hypotheses. No final Q inequality is assumed. -/
theorem sequence_Q_chain (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha)) {k X Y : ℤ}
    (hx : P.x h.pell k = (X : ℚ)) (hy : P.y h.pell k = (Y : ℚ))
    (hlarge : 4*Real.sqrt (|(P.normAlpha : ℝ)|/P.d) ≤ (Y : ℝ))
    (hscale : normalizerProduct (-1) (2*X) (2*unitPowerNorm P k*squareFactor P.normAlpha) /
        Real.sqrt P.d ≤ (Y : ℝ)) :
    let M := normalizerProduct (-1) (2*X) (2*unitPowerNorm P k*squareFactor P.normAlpha)
    let L := Real.sqrt P.d * (Y : ℝ)
    2*Real.exp (168/100)*(1+Real.sqrt (9375/10000))*L/M ≤
        Section2.Q (-1) (2*X) (2*unitPowerNorm P k*squareFactor P.normAlpha) ∧
    (2112/100 : ℝ)*L/M < 2*Real.exp (168/100)*(1+Real.sqrt (9375/10000))*L/M ∧
    (2112/100 : ℝ) ≤ (2112/100 : ℝ)*L/M := by
  have hc := sequence_coordinates P h hn hNs hx hy
  have hN : 0 < |(P.normAlpha : ℝ)| := abs_pos.mpr (by exact_mod_cast ne_of_lt hn)
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hy0 : (0 : ℝ) < Y := lt_of_lt_of_le (by positivity) hlarge
  have hnorm : (X : ℝ)^2 = P.d*(Y : ℝ)^2-|(P.normAlpha : ℝ)| := by
    have he := hc.2.2.1
    rw [mul_pow,Real.sq_sqrt hd.le] at he
    linarith
  have hco := (coordinate_bounds hN hd hlarge hnorm).1
  have hM := (gaussian_normalizer_bounds (X := X) (squareFactor_pos (ne_of_lt hn))
    (unitPowerNorm_sign P h.pell k)).1
  have hML := (div_le_iff₀ (Real.sqrt_pos.mpr hd)).mp hscale
  have hh := Revision06f.gaussian_Q_lower_chain (mul_pos (Real.sqrt_pos.mpr hd) hy0)
    hc.1 hc.2.2.1 (by simpa only [mul_pow,Real.sq_sqrt hd.le,mul_assoc] using hco)
    (by simpa only [mul_assoc] using (show 0 < normalizerProduct (-1) (2*X)
      (2*unitPowerNorm P k*squareFactor P.normAlpha) by linarith))
    (by simpa only [mul_assoc,mul_comm (Y : ℝ)] using hML)
  simpa only [mul_assoc] using hh

/-- Preserve JNT's actual indexed representation certificate and the f|b²
conclusion of Lemma 3.1. Only the missing general-b assembly is supplied here. -/
theorem sequence_certificate (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha)) {k : ℤ}
    (hk : k ≠ 0) (hs : IsIntegerSquare (P.y h.pell k)) (hy : 0 < P.y h.pell k) :
    ∃ p : P.SequenceDatum, P.SequenceGapCertificate h.pell k p ∧
      p.f ≤ (P.b : ℝ)^2 ∧ ∃ f : ℤ, p.f = (f : ℝ) ∧ f ∣ P.b^2 := by
  obtain ⟨T,U,X,v,hU,hv,hp,hrep,hyv,hx,heps⟩ :=
    P.sequence_square_representation_input_indexed h hk (integerSquare_isSquare hs) hy
  let Q := P.withUnit T U
  let : Fact (¬ IsSquare Q.d) := ⟨h.d_not_square⟩
  let : Fact (¬ IsSquare Q.normAlpha) := ⟨by
    intro hh
    have hh' := IsSquare.nonneg hh
    change 0 ≤ P.normAlpha at hh'
    omega⟩
  obtain ⟨ν,f,r,s,τ,hν,hf,hτ,hF,hdiv⟩ :=
    Q.proposition31b_published hrep (ne_of_gt h.a_pos) (ne_of_gt h.b_pos)
      (ne_of_gt hv) hU (ne_of_lt hn) (Q.epsilon_isIntegral hp) hNs
  rw [Q.normRadical_of_unit (Q.integer_unit_norm hp hν),mul_one] at hdiv
  obtain ⟨p,hpy,hpf,hpr,hps⟩ := Q.signed_representation_datum h.b_pos hn hp hv hf hτ hF
  have hpy' : p.y = (P.y h.pell k : ℝ) := by rw [hpy,hyv]; norm_cast
  have hle : f ≤ P.b^2 := Int.le_of_dvd (sq_pos_of_pos h.b_pos) hdiv
  refine ⟨p,⟨hpy',T,U,X,v,f,τ,hU,hv,hp,hrep,hpf,hτ,?_,hx,heps⟩,?_,f,hpf,hdiv⟩
  · simpa only [hpr,hps] using hF
  · rw [hpf]; exact_mod_cast hle

/-- The exact equality in (4.5), directly from the cited indexed JNT identity. -/
theorem comparison_identity (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) {i j : ℤ} (p q : P.SequenceDatum)
    (hp : P.SequenceGapCertificate h.pell i p) (hq : P.SequenceGapCertificate h.pell j q) :
    ‖P.sequenceOmega h.pell i -
      (star (star p.point*q.point)/(star p.point*q.point))^4‖ =
      2*Real.sqrt |(P.normAlpha : ℝ)|/(Real.sqrt P.d*q.y) := by
  have hh := (eq_div_iff (ne_of_gt q.y_pos)).mpr
    (P.sequence_cross_residual_published h hn p q hp hq)
  calc
    _ = 2*P.gapScale/q.y := hh
    _ = 2*Real.sqrt (|(P.normAlpha : ℝ)|/P.d)/q.y := by
      congr 1
      rw [P.gapScale_eq_sqrt h.b_pos hn]
    _ = _ := by rw [Real.sqrt_div (abs_nonneg _)]; ring

/-- (4.5), the minimizing phase and (4.12)--(4.13), using the actual indexed
JNT representations and retaining the general f and b factors. -/
theorem comparison_pair (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha)) {i j : ℤ}
    (p q : P.SequenceDatum) (hp : P.SequenceGapCertificate h.pell i p)
    (hq : P.SequenceGapCertificate h.pell j q)
    (hpf : p.f ≤ (P.b : ℝ)^2) (hqf : q.f ≤ (P.b : ℝ)^2)
    (hlarge : 4*Real.sqrt (|(P.normAlpha : ℝ)|/P.d) ≤ q.y) :
    let z := star p.point * q.point
    ∃ η : ℂ, FourthPhase η ∧
      (∀ ζ : ℂ, FourthPhase ζ →
        ‖P.sequenceOmega h.pell i ^ (1/4 : ℂ) - η*(star z/z)‖ ≤
        ‖P.sequenceOmega h.pell i ^ (1/4 : ℂ) - ζ*(star z/z)‖) ∧
      ‖P.sequenceOmega h.pell i ^ (1/4 : ℂ) - η*(star z/z)‖ < (127/1000 : ℝ) ∧
      (3959/1000 : ℝ)*‖P.sequenceOmega h.pell i ^ (1/4 : ℂ) - η*(star z/z)‖ <
        2*Real.sqrt |(P.normAlpha : ℝ)|/(Real.sqrt P.d*q.y) ∧
      ∃ p₀ q₀ : Section2.GaussianField, IsIntegral ℤ p₀ ∧ IsIntegral ℤ q₀ ∧ q₀ ≠ 0 ∧
        Section2.gaussianEmbedding p₀ = η*star z ∧ Section2.gaussianEmbedding q₀ = z ∧
        ‖Section2.gaussianEmbedding q₀‖ = Real.sqrt (p.f*q.f)*(p.y*q.y)^(1/4 : ℝ)/P.b ∧
        p.f*q.f ≤ (P.b : ℝ)^4 := by
  let z := star p.point*q.point
  have hz : z ≠ 0 := mul_ne_zero (star_ne_zero.mpr p.point_ne) q.point_ne
  have hv : ‖star z/z‖ = 1 := by rw [norm_div,norm_star,div_self (norm_ne_zero_iff.mpr hz)]
  have hres := P.sequence_cross_residual_published h hn p q hp hq
  have hr : ‖P.sequenceOmega h.pell i - (star z/z)^4‖ = 2*P.gapScale/q.y :=
    (eq_div_iff (ne_of_gt q.y_pos)).mpr hres
  have hpos : 0 < ‖P.sequenceOmega h.pell i - (star z/z)^4‖ := by
    rw [hr]; exact div_pos (mul_pos (by norm_num) (P.gapScale_pos h.b_pos hn)) q.y_pos
  have hsmall : ‖P.sequenceOmega h.pell i - (star z/z)^4‖ ≤ 1/2 := by
    rw [hr]
    apply (div_le_iff₀ q.y_pos).mpr
    have he := P.gapScale_eq_sqrt h.b_pos hn
    linarith only [he,hlarge]
  obtain ⟨η,hη,hmin,hclose,herr⟩ := Section4.comparison_phase_3959
    (P.sequenceOmega_norm h.pell hn i) hv hpos hsmall
  have hroot : 2*P.gapScale/q.y = 2*Real.sqrt |(P.normAlpha : ℝ)|/(Real.sqrt P.d*q.y) := by
    calc
      2*P.gapScale/q.y = 2*Real.sqrt (|(P.normAlpha : ℝ)|/P.d)/q.y := by
        congr 1
        rw [P.gapScale_eq_sqrt h.b_pos hn]
      _ = _ := by rw [Real.sqrt_div (abs_nonneg _)]; ring
  rw [hr,hroot] at herr
  have hS : -squarefreePart P.normAlpha = 1 := by
    rw [squarefreePart_eq_neg_one (ne_of_lt hn) hNs]; norm_num
  have hpoint (a : P.SequenceDatum) : a.point = quadraticPoint 1 a.r a.s := by
    simp only [FourthPowerDatum.point,hS]
  obtain ⟨p₀,q₀,hp₀,hq₀,hep,heq⟩ := Section4.comparison_integers p.r p.s q.r q.s hη
  rw [← hpoint p,← hpoint q] at hep heq
  have hqne : q₀ ≠ 0 := by
    intro he
    have hh : (0 : ℂ) = z := by simpa only [he,map_zero] using heq
    exact hz hh.symm
  refine ⟨η,hη,hmin,hclose,herr,p₀,q₀,hp₀,hq₀,hqne,hep,heq,?_,?_⟩
  · rw [heq]
    have hh := p.cross_denominator_norm q (by exact_mod_cast h.b_pos)
    have hroot4 : Real.sqrt (Real.sqrt (p.y*q.y)) = (p.y*q.y)^(1/4 : ℝ) := by
      rw [Real.sqrt_eq_rpow,Real.sqrt_eq_rpow,← Real.rpow_mul (mul_nonneg p.y_pos.le q.y_pos.le)]
      norm_num
    rw [hroot4] at hh
    simpa only [norm_mul,norm_star] using hh
  · have hh := mul_le_mul hpf hqf q.f_pos.le (sq_nonneg (P.b : ℝ))
    nlinarith only [hh]

/-- The stronger size assumption (4.4) implies the coordinate-size assumption
in (4.2). This uses |N_alpha|>=1 for a nonzero integer norm. -/
theorem threshold_implies_coordinate_size (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) {y : ℝ}
    (hy : 4*|(P.normAlpha : ℝ)|/Real.sqrt P.d ≤ y) :
    4*Real.sqrt (|(P.normAlpha : ℝ)|/P.d) ≤ y := by
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hN1 : (1 : ℝ) ≤ |(P.normAlpha : ℝ)| := by
    rw [abs_of_neg (by exact_mod_cast hn)]
    exact_mod_cast (show (1 : ℤ) ≤ -P.normAlpha by omega)
  have hs := Real.sqrt_le_self_iff.mpr (Or.inr hN1)
  have hh := (div_le_iff₀ (Real.sqrt_pos.mpr hd)).mp hy
  rw [Real.sqrt_div (abs_nonneg _),← mul_div_assoc]
  apply (div_le_iff₀ (Real.sqrt_pos.mpr hd)).mpr
  linarith

/-- The actual E,Q,ell and near-one prerequisites, with b arbitrary and
with their displayed estimates derived from (4.4), rather than assumed. -/
theorem application_parameters (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha)) {k X Y : ℤ}
    (hx : P.x h.pell k = (X : ℚ)) (hy : P.y h.pell k = (Y : ℚ))
    (hlarge : 4*|(P.normAlpha : ℝ)|/Real.sqrt P.d ≤ (Y : ℝ)) :
    let u₁ := 2*X
    let u₂ := 2*unitPowerNorm P k*squareFactor P.normAlpha
    let M := normalizerProduct (-1) u₁ u₂
    let L := Real.sqrt P.d*(Y : ℝ)
    let N := |(P.normAlpha : ℝ)|
    M ≤ L ∧ 2 ≤ M ∧
    (1832/10000 : ℝ)*M*L/N < Section2.E (-1) u₁ u₂ ∧ 1 < Section2.E (-1) u₁ u₂ ∧
    (2112/100 : ℝ) < Section2.Q (-1) u₁ u₂ ∧
    Section2.Q (-1) u₁ u₂ < (2147/100 : ℝ)*L/M ∧
    Section2.ell (-1) u₁ u₂ < (615/1000 : ℝ)*Real.sqrt N/|(X : ℝ)| ∧
    ‖Section2.omega (-1) u₁ u₂-1‖ < 1 := by
  let Z := unitPowerNorm P k*squareFactor P.normAlpha
  let M := normalizerProduct (-1) (2*X) (2*Z)
  let L := Real.sqrt P.d*(Y : ℝ)
  let N := |(P.normAlpha : ℝ)|
  have hc := sequence_coordinates P h hn hNs hx hy
  have hN : 0 < N := abs_pos.mpr (by exact_mod_cast ne_of_lt hn)
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hsize := threshold_implies_coordinate_size P h hn hlarge
  have hypos : (0 : ℝ) < Y := lt_of_lt_of_le (by positivity) hsize
  have hL : 0 < L := mul_pos (Real.sqrt_pos.mpr hd) hypos
  have hL4 : 4*N ≤ L := by
    have hh := (div_le_iff₀ (Real.sqrt_pos.mpr hd)).mp hlarge
    simpa only [mul_comm (Y : ℝ)] using hh
  have hnrm := gaussian_normalizer_bounds (X := X) (squareFactor_pos (ne_of_lt hn))
    (unitPowerNorm_sign P h.pell k)
  have hM2 : 2 ≤ M := by simpa only [M,Z,mul_assoc] using hnrm.1
  have hM : 0 < M := by linarith
  have hC2 : (squareFactor P.normAlpha : ℝ)^2 = N := by
    have hh := squareFactor_sq_mul P.normAlpha
    rw [squarefreePart_eq_neg_one (ne_of_lt hn) hNs] at hh
    dsimp [N]; rw [abs_of_neg (by exact_mod_cast hn)]
    exact_mod_cast (show (squareFactor P.normAlpha)^2 = -P.normAlpha by linarith only [hh])
  have hML : M ≤ L := by
    have hh := lt_of_le_of_lt hnrm.2.1 hnrm.2.2
    rw [hC2] at hh
    have hh' : M < 4*N := by simpa only [M,Z,mul_assoc] using hh
    exact hh'.le.trans hL4
  have hnorm : (X : ℝ)^2 = P.d*(Y : ℝ)^2-N := by
    have hh := hc.2.2.1
    rw [mul_pow,Real.sq_sqrt hd.le] at hh
    linarith
  have hlow : (15/16 : ℝ)*L^2 ≤ (X : ℝ)^2 := by
    have hh := (coordinate_bounds hN hd hsize hnorm).1
    simpa only [L,mul_pow,Real.sq_sqrt hd.le,mul_assoc] using hh
  have hhigh : |(X : ℝ)| < L := by
    have hh : (X : ℝ)^2+N=L^2 := hc.2.2.1
    nlinarith [sq_abs (X : ℝ),abs_nonneg (X : ℝ)]
  have hbounds := parameter_bounds hN hM hL hlow hhigh
  have hform := Section4.gaussian_parameters hL hc.1 hc.2.2.1
  rw [← hform.1,← hform.2] at hbounds
  have hE : 1 < Section2.E (-1) (2*X) (2*Z) := by
    have hprod := mul_le_mul hM2 hL4 (by positivity : 0 ≤ 4*N) hM.le
    have hh : 1 < (1832/10000 : ℝ)*M*L/N := by
      apply (lt_div_iff₀ hN).mpr
      nlinarith only [hprod,hN]
    exact hh.trans hbounds.1
  have hQ := (Revision06f.gaussian_Q_gt hL hc.1 hc.2.2.1 hlow hM hML).1
  have hgauss := Section4.gaussian_input_bounds hc.2.1 (by
    have hh : 15*(Z : ℝ)^2 ≤ (X : ℝ)^2 := by
      have hcoord : (X : ℝ)^2+N=L^2 := hc.2.2.1
      have hzsq : (Z : ℝ)^2=N := hc.1
      nlinarith only [hlow,hcoord,hzsq]
    exact_mod_cast hh)
  have hroot : |(Z : ℝ)| = Real.sqrt N := by
    change |(Z : ℝ)| = Real.sqrt |(P.normAlpha : ℝ)|
    rw [← hc.1,Real.sqrt_sq_eq_abs]
  have hell := hgauss.2
  rw [hroot] at hell
  have hresult := And.intro hML (And.intro hM2 (And.intro hbounds.1
    (And.intro hE (And.intro hQ (And.intro hbounds.2 (And.intro hell hgauss.1))))))
  simpa only [M,L,N,Z,mul_assoc] using hresult

/-- All data below are constructed by `prepare`, not external mathematical assumptions. -/
structure Prepared (P : Parameters) (h : P.Admissible) (i j : ℤ) where
  X : ℤ
  Y : ℤ
  hx : P.x h.pell i = (X : ℚ)
  hy : P.y h.pell i = (Y : ℚ)
  left : P.SequenceDatum
  right : P.SequenceDatum
  left_certificate : P.SequenceGapCertificate h.pell i left
  right_certificate : P.SequenceGapCertificate h.pell j right
  eta : ℂ
  phase : FourthPhase eta
  numerator : Section2.GaussianField
  denominator : Section2.GaussianField
  numerator_integral : IsIntegral ℤ numerator
  denominator_integral : IsIntegral ℤ denominator
  denominator_ne : denominator ≠ 0
  numerator_embedding : Section2.gaussianEmbedding numerator = eta*star (star left.point*right.point)
  denominator_embedding : Section2.gaussianEmbedding denominator = star left.point*right.point
  denominator_norm : ‖Section2.gaussianEmbedding denominator‖ =
    Real.sqrt (left.f*right.f)*(left.y*right.y)^(1/4 : ℝ)/P.b
  f_product : left.f*right.f ≤ (P.b : ℝ)^4
  comparison_bound : (3959/1000 : ℝ)*
    ‖P.sequenceOmega h.pell i ^ (1/4 : ℂ) -
      eta*(star (star left.point*right.point)/(star left.point*right.point))‖ <
      2*Real.sqrt |(P.normAlpha : ℝ)|/(Real.sqrt P.d*right.y)
  E_gt_one : 1 < Section2.E (-1) (2*X) (2*unitPowerNorm P i*squareFactor P.normAlpha)
  Q_gt_one : 1 < Section2.Q (-1) (2*X) (2*unitPowerNorm P i*squareFactor P.normAlpha)
  near_one : ‖Section2.omega (-1) (2*X) (2*unitPowerNorm P i*squareFactor P.normAlpha)-1‖ < 1

/-- Prepare Section 4.1 from its actual index, square, normalization and
size assumptions. The larger of the chosen square values cannot have index zero. -/
theorem prepare (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha))
    (hmin : SmallestInitialSquare P h.pell) (K : ℤ) (hK : P.IsNegativeCutoff h.pell K)
    {i j : ℤ} (hi : 1 ≤ i ∨ i ≤ K)
    (hsi : IsIntegerSquare (P.y h.pell i)) (hsj : IsIntegerSquare (P.y h.pell j))
    (hij : (P.y h.pell i : ℝ) < (P.y h.pell j : ℝ))
    (hsize : max (4*|(P.normAlpha : ℝ)|/Real.sqrt P.d)
      ((P.b : ℝ)^2*|(P.normAlpha : ℝ)|/P.d) ≤ (P.y h.pell i : ℝ)) :
    Nonempty (Prepared P h i j) := by
  have hi0 : i ≠ 0 := by have hh := hK.1; omega
  have hj0 : j ≠ 0 := by
    intro he
    have hm : (P.b : ℝ)^2 ≤ (P.y h.pell i : ℝ) := by exact_mod_cast hmin i hsi
    rw [he,P.y_zero] at hij
    push_cast at hij
    linarith
  have hlarge := le_trans (le_max_left _ _) hsize
  have hcoordsize := threshold_implies_coordinate_size P h hn hlarge
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hN : 0 < |(P.normAlpha : ℝ)| := abs_pos.mpr (by exact_mod_cast ne_of_lt hn)
  have hyi : (0 : ℝ) < (P.y h.pell i : ℝ) := lt_of_lt_of_le (by positivity) hcoordsize
  have hyj := hyi.trans hij
  obtain ⟨X,Y,hx,hy,_⟩ := P.section4_integer_coordinates h.pell hsi
  have hYlarge : 4*|(P.normAlpha : ℝ)|/Real.sqrt P.d ≤ (Y : ℝ) := by
    simpa only [hy,Rat.cast_intCast] using hlarge
  have hpars := application_parameters P h hn hNs hx hy hYlarge
  obtain ⟨p,hp,hpf,_⟩ := sequence_certificate P h hn hNs hi0 hsi (by exact_mod_cast hyi)
  obtain ⟨q,hq,hqf,_⟩ := sequence_certificate P h hn hNs hj0 hsj (by exact_mod_cast hyj)
  have hqsize : 4*Real.sqrt (|(P.normAlpha : ℝ)|/P.d) ≤ q.y := by
    rw [hq.1]; exact hcoordsize.trans hij.le
  obtain ⟨η,hη,_,_,herr,p₀,q₀,hp₀,hq₀,hqne,hep,heq,hqnorm,hfprod⟩ :=
    comparison_pair P h hn hNs p q hp hq hpf hqf hqsize
  refine ⟨{
    X := X
    Y := Y
    hx := hx
    hy := hy
    left := p
    right := q
    left_certificate := hp
    right_certificate := hq
    eta := η
    phase := hη
    numerator := p₀
    denominator := q₀
    numerator_integral := hp₀
    denominator_integral := hq₀
    denominator_ne := hqne
    numerator_embedding := hep
    denominator_embedding := heq
    denominator_norm := hqnorm
    f_product := hfprod
    comparison_bound := herr
    E_gt_one := hpars.2.2.2.1
    Q_gt_one := ?_
    near_one := hpars.2.2.2.2.2.2.2 }⟩
  exact lt_trans (by norm_num) hpars.2.2.2.2.1

/-- Lemma 2.1 with c=3/4 for the prepared comparison pair. The sole unresolved
analytic input is passed explicitly, just as in the preceding checkpoint. -/
theorem apply_prepared (hPrior : Hypergeometric.DenominatorEstimate4)
    (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (hNs : IsSquare (-P.normAlpha)) {i j : ℤ} (a : Prepared P h i j) :
    let u₁ := 2*a.X
    let u₂ := 2*unitPowerNorm P i*squareFactor P.normAlpha
    ∃ data : Section2.PaperApproximants u₁ u₂,
    let r := Approximation.firstIndex (Q := Section2.Q (-1) u₁ u₂)
      (ℓ := Section2.ell (-1) u₁ u₂) a.E_gt_one (by norm_num : (0 : ℝ) < 3/4)
        (Section2.gaussianEmbedding a.denominator)
    (1-(3/4 : ℝ)/Section2.E (-1) u₁ u₂)/(paperK0*Section2.Q (-1) u₁ u₂^(r+1)) <
        ‖Section2.gaussianEmbedding a.denominator*Section2.omega (-1) u₁ u₂^(1/4 : ℂ)-
          Section2.gaussianEmbedding a.numerator‖ ∧
    (data.pr r*a.denominator-data.qr r*a.numerator ≠ 0 →
      (1-(3/4 : ℝ))/(paperK0*Section2.Q (-1) u₁ u₂^r) <
        ‖Section2.gaussianEmbedding a.denominator*Section2.omega (-1) u₁ u₂^(1/4 : ℂ)-
          Section2.gaussianEmbedding a.numerator‖) := by
  have hc := sequence_coordinates P h hn hNs a.hx a.hy
  have hu₂ : 2*unitPowerNorm P i*squareFactor P.normAlpha ≠ 0 := by
    simpa only [mul_assoc] using mul_ne_zero (by decide : (2 : ℤ) ≠ 0) hc.2.1
  have hU : IsIntegral ℤ (Section2.U (-1) (2*a.X)
      (2*unitPowerNorm P i*squareFactor P.normAlpha)) := by
    simpa only [mul_assoc] using Section4.gaussian_U_integral a.X
      (unitPowerNorm P i*squareFactor P.normAlpha)
  exact Construction.lemma21_conditional hPrior hU hu₂ a.near_one
    a.numerator a.denominator a.numerator_integral a.denominator_integral
    (by rintro ⟨_,hq⟩; exact a.denominator_ne hq) a.E_gt_one a.Q_gt_one
    (by norm_num) (by norm_num)

/-- End-to-end Section 4.1 checkpoint, conditional only on the explicitly
unproved denominator estimate in addition to the manuscript hypotheses. -/
theorem prepare_and_apply (hPrior : Hypergeometric.DenominatorEstimate4)
    (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha))
    (hmin : SmallestInitialSquare P h.pell) (K : ℤ) (hK : P.IsNegativeCutoff h.pell K)
    {i j : ℤ} (hi : 1 ≤ i ∨ i ≤ K)
    (hsi : IsIntegerSquare (P.y h.pell i)) (hsj : IsIntegerSquare (P.y h.pell j))
    (hij : (P.y h.pell i : ℝ) < (P.y h.pell j : ℝ))
    (hsize : max (4*|(P.normAlpha : ℝ)|/Real.sqrt P.d)
      ((P.b : ℝ)^2*|(P.normAlpha : ℝ)|/P.d) ≤ (P.y h.pell i : ℝ)) :
    ∃ a : Prepared P h i j,
    let u₁ := 2*a.X
    let u₂ := 2*unitPowerNorm P i*squareFactor P.normAlpha
    ∃ data : Section2.PaperApproximants u₁ u₂,
    let r := Approximation.firstIndex (Q := Section2.Q (-1) u₁ u₂)
      (ℓ := Section2.ell (-1) u₁ u₂) a.E_gt_one (by norm_num : (0 : ℝ) < 3/4)
        (Section2.gaussianEmbedding a.denominator)
    (1-(3/4 : ℝ)/Section2.E (-1) u₁ u₂)/(paperK0*Section2.Q (-1) u₁ u₂^(r+1)) <
        ‖Section2.gaussianEmbedding a.denominator*Section2.omega (-1) u₁ u₂^(1/4 : ℂ)-
          Section2.gaussianEmbedding a.numerator‖ ∧
    (data.pr r*a.denominator-data.qr r*a.numerator ≠ 0 →
      (1-(3/4 : ℝ))/(paperK0*Section2.Q (-1) u₁ u₂^r) <
        ‖Section2.gaussianEmbedding a.denominator*Section2.omega (-1) u₁ u₂^(1/4 : ℂ)-
          Section2.gaussianEmbedding a.numerator‖) := by
  obtain ⟨a⟩ := prepare P h hn hNs hmin K hK hi hsi hsj hij hsize
  exact ⟨a,apply_prepared hPrior P h hn hNs a⟩

end AnyBNormSquare.Prerequisites
