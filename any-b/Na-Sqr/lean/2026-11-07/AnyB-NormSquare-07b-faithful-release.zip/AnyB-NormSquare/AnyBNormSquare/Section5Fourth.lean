module

public import AnyBNormSquare.Revision06g

@[expose] public section
namespace AnyBNormSquare.Section5Fourth

/-- (5.12), retaining G and setting n = r₀ - 1. -/
noncomputable def fourthDBound (n b u N G : ℝ) : ℝ :=
  (264:ℝ)^(2*n/(3*n+1))*b^(4*(n+1)/(3*n+1))*N^((n+1)/(3*n+1))*
  (5233/1000:ℝ)^(1/(3*n+1))/(u^(8*n/(3*n+1))*G^(4*n/(3*n+1)))

theorem fourth_rearrange {b d N u y G n : ℝ}
    (hb : 0 < b) (hd : 0 < d) (hu : 0 < u) (hN : 0 < N)
    (hG : 0 < G) (hn : 1 ≤ n)
    (hl : (99/400:ℝ)*N*d*u^4/b^2 ≤ y)
    (hh : y < (6532/100:ℝ)*(5233/1000:ℝ)^(1/(2*n))*b^(2/n)*
       N^((3/2:ℝ)+1/(2*n))/(G^2*d^((1/2:ℝ)+1/(2*n)))) :
    d < fourthDBound n b u N G := by
  have hn0 : 0 < n := by linarith
  have hz : 0 < 3*n+1 := by linarith
  have hc := Real.log_lt_log (by positivity) (hl.trans_lt hh)
  have hr := Real.log_lt_log (by norm_num : (0:ℝ)<(6532/100)/(99/400))
    (by norm_num : (6532/100:ℝ)/(99/400)<264)
  unfold fourthDBound
  apply (Real.log_lt_log_iff hd (by positivity)).mp
  simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_pow, Real.log_rpow] at hc hr ⊢
  norm_num1 at hc hr ⊢
  field_simp (disch := positivity) at hc ⊢
  have hcm := mul_lt_mul_of_pos_left hr (show 0 < 2*n by positivity)
  linarith only [hc,hcm]

/-- The constant factor and exponents in the deduction of (5.13). -/
theorem fourth_simplify {n b u N G : ℝ} (hn : 1 ≤ n) (hb : 1 ≤ b)
    (hu : 1 ≤ u) (hN : 1 ≤ N) (hG : 2 ≤ G) :
    fourthDBound n b u N G < (1634/100:ℝ)*b^2*N^(1/2:ℝ)/u^2 := by
  have hb' : 0 < b := by linarith
  have hu' : 0 < u := by linarith
  have hN' : 0 < N := by linarith
  have hg : 0 < G := by linarith
  have hz : 0 < 3*n+1 := by linarith
  have hc := Real.log_lt_log (by norm_num : 0 < (264:ℝ)^2/2^4)
    (by norm_num : (264:ℝ)^2/2^4 < (1634/100:ℝ)^3)
  have hr := Real.log_lt_log (by norm_num : 0 < (5233/1000:ℝ)^3*2^4/264^2)
    (by norm_num : (5233/1000:ℝ)^3*2^4/264^2 < 1)
  have hg' := Real.log_le_log (by norm_num : (0:ℝ)<2) hG
  unfold fourthDBound
  apply (Real.log_lt_log_iff (by positivity) (by positivity)).mp
  simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_rpow, Real.log_pow, Real.log_one] at hc hr ⊢
  norm_num1 at hc hr ⊢
  field_simp (disch := positivity)
  have hbcmp := mul_nonneg (sub_nonneg.mpr hn) (Real.log_nonneg hb)
  have hucmp := mul_nonneg (sub_nonneg.mpr hn) (Real.log_nonneg hu)
  have hNcmp := mul_nonneg (sub_nonneg.mpr hn) (Real.log_nonneg hN)
  have hbase := mul_lt_mul_of_pos_left hc hz
  have hgcmp := mul_le_mul_of_nonneg_left hg' (show 0 ≤ 4*n by linarith)
  linarith only [hbcmp,hucmp,hNcmp,hbase,hr,hgcmp]

/-- The 06g division and positive-power step with the inequality read from
the case bounds: a possible triple forces d below the resulting expression. -/
private theorem moving_d {d C r : ℝ} (hd : 0 < d) (hr : 2 ≤ r)
    (h : d < C*d^(r/(3*r-2))) : d < C^((3*r-2)/(2*(r-1))) := by
  have hdiv := (div_lt_iff₀ (Real.rpow_pos_of_pos hd (r/(3*r-2)))).mpr h
  have he := Revision06g.exponent_identities hr
  have hpow : d^(2*(r-1)/(3*r-2)) < C := by
    simpa only [← he.1, Real.rpow_sub hd, Real.rpow_one] using hdiv
  have hh := Real.rpow_lt_rpow (Real.rpow_nonneg hd.le _) hpow (Revision06g.exponent_positive hr)
  simpa only [← Real.rpow_mul hd.le, he.2.1, Real.rpow_one] using hh

theorem fourth_norm_free {d n b u N G : ℝ} (hd : 0 < d) (hn : 1 ≤ n)
    (hb : 1 ≤ b) (hu : 0 < u) (hN : 0 < N) (hG : 2 ≤ G)
    (hs : N < d*b^4) (hh : d < fourthDBound n b u N G) :
    d < 151*b^8/u^4 := by
  have hb' : 0 < b := by linarith
  have hg : 0 < G := by linarith
  have hn0 : 0 < n := by linarith
  have hz : 0 < 3*n+1 := by linarith
  let C : ℝ := (264^2/G^4)^(n/(3*n+1))*b^(8*(n+1)/(3*n+1))*
      (5233/1000:ℝ)^(1/(3*n+1))/u^(8*n/(3*n+1))
  have hC : 0 < C := by dsimp [C]; positivity
  have hpre : d < C*d^((n+1)/(3*(n+1)-2)) := by
    have hh' := Real.log_lt_log hd hh
    have hs' := Real.log_lt_log hN hs
    replace hs' := mul_lt_mul_of_pos_left hs' (show 0 < n+1 by linarith)
    unfold fourthDBound at hh'
    apply (Real.log_lt_log_iff hd (by positivity)).mp
    dsimp [C]
    rw [show 3*(n+1)-2=3*n+1 by ring]
    simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_pow, Real.log_rpow] at hh' hs' ⊢
    norm_num1 at hh' hs' ⊢
    field_simp (disch := positivity) at hh' ⊢
    linarith only [hs',hh']
  have hm := moving_d hd (show 2 ≤ n+1 by linarith) hpre
  rw [show 3*(n+1)-2=3*n+1 by ring,show n+1-1=n by ring] at hm
  apply hm.trans
  apply (Real.log_lt_log_iff (Real.rpow_pos_of_pos hC _) (by positivity)).mp
  have hc := Real.log_lt_log (by norm_num : 0 < (264:ℝ)^2*(5233/1000)/2^4)
    (by norm_num : (264:ℝ)^2*(5233/1000)/2^4 < 151^2)
  have hr := Real.log_nonneg (by norm_num : (1:ℝ) ≤ 5233/1000)
  have hgc := Real.log_le_log (by norm_num : (0:ℝ)<2) hG
  dsimp [C]
  simp (disch := positivity) only [Real.log_mul,Real.log_div,Real.log_rpow,Real.log_pow] at hc hr ⊢
  norm_num1 at hc hr ⊢
  ring_nf
  -- Cancel the reciprocal exponent against the powers defining C.
  field_simp (disch := positivity)
  have hbase := mul_lt_mul_of_pos_left hc hn0
  have hrem := mul_nonneg (sub_nonneg.mpr hn) hr
  have hbcmp := mul_nonneg (sub_nonneg.mpr hn) (Real.log_nonneg hb)
  have hgcmp := mul_le_mul_of_nonneg_left hgc (show 0 ≤ 4*n by linarith)
  linarith only [mul_lt_mul_of_pos_left hbase hz, mul_nonneg hz.le hrem, mul_nonneg hz.le hbcmp, mul_le_mul_of_nonneg_left hgcmp hz.le]

end AnyBNormSquare.Section5Fourth
