module

public import «JNT-2024».RepresentationFactors
public import «JNT-2024».Lemma54
public import «JNT-2024».Lemma54CasesPublished
public import Mathlib.NumberTheory.SumTwoSquares

@[expose] public section

/-!
# Lemma 3.6 of the exact supplied 2026-11-06c manuscript

Source: `lem:admissible-b`, TeX lines 785--813. The proof uses the prime
factorisation of a sum of two squares, excludes primes congruent to 3 modulo
4, then treats 2 separately, retaining the split at its exponent 4 and the
printed square-residue argument modulo 16.
-/

namespace AnyBNormSquare
open «JNT-2024»

namespace Lemma36Proof

/-- The positive integer being factorised, represented in `ℕ` for mathlib's
canonical prime factorisation. -/
def sumSquaresNat (a n : ℤ) : ℕ := a.natAbs ^ 2 + n.natAbs ^ 2

theorem sumSquaresNat_cast (a n : ℤ) :
    (sumSquaresNat a n : ℤ) = a ^ 2 + n ^ 2 := by
  simp [sumSquaresNat, sq_abs]

theorem sumSquaresNat_pos {a n : ℤ} (ha : 0 < a) : 0 < sumSquaresNat a n := by
  exact add_pos_of_pos_of_nonneg (pow_pos (Int.natAbs_pos.mpr (ne_of_gt ha)) 2)
    (Nat.zero_le _)

/-- Supporting the known common-divisor fact cited in TeX 797--798:
a prime `q = 3 mod 4` dividing a sum of two squares divides both coordinates.
This uses the same pinned mathlib quadratic-residue result used by JNT. -/
theorem prime_divides_both {q : ℕ} (hq : q.Prime) (hq4 : q % 4 = 3)
    {a n : ℤ} (hs : (q : ℤ) ∣ a ^ 2 + n ^ 2) :
    (q : ℤ) ∣ a ∧ (q : ℤ) ∣ n := by
  let : Fact q.Prime := ⟨hq⟩
  have hz := (ZMod.intCast_zmod_eq_zero_iff_dvd (a ^ 2 + n ^ 2) q).mpr hs
  push_cast at hz
  have he : (a : ZMod q) ^ 2 = -(n : ZMod q) ^ 2 := by linear_combination hz
  have hn : (n : ZMod q) = 0 := by
    by_contra hn
    exact (ZMod.mod_four_ne_three_of_sq_eq_neg_sq' hn he) hq4
  have ha : (a : ZMod q) = 0 := by
    rw [hn, zero_pow (by decide : 2 ≠ 0), add_zero] at hz
    exact sq_eq_zero_iff.mp hz
  exact ⟨(ZMod.intCast_zmod_eq_zero_iff_dvd a q).mp ha,
    (ZMod.intCast_zmod_eq_zero_iff_dvd n q).mp hn⟩

/-- The common `q^m` factor in the factorisation fact quoted by the paper.
This expands that supporting fact; the main proof below uses the printed
exponent `2m`, rather than replacing the factorisation argument. -/
theorem prime_power_divides_both {q : ℕ} (hq : q.Prime) (hq4 : q % 4 = 3)
    (m : ℕ) {a n : ℤ} (hs : (q : ℤ) ^ (2 * m) ∣ a ^ 2 + n ^ 2) :
    (q : ℤ) ^ m ∣ a ∧ (q : ℤ) ^ m ∣ n := by
  induction m generalizing a n with
  | zero => simp
  | succ m ih =>
    have hqz : (q : ℤ) ≠ 0 := by exact_mod_cast hq.ne_zero
    have hqdiv : (q : ℤ) ∣ a ^ 2 + n ^ 2 :=
      (dvd_pow_self (q : ℤ) (by omega : 2 * (m + 1) ≠ 0)).trans hs
    obtain ⟨ha, hn⟩ := prime_divides_both hq hq4 hqdiv
    obtain ⟨A, rfl⟩ := ha
    obtain ⟨N, rfl⟩ := hn
    rw [show 2 * (m + 1) = 2 + 2 * m by omega, pow_add,
      show ((q : ℤ) * A) ^ 2 + ((q : ℤ) * N) ^ 2 =
        (q : ℤ) ^ 2 * (A ^ 2 + N ^ 2) by ring] at hs
    have hsmall := (mul_dvd_mul_iff_left (pow_ne_zero 2 hqz)).mp hs
    obtain ⟨hA, hN⟩ := ih hsmall
    constructor
    · simpa only [pow_succ, mul_comm] using mul_dvd_mul_left (q : ℤ) hA
    · simpa only [pow_succ, mul_comm] using mul_dvd_mul_left (q : ℤ) hN

/-- TeX 793--798, expressed with canonical finite prime factorisation.
For every prime factor `q = 3 mod 4` the exponent is `2m`, with `m > 0`,
and `q^m` divides both `a` and `n`, precisely as in the printed factorisation. -/
theorem sum_prime_factorization {a n : ℤ} (ha : 0 < a) (_hn : 0 < n) :
    (sumSquaresNat a n).factorization.prod (fun p e => p ^ e) = sumSquaresNat a n ∧
    ∀ q ∈ (sumSquaresNat a n).primeFactors, q % 4 = 3 →
      ∃ m : ℕ, 0 < m ∧ (sumSquaresNat a n).factorization q = 2 * m ∧
        (q : ℤ) ^ m ∣ a ∧ (q : ℤ) ^ m ∣ n := by
  have hS := ne_of_gt (sumSquaresNat_pos (n := n) ha)
  refine ⟨Nat.prod_factorization_pow_eq_self hS, ?_⟩
  intro q hqmem hq4
  have hq := Nat.prime_of_mem_primeFactors hqmem
  let : Fact q.Prime := ⟨hq⟩
  have hqd := Nat.dvd_of_mem_primeFactors hqmem
  have heven := Nat.eq_sq_add_sq_iff.mp
    (show ∃ x y : ℕ, sumSquaresNat a n = x ^ 2 + y ^ 2 from ⟨a.natAbs, n.natAbs, rfl⟩)
    q hqmem hq4
  obtain ⟨m, hm⟩ := heven
  have he : padicValNat q (sumSquaresNat a n) = 2 * m := by omega
  have hv := one_le_padicValNat_of_dvd hS hqd
  have hpow : q ^ (2 * m) ∣ sumSquaresNat a n := by
    rw [← he]
    exact pow_padicValNat_dvd
  have hpowZ : (q : ℤ) ^ (2 * m) ∣ a ^ 2 + n ^ 2 := by
    rw [← sumSquaresNat_cast]
    exact_mod_cast hpow
  obtain ⟨hA, hN⟩ := prime_power_divides_both hq hq4 m hpowZ
  exact ⟨m, by omega, by rw [Nat.factorization_def _ hq, he], hA, hN⟩

/-- The consequence `q^4 | a^2+n^2` of `q | b` and the printed equation. -/
theorem fourth_power_dvd_sum {a b d n p : ℤ} (he : d * b ^ 4 - a ^ 2 = n ^ 2)
    (hp : p ∣ b) : p ^ 4 ∣ a ^ 2 + n ^ 2 := by
  have hs : a ^ 2 + n ^ 2 = d * b ^ 4 := by linarith
  rw [hs]
  exact dvd_mul_of_dvd_right (pow_dvd_pow_of_dvd hp 4) d

/-- A prime square dividing both `a` and `b²` contradicts the paper's
squarefreeness assumption on their gcd. -/
theorem no_prime_square_gcd {a b : ℤ} (h : Squarefree (Int.gcd a (b ^ 2)))
    {p : ℕ} (hp : p.Prime) (ha : (p : ℤ) ^ 2 ∣ a) (hb : (p : ℤ) ^ 2 ∣ b ^ 2) : False := by
  have hz : Squarefree (Int.gcd a (b ^ 2) : ℤ) := Int.squarefree_natCast.mpr h
  apply (Int.squarefree_iff_prime_sq_not_dvd.mp hz p hp)
  exact_mod_cast (Int.dvd_gcd ha hb)

/-- TeX 800--803: the exponent is at least four, hence `m ≥ 2`, giving the
prime-square contradiction exactly as printed. -/
theorem exclude_three_mod_four {a b d n : ℤ} (ha : 0 < a) (hn : 0 < n)
    (hg : Squarefree (Int.gcd a (b ^ 2))) (he : d * b ^ 4 - a ^ 2 = n ^ 2)
    {q : ℕ} (hq : q.Prime) (hq4 : q % 4 = 3) : ¬ (q : ℤ) ∣ b := by
  intro hqb
  let : Fact q.Prime := ⟨hq⟩
  have hfour := fourth_power_dvd_sum he hqb
  have hfourNat : q ^ 4 ∣ sumSquaresNat a n := by
    have hh : (q : ℤ) ^ 4 ∣ (sumSquaresNat a n : ℤ) := by
      rwa [sumSquaresNat_cast]
    exact_mod_cast hh
  have hqd := (dvd_pow_self q (by decide : 4 ≠ 0)).trans hfourNat
  have hS := ne_of_gt (sumSquaresNat_pos (n := n) ha)
  have hmem := Nat.mem_primeFactors.mpr ⟨hq, hqd, hS⟩
  obtain ⟨m, hm, heq, hqa, _⟩ := (sum_prime_factorization ha hn).2 q hmem hq4
  have hv : 4 ≤ padicValNat q (sumSquaresNat a n) :=
    (padicValNat_dvd_iff_le hS).mp hfourNat
  rw [Nat.factorization_def _ hq] at heq
  have hm2 : 2 ≤ m := by omega
  have hqa2 : (q : ℤ) ^ 2 ∣ a := (pow_dvd_pow (q : ℤ) hm2).trans hqa
  exact no_prime_square_gcd hg hq hqa2 (pow_dvd_pow_of_dvd hqb 2)

/-- The four square residues printed in TeX 807--808. The finite check is
evaluated by the Lean kernel. -/
theorem square_residues16 : ∀ x : ZMod 16, x ^ 2 = 0 ∨ x ^ 2 = 1 ∨ x ^ 2 = 4 ∨ x ^ 2 = 9 := by
  decide +kernel

/-- The printed list of nonzero possible sums, with the zero case isolated. -/
theorem sum_square_residues16 (x y : ZMod 16) :
    (x ^ 2 = 0 ∧ y ^ 2 = 0) ∨
    x ^ 2 + y ^ 2 = 1 ∨ x ^ 2 + y ^ 2 = 2 ∨ x ^ 2 + y ^ 2 = 4 ∨
    x ^ 2 + y ^ 2 = 5 ∨ x ^ 2 + y ^ 2 = 8 ∨ x ^ 2 + y ^ 2 = 9 ∨
    x ^ 2 + y ^ 2 = 10 ∨ x ^ 2 + y ^ 2 = 13 := by
  rcases square_residues16 x with hx | hx | hx | hx <;>
    rcases square_residues16 y with hy | hy | hy | hy <;> norm_num [hx, hy]
  decide +kernel

/-- Reuse JNT's square-residue divisibility implication and its bridge from
`ZMod 16` to integer congruences. -/
theorem four_dvd_of_square_zero16 {a : ℤ} (ha : (a : ZMod 16) ^ 2 = 0) :
    (4 : ℤ) ∣ a := by
  obtain ⟨_, _, _, _, hfour, _, _⟩ := Section5.lemma54_square_residues (a : ZMod 16)
  have hv := hfour (by rw [ha]; norm_num)
  exact Int.dvd_of_emod_eq_zero (Section5.int_mod_four_of_zmod_val hv)

/-- TeX 807--809: divisibility of the sum by 16 forces both coordinates to
be divisible by 4, by the displayed residue enumeration. -/
theorem four_dvd_coordinates_of_sum16 {a n : ℤ} (hs : (16 : ℤ) ∣ a ^ 2 + n ^ 2) :
    (4 : ℤ) ∣ a ∧ (4 : ℤ) ∣ n := by
  have hz := (ZMod.intCast_zmod_eq_zero_iff_dvd (a ^ 2 + n ^ 2) 16).mpr hs
  push_cast at hz
  have hzero : (a : ZMod 16) ^ 2 = 0 ∧ (n : ZMod 16) ^ 2 = 0 := by
    rcases sum_square_residues16 (a : ZMod 16) (n : ZMod 16) with
      hh | hh | hh | hh | hh | hh | hh | hh | hh
    · exact hh
    all_goals
      rw [hz] at hh
      exfalso
      revert hh
      decide +kernel
  exact ⟨four_dvd_of_square_zero16 hzero.1, four_dvd_of_square_zero16 hzero.2⟩

/-- TeX 805--806, the case `k < 4`: retain both printed conclusions,
`2^k | d` and `2` not dividing `b`. Here `k` is the exponent of 2 in the sum. -/
theorem two_small_case {a b d n : ℤ} (ha : 0 < a) (hb : 0 < b) (hd : 0 < d)
    (_hn : 0 < n) (he : d * b ^ 4 - a ^ 2 = n ^ 2)
    (hk : padicValInt 2 (a ^ 2 + n ^ 2) < 4) :
    (2 : ℤ) ^ padicValInt 2 (a ^ 2 + n ^ 2) ∣ d ∧ ¬ (2 : ℤ) ∣ b := by
  have hS : a ^ 2 + n ^ 2 ≠ 0 := ne_of_gt (by positivity)
  have hbodd : ¬ (2 : ℤ) ∣ b := by
    intro htwo
    have hfour := fourth_power_dvd_sum he htwo
    have hv := (padicValInt_dvd_iff (p := 2) 4 (a ^ 2 + n ^ 2)).mp hfour
    exact (not_le_of_gt hk) (hv.resolve_left hS)
  have hbval : padicValInt 2 b = 0 := by
    by_contra hh
    exact hbodd ((prime_dvd_iff_valuation_pos 2 (ne_of_gt hb)).mpr (Nat.pos_of_ne_zero hh))
  have hs : a ^ 2 + n ^ 2 = d * b ^ 4 := by linarith
  have hv : padicValInt 2 (a ^ 2 + n ^ 2) = padicValInt 2 d := by
    rw [hs, padicValInt.mul (ne_of_gt hd) (pow_ne_zero 4 (ne_of_gt hb)),
      valuation_int_pow, hbval, mul_zero, add_zero]
  refine ⟨?_, hbodd⟩
  rw [hv]
  exact (padicValInt_dvd_iff (p := 2) (padicValInt 2 d) d).mpr (Or.inr le_rfl)

/-- TeX 806--811, the case `k ≥ 4`: the modulo-16 conclusion makes
`4 | gcd(a,b²)` if `2 | b`, contradicting squarefreeness. -/
theorem two_large_case {a b n : ℤ} (hg : Squarefree (Int.gcd a (b ^ 2)))
    (hk : 4 ≤ padicValInt 2 (a ^ 2 + n ^ 2)) : ¬ (2 : ℤ) ∣ b := by
  have hs : (16 : ℤ) ∣ a ^ 2 + n ^ 2 :=
    (padicValInt_dvd_iff (p := 2) 4 (a ^ 2 + n ^ 2)).mpr (Or.inr hk)
  obtain ⟨ha, _hn⟩ := four_dvd_coordinates_of_sum16 hs
  intro hb
  exact no_prime_square_gcd hg Nat.prime_two (by simpa using ha)
    (pow_dvd_pow_of_dvd hb 2)

end Lemma36Proof

/-- Lemma 3.6 with the positive integer solution supplied explicitly.
All positivity hypotheses in the paper are retained; no nonsquareness or
coprimality hypothesis on these parameters is added. -/
theorem lemma36_of_solution (a b d n : ℤ) (ha : 0 < a) (hb : 0 < b) (hd : 0 < d)
    (hn : 0 < n) (hg : Squarefree (Int.gcd a (b ^ 2)))
    (he : d * b ^ 4 - a ^ 2 = n ^ 2) :
    ∀ p : ℕ, p.Prime → (p : ℤ) ∣ b → p % 4 = 1 := by
  have hthree : ∀ q : ℕ, q.Prime → q % 4 = 3 → ¬ (q : ℤ) ∣ b := by
    intro q hq hq4
    exact Lemma36Proof.exclude_three_mod_four ha hn hg he hq hq4
  have htwo : ¬ (2 : ℤ) ∣ b := by
    by_cases hk : padicValInt 2 (a ^ 2 + n ^ 2) < 4
    · exact (Lemma36Proof.two_small_case ha hb hd hn he hk).2
    · exact Lemma36Proof.two_large_case hg (n := n) (by omega)
  intro p hp hpb
  have hp2 : p ≠ 2 := by intro hh; subst p; exact htwo hpb
  have hp3 : p % 4 ≠ 3 := by intro hh; exact hthree p hp hh hpb
  have ho := hp.eq_two_or_odd.resolve_left hp2
  omega

/-- Lemma 3.6 (`lem:admissible-b`), with precisely the printed positive
integer parameters, squarefree gcd, and existence of a positive solution. -/
theorem lemma36 (a b d : ℤ) (ha : 0 < a) (hb : 0 < b) (hd : 0 < d)
    (hg : Squarefree (Int.gcd a (b ^ 2)))
    (hsolution : ∃ n : ℤ, 0 < n ∧ d * b ^ 4 - a ^ 2 = n ^ 2) :
    ∀ p : ℕ, p.Prime → (p : ℤ) ∣ b → p % 4 = 1 := by
  obtain ⟨n, hn, he⟩ := hsolution
  exact lemma36_of_solution a b d n ha hb hd hn hg he

end AnyBNormSquare
