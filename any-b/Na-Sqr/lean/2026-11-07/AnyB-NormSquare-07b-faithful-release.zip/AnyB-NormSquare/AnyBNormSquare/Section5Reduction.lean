module

public import AnyBNormSquare.SquareScaling
public import AnyBNormSquare.Section5Size

@[expose] public section
namespace AnyBNormSquare.Section5Reduction
open «JNT-2024» SquareScaling Section5Size

theorem positive_norm_root {P : Parameters} (hn : P.normAlpha < 0)
    (hs : IsSquare (-P.normAlpha)) :
    ∃ n : ℤ, 0 < n ∧ P.d*P.b^4-P.a^2=n^2 := by
  obtain ⟨z,hz⟩ := hs
  have hz0 : z ≠ 0 := by rintro rfl; simp at hz; omega
  refine ⟨|z|, abs_pos.mpr hz0, ?_⟩
  rw [sq_abs]
  unfold Parameters.normAlpha at hz
  linarith only [hz]

/-- After division by the square part, the remaining b divides b₁.
Each of its prime divisors is 1 modulo 4 by Lemma 3.6. -/
theorem small_normalized {P : Parameters} (h : P.Admissible)
    (hg : Squarefree (Int.gcd P.a (P.b^2))) (hn : P.normAlpha < 0)
    (hs : IsSquare (-P.normAlpha)) {c : ℤ} (had : AdmissibleB (c*P.b)) :
    P.b=1 ∨ P.b=5 ∨ P.b=13 ∨ P.b=17 := by
  obtain ⟨b₁,b₂,he,_,hb₁,hb₂⟩ := had
  have primes := lemma36 P.a P.b P.d h.a_pos h.b_pos h.d_pos hg (positive_norm_root hn hs)
  let B := P.b.toNat
  have hB : (B : ℤ)=P.b := Int.toNat_of_nonneg h.b_pos.le
  have hdiv : B ∣ b₁*b₂ := by
    have hh : (B:ℤ) ∣ ((b₁*b₂:ℕ):ℤ) := by rw [hB,← he]; exact dvd_mul_left _ _
    exact_mod_cast hh
  have cop : B.Coprime b₂ := by
    by_contra hh
    obtain ⟨p,hp,hpB,hp₂⟩ := Nat.Prime.not_coprime_iff_dvd.mp hh
    have hpB' : (p:ℤ) ∣ P.b := by rw [← hB]; exact_mod_cast hpB
    exact hb₂ p hp hp₂ (primes p hp hpB')
  have hd := cop.dvd_of_dvd_mul_right hdiv
  have four : B=1 ∨ B=5 ∨ B=13 ∨ B=17 := by
    rcases hb₁ with rfl | rfl | rfl | rfl
    · exact Or.inl (Nat.dvd_one.mp hd)
    · rcases (Nat.dvd_prime (by decide : Nat.Prime 5)).mp hd with h | h <;> simp [h]
    · rcases (Nat.dvd_prime (by decide : Nat.Prime 13)).mp hd with h | h <;> simp [h]
    · rcases (Nat.dvd_prime (by decide : Nat.Prime 17)).mp hd with h | h <;> simp [h]
  rw [← hB]
  exact_mod_cast four

/-- The normalized parameters can use the lower bound supplied before division. -/
theorem normalized_threshold (P : Parameters) (h : P.Admissible) {c : ℤ} (hc : 0 < c) :
    discriminantThreshold P ≤ discriminantThreshold (scaled P c) := by
  have hb : 0 ≤ (P.b:ℝ) := by exact_mod_cast h.b_pos.le
  have hu : 0 ≤ (P.u:ℝ) := by exact_mod_cast h.u_pos.le
  have hc' : (1:ℝ) ≤ c := by exact_mod_cast hc
  have hbc : (P.b:ℝ) ≤ (c:ℝ)*P.b := by nlinarith only [mul_nonneg (sub_nonneg.mpr hc') hb]
  have hcp : (1:ℝ) ≤ (c:ℝ)^4 := one_le_pow₀ hc'
  have hnc : |(P.normAlpha:ℝ)| ≤ (c:ℝ)^4*|(P.normAlpha:ℝ)| :=
    le_mul_of_one_le_left (abs_nonneg _) hcp
  unfold discriminantThreshold
  rw [scaled_norm]
  change _ ≤ 17*(((c*P.b:ℤ):ℝ)^(28/13:ℝ))*Real.sqrt |((c^4*P.normAlpha:ℤ):ℝ)|/(P.u:ℝ)^(24/13:ℝ)
  push_cast
  rw [abs_mul,abs_of_nonneg (by positivity : 0 ≤ (c:ℝ)^4)]
  gcongr

theorem rounded_bound (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (hd : discriminantThreshold P ≤ P.d) : normBound P.b P.u |(P.normAlpha:ℝ)| < P.d := by
  obtain ⟨hb,hN,_⟩ := Section4Proof.integer_bounds P h hn
  have hu : (1:ℝ) ≤ P.u := by exact_mod_cast h.u_pos
  have hb' : (0:ℝ)<P.b := by linarith
  have hu' : (0:ℝ)<P.u := by linarith
  have hN' : (0:ℝ) < |(P.normAlpha:ℝ)| := by linarith
  apply lt_of_le_of_lt (normBound_le hb hu hN)
  apply lt_of_lt_of_le _ hd
  unfold discriminantThreshold
  rw [Real.sqrt_eq_rpow]
  gcongr; norm_num

end AnyBNormSquare.Section5Reduction
