module

public import AnyBNormSquare.Case42
public import «JNT-2024».Section4ExactPublished

@[expose] public section
namespace AnyBNormSquare.Case43
open «JNT-2024» Approximation Prerequisites

/-- The doubled Gaussian imaginary coordinate is nonzero. -/
theorem imaginary_ne (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha)) {i j : ℤ}
    (a : Prepared P h i j) : 2*unitPowerNorm P i*squareFactor P.normAlpha ≠ 0 := by
  have hh := (sequence_coordinates P h hn hNs a.hx a.hy).2.1
  simpa only [mul_assoc] using mul_ne_zero (by decide : (2 : ℤ) ≠ 0) hh

/-- The actual comparison error, with the phase already in the numerator. -/
theorem comparison_upper (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha)) {i j : ℤ}
    (a : Prepared P h i j) :
    (3959/1000 : ℝ)*‖Section2.omega (-1) (2*a.X)
      (2*unitPowerNorm P i*squareFactor P.normAlpha)^(1/4 : ℂ)-
      Section2.gaussianEmbedding a.numerator/Section2.gaussianEmbedding a.denominator‖ <
      2*Real.sqrt |(P.normAlpha : ℝ)|/(Real.sqrt P.d*a.right.y) := by
  have he := (sequence_coordinates P h hn hNs a.hx a.hy).2.2.2
  have he' : Section2.omega (-1) (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha) =
      P.sequenceOmega h.pell i := by simpa only [mul_assoc] using he
  simpa only [he',a.numerator_embedding,a.denominator_embedding,mul_div_assoc] using a.comparison_bound

/-- The Gaussian chord in the sequence's actual coordinates. -/
theorem chord_half (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha)) {i j : ℤ}
    (a : Prepared P h i j) :
    ‖Section2.omega (-1) (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha)-1‖/2 =
      Real.sqrt |(P.normAlpha : ℝ)|/(Real.sqrt P.d*a.left.y) := by
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hc := sequence_coordinates P h hn hNs a.hx a.hy
  have hy : (a.Y : ℝ) = a.left.y := by rw [a.left_certificate.1,a.hy,Rat.cast_intCast]
  have he := hc.2.2.1
  rw [hy] at he
  rw [← hc.1] at he
  have hh := Section4.gaussian_chord (mul_pos (Real.sqrt_pos.mpr hd) a.left.y_pos) he
  have hab : |((unitPowerNorm P i*squareFactor P.normAlpha : ℤ) : ℝ)| =
      Real.sqrt |(P.normAlpha : ℝ)| := by rw [← hc.1,Real.sqrt_sq_eq_abs]
  rw [hab] at hh
  have hh' : ‖Section2.omega (-1) (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha)-1‖ =
      2*Real.sqrt |(P.normAlpha : ℝ)|/(Real.sqrt P.d*a.left.y) := by
    simpa only [mul_assoc] using hh
  rw [hh']; ring

/-- The general exact-case bound cited from JNT, for every r>=1. -/
theorem general_bound (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha)) {i j : ℤ}
    (a : Prepared P h i j)
    (data : Section2.PaperApproximants (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha))
    {r : ℕ} (hr : 1 ≤ r) (he : data.pr r*a.denominator-data.qr r*a.numerator=0) :
    a.right.y < (1734/1000 : ℝ)*Real.sqrt r*(4*P.d/|(P.normAlpha : ℝ)|)^r*a.left.y^(2*r+1) := by
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hN : 0 < |(P.normAlpha : ℝ)| := abs_pos.mpr (by exact_mod_cast ne_of_lt hn)
  have hl := Section4.exact_comparison_error_printed data (imaginary_ne P h hn hNs a)
    a.near_one a.denominator_ne hr he
  rw [chord_half P h hn hNs a] at hl
  have hcomp := comparison_upper P h hn hNs a
  rw [mul_comm (3959/1000 : ℝ)] at hcomp
  have hu := (lt_div_iff₀ (by norm_num : (0 : ℝ) < 3959/1000)).mpr hcomp
  apply Section4.exact_equation415 hN hd a.left.y_pos a.right.y_pos hr hl
  convert hu using 1; ring

/-- Specialize the cited bound and round 1.734*4 upward to 6.94. -/
theorem at_one (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha)) {i j : ℤ}
    (a : Prepared P h i j)
    (data : Section2.PaperApproximants (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha))
    (he : data.pr 1*a.denominator-data.qr 1*a.numerator=0) :
    a.right.y < (694/100 : ℝ)*P.d/|(P.normAlpha : ℝ)| *a.left.y^3 := by
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hN : 0 < |(P.normAlpha : ℝ)| := abs_pos.mpr (by exact_mod_cast ne_of_lt hn)
  exact Section4.exact_equation415_index_one hN hd a.left.y_pos
    (by simpa only [Nat.cast_one] using general_bound P h hn hNs a data (by omega : 1 ≤ (1 : ℕ)) he)

/-- Rearrange the two gaps and the exact-case upper bound, keeping 10^-6. -/
theorem sixth_power {b N d y z : ℝ} (hb : 0 < b) (hN : 0 < N) (hd : 0 < d) (hy : 0 < y)
    (hl : ((5732/100 : ℝ)*d^2/(b^4*N^2))^4*y^9 < z)
    (hu : z < (694/100 : ℝ)*d/N*y^3) : y^6 < (1/1000000 : ℝ)*b^16*N^7/d^7 := by
  have hh := hl.trans hu
  have hp : y^6 < (694/100 : ℝ)/(5732/100)^4*b^16*N^7/d^7 := by
    have hm := mul_lt_mul_of_pos_right hh (show 0 < b^16*N^8/d by positivity)
    apply (mul_lt_mul_iff_right₀ (show 0 < (5732/100 : ℝ)^4*d^7*y^3 by positivity)).mp
    convert hm using 1 <;> simp only [mul_pow,div_pow] <;> field_simp
  apply hp.trans
  have hc : (694/100 : ℝ)/(5732/100)^4 < 1/1000000 := by norm_num
  have hm := mul_lt_mul_of_pos_right hc (show 0 < b^16*N^7/d^7 by positivity)
  convert hm using 1 <;> ring

/-- Take sixth roots, exactly as printed in Section 4.3. -/
theorem root_bound {b N d y : ℝ} (hb : 0 < b) (hN : 0 < N) (hd : 0 < d) (hy : 0 < y)
    (hu : y^6 < (1/1000000 : ℝ)*b^16*N^7/d^7) :
    y < b^(8/3 : ℝ)*N^(7/6 : ℝ)/(10*d^(7/6 : ℝ)) := by
  apply (pow_lt_pow_iff_left₀ hy.le (by positivity) (by decide : (6 : ℕ) ≠ 0)).mp
  rw [div_pow,mul_pow,mul_pow,← Real.rpow_mul_natCast hb.le,
    ← Real.rpow_mul_natCast hN.le,← Real.rpow_mul_natCast hd.le]
  norm_num
  convert hu using 1; ring

/-- Section 4.3 for the same actual comparison data as the other cases. -/
theorem second_case (P : Parameters) (h : P.Admissible)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha))
    (hmin : SmallestInitialSquare P h.pell) (K : ℤ) (hK : P.IsNegativeCutoff h.pell K)
    {i j k : ℤ} (hi : 1 ≤ i ∨ i ≤ K)
    (hsi : IsIntegerSquare (P.y h.pell i)) (hsj : IsIntegerSquare (P.y h.pell j))
    (hsk : IsIntegerSquare (P.y h.pell k))
    (hij : (P.y h.pell i : ℝ) < (P.y h.pell j : ℝ))
    (hjk : (P.y h.pell j : ℝ) < (P.y h.pell k : ℝ))
    (hsize : max (4*|(P.normAlpha : ℝ)|/Real.sqrt P.d)
      ((P.b : ℝ)^2*|(P.normAlpha : ℝ)|/P.d) ≤ (P.y h.pell i : ℝ))
    (a : Prepared P h i k)
    (data : Section2.PaperApproximants (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha))
    (he : data.pr 1*a.denominator-data.qr 1*a.numerator=0) :
    (P.y h.pell i : ℝ) < (P.b : ℝ)^(8/3 : ℝ)*|(P.normAlpha : ℝ)|^(7/6 : ℝ)/
      (10*(P.d : ℝ)^(7/6 : ℝ)) := by
  have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
  have hb : (0 : ℝ) < P.b := by exact_mod_cast h.b_pos
  have hN : 0 < |(P.normAlpha : ℝ)| := abs_pos.mpr (by exact_mod_cast ne_of_lt hn)
  have hy : 0 < (P.y h.pell i : ℝ) := by rw [← a.left_certificate.1]; exact a.left.y_pos
  have hu := at_one P h hn hNs a data he
  rw [a.left_certificate.1,a.right_certificate.1] at hu
  have hl := (Case42.sequence_gaps P h hn hNs hmin K hK hi hsi hsj hsk hij hjk hsize).2.2
  exact root_bound hb hN hd hy (sixth_power hb hN hd hy hl hu)

end AnyBNormSquare.Case43
