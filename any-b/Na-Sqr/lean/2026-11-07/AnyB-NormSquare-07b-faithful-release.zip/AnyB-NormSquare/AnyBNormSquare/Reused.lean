module

public import «JNT-2024».ImaginaryQuadraticApproximation
public import «JNT-2024».Lemma38
public import «JNT-2024».ArgumentBounds
public import «JNT-2024».Targets
public import «JNT-2024».PaperBridge

@[expose] public section

/-!
# Results explicitly cited from JNT in the supplied paper

The proofs here are applications of the supplied faithful release, not new
proofs of its mathematics. The representation lemma only simplifies the
radical for unit norm, exactly as in the paragraph preceding `lem:quad-rep`.
-/

namespace AnyBNormSquare

open «JNT-2024»

/-- Lemma 2.1, reused with its full imaginary-quadratic-field hypotheses. -/
theorem lemma21 {K : Type*} [Field K] [NumberField K]
    [NumberField.IsTotallyComplex K] (hdegree : Module.finrank ℚ K = 2)
    (f : K →+* ℂ) (θ : ℂ) (p q : K) (pr qr : ℕ → K)
    (hp : IsIntegral ℤ p) (hq : IsIntegral ℤ q)
    (hpr : ∀ r, IsIntegral ℤ (pr r)) (hqr : ∀ r, IsIntegral ℤ (qr r))
    (hpq : ¬ (p = 0 ∧ q = 0))
    {k ℓ E Q c : ℝ} (hk : 0 < k) (hℓ : 0 < ℓ) (hE : 1 < E) (hQ : 1 < Q)
    (hc : 0 < c) (hc1 : c < 1)
    (hqb : ∀ r, ‖f (qr r)‖ < k * Q ^ r)
    (herr : ∀ r, ‖f (qr r) * θ - f (pr r)‖ ≤ ℓ / E ^ r)
    (hind : ∀ r, pr r * qr (r + 1) - pr (r + 1) * qr r ≠ 0) :
    let r := Approximation.firstIndex (Q := Q) (ℓ := ℓ) hE hc (f q)
    (1 - c / E) / (k * Q ^ (r + 1)) < ‖f q * θ - f p‖ ∧
      (pr r * q - qr r * p ≠ 0 → (1 - c) / (k * Q ^ r) < ‖f q * θ - f p‖) :=
  Approximation.lemma21_imaginaryQuadratic hdegree f θ p q pr qr hp hq hpr hqr
    hpq hk hℓ hE hQ hc hc1 hqb herr hind

/-- Lemma 3.1 (`lem:quad-rep`), including `f ∣ b²` and the companion identity.
`SignedFourthPowerRepresentation` is the actual quadratic-algebra equality.
`P.Pell` is equivalent to the stated ring-of-integers unit hypothesis. -/
theorem lemma31 (P : Parameters) (hd : ¬ IsSquare P.d)
    (ha : P.a ≠ 0) (hb : 0 < P.b) (hn : P.normAlpha < 0)
    (hNs : IsSquare (-P.normAlpha)) (hp : P.Pell)
    (_ht : P.t ≠ 0) (hu : P.u ≠ 0) {x y : ℤ}
    (_hx : x ≠ 0) (hy : 0 < y) (hr : P.RepresentsSquare x y) :
    ∃ f r s τ : ℤ, f ≠ 0 ∧ f ∣ P.b ^ 2 ∧ (τ = 1 ∨ τ = -1) ∧
      P.SignedFourthPowerRepresentation x y f r s τ := by
  let : Fact (¬ IsSquare P.d) := ⟨hd⟩
  let : Fact (¬ IsSquare P.normAlpha) := ⟨by
    rintro ⟨m, hm⟩
    nlinarith [sq_nonneg m]⟩
  obtain ⟨ν, f, r, s, τ, hν, hf, hτ, hrep, hdiv⟩ :=
    P.proposition31b_published hr ha (ne_of_gt hb) (ne_of_gt hy) hu
      (ne_of_lt hn) (P.epsilon_isIntegral hp) hNs
  rw [P.normRadical_of_unit (P.integer_unit_norm hp hν), mul_one] at hdiv
  exact ⟨f, r, s, τ, hf, hdiv, hτ, hrep⟩

/-- An integer square is a rational square; this is only a type bridge. -/
theorem integerSquare_isSquare {q : ℚ} (h : IsIntegerSquare q) : IsSquare q := by
  obtain ⟨n, rfl⟩ := h
  exact ⟨(n : ℚ), by ring⟩

/-- Lemma 3.3 (`lem:gap`), with integer square hypotheses and the printed coefficient. -/
theorem lemma33 (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (hNs : IsSquare (-P.normAlpha)) {i j : ℤ} (hi : i ≠ 0) (hj : j ≠ 0)
    (hsi : IsIntegerSquare (P.y h.pell i)) (hsj : IsIntegerSquare (P.y h.pell j))
    (hij : (P.y h.pell i : ℝ) < (P.y h.pell j : ℝ))
    (hlarge : max (4 * Real.sqrt (|(P.normAlpha : ℝ)| / P.d))
      ((P.b : ℝ) ^ 2 * |(P.normAlpha : ℝ)| / P.d) ≤ (P.y h.pell i : ℝ)) :
    (5732 / 100 : ℝ) * (P.d : ℝ) ^ 2 /
      ((P.b : ℝ) ^ 4 * |(P.normAlpha : ℝ)| ^ 2) *
      (P.y h.pell i : ℝ) ^ 3 < (P.y h.pell j : ℝ) := by
  have hh := P.lemma38a h hn hNs hi hj (integerSquare_isSquare hsi)
    (integerSquare_isSquare hsj) hij hlarge
  convert hh using 1
  simp only [div_pow, mul_pow]
  ring

/-- Lemma 3.4 (`lem:zeta`), using the same principal argument and signed unit norm. -/
theorem lemma34 (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) {k : ℤ}
    (_hs : IsIntegerSquare (P.y h.pell k))
    (hlarge : 4 * Real.sqrt (|(P.normAlpha : ℝ)| / P.d) ≤ (P.y h.pell k : ℝ)) :
    |(P.sequenceOmega h.pell k).arg| <
      (229 / 100 : ℝ) * Real.sqrt |(P.normAlpha : ℝ)| / |(P.x h.pell k : ℝ)| ∧
    (229 / 100 : ℝ) * Real.sqrt |(P.normAlpha : ℝ)| / |(P.x h.pell k : ℝ)| < 3 / 5 :=
  P.lemma39a h hn hlarge

end AnyBNormSquare
