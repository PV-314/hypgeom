module

public import AnyBNormSquare.Section5Size

@[expose] public section
namespace AnyBNormSquare.Section56Table
open Section5Size

def TableRow (b U D c₁ : ℕ) : Prop :=
  (b=5 ∧ U=74 ∧ D=58984375 ∧ c₁=242598) ∨
  (b=13 ∧ U=499 ∧ D=123175338871 ∧ c₁=18110693) ∨
  (b=17 ∧ U=852 ∧ D=1053339373591 ∧ c₁=58466661)

theorem antitone {b u v : ℝ} (hb : 0 ≤ b) (hu : 0 < u) (huv : u ≤ v) :
    finiteBound b v ≤ finiteBound b u := by
  unfold finiteBound
  gcongr

private theorem fifth_power_bound {b : ℝ} (hb : 1 ≤ b) (hh : b ≤ 128) :
    b^(36/7:ℝ) ≤ 2*b^5 := by
  have hb0 : 0 ≤ b := by linarith
  have hp := Real.rpow_le_rpow hb0 (show b ≤ (2:ℝ)^7 by norm_num; exact hh)
    (show (0:ℝ) ≤ 1/7 by norm_num)
  rw [← Real.rpow_natCast (2:ℝ) 7,← Real.rpow_mul (by norm_num)] at hp
  norm_num at hp
  rw [show (36/7:ℝ) = (5:ℕ)+(1/7:ℝ) by norm_num,Real.rpow_add (by linarith),Real.rpow_natCast]
  nlinarith only [mul_nonneg (pow_nonneg hb0 5) (sub_nonneg.mpr hp)]

private theorem comp {b u : ℝ} (hb : 1 ≤ b) (hh : b ≤ 128) (hu : 1 ≤ u) :
    finiteBound b u ≤ max (12*b^2/u^2) (max (b^3/u^2) (max (120*b^5/u^3) (151*b^8/u^4))) := by
  have hb0 : 0 < b := by linarith
  have hu0 : 0 < u := by linarith
  have hb3 : b^(8/3:ℝ) ≤ b^3 := by rw [← Real.rpow_natCast b 3]; gcongr; norm_num
  have hu2 : u^2 ≤ u^(44/21:ℝ) := by rw [← Real.rpow_natCast u 2]; gcongr; norm_num
  have hu3 : u^3 ≤ u^(24/7:ℝ) := by rw [← Real.rpow_natCast u 3]; gcongr; norm_num
  have h1 : (92/100:ℝ)*b^(8/3:ℝ)/u^(44/21:ℝ) ≤ b^3/u^2 := by
    calc
      _ ≤ 1*b^3/u^2 := by gcongr; norm_num
      _ = _ := by ring
  have h2 : (64/100:ℝ)*b^(8/3:ℝ)/u^2 ≤ b^3/u^2 := by
    calc
      _ ≤ 1*b^3/u^2 := by gcongr; norm_num
      _ = _ := by ring
  have h3 : 60*b^(36/7:ℝ)/u^(24/7:ℝ) ≤ 120*b^5/u^3 := by
    calc
      _ ≤ 60*(2*b^5)/u^3 := by gcongr; exact fifth_power_bound hb hh
      _ = _ := by ring
  unfold finiteBound
  grind

/-- Table 1. D is the bound at u=1 and U is the first positive integer
at which the maximum is less than 2. -/
theorem thresholds {b U D c₁ : ℕ} (h : TableRow b U D c₁) :
    finiteBound b 1 = D ∧ finiteBound b U < 2 ∧
    ∀ u : ℕ, 0 < u → u < U → 2 ≤ finiteBound b u := by
  have hb : (1:ℝ) ≤ b ∧ (b:ℝ) ≤ 128 := by
    rcases h with ⟨rfl,-,-,-⟩ | ⟨rfl,-,-,-⟩ | ⟨rfl,-,-,-⟩ <;> norm_num
  have step (u : ℝ) : 151*(b:ℝ)^8/u^4 ≤ finiteBound b u := by
    unfold finiteBound; grind
  constructor
  · apply le_antisymm
    · apply le_trans (comp hb.1 hb.2 (le_refl (1:ℝ)))
      rcases h with ⟨rfl,-,rfl,-⟩ | ⟨rfl,-,rfl,-⟩ | ⟨rfl,-,rfl,-⟩ <;> norm_num
    · apply le_trans _ (step 1)
      rcases h with ⟨rfl,-,rfl,-⟩ | ⟨rfl,-,rfl,-⟩ | ⟨rfl,-,rfl,-⟩ <;> norm_num
  constructor
  · have hu : (1:ℝ) ≤ U := by rcases h with ⟨-,rfl,-,-⟩ | ⟨-,rfl,-,-⟩ | ⟨-,rfl,-,-⟩ <;> norm_num
    apply lt_of_le_of_lt (comp hb.1 hb.2 hu)
    rcases h with ⟨rfl,rfl,-,-⟩ | ⟨rfl,rfl,-,-⟩ | ⟨rfl,rfl,-,-⟩ <;> norm_num
  · intro u hu hlt
    have hu' : (0:ℝ) < u := by exact_mod_cast hu
    apply le_trans _ (antitone (b:=(b:ℝ)) (by positivity) hu' (show (u:ℝ) ≤ ((U-1:ℕ):ℝ) by exact_mod_cast (show u ≤ U-1 by omega)))
    apply le_trans _ (step _)
    rcases h with ⟨rfl,rfl,-,-⟩ | ⟨rfl,rfl,-,-⟩ | ⟨rfl,rfl,-,-⟩ <;> norm_num

end AnyBNormSquare.Section56Table
