module

public import AnyBNormSquare.Section5Reduction
public import AnyBNormSquare.Section5Discriminant
public import AnyBNormSquare.Section56Calculations

@[expose] public section
namespace AnyBNormSquare.Section5Proof
open «JNT-2024» SquareScaling Section5Opening Section5Size Section5Reduction
open Section56Table Section56Calculations Section56Records

/-- The finite range left after the norm-free discriminant bound fails. -/
theorem finite_count (hPrior : Hypergeometric.DenominatorEstimate4)
    (hE : JavaEnumeration) (hJ : JavaSquareSearch) (hQ : ExceptionalQuartics)
    (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha))
    (hmin : SmallestInitialSquare P h.pell) (K : ℤ) (hK : P.IsNegativeCutoff h.pell K)
    {b U D c₁ : ℕ} (row : TableRow b U D c₁) (hb : P.b=b) (hd : (P.d:ℝ) ≤ finiteBound P.b P.u) :
    AtMostSquareValuesOn (P.y h.pell) (fun k => 2 ≤ k ∨ k ≤ K-1) 2 := by
  have hu : P.u < U := by
    by_contra! hh
    have hu0 : (0:ℝ) < U := by
      rcases row with ⟨-,rfl,-,-⟩ | ⟨-,rfl,-,-⟩ | ⟨-,rfl,-,-⟩ <;> norm_num
    have hbr : (P.b:ℝ)=(b:ℝ) := by exact_mod_cast hb
    have hd2 := (Section4Proof.integer_bounds P h hn).2.2
    rw [hbr] at hd
    have hle := Section56Table.antitone (b:=(b:ℝ)) (by positivity) hu0 (show (U:ℝ) ≤ P.u by exact_mod_cast hh)
    exact (not_lt_of_ge (hd2.trans (hd.trans hle))) (thresholds row).2.1
  obtain ⟨S,_,hS⟩ := hE b U D c₁ row
  have hmem := (hS P).mpr ⟨hb,h,hu,hd,hn,hNs⟩
  apply Section4Proof.count_from_no_three
  intro i j k hi hj hk hsi hsj hsk hij hjk
  have hcut := least_lt_searchBound hPrior P h hn hNs hmin K hK
    (by rcases hi with hx | hx <;> omega) hsi hsj hsk (by exact_mod_cast hij) (by exact_mod_cast hjk)
  obtain ⟨hit,hr,rfl⟩ := (hJ b U D c₁ row S hS P hmem h K hK).mp ⟨i,hi,hsi,hcut⟩
  exact hij.ne ((exceptional_values hQ hr h hn K hK hi hsi).trans
    (exceptional_values hQ hr h hn K hK hj hsj).symm)

/-- Theorem 1.4(a). All four analytic cases, the JNT b=1 reduction and the
two distinct computations appear as explicit hypotheses or proved dependencies. -/
theorem theorem14a_conditional (hPrior : Hypergeometric.DenominatorEstimate4)
    (hAkhtari : ExternalResults.AkhtariTheorem11) (hMagma : Calculations.Section46Magma)
    (hEnumeration : JavaEnumeration) (hSearch : JavaSquareSearch) (hQuartics : ExceptionalQuartics) :
    Theorem14a := by
  intro P h hn hNs hmin had K hK
  obtain ⟨c,Q,hc,rfl,hQ,hg⟩ := normalized_parameters P h
  obtain ⟨hnQ,hsQ⟩ := norm_hypotheses Q c hc.ne' hn hNs
  have hKQ := (scaled_cutoff_iff Q c hc.ne' hQ.pell K).mp hK
  have hminQ := (scaled_smallest_iff Q c hc.ne' hQ.pell).mp hmin
  apply count_transport Q c hc.ne'
  rcases small_normalized hQ hg hnQ hsQ had with hb | hb
  · exact small_b_one hPrior hAkhtari hMagma Q hQ hb hnQ hsQ K hKQ
  have hb5 : 5 ≤ Q.b := by omega
  by_cases hd : finiteBound Q.b Q.u < (Q.d:ℝ)
  · exact Section5Discriminant.count hPrior Q hQ hnQ hsQ hminQ K hKQ hb5 (Or.inr hd)
  have rowCase {b U D c₁ : ℕ} (row : TableRow b U D c₁) (he : Q.b=b) :=
    finite_count hPrior hEnumeration hSearch hQuartics Q hQ hnQ hsQ hminQ K hKQ row he (le_of_not_gt hd)
  rcases hb with hb | hb | hb
  · exact rowCase (b:=5) (U:=74) (D:=58984375) (c₁:=242598) (by simp [TableRow]) hb
  · exact rowCase (b:=13) (U:=499) (D:=123175338871) (c₁:=18110693) (by simp [TableRow]) hb
  · exact rowCase (b:=17) (U:=852) (D:=1053339373591) (c₁:=58466661) (by simp [TableRow]) hb

/-- Theorem 1.4(b), with the original exclusion and weak rounded inequality. -/
theorem theorem14b_conditional (hPrior : Hypergeometric.DenominatorEstimate4)
    (hAkhtari : ExternalResults.AkhtariTheorem11) (hMagma : Calculations.Section46Magma) :
    Theorem14b := by
  intro P h hn hNs hmin _ hd K hK
  obtain ⟨c,Q,hc,rfl,hQ,hg⟩ := normalized_parameters P h
  obtain ⟨hnQ,hsQ⟩ := norm_hypotheses Q c hc.ne' hn hNs
  have hKQ := (scaled_cutoff_iff Q c hc.ne' hQ.pell K).mp hK
  have hminQ := (scaled_smallest_iff Q c hc.ne' hQ.pell).mp hmin
  apply count_transport Q c hc.ne'
  rcases normalized_b_one_or_five Q.a Q.b Q.d hQ.a_pos hQ.b_pos hQ.d_pos hg
      (positive_norm_root hnQ hsQ) with hb | hb
  · exact small_b_one hPrior hAkhtari hMagma Q hQ hb hnQ hsQ K hKQ
  · have hrounded := (normalized_threshold Q hQ hc).trans hd
    exact Section5Discriminant.count hPrior Q hQ hnQ hsQ hminQ K hKQ hb
      (Or.inl (rounded_bound Q hQ hnQ hrounded))

end AnyBNormSquare.Section5Proof
