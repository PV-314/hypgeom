module

public import AnyBNormSquare.Section4
public import AnyBNormSquare.AdmissiblePrimes
public import AnyBNormSquare.Growth
public import «JNT-2024».Section5AssemblyRevised

@[expose] public section
namespace AnyBNormSquare.Section5Opening
open «JNT-2024»

/-- The two-step tails in the printed theorem lie strictly above the initial value. -/
theorem tail_gt_initial (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (K : ℤ) (hK : P.IsNegativeCutoff h.pell K) {k : ℤ}
    (hk : 2 ≤ k ∨ k ≤ K-1) : (P.b : ℚ)^2 < P.y h.pell k := by
  rcases hk with hk | hk
  · have hh := P.y_strictMono_nonnegative h hn (show 0 < k.toNat by omega)
    simpa only [Nat.cast_zero,Int.toNat_of_nonneg (by omega : 0 ≤ k),P.y_zero] using hh
  · have hh := P.y_strictMono_negative_tail h hn K hK
      (show 1 < (K+1-k).toNat by omega)
    have he : (K+1-k).toNat = (K+1-k : ℤ) := by
      exact Int.toNat_of_nonneg (by omega)
    have hh' : P.y h.pell K < P.y h.pell k := by
      simpa only [Nat.cast_one,he,show K+1-1=K by omega,
        show K+1-(K+1-k)=k by omega] using hh
    exact hK.2.1.trans hh'

/-- JNT's three-value bound suffices: remove the initial square 1. -/
theorem small_b_one
    (hPrior : Hypergeometric.DenominatorEstimate4)
    (hAkhtari : ExternalResults.AkhtariTheorem11)
    (hCalculation : Calculations.Section46Magma)
    (P : Parameters) (h : P.Admissible) (hb : P.b=1)
    (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha))
    (K : ℤ) (hK : P.IsNegativeCutoff h.pell K) :
    AtMostSquareValuesOn (P.y h.pell) (fun k => 2 ≤ k ∨ k ≤ K-1) 2 := by
  classical
  obtain ⟨S,hcard,hcover⟩ := (theorem14_revised hPrior hAkhtari hCalculation P h hb hn hNs).1
  have hmem : (1 : ℚ) ∈ S := by
    have hh := hcover 0 ⟨1,by simp [hb]⟩
    simpa [hb] using hh
  refine ⟨S.erase 1,?_,?_⟩
  · have hh := Finset.card_erase_add_one hmem
    omega
  · intro k hk hs
    apply Finset.mem_erase.mpr
    refine ⟨?_,hcover k hs⟩
    have hh := tail_gt_initial P h hn K hK hk
    simpa only [hb,Int.cast_one,one_pow] using ne_of_gt hh

/-- Lemma 3.6 excludes the normalized values 2, 3 and 4. -/
theorem normalized_b_one_or_five (a b d : ℤ) (ha : 0 < a) (hb : 0 < b) (hd : 0 < d)
    (hg : Squarefree (Int.gcd a (b^2)))
    (hs : ∃ n : ℤ, 0 < n ∧ d*b^4-a^2=n^2) : b=1 ∨ 5 ≤ b := by
  have hh := lemma36 a b d ha hb hd hg hs
  by_cases hb5 : 5 ≤ b
  · exact Or.inr hb5
  left
  have hc : b=1 ∨ b=2 ∨ b=3 ∨ b=4 := by omega
  rcases hc with rfl | rfl | rfl | rfl
  · rfl
  · have := hh 2 Nat.prime_two (by norm_num); norm_num at this
  · have := hh 3 Nat.prime_three (by norm_num); norm_num at this
  · have := hh 2 Nat.prime_two (by norm_num); norm_num at this

/-- The two-step specialization of Lemma 3.2(c), exactly (5.3). -/
theorem two_step_lower (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0)
    (K : ℤ) (hK : P.IsNegativeCutoff h.pell K) (hd : 300 ≤ P.d*P.u^2)
    {k : ℤ} (hk : 2 ≤ k ∨ k ≤ K-1) :
    (99/100 : ℚ) * |(P.normAlpha : ℚ)| * P.d*(P.u : ℚ)^4/(4*(P.b : ℚ)^2) ≤ P.y h.pell k := by
  let R : ℚ := (99/100)*P.d*(P.u : ℚ)^2
  have hR : 1 ≤ R := by
    have hh : (300 : ℚ) ≤ P.d*(P.u : ℚ)^2 := by exact_mod_cast hd
    dsimp [R]; linarith
  have hseed : 0 ≤ P.lowerSeed := by unfold Parameters.lowerSeed; positivity
  have hbound := lemma32c P h hn K hK (Or.inr hd)
  have finish (n : ℕ) (he : 1 ≤ n) (hy : P.lowerSeed*R^n ≤ P.y h.pell k) :
      P.lowerSeed*R ≤ P.y h.pell k := by
    have hp : R ≤ R^n := by simpa using pow_le_pow_right₀ hR he
    exact (mul_le_mul_of_nonneg_left hp hseed).trans hy
  have hh : P.lowerSeed*R ≤ P.y h.pell k := by
    rcases hk with hk | hk
    · exact finish (k-1).toNat (by omega) (hbound.1 k (by omega))
    · exact finish (K-k).toNat (by omega) (hbound.2 k (by have := hK.1; omega))
  convert hh using 1
  dsimp [Parameters.lowerSeed,R]
  ring

end AnyBNormSquare.Section5Opening
