module

public import AnyBNormSquare.Section5Opening
public import AnyBNormSquare.Section5Low

@[expose] public section
namespace AnyBNormSquare.Section5Size

noncomputable def normBound (b u N : ℝ) :=
  max ((925/1000:ℝ)*b^(48/23:ℝ)*N^(2/23:ℝ)/u^(44/23:ℝ))
    (max ((66/100:ℝ)*b^(28/13:ℝ)*N^(1/13:ℝ)/u^(24/13:ℝ))
      (max ((153/10:ℝ)*b^(20/11:ℝ)*N^(4/11:ℝ)/u^(24/11:ℝ))
        ((1634/100:ℝ)*b^2*N^(1/2:ℝ)/u^2)))

noncomputable def finiteBound (b u : ℝ) :=
  max (12*b^2/u^2)
    (max ((92/100:ℝ)*b^(8/3:ℝ)/u^(44/21:ℝ))
      (max ((64/100:ℝ)*b^(8/3:ℝ)/u^2)
        (max (60*b^(36/7:ℝ)/u^(24/7:ℝ)) (151*b^8/u^4))))

/-- In (5.18) replace each exponent and coefficient by its indicated extreme. -/
theorem normBound_le {b u N : ℝ} (hb : 1 ≤ b) (hu : 1 ≤ u) (hN : 1 ≤ N) :
    normBound b u N ≤ (1634/100:ℝ)*b^(28/13:ℝ)*N^(1/2:ℝ)/u^(24/13:ℝ) := by
  have hb' : 0 < b := by linarith
  have hu' : 0 < u := by linarith
  have hN' : 0 < N := by linarith
  have bound (c x z w : ℝ) (hc : 0 ≤ c) (hc' : c ≤ 1634/100)
      (hx : x ≤ 28/13) (hz : z ≤ 1/2) (hw : 24/13 ≤ w) :
      c*b^x*N^z/u^w ≤ (1634/100:ℝ)*b^(28/13:ℝ)*N^(1/2:ℝ)/u^(24/13:ℝ) := by
    gcongr
  unfold normBound
  simp only [max_le_iff]
  rw [← Real.rpow_natCast b 2, ← Real.rpow_natCast u 2]
  exact ⟨bound _ _ _ _ (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
    bound _ _ _ _ (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
    bound _ _ _ _ (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num),
    bound _ _ _ _ (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)⟩

/-- The last term of (5.18) dominates the common sufficient size bound used
also at the beginning of Section 5.6. -/
theorem common_of_norm {b u N d : ℝ} (hN : 1 ≤ N)
    (h : normBound b u N < d) : 12*b^2/u^2 < d := by
  simp only [normBound,max_lt_iff] at h
  apply lt_of_le_of_lt _ h.2.2.2
  have hpow : 1 ≤ N^(1/2:ℝ) := Real.one_le_rpow hN (by norm_num)
  apply div_le_div_of_nonneg_right _ (sq_nonneg _)
  nlinarith only [mul_nonneg (sq_nonneg b) (sub_nonneg.mpr hpow), sq_nonneg b]

/-- The three preliminary conditions of Section 5.5. -/
theorem preliminary {b u d : ℝ} (hb : 5 ≤ b) (hu : 1 ≤ u)
    (h : 12*b^2/u^2 < d) :
    300 ≤ d*u^2 ∧ 7*b^(4/3:ℝ)/u^(8/3:ℝ) ≤ d ∧ (21/10:ℝ)*b^2/u^2 ≤ d := by
  have hb' : 1 ≤ b := by linarith
  have hu' : 0 < u := by linarith
  have hb0 : 0 < b := by linarith
  have hmul := (div_lt_iff₀ (sq_pos_of_pos hu')).mp h
  have hbpow : b^(4/3:ℝ) ≤ b^2 := by
    rw [← Real.rpow_natCast b 2]
    apply Real.rpow_le_rpow_of_exponent_le hb'
    norm_num
  have hupow : u^2 ≤ u^(8/3:ℝ) := by
    rw [← Real.rpow_natCast u 2]
    apply Real.rpow_le_rpow_of_exponent_le hu
    norm_num
  refine ⟨by nlinarith [sq_nonneg (b-5)], ?_, ?_⟩
  · apply le_trans _ h.le
    gcongr; norm_num
  · apply le_trans _ h.le
    gcongr; norm_num

/-- Compare (5.3) with the two size hypotheses in (4.4). -/
theorem large_y {b u d N y : ℝ} (hb : 0 < b) (hu : 0 < u) (hd : 0 < d) (hN : 0 < N)
    (h₁ : 7*b^(4/3:ℝ)/u^(8/3:ℝ) ≤ d) (h₂ : (21/10:ℝ)*b^2/u^2 ≤ d)
    (hl : (99/400:ℝ)*N*d*u^4/b^2 ≤ y) :
    max (4*N/Real.sqrt d) (b^2*N/d) ≤ y := by
  apply le_trans _ hl
  apply max_le
  · apply (Real.log_le_log_iff (by positivity) (by positivity)).mp
    have hx := Real.log_le_log (by positivity) h₁
    have hc := Real.log_le_log (by norm_num : 0 < (4:ℝ)^2)
      (by norm_num : (4:ℝ)^2 ≤ (99/400)^2*7^3)
    rw [Real.sqrt_eq_rpow]
    simp (disch := positivity) only [Real.log_mul,Real.log_div,Real.log_pow,Real.log_rpow] at hx hc ⊢
    norm_num1 at hx hc ⊢
    linarith only [hx,hc]
  · apply (Real.log_le_log_iff (by positivity) (by positivity)).mp
    have hx := Real.log_le_log (by positivity) h₂
    have hc := Real.log_nonneg (by norm_num : (1:ℝ) ≤ (99/400)*(21/10)^2)
    simp (disch := positivity) only [Real.log_mul,Real.log_div,Real.log_pow] at hx hc ⊢
    norm_num1 at hx hc ⊢
    linarith only [hx,hc]

end AnyBNormSquare.Section5Size
