module

public import AnyBNormSquare.Section5Opening
public import AnyBNormSquare.Section5Low
public import AnyBNormSquare.Section5High
public import AnyBNormSquare.Section5Fourth

@[expose] public section
namespace AnyBNormSquare.Section5Cases
open «JNT-2024» Approximation Prerequisites

/-- The four strict bounds for the least square before the final simplifications
in Section 4. The last two witnesses come from the actual least index and G. -/
def FourBounds (b d N y : ℝ) : Prop :=
  y < (21/100:ℝ)*b^(26/11:ℝ)*N^(13/11:ℝ)/d^(12/11:ℝ) ∨
  y < b^(8/3:ℝ)*N^(7/6:ℝ)/(10*d^(7/6:ℝ)) ∨
  (∃ n G : ℝ, 3 ≤ n ∧ 2 ≤ G ∧
    y < (592/10:ℝ)*(653/1000:ℝ)^(1/n)*b^(4/n)*
      N^((3/2:ℝ)+1/(2*n))/(d^((1/2:ℝ)+1/n)*G^(2-1/n))) ∨
  (∃ n G : ℝ, 1 ≤ n ∧ 2 ≤ G ∧
    y < (6532/100:ℝ)*(5233/1000:ℝ)^(1/(2*n))*b^(2/n)*
      N^((3/2:ℝ)+1/(2*n))/(G^2*d^((1/2:ℝ)+1/(2*n))))

theorem four_bounds (hPrior : Hypergeometric.DenominatorEstimate4)
    (P : Parameters) (h : P.Admissible) (hn : P.normAlpha < 0) (hNs : IsSquare (-P.normAlpha))
    (hmin : SmallestInitialSquare P h.pell) (K : ℤ) (hK : P.IsNegativeCutoff h.pell K)
    {i j k : ℤ} (hi : 1 ≤ i ∨ i ≤ K)
    (hsi : IsIntegerSquare (P.y h.pell i)) (hsj : IsIntegerSquare (P.y h.pell j))
    (hsk : IsIntegerSquare (P.y h.pell k))
    (hij : (P.y h.pell i : ℝ) < (P.y h.pell j : ℝ))
    (hjk : (P.y h.pell j : ℝ) < (P.y h.pell k : ℝ))
    (hsize : max (4*|(P.normAlpha : ℝ)|/Real.sqrt P.d)
      ((P.b : ℝ)^2*|(P.normAlpha : ℝ)|/P.d) ≤ (P.y h.pell i : ℝ)) :
    FourBounds P.b P.d |(P.normAlpha : ℝ)| (P.y h.pell i) := by
  obtain ⟨a⟩ := prepare P h hn hNs hmin K hK hi hsi hsk (hij.trans hjk) hsize
  obtain ⟨data,_⟩ := apply_prepared hPrior P h hn hNs a
  let r := Case42.index a (by norm_num : (0 : ℝ) < 3/4)
  have hrpos : 1 ≤ r := (firstIndex_spec a.E_gt_one (by norm_num : (0 : ℝ) < 3/4) _).1
  by_cases hr : r=1
  · by_cases he : data.pr r*a.denominator-data.qr r*a.numerator=0
    · have he1 : data.pr 1*a.denominator-data.qr 1*a.numerator=0 := by rwa [hr] at he
      have hh := Case43.second_case P h hn hNs hmin K hK hi hsi hsj hsk hij hjk hsize a data he1
      exact Or.inr (Or.inl hh)
    · exact Or.inl (Case42.first_case P h hn hNs hmin K hK hi hsi hsj hsk hij hjk hsize a data hr he)
  · have hr' : 1 < r := by omega
    have hlarge := (le_max_left _ _).trans hsize
    have hd : (0 : ℝ) < P.d := by exact_mod_cast h.d_pos
    have hb : (0 : ℝ) < P.b := by exact_mod_cast h.b_pos
    have hN : 0 < |(P.normAlpha : ℝ)| := abs_pos.mpr (by exact_mod_cast ne_of_lt hn)
    have hY : 4*|(P.normAlpha : ℝ)|/Real.sqrt P.d ≤ (a.Y : ℝ) := by
      simpa only [a.hy,Rat.cast_intCast] using hlarge
    have hM2 := (application_parameters P h hn hNs a.hx a.hy hY).2.1
    have hM : 0 < normalizerProduct (-1) (2*a.X) (2*unitPowerNorm P i*squareFactor P.normAlpha) := by linarith
    have hF := mul_pos a.left.f_pos a.right.f_pos
    have hl := HigherIndex.sequence_lower P h hn hNs a hlarge (by norm_num : (0 : ℝ) < 3/4) hr'
    by_cases he : data.pr r*a.denominator-data.qr r*a.numerator=0
    · have hu := Case43.general_bound P h hn hNs a data (by omega) he
      have hc := Case45.remove_sqrt hN hd a.left.y_pos hF hM hb (by omega) hl hu
      have hnrm := Case45.normalized hN hd a.left.y_pos hF hM hb (by omega) hc
      have hwith := Case45.eliminate_f hN hd hF hb a.f_product hnrm
      have hroot := Case45.root_bound hN hd a.left.y_pos hM hb (by omega) hwith
      refine Or.inr (Or.inr (Or.inr ⟨((r-1 : ℕ) : ℝ), _, ?_, hM2, ?_⟩))
      · exact_mod_cast (show 1 ≤ r-1 by omega)
      · simpa only [a.left_certificate.1] using hroot
    · have hu := Case42.general_bound P h hn hNs a hlarge data (by norm_num : (0 : ℝ) < 3/4) (by norm_num) he
      have hc := Case44.combine hN hd a.left.y_pos hF hM hb (by norm_num) (by omega) hl hu
      have hnrm := Case44.normalized hN hd a.left.y_pos hF hM hb (by omega) hc
      have hwith := Case44.normalized_with_b hN hd hF hM hb a.f_product hnrm
      have hroot := Case44.root_bound hN hd a.left.y_pos hM hb (by omega) hwith
      refine Or.inr (Or.inr (Or.inl ⟨((2*r-1 : ℕ) : ℝ), _, ?_, hM2, ?_⟩))
      · exact_mod_cast (show 3 ≤ 2*r-1 by omega)
      · simpa only [a.left_certificate.1] using hroot

end AnyBNormSquare.Section5Cases
