module

public import «JNT-2024».Targets
public import «JNT-2024».Monotonicity
public import Mathlib.Analysis.SpecialFunctions.Pow.Real

@[expose] public section

/-!
# Main statements: definitions of pending propositions, NOT proved theorems

The only manuscript source is the supplied 2026-11-06c TeX. The section-wide
smallest-square convention (lines 183--192) is explicit below. All fractional
powers are real powers and all printed decimal constants are exact rationals.
-/

namespace AnyBNormSquare

open «JNT-2024»

/-- Restrict the upstream value-counting definition to the indicated indices. -/
def AtMostSquareValuesOn (y : ℤ → ℚ) (indices : ℤ → Prop) (bound : ℕ) : Prop :=
  ∃ S : Finset ℚ, S.card ≤ bound ∧
    ∀ k : ℤ, indices k → IsIntegerSquare (y k) → y k ∈ S

/-- The standing normalisation in Section 1.1: `b²` is the smallest square value. -/
def SmallestInitialSquare (P : Parameters) (hp : P.Pell) : Prop :=
  ∀ k : ℤ, IsIntegerSquare (P.y hp k) → (P.b : ℚ) ^ 2 ≤ P.y hp k

/-- The factorisation condition in Theorem 1.4(a). -/
def AdmissibleB (b : ℤ) : Prop :=
  ∃ b₁ b₂ : ℕ, b = (b₁ * b₂ : ℕ) ∧ 0 < b₂ ∧
    (b₁ = 1 ∨ b₁ = 5 ∨ b₁ = 13 ∨ b₁ = 17) ∧
    ∀ p : ℕ, p.Prime → p ∣ b₂ → p % 4 ≠ 1

noncomputable def largeSquareThreshold (P : Parameters) : ℝ :=
  (2643 / 100 : ℝ) * (P.b : ℝ) ^ (8 / 3 : ℝ) * |(P.normAlpha : ℝ)| ^ 2 /
    Real.sqrt (P.d : ℝ)

/-- The six bounds in Proposition 4.1, in their printed order. -/
noncomputable def preciseSquareThreshold (P : Parameters) : ℝ :=
  let b : ℝ := P.b
  let d : ℝ := P.d
  let N : ℝ := |(P.normAlpha : ℝ)|
  max ((21 / 100 : ℝ) * b ^ (26 / 11 : ℝ) * N ^ (13 / 11 : ℝ) / d ^ (12 / 11 : ℝ))
  (max (b ^ (8 / 3 : ℝ) * N ^ (7 / 6 : ℝ) / (10 * d ^ (7 / 6 : ℝ)))
  (max ((148 / 10 : ℝ) * b ^ (4 / 3 : ℝ) * N ^ (5 / 3 : ℝ) / Real.sqrt d)
  (max ((2643 / 100 : ℝ) * b ^ 2 * N ^ 2 / Real.sqrt d)
  (max (4 * N / Real.sqrt d) (b ^ 2 * N / d)))))

noncomputable def discriminantThreshold (P : Parameters) : ℝ :=
  17 * (P.b : ℝ) ^ (28 / 13 : ℝ) * Real.sqrt |(P.normAlpha : ℝ)| /
    (P.u : ℝ) ^ (24 / 13 : ℝ)

/-- Theorem 1.3, label `thm:1.2-seq-new`. Pending. -/
def Theorem13 : Prop :=
  ∀ (P : Parameters) (h : P.Admissible),
    P.normAlpha < 0 → IsSquare (-P.normAlpha) → SmallestInitialSquare P h.pell →
    ∀ K : ℤ, P.IsNegativeCutoff h.pell K →
      AtMostSquareValuesOn (P.y h.pell)
        (fun k => (1 ≤ k ∨ k ≤ K) ∧ largeSquareThreshold P < (P.y h.pell k : ℝ)) 2

/-- Proposition 4.1, label `prop:1.2-seq-new`. Pending. -/
def Proposition41 : Prop :=
  ∀ (P : Parameters) (h : P.Admissible),
    P.normAlpha < 0 → IsSquare (-P.normAlpha) → SmallestInitialSquare P h.pell →
    ∀ K : ℤ, P.IsNegativeCutoff h.pell K →
      AtMostSquareValuesOn (P.y h.pell)
        (fun k => (1 ≤ k ∨ k ≤ K) ∧ preciseSquareThreshold P < (P.y h.pell k : ℝ)) 2

/-- Theorem 1.4(a), label `thm:1.3-seq-new`. Pending. -/
def Theorem14a : Prop :=
  ∀ (P : Parameters) (h : P.Admissible),
    P.normAlpha < 0 → IsSquare (-P.normAlpha) → SmallestInitialSquare P h.pell →
    AdmissibleB P.b → ∀ K : ℤ, P.IsNegativeCutoff h.pell K →
      AtMostSquareValuesOn (P.y h.pell) (fun k => 2 ≤ k ∨ k ≤ K - 1) 2

/-- Theorem 1.4(b); the exclusion of part (a) is retained. Pending. -/
def Theorem14b : Prop :=
  ∀ (P : Parameters) (h : P.Admissible),
    P.normAlpha < 0 → IsSquare (-P.normAlpha) → SmallestInitialSquare P h.pell →
    ¬ AdmissibleB P.b → discriminantThreshold P ≤ (P.d : ℝ) →
    ∀ K : ℤ, P.IsNegativeCutoff h.pell K →
      AtMostSquareValuesOn (P.y h.pell) (fun k => 2 ≤ k ∨ k ≤ K - 1) 2

/-- Corollary 1.5(a), label `cor:1.3-seq-new`. Pending. -/
def Corollary15a : Prop :=
  ∀ (P : Parameters) (h : P.Admissible),
    P.normAlpha < 0 → IsSquare (-P.normAlpha) → SmallestInitialSquare P h.pell →
    AdmissibleB P.b → AtMostSquareValues (P.y h.pell) 5

/-- Corollary 1.5(b). Pending. -/
def Corollary15b : Prop :=
  ∀ (P : Parameters) (h : P.Admissible),
    P.normAlpha < 0 → IsSquare (-P.normAlpha) → SmallestInitialSquare P h.pell →
    ¬ AdmissibleB P.b → discriminantThreshold P ≤ (P.d : ℝ) →
    AtMostSquareValues (P.y h.pell) 5

end AnyBNormSquare
