"""Statement and proof-route audit for the general-b Section 4.1 checkpoint."""
from dependency_guard import ROOT, SOURCE_STEM, SOURCE_HASHES, sha, require, write_json, verify_sources

LOCAL = "AnyBNormSquare.Prerequisites."
JNT = "«JNT-2024»."
ROUTES = {
    "scale_le_sqrt_abs": ["padicValInt_dvd"],
    "gaussian_g_upper": [JNT+"Approximation.g1_unit", JNT+"Section2.g2_gaussian", JNT+"Section2.g3_gaussian"],
    "gaussian_scale_upper": ["AnyBNormSquare.Lemma35Proof.one_le_g", LOCAL+"scale_le_sqrt_abs", JNT+"Approximation.dPrimeInteger_cast"],
    "gaussian_normalizer_bounds": [LOCAL+"gaussian_scale_upper", LOCAL+"gaussian_g_upper", "AnyBNormSquare.Lemma35Proof.lower_bound"],
    "coordinate_bounds": ["Real.sq_sqrt"],
    "parameter_bounds": [JNT+"Section4.exp_168_bounds"],
    "sequence_coordinates": [JNT+"Parameters.norm_identity", "AnyBNormSquare.unitPowerNorm_sign", "AnyBNormSquare.unitPowerNorm_cast"],
    "sequence_Q_chain": ["AnyBNormSquare.Revision06f.gaussian_Q_lower_chain", LOCAL+"coordinate_bounds", LOCAL+"sequence_coordinates"],
    "sequence_certificate": [JNT+"Parameters.sequence_square_representation_input_indexed", JNT+"Parameters.proposition31b_published", JNT+"Parameters.signed_representation_datum"],
    "comparison_identity": [JNT+"Parameters.sequence_cross_residual_published"],
    "comparison_pair": [JNT+"Section4.comparison_phase_3959", JNT+"Section4.comparison_integers", JNT+"FourthPowerDatum.cross_denominator_norm", JNT+"Parameters.sequence_cross_residual_published"],
    "threshold_implies_coordinate_size": ["Real.sqrt_le_self_iff"],
    "application_parameters": [LOCAL+"gaussian_normalizer_bounds", LOCAL+"parameter_bounds", LOCAL+"threshold_implies_coordinate_size", JNT+"Section4.gaussian_parameters", "AnyBNormSquare.Revision06f.gaussian_Q_gt", JNT+"Section4.gaussian_input_bounds"],
    "prepare": [LOCAL+"sequence_certificate", LOCAL+"comparison_pair", LOCAL+"application_parameters", JNT+"Parameters.section4_integer_coordinates"],
    "apply_prepared": ["AnyBNormSquare.Construction.lemma21_conditional", LOCAL+"sequence_coordinates"],
    "prepare_and_apply": [LOCAL+"prepare", LOCAL+"apply_prepared"],
}
CONDITIONAL = {"apply_prepared", "prepare_and_apply"}
FORBIDDEN = {JNT+"Parameters."+n for n in ["section4_comparison", "section4_parameter_bounds_published", "section4_norm_range", "section4_coordinate_bounds", "section4_representation"]}

def audit_prerequisites(rows=None):
    verify_sources(ROOT)
    if rows is not None:
        by_name = {r["name"]:r for r in rows}
        for name, deps in ROUTES.items():
            row = by_name[LOCAL+name]
            require(row["theorem"], "Expected proved theorem: "+name)
            for dep in deps: require(dep in row["deps"], "Missing prerequisite proof route: "+name+" -> "+dep)
            require((JNT+"Hypergeometric.DenominatorEstimate4" in row["deps"]) == (name in CONDITIONAL), "Unexpected denominator premise: "+name)
        for row in rows:
            if row["module"] == "AnyBNormSquare.Prerequisites":
                require(not set(row["deps"]) & FORBIDDEN, "Used b=1 application wrapper: "+row["name"])
    steps = [
        (832,869,"Square/index assumptions, normalizer bounds and consolidated size condition",["gaussian_g_upper","gaussian_scale_upper","gaussian_normalizer_bounds","threshold_implies_coordinate_size","prepare"]),
        (872,908,"Actual indexed representations, minimizing fourth-root phase, exact residual and 3.959 comparison",["sequence_certificate","comparison_identity","comparison_pair"]),
        (922,940,"Norm identity, non-strict 0.9375 estimate, 1.04 comparison and actual Gaussian coordinates",["coordinate_bounds","sequence_coordinates"]),
        (942,978,"E lower bound, E>1, corrected Q chain, Q upper bound, ell and near-one condition",["parameter_bounds","sequence_Q_chain","application_parameters"]),
        (980,995,"Gaussian comparison pair, literal real-fourth-power norm formula and f-product bound",["sequence_certificate","comparison_pair"]),
        (998,1008,"c=3/4 and connection to both parts of Lemma 2.1 with exact/nonexact distinction",["prepare","apply_prepared","prepare_and_apply"]),
    ]
    report = dict(status="passed" if rows is not None else "compiled audit pending",
        scope="Section 4.1 prerequisites and conditional connection to Lemma 2.1; four cases and main theorems pending",
        source="source/"+SOURCE_STEM+".tex", source_sha256=SOURCE_HASHES[".tex"],
        lean_sha256=sha(ROOT/"AnyBNormSquare/Prerequisites.lean"), manuscript_complete=False,
        corrections=["Only the author-approved 06f first comparison in (4.9): > becomes >=; Q>21.12>1 remains strict"],
        silent_mathematical_repairs=[], alternative_arguments=[],
        b_one_assumption_added=False, f_and_b_factors_retained=True, denominator_estimate_proved=False,
        conditional_declarations=sorted(CONDITIONAL),
        data_interface="Prepared is an internal bundle whose existence is proved by prepare from manuscript hypotheses. prepare_and_apply constructs it, then constructs the actual approximants from the explicit denominator premise. No external Prepared or approximant existence premise is assumed by that endpoint.",
        exactness="The Lemma 2.1(b) determinant condition is retained. All decimals are rational literals; (y_i*y_j)^(1/4) is real rpow.",
        normalization="The manuscript's standing smallest-initial-square convention remains an explicit hypothesis; its global availability is a later normalization checkpoint.",
        steps=[dict(first_line=a,last_line=b,argument=c,lean=[LOCAL+n for n in names]) for a,b,c,names in steps],
        proof_routes_checked=ROUTES if rows is not None else {})
    write_json(ROOT/"audit/prerequisites-faithfulness.json",report)
    return report
