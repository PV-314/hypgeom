"""Dependency identity and Lake resolution checks for the supplied release.

This module contains no mathematical declarations. The trusted source of JNT
and transitive pins is the exact SHA-256-pinned archive, not an editable cache.
"""
from pathlib import Path, PurePosixPath
import copy
import hashlib
import json
import os
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
RELEASE = "JNT-2024-faithful-20261106-f2-evidence1"
ARCHIVE_SHA = "158fc598a641828d30b5e543608a66c5e6e61d64104eb8881ce2cf522b726990"
SOURCE_STEM = "sequence-version-any-b-nrmA-sqr-with-y-result-2026-11-07b"
SOURCE_HASHES = {
    ".tex": "ee5fe5a080c2a02fb216ae9d42f0f331b937950fce1a7b07b481e14f0fd0ddb7",
    ".pdf": "49cd9540c161ed25c35f450ff991ed8814d1663be2a43bc20d2674e04ef5a875",
}
SOURCE_DIR = Path(os.environ.get("ANYB_MANUSCRIPT_DIR", ROOT / "source"))
CONFIG_HASHES = {
    "lakefile.toml": "b59d349f08119a4afbdee980ecb88390507199d9979e4cde1e3f73529c12a31b",
    "lean-toolchain": "ca5f1f601d34c49079e38d7e7041eb0f2a9c227fbc1df0f404820069a052330c",
}
LEAN_COMMIT = "eb6cafb7290e8bd5f2937522d8d804f58f02bafc"
JNT_NAME = "«JNT-2024»"


class DependencyError(RuntimeError):
    """A pin, verified source, or effective dependency path is inconsistent."""


def require(condition, message):
    if not condition:
        raise DependencyError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def json_bytes(value):
    # Preserve the established Windows pin bytes on every host platform.
    return (json.dumps(value, indent=2) + "\n").replace("\n", "\r\n").encode("utf-8")


def read_json(path):
    def unique_keys(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, f"Duplicate JSON key {key!r} in {path}")
            result[key] = value
        return result
    return json.loads(Path(path).read_text(encoding="utf-8"), object_pairs_hook=unique_keys)


def write_json(path, value):
    """Write generated reports only. Pin files use initialize_pin instead."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and read_json(path) == value:
        return
    path.write_bytes(json_bytes(value))


def check_pin(path, expected, allow_missing=False):
    path = Path(path)
    if not path.exists():
        require(allow_missing, f"Missing pin: {path}")
        return
    require(path.read_bytes() == expected, f"Changed pin: {path}; refusing to rewrite it")


def initialize_pin(path, expected):
    """Create a missing pin; never repair or overwrite an existing one."""
    path = Path(path)
    check_pin(path, expected, allow_missing=True)
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as stream:
            stream.write(expected)


def archive_members(archive):
    require(sha(archive) == ARCHIVE_SHA, "Wrong or changed JNT release archive")
    rows = {}
    with zipfile.ZipFile(archive) as z:
        for item in z.infolist():
            if item.is_dir():
                continue
            require(item.filename.startswith(RELEASE + "/"), "Unexpected archive root")
            relative = item.filename[len(RELEASE) + 1:]
            path = PurePosixPath(relative)
            require(not path.is_absolute() and ".." not in path.parts and "\\" not in relative,
                    "Invalid release member path")
            require(relative not in rows, "Duplicate release member")
            rows[relative] = z.read(item)
    return rows


def expected_contract(members):
    upstream = json.loads(members["lake-manifest.json"])
    manifest = copy.deepcopy(upstream)
    for entry in manifest["packages"]:
        entry["inherited"] = True
    manifest["name"] = "AnyBNormSquare"
    manifest["packages"].insert(0, dict(name=JNT_NAME, type="path", scope="",
        dir=".dependencies/" + RELEASE, copy=True, inherited=False,
        configFile="lakefile.toml", manifestFile="lake-manifest.json"))
    lock = dict(schema=1, release=RELEASE, archive_sha256=ARCHIVE_SHA,
        release_manifest_sha256=hashlib.sha256(members["release/MANIFEST.sha256"]).hexdigest(),
        lean_toolchain=members["lean-toolchain"].decode().strip(),
        git_revisions={p["name"]: p["rev"] for p in upstream["packages"]},
        lake_manifest_sha256=hashlib.sha256(json_bytes(manifest)).hexdigest())
    return manifest, lock, {p["name"]: p for p in upstream["packages"]}


def verify_pin_files(root, members, allow_missing=False):
    for name, digest in CONFIG_HASHES.items():
        require(sha(root / name) == digest, f"Changed build configuration: {name}")
    manifest, lock, packages = expected_contract(members)
    check_pin(root / "lake-manifest.json", json_bytes(manifest), allow_missing)
    check_pin(root / "dependencies.lock.json", json_bytes(lock), allow_missing)
    return manifest, lock, packages


def verify_release(dep, members=None):
    if members is None:
        members = archive_members(ROOT / ".dependencies" / (RELEASE + ".zip"))
    for name, data in members.items():
        path = dep / name
        require(path.is_file() and path.read_bytes() == data, f"Changed release file: {path}")


def provenance():
    return {suffix[1:]: dict(
        original_file=SOURCE_STEM + suffix,
        file="source/" + SOURCE_STEM + suffix, sha256=digest)
        for suffix, digest in SOURCE_HASHES.items()}


def verify_sources(root):
    for suffix, digest in SOURCE_HASHES.items():
        require(sha(root / "source" / (SOURCE_STEM + suffix)) == digest,
                f"Changed supplied manuscript: {suffix}")
    check_pin(root / "source/provenance.json", json_bytes(provenance()))


def override_entry(pin, directory):
    return dict(name=pin["name"], type="path", scope=pin["scope"], dir=str(directory),
        copy=False, inherited=True, configFile=pin["configFile"], manifestFile=pin["manifestFile"])


def validate_overrides(data, packages, root):
    require(isinstance(data, dict) and set(data) == {"version", "packages"}
            and data["version"] == "1.3.0" and isinstance(data["packages"], list),
            "Unexpected overrides document format")
    result = {}
    for entry in data["packages"]:
        require(isinstance(entry, dict), "Invalid override entry")
        name = entry.get("name")
        require(isinstance(name, str) and name in packages,
                f"Unexpected override {name!r}; JNT and root-package overrides are forbidden")
        require(name not in result, f"Duplicate override: {name}")
        directory = entry.get("dir")
        require(isinstance(directory, str) and bool(directory), f"Invalid override path: {name}")
        expected = override_entry(packages[name], directory)
        require(entry == expected, f"Unexpected override fields: {name}")
        result[name] = (root / directory).resolve()
    return result


def load_overrides(root, packages):
    path = root / ".lake/package-overrides.json"
    return validate_overrides(read_json(path), packages, root) if path.exists() else {}


def verify_git(path, pin):
    actual = subprocess.check_output(["git", "-C", str(path), "rev-parse", "HEAD"],
                                     text=True).strip()
    require(actual == pin["rev"], f"Wrong git revision: {pin['name']}")
    dirty = subprocess.run(["git", "-C", str(path), "diff", "--quiet", "HEAD"])
    require(dirty.returncode == 0, f"Changed tracked dependency sources: {pin['name']}")


def runtime(lean_bin=None):
    env = os.environ.copy()
    for name in ["LEAN_PATH", "LEAN_SRC_PATH", "LEAN_SYSROOT", "LEAN", "LAKE", "LAKE_HOME"]:
        env.pop(name, None)
    if lean_bin:
        env["PATH"] = str(Path(lean_bin).resolve()) + os.pathsep + env["PATH"]
    env["LEAN_NUM_THREADS"] = "2"
    lean, lake = (shutil.which(name, path=env["PATH"]) for name in ["lean", "lake"])
    require(lean and lake, "Install the pinned Lean/Lake or supply --lean-bin")
    lean, lake = Path(lean).resolve(), Path(lake).resolve()
    require(lean.parent == lake.parent, "Lean and Lake come from different toolchains")
    version = subprocess.check_output([str(lean), "--version"], env=env, text=True).strip()
    require("version 4.35.0," in version and LEAN_COMMIT in version, "Wrong Lean compiler")
    lake_version = subprocess.check_output([str(lake), "--version"], env=env, text=True).strip()
    require("eb6cafb" in lake_version and "Lean version 4.35.0" in lake_version, "Wrong Lake compiler")
    return dict(env=env, lean=lean, lake=lake, version=version, lake_version=lake_version)


def path_key(path):
    return os.path.normcase(str(Path(path).resolve()))


def validate_lake_paths(data, root, paths, rt):
    binary = [path_key(p) for p in data["LEAN_PATH"].split(os.pathsep) if p]
    source = [path_key(p) for p in data["LEAN_SRC_PATH"].split(os.pathsep) if p]
    system = rt["lean"].parent.parent
    expected_binary = {path_key(p / ".lake/build/lib/lean") for p in paths.values()}
    expected_binary |= {path_key(root / ".lake/build/lib/lean"), path_key(system / "lib/lean")}
    expected_source = {path_key(p) for p in paths.values()}
    expected_source |= {path_key(root), path_key(system / "src/lean/lake")}
    require(set(binary) == expected_binary and len(binary) == len(set(binary)),
            "Lake's effective binary search paths differ from the verified dependencies")
    # Multiple libraries/executables in a package legitimately repeat a source directory.
    require(set(source) == expected_source,
            "Lake's effective source search paths differ from the verified dependencies")
    for key, expected in [("LEAN", rt["lean"]), ("LAKE", rt["lake"]),
                          ("LEAN_SYSROOT", system), ("LAKE_HOME", system)]:
        require(path_key(data[key]) == path_key(expected), f"Lake resolved an unexpected {key}")


def probe_lake(root, paths, rt):
    names = ["LEAN_PATH", "LEAN_SRC_PATH", "LEAN_SYSROOT", "LEAN", "LAKE", "LAKE_HOME"]
    command = "import os,json; print(json.dumps({k:os.environ.get(k,'') for k in " + repr(names) + "}))"
    output = subprocess.check_output([str(rt["lake"]), "-R", "env", sys.executable, "-B", "-c", command],
        cwd=root, env=rt["env"], text=True, encoding="utf-8")
    data = json.loads(output)
    validate_lake_paths(data, root, paths, rt)
    return data


def verify_dependencies(root=ROOT, rt=None, probe=True):
    members = archive_members(root / ".dependencies" / (RELEASE + ".zip"))
    _, lock, packages = verify_pin_files(root, members)
    verify_sources(root)
    verify_release(root / ".dependencies" / RELEASE, members)
    verify_release(root / ".lake/packages/JNT-2024", members)
    overrides = load_overrides(root, packages)
    paths = {name: overrides.get(name, (root / ".lake/packages" / name).resolve())
             for name in packages}
    for name, path in paths.items():
        verify_git(path, packages[name])
    paths[JNT_NAME] = (root / ".lake/packages/JNT-2024").resolve()
    result = dict(archive_sha256=ARCHIVE_SHA, release_files=len(members),
        git_revisions=lock["git_revisions"],
        effective_package_paths={n: str(p) for n, p in paths.items()},
        manifest_sha256=sha(root / "lake-manifest.json"),
        lock_sha256=sha(root / "dependencies.lock.json"),
        overrides_sha256=sha(root / ".lake/package-overrides.json") if overrides else None)
    if probe:
        require(rt is not None, "A pinned runtime is required for a Lake resolution check")
        result["lake_environment"] = probe_lake(root, paths, rt)
        result["lean"] = rt["version"]
        result["lake"] = rt["lake_version"]
    return result
