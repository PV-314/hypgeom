# Final 07b scope decisions

Section 1.1 excludes a zero rational coordinate at the new starting square by using that −Nα is a square. The release proves that argument under this hypothesis and retains the original domains of the two conjectures. The user's private wording clarification is not a new source revision.

The finite three-square example in lines 269–276 is checked in Remarks.lean. The author retained lines 278–279 as an indication of possible improvement. This entails no change to a mathematical statement, proof, constant or premise used by the release.

## 07b, Section 5.6

06g described the Java search using the six-term threshold displayed in Proposition 4.1. The corrected text cites (4.18), (4.20), (4.25), (4.28) and uses the strict search bound Y(b,d). The 07b revision restores the full exceptional quartic claim, including the initial solution, and removes the forward reference introduced in 07a. No numbered statement changed. The Java and Magma completeness claims are explicit external obligations.

# Author correction in 06g: Section 5.4

Original 06f lines 1604--1605 say to take the reciprocal-exponent-th root.
The author changed this to raising both sides to that power in 06g lines
1604--1606. This is the correct monotone operation for positive bases and
r_0 >= 2. The next displayed bound and all constants are unchanged.
Revision06g.power_step proves the operation, and exponent_identities checks
its cancellations. This is not a replacement argument. Three further edits
are grammar only (TeX lines 273,455,583); the last is within Lemma 3.1 but
changes no hypothesis. Earlier mathematical proof modules remain unchanged.

# Author-approved 06f correction

At 06f TeX line 955, equation (4.9), the author changed the first `>` to
`\geq`. Original: Q strictly exceeds the expression containing sqrt(0.9375).
Correction: Q is at least that expression, directly from (4.6).
The next comparison is still strict, so Q>21.12>1 and downstream bounds are
unchanged. Revision06f.lean follows this weak/strict chain without introducing
the previously suggested equality-exclusion argument. The denominator estimate
remains unproved. No other manuscript edit is incorporated by this migration.

The entries below are historical records of earlier checkpoints.

# Section 2.1 construction checkpoint

No new mathematical correction or alternative argument was introduced.
The 06e manuscript is unchanged. The current module imports the pinned JNT
construction and exposes its correspondences to the printed formulas.
The denominator estimate remains unproved and explicit; conditional assembly
is not recorded as an unconditional result. All earlier proof modules are
byte-identical to the revision06e checkpoint.

# Author-approved 06e revision

The author supplied 06e and explicitly confirmed the fixed k0 choice.
No assistant repair of the manuscript has been applied.

- Original (06c, lines 521--524): error identity without an explicit near-one
  condition. Revised (06e, lines 521--527): require |omega-1|<1 and refer to
  Section 4.1 for its verification. Consequence: the assertion is expressly
  restricted; the printed Lemma 3.4 argument supplies the condition in the
  application. Both raw and phase-corrected identities reuse pinned JNT proofs.
  This is not a claim that the identity fails outside the stated disk.
- Original (06c, line 547): k0<1.257. Revised (06e, line 551): k0=1.257.
  New line 559 explains the choice using 1.072 C4,1<1.257. The pinned JNT
  constants give exactly 1.256384<1.257. Its strict approximation bound holds
  for the fixed value, still conditional on the unproved denominator estimate.
  The replacement in Section 4.2 retains the already strict inequalities;
  no new downstream numerical value or argument is introduced.
- The 06d missing period and sentence fragment were fixed by the author in 06e.
  These have no mathematical effect.

All 14 numbered statements and the text from Section 3 onward are unchanged.
Old proof modules are byte-identical. The current source map accounts for the
four-line shift after Section 2. Historical reports below remain historical.

# Historical record through 06c

No mathematical correction has been applied to the supplied 2026-11-06c
manuscript through the Lemma 3.6 checkpoint. The file itself already incorporates
corrections to earlier published constants and to the approximation lemma.
Those corrected values and hypotheses are retained.

Lemma 3.5 required no correction. Its valuation-to-integrality implication is
expanded into a Lean proof using the existing JNT prime-by-prime divisibility
theorem. The original two-case argument and gcd bounds are retained.

Lemma 3.6 required no correction. The common-prime-power divisor fact quoted
in lines 797--798 is expanded into supporting Lean lemmas. The main proof
retains the factorisation argument, both cases for the exponent of 2, and
the printed modulo-16 residue list.

The full paper has not yet been proof-audited. No claim of error-freedom is
made. For each future repair record the exact TeX label and lines, original
claim or argument, mathematical obstruction, minimal correction, effect on
hypotheses/constants/downstream results, and Lean evidence. Alternative
arguments or improvements are outside the authorised faithful task.

Section 4.1 checkpoint: no further mathematical correction was needed.
The non-strict coordinate/Q step is retained exactly as printed in 06f.
The original argument uses general-b indexed representations; the formalisation
reuses the corresponding lower-level JNT results and keeps f and b explicit.
No b=1 application hypothesis or alternative equality-exclusion proof is inserted.

Section 4.2 checkpoint (06f): no mathematical correction or change of argument.
The original assertions and all constants are retained. The phase is absorbed
into the Gaussian comparison numerator, as in the established Section 4.1
interface; determinant nonvanishing is exactly the paper's nonexact case.
Squared absolute norms and squared signed norms agree by sq_abs; natural
powers at r>=1 and real 22nd-root exponents retain the printed meanings.
The proof expands the justification that the middle index is nonzero and that
its square value satisfies the size hypothesis for the second gap application.
These follow from the existing normalization, ordering and size assumptions;
no additional hypothesis or manuscript repair is needed.

Sections 4.3--4.6 checkpoint (06f): no new mathematical correction or alternative
argument. All printed constants and final bounds are retained. The general
JNT division identities are instantiated with the actual b-dependent factors,
not with its fixed b=1 constants. The square-coordinate bound used for 1.498 is
exactly equation (4.6), label eq:25, with coefficient 0.9375. Natural reindexing
n=2r-1 or n=r-1 merely abbreviates the printed exponents under r>=2. Positive
real-root identities connect those expressions to the displayed fractional
powers. The ordered-three contradiction is converted into the literal count
of distinct square values without imposing integrality on all sequence terms.
DenominatorEstimate4 remains the accepted explicit unproved premise.
