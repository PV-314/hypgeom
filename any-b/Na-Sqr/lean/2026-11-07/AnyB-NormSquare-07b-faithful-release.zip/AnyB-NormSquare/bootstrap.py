"""Prepare missing pinned dependencies; reject drift instead of repairing pins.

Python 3.9+. Optional caches accelerate compilation without changing source
dependencies. Existing pins and overrides are checked before setup writes.
"""
from pathlib import Path
import argparse
import shutil
from dependency_guard import (
    ROOT, RELEASE, ARCHIVE_SHA, SOURCE_STEM, SOURCE_HASHES, ORIGINAL_DIR,
    sha, write_json, verify_release, require, archive_members, verify_pin_files,
    initialize_pin, check_pin, json_bytes, provenance, load_overrides,
    validate_overrides, override_entry, verify_git,
)


def copy_bytes(source, target):
    Path(target).write_bytes(Path(source).read_bytes())
    return str(target)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path,
        default=ORIGINAL_DIR / "Lean/JNT-2024" / (RELEASE + ".zip"))
    parser.add_argument("--cache-root", type=Path)
    parser.add_argument("--jnt-cache", type=Path,
                        help="Optional exact-source JNT build cache, never a source dependency")
    args = parser.parse_args()
    archive = ROOT / ".dependencies" / (RELEASE + ".zip")
    origin = archive if archive.exists() else args.archive
    members = archive_members(origin)
    manifest, lock, packages = verify_pin_files(ROOT, members, allow_missing=True)
    existing_overrides = load_overrides(ROOT, packages)
    for name, path in existing_overrides.items():
        verify_git(path, packages[name])
    proposed = None
    if args.cache_root:
        proposed = dict(version="1.3.0", packages=[override_entry(pin,
            (args.cache_root / name).resolve()) for name, pin in packages.items()])
        paths = validate_overrides(proposed, packages, ROOT)
        for name, path in paths.items():
            verify_git(path, packages[name])
        check_pin(ROOT / ".lake/package-overrides.json", json_bytes(proposed), allow_missing=True)
    source_copies = []
    for suffix, digest in SOURCE_HASHES.items():
        name = SOURCE_STEM + suffix
        destination = ROOT / "source" / name
        original = ORIGINAL_DIR / "any-b/Na-Sqr" / name
        require(sha(destination if destination.exists() else original) == digest,
                f"Wrong or changed supplied manuscript: {name}")
        if not destination.exists():
            source_copies.append((original, destination))
    check_pin(ROOT / "source/provenance.json", json_bytes(provenance()), allow_missing=True)
    dep = ROOT / ".dependencies" / RELEASE
    target = ROOT / ".lake/packages/JNT-2024"
    for directory in [dep, target]:
        if directory.exists():
            verify_release(directory, members)
    if args.jnt_cache:
        cache = args.jnt_cache.resolve()
        names = ["JNT-2024.lean", "lakefile.toml", "lean-toolchain"] + sorted(
            n for n in members if n.startswith("JNT-2024/") and n.endswith(".lean"))
        require({p.relative_to(cache).as_posix() for p in (cache / "JNT-2024").rglob("*.lean")}
            == {n for n in names if n.startswith("JNT-2024/")}, "JNT cache source inventory mismatch")
        require(all((cache / n).read_bytes() == members[n] for n in names), "JNT cache source mismatch")
        require((cache / ".lake/build").is_dir(), "JNT cache has no build directory")

    # Every existing pin/override/source has now passed the preflight.
    archive.parent.mkdir(exist_ok=True)
    if not archive.exists():
        copy_bytes(origin, archive)
    if not dep.exists():
        for name, data in members.items():
            destination = dep / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
    for original, destination in source_copies:
        destination.parent.mkdir(parents=True, exist_ok=True)
        copy_bytes(original, destination)
    initialize_pin(ROOT / "source/provenance.json", json_bytes(provenance()))
    initialize_pin(ROOT / "lake-manifest.json", json_bytes(manifest))
    initialize_pin(ROOT / "dependencies.lock.json", json_bytes(lock))
    if proposed is not None:
        initialize_pin(ROOT / ".lake/package-overrides.json", json_bytes(proposed))
    if not target.exists():
        shutil.copytree(dep, target, copy_function=copy_bytes)
    verify_release(target, members)
    if args.jnt_cache:
        shutil.copytree(cache / ".lake/build", target / ".lake/build",
                        dirs_exist_ok=True, copy_function=copy_bytes)
        write_json(ROOT / ".lake/jnt-cache-provenance.json", dict(cache=str(cache),
            source_hashes={n: sha(cache / n) for n in names},
            note="Optional exact-source dependency cache. Lake validates build traces."))
    print("Supplied sources and JNT verified; existing pins preserved; missing setup prepared.")


if __name__ == "__main__":
    main()

