# External mathematical and computational inputs

## Section 5 of the 07b manuscript

The exact theorem types are in `AnyBNormSquare/Section5Main.lean`. Both parts
take JNT's `Hypergeometric.DenominatorEstimate4`, `ExternalResults.AkhtariTheorem11`
and `Calculations.Section46Magma`. The last two enter through the normalized
b=1 case of JNT Theorem 1.4. The denominator estimate is also used in the four
analytic cases. These are explicit, unproved arguments.

Theorem 1.4(a) has three additional unproved arguments, defined in
`AnyBNormSquare/Section56Calculations.lean`.

- `JavaEnumeration` gives the complete finite sets of tuples and their three
  c₁ counts in the precise arithmetic ranges of Table 1.
- `JavaSquareSearch` identifies exactly which of those tuples have a square
  below the real search bound on the specified tails. It includes correctness
  of the implemented stopping comparisons. The three c₂ values and the 18
  distinct equations are checked separately on the concrete records.
- `ExceptionalQuartics` describes the positive quartic solutions that
  correspond to the given sequence, up to sign, for each exceptional tuple.
  Both Magma and PARI/GP were used according to the author's confirmation.
  This premise does not require every quartic to have just two positive
  solutions across all possible sequences.

Lean verifies the exact Table 1 bounds D and U, the sizes of the recorded hit
lists, the two quartic points on each row and both coordinates at the actual
recorded index. The historical October output and later Java changes remain
distinguished in the provenance records. All seven corrected PARI paths
loaded from the corresponding source directories at published Git commit
7ad2a61eb8f02864ebd4f90593b81a8b22867f3d.

## Release endpoints

Corollaries 1.5(a) and 1.6 inherit the six premises of Theorem 1.4(a). Corollary 1.5(b) inherits the three JNT premises of Theorem 1.4(b). Theorem 1.3, Proposition 4.1 and the concrete three-square example require only DenominatorEstimate4. Normalisation and the b<25 remark require none. The big-O suggestion is outside the theorem and premise inventories.

## Historical checkpoint records

## Earlier checkpoint records

No external theorem premise is added to the completed lemmas through the
Lemma 3.6 checkpoint. Their actual types are printed in audit/axioms-and-statements.log.

The supplied JNT release defines `JNT-2024.Hypergeometric.DenominatorEstimate4`
as a proposition for the cited large-index n=4 denominator estimate, r >= 139.
It is not a theorem proving that estimate. JNT's
`lemma23a_of_denominatorEstimate4` proves the finite part and takes this
large-index estimate as a premise. The user has explicitly accepted retaining
it unproved in this formalisation. Every conditional end-to-end theorem
exposes it as an argument; no axiom or proof of the estimate is introduced.
Lemmas 2.1 and 3.1--3.6 themselves do not use it.

JNT's other principal premises, Akhtari's theorem and the Section 4.6 Magma
completeness calculation, are not inherited as approvals for this paper.
If the b=1 reduction imports a JNT main theorem, inspect and disclose every
premise of that invocation.

This paper's Section 5.6 reports separate calculations for b=5,13,17:
enumeration counts 242598, 18110693, 58466661; respectively 8,6,10 exceptional
sequences; and 6+4+8=18 distinct quartic equations solved with Magma.
These are new proof obligations. No enumeration, completeness certificate,
quartic-solving transcript or proof of the reported counts is claimed here.
The attached files do not include the calculation code or certificates. The
manuscript names a public code location, which can be investigated in that
phase without replacing the authoritative TeX/PDF. An enumeration below a
bound does not by itself certify unrestricted quartic-solution completeness.

Historical timings and bibliographic assertions are not mathematical proofs.
Any proposed omission from the user's requested coverage must remain visible;
upstream omissions are not automatic scope exclusions in this project.

The 06e revision adds `section21_q_bound_conditional`, whose theorem type
explicitly takes `Hypergeometric.DenominatorEstimate4`. This proves an implication,
not that premise or an unconditional endpoint. `section21_error_identity`,
`section21_corrected_error_identity`, `paperK0_justified`, and
`section41_near_one` do not use the estimate. The supplied JNT archive and all
versions remain unchanged; the new manuscript does not update the upstream pin.

Section 2.1 construction checkpoint: `Construction.error_bound_conditional`,
`Construction.approximants_conditional` and `Construction.lemma21_conditional`
take DenominatorEstimate4 explicitly. `Construction.apply_lemma21` takes
PaperApproximants data (including their bounds); the end-to-end conditional
theorem constructs these data from the stated denominator premise. The
algebraic properties and formula bridges do not use the premise. The existing
`section21_q_bound_conditional` is reused. E,Q>1 are still hypotheses and
must be established in the subsequent Section 4.1 application checkpoint.

The 06f correction to (4.9) requires no new external mathematical premise.
Revision06f.Q_lower_chain and its Gaussian specialization use the printed
weak coordinate estimate, positive scale and L>=M; the next strict numerical
comparison is certified using JNT's exp_168_bounds. No denominator estimate
is used by these lemmas. Sequence hypotheses still need to supply these inputs.

Section 4.1 completion supersedes the earlier pending-application entries:
Prerequisites.prepare proves existence of the Prepared bundle from manuscript
hypotheses. Prerequisites.prepare_and_apply constructs both the bundle and
actual approximants; DenominatorEstimate4 remains an explicit unproved premise.
E>1, Q>1, Gaussian integrality, nonzero comparison denominator and near-one
are derived, not assumed as independent external obligations at that endpoint.
The global smallest-square normalization proof and later sections remain pending.

Section 4.2: `Case42.first_case_conditional` constructs the Prepared comparison
and actual JNT approximants from the manuscript hypotheses and the explicit
DenominatorEstimate4 premise. The general-bound and case helpers accept these
internal constructed data, retaining their formula identities and bounds.
No extra external estimate is added. `sequence_gaps` uses the proved local
Lemma 3.3 twice and is independent of DenominatorEstimate4.
The current user acceptance is specific to this denominator premise; it does
not approve any other external theorem or computational completeness premise.

Section 4 completion: `Section4Proof.no_three`,
`Section4Proof.proposition41_conditional` and
`Section4Proof.theorem13_conditional` explicitly take DenominatorEstimate4.
No Akhtari or Magma/computational-completeness premise is used by these proofs.
The representations and approximants are constructed, then shared by all four
case branches. Actual firstIndex minimality supplies the higher-index estimate.
The theorem types retain the manuscript's standing smallest-square convention;
its global availability by normalization has not been proved in this checkpoint.
The existing Proposition41 and Theorem13 definitions are unchanged interfaces;
separate conditional theorems now prove them. The estimate itself remains
unproved, and there is no unconditional-main-theorem claim.
