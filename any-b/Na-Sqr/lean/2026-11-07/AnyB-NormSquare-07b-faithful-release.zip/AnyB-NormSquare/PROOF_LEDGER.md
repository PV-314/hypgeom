# 07b release proof ledger

The current statement inventory is SOURCE_MAP.md. Earlier checkpoint entries below reflect their status at the time.

| 07b passage | Checked mathematical content |
|---|---|
| Section 1.1 | The pinned JNT Sequence, PaperBridge, IntroductionAudit and Monotonicity modules supply the coordinates, the unit criterion, the norm identity, the trace recurrence and the negative cutoff. Reindex.lean and Corollary16.lean supply the least square, integrality at a square, nonzero rational coordinate under square negative norm, translation, and reversal by negative conjugation. |
| Conjectures 1.1–1.2 and following remark | Conjecture11 and Conjecture12 record the even-power and unrestricted-power conjectures. JNT RepeatedValues.lean proves the printed reflection for (42,4,7,16,6) and the ring-of-integers unit condition. |
| Theorem 1.3 and following remarks | Section4.lean derives the theorem from Proposition 4.1. Remarks.lean proves the concrete three-square improvement using Lemma 3.3, the exact cube coefficient and Theorem 1.3. The citation of JNT's b=1 result is covered by its theorem14_revised. Lines 278–279 describe a possible future improvement, as confirmed by the author. |
| Theorem 1.4 | Section5Main.lean assembles the square-factor reduction, b=1 application of JNT, analytic cases, and finite computation described below. |
| Corollary 1.5 | Corollary15.lean adjoins the values at 0, 1 and K. Each square strictly between K and 0 is equal to the least square by the cutoff definition. |
| Corollary 1.6 and following remarks | Corollary16.lean applies Corollary 1.5(a) once per parity class and bounds the union. The even parity norm is preserved for every Pell unit. The odd shift uses norm +1. Remarks.lean checks the b<25 assertion. The historical comments on errata report the corrected constants used in Section 2. |
| Sections 2 and 3 | Reused.lean, Construction.lean, Revision06e.lean, Growth.lean, Normalizer.lean and AdmissiblePrimes.lean implement the cited estimates and the specialization m=1, n=4 used by the paper. The source-map rows name each numbered lemma; older audit reports specify the formula and proof correspondences. |
| Sections 4.1–4.6 | Prerequisites.lean constructs the common data, Case42.lean through Case45.lean retain the four alternatives and HigherIndex.lean gives the first-index estimate. Section4.lean gives both final thresholds and the count. |
| Sections 5.1–5.6 | Theorem 1.4 uses the reductions and four intermediate bounds in the printed order. Section56Cutoff.lean gives the strict search threshold. Section56Table.lean, Section56Records.lean and Section5Checks.lean certify the concrete finite data. Section56Calculations.lean gives the separate computational premises for exhaustiveness. |

The dates in preserved proof-module comments identify the checkpoint where those modules were introduced. Historical source hashes and correspondence reports permit verification against the later 07b revision. The manuscript files receive no edits during the release process.

## Historical checkpoint records

## 07b Section 5 completion

The two conditional theorems in Section5Main.lean establish 1.4(a,b).
The table, occurrence indices and quartic-point certificates are kernel checked.
EXTERNAL_INPUTS.md lists the premises. The Section 1.1 normalization at lines
181–190 needs a scope decision before the final release. Its exclusion of a=0
uses the square-norm assumption. Pinned JNT IntroductionAudit.lean, lines
41–92, gives a counterexample to using that exclusion for general norms.
This scope question does not affect Section 5.

## Earlier 07b checkpoint for the opening and finite records

SquareScaling formalises the simultaneous division of a and b. Section5Opening proves the b=1 and b<5 reductions and (5.3). Section5Low proves the two contradictions in each of Sections 5.1 and 5.2. Section56Records checks the recorded 24 hits, 18 distinct quartics, and both explicit points on every row. Infinite completeness remains external. The remaining Section 5 arguments and final corollaries are pending.

# Current source: author-corrected 06g

The 06g migration proves the corrected positive-power step in Section 5.4.
It preserves all earlier proof modules and dependency pins. Section 5 and
the final release remain in progress; external premises are approved and
remain explicit and unproved. Historical checkpoint notes follow.

# Current checkpoint: 06f and completion of Section 4

Section 4 follows all four printed cases and their consolidation. The exact
06f source and all prior proof modules, including Section 4.2, are preserved.
`Section4Proof.proposition41_conditional` and `theorem13_conditional` prove the
unchanged target propositions with DenominatorEstimate4 explicit and unproved.
The standing smallest-initial-square convention remains explicit; its global
normalization proof belongs to the later normalization checkpoint.
No new mathematical correction or alternative argument was introduced.
Current status and verified hashes are in verification.json; correspondence
and compiled proof routes are in audit/section4-faithfulness.json.

# Proof ledger and continuation plan

This remains a partial formalisation. Theorems 1.3 and 1.4 and Proposition 4.1 are proved conditionally. The remaining corollaries and the general normalization argument have a separate checkpoint.
See SOURCE_MAP.md for all 14 numbered statements.

1. **Source and dependency identity.** Pin the two supplied manuscript files
   and the supplied JNT archive. Import JNT definitions, keeping rational
   coordinates, integer indices, exact constants, principal arguments and
   value-based square counts. The JNT Pell/unit equivalence is available in
   `Parameters.admissible_iff_paper`; it is not an extra mathematical premise.
2. **Reused results.** Lemma 2.1 uses JNT's full imaginary quadratic theorem.
   Lemma 3.1 applies its published Proposition 3.1(b), then cancels the unit
   radical. Lemma 3.3 applies JNT Lemma 3.8(a); Lemma 3.4 applies JNT Lemma
   3.9(a). The public statements retain the paper's square/integer hypotheses.
3. **New growth lemma.** Lemma 3.2(a) reuses JNT Lemma 3.5(b). Part (b) uses
   the same square-completion seed and recurrence induction with rate `du²-3`.
   Part (c) splits on norm +1 or `du² >= 300`, then compares the rate to
   `99du²/100`. Its last sentence is exactly JNT's rate `2du²/5`.
4. **Lemmas 3.5 and 3.6 implemented.** `Normalizer.lean` preserves
   the two 2-adic valuation cases and the gcd bounds of Lemma 3.5, without
   introducing a coprimality or square-negative-norm assumption. It reuses
   JNT's definitions, valuation identities, integrality of `d′`, unit norm
   signs, and prime-by-prime divisibility theorem. The public statement
   includes the original sequence/integrality hypotheses and real fractional
   power; the normalizer interface is proved equivalent. The source-to-proof
   steps are recorded in `audit/lemma35-correspondence.json`. No correction
   was needed. `AdmissiblePrimes.lean` implements Lemma 3.6 using the printed
   sum-of-two-squares prime factorisation, the common `q^m` divisors, and the
   squarefree-gcd contradiction for primes congruent to 3 modulo 4. It then
   retains both exponent cases for 2, including `2^k | d` when `k < 4`, and
   the complete printed mod-16 residue list when `k ≥ 4`. It reuses pinned
   JNT valuation and residue results and mathlib's factorisation theorem.
   No correction was needed. See `audit/lemma36-correspondence.json`.
5. **Section 2 construction and Section 4.1 prerequisites completed conditionally.**
   The actual pinned approximants and comparison pair are constructed. The
   printed g/N4 bounds, 0.9375 and 1.04 estimates, E/Q/ell bounds, minimizing
   phase, residual identity, comparison norm and f-product bound are formalised.
   E,Q>1 are derived for the application. The only analytic obligation left
   as a premise is DenominatorEstimate4. All prior proof modules remain unchanged.
6. **Sections 4.2--4.5 completed conditionally.** All four cases retain the
   actual least index and actual JNT approximants. The first two cases apply
   the gap principle twice. The higher-index cases follow the printed cutoff
   lower bound, exponent manipulations, f-product elimination and real roots.
   Pinned JNT supplies the exact-case estimate, the general division identities,
   the cutoff-choice monotonicity and the exponential comparison. Its fixed
   b=1 or Q>190 wrappers are not used in place of this paper's constants.
7. **Section 4.6 completed conditionally.** `no_three` constructs the data once,
   splits into four cases and applies the six-way maximum. The counting bridge
   preserves distinct integer-square values on the stated index set. The
   coefficient/exponent comparison gives Theorem 1.3 from Proposition 4.1.
   Both conditional theorem types explicitly retain DenominatorEstimate4.
8. **Section 5 completed conditionally.** `Section5Proof.theorem14a_conditional`
   and `Section5Proof.theorem14b_conditional` prove the target propositions.
   Square-factor division transports the Pell sequence, cutoff, smallest
   square, norm and count. The b=1 case invokes pinned JNT. For the other
   cases the four Section 4 inequalities use the constructed approximants,
   and the two-step growth estimate supplies (5.3). Sections 5.1–5.5 retain
   the separate norm-dependent and norm-free inequalities, including the
   positive power in Section 5.4. Section 5.6 proves the exact Table 1
   `D_b` and `U_b` values and the strict `Y_{b,d}` bound. The final count
   uses the explicit enumeration, square-search and sequence-specific
   quartic premises in `Section56Calculations.lean`. Both parts count
   distinct values on the two printed tails. No additional correction
   to the 07b mathematics was needed in this checkpoint.
9. **Counting and normalisation.** Derive Corollary 1.5 from the two tail
   squares plus the three possible exceptional values. Formalise Corollary
   1.6 using the even/odd split, norm +1, reindexing, negative conjugation and
   the nonzero rational-coordinate argument. Reuse the located JNT
   `Parameters.generalY` and `generalY_even` in `Section6Sequence`; its exact
   target has not yet been added here. Both conjectures remain unasserted.
10. **Completion audit.** Verify every definition, labelled statement,
    displayed estimate used in proofs, finite calculation, and proof branch.
    Inspect full theorem types, generated declarations, axioms, proof-body
    dependencies and statement correspondence. Never equate build success
    with completion.

The smallest-square convention in Section 1.1 is explicit in the principal
target definitions. Its availability by normalisation still needs its printed
proof, particularly the zero-coordinate exclusion under square negative norm.
The first milestone has not silently established that normalisation step.
