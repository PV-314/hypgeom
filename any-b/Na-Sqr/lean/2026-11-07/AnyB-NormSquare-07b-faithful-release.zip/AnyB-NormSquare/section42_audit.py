"""Faithfulness, preservation and compiled proof-route audit for Section 4.2."""
from dependency_guard import ROOT, SOURCE_STEM, SOURCE_HASHES, sha, require, read_json, write_json, verify_sources

LOCAL = "AnyBNormSquare.Case42."
PRE = "AnyBNormSquare.Prerequisites."
JNT = "«JNT-2024»."
ROUTES = {
    "before_fourth": [LOCAL+"numerical_constants"],
    "at_one": [LOCAL+"numerical_constants"],
    "root_bound": [LOCAL+"numerical_constants", "Real.rpow_mul_natCast"],
    "norm_fourth": [PRE+"Prepared.denominator_norm", "Real.rpow_mul_natCast"],
    "error_chain": ["AnyBNormSquare.Construction.apply_lemma21", PRE+"sequence_coordinates", LOCAL+"error_factor"],
    "general_bound": [LOCAL+"substitute_Q", LOCAL+"before_fourth", LOCAL+"fourth_power", LOCAL+"expanded_bound", LOCAL+"norm_fourth", LOCAL+"error_chain", PRE+"application_parameters", JNT+"Approximation.firstIndex_spec"],
    "first_case_upper": [LOCAL+"general_bound", LOCAL+"at_one", LOCAL+"eliminate_f", PRE+"application_parameters"],
    "sequence_gaps": ["AnyBNormSquare.lemma33", LOCAL+"gap_twice", PRE+"threshold_implies_coordinate_size"],
    "first_case": [LOCAL+"first_case_upper", LOCAL+"sequence_gaps", LOCAL+"cancel_fifth", LOCAL+"root_bound"],
    "first_case_conditional": [PRE+"prepare", PRE+"apply_prepared", LOCAL+"first_case", JNT+"Hypergeometric.DenominatorEstimate4"],
}

def audit_section42(rows=None):
    verify_sources(ROOT)
    baseline = read_json(ROOT/"audit/section42-baseline.json")
    for name, digest in baseline["files"].items():
        if name not in baseline["authorised_existing_edits"]:
            require(sha(ROOT/("source/provenance06f.json" if name == "source/provenance.json" else name)) == digest, "Changed prior proof/source/pin: "+name)
    require((ROOT/"AnyBNormSquare.lean").read_text(encoding="utf-8") ==
        baseline["old_import"]+"\npublic import AnyBNormSquare.Case42\n\npublic import AnyBNormSquare.Case43\n\npublic import AnyBNormSquare.HigherIndex\n\npublic import AnyBNormSquare.Case44\n\npublic import AnyBNormSquare.Case45\n\npublic import AnyBNormSquare.Section4\n\npublic import AnyBNormSquare.Revision06g\n\npublic import AnyBNormSquare.Section5Work\n\npublic import AnyBNormSquare.Remarks\n", "Unexpected root import edit")
    require((ROOT/"Audit.lean").read_text(encoding="utf-8").startswith(baseline["old_audit"]), "Changed previous audit commands")
    archive = ROOT.parent/"output"/baseline["previous_checkpoint"]
    if archive.exists(): require(sha(archive) == baseline["previous_checkpoint_sha256"], "Previous checkpoint changed")
    if rows is not None:
        by_name = {r["name"]:r for r in rows}
        for name, deps in ROUTES.items():
            row = by_name[LOCAL+name]
            require(row["theorem"], "Expected proved theorem: "+name)
            for dep in deps:
                require(dep in row["deps"], "Missing Section 4.2 proof route: "+name+" -> "+dep)
            require((JNT+"Hypergeometric.DenominatorEstimate4" in row["deps"]) ==
                (name == "first_case_conditional"), "Unexpected denominator premise: "+name)
        for row in rows:
            if row["module"] == "AnyBNormSquare.Case42":
                require(not any("nonexact_paper_bound" in dep or "Section4NonexactPublished" in dep for dep in row["deps"]),
                    "Used a differently parameterized JNT nonexact bound: "+row["name"])
    steps = [
        (1013,1023,"General nonexact case: actual Lemma 2.1(b), comparison norm and strict error chain",["index","norm_fourth","error_factor","error_chain"]),
        (1026,1039,"Substitute k0=1.257 and Q upper bound before fourth powers; exact 0.636 rounding; expand exponents for r>=1",["numerical_constants","substitute_Q","before_fourth","fourth_power","expanded_bound","general_bound"]),
        (1041,1052,"r=1, M>=2, 2180 rounding and f-product <= b^4",["at_one","eliminate_f","first_case_upper"]),
        (1055,1075,"Lemma 3.3 twice; cube the resulting gap and cancel y_i^5; check both size/index hypotheses",["gap_twice","sequence_gaps","cancel_fifth"]),
        (1078,1085,"c=3/4, exact 22nd-root rounding and the printed bound",["root_bound","first_case","first_case_conditional"]),
    ]
    report = dict(status="passed" if rows is not None else "source preservation passed; compiled audit pending",
        scope="Section 4.2 of the exact 06f paper, including the general nonexact bound reused in Section 4.4",
        source="source/"+SOURCE_STEM+".tex", source_sha256=SOURCE_HASHES[".tex"],
        lean_sha256=sha(ROOT/"AnyBNormSquare/Case42.lean"), manuscript_complete=False,
        prior_proof_modules_unchanged=True, dependency_pins_unchanged=True,
        new_mathematical_corrections=[], silent_mathematical_repairs=[], alternative_arguments=[],
        denominator_estimate_proved=False, accepted_unproved_premise=JNT+"Hypergeometric.DenominatorEstimate4",
        conditional_endpoint=LOCAL+"first_case_conditional",
        data_interface="The endpoint constructs both Prepared and actual JNT PaperApproximants. The helpers work for every such constructed choice. The numerator already contains eta, so determinant nonvanishing is the printed nonexact condition with its sides reversed. No arbitrary rational approximant replaces the JNT construction.",
        statement_bridges="(N*f_i*f_k)^2 = (abs(N)*f_i*f_k)^2 by mul_pow and sq_abs. Division by a fourth power expresses the printed negative fourth exponent. The index is the actual least positive firstIndex; the general bound retains r>=1 and natural exponent 2r-2. Fractional exponents in the conclusion are real powers.",
        proof_details="The two cubic gaps yield G^4*y_i^9<y_k; cubing and cancelling positive y_i^5 yields G^12*y_i^22<A. The middle and final indices are nonzero by ordering and the standing smallest-initial-square convention. The size condition propagates to the middle value. No extra hypothesis is introduced.",
        constants={"before_fourth":"2*1.257 < 0.636*3.959", "at_one":"(0.636*21.47/2)^4 < 2180", "root":"2180*4^4 < 0.21^22*57.32^12"},
        jnt_reuse="Pinned Section 2 approximants and Lemma 2.1 through Construction/Prerequisites; pinned gap principle through local lemma33. JNT's fixed 0.64/35700 nonexact estimates cannot establish this paper's printed tighter constants and are not substituted.",
        pending="DenominatorEstimate4; Sections 4.3 onward and global normalization; main theorems remain unproved targets.",
        steps=[dict(first_line=a,last_line=b,argument=c,lean=[LOCAL+n for n in names]) for a,b,c,names in steps],
        proof_routes_checked=ROUTES if rows is not None else {})
    write_json(ROOT/"audit/section42-faithfulness.json",report)
    return report

if __name__ == "__main__":
    print(audit_section42())
