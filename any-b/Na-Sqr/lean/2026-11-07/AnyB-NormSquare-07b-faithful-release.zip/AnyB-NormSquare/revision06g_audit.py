"""Check the exact four author edits, preservation and corrected proof step."""
import re
from dependency_guard import ROOT, SOURCE_STEM, SOURCE_HASHES, SOURCE_DIR, sha, read_json, write_json, require, verify_sources

SOURCE_STEM = "sequence-version-any-b-nrmA-sqr-with-y-result-2026-11-06g"
SOURCE_HASHES = {'.tex': 'b3a9458b53e70c585a767648357d6d8319f950f546ccc69c593ff6061f0568c5', '.pdf': '6ecf3619fdb580b1f13434bfd71bbdc2202ea2d61aee44dbd873bcf24b564843'}

def audit_revision06g(rows=None):
    verify_sources(ROOT)
    old = ROOT / 'source/sequence-version-any-b-nrmA-sqr-with-y-result-2026-11-06f.tex'
    new = ROOT / 'source' / (SOURCE_STEM + '.tex')
    a, b = old.read_text(encoding='utf-8'), new.read_text(encoding='utf-8')
    replacements = [
        ('because, applying Lemma~\\ref{lem:gap}, we have', 'because, applying Lemma~\\ref{lem:gap}, we find that'),
        ('such that $U=\\left( u_{1}+u_{2}\\sqrt{t\'} \\right)/2$ be an algebraic integer in',
         'such that $U=\\left( u_{1}+u_{2}\\sqrt{t\'} \\right)/2$ is an algebraic integer in'),
        ('$t$ and $u$ non-zero rational integers,', '$t$ and $u$ are non-zero rational integers,'),
        ('Moving the factor of $d$ to the left-hand side and taking the $\\left( 3r_{0}-2 \\right)/ \\left( 2 \\left( r_{0}-1 \\right) \\right)$-th\nroot of both sides, this becomes',
         'Moving the factor of $d$ to the left-hand side and raising both sides to the\n$\\left( 3r_{0}-2 \\right)/ \\left( 2 \\left( r_{0}-1 \\right) \\right)$-th power,\nthis becomes')]
    expected = a
    for before, after in replacements:
        require(expected.count(before) == 1, 'Ambiguous or missing author edit')
        expected = expected.replace(before, after, 1)
    require(b == expected, 'Unreviewed 06g edit')
    pattern = r'\\begin\{(theorem|lemma|proposition|corollary|conjecture)\}.*?\\end\{\1\}'
    sa = [m.group().replace(*replacements[2]) for m in re.finditer(pattern,a,re.S)]
    sb = [m.group() for m in re.finditer(pattern,b,re.S)]
    require(len(sa)==14 and sa==sb,'Changed numbered mathematical statement')
    baseline = read_json(ROOT/'audit/revision06g-baseline.json')
    for name,digest in baseline['files'].items():
        if name.startswith('AnyBNormSquare/') or name in ['lakefile.toml','lean-toolchain','lake-manifest.json','dependencies.lock.json']:
            require(sha(ROOT/name)==digest,'Changed prior proof or dependency pin: '+name)
    require(sha(ROOT/'source/provenance06f.json')==baseline['files']['source/provenance.json'],'Old provenance changed')
    require((ROOT/'AnyBNormSquare.lean').read_text(encoding='utf-8')==baseline['old_import']+'\npublic import AnyBNormSquare.Revision06g\n\npublic import AnyBNormSquare.Section5Work\n\npublic import AnyBNormSquare.Remarks\n','Unexpected import edit')
    require((ROOT/'Audit.lean').read_text(encoding='utf-8').startswith(baseline['old_audit']),'Prior audit changed')
    require(read_json(ROOT/'audit/source-map06g.json')['sha256']==sha(new),'Stale source map')
    for ext,digest in SOURCE_HASHES.items():
        original=SOURCE_DIR/(SOURCE_STEM+ext)
        if original.exists(): require(sha(original)==digest,'Changed original attachment')
    pdf=read_json(ROOT/'audit/revision06g-pdf.json')
    require(pdf['status']=='passed' and pdf['pdf_sha256']==SOURCE_HASHES['.pdf'],'PDF mismatch')
    for name,digest in pdf['images'].items():require(sha(ROOT/'audit/pdf06g'/name)==digest,'Changed PDF image')
    if rows is not None:
        by_name={r['name']:r for r in rows}
        step=by_name['AnyBNormSquare.Revision06g.power_step']
        for suffix in ['exponent_positive','exponent_identities']:
            require('AnyBNormSquare.Revision06g.'+suffix in step['deps'],'Missing exponent proof')
        require('Real.rpow_lt_rpow' in step['deps'],'Missing monotonicity step')
        for row in rows:
            if row['module']=='AnyBNormSquare.Revision06g':
                require(not any(s in d for d in row['deps'] for s in ['DenominatorEstimate4','AkhtariTheorem11','Section46Magma']),'Unexpected external premise')
    report=dict(status='passed' if rows is not None else 'source checks passed; compiled audit pending',
        source_sha256=sha(new),pdf_sha256=SOURCE_HASHES['.pdf'],
        exact_author_edits=4,grammar_edits=3,numbered_statements_semantically_unchanged=14,
        correction={'original':'taking the reciprocal-exponent-th root','corrected':'raising both sides to the reciprocal-exponent-th power','consequence':'correct positive-power operation; following displayed bound unchanged','author_approved':True},
        prior_proof_sources_unchanged=True,dependency_pins_unchanged=True,
        silent_repairs=[],alternative_proofs=[],section5_complete=False,manuscript_complete=False)
    write_json(ROOT/'audit/revision06g-faithfulness.json',report)
    return report
