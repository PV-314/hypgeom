"""Package the verified 07b conditional release, including the exact dependency archive."""
from pathlib import Path
import argparse
import json
import zipfile
from dependency_guard import ROOT, RELEASE, ARCHIVE_SHA, sha, write_json, require, verify_sources


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
        default=ROOT.parent / "output/AnyB-NormSquare-07b-faithful-release.zip")
    args = parser.parse_args()
    verification = json.loads((ROOT / "verification.json").read_text(encoding="utf-8"))
    require(verification["status"] == "passed", "Verification has not passed")
    require(verification["manuscript_complete"] is True and verification["release_scope"]["numbered_statements"] == 14, "Unexpected manuscript status")
    tests = json.loads((ROOT / "audit/dependency-tests.json").read_text(encoding="utf-8"))
    require(tests["status"] == "passed", "Dependency tests have not passed")
    for name, digest in verification["inputs"].items():
        require(sha(ROOT / name) == digest, "Changed after verification: " + name)
    verify_sources(ROOT)
    archive = ROOT / ".dependencies" / (RELEASE + ".zip")
    require(sha(archive) == ARCHIVE_SHA, "Changed dependency archive")
    files = [p for p in ROOT.iterdir() if p.is_file() and p.suffix in
             {".py", ".json", ".md", ".toml"} and p.name != "PACKAGE-MANIFEST.json"]
    files += [ROOT / "AnyBNormSquare.lean", ROOT / "Audit.lean", ROOT / "Construction.lean"]
    files += [ROOT / "lean-toolchain", ROOT / ".gitignore"]
    for directory in ["source", "AnyBNormSquare", "audit"]:
        files += [p for p in (ROOT / directory).rglob("*") if p.is_file()]
    files.append(archive)
    files = sorted(set(files))
    manifest = {p.relative_to(ROOT).as_posix(): sha(p) for p in files}
    destination = args.output.resolve()
    require(not destination.exists() and not destination.with_suffix(".json").exists(),
            "Checkpoint already exists; choose a new output path")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, "x", zipfile.ZIP_DEFLATED) as z:
        for p in files:
            z.write(p, "AnyB-NormSquare/" + p.relative_to(ROOT).as_posix())
        z.writestr("AnyB-NormSquare/PACKAGE-MANIFEST.json", json.dumps(manifest, indent=2) + "\n")
    # Read every packaged member back and verify content, not just the ZIP CRC.
    import hashlib
    with zipfile.ZipFile(destination) as z:
        require(z.testzip() is None, "ZIP integrity check failed")
        for name, digest in manifest.items():
            require(hashlib.sha256(z.read("AnyB-NormSquare/" + name)).hexdigest() == digest,
                    "Packaged file hash mismatch: " + name)
    write_json(destination.with_suffix(".json"), dict(file=destination.name,
        sha256=sha(destination), bytes=destination.stat().st_size,
        files=len(manifest), manuscript_complete=True, conditional_on_agreed_premises=True,
        manuscript_revision="2026-11-07b", corrected_power_step=True, section5_complete=verification['section5_complete_conditionally'], corrected_Q_chain=True, section41_prerequisites=True, section42_first_case=True, section4_complete_conditionally=True, proposition41_conditional=True, theorem13_conditional=True, conditional_q_bound=True, conditional_construction=True, denominator_estimate_proved=False,
        verified_lemmas=["2.1", "3.1", "3.2(a,b,c)", "3.3", "3.4", "3.5", "3.6"]))
    print(destination)
    print("SHA-256: " + sha(destination))


if __name__ == "__main__":
    main()
